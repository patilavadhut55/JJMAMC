
<!--?php if(isset($_GET['id'])){ 
            $app = Application::LoadByIdapplication($_GET['id']);
            ?-->
<div class="form-controls" style="width: 90%; margin-left:40px;margin-right: 40px;margin-bottom: 90px;">
<table width="100%" cellpadding="6" cellspacing="0" bgcolor="#ffffff">
    <tbody>
        <tr valign="TOP">
            <td width="100%" bgcolor="#ffffff" style="border-width: initial; border-style: none; border-color: initial; padding: 0in;">
            <div align="Center" width="100%">
            <div style="float:left; margin-left:3%; width: 10%; margin-top: 20px;" align="right"><img src="../../assets/_core/images/Walchand_11.gif" width="100" height="85" alt="" /></div>
            <div style=" width: 85%; float:right; font-size: 25px; margin-top: 20px; text-align: center;">
            <div style="font-size: 18px; text-align: center;"><font color="#cc0000"><font face="Verdana, serif"><font style="font-size: 20pt;"><b>Walchand College of Engineering, Sangli</b></font></font></font></div>
            <div style="font-size: 13px;"><font color="#cc0000"><font face="Verdana, serif"><b>(An Autonomous Institute)</b></font></font></div>
            <div style="font-size: 15px;"><font size="4"><font color="#cc0000">Vishrambag, SANGLI-416415 (M.S.), India</font></font></div>
            <div style="font-size: 16px;"><font face="Verdana, serif"><font color="#cc0000">Website : www.walchandsangli.ac.in</font></font></div>
            <div style="font-size: 16px;"><font color="#cc0000">Email :&nbsp;<a href="mailto:director.wcesangli@gmail.com" style="color: rgb(0, 0, 255);">director.wcesangli@gmail.com</a>,&nbsp;<a href="mailto:director@walchandsangli.ac.in" style="color: rgb(0, 0, 255);">director@walchandsangli.ac.in</a>,&nbsp;<a href="mailto:walchand@rediffmail.com" style="color: rgb(0, 0, 255);">walchand@rediffmail.com</a></font></div>
            </div>
            <div style="clear: both; margin-top: 30px; ">&nbsp;</div>
            </div>
            </td>
        </tr>
    </tbody>
    <tbody>
        <tr>
            <td colspan="2" width="754" valign="TOP" bgcolor="#ffffff" style="border-top: 1.5pt solid rgb(204, 0, 0); border-bottom: 1.5pt solid rgb(204, 0, 0); border-left: none; border-right: none; padding: 0in;">
            <p align="CENTER" style="margin-bottom: 0.08in; direction: ltr;"><font color="#cc0000"> &#9742;</font><font color="#cc0000">&nbsp;Director +91-233-2303433&nbsp;</font><font color="#cc0000"><font face="Wingdings, serif"><font style="font-size: 16pt;">&#9742;</font></font></font><font color="#cc0000">&nbsp;Office +91-233-2300383 Fax : +91-233-2300831</font></p>
            </td>
        </tr>
    </tbody>
</table>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT FACE="Krishna, serif"><FONT SIZE=4 STYLE="font-size: 16pt"><FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt">Ref No.
Estt/Apptt.Ord./Contract/                                   
      </FONT></FONT></FONT></FONT></P>
<p align="RIGHT" style="margin-bottom: 0in; direction: ltr; font-family: &quot;Times New Roman&quot;; font-size: medium; line-height: 16px;"><font face="Times New Roman, serif"><font size="4"><b>Date: - <!--?php _p(date('d-m-Y',  strtotime(QDateTime::Now())));?--></b></font></font></p><p class="western" align="JUSTIFY" style="margin-bottom: 0in; direction: ltr; line-height: 13.3333px; font-family: &quot;Times New Roman&quot;, serif; font-size: 10pt;">&nbsp;</p>
<p align="LEFT" style="margin-bottom: 0in; direction: ltr; font-family: &quot;Times New Roman&quot;; font-size: medium; line-height: 16px;">To,</p>
<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt"><!--?php _p(delete_all_between('[',']',$app->ApplicantObject->OfObject->Name));?--></FONT></FONT></P>
 <p width="10%" class="western" align="LFET" style="margin-bottom: 0in; direction: ltr; line-height: 15.3333px; font-family: &quot;Times New Roman&quot;, serif; font-size: 10pt;"><font size="4"><!--?php _p($app->Data8);?--></font></p>
<H2 CLASS="western" ALIGN=JUSTIFY>   <FONT SIZE=2 STYLE="font-size: 11pt">	With
reference to your application dt. 04/10/2016  and on recommendation 
of HOD <!--?php _p(delete_all_between('[',']',$app->Data2));?--> Deptt., undersigned is pleased to inform 
that you have been offered the post of Assistant Professor  </FONT><FONT SIZE=2 STYLE="font-size: 11pt">in
</FONT><FONT SIZE=2 STYLE="font-size: 11pt"><SPAN STYLE="font-weight: normal"><!--?php _p(delete_all_between('[',']',$app->Data2));?--> </SPAN></FONT><FONT SIZE=2 STYLE="font-size: 11pt"> </FONT><FONT SIZE=2 STYLE="font-size: 11pt">on
</FONT><FONT SIZE=2 STYLE="font-size: 11pt"><SPAN STYLE="font-weight: normal">Degree
Wing</SPAN></FONT><FONT SIZE=2 STYLE="font-size: 11pt"> on following
terms &amp; conditions. </FONT>
</H2>
<OL>
	<LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt">Your
	appointment in the post of </FONT><FONT SIZE=2 STYLE="font-size: 11pt"><B>Assistant
	Professor</B></FONT><FONT SIZE=2 STYLE="font-size: 11pt"> in </FONT><FONT SIZE=2 STYLE="font-size: 11pt"><B><!--?php _p(delete_all_between('[',']',$app->Data2));?--></B></FONT><FONT SIZE=2 STYLE="font-size: 11pt">           
	                     </FONT><FONT SIZE=2 STYLE="font-size: 11pt"><B>
	      </B></FONT><FONT SIZE=2 STYLE="font-size: 11pt">is purely on
	temporary and contractual basis from the date of your joining  till 
	<!--?php _p($app->Data10);?-->  </FONT><FONT SIZE=2 STYLE="font-size: 11pt"><B>OR</B></FONT><FONT SIZE=2 STYLE="font-size: 11pt">
	joining of faculty member appointed on regular selection procedure
	whichever is earlier.    </FONT></FONT>
	</P>
</OL>
<OL START=2>
	<LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt">Your
	 pay on appointment will be Rs. <!--?php _p($app->Data4);?-->/- p.m. consolidated and you
	will not be entitled for any allowances. </FONT></FONT>
	</P>
</OL>
<OL START=3>
	<LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt">You
	will be subject to such service rules and regulations as are
	prescribed  for contract appointments from time to time by the
	college authorities.</FONT></FONT></P>
</OL>
<OL START=4>
	<LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt">The
	appointment is full time one and you are required to be present in
	the college during entire working hours of the college.</FONT></FONT></P>
</OL>
<OL START=5>
	<LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt">It
	is  obligatory for you to do such work in the College or outside,
	that pertains to and has bearing upon the smooth running or
	improvement of the College.</FONT></FONT></P>
</OL>
<OL START=6>
	<LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt">You
	will be required to carry out all work related to academic programs,
	extra curricular and extra co-curricular activities, laboratory
	development, maintenance of equipment, R &amp; D work and any
	administrative work assigned to you by the Head of
	Department/Director  from time to time.</FONT></FONT></P>
</OL>
<OL START=7>
	<LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt">As
	your  appointment is  purely on temporary and  contractual basis as
	per the advertisement, you are not entitled for any claims/benefits
	other than consolidated pay. </FONT></FONT>
	</P>
</OL>
<OL START=8>
	<LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt">Management
	reserves the right to terminate your services without any reasons at
	any time.                    </FONT></FONT>
	</P>
</OL>
<OL START=9>
	<LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt">If
	you desire to leave the service of this College, you are required to
	give one month’s notice or one</FONT> <FONT SIZE=2 STYLE="font-size: 11pt">months
	salary in lieu of notice.</FONT>  <FONT SIZE=2 STYLE="font-size: 11pt">
	                                              </FONT></FONT>
	</P>
</OL>
 <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in">  </p><br>
 <br>
 <br>
 <br>
 <br> <br>
 <br>
 <br>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0in">             <FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt"><B>You
are requested to intimate the acceptance of the above offer of
appointment along with all its terms and conditions as mentioned
above immediately &amp; join your duties at this college. </B></FONT><FONT SIZE=2 STYLE="font-size: 11pt">Further,
you  will have to submit an agreement bond on stamp paper of Rs.100/-
in prescribed format which is available in the office  while joining
the duties.  </FONT><FONT SIZE=2 STYLE="font-size: 11pt"><B>Further,
you have to submit the xerox copy of PAN card &amp; Bank account
number with Bank of India, Vishrambag Br. after joining the duties. </B></FONT></FONT>
</P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0in">  </p>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0in">  </p>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0in">  </p><br><br>
<br>
<p class="western" align="RIGHT" style="margin-bottom: 0in; direction: ltr; line-height: 26.6667px; font-family: &quot;Times New Roman&quot;, serif; font-size: 10pt;"><a name="_GoBack"></a><font size="4"><b>Yours faithfully,<br>DIRECTOR</b></font></p>
<P CLASS="western" STYLE="margin-bottom: 0in"><FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt">Copy
to :</FONT></FONT></P>
<P CLASS="western" STYLE="margin-left: 0.25in; margin-bottom: 0in"><FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt">1)
    Head of  <!--?php _p(delete_all_between('[',']',$app->Data2));?--> Deptt.</FONT></FONT></P>
<P CLASS="western" STYLE="margin-left: 0.25in; margin-bottom: 0in"><FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt">2)
Accounts Section (Allocation: PG-<!--?php _p($app->Data1);?-->)</FONT></FONT></P>
<P CLASS="western" STYLE="margin-left: 0.25in; margin-bottom: 0in"><FONT FACE="Arial, serif"><FONT SIZE=2 STYLE="font-size: 11pt">3)
Establishment Section (contract basis)</FONT></FONT></P>
</div>
<!--?php } ?-->    

