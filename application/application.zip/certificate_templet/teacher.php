<!--?php if(isset($_GET['id'])){ 
            $app = Application::LoadByIdapplication($_GET['id']);
            if($app){ ?-->
<div class="form-controls" style="width: 90%; margin-left:40px;margin-right: 40px;margin-bottom: 90px;">
<table width="100%" cellpadding="6" cellspacing="0" bgcolor="#ffffff">
    <colgroup><col width="100" /><col width="500" /></colgroup>
    <tbody>
        <tr valign="TOP">
            <td width="100%" bgcolor="#ffffff" style="border-width: initial; border-style: none; border-color: initial; padding: 0in;">
            <div align="Center" width="100%">
            <div style="float:left; margin-left:3%; width: 10%; margin-top: 20px;" align="right"><img src="../../assets/_core/images/Walchand_11.gif" width="100" height="85" alt="" /></div>
            <div style=" width: 80%; float:right; font-size: 25px; margin-top: 20px; text-align: center;">
            <div style="font-size: 20px; text-align: center;"><font color="#cc0000"><font face="Verdana, serif"><b>Walchand College of Engineering, Sangli</b></font></font></font></div>
            <div style="font-size: 13px;"><font color="#cc0000"><font face="Verdana, serif"><b>(An Autonomous Institute)</b></font></font></div>
            <div style="font-size: 15px;"><font size="4"><font color="#cc0000">Vishrambag, SANGLI-416415 (M.S.), India</font></font></div>
            <div style="font-size: 14px;"><font face="Verdana, serif"><font color="#cc0000">Website : www.walchandsangli.ac.in</font></font></div>
            <div style="font-size: 14px;"><font color="#cc0000">Email :&nbsp;<a href="mailto:director.wcesangli@gmail.com" style="color: rgb(0, 0, 255);">director.wcesangli@gmail.com</a>,&nbsp;<a href="mailto:director@walchandsangli.ac.in" style="color: rgb(0, 0, 255);">director@walchandsangli.ac.in</a>,&nbsp;<a href="mailto:walchand@rediffmail.com" style="color: rgb(0, 0, 255);">walchand@rediffmail.com</a></font></div>
            </div>
            <div style="clear: both; margin-top: 30px; ">&nbsp;</div>
            </div>
            </td>
        </tr>
    </tbody>
    <tbody>
        <tr>
            <td colspan="2" width="754" valign="TOP" bgcolor="#ffffff" style="border-top: 1.5pt solid rgb(204, 0, 0); border-bottom: 1.5pt solid rgb(204, 0, 0); border-left: none; border-right: none; padding: 0in;">
            <p align="CENTER" style="margin-bottom: 0.08in; direction: ltr;"><font color="#cc0000">☎</font><font color="#cc0000">&nbsp;Director +91-233-2303433&nbsp;</font><font color="#cc0000"><font face="Wingdings, serif"><font style="font-size: 16pt;">☎</font></font></font><font color="#cc0000">&nbsp;Office +91-233-2300383 Fax : +91-233-2300831</font></p>
            </td>
        </tr>
    </tbody>
</table>
<div style="margin-top: 5px;">
<div style=" float: left; margin-bottom: 0in"><font face="Krishna, serif"><font size="4" style="font-size: 16pt"><font face="Arial, serif"><font size="2" style="font-size: 11pt">Ref No.     WCE/Estt/Apptt.Ord./Adhoc-PG/<!--?php _p(date('Y',  strtotime(QDateTime::Now)));?-->/                                          </font></font></font></font></div>
<div  style="float: right; margin-bottom: 0in; direction: ltr; font-family: &quot;Times New Roman&quot;; font-size: medium; line-height: 16px;"><font face="Times New Roman, serif"><font size="4"><b>Date: - <!--?php _p(date('d-m-Y',  strtotime(QDateTime::Now())));?--></b></font></font></div>
<div style="clear: both"></div>
</div>
<p class="western" align="JUSTIFY" style="margin-bottom: 0in; direction: ltr; line-height: 13.3333px; font-family: &quot;Times New Roman&quot;, serif; font-size: 10pt;">&nbsp;</p>
<p class="western" style="margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">To</font></font></p>
<p class="western" style="margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt"><!--?php _p(delete_all_between('[',']',$app->ApplicantObject->OfObject->Name))?--></font></font></p>
<p width="10%" class="western" align="LFET" style="margin-bottom: 0in; direction: ltr; line-height: 15.3333px; font-family: &quot;Times New Roman&quot;, serif; font-size: 10pt;"><font size="4"><!--?php _p($app->Data8);?--></font></p>
<p class="western" style="margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">Ref: Advertisement  for </font></font><font face="Arial, serif"><font size="2" style="font-size: 11pt"><b>Teacher appointments</b></font></font><font face="Arial, serif"><font size="2" style="font-size: 11pt"> published in daily  <!--?php _p($app->Data7);?-->   </font></font></p>
<p class="western" style="margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">Dear sir/madam,</font></font></p>
<h2 class="western" align="JUSTIFY"><font size="2" style="font-size: 11pt">	</font><font size="2" style="font-size: 11pt"><span style="font-style: normal"><span style="font-weight: normal">With reference to your interview before the Selection Committee meeting held on            <!--?php _p($app->Data9);?--> the undersigned is pleased to inform  that you have been offered the post of  Assistant Professor in </span></span></font><font size="2" style="font-size: 11pt"><span style="font-style: normal"><!--?php _p(delete_all_between('[',']',$app->Data2));?--></span></font><font size="2" style="font-size: 11pt"><span style="font-style: normal"><span style="font-weight: normal"> on following terms &amp; conditions</span></span></font><font size="2" style="font-size: 11pt"><span style="font-style: normal">. </span></font></h2>
<p align="JUSTIFY" style="margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">1.Your appointment in the post of Assistant Professor in  </font><font size="2" style="font-size: 11pt"><b><!--?php _p(delete_all_between('[',']',$app->Data2));?--></b></font><font size="2" style="font-size: 11pt"><i><b> </b></i></font><font size="2" style="font-size: 11pt">                               </font><font size="2" style="font-size: 11pt"><b>       </b></font><font size="2" style="font-size: 11pt">is on full time </font><font size="2" style="font-size: 11pt"><b>Adhoc basis</b></font><font size="2" style="font-size: 11pt"> initially for a maximum period of up to <!--?php _p($app->Data3);?--> Years from the date of your joining. Same can be extended further for a maximum period up to 3 years  discretionary of management </font></font></p>
<p align="JUSTIFY" style="margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">2.</font><font size="2" style="font-size: 11pt">Your  pay on appointment will be Rs.<!--?php _p($app->Data4);?-->/- in PB-3 with Pay Band of Rs. <!--?php _p($app->Data5);?-->/- and Academic Grade Pay of Rs.<!--?php _p($app->Data6);?-->/- + D.A. + H.R.A.+ other allowances at the rates sanctioned and approved by the Administrative Council of the college</font>. </font></p>
<p align="JUSTIFY" style="margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">3. You will be subjected to such service rules and regulations as are prescribed  for contract/Adhoc appointments from time to time by the college authorities.</font></font></p>
<p align="JUSTIFY" style="margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">4. The appointment is full time one and you are required to be present in the college during entire working hours of the college.</font></font></p>
<p align="JUSTIFY" style="margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">5. It is  obligatory for you to do such work in the College or outside, that pertains to and has bearing upon the smooth running or improvement of the College.</font></font></p>
<p align="JUSTIFY" style="margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">6. You will be required to carry out all work related to academic programs, extra curricular and extra co-curricular activities, laboratory development, maintenance of equipment, R &amp; D work and any administrative work assigned to you by the Head of Department/Director  from time to time.</font></font></p>
<p align="JUSTIFY" style="margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">7. As your appointment is on full time Adhoc basis, you are not entitled for any claims/benefits other than pay. </font></font></p>
<p align="JUSTIFY" style="margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">8. If your performance during the period is not found satisfactory your services will be terminated from the college side with 8 ( eight ) days notice in advance.      </font></font></p>
<p align="JUSTIFY" style="margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">9. If you desire to leave the service of this College, you are required to give one months </font></font></p>
<p align="JUSTIFY" style="margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">notice or one</font> <font size="2" style="font-size: 11pt">months salary in lieu of notice.</font>  <font size="2" style="font-size: 11pt">     </font></font></p>

<p align="JUSTIFY" style="margin-bottom: 0in;"><font face="Arial, serif"><font size="2" style="font-size: 11pt"><b>You are requested to intimate the acceptance of the above offer of appointment along with all its terms and conditions as mentioned above immediately &amp; join your duties at this college between <!--?php _p($app->Data10);?--></b></font><font size="2" style="font-size: 11pt"><b>  , failing which this offer of appointment will automatically stands cancelled. </b></font><font size="2" style="font-size: 11pt"> </font><font size="2" style="font-size: 11pt"><b>Further, you have to submit the xerox copy of PAN card &amp; Bank account number with Bank of India, Vishrambag Br. after joining the duties. </b></font></font></p>
<br />
<p class="western" align="RIGHT" style="margin-bottom: 0in; direction: ltr; line-height: 26.6667px; font-family: &quot;Times New Roman&quot;, serif; font-size: 10pt;"><a name="_GoBack"></a><font size="4"><b>Yours faithfully,<br><br>
DIRECTOR</b></font></p>
<p class="western" style="margin-left: 0.44in; text-indent: -0.44in; margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">Copy to: 								    </font></font></p>
<p class="western" style="margin-left: 0.44in; text-indent: -0.44in; margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">1) Head of <!--?php _p(delete_all_between('[',']',$app->Data2));?--> Deptt.</font></font></p>
<p class="western" style="margin-left: 0.44in; text-indent: -0.44in; margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">2) Accounts Section (Salary)</font></font></p>
<p class="western" style="margin-left: 0.44in; text-indent: -0.44in; margin-bottom: 0in"><font face="Arial, serif"><font size="2" style="font-size: 11pt">3) Establishment</font></font></p>
</div>
<!--?php } }?-->