<?php
require('../../qcubed.inc.php');
    class IssueDocumentForm extends QForm {
        protected $txtSearch;
        protected $txtReason;
        protected $caldate;
        protected $txtcompaddrs;
        protected $lstcompname;
        protected $lstdoc;
        protected $txtinstidues;
        protected $txtconduct;
        protected $txtremark;
        protected $btnSearch;
        protected $txtexamno;
        protected $txtcpi;
        protected $btnSave;
        protected $btnCancel;
        protected $lblView;
        protected $calPassDate;
        protected $refcaldate;


        protected function Form_Run() {
                parent::Form_Run();
           QApplication::CheckRemoteAdmin();
        }
        protected function Form_Create() {
            parent::Form_Create();
            
            $this->lblView = new QLabel($this);
            $this->lblView->HtmlEntities = FALSE;
            
            $this->txtSearch = new QAjaxAutoCompleteTextBox($this, 'txtSearch_Change');
            $this->txtSearch->Name = 'Student ID';
            $this->txtSearch->Width = 450;
            
            $this->txtReason = new QTextBox($this);
            $this->txtReason->Name = 'Reason';
            $this->txtReason->Width ="100%";
            
            $this->caldate = new QDateTimePicker($this);
            $this->caldate->Width = 70;
            $this->caldate->Name = "Date"; 
            $this->caldate->DateTime = QDateTime::Now();
            
            $this->refcaldate = new QDateTimePicker($this);
            $this->refcaldate->Width = 70;
            $this->refcaldate->Name = 'Reference Date';
            
            $this->lstdoc = new QSelect2ListBox($this);
            $this->lstdoc->Name = 'Document';
            $this->lstdoc->AddItem('--Select Document--');
             $certificate = CertificateTemplet::QueryArray(
                     QQ::AndCondition(
                             QQ::Equal(QQN::CertificateTemplet()->Group,4),
                             QQ::NotEqual(QQN::CertificateTemplet()->IdcertificateTemplet,9),
                             QQ::NotEqual(QQN::CertificateTemplet()->IdcertificateTemplet,10),
                             QQ::NotEqual(QQN::CertificateTemplet()->IdcertificateTemplet,23),
                             QQ::NotEqual(QQN::CertificateTemplet()->IdcertificateTemplet,24),
                             QQ::NotEqual(QQN::CertificateTemplet()->IdcertificateTemplet,25),
                             QQ::NotEqual(QQN::CertificateTemplet()->IdcertificateTemplet,26),
                             QQ::NotEqual(QQN::CertificateTemplet()->IdcertificateTemplet,27)
                     ));
             foreach ($certificate as $cer){
                     $this->lstdoc->AddItem($cer->Name,$cer->IdcertificateTemplet);
             }
            
            $this->btnSearch = new QButton($this);
            $this->btnSearch->ButtonMode = QButtonMode::Success;
            $this->btnSearch->Text = "<i class='fa fa-search '></i>";
            $this->btnSearch->AddAction(new QClickEvent(), new QAjaxAction('btnSearch_click'));
            
            $this->btnSave = new QButton($this);
            $this->btnSave->ButtonMode = QButtonMode::Success;
            $this->btnSave->Text ="Apply";
            $this->btnSave->AddAction(new QClickEvent(), new QServerAction('btnSave_click'));
            
            $this->btnCancel = new QButton($this);
            $this->btnCancel->ButtonMode = QButtonMode::Cancel;
            $this->btnCancel->AddAction(new QClickEvent(), new QServerAction('btnCancel_click'));
            
            if(isset($_GET['mem'])&&$_GET['doc']){
                $this->lstdoc->Enabled = FALSE;
                 $this->btnSearch->Visible = False;
                $app = CertificateTemplet::LoadByIdcertificateTemplet($_GET['doc']);
                $appaddr = Application::LoadByIdapplication($_GET['mem']);
                $led = Ledger::LoadByIdledger($_GET['mem']);
                $this->txtSearch->Text = $led->Name;
                $this->lstdoc->SelectedName = $app->Name;
                  if($app->IdcertificateTemplet==21){
                        $this->txtcompaddrs = new QTextBox($this);
                        $this->txtcompaddrs->Name = 'Company Adderess';
                        $this->txtcompaddrs->TextMode = QTextMode::MultiLine;
                        $this->txtcompaddrs->Width ="100%";

                        $this->lstcompname = new QSelect2ListBox($this);
                        $this->lstcompname->Name = 'Company Name';
                        $comp = CompanyMaster::LoadAll();
                        $this->lstcompname->AddItem('--Select Company--');
                        foreach ($comp as $company){
                            $this->lstcompname->AddItem($company->Name,$company->IdcompanyMaster);
                        }
                        $this->lstcompname->AddAction(new QChangeEvent(),new QAjaxAction('comp_select'));
                     
                        $this->txtexamno = new QTextBox($this);
                        $this->txtexamno->Name = 'Exam No';
                        $this->txtexamno->TextMode = QTextMode::MultiLine;
                        $this->txtexamno->Width ="100%";
                        
                        $this->txtcpi = new QTextBox($this);
                        $this->txtcpi->Name = 'CPI';
                        $this->txtcpi->TextMode = QTextMode::MultiLine;
                        $this->txtcpi->Width ="100%";
                     }
                   if($app->IdcertificateTemplet == 22)  {
                       
                         $this->txtinstidues = new QTextBox($this);
                         $this->txtinstidues->Name = 'Institute fees,Other Charges & Dues';
                         $this->txtinstidues->TextMode = QTextMode::MultiLine;
                         $this->txtinstidues->Width ="100%";
                         
                        $this->txtconduct = new QTextBox($this);
                        $this->txtconduct->Name = 'Conduct';
                        $this->txtconduct->TextMode = QTextMode::MultiLine;
                        $this->txtconduct->Width ="100%";
                        
                        $this->txtremark = new QTextBox($this);
                        $this->txtremark->Name = 'Remark';
                        $this->txtremark->TextMode = QTextMode::MultiLine;
                        $this->txtremark->Width ="100%";
                        
                        $this->calPassDate = new QCalendar($this);
                        $this->calPassDate->Width = 70;
                        $this->calPassDate->Name = "Passing Date"; 
                   }
        }
      }
        public function txtSearch_Change($strParameter){
            $objMemberArray = Ledger::QueryArray(
                QQ::AndCondition(
                    QQ::Equal(QQN::Ledger()->Grp, 244),
                    QQ::OrCondition(
                        QQ::Like(QQN::Ledger()->Name, '%'.$strParameter . '%'),
                        QQ::Like(QQN::Ledger()->Code, '%'.$strParameter . '%')
                    )
                )
            );

            $result = array();
            foreach($objMemberArray as $objMember){
                $result[] = $objMember->Code.' '.  GetFullNameNew($objMember->Name,$objMember->Code);
            }
            return $result;
        }
        
        protected function btnSearch_click($strFormId, $strControlId, $strParameter) {
            if($this->txtSearch->Text != NULL && $this->lstdoc->SelectedValue!=NULL){
                $text= $this->txtSearch->Text;
                $code = explode(" ", $text);
                $mem = Ledger::LoadByCode($code[0]);
                if($mem){
                    $currents = CurrentStatus::LoadArrayByStudent($mem->Idledger);
                    if($currents)
                        QApplication::Redirect(__VIRTUAL_DIRECTORY__ . __FORM_APPLICATION__ . '/certificate_templet/apply_document.php?mem='.$mem->Idledger.'&doc='.$this->lstdoc->SelectedValue); 
                    else
                        QApplication::DisplayAlert ("Student Haven't been admitted yet !!");
                }else{
                    QApplication::DisplayAlert ("Student not found !!");
                }
            }
            else{
                QApplication::DisplayAlert('Please select student and document type.');
            }
        }
        protected function btnSave_click($strFormId, $strControlId, $strParameter) {
            if(isset($_GET['mem'])){
                if($_GET['doc'] ==22){
                    $addresses = Address::LoadArrayByOf($_GET['mem']);
                    if($addresses){
                        foreach ($addresses as $address){}
                    }else{
                        $address = new Address();
                        $address->Title ="-";
                        $address->Save();
                    }    
                    $currentstatuses = CurrentStatus::LoadArrayByStudent($_GET['mem']);
                    foreach ($currentstatuses as $currentstatus){}
                    $app = new Application();
                    $app->Applicant = $address->Idaddress;
                        $app->AppliedFor = $this->lstdoc->SelectedValue; //Bonafide
                        $counter = CertificateTemplet::LoadByIdcertificateTemplet($this->lstdoc->SelectedValue); 
                        $app->Code = $counter->Abbrivation."".$counter->Counter;
                        $counter->Counter = $counter->Counter + 1;
                        $counter->Save();
                        
                    $profile = Profile::LoadByIdprofile($_GET['mem']);
                    //$profile->LeaveDate = $this->calPassDate->Text;
                    $profile->Save();
                    
                    $app->Date = QDateTime::Now();                                                             
                    $app->FinalDecision = 3;
                    $app->DataEntryBy = $_SESSION['login'];
                    $app->Reason = $this->txtReason->Text;
                    $app2 = CertificateTemplet::LoadByIdcertificateTemplet($_GET['doc']);
                    
                        if($app2->IdcertificateTemplet == 22){
                             $app->Data2 = 'Nill';
                            $app->Data3 = 'Good';
                            if( $this->txtremark->Text!= NULL){
                                $app->Data4 = $this->txtremark->Text;
                            }else{
                                QApplication::DisplayAlert('Please fill remark');
                            } 
                        }

                    $app->Save(); 
                    
                    $counter = CertificateTemplet::LoadByIdcertificateTemplet($_GET['doc']); 
                    $approvals = Approvel::LoadArrayByCertificateTemplet($counter->IdcertificateTemplet);
                    foreach ($approvals as $approval){
                            $appaproval = new AppApproval();
                            $appaproval->Application = $app->Idapplication;
                            $appaproval->Roll = $approval->Roll;
                            $appaproval->Code = $approval->Code;
                            $appaproval->IsFinalAuthority = $approval->IsFinalAuthority;
                            $appaproval->Decision = 3;
                            $appaproval->Save();
                    }
                    
                    
                     QApplication::Redirect(__VIRTUAL_DIRECTORY__ . __FORM_APPLICATION__ . '/certificate_templet/doc_view_1.php?id='.$app->Idapplication.'&appfor='.$app->AppliedFor);  

                
                }else{
                    $addresses = Address::LoadArrayByOf($_GET['mem']);
                    if($addresses){
                        foreach ($addresses as $address){}
                    }else{
                        $address = new Address();
                        $address->Title ="-";
                        $address->Save();
                    }    
                    $currentstatuses = CurrentStatus::LoadArrayByStudent($_GET['mem']);
                    foreach ($currentstatuses as $currentstatus){}
                    $app = new Application();
                    $app->Applicant = $address->Idaddress;

                        $app->AppliedFor = $this->lstdoc->SelectedValue; //Bonafide
                        $counter = CertificateTemplet::LoadByIdcertificateTemplet($this->lstdoc->SelectedValue); 
                        $app->Code = $counter->Abbrivation."".$counter->Counter;
                        $counter->Counter = $counter->Counter + 1;
                        $counter->Save();


                    $app->Date = QDateTime::Now();                                                             
                    $app->FinalDecision = 3;
                    $app->DataEntryBy = $_SESSION['login'];
                    $app->Reason = $this->txtReason->Text;
                    $app2 = CertificateTemplet::LoadByIdcertificateTemplet($_GET['doc']);
                    if($app2->IdcertificateTemplet == 21){
                       if(  $this->lstcompname->SelectedValue !=NULL && $this->txtcompaddrs->Text!=NULL){
                      $app->Data1 = $this->txtcompaddrs->Text;
                      $app->Company = $this->lstcompname->SelectedValue;
                      $app->Data6 = $this->txtexamno->Text;
                      $app->Data7 = $this->txtcpi->Text;
                      $app->CertificateGeneratedDate = $this->refcaldate->DateTime;
                     }else{
                         QApplication::DisplayAlert('Please fill company name and address');
                     }
                    }
                    $app->Save(); 
                    $approvals = Approvel::LoadArrayByCertificateTemplet($counter->IdcertificateTemplet);
                    foreach ($approvals as $approval){
                                $appaproval = new AppApproval();
                                $appaproval->Application = $app->Idapplication;
                                $appaproval->Roll = $approval->Roll;
                                $appaproval->Code = $approval->Code;
                                $appaproval->IsFinalAuthority = $approval->IsFinalAuthority;
                                $appaproval->Decision = 3;
                                $appaproval->Save();
                        }
                       QApplication::Redirect(__VIRTUAL_DIRECTORY__ . __FORM_APPLICATION__ . '/certificate_templet/doc_view.php?id='.$app->Idapplication.'&appfor='.$app->AppliedFor);  

                }
                
                }
            }
              protected function btnCancel_click($strFormId, $strControlId, $strParameter) {
                  QApplication::Redirect(__VIRTUAL_DIRECTORY__ . __FORM_APPLICATION__ . '/dashboard.php');
              }
              protected function comp_select(){
                  $comp = CompanyMaster::LoadByIdcompanyMaster($this->lstcompname->SelectedValue);
                  $this->txtcompaddrs->Text = $comp->Address;
                  $this->txtcompaddrs->Enabled = False;
              }
    }
    IssueDocumentForm::Run('IssueDocumentForm');
?>

