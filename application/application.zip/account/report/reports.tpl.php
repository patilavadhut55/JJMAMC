<?php
require(__CONFIGURATION__ . '/header.inc.php');
?>
<?php $this->RenderBegin() ?>

<div id="formControls">

</div>

<?php $this->RenderEnd() ?>

