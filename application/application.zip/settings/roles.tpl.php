<?php
	
	$strPageTitle = QApplication::Translate('Roles');
	require(__CONFIGURATION__ . '/header.inc.php');
?>
	<?php $this->RenderBegin() ?>
	<div class="form-controls">
	
        </div>

	<?php $this->RenderEnd() ?>

<?php require(__CONFIGURATION__ .'/footer.inc.php'); ?>