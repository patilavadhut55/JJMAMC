<?php
require('../../qcubed.inc.php');
//$roles = Role::LoadArrayByGrp(3);
//foreach ($roles as $role){
//    $menu = RoleHasMenu::LoadByRoleIdroleMenuIdmenu($role->Idrole, 53);
//    if(!$menu){
//        $menu = new RoleHasMenu();
//        $menu->RoleIdrole = $role->Idrole;
//        $menu->MenuIdmenu = 53;
//        $menu->Seq =1;
//        $menu->Permission = "CRUDE";
//        $menu->Level = 1;
//        $menu->Save();
//    }        
//}
?>

