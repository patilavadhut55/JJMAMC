
<?php
require('../../qcubed.inc.php');
    /*$from = date('Ymd',  strtotime('20160707'));
    $to = date('Ymd', strtotime('20160707')); 
    
    $vouss = Voucher::QueryArray(
                    QQ::AndCondition(
                    QQ::GreaterOrEqual(QQN::Voucher()->Date, $from."000000"),
                    QQ::LessThan(QQN::Voucher()->Date, $to."235959")
                ));
    if($vouss){            
        foreach($vouss as $vov){
            $vov->ApprovedBy = NULL;
            $vov->ApprovedDate = NULL;
            $vov->Save();
        }
    }
    _p('Uncheck All');*/
?>