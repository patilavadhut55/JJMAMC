<?php
require('../../../qcubed.inc.php');

        class PO extends QForm {
            protected $txtSub;
            protected $chkApprove;
            
            protected function Form_Run() {
			parent::Form_Run();
                   QApplication::CheckRemoteAdmin();
		}
            protected function Form_Create() {
            parent::Form_Create();
            
            $this->txtSub = new QTextBox($this);
            $this->txtSub->Width = 240;
            $this->txtSub->AddAction(new QClickEvent(), new QAjaxAction('txtSub_click'));
       
       
            $this->chkApprove = new QCheckBox($this);
            $this->chkApprove->AddAction(new QClickEvent(), new QAjaxAction('chkApprove_click'));
            $vov = Voucher::LoadByIdvoucher($_GET['id']);  
            if($vov->ApprovedBy != NULL)
                $this->chkApprove->Checked = TRUE;
            }
            
                 
     protected function txtSub_Click(){
        if(isset($_GET['id'])){
            $vovs = Voucher::LoadByIdvoucher($_GET['id']);
            
                 $vovs->CmpSubject = $this->txtSub->Text;
                
        } $vovs->Save();
        
            
        }
            protected function chkApprove_click(){
            $vov = Voucher::LoadByIdvoucher($_GET['id']);  
            //$vov->Approved = $this->chkApprove->Checked;
            $vov->Save();
            $status = NULL;
            if($this->chkApprove->Checked == 1)$status = "Approved";
            else $status = "Rejected";
            QApplication::DisplayAlert("Purchase Order for ".$vov->Narration.' To supplier'.$vov->ToObject.' has '.$status);
            }
            
        }
    PO::Run('PO');    
?>        
