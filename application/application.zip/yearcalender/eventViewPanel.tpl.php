<div class="col-md-1"><?php $_CONTROL->lblEdit->Render(); ?></div>
<div class="col-md-3"><?php $_CONTROL->lstGrp->Render(); ?></div>
<div class="col-md-4"><?php $_CONTROL->btnSearch->Render(); ?></div>
 <div class="clearfix"></div>
 <div class="form-controls" style="margin-top: 10px;">
<?php $_CONTROL->dtgEvent->Render(); ?>
 </div>

