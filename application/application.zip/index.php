<?php
require('../qcubed.inc.php');
QApplication::Redirect("login_edit.php")
?>