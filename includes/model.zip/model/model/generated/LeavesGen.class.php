<?php
	/**
	 * The abstract LeavesGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Leaves subclass which
	 * extends this LeavesGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Leaves class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idleaves the value for intIdleaves (Read-Only PK)
	 * @property integer $RefEstablishment the value for intRefEstablishment (Not Null)
	 * @property string $LeavesCarriedInDays the value for strLeavesCarriedInDays 
	 * @property string $LeavesAtCredit the value for strLeavesAtCredit 
	 * @property QDateTime $CreditLeaveTakenFrom the value for dttCreditLeaveTakenFrom 
	 * @property QDateTime $CreditLeaveTakenTo the value for dttCreditLeaveTakenTo 
	 * @property QDateTime $TakenLeaveForm the value for dttTakenLeaveForm 
	 * @property QDateTime $TakenLeaveTo the value for dttTakenLeaveTo 
	 * @property string $TakenNoOfDays the value for strTakenNoOfDays 
	 * @property string $LeaveBalance the value for strLeaveBalance 
	 * @property QDateTime $ServiceLengthFrom the value for dttServiceLengthFrom 
	 * @property QDateTime $ServiceLengthTo the value for dttServiceLengthTo 
	 * @property string $YearsOfService the value for strYearsOfService 
	 * @property string $LeaveEarned the value for strLeaveEarned 
	 * @property string $LeaveAtCredit the value for strLeaveAtCredit 
	 * @property QDateTime $MedicalCertLeaveFrom the value for dttMedicalCertLeaveFrom 
	 * @property QDateTime $MedicalCertLeaveTo the value for dttMedicalCertLeaveTo 
	 * @property string $TotalMedicalLeaves the value for strTotalMedicalLeaves 
	 * @property QDateTime $FullPayLeavesFrom the value for dttFullPayLeavesFrom 
	 * @property QDateTime $FullPayLeavesTo the value for dttFullPayLeavesTo 
	 * @property string $TotalFullPayLeaves the value for strTotalFullPayLeaves 
	 * @property string $CommutedHalfPayLeaves the value for strCommutedHalfPayLeaves 
	 * @property QDateTime $NonMedicalLeaveFrom the value for dttNonMedicalLeaveFrom 
	 * @property QDateTime $NonMedicalLeaveTo the value for dttNonMedicalLeaveTo 
	 * @property string $TotalNonMedicalLeave the value for strTotalNonMedicalLeave 
	 * @property string $TotalHalfPayLeaveTaken the value for strTotalHalfPayLeaveTaken 
	 * @property string $BalanceReturnLeave the value for strBalanceReturnLeave 
	 * @property string $Remarks the value for strRemarks 
	 * @property Establishment $RefEstablishmentObject the value for the Establishment object referenced by intRefEstablishment (Not Null)
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class LeavesGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column leaves.idleaves
		 * @var integer intIdleaves
		 */
		protected $intIdleaves;
		const IdleavesDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.ref_establishment
		 * @var integer intRefEstablishment
		 */
		protected $intRefEstablishment;
		const RefEstablishmentDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.leaves_carried_in_days
		 * @var string strLeavesCarriedInDays
		 */
		protected $strLeavesCarriedInDays;
		const LeavesCarriedInDaysDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.leaves_at_credit
		 * @var string strLeavesAtCredit
		 */
		protected $strLeavesAtCredit;
		const LeavesAtCreditDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.credit_leave_taken_from
		 * @var QDateTime dttCreditLeaveTakenFrom
		 */
		protected $dttCreditLeaveTakenFrom;
		const CreditLeaveTakenFromDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.credit_leave_taken_to
		 * @var QDateTime dttCreditLeaveTakenTo
		 */
		protected $dttCreditLeaveTakenTo;
		const CreditLeaveTakenToDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.taken_leave_form
		 * @var QDateTime dttTakenLeaveForm
		 */
		protected $dttTakenLeaveForm;
		const TakenLeaveFormDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.taken_leave_to
		 * @var QDateTime dttTakenLeaveTo
		 */
		protected $dttTakenLeaveTo;
		const TakenLeaveToDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.taken_no_of_days
		 * @var string strTakenNoOfDays
		 */
		protected $strTakenNoOfDays;
		const TakenNoOfDaysDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.leave_balance
		 * @var string strLeaveBalance
		 */
		protected $strLeaveBalance;
		const LeaveBalanceDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.service_length_from
		 * @var QDateTime dttServiceLengthFrom
		 */
		protected $dttServiceLengthFrom;
		const ServiceLengthFromDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.service_length_to
		 * @var QDateTime dttServiceLengthTo
		 */
		protected $dttServiceLengthTo;
		const ServiceLengthToDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.years_of_service
		 * @var string strYearsOfService
		 */
		protected $strYearsOfService;
		const YearsOfServiceDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.leave_earned
		 * @var string strLeaveEarned
		 */
		protected $strLeaveEarned;
		const LeaveEarnedDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.leave_at_credit
		 * @var string strLeaveAtCredit
		 */
		protected $strLeaveAtCredit;
		const LeaveAtCreditDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.medical_cert_leave_from
		 * @var QDateTime dttMedicalCertLeaveFrom
		 */
		protected $dttMedicalCertLeaveFrom;
		const MedicalCertLeaveFromDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.medical_cert_leave_to
		 * @var QDateTime dttMedicalCertLeaveTo
		 */
		protected $dttMedicalCertLeaveTo;
		const MedicalCertLeaveToDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.total_medical_leaves
		 * @var string strTotalMedicalLeaves
		 */
		protected $strTotalMedicalLeaves;
		const TotalMedicalLeavesDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.full_pay_leaves_from
		 * @var QDateTime dttFullPayLeavesFrom
		 */
		protected $dttFullPayLeavesFrom;
		const FullPayLeavesFromDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.full_pay_leaves_to
		 * @var QDateTime dttFullPayLeavesTo
		 */
		protected $dttFullPayLeavesTo;
		const FullPayLeavesToDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.total_full_pay_leaves
		 * @var string strTotalFullPayLeaves
		 */
		protected $strTotalFullPayLeaves;
		const TotalFullPayLeavesDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.commuted_half_pay_leaves
		 * @var string strCommutedHalfPayLeaves
		 */
		protected $strCommutedHalfPayLeaves;
		const CommutedHalfPayLeavesDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.non_medical_leave_from
		 * @var QDateTime dttNonMedicalLeaveFrom
		 */
		protected $dttNonMedicalLeaveFrom;
		const NonMedicalLeaveFromDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.non_medical_leave_to
		 * @var QDateTime dttNonMedicalLeaveTo
		 */
		protected $dttNonMedicalLeaveTo;
		const NonMedicalLeaveToDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.total_non_medical_leave
		 * @var string strTotalNonMedicalLeave
		 */
		protected $strTotalNonMedicalLeave;
		const TotalNonMedicalLeaveDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.total_half_pay_leave_taken
		 * @var string strTotalHalfPayLeaveTaken
		 */
		protected $strTotalHalfPayLeaveTaken;
		const TotalHalfPayLeaveTakenDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.balance_return_leave
		 * @var string strBalanceReturnLeave
		 */
		protected $strBalanceReturnLeave;
		const BalanceReturnLeaveDefault = null;


		/**
		 * Protected member variable that maps to the database column leaves.remarks
		 * @var string strRemarks
		 */
		protected $strRemarks;
		const RemarksDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column leaves.ref_establishment.
		 *
		 * NOTE: Always use the RefEstablishmentObject property getter to correctly retrieve this Establishment object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Establishment objRefEstablishmentObject
		 */
		protected $objRefEstablishmentObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdleaves = Leaves::IdleavesDefault;
			$this->intRefEstablishment = Leaves::RefEstablishmentDefault;
			$this->strLeavesCarriedInDays = Leaves::LeavesCarriedInDaysDefault;
			$this->strLeavesAtCredit = Leaves::LeavesAtCreditDefault;
			$this->dttCreditLeaveTakenFrom = (Leaves::CreditLeaveTakenFromDefault === null)?null:new QDateTime(Leaves::CreditLeaveTakenFromDefault);
			$this->dttCreditLeaveTakenTo = (Leaves::CreditLeaveTakenToDefault === null)?null:new QDateTime(Leaves::CreditLeaveTakenToDefault);
			$this->dttTakenLeaveForm = (Leaves::TakenLeaveFormDefault === null)?null:new QDateTime(Leaves::TakenLeaveFormDefault);
			$this->dttTakenLeaveTo = (Leaves::TakenLeaveToDefault === null)?null:new QDateTime(Leaves::TakenLeaveToDefault);
			$this->strTakenNoOfDays = Leaves::TakenNoOfDaysDefault;
			$this->strLeaveBalance = Leaves::LeaveBalanceDefault;
			$this->dttServiceLengthFrom = (Leaves::ServiceLengthFromDefault === null)?null:new QDateTime(Leaves::ServiceLengthFromDefault);
			$this->dttServiceLengthTo = (Leaves::ServiceLengthToDefault === null)?null:new QDateTime(Leaves::ServiceLengthToDefault);
			$this->strYearsOfService = Leaves::YearsOfServiceDefault;
			$this->strLeaveEarned = Leaves::LeaveEarnedDefault;
			$this->strLeaveAtCredit = Leaves::LeaveAtCreditDefault;
			$this->dttMedicalCertLeaveFrom = (Leaves::MedicalCertLeaveFromDefault === null)?null:new QDateTime(Leaves::MedicalCertLeaveFromDefault);
			$this->dttMedicalCertLeaveTo = (Leaves::MedicalCertLeaveToDefault === null)?null:new QDateTime(Leaves::MedicalCertLeaveToDefault);
			$this->strTotalMedicalLeaves = Leaves::TotalMedicalLeavesDefault;
			$this->dttFullPayLeavesFrom = (Leaves::FullPayLeavesFromDefault === null)?null:new QDateTime(Leaves::FullPayLeavesFromDefault);
			$this->dttFullPayLeavesTo = (Leaves::FullPayLeavesToDefault === null)?null:new QDateTime(Leaves::FullPayLeavesToDefault);
			$this->strTotalFullPayLeaves = Leaves::TotalFullPayLeavesDefault;
			$this->strCommutedHalfPayLeaves = Leaves::CommutedHalfPayLeavesDefault;
			$this->dttNonMedicalLeaveFrom = (Leaves::NonMedicalLeaveFromDefault === null)?null:new QDateTime(Leaves::NonMedicalLeaveFromDefault);
			$this->dttNonMedicalLeaveTo = (Leaves::NonMedicalLeaveToDefault === null)?null:new QDateTime(Leaves::NonMedicalLeaveToDefault);
			$this->strTotalNonMedicalLeave = Leaves::TotalNonMedicalLeaveDefault;
			$this->strTotalHalfPayLeaveTaken = Leaves::TotalHalfPayLeaveTakenDefault;
			$this->strBalanceReturnLeave = Leaves::BalanceReturnLeaveDefault;
			$this->strRemarks = Leaves::RemarksDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Leaves from PK Info
		 * @param integer $intIdleaves
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Leaves
		 */
		public static function Load($intIdleaves, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Leaves', $intIdleaves);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Leaves::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Leaves()->Idleaves, $intIdleaves)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Leaveses
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Leaves[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Leaves::QueryArray to perform the LoadAll query
			try {
				return Leaves::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Leaveses
		 * @return int
		 */
		public static function CountAll() {
			// Call Leaves::QueryCount to perform the CountAll query
			return Leaves::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Leaves::GetDatabase();

			// Create/Build out the QueryBuilder object with Leaves-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'leaves');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Leaves::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('leaves');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Leaves object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Leaves the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Leaves::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Leaves object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Leaves::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Leaves::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Leaves objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Leaves[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Leaves::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Leaves::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Leaves::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Leaves objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Leaves::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Leaves::GetDatabase();

			$strQuery = Leaves::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/leaves', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Leaves::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Leaves
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'leaves';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idleaves', $strAliasPrefix . 'idleaves');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idleaves', $strAliasPrefix . 'idleaves');
			    $objBuilder->AddSelectItem($strTableName, 'ref_establishment', $strAliasPrefix . 'ref_establishment');
			    $objBuilder->AddSelectItem($strTableName, 'leaves_carried_in_days', $strAliasPrefix . 'leaves_carried_in_days');
			    $objBuilder->AddSelectItem($strTableName, 'leaves_at_credit', $strAliasPrefix . 'leaves_at_credit');
			    $objBuilder->AddSelectItem($strTableName, 'credit_leave_taken_from', $strAliasPrefix . 'credit_leave_taken_from');
			    $objBuilder->AddSelectItem($strTableName, 'credit_leave_taken_to', $strAliasPrefix . 'credit_leave_taken_to');
			    $objBuilder->AddSelectItem($strTableName, 'taken_leave_form', $strAliasPrefix . 'taken_leave_form');
			    $objBuilder->AddSelectItem($strTableName, 'taken_leave_to', $strAliasPrefix . 'taken_leave_to');
			    $objBuilder->AddSelectItem($strTableName, 'taken_no_of_days', $strAliasPrefix . 'taken_no_of_days');
			    $objBuilder->AddSelectItem($strTableName, 'leave_balance', $strAliasPrefix . 'leave_balance');
			    $objBuilder->AddSelectItem($strTableName, 'service_length_from', $strAliasPrefix . 'service_length_from');
			    $objBuilder->AddSelectItem($strTableName, 'service_length_to', $strAliasPrefix . 'service_length_to');
			    $objBuilder->AddSelectItem($strTableName, 'years_of_service', $strAliasPrefix . 'years_of_service');
			    $objBuilder->AddSelectItem($strTableName, 'leave_earned', $strAliasPrefix . 'leave_earned');
			    $objBuilder->AddSelectItem($strTableName, 'leave_at_credit', $strAliasPrefix . 'leave_at_credit');
			    $objBuilder->AddSelectItem($strTableName, 'medical_cert_leave_from', $strAliasPrefix . 'medical_cert_leave_from');
			    $objBuilder->AddSelectItem($strTableName, 'medical_cert_leave_to', $strAliasPrefix . 'medical_cert_leave_to');
			    $objBuilder->AddSelectItem($strTableName, 'total_medical_leaves', $strAliasPrefix . 'total_medical_leaves');
			    $objBuilder->AddSelectItem($strTableName, 'full_pay_leaves_from', $strAliasPrefix . 'full_pay_leaves_from');
			    $objBuilder->AddSelectItem($strTableName, 'full_pay_leaves_to', $strAliasPrefix . 'full_pay_leaves_to');
			    $objBuilder->AddSelectItem($strTableName, 'total_full_pay_leaves', $strAliasPrefix . 'total_full_pay_leaves');
			    $objBuilder->AddSelectItem($strTableName, 'commuted_half_pay_leaves', $strAliasPrefix . 'commuted_half_pay_leaves');
			    $objBuilder->AddSelectItem($strTableName, 'non_medical_leave_from', $strAliasPrefix . 'non_medical_leave_from');
			    $objBuilder->AddSelectItem($strTableName, 'non_medical_leave_to', $strAliasPrefix . 'non_medical_leave_to');
			    $objBuilder->AddSelectItem($strTableName, 'total_non_medical_leave', $strAliasPrefix . 'total_non_medical_leave');
			    $objBuilder->AddSelectItem($strTableName, 'total_half_pay_leave_taken', $strAliasPrefix . 'total_half_pay_leave_taken');
			    $objBuilder->AddSelectItem($strTableName, 'balance_return_leave', $strAliasPrefix . 'balance_return_leave');
			    $objBuilder->AddSelectItem($strTableName, 'remarks', $strAliasPrefix . 'remarks');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Leaves from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Leaves::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Leaves
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the Leaves object
			$objToReturn = new Leaves();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idleaves';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdleaves = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'ref_establishment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intRefEstablishment = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'leaves_carried_in_days';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strLeavesCarriedInDays = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'leaves_at_credit';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strLeavesAtCredit = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'credit_leave_taken_from';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttCreditLeaveTakenFrom = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'credit_leave_taken_to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttCreditLeaveTakenTo = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'taken_leave_form';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttTakenLeaveForm = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'taken_leave_to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttTakenLeaveTo = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'taken_no_of_days';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTakenNoOfDays = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'leave_balance';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strLeaveBalance = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'service_length_from';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttServiceLengthFrom = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'service_length_to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttServiceLengthTo = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'years_of_service';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strYearsOfService = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'leave_earned';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strLeaveEarned = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'leave_at_credit';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strLeaveAtCredit = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'medical_cert_leave_from';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttMedicalCertLeaveFrom = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'medical_cert_leave_to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttMedicalCertLeaveTo = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'total_medical_leaves';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTotalMedicalLeaves = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'full_pay_leaves_from';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttFullPayLeavesFrom = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'full_pay_leaves_to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttFullPayLeavesTo = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'total_full_pay_leaves';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTotalFullPayLeaves = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'commuted_half_pay_leaves';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCommutedHalfPayLeaves = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'non_medical_leave_from';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttNonMedicalLeaveFrom = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'non_medical_leave_to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttNonMedicalLeaveTo = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'total_non_medical_leave';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTotalNonMedicalLeave = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'total_half_pay_leave_taken';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTotalHalfPayLeaveTaken = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'balance_return_leave';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strBalanceReturnLeave = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'remarks';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strRemarks = $objDbRow->GetColumn($strAliasName, 'Blob');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idleaves != $objPreviousItem->Idleaves) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'leaves__';

			// Check for RefEstablishmentObject Early Binding
			$strAlias = $strAliasPrefix . 'ref_establishment__idestablishment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objRefEstablishmentObject = Establishment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ref_establishment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of Leaveses from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Leaves[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Leaves::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Leaves::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Leaves object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Leaves next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Leaves::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Leaves object,
		 * by Idleaves Index(es)
		 * @param integer $intIdleaves
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Leaves
		*/
		public static function LoadByIdleaves($intIdleaves, $objOptionalClauses = null) {
			return Leaves::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Leaves()->Idleaves, $intIdleaves)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Leaves objects,
		 * by RefEstablishment Index(es)
		 * @param integer $intRefEstablishment
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Leaves[]
		*/
		public static function LoadArrayByRefEstablishment($intRefEstablishment, $objOptionalClauses = null) {
			// Call Leaves::QueryArray to perform the LoadArrayByRefEstablishment query
			try {
				return Leaves::QueryArray(
					QQ::Equal(QQN::Leaves()->RefEstablishment, $intRefEstablishment),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Leaveses
		 * by RefEstablishment Index(es)
		 * @param integer $intRefEstablishment
		 * @return int
		*/
		public static function CountByRefEstablishment($intRefEstablishment) {
			// Call Leaves::QueryCount to perform the CountByRefEstablishment query
			return Leaves::QueryCount(
				QQ::Equal(QQN::Leaves()->RefEstablishment, $intRefEstablishment)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Leaves
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Leaves::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `leaves` (
							`ref_establishment`,
							`leaves_carried_in_days`,
							`leaves_at_credit`,
							`credit_leave_taken_from`,
							`credit_leave_taken_to`,
							`taken_leave_form`,
							`taken_leave_to`,
							`taken_no_of_days`,
							`leave_balance`,
							`service_length_from`,
							`service_length_to`,
							`years_of_service`,
							`leave_earned`,
							`leave_at_credit`,
							`medical_cert_leave_from`,
							`medical_cert_leave_to`,
							`total_medical_leaves`,
							`full_pay_leaves_from`,
							`full_pay_leaves_to`,
							`total_full_pay_leaves`,
							`commuted_half_pay_leaves`,
							`non_medical_leave_from`,
							`non_medical_leave_to`,
							`total_non_medical_leave`,
							`total_half_pay_leave_taken`,
							`balance_return_leave`,
							`remarks`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intRefEstablishment) . ',
							' . $objDatabase->SqlVariable($this->strLeavesCarriedInDays) . ',
							' . $objDatabase->SqlVariable($this->strLeavesAtCredit) . ',
							' . $objDatabase->SqlVariable($this->dttCreditLeaveTakenFrom) . ',
							' . $objDatabase->SqlVariable($this->dttCreditLeaveTakenTo) . ',
							' . $objDatabase->SqlVariable($this->dttTakenLeaveForm) . ',
							' . $objDatabase->SqlVariable($this->dttTakenLeaveTo) . ',
							' . $objDatabase->SqlVariable($this->strTakenNoOfDays) . ',
							' . $objDatabase->SqlVariable($this->strLeaveBalance) . ',
							' . $objDatabase->SqlVariable($this->dttServiceLengthFrom) . ',
							' . $objDatabase->SqlVariable($this->dttServiceLengthTo) . ',
							' . $objDatabase->SqlVariable($this->strYearsOfService) . ',
							' . $objDatabase->SqlVariable($this->strLeaveEarned) . ',
							' . $objDatabase->SqlVariable($this->strLeaveAtCredit) . ',
							' . $objDatabase->SqlVariable($this->dttMedicalCertLeaveFrom) . ',
							' . $objDatabase->SqlVariable($this->dttMedicalCertLeaveTo) . ',
							' . $objDatabase->SqlVariable($this->strTotalMedicalLeaves) . ',
							' . $objDatabase->SqlVariable($this->dttFullPayLeavesFrom) . ',
							' . $objDatabase->SqlVariable($this->dttFullPayLeavesTo) . ',
							' . $objDatabase->SqlVariable($this->strTotalFullPayLeaves) . ',
							' . $objDatabase->SqlVariable($this->strCommutedHalfPayLeaves) . ',
							' . $objDatabase->SqlVariable($this->dttNonMedicalLeaveFrom) . ',
							' . $objDatabase->SqlVariable($this->dttNonMedicalLeaveTo) . ',
							' . $objDatabase->SqlVariable($this->strTotalNonMedicalLeave) . ',
							' . $objDatabase->SqlVariable($this->strTotalHalfPayLeaveTaken) . ',
							' . $objDatabase->SqlVariable($this->strBalanceReturnLeave) . ',
							' . $objDatabase->SqlVariable($this->strRemarks) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdleaves = $objDatabase->InsertId('leaves', 'idleaves');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`leaves`
						SET
							`ref_establishment` = ' . $objDatabase->SqlVariable($this->intRefEstablishment) . ',
							`leaves_carried_in_days` = ' . $objDatabase->SqlVariable($this->strLeavesCarriedInDays) . ',
							`leaves_at_credit` = ' . $objDatabase->SqlVariable($this->strLeavesAtCredit) . ',
							`credit_leave_taken_from` = ' . $objDatabase->SqlVariable($this->dttCreditLeaveTakenFrom) . ',
							`credit_leave_taken_to` = ' . $objDatabase->SqlVariable($this->dttCreditLeaveTakenTo) . ',
							`taken_leave_form` = ' . $objDatabase->SqlVariable($this->dttTakenLeaveForm) . ',
							`taken_leave_to` = ' . $objDatabase->SqlVariable($this->dttTakenLeaveTo) . ',
							`taken_no_of_days` = ' . $objDatabase->SqlVariable($this->strTakenNoOfDays) . ',
							`leave_balance` = ' . $objDatabase->SqlVariable($this->strLeaveBalance) . ',
							`service_length_from` = ' . $objDatabase->SqlVariable($this->dttServiceLengthFrom) . ',
							`service_length_to` = ' . $objDatabase->SqlVariable($this->dttServiceLengthTo) . ',
							`years_of_service` = ' . $objDatabase->SqlVariable($this->strYearsOfService) . ',
							`leave_earned` = ' . $objDatabase->SqlVariable($this->strLeaveEarned) . ',
							`leave_at_credit` = ' . $objDatabase->SqlVariable($this->strLeaveAtCredit) . ',
							`medical_cert_leave_from` = ' . $objDatabase->SqlVariable($this->dttMedicalCertLeaveFrom) . ',
							`medical_cert_leave_to` = ' . $objDatabase->SqlVariable($this->dttMedicalCertLeaveTo) . ',
							`total_medical_leaves` = ' . $objDatabase->SqlVariable($this->strTotalMedicalLeaves) . ',
							`full_pay_leaves_from` = ' . $objDatabase->SqlVariable($this->dttFullPayLeavesFrom) . ',
							`full_pay_leaves_to` = ' . $objDatabase->SqlVariable($this->dttFullPayLeavesTo) . ',
							`total_full_pay_leaves` = ' . $objDatabase->SqlVariable($this->strTotalFullPayLeaves) . ',
							`commuted_half_pay_leaves` = ' . $objDatabase->SqlVariable($this->strCommutedHalfPayLeaves) . ',
							`non_medical_leave_from` = ' . $objDatabase->SqlVariable($this->dttNonMedicalLeaveFrom) . ',
							`non_medical_leave_to` = ' . $objDatabase->SqlVariable($this->dttNonMedicalLeaveTo) . ',
							`total_non_medical_leave` = ' . $objDatabase->SqlVariable($this->strTotalNonMedicalLeave) . ',
							`total_half_pay_leave_taken` = ' . $objDatabase->SqlVariable($this->strTotalHalfPayLeaveTaken) . ',
							`balance_return_leave` = ' . $objDatabase->SqlVariable($this->strBalanceReturnLeave) . ',
							`remarks` = ' . $objDatabase->SqlVariable($this->strRemarks) . '
						WHERE
							`idleaves` = ' . $objDatabase->SqlVariable($this->intIdleaves) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Leaves
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdleaves)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Leaves with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Leaves::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leaves`
				WHERE
					`idleaves` = ' . $objDatabase->SqlVariable($this->intIdleaves) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Leaves ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Leaves', $this->intIdleaves);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Leaveses
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Leaves::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leaves`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate leaves table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Leaves::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `leaves`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Leaves from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Leaves object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Leaves::Load($this->intIdleaves);

			// Update $this's local variables to match
			$this->RefEstablishment = $objReloaded->RefEstablishment;
			$this->strLeavesCarriedInDays = $objReloaded->strLeavesCarriedInDays;
			$this->strLeavesAtCredit = $objReloaded->strLeavesAtCredit;
			$this->dttCreditLeaveTakenFrom = $objReloaded->dttCreditLeaveTakenFrom;
			$this->dttCreditLeaveTakenTo = $objReloaded->dttCreditLeaveTakenTo;
			$this->dttTakenLeaveForm = $objReloaded->dttTakenLeaveForm;
			$this->dttTakenLeaveTo = $objReloaded->dttTakenLeaveTo;
			$this->strTakenNoOfDays = $objReloaded->strTakenNoOfDays;
			$this->strLeaveBalance = $objReloaded->strLeaveBalance;
			$this->dttServiceLengthFrom = $objReloaded->dttServiceLengthFrom;
			$this->dttServiceLengthTo = $objReloaded->dttServiceLengthTo;
			$this->strYearsOfService = $objReloaded->strYearsOfService;
			$this->strLeaveEarned = $objReloaded->strLeaveEarned;
			$this->strLeaveAtCredit = $objReloaded->strLeaveAtCredit;
			$this->dttMedicalCertLeaveFrom = $objReloaded->dttMedicalCertLeaveFrom;
			$this->dttMedicalCertLeaveTo = $objReloaded->dttMedicalCertLeaveTo;
			$this->strTotalMedicalLeaves = $objReloaded->strTotalMedicalLeaves;
			$this->dttFullPayLeavesFrom = $objReloaded->dttFullPayLeavesFrom;
			$this->dttFullPayLeavesTo = $objReloaded->dttFullPayLeavesTo;
			$this->strTotalFullPayLeaves = $objReloaded->strTotalFullPayLeaves;
			$this->strCommutedHalfPayLeaves = $objReloaded->strCommutedHalfPayLeaves;
			$this->dttNonMedicalLeaveFrom = $objReloaded->dttNonMedicalLeaveFrom;
			$this->dttNonMedicalLeaveTo = $objReloaded->dttNonMedicalLeaveTo;
			$this->strTotalNonMedicalLeave = $objReloaded->strTotalNonMedicalLeave;
			$this->strTotalHalfPayLeaveTaken = $objReloaded->strTotalHalfPayLeaveTaken;
			$this->strBalanceReturnLeave = $objReloaded->strBalanceReturnLeave;
			$this->strRemarks = $objReloaded->strRemarks;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idleaves':
					/**
					 * Gets the value for intIdleaves (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdleaves;

				case 'RefEstablishment':
					/**
					 * Gets the value for intRefEstablishment (Not Null)
					 * @return integer
					 */
					return $this->intRefEstablishment;

				case 'LeavesCarriedInDays':
					/**
					 * Gets the value for strLeavesCarriedInDays 
					 * @return string
					 */
					return $this->strLeavesCarriedInDays;

				case 'LeavesAtCredit':
					/**
					 * Gets the value for strLeavesAtCredit 
					 * @return string
					 */
					return $this->strLeavesAtCredit;

				case 'CreditLeaveTakenFrom':
					/**
					 * Gets the value for dttCreditLeaveTakenFrom 
					 * @return QDateTime
					 */
					return $this->dttCreditLeaveTakenFrom;

				case 'CreditLeaveTakenTo':
					/**
					 * Gets the value for dttCreditLeaveTakenTo 
					 * @return QDateTime
					 */
					return $this->dttCreditLeaveTakenTo;

				case 'TakenLeaveForm':
					/**
					 * Gets the value for dttTakenLeaveForm 
					 * @return QDateTime
					 */
					return $this->dttTakenLeaveForm;

				case 'TakenLeaveTo':
					/**
					 * Gets the value for dttTakenLeaveTo 
					 * @return QDateTime
					 */
					return $this->dttTakenLeaveTo;

				case 'TakenNoOfDays':
					/**
					 * Gets the value for strTakenNoOfDays 
					 * @return string
					 */
					return $this->strTakenNoOfDays;

				case 'LeaveBalance':
					/**
					 * Gets the value for strLeaveBalance 
					 * @return string
					 */
					return $this->strLeaveBalance;

				case 'ServiceLengthFrom':
					/**
					 * Gets the value for dttServiceLengthFrom 
					 * @return QDateTime
					 */
					return $this->dttServiceLengthFrom;

				case 'ServiceLengthTo':
					/**
					 * Gets the value for dttServiceLengthTo 
					 * @return QDateTime
					 */
					return $this->dttServiceLengthTo;

				case 'YearsOfService':
					/**
					 * Gets the value for strYearsOfService 
					 * @return string
					 */
					return $this->strYearsOfService;

				case 'LeaveEarned':
					/**
					 * Gets the value for strLeaveEarned 
					 * @return string
					 */
					return $this->strLeaveEarned;

				case 'LeaveAtCredit':
					/**
					 * Gets the value for strLeaveAtCredit 
					 * @return string
					 */
					return $this->strLeaveAtCredit;

				case 'MedicalCertLeaveFrom':
					/**
					 * Gets the value for dttMedicalCertLeaveFrom 
					 * @return QDateTime
					 */
					return $this->dttMedicalCertLeaveFrom;

				case 'MedicalCertLeaveTo':
					/**
					 * Gets the value for dttMedicalCertLeaveTo 
					 * @return QDateTime
					 */
					return $this->dttMedicalCertLeaveTo;

				case 'TotalMedicalLeaves':
					/**
					 * Gets the value for strTotalMedicalLeaves 
					 * @return string
					 */
					return $this->strTotalMedicalLeaves;

				case 'FullPayLeavesFrom':
					/**
					 * Gets the value for dttFullPayLeavesFrom 
					 * @return QDateTime
					 */
					return $this->dttFullPayLeavesFrom;

				case 'FullPayLeavesTo':
					/**
					 * Gets the value for dttFullPayLeavesTo 
					 * @return QDateTime
					 */
					return $this->dttFullPayLeavesTo;

				case 'TotalFullPayLeaves':
					/**
					 * Gets the value for strTotalFullPayLeaves 
					 * @return string
					 */
					return $this->strTotalFullPayLeaves;

				case 'CommutedHalfPayLeaves':
					/**
					 * Gets the value for strCommutedHalfPayLeaves 
					 * @return string
					 */
					return $this->strCommutedHalfPayLeaves;

				case 'NonMedicalLeaveFrom':
					/**
					 * Gets the value for dttNonMedicalLeaveFrom 
					 * @return QDateTime
					 */
					return $this->dttNonMedicalLeaveFrom;

				case 'NonMedicalLeaveTo':
					/**
					 * Gets the value for dttNonMedicalLeaveTo 
					 * @return QDateTime
					 */
					return $this->dttNonMedicalLeaveTo;

				case 'TotalNonMedicalLeave':
					/**
					 * Gets the value for strTotalNonMedicalLeave 
					 * @return string
					 */
					return $this->strTotalNonMedicalLeave;

				case 'TotalHalfPayLeaveTaken':
					/**
					 * Gets the value for strTotalHalfPayLeaveTaken 
					 * @return string
					 */
					return $this->strTotalHalfPayLeaveTaken;

				case 'BalanceReturnLeave':
					/**
					 * Gets the value for strBalanceReturnLeave 
					 * @return string
					 */
					return $this->strBalanceReturnLeave;

				case 'Remarks':
					/**
					 * Gets the value for strRemarks 
					 * @return string
					 */
					return $this->strRemarks;


				///////////////////
				// Member Objects
				///////////////////
				case 'RefEstablishmentObject':
					/**
					 * Gets the value for the Establishment object referenced by intRefEstablishment (Not Null)
					 * @return Establishment
					 */
					try {
						if ((!$this->objRefEstablishmentObject) && (!is_null($this->intRefEstablishment)))
							$this->objRefEstablishmentObject = Establishment::Load($this->intRefEstablishment);
						return $this->objRefEstablishmentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'RefEstablishment':
					/**
					 * Sets the value for intRefEstablishment (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objRefEstablishmentObject = null;
						return ($this->intRefEstablishment = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeavesCarriedInDays':
					/**
					 * Sets the value for strLeavesCarriedInDays 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strLeavesCarriedInDays = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeavesAtCredit':
					/**
					 * Sets the value for strLeavesAtCredit 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strLeavesAtCredit = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CreditLeaveTakenFrom':
					/**
					 * Sets the value for dttCreditLeaveTakenFrom 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttCreditLeaveTakenFrom = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CreditLeaveTakenTo':
					/**
					 * Sets the value for dttCreditLeaveTakenTo 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttCreditLeaveTakenTo = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TakenLeaveForm':
					/**
					 * Sets the value for dttTakenLeaveForm 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttTakenLeaveForm = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TakenLeaveTo':
					/**
					 * Sets the value for dttTakenLeaveTo 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttTakenLeaveTo = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TakenNoOfDays':
					/**
					 * Sets the value for strTakenNoOfDays 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTakenNoOfDays = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeaveBalance':
					/**
					 * Sets the value for strLeaveBalance 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strLeaveBalance = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ServiceLengthFrom':
					/**
					 * Sets the value for dttServiceLengthFrom 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttServiceLengthFrom = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ServiceLengthTo':
					/**
					 * Sets the value for dttServiceLengthTo 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttServiceLengthTo = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'YearsOfService':
					/**
					 * Sets the value for strYearsOfService 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strYearsOfService = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeaveEarned':
					/**
					 * Sets the value for strLeaveEarned 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strLeaveEarned = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeaveAtCredit':
					/**
					 * Sets the value for strLeaveAtCredit 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strLeaveAtCredit = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'MedicalCertLeaveFrom':
					/**
					 * Sets the value for dttMedicalCertLeaveFrom 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttMedicalCertLeaveFrom = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'MedicalCertLeaveTo':
					/**
					 * Sets the value for dttMedicalCertLeaveTo 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttMedicalCertLeaveTo = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TotalMedicalLeaves':
					/**
					 * Sets the value for strTotalMedicalLeaves 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTotalMedicalLeaves = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'FullPayLeavesFrom':
					/**
					 * Sets the value for dttFullPayLeavesFrom 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttFullPayLeavesFrom = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'FullPayLeavesTo':
					/**
					 * Sets the value for dttFullPayLeavesTo 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttFullPayLeavesTo = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TotalFullPayLeaves':
					/**
					 * Sets the value for strTotalFullPayLeaves 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTotalFullPayLeaves = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CommutedHalfPayLeaves':
					/**
					 * Sets the value for strCommutedHalfPayLeaves 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCommutedHalfPayLeaves = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'NonMedicalLeaveFrom':
					/**
					 * Sets the value for dttNonMedicalLeaveFrom 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttNonMedicalLeaveFrom = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'NonMedicalLeaveTo':
					/**
					 * Sets the value for dttNonMedicalLeaveTo 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttNonMedicalLeaveTo = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TotalNonMedicalLeave':
					/**
					 * Sets the value for strTotalNonMedicalLeave 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTotalNonMedicalLeave = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TotalHalfPayLeaveTaken':
					/**
					 * Sets the value for strTotalHalfPayLeaveTaken 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTotalHalfPayLeaveTaken = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'BalanceReturnLeave':
					/**
					 * Sets the value for strBalanceReturnLeave 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strBalanceReturnLeave = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Remarks':
					/**
					 * Sets the value for strRemarks 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strRemarks = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'RefEstablishmentObject':
					/**
					 * Sets the value for the Establishment object referenced by intRefEstablishment (Not Null)
					 * @param Establishment $mixValue
					 * @return Establishment
					 */
					if (is_null($mixValue)) {
						$this->intRefEstablishment = null;
						$this->objRefEstablishmentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Establishment object
						try {
							$mixValue = QType::Cast($mixValue, 'Establishment');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Establishment object
						if (is_null($mixValue->Idestablishment))
							throw new QCallerException('Unable to set an unsaved RefEstablishmentObject for this Leaves');

						// Update Local Member Variables
						$this->objRefEstablishmentObject = $mixValue;
						$this->intRefEstablishment = $mixValue->Idestablishment;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "leaves";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Leaves::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Leaves"><sequence>';
			$strToReturn .= '<element name="Idleaves" type="xsd:int"/>';
			$strToReturn .= '<element name="RefEstablishmentObject" type="xsd1:Establishment"/>';
			$strToReturn .= '<element name="LeavesCarriedInDays" type="xsd:string"/>';
			$strToReturn .= '<element name="LeavesAtCredit" type="xsd:string"/>';
			$strToReturn .= '<element name="CreditLeaveTakenFrom" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="CreditLeaveTakenTo" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="TakenLeaveForm" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="TakenLeaveTo" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="TakenNoOfDays" type="xsd:string"/>';
			$strToReturn .= '<element name="LeaveBalance" type="xsd:string"/>';
			$strToReturn .= '<element name="ServiceLengthFrom" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="ServiceLengthTo" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="YearsOfService" type="xsd:string"/>';
			$strToReturn .= '<element name="LeaveEarned" type="xsd:string"/>';
			$strToReturn .= '<element name="LeaveAtCredit" type="xsd:string"/>';
			$strToReturn .= '<element name="MedicalCertLeaveFrom" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="MedicalCertLeaveTo" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="TotalMedicalLeaves" type="xsd:string"/>';
			$strToReturn .= '<element name="FullPayLeavesFrom" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="FullPayLeavesTo" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="TotalFullPayLeaves" type="xsd:string"/>';
			$strToReturn .= '<element name="CommutedHalfPayLeaves" type="xsd:string"/>';
			$strToReturn .= '<element name="NonMedicalLeaveFrom" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="NonMedicalLeaveTo" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="TotalNonMedicalLeave" type="xsd:string"/>';
			$strToReturn .= '<element name="TotalHalfPayLeaveTaken" type="xsd:string"/>';
			$strToReturn .= '<element name="BalanceReturnLeave" type="xsd:string"/>';
			$strToReturn .= '<element name="Remarks" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Leaves', $strComplexTypeArray)) {
				$strComplexTypeArray['Leaves'] = Leaves::GetSoapComplexTypeXml();
				Establishment::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Leaves::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Leaves();
			if (property_exists($objSoapObject, 'Idleaves'))
				$objToReturn->intIdleaves = $objSoapObject->Idleaves;
			if ((property_exists($objSoapObject, 'RefEstablishmentObject')) &&
				($objSoapObject->RefEstablishmentObject))
				$objToReturn->RefEstablishmentObject = Establishment::GetObjectFromSoapObject($objSoapObject->RefEstablishmentObject);
			if (property_exists($objSoapObject, 'LeavesCarriedInDays'))
				$objToReturn->strLeavesCarriedInDays = $objSoapObject->LeavesCarriedInDays;
			if (property_exists($objSoapObject, 'LeavesAtCredit'))
				$objToReturn->strLeavesAtCredit = $objSoapObject->LeavesAtCredit;
			if (property_exists($objSoapObject, 'CreditLeaveTakenFrom'))
				$objToReturn->dttCreditLeaveTakenFrom = new QDateTime($objSoapObject->CreditLeaveTakenFrom);
			if (property_exists($objSoapObject, 'CreditLeaveTakenTo'))
				$objToReturn->dttCreditLeaveTakenTo = new QDateTime($objSoapObject->CreditLeaveTakenTo);
			if (property_exists($objSoapObject, 'TakenLeaveForm'))
				$objToReturn->dttTakenLeaveForm = new QDateTime($objSoapObject->TakenLeaveForm);
			if (property_exists($objSoapObject, 'TakenLeaveTo'))
				$objToReturn->dttTakenLeaveTo = new QDateTime($objSoapObject->TakenLeaveTo);
			if (property_exists($objSoapObject, 'TakenNoOfDays'))
				$objToReturn->strTakenNoOfDays = $objSoapObject->TakenNoOfDays;
			if (property_exists($objSoapObject, 'LeaveBalance'))
				$objToReturn->strLeaveBalance = $objSoapObject->LeaveBalance;
			if (property_exists($objSoapObject, 'ServiceLengthFrom'))
				$objToReturn->dttServiceLengthFrom = new QDateTime($objSoapObject->ServiceLengthFrom);
			if (property_exists($objSoapObject, 'ServiceLengthTo'))
				$objToReturn->dttServiceLengthTo = new QDateTime($objSoapObject->ServiceLengthTo);
			if (property_exists($objSoapObject, 'YearsOfService'))
				$objToReturn->strYearsOfService = $objSoapObject->YearsOfService;
			if (property_exists($objSoapObject, 'LeaveEarned'))
				$objToReturn->strLeaveEarned = $objSoapObject->LeaveEarned;
			if (property_exists($objSoapObject, 'LeaveAtCredit'))
				$objToReturn->strLeaveAtCredit = $objSoapObject->LeaveAtCredit;
			if (property_exists($objSoapObject, 'MedicalCertLeaveFrom'))
				$objToReturn->dttMedicalCertLeaveFrom = new QDateTime($objSoapObject->MedicalCertLeaveFrom);
			if (property_exists($objSoapObject, 'MedicalCertLeaveTo'))
				$objToReturn->dttMedicalCertLeaveTo = new QDateTime($objSoapObject->MedicalCertLeaveTo);
			if (property_exists($objSoapObject, 'TotalMedicalLeaves'))
				$objToReturn->strTotalMedicalLeaves = $objSoapObject->TotalMedicalLeaves;
			if (property_exists($objSoapObject, 'FullPayLeavesFrom'))
				$objToReturn->dttFullPayLeavesFrom = new QDateTime($objSoapObject->FullPayLeavesFrom);
			if (property_exists($objSoapObject, 'FullPayLeavesTo'))
				$objToReturn->dttFullPayLeavesTo = new QDateTime($objSoapObject->FullPayLeavesTo);
			if (property_exists($objSoapObject, 'TotalFullPayLeaves'))
				$objToReturn->strTotalFullPayLeaves = $objSoapObject->TotalFullPayLeaves;
			if (property_exists($objSoapObject, 'CommutedHalfPayLeaves'))
				$objToReturn->strCommutedHalfPayLeaves = $objSoapObject->CommutedHalfPayLeaves;
			if (property_exists($objSoapObject, 'NonMedicalLeaveFrom'))
				$objToReturn->dttNonMedicalLeaveFrom = new QDateTime($objSoapObject->NonMedicalLeaveFrom);
			if (property_exists($objSoapObject, 'NonMedicalLeaveTo'))
				$objToReturn->dttNonMedicalLeaveTo = new QDateTime($objSoapObject->NonMedicalLeaveTo);
			if (property_exists($objSoapObject, 'TotalNonMedicalLeave'))
				$objToReturn->strTotalNonMedicalLeave = $objSoapObject->TotalNonMedicalLeave;
			if (property_exists($objSoapObject, 'TotalHalfPayLeaveTaken'))
				$objToReturn->strTotalHalfPayLeaveTaken = $objSoapObject->TotalHalfPayLeaveTaken;
			if (property_exists($objSoapObject, 'BalanceReturnLeave'))
				$objToReturn->strBalanceReturnLeave = $objSoapObject->BalanceReturnLeave;
			if (property_exists($objSoapObject, 'Remarks'))
				$objToReturn->strRemarks = $objSoapObject->Remarks;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Leaves::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objRefEstablishmentObject)
				$objObject->objRefEstablishmentObject = Establishment::GetSoapObjectFromObject($objObject->objRefEstablishmentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intRefEstablishment = null;
			if ($objObject->dttCreditLeaveTakenFrom)
				$objObject->dttCreditLeaveTakenFrom = $objObject->dttCreditLeaveTakenFrom->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttCreditLeaveTakenTo)
				$objObject->dttCreditLeaveTakenTo = $objObject->dttCreditLeaveTakenTo->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttTakenLeaveForm)
				$objObject->dttTakenLeaveForm = $objObject->dttTakenLeaveForm->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttTakenLeaveTo)
				$objObject->dttTakenLeaveTo = $objObject->dttTakenLeaveTo->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttServiceLengthFrom)
				$objObject->dttServiceLengthFrom = $objObject->dttServiceLengthFrom->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttServiceLengthTo)
				$objObject->dttServiceLengthTo = $objObject->dttServiceLengthTo->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttMedicalCertLeaveFrom)
				$objObject->dttMedicalCertLeaveFrom = $objObject->dttMedicalCertLeaveFrom->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttMedicalCertLeaveTo)
				$objObject->dttMedicalCertLeaveTo = $objObject->dttMedicalCertLeaveTo->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttFullPayLeavesFrom)
				$objObject->dttFullPayLeavesFrom = $objObject->dttFullPayLeavesFrom->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttFullPayLeavesTo)
				$objObject->dttFullPayLeavesTo = $objObject->dttFullPayLeavesTo->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttNonMedicalLeaveFrom)
				$objObject->dttNonMedicalLeaveFrom = $objObject->dttNonMedicalLeaveFrom->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttNonMedicalLeaveTo)
				$objObject->dttNonMedicalLeaveTo = $objObject->dttNonMedicalLeaveTo->qFormat(QDateTime::FormatSoap);
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idleaves'] = $this->intIdleaves;
			$iArray['RefEstablishment'] = $this->intRefEstablishment;
			$iArray['LeavesCarriedInDays'] = $this->strLeavesCarriedInDays;
			$iArray['LeavesAtCredit'] = $this->strLeavesAtCredit;
			$iArray['CreditLeaveTakenFrom'] = $this->dttCreditLeaveTakenFrom;
			$iArray['CreditLeaveTakenTo'] = $this->dttCreditLeaveTakenTo;
			$iArray['TakenLeaveForm'] = $this->dttTakenLeaveForm;
			$iArray['TakenLeaveTo'] = $this->dttTakenLeaveTo;
			$iArray['TakenNoOfDays'] = $this->strTakenNoOfDays;
			$iArray['LeaveBalance'] = $this->strLeaveBalance;
			$iArray['ServiceLengthFrom'] = $this->dttServiceLengthFrom;
			$iArray['ServiceLengthTo'] = $this->dttServiceLengthTo;
			$iArray['YearsOfService'] = $this->strYearsOfService;
			$iArray['LeaveEarned'] = $this->strLeaveEarned;
			$iArray['LeaveAtCredit'] = $this->strLeaveAtCredit;
			$iArray['MedicalCertLeaveFrom'] = $this->dttMedicalCertLeaveFrom;
			$iArray['MedicalCertLeaveTo'] = $this->dttMedicalCertLeaveTo;
			$iArray['TotalMedicalLeaves'] = $this->strTotalMedicalLeaves;
			$iArray['FullPayLeavesFrom'] = $this->dttFullPayLeavesFrom;
			$iArray['FullPayLeavesTo'] = $this->dttFullPayLeavesTo;
			$iArray['TotalFullPayLeaves'] = $this->strTotalFullPayLeaves;
			$iArray['CommutedHalfPayLeaves'] = $this->strCommutedHalfPayLeaves;
			$iArray['NonMedicalLeaveFrom'] = $this->dttNonMedicalLeaveFrom;
			$iArray['NonMedicalLeaveTo'] = $this->dttNonMedicalLeaveTo;
			$iArray['TotalNonMedicalLeave'] = $this->strTotalNonMedicalLeave;
			$iArray['TotalHalfPayLeaveTaken'] = $this->strTotalHalfPayLeaveTaken;
			$iArray['BalanceReturnLeave'] = $this->strBalanceReturnLeave;
			$iArray['Remarks'] = $this->strRemarks;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdleaves ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idleaves
     * @property-read QQNode $RefEstablishment
     * @property-read QQNodeEstablishment $RefEstablishmentObject
     * @property-read QQNode $LeavesCarriedInDays
     * @property-read QQNode $LeavesAtCredit
     * @property-read QQNode $CreditLeaveTakenFrom
     * @property-read QQNode $CreditLeaveTakenTo
     * @property-read QQNode $TakenLeaveForm
     * @property-read QQNode $TakenLeaveTo
     * @property-read QQNode $TakenNoOfDays
     * @property-read QQNode $LeaveBalance
     * @property-read QQNode $ServiceLengthFrom
     * @property-read QQNode $ServiceLengthTo
     * @property-read QQNode $YearsOfService
     * @property-read QQNode $LeaveEarned
     * @property-read QQNode $LeaveAtCredit
     * @property-read QQNode $MedicalCertLeaveFrom
     * @property-read QQNode $MedicalCertLeaveTo
     * @property-read QQNode $TotalMedicalLeaves
     * @property-read QQNode $FullPayLeavesFrom
     * @property-read QQNode $FullPayLeavesTo
     * @property-read QQNode $TotalFullPayLeaves
     * @property-read QQNode $CommutedHalfPayLeaves
     * @property-read QQNode $NonMedicalLeaveFrom
     * @property-read QQNode $NonMedicalLeaveTo
     * @property-read QQNode $TotalNonMedicalLeave
     * @property-read QQNode $TotalHalfPayLeaveTaken
     * @property-read QQNode $BalanceReturnLeave
     * @property-read QQNode $Remarks
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeLeaves extends QQNode {
		protected $strTableName = 'leaves';
		protected $strPrimaryKey = 'idleaves';
		protected $strClassName = 'Leaves';
		public function __get($strName) {
			switch ($strName) {
				case 'Idleaves':
					return new QQNode('idleaves', 'Idleaves', 'Integer', $this);
				case 'RefEstablishment':
					return new QQNode('ref_establishment', 'RefEstablishment', 'Integer', $this);
				case 'RefEstablishmentObject':
					return new QQNodeEstablishment('ref_establishment', 'RefEstablishmentObject', 'Integer', $this);
				case 'LeavesCarriedInDays':
					return new QQNode('leaves_carried_in_days', 'LeavesCarriedInDays', 'VarChar', $this);
				case 'LeavesAtCredit':
					return new QQNode('leaves_at_credit', 'LeavesAtCredit', 'VarChar', $this);
				case 'CreditLeaveTakenFrom':
					return new QQNode('credit_leave_taken_from', 'CreditLeaveTakenFrom', 'Date', $this);
				case 'CreditLeaveTakenTo':
					return new QQNode('credit_leave_taken_to', 'CreditLeaveTakenTo', 'Date', $this);
				case 'TakenLeaveForm':
					return new QQNode('taken_leave_form', 'TakenLeaveForm', 'Date', $this);
				case 'TakenLeaveTo':
					return new QQNode('taken_leave_to', 'TakenLeaveTo', 'Date', $this);
				case 'TakenNoOfDays':
					return new QQNode('taken_no_of_days', 'TakenNoOfDays', 'VarChar', $this);
				case 'LeaveBalance':
					return new QQNode('leave_balance', 'LeaveBalance', 'VarChar', $this);
				case 'ServiceLengthFrom':
					return new QQNode('service_length_from', 'ServiceLengthFrom', 'Date', $this);
				case 'ServiceLengthTo':
					return new QQNode('service_length_to', 'ServiceLengthTo', 'Date', $this);
				case 'YearsOfService':
					return new QQNode('years_of_service', 'YearsOfService', 'VarChar', $this);
				case 'LeaveEarned':
					return new QQNode('leave_earned', 'LeaveEarned', 'VarChar', $this);
				case 'LeaveAtCredit':
					return new QQNode('leave_at_credit', 'LeaveAtCredit', 'VarChar', $this);
				case 'MedicalCertLeaveFrom':
					return new QQNode('medical_cert_leave_from', 'MedicalCertLeaveFrom', 'Date', $this);
				case 'MedicalCertLeaveTo':
					return new QQNode('medical_cert_leave_to', 'MedicalCertLeaveTo', 'Date', $this);
				case 'TotalMedicalLeaves':
					return new QQNode('total_medical_leaves', 'TotalMedicalLeaves', 'VarChar', $this);
				case 'FullPayLeavesFrom':
					return new QQNode('full_pay_leaves_from', 'FullPayLeavesFrom', 'Date', $this);
				case 'FullPayLeavesTo':
					return new QQNode('full_pay_leaves_to', 'FullPayLeavesTo', 'Date', $this);
				case 'TotalFullPayLeaves':
					return new QQNode('total_full_pay_leaves', 'TotalFullPayLeaves', 'VarChar', $this);
				case 'CommutedHalfPayLeaves':
					return new QQNode('commuted_half_pay_leaves', 'CommutedHalfPayLeaves', 'VarChar', $this);
				case 'NonMedicalLeaveFrom':
					return new QQNode('non_medical_leave_from', 'NonMedicalLeaveFrom', 'Date', $this);
				case 'NonMedicalLeaveTo':
					return new QQNode('non_medical_leave_to', 'NonMedicalLeaveTo', 'Date', $this);
				case 'TotalNonMedicalLeave':
					return new QQNode('total_non_medical_leave', 'TotalNonMedicalLeave', 'VarChar', $this);
				case 'TotalHalfPayLeaveTaken':
					return new QQNode('total_half_pay_leave_taken', 'TotalHalfPayLeaveTaken', 'VarChar', $this);
				case 'BalanceReturnLeave':
					return new QQNode('balance_return_leave', 'BalanceReturnLeave', 'VarChar', $this);
				case 'Remarks':
					return new QQNode('remarks', 'Remarks', 'Blob', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idleaves', 'Idleaves', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idleaves
     * @property-read QQNode $RefEstablishment
     * @property-read QQNodeEstablishment $RefEstablishmentObject
     * @property-read QQNode $LeavesCarriedInDays
     * @property-read QQNode $LeavesAtCredit
     * @property-read QQNode $CreditLeaveTakenFrom
     * @property-read QQNode $CreditLeaveTakenTo
     * @property-read QQNode $TakenLeaveForm
     * @property-read QQNode $TakenLeaveTo
     * @property-read QQNode $TakenNoOfDays
     * @property-read QQNode $LeaveBalance
     * @property-read QQNode $ServiceLengthFrom
     * @property-read QQNode $ServiceLengthTo
     * @property-read QQNode $YearsOfService
     * @property-read QQNode $LeaveEarned
     * @property-read QQNode $LeaveAtCredit
     * @property-read QQNode $MedicalCertLeaveFrom
     * @property-read QQNode $MedicalCertLeaveTo
     * @property-read QQNode $TotalMedicalLeaves
     * @property-read QQNode $FullPayLeavesFrom
     * @property-read QQNode $FullPayLeavesTo
     * @property-read QQNode $TotalFullPayLeaves
     * @property-read QQNode $CommutedHalfPayLeaves
     * @property-read QQNode $NonMedicalLeaveFrom
     * @property-read QQNode $NonMedicalLeaveTo
     * @property-read QQNode $TotalNonMedicalLeave
     * @property-read QQNode $TotalHalfPayLeaveTaken
     * @property-read QQNode $BalanceReturnLeave
     * @property-read QQNode $Remarks
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeLeaves extends QQReverseReferenceNode {
		protected $strTableName = 'leaves';
		protected $strPrimaryKey = 'idleaves';
		protected $strClassName = 'Leaves';
		public function __get($strName) {
			switch ($strName) {
				case 'Idleaves':
					return new QQNode('idleaves', 'Idleaves', 'integer', $this);
				case 'RefEstablishment':
					return new QQNode('ref_establishment', 'RefEstablishment', 'integer', $this);
				case 'RefEstablishmentObject':
					return new QQNodeEstablishment('ref_establishment', 'RefEstablishmentObject', 'integer', $this);
				case 'LeavesCarriedInDays':
					return new QQNode('leaves_carried_in_days', 'LeavesCarriedInDays', 'string', $this);
				case 'LeavesAtCredit':
					return new QQNode('leaves_at_credit', 'LeavesAtCredit', 'string', $this);
				case 'CreditLeaveTakenFrom':
					return new QQNode('credit_leave_taken_from', 'CreditLeaveTakenFrom', 'QDateTime', $this);
				case 'CreditLeaveTakenTo':
					return new QQNode('credit_leave_taken_to', 'CreditLeaveTakenTo', 'QDateTime', $this);
				case 'TakenLeaveForm':
					return new QQNode('taken_leave_form', 'TakenLeaveForm', 'QDateTime', $this);
				case 'TakenLeaveTo':
					return new QQNode('taken_leave_to', 'TakenLeaveTo', 'QDateTime', $this);
				case 'TakenNoOfDays':
					return new QQNode('taken_no_of_days', 'TakenNoOfDays', 'string', $this);
				case 'LeaveBalance':
					return new QQNode('leave_balance', 'LeaveBalance', 'string', $this);
				case 'ServiceLengthFrom':
					return new QQNode('service_length_from', 'ServiceLengthFrom', 'QDateTime', $this);
				case 'ServiceLengthTo':
					return new QQNode('service_length_to', 'ServiceLengthTo', 'QDateTime', $this);
				case 'YearsOfService':
					return new QQNode('years_of_service', 'YearsOfService', 'string', $this);
				case 'LeaveEarned':
					return new QQNode('leave_earned', 'LeaveEarned', 'string', $this);
				case 'LeaveAtCredit':
					return new QQNode('leave_at_credit', 'LeaveAtCredit', 'string', $this);
				case 'MedicalCertLeaveFrom':
					return new QQNode('medical_cert_leave_from', 'MedicalCertLeaveFrom', 'QDateTime', $this);
				case 'MedicalCertLeaveTo':
					return new QQNode('medical_cert_leave_to', 'MedicalCertLeaveTo', 'QDateTime', $this);
				case 'TotalMedicalLeaves':
					return new QQNode('total_medical_leaves', 'TotalMedicalLeaves', 'string', $this);
				case 'FullPayLeavesFrom':
					return new QQNode('full_pay_leaves_from', 'FullPayLeavesFrom', 'QDateTime', $this);
				case 'FullPayLeavesTo':
					return new QQNode('full_pay_leaves_to', 'FullPayLeavesTo', 'QDateTime', $this);
				case 'TotalFullPayLeaves':
					return new QQNode('total_full_pay_leaves', 'TotalFullPayLeaves', 'string', $this);
				case 'CommutedHalfPayLeaves':
					return new QQNode('commuted_half_pay_leaves', 'CommutedHalfPayLeaves', 'string', $this);
				case 'NonMedicalLeaveFrom':
					return new QQNode('non_medical_leave_from', 'NonMedicalLeaveFrom', 'QDateTime', $this);
				case 'NonMedicalLeaveTo':
					return new QQNode('non_medical_leave_to', 'NonMedicalLeaveTo', 'QDateTime', $this);
				case 'TotalNonMedicalLeave':
					return new QQNode('total_non_medical_leave', 'TotalNonMedicalLeave', 'string', $this);
				case 'TotalHalfPayLeaveTaken':
					return new QQNode('total_half_pay_leave_taken', 'TotalHalfPayLeaveTaken', 'string', $this);
				case 'BalanceReturnLeave':
					return new QQNode('balance_return_leave', 'BalanceReturnLeave', 'string', $this);
				case 'Remarks':
					return new QQNode('remarks', 'Remarks', 'string', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idleaves', 'Idleaves', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
