<?php
	/**
	 * The abstract DeptYearEventsGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the DeptYearEvents subclass which
	 * extends this DeptYearEventsGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the DeptYearEvents class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IddeptYearEvents the value for intIddeptYearEvents (Read-Only PK)
	 * @property string $Title the value for strTitle (Unique)
	 * @property integer $Event the value for intEvent (Not Null)
	 * @property integer $Department the value for intDepartment 
	 * @property integer $DeptYear the value for intDeptYear 
	 * @property integer $CalenderYear the value for intCalenderYear 
	 * @property integer $Parrent the value for intParrent 
	 * @property QDateTime $From the value for dttFrom (Not Null)
	 * @property QDateTime $To the value for dttTo (Not Null)
	 * @property string $Description the value for strDescription 
	 * @property Event $EventObject the value for the Event object referenced by intEvent (Not Null)
	 * @property Role $DepartmentObject the value for the Role object referenced by intDepartment 
	 * @property DeptYear $DeptYearObject the value for the DeptYear object referenced by intDeptYear 
	 * @property CalenderYear $CalenderYearObject the value for the CalenderYear object referenced by intCalenderYear 
	 * @property DeptYearEvents $ParrentObject the value for the DeptYearEvents object referenced by intParrent 
	 * @property-read DeptYearEvents $_DeptYearEventsAsParrent the value for the private _objDeptYearEventsAsParrent (Read-Only) if set due to an expansion on the dept_year_events.parrent reverse relationship
	 * @property-read DeptYearEvents[] $_DeptYearEventsAsParrentArray the value for the private _objDeptYearEventsAsParrentArray (Read-Only) if set due to an ExpandAsArray on the dept_year_events.parrent reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class DeptYearEventsGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column dept_year_events.iddept_year_events
		 * @var integer intIddeptYearEvents
		 */
		protected $intIddeptYearEvents;
		const IddeptYearEventsDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.title
		 * @var string strTitle
		 */
		protected $strTitle;
		const TitleMaxLength = 255;
		const TitleDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.event
		 * @var integer intEvent
		 */
		protected $intEvent;
		const EventDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.department
		 * @var integer intDepartment
		 */
		protected $intDepartment;
		const DepartmentDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.dept_year
		 * @var integer intDeptYear
		 */
		protected $intDeptYear;
		const DeptYearDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.calender_year
		 * @var integer intCalenderYear
		 */
		protected $intCalenderYear;
		const CalenderYearDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.parrent
		 * @var integer intParrent
		 */
		protected $intParrent;
		const ParrentDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.from
		 * @var QDateTime dttFrom
		 */
		protected $dttFrom;
		const FromDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.to
		 * @var QDateTime dttTo
		 */
		protected $dttTo;
		const ToDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.description
		 * @var string strDescription
		 */
		protected $strDescription;
		const DescriptionDefault = null;


		/**
		 * Private member variable that stores a reference to a single DeptYearEventsAsParrent object
		 * (of type DeptYearEvents), if this DeptYearEvents object was restored with
		 * an expansion on the dept_year_events association table.
		 * @var DeptYearEvents _objDeptYearEventsAsParrent;
		 */
		private $_objDeptYearEventsAsParrent;

		/**
		 * Private member variable that stores a reference to an array of DeptYearEventsAsParrent objects
		 * (of type DeptYearEvents[]), if this DeptYearEvents object was restored with
		 * an ExpandAsArray on the dept_year_events association table.
		 * @var DeptYearEvents[] _objDeptYearEventsAsParrentArray;
		 */
		private $_objDeptYearEventsAsParrentArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_events.event.
		 *
		 * NOTE: Always use the EventObject property getter to correctly retrieve this Event object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Event objEventObject
		 */
		protected $objEventObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_events.department.
		 *
		 * NOTE: Always use the DepartmentObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objDepartmentObject
		 */
		protected $objDepartmentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_events.dept_year.
		 *
		 * NOTE: Always use the DeptYearObject property getter to correctly retrieve this DeptYear object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var DeptYear objDeptYearObject
		 */
		protected $objDeptYearObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_events.calender_year.
		 *
		 * NOTE: Always use the CalenderYearObject property getter to correctly retrieve this CalenderYear object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var CalenderYear objCalenderYearObject
		 */
		protected $objCalenderYearObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_events.parrent.
		 *
		 * NOTE: Always use the ParrentObject property getter to correctly retrieve this DeptYearEvents object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var DeptYearEvents objParrentObject
		 */
		protected $objParrentObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIddeptYearEvents = DeptYearEvents::IddeptYearEventsDefault;
			$this->strTitle = DeptYearEvents::TitleDefault;
			$this->intEvent = DeptYearEvents::EventDefault;
			$this->intDepartment = DeptYearEvents::DepartmentDefault;
			$this->intDeptYear = DeptYearEvents::DeptYearDefault;
			$this->intCalenderYear = DeptYearEvents::CalenderYearDefault;
			$this->intParrent = DeptYearEvents::ParrentDefault;
			$this->dttFrom = (DeptYearEvents::FromDefault === null)?null:new QDateTime(DeptYearEvents::FromDefault);
			$this->dttTo = (DeptYearEvents::ToDefault === null)?null:new QDateTime(DeptYearEvents::ToDefault);
			$this->strDescription = DeptYearEvents::DescriptionDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a DeptYearEvents from PK Info
		 * @param integer $intIddeptYearEvents
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents
		 */
		public static function Load($intIddeptYearEvents, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'DeptYearEvents', $intIddeptYearEvents);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = DeptYearEvents::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::DeptYearEvents()->IddeptYearEvents, $intIddeptYearEvents)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all DeptYearEventses
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call DeptYearEvents::QueryArray to perform the LoadAll query
			try {
				return DeptYearEvents::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all DeptYearEventses
		 * @return int
		 */
		public static function CountAll() {
			// Call DeptYearEvents::QueryCount to perform the CountAll query
			return DeptYearEvents::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Create/Build out the QueryBuilder object with DeptYearEvents-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'dept_year_events');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				DeptYearEvents::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('dept_year_events');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single DeptYearEvents object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return DeptYearEvents the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = DeptYearEvents::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new DeptYearEvents object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = DeptYearEvents::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return DeptYearEvents::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of DeptYearEvents objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return DeptYearEvents[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = DeptYearEvents::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return DeptYearEvents::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = DeptYearEvents::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of DeptYearEvents objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = DeptYearEvents::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			$strQuery = DeptYearEvents::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/deptyearevents', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = DeptYearEvents::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this DeptYearEvents
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'dept_year_events';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'iddept_year_events', $strAliasPrefix . 'iddept_year_events');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'iddept_year_events', $strAliasPrefix . 'iddept_year_events');
			    $objBuilder->AddSelectItem($strTableName, 'title', $strAliasPrefix . 'title');
			    $objBuilder->AddSelectItem($strTableName, 'event', $strAliasPrefix . 'event');
			    $objBuilder->AddSelectItem($strTableName, 'department', $strAliasPrefix . 'department');
			    $objBuilder->AddSelectItem($strTableName, 'dept_year', $strAliasPrefix . 'dept_year');
			    $objBuilder->AddSelectItem($strTableName, 'calender_year', $strAliasPrefix . 'calender_year');
			    $objBuilder->AddSelectItem($strTableName, 'parrent', $strAliasPrefix . 'parrent');
			    $objBuilder->AddSelectItem($strTableName, 'from', $strAliasPrefix . 'from');
			    $objBuilder->AddSelectItem($strTableName, 'to', $strAliasPrefix . 'to');
			    $objBuilder->AddSelectItem($strTableName, 'description', $strAliasPrefix . 'description');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a DeptYearEvents from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this DeptYearEvents::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return DeptYearEvents
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIddeptYearEvents == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'dept_year_events__';


						// Expanding reverse references: DeptYearEventsAsParrent
						$strAlias = $strAliasPrefix . 'deptyeareventsasparrent__iddept_year_events';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objDeptYearEventsAsParrentArray)
								$objPreviousItem->_objDeptYearEventsAsParrentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objDeptYearEventsAsParrentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objDeptYearEventsAsParrentArray;
								$objChildItem = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasparrent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objDeptYearEventsAsParrentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objDeptYearEventsAsParrentArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'dept_year_events__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the DeptYearEvents object
			$objToReturn = new DeptYearEvents();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIddeptYearEvents = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'title';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTitle = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'event';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intEvent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'department';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDepartment = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'dept_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDeptYear = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'calender_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCalenderYear = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'parrent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intParrent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'from';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttFrom = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttTo = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'description';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strDescription = $objDbRow->GetColumn($strAliasName, 'Blob');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IddeptYearEvents != $objPreviousItem->IddeptYearEvents) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objDeptYearEventsAsParrentArray);
					$cnt = count($objToReturn->_objDeptYearEventsAsParrentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objDeptYearEventsAsParrentArray, $objToReturn->_objDeptYearEventsAsParrentArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'dept_year_events__';

			// Check for EventObject Early Binding
			$strAlias = $strAliasPrefix . 'event__idevent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objEventObject = Event::InstantiateDbRow($objDbRow, $strAliasPrefix . 'event__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DepartmentObject Early Binding
			$strAlias = $strAliasPrefix . 'department__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDepartmentObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'department__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DeptYearObject Early Binding
			$strAlias = $strAliasPrefix . 'dept_year__iddept_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDeptYearObject = DeptYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'dept_year__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CalenderYearObject Early Binding
			$strAlias = $strAliasPrefix . 'calender_year__idcalender_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCalenderYearObject = CalenderYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calender_year__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ParrentObject Early Binding
			$strAlias = $strAliasPrefix . 'parrent__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objParrentObject = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'parrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for DeptYearEventsAsParrent Virtual Binding
			$strAlias = $strAliasPrefix . 'deptyeareventsasparrent__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objDeptYearEventsAsParrentArray)
				$objToReturn->_objDeptYearEventsAsParrentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objDeptYearEventsAsParrentArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objDeptYearEventsAsParrent = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of DeptYearEventses from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return DeptYearEvents[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = DeptYearEvents::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = DeptYearEvents::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single DeptYearEvents object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return DeptYearEvents next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return DeptYearEvents::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single DeptYearEvents object,
		 * by IddeptYearEvents Index(es)
		 * @param integer $intIddeptYearEvents
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents
		*/
		public static function LoadByIddeptYearEvents($intIddeptYearEvents, $objOptionalClauses = null) {
			return DeptYearEvents::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::DeptYearEvents()->IddeptYearEvents, $intIddeptYearEvents)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single DeptYearEvents object,
		 * by Title Index(es)
		 * @param string $strTitle
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents
		*/
		public static function LoadByTitle($strTitle, $objOptionalClauses = null) {
			return DeptYearEvents::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::DeptYearEvents()->Title, $strTitle)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of DeptYearEvents objects,
		 * by Event Index(es)
		 * @param integer $intEvent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public static function LoadArrayByEvent($intEvent, $objOptionalClauses = null) {
			// Call DeptYearEvents::QueryArray to perform the LoadArrayByEvent query
			try {
				return DeptYearEvents::QueryArray(
					QQ::Equal(QQN::DeptYearEvents()->Event, $intEvent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearEventses
		 * by Event Index(es)
		 * @param integer $intEvent
		 * @return int
		*/
		public static function CountByEvent($intEvent) {
			// Call DeptYearEvents::QueryCount to perform the CountByEvent query
			return DeptYearEvents::QueryCount(
				QQ::Equal(QQN::DeptYearEvents()->Event, $intEvent)
			);
		}

		/**
		 * Load an array of DeptYearEvents objects,
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public static function LoadArrayByDepartment($intDepartment, $objOptionalClauses = null) {
			// Call DeptYearEvents::QueryArray to perform the LoadArrayByDepartment query
			try {
				return DeptYearEvents::QueryArray(
					QQ::Equal(QQN::DeptYearEvents()->Department, $intDepartment),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearEventses
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @return int
		*/
		public static function CountByDepartment($intDepartment) {
			// Call DeptYearEvents::QueryCount to perform the CountByDepartment query
			return DeptYearEvents::QueryCount(
				QQ::Equal(QQN::DeptYearEvents()->Department, $intDepartment)
			);
		}

		/**
		 * Load an array of DeptYearEvents objects,
		 * by DeptYear Index(es)
		 * @param integer $intDeptYear
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public static function LoadArrayByDeptYear($intDeptYear, $objOptionalClauses = null) {
			// Call DeptYearEvents::QueryArray to perform the LoadArrayByDeptYear query
			try {
				return DeptYearEvents::QueryArray(
					QQ::Equal(QQN::DeptYearEvents()->DeptYear, $intDeptYear),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearEventses
		 * by DeptYear Index(es)
		 * @param integer $intDeptYear
		 * @return int
		*/
		public static function CountByDeptYear($intDeptYear) {
			// Call DeptYearEvents::QueryCount to perform the CountByDeptYear query
			return DeptYearEvents::QueryCount(
				QQ::Equal(QQN::DeptYearEvents()->DeptYear, $intDeptYear)
			);
		}

		/**
		 * Load an array of DeptYearEvents objects,
		 * by CalenderYear Index(es)
		 * @param integer $intCalenderYear
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public static function LoadArrayByCalenderYear($intCalenderYear, $objOptionalClauses = null) {
			// Call DeptYearEvents::QueryArray to perform the LoadArrayByCalenderYear query
			try {
				return DeptYearEvents::QueryArray(
					QQ::Equal(QQN::DeptYearEvents()->CalenderYear, $intCalenderYear),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearEventses
		 * by CalenderYear Index(es)
		 * @param integer $intCalenderYear
		 * @return int
		*/
		public static function CountByCalenderYear($intCalenderYear) {
			// Call DeptYearEvents::QueryCount to perform the CountByCalenderYear query
			return DeptYearEvents::QueryCount(
				QQ::Equal(QQN::DeptYearEvents()->CalenderYear, $intCalenderYear)
			);
		}

		/**
		 * Load an array of DeptYearEvents objects,
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public static function LoadArrayByParrent($intParrent, $objOptionalClauses = null) {
			// Call DeptYearEvents::QueryArray to perform the LoadArrayByParrent query
			try {
				return DeptYearEvents::QueryArray(
					QQ::Equal(QQN::DeptYearEvents()->Parrent, $intParrent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearEventses
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @return int
		*/
		public static function CountByParrent($intParrent) {
			// Call DeptYearEvents::QueryCount to perform the CountByParrent query
			return DeptYearEvents::QueryCount(
				QQ::Equal(QQN::DeptYearEvents()->Parrent, $intParrent)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this DeptYearEvents
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `dept_year_events` (
							`title`,
							`event`,
							`department`,
							`dept_year`,
							`calender_year`,
							`parrent`,
							`from`,
							`to`,
							`description`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strTitle) . ',
							' . $objDatabase->SqlVariable($this->intEvent) . ',
							' . $objDatabase->SqlVariable($this->intDepartment) . ',
							' . $objDatabase->SqlVariable($this->intDeptYear) . ',
							' . $objDatabase->SqlVariable($this->intCalenderYear) . ',
							' . $objDatabase->SqlVariable($this->intParrent) . ',
							' . $objDatabase->SqlVariable($this->dttFrom) . ',
							' . $objDatabase->SqlVariable($this->dttTo) . ',
							' . $objDatabase->SqlVariable($this->strDescription) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIddeptYearEvents = $objDatabase->InsertId('dept_year_events', 'iddept_year_events');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`dept_year_events`
						SET
							`title` = ' . $objDatabase->SqlVariable($this->strTitle) . ',
							`event` = ' . $objDatabase->SqlVariable($this->intEvent) . ',
							`department` = ' . $objDatabase->SqlVariable($this->intDepartment) . ',
							`dept_year` = ' . $objDatabase->SqlVariable($this->intDeptYear) . ',
							`calender_year` = ' . $objDatabase->SqlVariable($this->intCalenderYear) . ',
							`parrent` = ' . $objDatabase->SqlVariable($this->intParrent) . ',
							`from` = ' . $objDatabase->SqlVariable($this->dttFrom) . ',
							`to` = ' . $objDatabase->SqlVariable($this->dttTo) . ',
							`description` = ' . $objDatabase->SqlVariable($this->strDescription) . '
						WHERE
							`iddept_year_events` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this DeptYearEvents
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this DeptYearEvents with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this DeptYearEvents ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'DeptYearEvents', $this->intIddeptYearEvents);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all DeptYearEventses
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate dept_year_events table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `dept_year_events`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this DeptYearEvents from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved DeptYearEvents object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = DeptYearEvents::Load($this->intIddeptYearEvents);

			// Update $this's local variables to match
			$this->strTitle = $objReloaded->strTitle;
			$this->Event = $objReloaded->Event;
			$this->Department = $objReloaded->Department;
			$this->DeptYear = $objReloaded->DeptYear;
			$this->CalenderYear = $objReloaded->CalenderYear;
			$this->Parrent = $objReloaded->Parrent;
			$this->dttFrom = $objReloaded->dttFrom;
			$this->dttTo = $objReloaded->dttTo;
			$this->strDescription = $objReloaded->strDescription;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IddeptYearEvents':
					/**
					 * Gets the value for intIddeptYearEvents (Read-Only PK)
					 * @return integer
					 */
					return $this->intIddeptYearEvents;

				case 'Title':
					/**
					 * Gets the value for strTitle (Unique)
					 * @return string
					 */
					return $this->strTitle;

				case 'Event':
					/**
					 * Gets the value for intEvent (Not Null)
					 * @return integer
					 */
					return $this->intEvent;

				case 'Department':
					/**
					 * Gets the value for intDepartment 
					 * @return integer
					 */
					return $this->intDepartment;

				case 'DeptYear':
					/**
					 * Gets the value for intDeptYear 
					 * @return integer
					 */
					return $this->intDeptYear;

				case 'CalenderYear':
					/**
					 * Gets the value for intCalenderYear 
					 * @return integer
					 */
					return $this->intCalenderYear;

				case 'Parrent':
					/**
					 * Gets the value for intParrent 
					 * @return integer
					 */
					return $this->intParrent;

				case 'From':
					/**
					 * Gets the value for dttFrom (Not Null)
					 * @return QDateTime
					 */
					return $this->dttFrom;

				case 'To':
					/**
					 * Gets the value for dttTo (Not Null)
					 * @return QDateTime
					 */
					return $this->dttTo;

				case 'Description':
					/**
					 * Gets the value for strDescription 
					 * @return string
					 */
					return $this->strDescription;


				///////////////////
				// Member Objects
				///////////////////
				case 'EventObject':
					/**
					 * Gets the value for the Event object referenced by intEvent (Not Null)
					 * @return Event
					 */
					try {
						if ((!$this->objEventObject) && (!is_null($this->intEvent)))
							$this->objEventObject = Event::Load($this->intEvent);
						return $this->objEventObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DepartmentObject':
					/**
					 * Gets the value for the Role object referenced by intDepartment 
					 * @return Role
					 */
					try {
						if ((!$this->objDepartmentObject) && (!is_null($this->intDepartment)))
							$this->objDepartmentObject = Role::Load($this->intDepartment);
						return $this->objDepartmentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DeptYearObject':
					/**
					 * Gets the value for the DeptYear object referenced by intDeptYear 
					 * @return DeptYear
					 */
					try {
						if ((!$this->objDeptYearObject) && (!is_null($this->intDeptYear)))
							$this->objDeptYearObject = DeptYear::Load($this->intDeptYear);
						return $this->objDeptYearObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CalenderYearObject':
					/**
					 * Gets the value for the CalenderYear object referenced by intCalenderYear 
					 * @return CalenderYear
					 */
					try {
						if ((!$this->objCalenderYearObject) && (!is_null($this->intCalenderYear)))
							$this->objCalenderYearObject = CalenderYear::Load($this->intCalenderYear);
						return $this->objCalenderYearObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ParrentObject':
					/**
					 * Gets the value for the DeptYearEvents object referenced by intParrent 
					 * @return DeptYearEvents
					 */
					try {
						if ((!$this->objParrentObject) && (!is_null($this->intParrent)))
							$this->objParrentObject = DeptYearEvents::Load($this->intParrent);
						return $this->objParrentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_DeptYearEventsAsParrent':
					/**
					 * Gets the value for the private _objDeptYearEventsAsParrent (Read-Only)
					 * if set due to an expansion on the dept_year_events.parrent reverse relationship
					 * @return DeptYearEvents
					 */
					return $this->_objDeptYearEventsAsParrent;

				case '_DeptYearEventsAsParrentArray':
					/**
					 * Gets the value for the private _objDeptYearEventsAsParrentArray (Read-Only)
					 * if set due to an ExpandAsArray on the dept_year_events.parrent reverse relationship
					 * @return DeptYearEvents[]
					 */
					return $this->_objDeptYearEventsAsParrentArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Title':
					/**
					 * Sets the value for strTitle (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTitle = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Event':
					/**
					 * Sets the value for intEvent (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objEventObject = null;
						return ($this->intEvent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Department':
					/**
					 * Sets the value for intDepartment 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDepartmentObject = null;
						return ($this->intDepartment = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DeptYear':
					/**
					 * Sets the value for intDeptYear 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDeptYearObject = null;
						return ($this->intDeptYear = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CalenderYear':
					/**
					 * Sets the value for intCalenderYear 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCalenderYearObject = null;
						return ($this->intCalenderYear = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Parrent':
					/**
					 * Sets the value for intParrent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objParrentObject = null;
						return ($this->intParrent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'From':
					/**
					 * Sets the value for dttFrom (Not Null)
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttFrom = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'To':
					/**
					 * Sets the value for dttTo (Not Null)
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttTo = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Description':
					/**
					 * Sets the value for strDescription 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strDescription = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'EventObject':
					/**
					 * Sets the value for the Event object referenced by intEvent (Not Null)
					 * @param Event $mixValue
					 * @return Event
					 */
					if (is_null($mixValue)) {
						$this->intEvent = null;
						$this->objEventObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Event object
						try {
							$mixValue = QType::Cast($mixValue, 'Event');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Event object
						if (is_null($mixValue->Idevent))
							throw new QCallerException('Unable to set an unsaved EventObject for this DeptYearEvents');

						// Update Local Member Variables
						$this->objEventObject = $mixValue;
						$this->intEvent = $mixValue->Idevent;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DepartmentObject':
					/**
					 * Sets the value for the Role object referenced by intDepartment 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intDepartment = null;
						$this->objDepartmentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved DepartmentObject for this DeptYearEvents');

						// Update Local Member Variables
						$this->objDepartmentObject = $mixValue;
						$this->intDepartment = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DeptYearObject':
					/**
					 * Sets the value for the DeptYear object referenced by intDeptYear 
					 * @param DeptYear $mixValue
					 * @return DeptYear
					 */
					if (is_null($mixValue)) {
						$this->intDeptYear = null;
						$this->objDeptYearObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a DeptYear object
						try {
							$mixValue = QType::Cast($mixValue, 'DeptYear');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED DeptYear object
						if (is_null($mixValue->IddeptYear))
							throw new QCallerException('Unable to set an unsaved DeptYearObject for this DeptYearEvents');

						// Update Local Member Variables
						$this->objDeptYearObject = $mixValue;
						$this->intDeptYear = $mixValue->IddeptYear;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CalenderYearObject':
					/**
					 * Sets the value for the CalenderYear object referenced by intCalenderYear 
					 * @param CalenderYear $mixValue
					 * @return CalenderYear
					 */
					if (is_null($mixValue)) {
						$this->intCalenderYear = null;
						$this->objCalenderYearObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a CalenderYear object
						try {
							$mixValue = QType::Cast($mixValue, 'CalenderYear');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED CalenderYear object
						if (is_null($mixValue->IdcalenderYear))
							throw new QCallerException('Unable to set an unsaved CalenderYearObject for this DeptYearEvents');

						// Update Local Member Variables
						$this->objCalenderYearObject = $mixValue;
						$this->intCalenderYear = $mixValue->IdcalenderYear;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ParrentObject':
					/**
					 * Sets the value for the DeptYearEvents object referenced by intParrent 
					 * @param DeptYearEvents $mixValue
					 * @return DeptYearEvents
					 */
					if (is_null($mixValue)) {
						$this->intParrent = null;
						$this->objParrentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a DeptYearEvents object
						try {
							$mixValue = QType::Cast($mixValue, 'DeptYearEvents');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED DeptYearEvents object
						if (is_null($mixValue->IddeptYearEvents))
							throw new QCallerException('Unable to set an unsaved ParrentObject for this DeptYearEvents');

						// Update Local Member Variables
						$this->objParrentObject = $mixValue;
						$this->intParrent = $mixValue->IddeptYearEvents;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for DeptYearEventsAsParrent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated DeptYearEventsesAsParrent as an array of DeptYearEvents objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public function GetDeptYearEventsAsParrentArray($objOptionalClauses = null) {
			if ((is_null($this->intIddeptYearEvents)))
				return array();

			try {
				return DeptYearEvents::LoadArrayByParrent($this->intIddeptYearEvents, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated DeptYearEventsesAsParrent
		 * @return int
		*/
		public function CountDeptYearEventsesAsParrent() {
			if ((is_null($this->intIddeptYearEvents)))
				return 0;

			return DeptYearEvents::CountByParrent($this->intIddeptYearEvents);
		}

		/**
		 * Associates a DeptYearEventsAsParrent
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function AssociateDeptYearEventsAsParrent(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEventsAsParrent on this unsaved DeptYearEvents.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEventsAsParrent on this DeptYearEvents with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`parrent` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates a DeptYearEventsAsParrent
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function UnassociateDeptYearEventsAsParrent(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsParrent on this unsaved DeptYearEvents.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsParrent on this DeptYearEvents with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`parrent` = null
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates all DeptYearEventsesAsParrent
		 * @return void
		*/
		public function UnassociateAllDeptYearEventsesAsParrent() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsParrent on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`parrent` = null
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes an associated DeptYearEventsAsParrent
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function DeleteAssociatedDeptYearEventsAsParrent(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsParrent on this unsaved DeptYearEvents.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsParrent on this DeptYearEvents with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes all associated DeptYearEventsesAsParrent
		 * @return void
		*/
		public function DeleteAllDeptYearEventsesAsParrent() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsParrent on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "dept_year_events";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[DeptYearEvents::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="DeptYearEvents"><sequence>';
			$strToReturn .= '<element name="IddeptYearEvents" type="xsd:int"/>';
			$strToReturn .= '<element name="Title" type="xsd:string"/>';
			$strToReturn .= '<element name="EventObject" type="xsd1:Event"/>';
			$strToReturn .= '<element name="DepartmentObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="DeptYearObject" type="xsd1:DeptYear"/>';
			$strToReturn .= '<element name="CalenderYearObject" type="xsd1:CalenderYear"/>';
			$strToReturn .= '<element name="ParrentObject" type="xsd1:DeptYearEvents"/>';
			$strToReturn .= '<element name="From" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="To" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Description" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('DeptYearEvents', $strComplexTypeArray)) {
				$strComplexTypeArray['DeptYearEvents'] = DeptYearEvents::GetSoapComplexTypeXml();
				Event::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				DeptYear::AlterSoapComplexTypeArray($strComplexTypeArray);
				CalenderYear::AlterSoapComplexTypeArray($strComplexTypeArray);
				DeptYearEvents::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, DeptYearEvents::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new DeptYearEvents();
			if (property_exists($objSoapObject, 'IddeptYearEvents'))
				$objToReturn->intIddeptYearEvents = $objSoapObject->IddeptYearEvents;
			if (property_exists($objSoapObject, 'Title'))
				$objToReturn->strTitle = $objSoapObject->Title;
			if ((property_exists($objSoapObject, 'EventObject')) &&
				($objSoapObject->EventObject))
				$objToReturn->EventObject = Event::GetObjectFromSoapObject($objSoapObject->EventObject);
			if ((property_exists($objSoapObject, 'DepartmentObject')) &&
				($objSoapObject->DepartmentObject))
				$objToReturn->DepartmentObject = Role::GetObjectFromSoapObject($objSoapObject->DepartmentObject);
			if ((property_exists($objSoapObject, 'DeptYearObject')) &&
				($objSoapObject->DeptYearObject))
				$objToReturn->DeptYearObject = DeptYear::GetObjectFromSoapObject($objSoapObject->DeptYearObject);
			if ((property_exists($objSoapObject, 'CalenderYearObject')) &&
				($objSoapObject->CalenderYearObject))
				$objToReturn->CalenderYearObject = CalenderYear::GetObjectFromSoapObject($objSoapObject->CalenderYearObject);
			if ((property_exists($objSoapObject, 'ParrentObject')) &&
				($objSoapObject->ParrentObject))
				$objToReturn->ParrentObject = DeptYearEvents::GetObjectFromSoapObject($objSoapObject->ParrentObject);
			if (property_exists($objSoapObject, 'From'))
				$objToReturn->dttFrom = new QDateTime($objSoapObject->From);
			if (property_exists($objSoapObject, 'To'))
				$objToReturn->dttTo = new QDateTime($objSoapObject->To);
			if (property_exists($objSoapObject, 'Description'))
				$objToReturn->strDescription = $objSoapObject->Description;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, DeptYearEvents::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objEventObject)
				$objObject->objEventObject = Event::GetSoapObjectFromObject($objObject->objEventObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intEvent = null;
			if ($objObject->objDepartmentObject)
				$objObject->objDepartmentObject = Role::GetSoapObjectFromObject($objObject->objDepartmentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDepartment = null;
			if ($objObject->objDeptYearObject)
				$objObject->objDeptYearObject = DeptYear::GetSoapObjectFromObject($objObject->objDeptYearObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDeptYear = null;
			if ($objObject->objCalenderYearObject)
				$objObject->objCalenderYearObject = CalenderYear::GetSoapObjectFromObject($objObject->objCalenderYearObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCalenderYear = null;
			if ($objObject->objParrentObject)
				$objObject->objParrentObject = DeptYearEvents::GetSoapObjectFromObject($objObject->objParrentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intParrent = null;
			if ($objObject->dttFrom)
				$objObject->dttFrom = $objObject->dttFrom->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttTo)
				$objObject->dttTo = $objObject->dttTo->qFormat(QDateTime::FormatSoap);
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IddeptYearEvents'] = $this->intIddeptYearEvents;
			$iArray['Title'] = $this->strTitle;
			$iArray['Event'] = $this->intEvent;
			$iArray['Department'] = $this->intDepartment;
			$iArray['DeptYear'] = $this->intDeptYear;
			$iArray['CalenderYear'] = $this->intCalenderYear;
			$iArray['Parrent'] = $this->intParrent;
			$iArray['From'] = $this->dttFrom;
			$iArray['To'] = $this->dttTo;
			$iArray['Description'] = $this->strDescription;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIddeptYearEvents ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IddeptYearEvents
     * @property-read QQNode $Title
     * @property-read QQNode $Event
     * @property-read QQNodeEvent $EventObject
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $DeptYear
     * @property-read QQNodeDeptYear $DeptYearObject
     * @property-read QQNode $CalenderYear
     * @property-read QQNodeCalenderYear $CalenderYearObject
     * @property-read QQNode $Parrent
     * @property-read QQNodeDeptYearEvents $ParrentObject
     * @property-read QQNode $From
     * @property-read QQNode $To
     * @property-read QQNode $Description
     *
     *
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEventsAsParrent

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeDeptYearEvents extends QQNode {
		protected $strTableName = 'dept_year_events';
		protected $strPrimaryKey = 'iddept_year_events';
		protected $strClassName = 'DeptYearEvents';
		public function __get($strName) {
			switch ($strName) {
				case 'IddeptYearEvents':
					return new QQNode('iddept_year_events', 'IddeptYearEvents', 'Integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'VarChar', $this);
				case 'Event':
					return new QQNode('event', 'Event', 'Integer', $this);
				case 'EventObject':
					return new QQNodeEvent('event', 'EventObject', 'Integer', $this);
				case 'Department':
					return new QQNode('department', 'Department', 'Integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'Integer', $this);
				case 'DeptYear':
					return new QQNode('dept_year', 'DeptYear', 'Integer', $this);
				case 'DeptYearObject':
					return new QQNodeDeptYear('dept_year', 'DeptYearObject', 'Integer', $this);
				case 'CalenderYear':
					return new QQNode('calender_year', 'CalenderYear', 'Integer', $this);
				case 'CalenderYearObject':
					return new QQNodeCalenderYear('calender_year', 'CalenderYearObject', 'Integer', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'Integer', $this);
				case 'ParrentObject':
					return new QQNodeDeptYearEvents('parrent', 'ParrentObject', 'Integer', $this);
				case 'From':
					return new QQNode('from', 'From', 'DateTime', $this);
				case 'To':
					return new QQNode('to', 'To', 'DateTime', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'Blob', $this);
				case 'DeptYearEventsAsParrent':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyeareventsasparrent', 'reverse_reference', 'parrent');

				case '_PrimaryKeyNode':
					return new QQNode('iddept_year_events', 'IddeptYearEvents', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IddeptYearEvents
     * @property-read QQNode $Title
     * @property-read QQNode $Event
     * @property-read QQNodeEvent $EventObject
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $DeptYear
     * @property-read QQNodeDeptYear $DeptYearObject
     * @property-read QQNode $CalenderYear
     * @property-read QQNodeCalenderYear $CalenderYearObject
     * @property-read QQNode $Parrent
     * @property-read QQNodeDeptYearEvents $ParrentObject
     * @property-read QQNode $From
     * @property-read QQNode $To
     * @property-read QQNode $Description
     *
     *
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEventsAsParrent

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeDeptYearEvents extends QQReverseReferenceNode {
		protected $strTableName = 'dept_year_events';
		protected $strPrimaryKey = 'iddept_year_events';
		protected $strClassName = 'DeptYearEvents';
		public function __get($strName) {
			switch ($strName) {
				case 'IddeptYearEvents':
					return new QQNode('iddept_year_events', 'IddeptYearEvents', 'integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'string', $this);
				case 'Event':
					return new QQNode('event', 'Event', 'integer', $this);
				case 'EventObject':
					return new QQNodeEvent('event', 'EventObject', 'integer', $this);
				case 'Department':
					return new QQNode('department', 'Department', 'integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'integer', $this);
				case 'DeptYear':
					return new QQNode('dept_year', 'DeptYear', 'integer', $this);
				case 'DeptYearObject':
					return new QQNodeDeptYear('dept_year', 'DeptYearObject', 'integer', $this);
				case 'CalenderYear':
					return new QQNode('calender_year', 'CalenderYear', 'integer', $this);
				case 'CalenderYearObject':
					return new QQNodeCalenderYear('calender_year', 'CalenderYearObject', 'integer', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'integer', $this);
				case 'ParrentObject':
					return new QQNodeDeptYearEvents('parrent', 'ParrentObject', 'integer', $this);
				case 'From':
					return new QQNode('from', 'From', 'QDateTime', $this);
				case 'To':
					return new QQNode('to', 'To', 'QDateTime', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'string', $this);
				case 'DeptYearEventsAsParrent':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyeareventsasparrent', 'reverse_reference', 'parrent');

				case '_PrimaryKeyNode':
					return new QQNode('iddept_year_events', 'IddeptYearEvents', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
