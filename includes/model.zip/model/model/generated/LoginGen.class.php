<?php
	/**
	 * The abstract LoginGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Login subclass which
	 * extends this LoginGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Login class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property integer $Idlogin the value for intIdlogin (PK)
	 * @property string $Username the value for strUsername (Unique)
	 * @property string $Password the value for strPassword 
	 * @property boolean $IsEnabled the value for blnIsEnabled (Not Null)
	 * @property Ledger $IdloginObject the value for the Ledger object referenced by intIdlogin (PK)
	 * @property-read AppApproval $_AppApprovalAsDecisionBy the value for the private _objAppApprovalAsDecisionBy (Read-Only) if set due to an expansion on the app_approval.decision_by reverse relationship
	 * @property-read AppApproval[] $_AppApprovalAsDecisionByArray the value for the private _objAppApprovalAsDecisionByArray (Read-Only) if set due to an ExpandAsArray on the app_approval.decision_by reverse relationship
	 * @property-read Application $_ApplicationAsDataEntryBy the value for the private _objApplicationAsDataEntryBy (Read-Only) if set due to an expansion on the application.data_entry_by reverse relationship
	 * @property-read Application[] $_ApplicationAsDataEntryByArray the value for the private _objApplicationAsDataEntryByArray (Read-Only) if set due to an ExpandAsArray on the application.data_entry_by reverse relationship
	 * @property-read Application $_ApplicationAsCertificateIssueBy the value for the private _objApplicationAsCertificateIssueBy (Read-Only) if set due to an expansion on the application.certificate_issue_by reverse relationship
	 * @property-read Application[] $_ApplicationAsCertificateIssueByArray the value for the private _objApplicationAsCertificateIssueByArray (Read-Only) if set due to an ExpandAsArray on the application.certificate_issue_by reverse relationship
	 * @property-read Log $_LogAsDataBy the value for the private _objLogAsDataBy (Read-Only) if set due to an expansion on the log.data_by reverse relationship
	 * @property-read Log[] $_LogAsDataByArray the value for the private _objLogAsDataByArray (Read-Only) if set due to an ExpandAsArray on the log.data_by reverse relationship
	 * @property-read LoginHasRole $_LoginHasRoleAsId the value for the private _objLoginHasRoleAsId (Read-Only) if set due to an expansion on the login_has_role.login_idlogin reverse relationship
	 * @property-read LoginHasRole[] $_LoginHasRoleAsIdArray the value for the private _objLoginHasRoleAsIdArray (Read-Only) if set due to an ExpandAsArray on the login_has_role.login_idlogin reverse relationship
	 * @property-read Note $_NoteAsDataby the value for the private _objNoteAsDataby (Read-Only) if set due to an expansion on the note.databy reverse relationship
	 * @property-read Note[] $_NoteAsDatabyArray the value for the private _objNoteAsDatabyArray (Read-Only) if set due to an ExpandAsArray on the note.databy reverse relationship
	 * @property-read SignPatch $_SignPatch the value for the private _objSignPatch (Read-Only) if set due to an expansion on the sign_patch.login reverse relationship
	 * @property-read SignPatch[] $_SignPatchArray the value for the private _objSignPatchArray (Read-Only) if set due to an ExpandAsArray on the sign_patch.login reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class LoginGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK column login.idlogin
		 * @var integer intIdlogin
		 */
		protected $intIdlogin;
		const IdloginDefault = null;


		/**
		 * Protected internal member variable that stores the original version of the PK column value (if restored)
		 * Used by Save() to update a PK column during UPDATE
		 * @var integer __intIdlogin;
		 */
		protected $__intIdlogin;

		/**
		 * Protected member variable that maps to the database column login.username
		 * @var string strUsername
		 */
		protected $strUsername;
		const UsernameMaxLength = 20;
		const UsernameDefault = null;


		/**
		 * Protected member variable that maps to the database column login.password
		 * @var string strPassword
		 */
		protected $strPassword;
		const PasswordMaxLength = 20;
		const PasswordDefault = null;


		/**
		 * Protected member variable that maps to the database column login.is_enabled
		 * @var boolean blnIsEnabled
		 */
		protected $blnIsEnabled;
		const IsEnabledDefault = null;


		/**
		 * Private member variable that stores a reference to a single AppApprovalAsDecisionBy object
		 * (of type AppApproval), if this Login object was restored with
		 * an expansion on the app_approval association table.
		 * @var AppApproval _objAppApprovalAsDecisionBy;
		 */
		private $_objAppApprovalAsDecisionBy;

		/**
		 * Private member variable that stores a reference to an array of AppApprovalAsDecisionBy objects
		 * (of type AppApproval[]), if this Login object was restored with
		 * an ExpandAsArray on the app_approval association table.
		 * @var AppApproval[] _objAppApprovalAsDecisionByArray;
		 */
		private $_objAppApprovalAsDecisionByArray = null;

		/**
		 * Private member variable that stores a reference to a single ApplicationAsDataEntryBy object
		 * (of type Application), if this Login object was restored with
		 * an expansion on the application association table.
		 * @var Application _objApplicationAsDataEntryBy;
		 */
		private $_objApplicationAsDataEntryBy;

		/**
		 * Private member variable that stores a reference to an array of ApplicationAsDataEntryBy objects
		 * (of type Application[]), if this Login object was restored with
		 * an ExpandAsArray on the application association table.
		 * @var Application[] _objApplicationAsDataEntryByArray;
		 */
		private $_objApplicationAsDataEntryByArray = null;

		/**
		 * Private member variable that stores a reference to a single ApplicationAsCertificateIssueBy object
		 * (of type Application), if this Login object was restored with
		 * an expansion on the application association table.
		 * @var Application _objApplicationAsCertificateIssueBy;
		 */
		private $_objApplicationAsCertificateIssueBy;

		/**
		 * Private member variable that stores a reference to an array of ApplicationAsCertificateIssueBy objects
		 * (of type Application[]), if this Login object was restored with
		 * an ExpandAsArray on the application association table.
		 * @var Application[] _objApplicationAsCertificateIssueByArray;
		 */
		private $_objApplicationAsCertificateIssueByArray = null;

		/**
		 * Private member variable that stores a reference to a single LogAsDataBy object
		 * (of type Log), if this Login object was restored with
		 * an expansion on the log association table.
		 * @var Log _objLogAsDataBy;
		 */
		private $_objLogAsDataBy;

		/**
		 * Private member variable that stores a reference to an array of LogAsDataBy objects
		 * (of type Log[]), if this Login object was restored with
		 * an ExpandAsArray on the log association table.
		 * @var Log[] _objLogAsDataByArray;
		 */
		private $_objLogAsDataByArray = null;

		/**
		 * Private member variable that stores a reference to a single LoginHasRoleAsId object
		 * (of type LoginHasRole), if this Login object was restored with
		 * an expansion on the login_has_role association table.
		 * @var LoginHasRole _objLoginHasRoleAsId;
		 */
		private $_objLoginHasRoleAsId;

		/**
		 * Private member variable that stores a reference to an array of LoginHasRoleAsId objects
		 * (of type LoginHasRole[]), if this Login object was restored with
		 * an ExpandAsArray on the login_has_role association table.
		 * @var LoginHasRole[] _objLoginHasRoleAsIdArray;
		 */
		private $_objLoginHasRoleAsIdArray = null;

		/**
		 * Private member variable that stores a reference to a single NoteAsDataby object
		 * (of type Note), if this Login object was restored with
		 * an expansion on the note association table.
		 * @var Note _objNoteAsDataby;
		 */
		private $_objNoteAsDataby;

		/**
		 * Private member variable that stores a reference to an array of NoteAsDataby objects
		 * (of type Note[]), if this Login object was restored with
		 * an ExpandAsArray on the note association table.
		 * @var Note[] _objNoteAsDatabyArray;
		 */
		private $_objNoteAsDatabyArray = null;

		/**
		 * Private member variable that stores a reference to a single SignPatch object
		 * (of type SignPatch), if this Login object was restored with
		 * an expansion on the sign_patch association table.
		 * @var SignPatch _objSignPatch;
		 */
		private $_objSignPatch;

		/**
		 * Private member variable that stores a reference to an array of SignPatch objects
		 * (of type SignPatch[]), if this Login object was restored with
		 * an ExpandAsArray on the sign_patch association table.
		 * @var SignPatch[] _objSignPatchArray;
		 */
		private $_objSignPatchArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column login.idlogin.
		 *
		 * NOTE: Always use the IdloginObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objIdloginObject
		 */
		protected $objIdloginObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdlogin = Login::IdloginDefault;
			$this->strUsername = Login::UsernameDefault;
			$this->strPassword = Login::PasswordDefault;
			$this->blnIsEnabled = Login::IsEnabledDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Login from PK Info
		 * @param integer $intIdlogin
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Login
		 */
		public static function Load($intIdlogin, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Login', $intIdlogin);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Login::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Login()->Idlogin, $intIdlogin)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Logins
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Login[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Login::QueryArray to perform the LoadAll query
			try {
				return Login::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Logins
		 * @return int
		 */
		public static function CountAll() {
			// Call Login::QueryCount to perform the CountAll query
			return Login::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Create/Build out the QueryBuilder object with Login-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'login');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Login::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('login');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Login object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Login the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Login::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Login object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Login::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Login::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Login objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Login[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Login::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Login::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Login::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Login objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Login::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			$strQuery = Login::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/login', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Login::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Login
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'login';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idlogin', $strAliasPrefix . 'idlogin');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idlogin', $strAliasPrefix . 'idlogin');
			    $objBuilder->AddSelectItem($strTableName, 'username', $strAliasPrefix . 'username');
			    $objBuilder->AddSelectItem($strTableName, 'password', $strAliasPrefix . 'password');
			    $objBuilder->AddSelectItem($strTableName, 'is_enabled', $strAliasPrefix . 'is_enabled');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Login from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Login::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Login
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdlogin == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'login__';


						// Expanding reverse references: AppApprovalAsDecisionBy
						$strAlias = $strAliasPrefix . 'appapprovalasdecisionby__idapp_approval';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objAppApprovalAsDecisionByArray)
								$objPreviousItem->_objAppApprovalAsDecisionByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objAppApprovalAsDecisionByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objAppApprovalAsDecisionByArray;
								$objChildItem = AppApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appapprovalasdecisionby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objAppApprovalAsDecisionByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objAppApprovalAsDecisionByArray[] = AppApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appapprovalasdecisionby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ApplicationAsDataEntryBy
						$strAlias = $strAliasPrefix . 'applicationasdataentryby__idapplication';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objApplicationAsDataEntryByArray)
								$objPreviousItem->_objApplicationAsDataEntryByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objApplicationAsDataEntryByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objApplicationAsDataEntryByArray;
								$objChildItem = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationasdataentryby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objApplicationAsDataEntryByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objApplicationAsDataEntryByArray[] = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationasdataentryby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ApplicationAsCertificateIssueBy
						$strAlias = $strAliasPrefix . 'applicationascertificateissueby__idapplication';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objApplicationAsCertificateIssueByArray)
								$objPreviousItem->_objApplicationAsCertificateIssueByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objApplicationAsCertificateIssueByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objApplicationAsCertificateIssueByArray;
								$objChildItem = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationascertificateissueby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objApplicationAsCertificateIssueByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objApplicationAsCertificateIssueByArray[] = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationascertificateissueby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: LogAsDataBy
						$strAlias = $strAliasPrefix . 'logasdataby__idlog';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objLogAsDataByArray)
								$objPreviousItem->_objLogAsDataByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objLogAsDataByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objLogAsDataByArray;
								$objChildItem = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logasdataby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objLogAsDataByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objLogAsDataByArray[] = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: LoginHasRoleAsId
						$strAlias = $strAliasPrefix . 'loginhasroleasid__login_idlogin';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objLoginHasRoleAsIdArray)
								$objPreviousItem->_objLoginHasRoleAsIdArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objLoginHasRoleAsIdArray)) {
								$objPreviousChildItems = $objPreviousItem->_objLoginHasRoleAsIdArray;
								$objChildItem = LoginHasRole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'loginhasroleasid__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objLoginHasRoleAsIdArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objLoginHasRoleAsIdArray[] = LoginHasRole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'loginhasroleasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: NoteAsDataby
						$strAlias = $strAliasPrefix . 'noteasdataby__idnote';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objNoteAsDatabyArray)
								$objPreviousItem->_objNoteAsDatabyArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objNoteAsDatabyArray)) {
								$objPreviousChildItems = $objPreviousItem->_objNoteAsDatabyArray;
								$objChildItem = Note::InstantiateDbRow($objDbRow, $strAliasPrefix . 'noteasdataby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objNoteAsDatabyArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objNoteAsDatabyArray[] = Note::InstantiateDbRow($objDbRow, $strAliasPrefix . 'noteasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: SignPatch
						$strAlias = $strAliasPrefix . 'signpatch__idsign_patch';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objSignPatchArray)
								$objPreviousItem->_objSignPatchArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objSignPatchArray)) {
								$objPreviousChildItems = $objPreviousItem->_objSignPatchArray;
								$objChildItem = SignPatch::InstantiateDbRow($objDbRow, $strAliasPrefix . 'signpatch__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objSignPatchArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objSignPatchArray[] = SignPatch::InstantiateDbRow($objDbRow, $strAliasPrefix . 'signpatch__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'login__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Login object
			$objToReturn = new Login();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdlogin = $objDbRow->GetColumn($strAliasName, 'Integer');
			$objToReturn->__intIdlogin = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'username';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strUsername = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'password';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strPassword = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'is_enabled';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnIsEnabled = $objDbRow->GetColumn($strAliasName, 'Bit');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idlogin != $objPreviousItem->Idlogin) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objAppApprovalAsDecisionByArray);
					$cnt = count($objToReturn->_objAppApprovalAsDecisionByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objAppApprovalAsDecisionByArray, $objToReturn->_objAppApprovalAsDecisionByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objApplicationAsDataEntryByArray);
					$cnt = count($objToReturn->_objApplicationAsDataEntryByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objApplicationAsDataEntryByArray, $objToReturn->_objApplicationAsDataEntryByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objApplicationAsCertificateIssueByArray);
					$cnt = count($objToReturn->_objApplicationAsCertificateIssueByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objApplicationAsCertificateIssueByArray, $objToReturn->_objApplicationAsCertificateIssueByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objLogAsDataByArray);
					$cnt = count($objToReturn->_objLogAsDataByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objLogAsDataByArray, $objToReturn->_objLogAsDataByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objLoginHasRoleAsIdArray);
					$cnt = count($objToReturn->_objLoginHasRoleAsIdArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objLoginHasRoleAsIdArray, $objToReturn->_objLoginHasRoleAsIdArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objNoteAsDatabyArray);
					$cnt = count($objToReturn->_objNoteAsDatabyArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objNoteAsDatabyArray, $objToReturn->_objNoteAsDatabyArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objSignPatchArray);
					$cnt = count($objToReturn->_objSignPatchArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objSignPatchArray, $objToReturn->_objSignPatchArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'login__';

			// Check for IdloginObject Early Binding
			$strAlias = $strAliasPrefix . 'idlogin__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objIdloginObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'idlogin__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for AppApprovalAsDecisionBy Virtual Binding
			$strAlias = $strAliasPrefix . 'appapprovalasdecisionby__idapp_approval';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objAppApprovalAsDecisionByArray)
				$objToReturn->_objAppApprovalAsDecisionByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objAppApprovalAsDecisionByArray[] = AppApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appapprovalasdecisionby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objAppApprovalAsDecisionBy = AppApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appapprovalasdecisionby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ApplicationAsDataEntryBy Virtual Binding
			$strAlias = $strAliasPrefix . 'applicationasdataentryby__idapplication';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objApplicationAsDataEntryByArray)
				$objToReturn->_objApplicationAsDataEntryByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objApplicationAsDataEntryByArray[] = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationasdataentryby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objApplicationAsDataEntryBy = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationasdataentryby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ApplicationAsCertificateIssueBy Virtual Binding
			$strAlias = $strAliasPrefix . 'applicationascertificateissueby__idapplication';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objApplicationAsCertificateIssueByArray)
				$objToReturn->_objApplicationAsCertificateIssueByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objApplicationAsCertificateIssueByArray[] = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationascertificateissueby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objApplicationAsCertificateIssueBy = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationascertificateissueby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for LogAsDataBy Virtual Binding
			$strAlias = $strAliasPrefix . 'logasdataby__idlog';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objLogAsDataByArray)
				$objToReturn->_objLogAsDataByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objLogAsDataByArray[] = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objLogAsDataBy = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for LoginHasRoleAsId Virtual Binding
			$strAlias = $strAliasPrefix . 'loginhasroleasid__login_idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objLoginHasRoleAsIdArray)
				$objToReturn->_objLoginHasRoleAsIdArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objLoginHasRoleAsIdArray[] = LoginHasRole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'loginhasroleasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objLoginHasRoleAsId = LoginHasRole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'loginhasroleasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for NoteAsDataby Virtual Binding
			$strAlias = $strAliasPrefix . 'noteasdataby__idnote';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objNoteAsDatabyArray)
				$objToReturn->_objNoteAsDatabyArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objNoteAsDatabyArray[] = Note::InstantiateDbRow($objDbRow, $strAliasPrefix . 'noteasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objNoteAsDataby = Note::InstantiateDbRow($objDbRow, $strAliasPrefix . 'noteasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for SignPatch Virtual Binding
			$strAlias = $strAliasPrefix . 'signpatch__idsign_patch';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objSignPatchArray)
				$objToReturn->_objSignPatchArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objSignPatchArray[] = SignPatch::InstantiateDbRow($objDbRow, $strAliasPrefix . 'signpatch__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objSignPatch = SignPatch::InstantiateDbRow($objDbRow, $strAliasPrefix . 'signpatch__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Logins from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Login[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Login::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Login::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Login object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Login next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Login::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Login object,
		 * by Idlogin Index(es)
		 * @param integer $intIdlogin
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Login
		*/
		public static function LoadByIdlogin($intIdlogin, $objOptionalClauses = null) {
			return Login::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Login()->Idlogin, $intIdlogin)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single Login object,
		 * by Username Index(es)
		 * @param string $strUsername
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Login
		*/
		public static function LoadByUsername($strUsername, $objOptionalClauses = null) {
			return Login::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Login()->Username, $strUsername)
				),
				$objOptionalClauses
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Login
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return void
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `login` (
							`idlogin`,
							`username`,
							`password`,
							`is_enabled`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intIdlogin) . ',
							' . $objDatabase->SqlVariable($this->strUsername) . ',
							' . $objDatabase->SqlVariable($this->strPassword) . ',
							' . $objDatabase->SqlVariable($this->blnIsEnabled) . '
						)
					');


				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`login`
						SET
							`idlogin` = ' . $objDatabase->SqlVariable($this->intIdlogin) . ',
							`username` = ' . $objDatabase->SqlVariable($this->strUsername) . ',
							`password` = ' . $objDatabase->SqlVariable($this->strPassword) . ',
							`is_enabled` = ' . $objDatabase->SqlVariable($this->blnIsEnabled) . '
						WHERE
							`idlogin` = ' . $objDatabase->SqlVariable($this->__intIdlogin) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;
			$this->__intIdlogin = $this->intIdlogin;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Login
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Login with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`login`
				WHERE
					`idlogin` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Login ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Login', $this->intIdlogin);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Logins
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`login`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate login table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `login`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Login from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Login object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Login::Load($this->intIdlogin);

			// Update $this's local variables to match
			$this->Idlogin = $objReloaded->Idlogin;
			$this->__intIdlogin = $this->intIdlogin;
			$this->strUsername = $objReloaded->strUsername;
			$this->strPassword = $objReloaded->strPassword;
			$this->blnIsEnabled = $objReloaded->blnIsEnabled;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idlogin':
					/**
					 * Gets the value for intIdlogin (PK)
					 * @return integer
					 */
					return $this->intIdlogin;

				case 'Username':
					/**
					 * Gets the value for strUsername (Unique)
					 * @return string
					 */
					return $this->strUsername;

				case 'Password':
					/**
					 * Gets the value for strPassword 
					 * @return string
					 */
					return $this->strPassword;

				case 'IsEnabled':
					/**
					 * Gets the value for blnIsEnabled (Not Null)
					 * @return boolean
					 */
					return $this->blnIsEnabled;


				///////////////////
				// Member Objects
				///////////////////
				case 'IdloginObject':
					/**
					 * Gets the value for the Ledger object referenced by intIdlogin (PK)
					 * @return Ledger
					 */
					try {
						if ((!$this->objIdloginObject) && (!is_null($this->intIdlogin)))
							$this->objIdloginObject = Ledger::Load($this->intIdlogin);
						return $this->objIdloginObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_AppApprovalAsDecisionBy':
					/**
					 * Gets the value for the private _objAppApprovalAsDecisionBy (Read-Only)
					 * if set due to an expansion on the app_approval.decision_by reverse relationship
					 * @return AppApproval
					 */
					return $this->_objAppApprovalAsDecisionBy;

				case '_AppApprovalAsDecisionByArray':
					/**
					 * Gets the value for the private _objAppApprovalAsDecisionByArray (Read-Only)
					 * if set due to an ExpandAsArray on the app_approval.decision_by reverse relationship
					 * @return AppApproval[]
					 */
					return $this->_objAppApprovalAsDecisionByArray;

				case '_ApplicationAsDataEntryBy':
					/**
					 * Gets the value for the private _objApplicationAsDataEntryBy (Read-Only)
					 * if set due to an expansion on the application.data_entry_by reverse relationship
					 * @return Application
					 */
					return $this->_objApplicationAsDataEntryBy;

				case '_ApplicationAsDataEntryByArray':
					/**
					 * Gets the value for the private _objApplicationAsDataEntryByArray (Read-Only)
					 * if set due to an ExpandAsArray on the application.data_entry_by reverse relationship
					 * @return Application[]
					 */
					return $this->_objApplicationAsDataEntryByArray;

				case '_ApplicationAsCertificateIssueBy':
					/**
					 * Gets the value for the private _objApplicationAsCertificateIssueBy (Read-Only)
					 * if set due to an expansion on the application.certificate_issue_by reverse relationship
					 * @return Application
					 */
					return $this->_objApplicationAsCertificateIssueBy;

				case '_ApplicationAsCertificateIssueByArray':
					/**
					 * Gets the value for the private _objApplicationAsCertificateIssueByArray (Read-Only)
					 * if set due to an ExpandAsArray on the application.certificate_issue_by reverse relationship
					 * @return Application[]
					 */
					return $this->_objApplicationAsCertificateIssueByArray;

				case '_LogAsDataBy':
					/**
					 * Gets the value for the private _objLogAsDataBy (Read-Only)
					 * if set due to an expansion on the log.data_by reverse relationship
					 * @return Log
					 */
					return $this->_objLogAsDataBy;

				case '_LogAsDataByArray':
					/**
					 * Gets the value for the private _objLogAsDataByArray (Read-Only)
					 * if set due to an ExpandAsArray on the log.data_by reverse relationship
					 * @return Log[]
					 */
					return $this->_objLogAsDataByArray;

				case '_LoginHasRoleAsId':
					/**
					 * Gets the value for the private _objLoginHasRoleAsId (Read-Only)
					 * if set due to an expansion on the login_has_role.login_idlogin reverse relationship
					 * @return LoginHasRole
					 */
					return $this->_objLoginHasRoleAsId;

				case '_LoginHasRoleAsIdArray':
					/**
					 * Gets the value for the private _objLoginHasRoleAsIdArray (Read-Only)
					 * if set due to an ExpandAsArray on the login_has_role.login_idlogin reverse relationship
					 * @return LoginHasRole[]
					 */
					return $this->_objLoginHasRoleAsIdArray;

				case '_NoteAsDataby':
					/**
					 * Gets the value for the private _objNoteAsDataby (Read-Only)
					 * if set due to an expansion on the note.databy reverse relationship
					 * @return Note
					 */
					return $this->_objNoteAsDataby;

				case '_NoteAsDatabyArray':
					/**
					 * Gets the value for the private _objNoteAsDatabyArray (Read-Only)
					 * if set due to an ExpandAsArray on the note.databy reverse relationship
					 * @return Note[]
					 */
					return $this->_objNoteAsDatabyArray;

				case '_SignPatch':
					/**
					 * Gets the value for the private _objSignPatch (Read-Only)
					 * if set due to an expansion on the sign_patch.login reverse relationship
					 * @return SignPatch
					 */
					return $this->_objSignPatch;

				case '_SignPatchArray':
					/**
					 * Gets the value for the private _objSignPatchArray (Read-Only)
					 * if set due to an ExpandAsArray on the sign_patch.login reverse relationship
					 * @return SignPatch[]
					 */
					return $this->_objSignPatchArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idlogin':
					/**
					 * Sets the value for intIdlogin (PK)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objIdloginObject = null;
						return ($this->intIdlogin = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Username':
					/**
					 * Sets the value for strUsername (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strUsername = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Password':
					/**
					 * Sets the value for strPassword 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strPassword = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'IsEnabled':
					/**
					 * Sets the value for blnIsEnabled (Not Null)
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnIsEnabled = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'IdloginObject':
					/**
					 * Sets the value for the Ledger object referenced by intIdlogin (PK)
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intIdlogin = null;
						$this->objIdloginObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved IdloginObject for this Login');

						// Update Local Member Variables
						$this->objIdloginObject = $mixValue;
						$this->intIdlogin = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for AppApprovalAsDecisionBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated AppApprovalsAsDecisionBy as an array of AppApproval objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppApproval[]
		*/
		public function GetAppApprovalAsDecisionByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return AppApproval::LoadArrayByDecisionBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated AppApprovalsAsDecisionBy
		 * @return int
		*/
		public function CountAppApprovalsAsDecisionBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return AppApproval::CountByDecisionBy($this->intIdlogin);
		}

		/**
		 * Associates a AppApprovalAsDecisionBy
		 * @param AppApproval $objAppApproval
		 * @return void
		*/
		public function AssociateAppApprovalAsDecisionBy(AppApproval $objAppApproval) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppApprovalAsDecisionBy on this unsaved Login.');
			if ((is_null($objAppApproval->IdappApproval)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppApprovalAsDecisionBy on this Login with an unsaved AppApproval.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`app_approval`
				SET
					`decision_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idapp_approval` = ' . $objDatabase->SqlVariable($objAppApproval->IdappApproval) . '
			');
		}

		/**
		 * Unassociates a AppApprovalAsDecisionBy
		 * @param AppApproval $objAppApproval
		 * @return void
		*/
		public function UnassociateAppApprovalAsDecisionBy(AppApproval $objAppApproval) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsDecisionBy on this unsaved Login.');
			if ((is_null($objAppApproval->IdappApproval)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsDecisionBy on this Login with an unsaved AppApproval.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`app_approval`
				SET
					`decision_by` = null
				WHERE
					`idapp_approval` = ' . $objDatabase->SqlVariable($objAppApproval->IdappApproval) . ' AND
					`decision_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all AppApprovalsAsDecisionBy
		 * @return void
		*/
		public function UnassociateAllAppApprovalsAsDecisionBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsDecisionBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`app_approval`
				SET
					`decision_by` = null
				WHERE
					`decision_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated AppApprovalAsDecisionBy
		 * @param AppApproval $objAppApproval
		 * @return void
		*/
		public function DeleteAssociatedAppApprovalAsDecisionBy(AppApproval $objAppApproval) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsDecisionBy on this unsaved Login.');
			if ((is_null($objAppApproval->IdappApproval)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsDecisionBy on this Login with an unsaved AppApproval.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`app_approval`
				WHERE
					`idapp_approval` = ' . $objDatabase->SqlVariable($objAppApproval->IdappApproval) . ' AND
					`decision_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated AppApprovalsAsDecisionBy
		 * @return void
		*/
		public function DeleteAllAppApprovalsAsDecisionBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsDecisionBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`app_approval`
				WHERE
					`decision_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for ApplicationAsDataEntryBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ApplicationsAsDataEntryBy as an array of Application objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Application[]
		*/
		public function GetApplicationAsDataEntryByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Application::LoadArrayByDataEntryBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ApplicationsAsDataEntryBy
		 * @return int
		*/
		public function CountApplicationsAsDataEntryBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Application::CountByDataEntryBy($this->intIdlogin);
		}

		/**
		 * Associates a ApplicationAsDataEntryBy
		 * @param Application $objApplication
		 * @return void
		*/
		public function AssociateApplicationAsDataEntryBy(Application $objApplication) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplicationAsDataEntryBy on this unsaved Login.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplicationAsDataEntryBy on this Login with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`data_entry_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . '
			');
		}

		/**
		 * Unassociates a ApplicationAsDataEntryBy
		 * @param Application $objApplication
		 * @return void
		*/
		public function UnassociateApplicationAsDataEntryBy(Application $objApplication) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsDataEntryBy on this unsaved Login.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsDataEntryBy on this Login with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`data_entry_by` = null
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . ' AND
					`data_entry_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all ApplicationsAsDataEntryBy
		 * @return void
		*/
		public function UnassociateAllApplicationsAsDataEntryBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsDataEntryBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`data_entry_by` = null
				WHERE
					`data_entry_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated ApplicationAsDataEntryBy
		 * @param Application $objApplication
		 * @return void
		*/
		public function DeleteAssociatedApplicationAsDataEntryBy(Application $objApplication) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsDataEntryBy on this unsaved Login.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsDataEntryBy on this Login with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`application`
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . ' AND
					`data_entry_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated ApplicationsAsDataEntryBy
		 * @return void
		*/
		public function DeleteAllApplicationsAsDataEntryBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsDataEntryBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`application`
				WHERE
					`data_entry_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for ApplicationAsCertificateIssueBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ApplicationsAsCertificateIssueBy as an array of Application objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Application[]
		*/
		public function GetApplicationAsCertificateIssueByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Application::LoadArrayByCertificateIssueBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ApplicationsAsCertificateIssueBy
		 * @return int
		*/
		public function CountApplicationsAsCertificateIssueBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Application::CountByCertificateIssueBy($this->intIdlogin);
		}

		/**
		 * Associates a ApplicationAsCertificateIssueBy
		 * @param Application $objApplication
		 * @return void
		*/
		public function AssociateApplicationAsCertificateIssueBy(Application $objApplication) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplicationAsCertificateIssueBy on this unsaved Login.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplicationAsCertificateIssueBy on this Login with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`certificate_issue_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . '
			');
		}

		/**
		 * Unassociates a ApplicationAsCertificateIssueBy
		 * @param Application $objApplication
		 * @return void
		*/
		public function UnassociateApplicationAsCertificateIssueBy(Application $objApplication) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsCertificateIssueBy on this unsaved Login.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsCertificateIssueBy on this Login with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`certificate_issue_by` = null
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . ' AND
					`certificate_issue_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all ApplicationsAsCertificateIssueBy
		 * @return void
		*/
		public function UnassociateAllApplicationsAsCertificateIssueBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsCertificateIssueBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`certificate_issue_by` = null
				WHERE
					`certificate_issue_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated ApplicationAsCertificateIssueBy
		 * @param Application $objApplication
		 * @return void
		*/
		public function DeleteAssociatedApplicationAsCertificateIssueBy(Application $objApplication) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsCertificateIssueBy on this unsaved Login.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsCertificateIssueBy on this Login with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`application`
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . ' AND
					`certificate_issue_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated ApplicationsAsCertificateIssueBy
		 * @return void
		*/
		public function DeleteAllApplicationsAsCertificateIssueBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsCertificateIssueBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`application`
				WHERE
					`certificate_issue_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for LogAsDataBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated LogsAsDataBy as an array of Log objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Log[]
		*/
		public function GetLogAsDataByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Log::LoadArrayByDataBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated LogsAsDataBy
		 * @return int
		*/
		public function CountLogsAsDataBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Log::CountByDataBy($this->intIdlogin);
		}

		/**
		 * Associates a LogAsDataBy
		 * @param Log $objLog
		 * @return void
		*/
		public function AssociateLogAsDataBy(Log $objLog) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLogAsDataBy on this unsaved Login.');
			if ((is_null($objLog->Idlog)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLogAsDataBy on this Login with an unsaved Log.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`log`
				SET
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idlog` = ' . $objDatabase->SqlVariable($objLog->Idlog) . '
			');
		}

		/**
		 * Unassociates a LogAsDataBy
		 * @param Log $objLog
		 * @return void
		*/
		public function UnassociateLogAsDataBy(Log $objLog) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsDataBy on this unsaved Login.');
			if ((is_null($objLog->Idlog)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsDataBy on this Login with an unsaved Log.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`log`
				SET
					`data_by` = null
				WHERE
					`idlog` = ' . $objDatabase->SqlVariable($objLog->Idlog) . ' AND
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all LogsAsDataBy
		 * @return void
		*/
		public function UnassociateAllLogsAsDataBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsDataBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`log`
				SET
					`data_by` = null
				WHERE
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated LogAsDataBy
		 * @param Log $objLog
		 * @return void
		*/
		public function DeleteAssociatedLogAsDataBy(Log $objLog) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsDataBy on this unsaved Login.');
			if ((is_null($objLog->Idlog)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsDataBy on this Login with an unsaved Log.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`log`
				WHERE
					`idlog` = ' . $objDatabase->SqlVariable($objLog->Idlog) . ' AND
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated LogsAsDataBy
		 * @return void
		*/
		public function DeleteAllLogsAsDataBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsDataBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`log`
				WHERE
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for LoginHasRoleAsId
		//-------------------------------------------------------------------

		/**
		 * Gets all associated LoginHasRolesAsId as an array of LoginHasRole objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LoginHasRole[]
		*/
		public function GetLoginHasRoleAsIdArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return LoginHasRole::LoadArrayByLoginIdlogin($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated LoginHasRolesAsId
		 * @return int
		*/
		public function CountLoginHasRolesAsId() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return LoginHasRole::CountByLoginIdlogin($this->intIdlogin);
		}

		/**
		 * Associates a LoginHasRoleAsId
		 * @param LoginHasRole $objLoginHasRole
		 * @return void
		*/
		public function AssociateLoginHasRoleAsId(LoginHasRole $objLoginHasRole) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLoginHasRoleAsId on this unsaved Login.');
			if ((is_null($objLoginHasRole->LoginIdlogin)) || (is_null($objLoginHasRole->RoleIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLoginHasRoleAsId on this Login with an unsaved LoginHasRole.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`login_has_role`
				SET
					`login_idlogin` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`login_idlogin` = ' . $objDatabase->SqlVariable($objLoginHasRole->LoginIdlogin) . ' AND
					`role_idrole` = ' . $objDatabase->SqlVariable($objLoginHasRole->RoleIdrole) . '
			');
		}

		/**
		 * Unassociates a LoginHasRoleAsId
		 * @param LoginHasRole $objLoginHasRole
		 * @return void
		*/
		public function UnassociateLoginHasRoleAsId(LoginHasRole $objLoginHasRole) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this unsaved Login.');
			if ((is_null($objLoginHasRole->LoginIdlogin)) || (is_null($objLoginHasRole->RoleIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this Login with an unsaved LoginHasRole.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`login_has_role`
				SET
					`login_idlogin` = null
				WHERE
					`login_idlogin` = ' . $objDatabase->SqlVariable($objLoginHasRole->LoginIdlogin) . ' AND
					`role_idrole` = ' . $objDatabase->SqlVariable($objLoginHasRole->RoleIdrole) . ' AND
					`login_idlogin` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all LoginHasRolesAsId
		 * @return void
		*/
		public function UnassociateAllLoginHasRolesAsId() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`login_has_role`
				SET
					`login_idlogin` = null
				WHERE
					`login_idlogin` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated LoginHasRoleAsId
		 * @param LoginHasRole $objLoginHasRole
		 * @return void
		*/
		public function DeleteAssociatedLoginHasRoleAsId(LoginHasRole $objLoginHasRole) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this unsaved Login.');
			if ((is_null($objLoginHasRole->LoginIdlogin)) || (is_null($objLoginHasRole->RoleIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this Login with an unsaved LoginHasRole.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`login_has_role`
				WHERE
					`login_idlogin` = ' . $objDatabase->SqlVariable($objLoginHasRole->LoginIdlogin) . ' AND
					`role_idrole` = ' . $objDatabase->SqlVariable($objLoginHasRole->RoleIdrole) . ' AND
					`login_idlogin` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated LoginHasRolesAsId
		 * @return void
		*/
		public function DeleteAllLoginHasRolesAsId() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`login_has_role`
				WHERE
					`login_idlogin` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for NoteAsDataby
		//-------------------------------------------------------------------

		/**
		 * Gets all associated NotesAsDataby as an array of Note objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Note[]
		*/
		public function GetNoteAsDatabyArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Note::LoadArrayByDataby($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated NotesAsDataby
		 * @return int
		*/
		public function CountNotesAsDataby() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Note::CountByDataby($this->intIdlogin);
		}

		/**
		 * Associates a NoteAsDataby
		 * @param Note $objNote
		 * @return void
		*/
		public function AssociateNoteAsDataby(Note $objNote) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateNoteAsDataby on this unsaved Login.');
			if ((is_null($objNote->Idnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateNoteAsDataby on this Login with an unsaved Note.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`note`
				SET
					`databy` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idnote` = ' . $objDatabase->SqlVariable($objNote->Idnote) . '
			');
		}

		/**
		 * Unassociates a NoteAsDataby
		 * @param Note $objNote
		 * @return void
		*/
		public function UnassociateNoteAsDataby(Note $objNote) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNoteAsDataby on this unsaved Login.');
			if ((is_null($objNote->Idnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNoteAsDataby on this Login with an unsaved Note.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`note`
				SET
					`databy` = null
				WHERE
					`idnote` = ' . $objDatabase->SqlVariable($objNote->Idnote) . ' AND
					`databy` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all NotesAsDataby
		 * @return void
		*/
		public function UnassociateAllNotesAsDataby() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNoteAsDataby on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`note`
				SET
					`databy` = null
				WHERE
					`databy` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated NoteAsDataby
		 * @param Note $objNote
		 * @return void
		*/
		public function DeleteAssociatedNoteAsDataby(Note $objNote) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNoteAsDataby on this unsaved Login.');
			if ((is_null($objNote->Idnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNoteAsDataby on this Login with an unsaved Note.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`note`
				WHERE
					`idnote` = ' . $objDatabase->SqlVariable($objNote->Idnote) . ' AND
					`databy` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated NotesAsDataby
		 * @return void
		*/
		public function DeleteAllNotesAsDataby() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNoteAsDataby on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`note`
				WHERE
					`databy` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for SignPatch
		//-------------------------------------------------------------------

		/**
		 * Gets all associated SignPatches as an array of SignPatch objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SignPatch[]
		*/
		public function GetSignPatchArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return SignPatch::LoadArrayByLogin($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated SignPatches
		 * @return int
		*/
		public function CountSignPatches() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return SignPatch::CountByLogin($this->intIdlogin);
		}

		/**
		 * Associates a SignPatch
		 * @param SignPatch $objSignPatch
		 * @return void
		*/
		public function AssociateSignPatch(SignPatch $objSignPatch) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSignPatch on this unsaved Login.');
			if ((is_null($objSignPatch->IdsignPatch)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSignPatch on this Login with an unsaved SignPatch.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`sign_patch`
				SET
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idsign_patch` = ' . $objDatabase->SqlVariable($objSignPatch->IdsignPatch) . '
			');
		}

		/**
		 * Unassociates a SignPatch
		 * @param SignPatch $objSignPatch
		 * @return void
		*/
		public function UnassociateSignPatch(SignPatch $objSignPatch) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSignPatch on this unsaved Login.');
			if ((is_null($objSignPatch->IdsignPatch)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSignPatch on this Login with an unsaved SignPatch.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`sign_patch`
				SET
					`login` = null
				WHERE
					`idsign_patch` = ' . $objDatabase->SqlVariable($objSignPatch->IdsignPatch) . ' AND
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all SignPatches
		 * @return void
		*/
		public function UnassociateAllSignPatches() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSignPatch on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`sign_patch`
				SET
					`login` = null
				WHERE
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated SignPatch
		 * @param SignPatch $objSignPatch
		 * @return void
		*/
		public function DeleteAssociatedSignPatch(SignPatch $objSignPatch) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSignPatch on this unsaved Login.');
			if ((is_null($objSignPatch->IdsignPatch)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSignPatch on this Login with an unsaved SignPatch.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`sign_patch`
				WHERE
					`idsign_patch` = ' . $objDatabase->SqlVariable($objSignPatch->IdsignPatch) . ' AND
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated SignPatches
		 * @return void
		*/
		public function DeleteAllSignPatches() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSignPatch on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`sign_patch`
				WHERE
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "login";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Login::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Login"><sequence>';
			$strToReturn .= '<element name="IdloginObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="Username" type="xsd:string"/>';
			$strToReturn .= '<element name="Password" type="xsd:string"/>';
			$strToReturn .= '<element name="IsEnabled" type="xsd:boolean"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Login', $strComplexTypeArray)) {
				$strComplexTypeArray['Login'] = Login::GetSoapComplexTypeXml();
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Login::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Login();
			if ((property_exists($objSoapObject, 'IdloginObject')) &&
				($objSoapObject->IdloginObject))
				$objToReturn->IdloginObject = Ledger::GetObjectFromSoapObject($objSoapObject->IdloginObject);
			if (property_exists($objSoapObject, 'Username'))
				$objToReturn->strUsername = $objSoapObject->Username;
			if (property_exists($objSoapObject, 'Password'))
				$objToReturn->strPassword = $objSoapObject->Password;
			if (property_exists($objSoapObject, 'IsEnabled'))
				$objToReturn->blnIsEnabled = $objSoapObject->IsEnabled;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Login::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objIdloginObject)
				$objObject->objIdloginObject = Ledger::GetSoapObjectFromObject($objObject->objIdloginObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intIdlogin = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idlogin'] = $this->intIdlogin;
			$iArray['Username'] = $this->strUsername;
			$iArray['Password'] = $this->strPassword;
			$iArray['IsEnabled'] = $this->blnIsEnabled;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdlogin ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idlogin
     * @property-read QQNodeLedger $IdloginObject
     * @property-read QQNode $Username
     * @property-read QQNode $Password
     * @property-read QQNode $IsEnabled
     *
     *
     * @property-read QQReverseReferenceNodeAppApproval $AppApprovalAsDecisionBy
     * @property-read QQReverseReferenceNodeApplication $ApplicationAsDataEntryBy
     * @property-read QQReverseReferenceNodeApplication $ApplicationAsCertificateIssueBy
     * @property-read QQReverseReferenceNodeLog $LogAsDataBy
     * @property-read QQReverseReferenceNodeLoginHasRole $LoginHasRoleAsId
     * @property-read QQReverseReferenceNodeNote $NoteAsDataby
     * @property-read QQReverseReferenceNodeSignPatch $SignPatch

     * @property-read QQNodeLedger $_PrimaryKeyNode
     **/
	class QQNodeLogin extends QQNode {
		protected $strTableName = 'login';
		protected $strPrimaryKey = 'idlogin';
		protected $strClassName = 'Login';
		public function __get($strName) {
			switch ($strName) {
				case 'Idlogin':
					return new QQNode('idlogin', 'Idlogin', 'Integer', $this);
				case 'IdloginObject':
					return new QQNodeLedger('idlogin', 'IdloginObject', 'Integer', $this);
				case 'Username':
					return new QQNode('username', 'Username', 'VarChar', $this);
				case 'Password':
					return new QQNode('password', 'Password', 'VarChar', $this);
				case 'IsEnabled':
					return new QQNode('is_enabled', 'IsEnabled', 'Bit', $this);
				case 'AppApprovalAsDecisionBy':
					return new QQReverseReferenceNodeAppApproval($this, 'appapprovalasdecisionby', 'reverse_reference', 'decision_by');
				case 'ApplicationAsDataEntryBy':
					return new QQReverseReferenceNodeApplication($this, 'applicationasdataentryby', 'reverse_reference', 'data_entry_by');
				case 'ApplicationAsCertificateIssueBy':
					return new QQReverseReferenceNodeApplication($this, 'applicationascertificateissueby', 'reverse_reference', 'certificate_issue_by');
				case 'LogAsDataBy':
					return new QQReverseReferenceNodeLog($this, 'logasdataby', 'reverse_reference', 'data_by');
				case 'LoginHasRoleAsId':
					return new QQReverseReferenceNodeLoginHasRole($this, 'loginhasroleasid', 'reverse_reference', 'login_idlogin');
				case 'NoteAsDataby':
					return new QQReverseReferenceNodeNote($this, 'noteasdataby', 'reverse_reference', 'databy');
				case 'SignPatch':
					return new QQReverseReferenceNodeSignPatch($this, 'signpatch', 'reverse_reference', 'login');

				case '_PrimaryKeyNode':
					return new QQNodeLedger('idlogin', 'Idlogin', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idlogin
     * @property-read QQNodeLedger $IdloginObject
     * @property-read QQNode $Username
     * @property-read QQNode $Password
     * @property-read QQNode $IsEnabled
     *
     *
     * @property-read QQReverseReferenceNodeAppApproval $AppApprovalAsDecisionBy
     * @property-read QQReverseReferenceNodeApplication $ApplicationAsDataEntryBy
     * @property-read QQReverseReferenceNodeApplication $ApplicationAsCertificateIssueBy
     * @property-read QQReverseReferenceNodeLog $LogAsDataBy
     * @property-read QQReverseReferenceNodeLoginHasRole $LoginHasRoleAsId
     * @property-read QQReverseReferenceNodeNote $NoteAsDataby
     * @property-read QQReverseReferenceNodeSignPatch $SignPatch

     * @property-read QQNodeLedger $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeLogin extends QQReverseReferenceNode {
		protected $strTableName = 'login';
		protected $strPrimaryKey = 'idlogin';
		protected $strClassName = 'Login';
		public function __get($strName) {
			switch ($strName) {
				case 'Idlogin':
					return new QQNode('idlogin', 'Idlogin', 'integer', $this);
				case 'IdloginObject':
					return new QQNodeLedger('idlogin', 'IdloginObject', 'integer', $this);
				case 'Username':
					return new QQNode('username', 'Username', 'string', $this);
				case 'Password':
					return new QQNode('password', 'Password', 'string', $this);
				case 'IsEnabled':
					return new QQNode('is_enabled', 'IsEnabled', 'boolean', $this);
				case 'AppApprovalAsDecisionBy':
					return new QQReverseReferenceNodeAppApproval($this, 'appapprovalasdecisionby', 'reverse_reference', 'decision_by');
				case 'ApplicationAsDataEntryBy':
					return new QQReverseReferenceNodeApplication($this, 'applicationasdataentryby', 'reverse_reference', 'data_entry_by');
				case 'ApplicationAsCertificateIssueBy':
					return new QQReverseReferenceNodeApplication($this, 'applicationascertificateissueby', 'reverse_reference', 'certificate_issue_by');
				case 'LogAsDataBy':
					return new QQReverseReferenceNodeLog($this, 'logasdataby', 'reverse_reference', 'data_by');
				case 'LoginHasRoleAsId':
					return new QQReverseReferenceNodeLoginHasRole($this, 'loginhasroleasid', 'reverse_reference', 'login_idlogin');
				case 'NoteAsDataby':
					return new QQReverseReferenceNodeNote($this, 'noteasdataby', 'reverse_reference', 'databy');
				case 'SignPatch':
					return new QQReverseReferenceNodeSignPatch($this, 'signpatch', 'reverse_reference', 'login');

				case '_PrimaryKeyNode':
					return new QQNodeLedger('idlogin', 'Idlogin', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
