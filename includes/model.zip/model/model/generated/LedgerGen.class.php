<?php
	/**
	 * The abstract LedgerGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Ledger subclass which
	 * extends this LedgerGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Ledger class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idledger the value for intIdledger (Read-Only PK)
	 * @property string $Code the value for strCode (Unique)
	 * @property string $Name the value for strName (Not Null)
	 * @property integer $Grp the value for intGrp 
	 * @property boolean $IsGrp the value for blnIsGrp 
	 * @property string $Description the value for strDescription 
	 * @property Ledger $GrpObject the value for the Ledger object referenced by intGrp 
	 * @property LedgerDetails $LedgerDetails the value for the LedgerDetails object that uniquely references this Ledger
	 * @property Login $Login the value for the Login object that uniquely references this Ledger
	 * @property Profile $Profile the value for the Profile object that uniquely references this Ledger
	 * @property-read Address $_AddressAsOf the value for the private _objAddressAsOf (Read-Only) if set due to an expansion on the address.of reverse relationship
	 * @property-read Address[] $_AddressAsOfArray the value for the private _objAddressAsOfArray (Read-Only) if set due to an ExpandAsArray on the address.of reverse relationship
	 * @property-read AppDocs $_AppDocsAsDocument the value for the private _objAppDocsAsDocument (Read-Only) if set due to an expansion on the app_docs.document reverse relationship
	 * @property-read AppDocs[] $_AppDocsAsDocumentArray the value for the private _objAppDocsAsDocumentArray (Read-Only) if set due to an ExpandAsArray on the app_docs.document reverse relationship
	 * @property-read FeesTemplet $_FeesTempletAsFees the value for the private _objFeesTempletAsFees (Read-Only) if set due to an expansion on the fees_templet.fees reverse relationship
	 * @property-read FeesTemplet[] $_FeesTempletAsFeesArray the value for the private _objFeesTempletAsFeesArray (Read-Only) if set due to an ExpandAsArray on the fees_templet.fees reverse relationship
	 * @property-read FeesTemplet $_FeesTempletAsConcession the value for the private _objFeesTempletAsConcession (Read-Only) if set due to an expansion on the fees_templet.concession reverse relationship
	 * @property-read FeesTemplet[] $_FeesTempletAsConcessionArray the value for the private _objFeesTempletAsConcessionArray (Read-Only) if set due to an ExpandAsArray on the fees_templet.concession reverse relationship
	 * @property-read FeesTemplet $_FeesTempletAsSource the value for the private _objFeesTempletAsSource (Read-Only) if set due to an expansion on the fees_templet.source reverse relationship
	 * @property-read FeesTemplet[] $_FeesTempletAsSourceArray the value for the private _objFeesTempletAsSourceArray (Read-Only) if set due to an ExpandAsArray on the fees_templet.source reverse relationship
	 * @property-read Ledger $_LedgerAsGrp the value for the private _objLedgerAsGrp (Read-Only) if set due to an expansion on the ledger.grp reverse relationship
	 * @property-read Ledger[] $_LedgerAsGrpArray the value for the private _objLedgerAsGrpArray (Read-Only) if set due to an ExpandAsArray on the ledger.grp reverse relationship
	 * @property-read TempletDocuments $_TempletDocumentsAsDocument the value for the private _objTempletDocumentsAsDocument (Read-Only) if set due to an expansion on the templet_documents.document reverse relationship
	 * @property-read TempletDocuments[] $_TempletDocumentsAsDocumentArray the value for the private _objTempletDocumentsAsDocumentArray (Read-Only) if set due to an ExpandAsArray on the templet_documents.document reverse relationship
	 * @property-read Voucher $_VoucherAsDr the value for the private _objVoucherAsDr (Read-Only) if set due to an expansion on the voucher.dr reverse relationship
	 * @property-read Voucher[] $_VoucherAsDrArray the value for the private _objVoucherAsDrArray (Read-Only) if set due to an ExpandAsArray on the voucher.dr reverse relationship
	 * @property-read Voucher $_VoucherAsCr the value for the private _objVoucherAsCr (Read-Only) if set due to an expansion on the voucher.cr reverse relationship
	 * @property-read Voucher[] $_VoucherAsCrArray the value for the private _objVoucherAsCrArray (Read-Only) if set due to an ExpandAsArray on the voucher.cr reverse relationship
	 * @property-read Voucher $_VoucherAsDataBy the value for the private _objVoucherAsDataBy (Read-Only) if set due to an expansion on the voucher.data_by reverse relationship
	 * @property-read Voucher[] $_VoucherAsDataByArray the value for the private _objVoucherAsDataByArray (Read-Only) if set due to an ExpandAsArray on the voucher.data_by reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class LedgerGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column ledger.idledger
		 * @var integer intIdledger
		 */
		protected $intIdledger;
		const IdledgerDefault = null;


		/**
		 * Protected member variable that maps to the database column ledger.code
		 * @var string strCode
		 */
		protected $strCode;
		const CodeMaxLength = 45;
		const CodeDefault = null;


		/**
		 * Protected member variable that maps to the database column ledger.name
		 * @var string strName
		 */
		protected $strName;
		const NameMaxLength = 45;
		const NameDefault = null;


		/**
		 * Protected member variable that maps to the database column ledger.grp
		 * @var integer intGrp
		 */
		protected $intGrp;
		const GrpDefault = null;


		/**
		 * Protected member variable that maps to the database column ledger.is_grp
		 * @var boolean blnIsGrp
		 */
		protected $blnIsGrp;
		const IsGrpDefault = null;


		/**
		 * Protected member variable that maps to the database column ledger.description
		 * @var string strDescription
		 */
		protected $strDescription;
		const DescriptionMaxLength = 45;
		const DescriptionDefault = null;


		/**
		 * Private member variable that stores a reference to a single AddressAsOf object
		 * (of type Address), if this Ledger object was restored with
		 * an expansion on the address association table.
		 * @var Address _objAddressAsOf;
		 */
		private $_objAddressAsOf;

		/**
		 * Private member variable that stores a reference to an array of AddressAsOf objects
		 * (of type Address[]), if this Ledger object was restored with
		 * an ExpandAsArray on the address association table.
		 * @var Address[] _objAddressAsOfArray;
		 */
		private $_objAddressAsOfArray = null;

		/**
		 * Private member variable that stores a reference to a single AppDocsAsDocument object
		 * (of type AppDocs), if this Ledger object was restored with
		 * an expansion on the app_docs association table.
		 * @var AppDocs _objAppDocsAsDocument;
		 */
		private $_objAppDocsAsDocument;

		/**
		 * Private member variable that stores a reference to an array of AppDocsAsDocument objects
		 * (of type AppDocs[]), if this Ledger object was restored with
		 * an ExpandAsArray on the app_docs association table.
		 * @var AppDocs[] _objAppDocsAsDocumentArray;
		 */
		private $_objAppDocsAsDocumentArray = null;

		/**
		 * Private member variable that stores a reference to a single FeesTempletAsFees object
		 * (of type FeesTemplet), if this Ledger object was restored with
		 * an expansion on the fees_templet association table.
		 * @var FeesTemplet _objFeesTempletAsFees;
		 */
		private $_objFeesTempletAsFees;

		/**
		 * Private member variable that stores a reference to an array of FeesTempletAsFees objects
		 * (of type FeesTemplet[]), if this Ledger object was restored with
		 * an ExpandAsArray on the fees_templet association table.
		 * @var FeesTemplet[] _objFeesTempletAsFeesArray;
		 */
		private $_objFeesTempletAsFeesArray = null;

		/**
		 * Private member variable that stores a reference to a single FeesTempletAsConcession object
		 * (of type FeesTemplet), if this Ledger object was restored with
		 * an expansion on the fees_templet association table.
		 * @var FeesTemplet _objFeesTempletAsConcession;
		 */
		private $_objFeesTempletAsConcession;

		/**
		 * Private member variable that stores a reference to an array of FeesTempletAsConcession objects
		 * (of type FeesTemplet[]), if this Ledger object was restored with
		 * an ExpandAsArray on the fees_templet association table.
		 * @var FeesTemplet[] _objFeesTempletAsConcessionArray;
		 */
		private $_objFeesTempletAsConcessionArray = null;

		/**
		 * Private member variable that stores a reference to a single FeesTempletAsSource object
		 * (of type FeesTemplet), if this Ledger object was restored with
		 * an expansion on the fees_templet association table.
		 * @var FeesTemplet _objFeesTempletAsSource;
		 */
		private $_objFeesTempletAsSource;

		/**
		 * Private member variable that stores a reference to an array of FeesTempletAsSource objects
		 * (of type FeesTemplet[]), if this Ledger object was restored with
		 * an ExpandAsArray on the fees_templet association table.
		 * @var FeesTemplet[] _objFeesTempletAsSourceArray;
		 */
		private $_objFeesTempletAsSourceArray = null;

		/**
		 * Private member variable that stores a reference to a single LedgerAsGrp object
		 * (of type Ledger), if this Ledger object was restored with
		 * an expansion on the ledger association table.
		 * @var Ledger _objLedgerAsGrp;
		 */
		private $_objLedgerAsGrp;

		/**
		 * Private member variable that stores a reference to an array of LedgerAsGrp objects
		 * (of type Ledger[]), if this Ledger object was restored with
		 * an ExpandAsArray on the ledger association table.
		 * @var Ledger[] _objLedgerAsGrpArray;
		 */
		private $_objLedgerAsGrpArray = null;

		/**
		 * Private member variable that stores a reference to a single TempletDocumentsAsDocument object
		 * (of type TempletDocuments), if this Ledger object was restored with
		 * an expansion on the templet_documents association table.
		 * @var TempletDocuments _objTempletDocumentsAsDocument;
		 */
		private $_objTempletDocumentsAsDocument;

		/**
		 * Private member variable that stores a reference to an array of TempletDocumentsAsDocument objects
		 * (of type TempletDocuments[]), if this Ledger object was restored with
		 * an ExpandAsArray on the templet_documents association table.
		 * @var TempletDocuments[] _objTempletDocumentsAsDocumentArray;
		 */
		private $_objTempletDocumentsAsDocumentArray = null;

		/**
		 * Private member variable that stores a reference to a single VoucherAsDr object
		 * (of type Voucher), if this Ledger object was restored with
		 * an expansion on the voucher association table.
		 * @var Voucher _objVoucherAsDr;
		 */
		private $_objVoucherAsDr;

		/**
		 * Private member variable that stores a reference to an array of VoucherAsDr objects
		 * (of type Voucher[]), if this Ledger object was restored with
		 * an ExpandAsArray on the voucher association table.
		 * @var Voucher[] _objVoucherAsDrArray;
		 */
		private $_objVoucherAsDrArray = null;

		/**
		 * Private member variable that stores a reference to a single VoucherAsCr object
		 * (of type Voucher), if this Ledger object was restored with
		 * an expansion on the voucher association table.
		 * @var Voucher _objVoucherAsCr;
		 */
		private $_objVoucherAsCr;

		/**
		 * Private member variable that stores a reference to an array of VoucherAsCr objects
		 * (of type Voucher[]), if this Ledger object was restored with
		 * an ExpandAsArray on the voucher association table.
		 * @var Voucher[] _objVoucherAsCrArray;
		 */
		private $_objVoucherAsCrArray = null;

		/**
		 * Private member variable that stores a reference to a single VoucherAsDataBy object
		 * (of type Voucher), if this Ledger object was restored with
		 * an expansion on the voucher association table.
		 * @var Voucher _objVoucherAsDataBy;
		 */
		private $_objVoucherAsDataBy;

		/**
		 * Private member variable that stores a reference to an array of VoucherAsDataBy objects
		 * (of type Voucher[]), if this Ledger object was restored with
		 * an ExpandAsArray on the voucher association table.
		 * @var Voucher[] _objVoucherAsDataByArray;
		 */
		private $_objVoucherAsDataByArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column ledger.grp.
		 *
		 * NOTE: Always use the GrpObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objGrpObject
		 */
		protected $objGrpObject;

		/**
		 * Protected member variable that contains the object which points to
		 * this object by the reference in the unique database column ledger_details.idledger_details.
		 *
		 * NOTE: Always use the LedgerDetails property getter to correctly retrieve this LedgerDetails object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var LedgerDetails objLedgerDetails
		 */
		protected $objLedgerDetails;

		/**
		 * Used internally to manage whether the adjoined LedgerDetails object
		 * needs to be updated on save.
		 *
		 * NOTE: Do not manually update this value
		 */
		protected $blnDirtyLedgerDetails;

		/**
		 * Protected member variable that contains the object which points to
		 * this object by the reference in the unique database column login.idlogin.
		 *
		 * NOTE: Always use the Login property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objLogin
		 */
		protected $objLogin;

		/**
		 * Used internally to manage whether the adjoined Login object
		 * needs to be updated on save.
		 *
		 * NOTE: Do not manually update this value
		 */
		protected $blnDirtyLogin;

		/**
		 * Protected member variable that contains the object which points to
		 * this object by the reference in the unique database column profile.idprofile.
		 *
		 * NOTE: Always use the Profile property getter to correctly retrieve this Profile object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Profile objProfile
		 */
		protected $objProfile;

		/**
		 * Used internally to manage whether the adjoined Profile object
		 * needs to be updated on save.
		 *
		 * NOTE: Do not manually update this value
		 */
		protected $blnDirtyProfile;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdledger = Ledger::IdledgerDefault;
			$this->strCode = Ledger::CodeDefault;
			$this->strName = Ledger::NameDefault;
			$this->intGrp = Ledger::GrpDefault;
			$this->blnIsGrp = Ledger::IsGrpDefault;
			$this->strDescription = Ledger::DescriptionDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Ledger from PK Info
		 * @param integer $intIdledger
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Ledger
		 */
		public static function Load($intIdledger, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Ledger', $intIdledger);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Ledger::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Ledger()->Idledger, $intIdledger)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Ledgers
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Ledger[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Ledger::QueryArray to perform the LoadAll query
			try {
				return Ledger::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Ledgers
		 * @return int
		 */
		public static function CountAll() {
			// Call Ledger::QueryCount to perform the CountAll query
			return Ledger::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Create/Build out the QueryBuilder object with Ledger-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'ledger');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Ledger::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('ledger');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Ledger object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Ledger the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Ledger::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Ledger object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Ledger::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Ledger::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Ledger objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Ledger[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Ledger::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Ledger::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Ledger::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Ledger objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Ledger::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			$strQuery = Ledger::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/ledger', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Ledger::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Ledger
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'ledger';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idledger', $strAliasPrefix . 'idledger');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idledger', $strAliasPrefix . 'idledger');
			    $objBuilder->AddSelectItem($strTableName, 'code', $strAliasPrefix . 'code');
			    $objBuilder->AddSelectItem($strTableName, 'name', $strAliasPrefix . 'name');
			    $objBuilder->AddSelectItem($strTableName, 'grp', $strAliasPrefix . 'grp');
			    $objBuilder->AddSelectItem($strTableName, 'is_grp', $strAliasPrefix . 'is_grp');
			    $objBuilder->AddSelectItem($strTableName, 'description', $strAliasPrefix . 'description');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Ledger from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Ledger::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Ledger
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdledger == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'ledger__';


						// Expanding reverse references: AddressAsOf
						$strAlias = $strAliasPrefix . 'addressasof__idaddress';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objAddressAsOfArray)
								$objPreviousItem->_objAddressAsOfArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objAddressAsOfArray)) {
								$objPreviousChildItems = $objPreviousItem->_objAddressAsOfArray;
								$objChildItem = Address::InstantiateDbRow($objDbRow, $strAliasPrefix . 'addressasof__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objAddressAsOfArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objAddressAsOfArray[] = Address::InstantiateDbRow($objDbRow, $strAliasPrefix . 'addressasof__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: AppDocsAsDocument
						$strAlias = $strAliasPrefix . 'appdocsasdocument__idapp_docs';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objAppDocsAsDocumentArray)
								$objPreviousItem->_objAppDocsAsDocumentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objAppDocsAsDocumentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objAppDocsAsDocumentArray;
								$objChildItem = AppDocs::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appdocsasdocument__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objAppDocsAsDocumentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objAppDocsAsDocumentArray[] = AppDocs::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appdocsasdocument__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: FeesTempletAsFees
						$strAlias = $strAliasPrefix . 'feestempletasfees__idfees_templet';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objFeesTempletAsFeesArray)
								$objPreviousItem->_objFeesTempletAsFeesArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objFeesTempletAsFeesArray)) {
								$objPreviousChildItems = $objPreviousItem->_objFeesTempletAsFeesArray;
								$objChildItem = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletasfees__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objFeesTempletAsFeesArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objFeesTempletAsFeesArray[] = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletasfees__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: FeesTempletAsConcession
						$strAlias = $strAliasPrefix . 'feestempletasconcession__idfees_templet';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objFeesTempletAsConcessionArray)
								$objPreviousItem->_objFeesTempletAsConcessionArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objFeesTempletAsConcessionArray)) {
								$objPreviousChildItems = $objPreviousItem->_objFeesTempletAsConcessionArray;
								$objChildItem = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletasconcession__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objFeesTempletAsConcessionArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objFeesTempletAsConcessionArray[] = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletasconcession__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: FeesTempletAsSource
						$strAlias = $strAliasPrefix . 'feestempletassource__idfees_templet';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objFeesTempletAsSourceArray)
								$objPreviousItem->_objFeesTempletAsSourceArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objFeesTempletAsSourceArray)) {
								$objPreviousChildItems = $objPreviousItem->_objFeesTempletAsSourceArray;
								$objChildItem = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletassource__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objFeesTempletAsSourceArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objFeesTempletAsSourceArray[] = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletassource__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: LedgerAsGrp
						$strAlias = $strAliasPrefix . 'ledgerasgrp__idledger';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objLedgerAsGrpArray)
								$objPreviousItem->_objLedgerAsGrpArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objLedgerAsGrpArray)) {
								$objPreviousChildItems = $objPreviousItem->_objLedgerAsGrpArray;
								$objChildItem = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ledgerasgrp__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objLedgerAsGrpArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objLedgerAsGrpArray[] = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ledgerasgrp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: TempletDocumentsAsDocument
						$strAlias = $strAliasPrefix . 'templetdocumentsasdocument__idtemplet_documents';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objTempletDocumentsAsDocumentArray)
								$objPreviousItem->_objTempletDocumentsAsDocumentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objTempletDocumentsAsDocumentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objTempletDocumentsAsDocumentArray;
								$objChildItem = TempletDocuments::InstantiateDbRow($objDbRow, $strAliasPrefix . 'templetdocumentsasdocument__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objTempletDocumentsAsDocumentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objTempletDocumentsAsDocumentArray[] = TempletDocuments::InstantiateDbRow($objDbRow, $strAliasPrefix . 'templetdocumentsasdocument__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: VoucherAsDr
						$strAlias = $strAliasPrefix . 'voucherasdr__idvoucher';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objVoucherAsDrArray)
								$objPreviousItem->_objVoucherAsDrArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objVoucherAsDrArray)) {
								$objPreviousChildItems = $objPreviousItem->_objVoucherAsDrArray;
								$objChildItem = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasdr__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objVoucherAsDrArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objVoucherAsDrArray[] = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasdr__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: VoucherAsCr
						$strAlias = $strAliasPrefix . 'voucherascr__idvoucher';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objVoucherAsCrArray)
								$objPreviousItem->_objVoucherAsCrArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objVoucherAsCrArray)) {
								$objPreviousChildItems = $objPreviousItem->_objVoucherAsCrArray;
								$objChildItem = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherascr__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objVoucherAsCrArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objVoucherAsCrArray[] = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherascr__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: VoucherAsDataBy
						$strAlias = $strAliasPrefix . 'voucherasdataby__idvoucher';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objVoucherAsDataByArray)
								$objPreviousItem->_objVoucherAsDataByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objVoucherAsDataByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objVoucherAsDataByArray;
								$objChildItem = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasdataby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objVoucherAsDataByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objVoucherAsDataByArray[] = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'ledger__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Ledger object
			$objToReturn = new Ledger();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdledger = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'name';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strName = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intGrp = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'is_grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnIsGrp = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'description';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strDescription = $objDbRow->GetColumn($strAliasName, 'VarChar');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idledger != $objPreviousItem->Idledger) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objAddressAsOfArray);
					$cnt = count($objToReturn->_objAddressAsOfArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objAddressAsOfArray, $objToReturn->_objAddressAsOfArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objAppDocsAsDocumentArray);
					$cnt = count($objToReturn->_objAppDocsAsDocumentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objAppDocsAsDocumentArray, $objToReturn->_objAppDocsAsDocumentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objFeesTempletAsFeesArray);
					$cnt = count($objToReturn->_objFeesTempletAsFeesArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objFeesTempletAsFeesArray, $objToReturn->_objFeesTempletAsFeesArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objFeesTempletAsConcessionArray);
					$cnt = count($objToReturn->_objFeesTempletAsConcessionArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objFeesTempletAsConcessionArray, $objToReturn->_objFeesTempletAsConcessionArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objFeesTempletAsSourceArray);
					$cnt = count($objToReturn->_objFeesTempletAsSourceArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objFeesTempletAsSourceArray, $objToReturn->_objFeesTempletAsSourceArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objLedgerAsGrpArray);
					$cnt = count($objToReturn->_objLedgerAsGrpArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objLedgerAsGrpArray, $objToReturn->_objLedgerAsGrpArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objTempletDocumentsAsDocumentArray);
					$cnt = count($objToReturn->_objTempletDocumentsAsDocumentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objTempletDocumentsAsDocumentArray, $objToReturn->_objTempletDocumentsAsDocumentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objVoucherAsDrArray);
					$cnt = count($objToReturn->_objVoucherAsDrArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objVoucherAsDrArray, $objToReturn->_objVoucherAsDrArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objVoucherAsCrArray);
					$cnt = count($objToReturn->_objVoucherAsCrArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objVoucherAsCrArray, $objToReturn->_objVoucherAsCrArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objVoucherAsDataByArray);
					$cnt = count($objToReturn->_objVoucherAsDataByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objVoucherAsDataByArray, $objToReturn->_objVoucherAsDataByArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'ledger__';

			// Check for GrpObject Early Binding
			$strAlias = $strAliasPrefix . 'grp__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objGrpObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'grp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);


			// Check for LedgerDetails Unique ReverseReference Binding
			$strAlias = $strAliasPrefix . 'ledgerdetails__idledger_details';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if ($objDbRow->ColumnExists($strAliasName)) {
				if (!is_null($objDbRow->GetColumn($strAliasName)))
					$objToReturn->objLedgerDetails = LedgerDetails::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ledgerdetails__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					// We ATTEMPTED to do an Early Bind but the Object Doesn't Exist
					// Let's set to FALSE so that the object knows not to try and re-query again
					$objToReturn->objLedgerDetails = false;
			}

			// Check for Login Unique ReverseReference Binding
			$strAlias = $strAliasPrefix . 'login__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if ($objDbRow->ColumnExists($strAliasName)) {
				if (!is_null($objDbRow->GetColumn($strAliasName)))
					$objToReturn->objLogin = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'login__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					// We ATTEMPTED to do an Early Bind but the Object Doesn't Exist
					// Let's set to FALSE so that the object knows not to try and re-query again
					$objToReturn->objLogin = false;
			}

			// Check for Profile Unique ReverseReference Binding
			$strAlias = $strAliasPrefix . 'profile__idprofile';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if ($objDbRow->ColumnExists($strAliasName)) {
				if (!is_null($objDbRow->GetColumn($strAliasName)))
					$objToReturn->objProfile = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profile__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					// We ATTEMPTED to do an Early Bind but the Object Doesn't Exist
					// Let's set to FALSE so that the object knows not to try and re-query again
					$objToReturn->objProfile = false;
			}



			// Check for AddressAsOf Virtual Binding
			$strAlias = $strAliasPrefix . 'addressasof__idaddress';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objAddressAsOfArray)
				$objToReturn->_objAddressAsOfArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objAddressAsOfArray[] = Address::InstantiateDbRow($objDbRow, $strAliasPrefix . 'addressasof__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objAddressAsOf = Address::InstantiateDbRow($objDbRow, $strAliasPrefix . 'addressasof__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for AppDocsAsDocument Virtual Binding
			$strAlias = $strAliasPrefix . 'appdocsasdocument__idapp_docs';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objAppDocsAsDocumentArray)
				$objToReturn->_objAppDocsAsDocumentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objAppDocsAsDocumentArray[] = AppDocs::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appdocsasdocument__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objAppDocsAsDocument = AppDocs::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appdocsasdocument__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for FeesTempletAsFees Virtual Binding
			$strAlias = $strAliasPrefix . 'feestempletasfees__idfees_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objFeesTempletAsFeesArray)
				$objToReturn->_objFeesTempletAsFeesArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objFeesTempletAsFeesArray[] = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletasfees__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objFeesTempletAsFees = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletasfees__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for FeesTempletAsConcession Virtual Binding
			$strAlias = $strAliasPrefix . 'feestempletasconcession__idfees_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objFeesTempletAsConcessionArray)
				$objToReturn->_objFeesTempletAsConcessionArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objFeesTempletAsConcessionArray[] = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletasconcession__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objFeesTempletAsConcession = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletasconcession__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for FeesTempletAsSource Virtual Binding
			$strAlias = $strAliasPrefix . 'feestempletassource__idfees_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objFeesTempletAsSourceArray)
				$objToReturn->_objFeesTempletAsSourceArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objFeesTempletAsSourceArray[] = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletassource__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objFeesTempletAsSource = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletassource__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for LedgerAsGrp Virtual Binding
			$strAlias = $strAliasPrefix . 'ledgerasgrp__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objLedgerAsGrpArray)
				$objToReturn->_objLedgerAsGrpArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objLedgerAsGrpArray[] = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ledgerasgrp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objLedgerAsGrp = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ledgerasgrp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for TempletDocumentsAsDocument Virtual Binding
			$strAlias = $strAliasPrefix . 'templetdocumentsasdocument__idtemplet_documents';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objTempletDocumentsAsDocumentArray)
				$objToReturn->_objTempletDocumentsAsDocumentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objTempletDocumentsAsDocumentArray[] = TempletDocuments::InstantiateDbRow($objDbRow, $strAliasPrefix . 'templetdocumentsasdocument__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objTempletDocumentsAsDocument = TempletDocuments::InstantiateDbRow($objDbRow, $strAliasPrefix . 'templetdocumentsasdocument__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for VoucherAsDr Virtual Binding
			$strAlias = $strAliasPrefix . 'voucherasdr__idvoucher';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objVoucherAsDrArray)
				$objToReturn->_objVoucherAsDrArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objVoucherAsDrArray[] = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasdr__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objVoucherAsDr = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasdr__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for VoucherAsCr Virtual Binding
			$strAlias = $strAliasPrefix . 'voucherascr__idvoucher';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objVoucherAsCrArray)
				$objToReturn->_objVoucherAsCrArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objVoucherAsCrArray[] = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherascr__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objVoucherAsCr = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherascr__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for VoucherAsDataBy Virtual Binding
			$strAlias = $strAliasPrefix . 'voucherasdataby__idvoucher';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objVoucherAsDataByArray)
				$objToReturn->_objVoucherAsDataByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objVoucherAsDataByArray[] = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objVoucherAsDataBy = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Ledgers from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Ledger[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Ledger::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Ledger::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Ledger object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Ledger next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Ledger::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Ledger object,
		 * by Idledger Index(es)
		 * @param integer $intIdledger
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Ledger
		*/
		public static function LoadByIdledger($intIdledger, $objOptionalClauses = null) {
			return Ledger::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Ledger()->Idledger, $intIdledger)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single Ledger object,
		 * by Code Index(es)
		 * @param string $strCode
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Ledger
		*/
		public static function LoadByCode($strCode, $objOptionalClauses = null) {
			return Ledger::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Ledger()->Code, $strCode)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Ledger objects,
		 * by Grp Index(es)
		 * @param integer $intGrp
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Ledger[]
		*/
		public static function LoadArrayByGrp($intGrp, $objOptionalClauses = null) {
			// Call Ledger::QueryArray to perform the LoadArrayByGrp query
			try {
				return Ledger::QueryArray(
					QQ::Equal(QQN::Ledger()->Grp, $intGrp),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Ledgers
		 * by Grp Index(es)
		 * @param integer $intGrp
		 * @return int
		*/
		public static function CountByGrp($intGrp) {
			// Call Ledger::QueryCount to perform the CountByGrp query
			return Ledger::QueryCount(
				QQ::Equal(QQN::Ledger()->Grp, $intGrp)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Ledger
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `ledger` (
							`code`,
							`name`,
							`grp`,
							`is_grp`,
							`description`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strCode) . ',
							' . $objDatabase->SqlVariable($this->strName) . ',
							' . $objDatabase->SqlVariable($this->intGrp) . ',
							' . $objDatabase->SqlVariable($this->blnIsGrp) . ',
							' . $objDatabase->SqlVariable($this->strDescription) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdledger = $objDatabase->InsertId('ledger', 'idledger');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`ledger`
						SET
							`code` = ' . $objDatabase->SqlVariable($this->strCode) . ',
							`name` = ' . $objDatabase->SqlVariable($this->strName) . ',
							`grp` = ' . $objDatabase->SqlVariable($this->intGrp) . ',
							`is_grp` = ' . $objDatabase->SqlVariable($this->blnIsGrp) . ',
							`description` = ' . $objDatabase->SqlVariable($this->strDescription) . '
						WHERE
							`idledger` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
					');
				}



				// Update the adjoined LedgerDetails object (if applicable)
				// TODO: Make this into hard-coded SQL queries
				if ($this->blnDirtyLedgerDetails) {
					// Unassociate the old one (if applicable)
					if ($objAssociated = LedgerDetails::LoadByIdledgerDetails($this->intIdledger)) {
						$objAssociated->IdledgerDetails = null;
						$objAssociated->Save();
					}

					// Associate the new one (if applicable)
					if ($this->objLedgerDetails) {
						$this->objLedgerDetails->IdledgerDetails = $this->intIdledger;
						$this->objLedgerDetails->Save();
					}

					// Reset the "Dirty" flag
					$this->blnDirtyLedgerDetails = false;
				}


				// Update the adjoined Login object (if applicable)
				// TODO: Make this into hard-coded SQL queries
				if ($this->blnDirtyLogin) {
					// Unassociate the old one (if applicable)
					if ($objAssociated = Login::LoadByIdlogin($this->intIdledger)) {
						$objAssociated->Idlogin = null;
						$objAssociated->Save();
					}

					// Associate the new one (if applicable)
					if ($this->objLogin) {
						$this->objLogin->Idlogin = $this->intIdledger;
						$this->objLogin->Save();
					}

					// Reset the "Dirty" flag
					$this->blnDirtyLogin = false;
				}


				// Update the adjoined Profile object (if applicable)
				// TODO: Make this into hard-coded SQL queries
				if ($this->blnDirtyProfile) {
					// Unassociate the old one (if applicable)
					if ($objAssociated = Profile::LoadByIdprofile($this->intIdledger)) {
						$objAssociated->Idprofile = null;
						$objAssociated->Save();
					}

					// Associate the new one (if applicable)
					if ($this->objProfile) {
						$this->objProfile->Idprofile = $this->intIdledger;
						$this->objProfile->Save();
					}

					// Reset the "Dirty" flag
					$this->blnDirtyProfile = false;
				}
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Ledger
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Ledger with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();


		
			// Update the adjoined LedgerDetails object (if applicable) and perform a delete

			// Optional -- if you **KNOW** that you do not want to EVER run any level of business logic on the disassocation,
			// you *could* override Delete() so that this step can be a single hard coded query to optimize performance.
			if ($objAssociated = LedgerDetails::LoadByIdledgerDetails($this->intIdledger)) {
				$objAssociated->Delete();
			}

		
			// Update the adjoined Login object (if applicable) and perform a delete

			// Optional -- if you **KNOW** that you do not want to EVER run any level of business logic on the disassocation,
			// you *could* override Delete() so that this step can be a single hard coded query to optimize performance.
			if ($objAssociated = Login::LoadByIdlogin($this->intIdledger)) {
				$objAssociated->Delete();
			}

		
			// Update the adjoined Profile object (if applicable) and perform a delete

			// Optional -- if you **KNOW** that you do not want to EVER run any level of business logic on the disassocation,
			// you *could* override Delete() so that this step can be a single hard coded query to optimize performance.
			if ($objAssociated = Profile::LoadByIdprofile($this->intIdledger)) {
				$objAssociated->Delete();
			}

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`ledger`
				WHERE
					`idledger` = ' . $objDatabase->SqlVariable($this->intIdledger) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Ledger ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Ledger', $this->intIdledger);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Ledgers
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`ledger`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate ledger table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `ledger`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Ledger from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Ledger object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Ledger::Load($this->intIdledger);

			// Update $this's local variables to match
			$this->strCode = $objReloaded->strCode;
			$this->strName = $objReloaded->strName;
			$this->Grp = $objReloaded->Grp;
			$this->blnIsGrp = $objReloaded->blnIsGrp;
			$this->strDescription = $objReloaded->strDescription;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idledger':
					/**
					 * Gets the value for intIdledger (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdledger;

				case 'Code':
					/**
					 * Gets the value for strCode (Unique)
					 * @return string
					 */
					return $this->strCode;

				case 'Name':
					/**
					 * Gets the value for strName (Not Null)
					 * @return string
					 */
					return $this->strName;

				case 'Grp':
					/**
					 * Gets the value for intGrp 
					 * @return integer
					 */
					return $this->intGrp;

				case 'IsGrp':
					/**
					 * Gets the value for blnIsGrp 
					 * @return boolean
					 */
					return $this->blnIsGrp;

				case 'Description':
					/**
					 * Gets the value for strDescription 
					 * @return string
					 */
					return $this->strDescription;


				///////////////////
				// Member Objects
				///////////////////
				case 'GrpObject':
					/**
					 * Gets the value for the Ledger object referenced by intGrp 
					 * @return Ledger
					 */
					try {
						if ((!$this->objGrpObject) && (!is_null($this->intGrp)))
							$this->objGrpObject = Ledger::Load($this->intGrp);
						return $this->objGrpObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LedgerDetails':
					/**
					 * Gets the value for the LedgerDetails object that uniquely references this Ledger
					 * by objLedgerDetails (Unique)
					 * @return LedgerDetails
					 */
					try {
						if ($this->objLedgerDetails === false)
							// We've attempted early binding -- and the reverse reference object does not exist
							return null;
						if (!$this->objLedgerDetails)
							$this->objLedgerDetails = LedgerDetails::LoadByIdledgerDetails($this->intIdledger);
						return $this->objLedgerDetails;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Login':
					/**
					 * Gets the value for the Login object that uniquely references this Ledger
					 * by objLogin (Unique)
					 * @return Login
					 */
					try {
						if ($this->objLogin === false)
							// We've attempted early binding -- and the reverse reference object does not exist
							return null;
						if (!$this->objLogin)
							$this->objLogin = Login::LoadByIdlogin($this->intIdledger);
						return $this->objLogin;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Profile':
					/**
					 * Gets the value for the Profile object that uniquely references this Ledger
					 * by objProfile (Unique)
					 * @return Profile
					 */
					try {
						if ($this->objProfile === false)
							// We've attempted early binding -- and the reverse reference object does not exist
							return null;
						if (!$this->objProfile)
							$this->objProfile = Profile::LoadByIdprofile($this->intIdledger);
						return $this->objProfile;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_AddressAsOf':
					/**
					 * Gets the value for the private _objAddressAsOf (Read-Only)
					 * if set due to an expansion on the address.of reverse relationship
					 * @return Address
					 */
					return $this->_objAddressAsOf;

				case '_AddressAsOfArray':
					/**
					 * Gets the value for the private _objAddressAsOfArray (Read-Only)
					 * if set due to an ExpandAsArray on the address.of reverse relationship
					 * @return Address[]
					 */
					return $this->_objAddressAsOfArray;

				case '_AppDocsAsDocument':
					/**
					 * Gets the value for the private _objAppDocsAsDocument (Read-Only)
					 * if set due to an expansion on the app_docs.document reverse relationship
					 * @return AppDocs
					 */
					return $this->_objAppDocsAsDocument;

				case '_AppDocsAsDocumentArray':
					/**
					 * Gets the value for the private _objAppDocsAsDocumentArray (Read-Only)
					 * if set due to an ExpandAsArray on the app_docs.document reverse relationship
					 * @return AppDocs[]
					 */
					return $this->_objAppDocsAsDocumentArray;

				case '_FeesTempletAsFees':
					/**
					 * Gets the value for the private _objFeesTempletAsFees (Read-Only)
					 * if set due to an expansion on the fees_templet.fees reverse relationship
					 * @return FeesTemplet
					 */
					return $this->_objFeesTempletAsFees;

				case '_FeesTempletAsFeesArray':
					/**
					 * Gets the value for the private _objFeesTempletAsFeesArray (Read-Only)
					 * if set due to an ExpandAsArray on the fees_templet.fees reverse relationship
					 * @return FeesTemplet[]
					 */
					return $this->_objFeesTempletAsFeesArray;

				case '_FeesTempletAsConcession':
					/**
					 * Gets the value for the private _objFeesTempletAsConcession (Read-Only)
					 * if set due to an expansion on the fees_templet.concession reverse relationship
					 * @return FeesTemplet
					 */
					return $this->_objFeesTempletAsConcession;

				case '_FeesTempletAsConcessionArray':
					/**
					 * Gets the value for the private _objFeesTempletAsConcessionArray (Read-Only)
					 * if set due to an ExpandAsArray on the fees_templet.concession reverse relationship
					 * @return FeesTemplet[]
					 */
					return $this->_objFeesTempletAsConcessionArray;

				case '_FeesTempletAsSource':
					/**
					 * Gets the value for the private _objFeesTempletAsSource (Read-Only)
					 * if set due to an expansion on the fees_templet.source reverse relationship
					 * @return FeesTemplet
					 */
					return $this->_objFeesTempletAsSource;

				case '_FeesTempletAsSourceArray':
					/**
					 * Gets the value for the private _objFeesTempletAsSourceArray (Read-Only)
					 * if set due to an ExpandAsArray on the fees_templet.source reverse relationship
					 * @return FeesTemplet[]
					 */
					return $this->_objFeesTempletAsSourceArray;

				case '_LedgerAsGrp':
					/**
					 * Gets the value for the private _objLedgerAsGrp (Read-Only)
					 * if set due to an expansion on the ledger.grp reverse relationship
					 * @return Ledger
					 */
					return $this->_objLedgerAsGrp;

				case '_LedgerAsGrpArray':
					/**
					 * Gets the value for the private _objLedgerAsGrpArray (Read-Only)
					 * if set due to an ExpandAsArray on the ledger.grp reverse relationship
					 * @return Ledger[]
					 */
					return $this->_objLedgerAsGrpArray;

				case '_TempletDocumentsAsDocument':
					/**
					 * Gets the value for the private _objTempletDocumentsAsDocument (Read-Only)
					 * if set due to an expansion on the templet_documents.document reverse relationship
					 * @return TempletDocuments
					 */
					return $this->_objTempletDocumentsAsDocument;

				case '_TempletDocumentsAsDocumentArray':
					/**
					 * Gets the value for the private _objTempletDocumentsAsDocumentArray (Read-Only)
					 * if set due to an ExpandAsArray on the templet_documents.document reverse relationship
					 * @return TempletDocuments[]
					 */
					return $this->_objTempletDocumentsAsDocumentArray;

				case '_VoucherAsDr':
					/**
					 * Gets the value for the private _objVoucherAsDr (Read-Only)
					 * if set due to an expansion on the voucher.dr reverse relationship
					 * @return Voucher
					 */
					return $this->_objVoucherAsDr;

				case '_VoucherAsDrArray':
					/**
					 * Gets the value for the private _objVoucherAsDrArray (Read-Only)
					 * if set due to an ExpandAsArray on the voucher.dr reverse relationship
					 * @return Voucher[]
					 */
					return $this->_objVoucherAsDrArray;

				case '_VoucherAsCr':
					/**
					 * Gets the value for the private _objVoucherAsCr (Read-Only)
					 * if set due to an expansion on the voucher.cr reverse relationship
					 * @return Voucher
					 */
					return $this->_objVoucherAsCr;

				case '_VoucherAsCrArray':
					/**
					 * Gets the value for the private _objVoucherAsCrArray (Read-Only)
					 * if set due to an ExpandAsArray on the voucher.cr reverse relationship
					 * @return Voucher[]
					 */
					return $this->_objVoucherAsCrArray;

				case '_VoucherAsDataBy':
					/**
					 * Gets the value for the private _objVoucherAsDataBy (Read-Only)
					 * if set due to an expansion on the voucher.data_by reverse relationship
					 * @return Voucher
					 */
					return $this->_objVoucherAsDataBy;

				case '_VoucherAsDataByArray':
					/**
					 * Gets the value for the private _objVoucherAsDataByArray (Read-Only)
					 * if set due to an ExpandAsArray on the voucher.data_by reverse relationship
					 * @return Voucher[]
					 */
					return $this->_objVoucherAsDataByArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Code':
					/**
					 * Sets the value for strCode (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Name':
					/**
					 * Sets the value for strName (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strName = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Grp':
					/**
					 * Sets the value for intGrp 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objGrpObject = null;
						return ($this->intGrp = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'IsGrp':
					/**
					 * Sets the value for blnIsGrp 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnIsGrp = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Description':
					/**
					 * Sets the value for strDescription 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strDescription = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'GrpObject':
					/**
					 * Sets the value for the Ledger object referenced by intGrp 
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intGrp = null;
						$this->objGrpObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved GrpObject for this Ledger');

						// Update Local Member Variables
						$this->objGrpObject = $mixValue;
						$this->intGrp = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'LedgerDetails':
					/**
					 * Sets the value for the LedgerDetails object referenced by objLedgerDetails (Unique)
					 * @param LedgerDetails $mixValue
					 * @return LedgerDetails
					 */
					if (is_null($mixValue)) {
						$this->objLedgerDetails = null;

						// Make sure we update the adjoined LedgerDetails object the next time we call Save()
						$this->blnDirtyLedgerDetails = true;

						return null;
					} else {
						// Make sure $mixValue actually is a LedgerDetails object
						try {
							$mixValue = QType::Cast($mixValue, 'LedgerDetails');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Are we setting objLedgerDetails to a DIFFERENT $mixValue?
						if ((!$this->LedgerDetails) || ($this->LedgerDetails->IdledgerDetails != $mixValue->IdledgerDetails)) {
							// Yes -- therefore, set the "Dirty" flag to true
							// to make sure we update the adjoined LedgerDetails object the next time we call Save()
							$this->blnDirtyLedgerDetails = true;

							// Update Local Member Variable
							$this->objLedgerDetails = $mixValue;
						} else {
							// Nope -- therefore, make no changes
						}

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'Login':
					/**
					 * Sets the value for the Login object referenced by objLogin (Unique)
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->objLogin = null;

						// Make sure we update the adjoined Login object the next time we call Save()
						$this->blnDirtyLogin = true;

						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Are we setting objLogin to a DIFFERENT $mixValue?
						if ((!$this->Login) || ($this->Login->Idlogin != $mixValue->Idlogin)) {
							// Yes -- therefore, set the "Dirty" flag to true
							// to make sure we update the adjoined Login object the next time we call Save()
							$this->blnDirtyLogin = true;

							// Update Local Member Variable
							$this->objLogin = $mixValue;
						} else {
							// Nope -- therefore, make no changes
						}

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'Profile':
					/**
					 * Sets the value for the Profile object referenced by objProfile (Unique)
					 * @param Profile $mixValue
					 * @return Profile
					 */
					if (is_null($mixValue)) {
						$this->objProfile = null;

						// Make sure we update the adjoined Profile object the next time we call Save()
						$this->blnDirtyProfile = true;

						return null;
					} else {
						// Make sure $mixValue actually is a Profile object
						try {
							$mixValue = QType::Cast($mixValue, 'Profile');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Are we setting objProfile to a DIFFERENT $mixValue?
						if ((!$this->Profile) || ($this->Profile->Idprofile != $mixValue->Idprofile)) {
							// Yes -- therefore, set the "Dirty" flag to true
							// to make sure we update the adjoined Profile object the next time we call Save()
							$this->blnDirtyProfile = true;

							// Update Local Member Variable
							$this->objProfile = $mixValue;
						} else {
							// Nope -- therefore, make no changes
						}

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for AddressAsOf
		//-------------------------------------------------------------------

		/**
		 * Gets all associated AddressesAsOf as an array of Address objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Address[]
		*/
		public function GetAddressAsOfArray($objOptionalClauses = null) {
			if ((is_null($this->intIdledger)))
				return array();

			try {
				return Address::LoadArrayByOf($this->intIdledger, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated AddressesAsOf
		 * @return int
		*/
		public function CountAddressesAsOf() {
			if ((is_null($this->intIdledger)))
				return 0;

			return Address::CountByOf($this->intIdledger);
		}

		/**
		 * Associates a AddressAsOf
		 * @param Address $objAddress
		 * @return void
		*/
		public function AssociateAddressAsOf(Address $objAddress) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAddressAsOf on this unsaved Ledger.');
			if ((is_null($objAddress->Idaddress)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAddressAsOf on this Ledger with an unsaved Address.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`address`
				SET
					`of` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
				WHERE
					`idaddress` = ' . $objDatabase->SqlVariable($objAddress->Idaddress) . '
			');
		}

		/**
		 * Unassociates a AddressAsOf
		 * @param Address $objAddress
		 * @return void
		*/
		public function UnassociateAddressAsOf(Address $objAddress) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAddressAsOf on this unsaved Ledger.');
			if ((is_null($objAddress->Idaddress)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAddressAsOf on this Ledger with an unsaved Address.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`address`
				SET
					`of` = null
				WHERE
					`idaddress` = ' . $objDatabase->SqlVariable($objAddress->Idaddress) . ' AND
					`of` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Unassociates all AddressesAsOf
		 * @return void
		*/
		public function UnassociateAllAddressesAsOf() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAddressAsOf on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`address`
				SET
					`of` = null
				WHERE
					`of` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes an associated AddressAsOf
		 * @param Address $objAddress
		 * @return void
		*/
		public function DeleteAssociatedAddressAsOf(Address $objAddress) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAddressAsOf on this unsaved Ledger.');
			if ((is_null($objAddress->Idaddress)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAddressAsOf on this Ledger with an unsaved Address.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`address`
				WHERE
					`idaddress` = ' . $objDatabase->SqlVariable($objAddress->Idaddress) . ' AND
					`of` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes all associated AddressesAsOf
		 * @return void
		*/
		public function DeleteAllAddressesAsOf() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAddressAsOf on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`address`
				WHERE
					`of` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}


		// Related Objects' Methods for AppDocsAsDocument
		//-------------------------------------------------------------------

		/**
		 * Gets all associated AppDocsesAsDocument as an array of AppDocs objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppDocs[]
		*/
		public function GetAppDocsAsDocumentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdledger)))
				return array();

			try {
				return AppDocs::LoadArrayByDocument($this->intIdledger, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated AppDocsesAsDocument
		 * @return int
		*/
		public function CountAppDocsesAsDocument() {
			if ((is_null($this->intIdledger)))
				return 0;

			return AppDocs::CountByDocument($this->intIdledger);
		}

		/**
		 * Associates a AppDocsAsDocument
		 * @param AppDocs $objAppDocs
		 * @return void
		*/
		public function AssociateAppDocsAsDocument(AppDocs $objAppDocs) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppDocsAsDocument on this unsaved Ledger.');
			if ((is_null($objAppDocs->IdappDocs)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppDocsAsDocument on this Ledger with an unsaved AppDocs.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`app_docs`
				SET
					`document` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
				WHERE
					`idapp_docs` = ' . $objDatabase->SqlVariable($objAppDocs->IdappDocs) . '
			');
		}

		/**
		 * Unassociates a AppDocsAsDocument
		 * @param AppDocs $objAppDocs
		 * @return void
		*/
		public function UnassociateAppDocsAsDocument(AppDocs $objAppDocs) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppDocsAsDocument on this unsaved Ledger.');
			if ((is_null($objAppDocs->IdappDocs)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppDocsAsDocument on this Ledger with an unsaved AppDocs.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`app_docs`
				SET
					`document` = null
				WHERE
					`idapp_docs` = ' . $objDatabase->SqlVariable($objAppDocs->IdappDocs) . ' AND
					`document` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Unassociates all AppDocsesAsDocument
		 * @return void
		*/
		public function UnassociateAllAppDocsesAsDocument() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppDocsAsDocument on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`app_docs`
				SET
					`document` = null
				WHERE
					`document` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes an associated AppDocsAsDocument
		 * @param AppDocs $objAppDocs
		 * @return void
		*/
		public function DeleteAssociatedAppDocsAsDocument(AppDocs $objAppDocs) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppDocsAsDocument on this unsaved Ledger.');
			if ((is_null($objAppDocs->IdappDocs)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppDocsAsDocument on this Ledger with an unsaved AppDocs.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`app_docs`
				WHERE
					`idapp_docs` = ' . $objDatabase->SqlVariable($objAppDocs->IdappDocs) . ' AND
					`document` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes all associated AppDocsesAsDocument
		 * @return void
		*/
		public function DeleteAllAppDocsesAsDocument() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppDocsAsDocument on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`app_docs`
				WHERE
					`document` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}


		// Related Objects' Methods for FeesTempletAsFees
		//-------------------------------------------------------------------

		/**
		 * Gets all associated FeesTempletsAsFees as an array of FeesTemplet objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return FeesTemplet[]
		*/
		public function GetFeesTempletAsFeesArray($objOptionalClauses = null) {
			if ((is_null($this->intIdledger)))
				return array();

			try {
				return FeesTemplet::LoadArrayByFees($this->intIdledger, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated FeesTempletsAsFees
		 * @return int
		*/
		public function CountFeesTempletsAsFees() {
			if ((is_null($this->intIdledger)))
				return 0;

			return FeesTemplet::CountByFees($this->intIdledger);
		}

		/**
		 * Associates a FeesTempletAsFees
		 * @param FeesTemplet $objFeesTemplet
		 * @return void
		*/
		public function AssociateFeesTempletAsFees(FeesTemplet $objFeesTemplet) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateFeesTempletAsFees on this unsaved Ledger.');
			if ((is_null($objFeesTemplet->IdfeesTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateFeesTempletAsFees on this Ledger with an unsaved FeesTemplet.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`fees_templet`
				SET
					`fees` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
				WHERE
					`idfees_templet` = ' . $objDatabase->SqlVariable($objFeesTemplet->IdfeesTemplet) . '
			');
		}

		/**
		 * Unassociates a FeesTempletAsFees
		 * @param FeesTemplet $objFeesTemplet
		 * @return void
		*/
		public function UnassociateFeesTempletAsFees(FeesTemplet $objFeesTemplet) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsFees on this unsaved Ledger.');
			if ((is_null($objFeesTemplet->IdfeesTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsFees on this Ledger with an unsaved FeesTemplet.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`fees_templet`
				SET
					`fees` = null
				WHERE
					`idfees_templet` = ' . $objDatabase->SqlVariable($objFeesTemplet->IdfeesTemplet) . ' AND
					`fees` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Unassociates all FeesTempletsAsFees
		 * @return void
		*/
		public function UnassociateAllFeesTempletsAsFees() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsFees on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`fees_templet`
				SET
					`fees` = null
				WHERE
					`fees` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes an associated FeesTempletAsFees
		 * @param FeesTemplet $objFeesTemplet
		 * @return void
		*/
		public function DeleteAssociatedFeesTempletAsFees(FeesTemplet $objFeesTemplet) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsFees on this unsaved Ledger.');
			if ((is_null($objFeesTemplet->IdfeesTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsFees on this Ledger with an unsaved FeesTemplet.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`fees_templet`
				WHERE
					`idfees_templet` = ' . $objDatabase->SqlVariable($objFeesTemplet->IdfeesTemplet) . ' AND
					`fees` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes all associated FeesTempletsAsFees
		 * @return void
		*/
		public function DeleteAllFeesTempletsAsFees() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsFees on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`fees_templet`
				WHERE
					`fees` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}


		// Related Objects' Methods for FeesTempletAsConcession
		//-------------------------------------------------------------------

		/**
		 * Gets all associated FeesTempletsAsConcession as an array of FeesTemplet objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return FeesTemplet[]
		*/
		public function GetFeesTempletAsConcessionArray($objOptionalClauses = null) {
			if ((is_null($this->intIdledger)))
				return array();

			try {
				return FeesTemplet::LoadArrayByConcession($this->intIdledger, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated FeesTempletsAsConcession
		 * @return int
		*/
		public function CountFeesTempletsAsConcession() {
			if ((is_null($this->intIdledger)))
				return 0;

			return FeesTemplet::CountByConcession($this->intIdledger);
		}

		/**
		 * Associates a FeesTempletAsConcession
		 * @param FeesTemplet $objFeesTemplet
		 * @return void
		*/
		public function AssociateFeesTempletAsConcession(FeesTemplet $objFeesTemplet) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateFeesTempletAsConcession on this unsaved Ledger.');
			if ((is_null($objFeesTemplet->IdfeesTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateFeesTempletAsConcession on this Ledger with an unsaved FeesTemplet.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`fees_templet`
				SET
					`concession` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
				WHERE
					`idfees_templet` = ' . $objDatabase->SqlVariable($objFeesTemplet->IdfeesTemplet) . '
			');
		}

		/**
		 * Unassociates a FeesTempletAsConcession
		 * @param FeesTemplet $objFeesTemplet
		 * @return void
		*/
		public function UnassociateFeesTempletAsConcession(FeesTemplet $objFeesTemplet) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsConcession on this unsaved Ledger.');
			if ((is_null($objFeesTemplet->IdfeesTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsConcession on this Ledger with an unsaved FeesTemplet.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`fees_templet`
				SET
					`concession` = null
				WHERE
					`idfees_templet` = ' . $objDatabase->SqlVariable($objFeesTemplet->IdfeesTemplet) . ' AND
					`concession` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Unassociates all FeesTempletsAsConcession
		 * @return void
		*/
		public function UnassociateAllFeesTempletsAsConcession() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsConcession on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`fees_templet`
				SET
					`concession` = null
				WHERE
					`concession` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes an associated FeesTempletAsConcession
		 * @param FeesTemplet $objFeesTemplet
		 * @return void
		*/
		public function DeleteAssociatedFeesTempletAsConcession(FeesTemplet $objFeesTemplet) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsConcession on this unsaved Ledger.');
			if ((is_null($objFeesTemplet->IdfeesTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsConcession on this Ledger with an unsaved FeesTemplet.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`fees_templet`
				WHERE
					`idfees_templet` = ' . $objDatabase->SqlVariable($objFeesTemplet->IdfeesTemplet) . ' AND
					`concession` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes all associated FeesTempletsAsConcession
		 * @return void
		*/
		public function DeleteAllFeesTempletsAsConcession() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsConcession on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`fees_templet`
				WHERE
					`concession` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}


		// Related Objects' Methods for FeesTempletAsSource
		//-------------------------------------------------------------------

		/**
		 * Gets all associated FeesTempletsAsSource as an array of FeesTemplet objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return FeesTemplet[]
		*/
		public function GetFeesTempletAsSourceArray($objOptionalClauses = null) {
			if ((is_null($this->intIdledger)))
				return array();

			try {
				return FeesTemplet::LoadArrayBySource($this->intIdledger, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated FeesTempletsAsSource
		 * @return int
		*/
		public function CountFeesTempletsAsSource() {
			if ((is_null($this->intIdledger)))
				return 0;

			return FeesTemplet::CountBySource($this->intIdledger);
		}

		/**
		 * Associates a FeesTempletAsSource
		 * @param FeesTemplet $objFeesTemplet
		 * @return void
		*/
		public function AssociateFeesTempletAsSource(FeesTemplet $objFeesTemplet) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateFeesTempletAsSource on this unsaved Ledger.');
			if ((is_null($objFeesTemplet->IdfeesTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateFeesTempletAsSource on this Ledger with an unsaved FeesTemplet.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`fees_templet`
				SET
					`source` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
				WHERE
					`idfees_templet` = ' . $objDatabase->SqlVariable($objFeesTemplet->IdfeesTemplet) . '
			');
		}

		/**
		 * Unassociates a FeesTempletAsSource
		 * @param FeesTemplet $objFeesTemplet
		 * @return void
		*/
		public function UnassociateFeesTempletAsSource(FeesTemplet $objFeesTemplet) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsSource on this unsaved Ledger.');
			if ((is_null($objFeesTemplet->IdfeesTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsSource on this Ledger with an unsaved FeesTemplet.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`fees_templet`
				SET
					`source` = null
				WHERE
					`idfees_templet` = ' . $objDatabase->SqlVariable($objFeesTemplet->IdfeesTemplet) . ' AND
					`source` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Unassociates all FeesTempletsAsSource
		 * @return void
		*/
		public function UnassociateAllFeesTempletsAsSource() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsSource on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`fees_templet`
				SET
					`source` = null
				WHERE
					`source` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes an associated FeesTempletAsSource
		 * @param FeesTemplet $objFeesTemplet
		 * @return void
		*/
		public function DeleteAssociatedFeesTempletAsSource(FeesTemplet $objFeesTemplet) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsSource on this unsaved Ledger.');
			if ((is_null($objFeesTemplet->IdfeesTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsSource on this Ledger with an unsaved FeesTemplet.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`fees_templet`
				WHERE
					`idfees_templet` = ' . $objDatabase->SqlVariable($objFeesTemplet->IdfeesTemplet) . ' AND
					`source` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes all associated FeesTempletsAsSource
		 * @return void
		*/
		public function DeleteAllFeesTempletsAsSource() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsSource on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`fees_templet`
				WHERE
					`source` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}


		// Related Objects' Methods for LedgerAsGrp
		//-------------------------------------------------------------------

		/**
		 * Gets all associated LedgersAsGrp as an array of Ledger objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Ledger[]
		*/
		public function GetLedgerAsGrpArray($objOptionalClauses = null) {
			if ((is_null($this->intIdledger)))
				return array();

			try {
				return Ledger::LoadArrayByGrp($this->intIdledger, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated LedgersAsGrp
		 * @return int
		*/
		public function CountLedgersAsGrp() {
			if ((is_null($this->intIdledger)))
				return 0;

			return Ledger::CountByGrp($this->intIdledger);
		}

		/**
		 * Associates a LedgerAsGrp
		 * @param Ledger $objLedger
		 * @return void
		*/
		public function AssociateLedgerAsGrp(Ledger $objLedger) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLedgerAsGrp on this unsaved Ledger.');
			if ((is_null($objLedger->Idledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLedgerAsGrp on this Ledger with an unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`ledger`
				SET
					`grp` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
				WHERE
					`idledger` = ' . $objDatabase->SqlVariable($objLedger->Idledger) . '
			');
		}

		/**
		 * Unassociates a LedgerAsGrp
		 * @param Ledger $objLedger
		 * @return void
		*/
		public function UnassociateLedgerAsGrp(Ledger $objLedger) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLedgerAsGrp on this unsaved Ledger.');
			if ((is_null($objLedger->Idledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLedgerAsGrp on this Ledger with an unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`ledger`
				SET
					`grp` = null
				WHERE
					`idledger` = ' . $objDatabase->SqlVariable($objLedger->Idledger) . ' AND
					`grp` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Unassociates all LedgersAsGrp
		 * @return void
		*/
		public function UnassociateAllLedgersAsGrp() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLedgerAsGrp on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`ledger`
				SET
					`grp` = null
				WHERE
					`grp` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes an associated LedgerAsGrp
		 * @param Ledger $objLedger
		 * @return void
		*/
		public function DeleteAssociatedLedgerAsGrp(Ledger $objLedger) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLedgerAsGrp on this unsaved Ledger.');
			if ((is_null($objLedger->Idledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLedgerAsGrp on this Ledger with an unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`ledger`
				WHERE
					`idledger` = ' . $objDatabase->SqlVariable($objLedger->Idledger) . ' AND
					`grp` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes all associated LedgersAsGrp
		 * @return void
		*/
		public function DeleteAllLedgersAsGrp() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLedgerAsGrp on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`ledger`
				WHERE
					`grp` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}


		// Related Objects' Methods for TempletDocumentsAsDocument
		//-------------------------------------------------------------------

		/**
		 * Gets all associated TempletDocumentsesAsDocument as an array of TempletDocuments objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return TempletDocuments[]
		*/
		public function GetTempletDocumentsAsDocumentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdledger)))
				return array();

			try {
				return TempletDocuments::LoadArrayByDocument($this->intIdledger, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated TempletDocumentsesAsDocument
		 * @return int
		*/
		public function CountTempletDocumentsesAsDocument() {
			if ((is_null($this->intIdledger)))
				return 0;

			return TempletDocuments::CountByDocument($this->intIdledger);
		}

		/**
		 * Associates a TempletDocumentsAsDocument
		 * @param TempletDocuments $objTempletDocuments
		 * @return void
		*/
		public function AssociateTempletDocumentsAsDocument(TempletDocuments $objTempletDocuments) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateTempletDocumentsAsDocument on this unsaved Ledger.');
			if ((is_null($objTempletDocuments->IdtempletDocuments)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateTempletDocumentsAsDocument on this Ledger with an unsaved TempletDocuments.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`templet_documents`
				SET
					`document` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
				WHERE
					`idtemplet_documents` = ' . $objDatabase->SqlVariable($objTempletDocuments->IdtempletDocuments) . '
			');
		}

		/**
		 * Unassociates a TempletDocumentsAsDocument
		 * @param TempletDocuments $objTempletDocuments
		 * @return void
		*/
		public function UnassociateTempletDocumentsAsDocument(TempletDocuments $objTempletDocuments) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTempletDocumentsAsDocument on this unsaved Ledger.');
			if ((is_null($objTempletDocuments->IdtempletDocuments)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTempletDocumentsAsDocument on this Ledger with an unsaved TempletDocuments.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`templet_documents`
				SET
					`document` = null
				WHERE
					`idtemplet_documents` = ' . $objDatabase->SqlVariable($objTempletDocuments->IdtempletDocuments) . ' AND
					`document` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Unassociates all TempletDocumentsesAsDocument
		 * @return void
		*/
		public function UnassociateAllTempletDocumentsesAsDocument() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTempletDocumentsAsDocument on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`templet_documents`
				SET
					`document` = null
				WHERE
					`document` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes an associated TempletDocumentsAsDocument
		 * @param TempletDocuments $objTempletDocuments
		 * @return void
		*/
		public function DeleteAssociatedTempletDocumentsAsDocument(TempletDocuments $objTempletDocuments) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTempletDocumentsAsDocument on this unsaved Ledger.');
			if ((is_null($objTempletDocuments->IdtempletDocuments)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTempletDocumentsAsDocument on this Ledger with an unsaved TempletDocuments.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`templet_documents`
				WHERE
					`idtemplet_documents` = ' . $objDatabase->SqlVariable($objTempletDocuments->IdtempletDocuments) . ' AND
					`document` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes all associated TempletDocumentsesAsDocument
		 * @return void
		*/
		public function DeleteAllTempletDocumentsesAsDocument() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTempletDocumentsAsDocument on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`templet_documents`
				WHERE
					`document` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}


		// Related Objects' Methods for VoucherAsDr
		//-------------------------------------------------------------------

		/**
		 * Gets all associated VouchersAsDr as an array of Voucher objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Voucher[]
		*/
		public function GetVoucherAsDrArray($objOptionalClauses = null) {
			if ((is_null($this->intIdledger)))
				return array();

			try {
				return Voucher::LoadArrayByDr($this->intIdledger, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated VouchersAsDr
		 * @return int
		*/
		public function CountVouchersAsDr() {
			if ((is_null($this->intIdledger)))
				return 0;

			return Voucher::CountByDr($this->intIdledger);
		}

		/**
		 * Associates a VoucherAsDr
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function AssociateVoucherAsDr(Voucher $objVoucher) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherAsDr on this unsaved Ledger.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherAsDr on this Ledger with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`dr` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . '
			');
		}

		/**
		 * Unassociates a VoucherAsDr
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function UnassociateVoucherAsDr(Voucher $objVoucher) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsDr on this unsaved Ledger.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsDr on this Ledger with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`dr` = null
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . ' AND
					`dr` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Unassociates all VouchersAsDr
		 * @return void
		*/
		public function UnassociateAllVouchersAsDr() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsDr on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`dr` = null
				WHERE
					`dr` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes an associated VoucherAsDr
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function DeleteAssociatedVoucherAsDr(Voucher $objVoucher) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsDr on this unsaved Ledger.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsDr on this Ledger with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher`
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . ' AND
					`dr` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes all associated VouchersAsDr
		 * @return void
		*/
		public function DeleteAllVouchersAsDr() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsDr on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher`
				WHERE
					`dr` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}


		// Related Objects' Methods for VoucherAsCr
		//-------------------------------------------------------------------

		/**
		 * Gets all associated VouchersAsCr as an array of Voucher objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Voucher[]
		*/
		public function GetVoucherAsCrArray($objOptionalClauses = null) {
			if ((is_null($this->intIdledger)))
				return array();

			try {
				return Voucher::LoadArrayByCr($this->intIdledger, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated VouchersAsCr
		 * @return int
		*/
		public function CountVouchersAsCr() {
			if ((is_null($this->intIdledger)))
				return 0;

			return Voucher::CountByCr($this->intIdledger);
		}

		/**
		 * Associates a VoucherAsCr
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function AssociateVoucherAsCr(Voucher $objVoucher) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherAsCr on this unsaved Ledger.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherAsCr on this Ledger with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`cr` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . '
			');
		}

		/**
		 * Unassociates a VoucherAsCr
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function UnassociateVoucherAsCr(Voucher $objVoucher) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsCr on this unsaved Ledger.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsCr on this Ledger with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`cr` = null
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . ' AND
					`cr` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Unassociates all VouchersAsCr
		 * @return void
		*/
		public function UnassociateAllVouchersAsCr() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsCr on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`cr` = null
				WHERE
					`cr` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes an associated VoucherAsCr
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function DeleteAssociatedVoucherAsCr(Voucher $objVoucher) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsCr on this unsaved Ledger.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsCr on this Ledger with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher`
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . ' AND
					`cr` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes all associated VouchersAsCr
		 * @return void
		*/
		public function DeleteAllVouchersAsCr() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsCr on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher`
				WHERE
					`cr` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}


		// Related Objects' Methods for VoucherAsDataBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated VouchersAsDataBy as an array of Voucher objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Voucher[]
		*/
		public function GetVoucherAsDataByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdledger)))
				return array();

			try {
				return Voucher::LoadArrayByDataBy($this->intIdledger, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated VouchersAsDataBy
		 * @return int
		*/
		public function CountVouchersAsDataBy() {
			if ((is_null($this->intIdledger)))
				return 0;

			return Voucher::CountByDataBy($this->intIdledger);
		}

		/**
		 * Associates a VoucherAsDataBy
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function AssociateVoucherAsDataBy(Voucher $objVoucher) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherAsDataBy on this unsaved Ledger.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherAsDataBy on this Ledger with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . '
			');
		}

		/**
		 * Unassociates a VoucherAsDataBy
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function UnassociateVoucherAsDataBy(Voucher $objVoucher) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsDataBy on this unsaved Ledger.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsDataBy on this Ledger with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`data_by` = null
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . ' AND
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Unassociates all VouchersAsDataBy
		 * @return void
		*/
		public function UnassociateAllVouchersAsDataBy() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsDataBy on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`data_by` = null
				WHERE
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes an associated VoucherAsDataBy
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function DeleteAssociatedVoucherAsDataBy(Voucher $objVoucher) {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsDataBy on this unsaved Ledger.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsDataBy on this Ledger with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher`
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . ' AND
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}

		/**
		 * Deletes all associated VouchersAsDataBy
		 * @return void
		*/
		public function DeleteAllVouchersAsDataBy() {
			if ((is_null($this->intIdledger)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsDataBy on this unsaved Ledger.');

			// Get the Database Object for this Class
			$objDatabase = Ledger::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher`
				WHERE
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdledger) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "ledger";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Ledger::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Ledger"><sequence>';
			$strToReturn .= '<element name="Idledger" type="xsd:int"/>';
			$strToReturn .= '<element name="Code" type="xsd:string"/>';
			$strToReturn .= '<element name="Name" type="xsd:string"/>';
			$strToReturn .= '<element name="GrpObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="IsGrp" type="xsd:boolean"/>';
			$strToReturn .= '<element name="Description" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Ledger', $strComplexTypeArray)) {
				$strComplexTypeArray['Ledger'] = Ledger::GetSoapComplexTypeXml();
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Ledger::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Ledger();
			if (property_exists($objSoapObject, 'Idledger'))
				$objToReturn->intIdledger = $objSoapObject->Idledger;
			if (property_exists($objSoapObject, 'Code'))
				$objToReturn->strCode = $objSoapObject->Code;
			if (property_exists($objSoapObject, 'Name'))
				$objToReturn->strName = $objSoapObject->Name;
			if ((property_exists($objSoapObject, 'GrpObject')) &&
				($objSoapObject->GrpObject))
				$objToReturn->GrpObject = Ledger::GetObjectFromSoapObject($objSoapObject->GrpObject);
			if (property_exists($objSoapObject, 'IsGrp'))
				$objToReturn->blnIsGrp = $objSoapObject->IsGrp;
			if (property_exists($objSoapObject, 'Description'))
				$objToReturn->strDescription = $objSoapObject->Description;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Ledger::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objGrpObject)
				$objObject->objGrpObject = Ledger::GetSoapObjectFromObject($objObject->objGrpObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intGrp = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idledger'] = $this->intIdledger;
			$iArray['Code'] = $this->strCode;
			$iArray['Name'] = $this->strName;
			$iArray['Grp'] = $this->intGrp;
			$iArray['IsGrp'] = $this->blnIsGrp;
			$iArray['Description'] = $this->strDescription;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdledger ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idledger
     * @property-read QQNode $Code
     * @property-read QQNode $Name
     * @property-read QQNode $Grp
     * @property-read QQNodeLedger $GrpObject
     * @property-read QQNode $IsGrp
     * @property-read QQNode $Description
     *
     *
     * @property-read QQReverseReferenceNodeAddress $AddressAsOf
     * @property-read QQReverseReferenceNodeAppDocs $AppDocsAsDocument
     * @property-read QQReverseReferenceNodeFeesTemplet $FeesTempletAsFees
     * @property-read QQReverseReferenceNodeFeesTemplet $FeesTempletAsConcession
     * @property-read QQReverseReferenceNodeFeesTemplet $FeesTempletAsSource
     * @property-read QQReverseReferenceNodeLedger $LedgerAsGrp
     * @property-read QQReverseReferenceNodeLedgerDetails $LedgerDetails
     * @property-read QQReverseReferenceNodeLogin $Login
     * @property-read QQReverseReferenceNodeProfile $Profile
     * @property-read QQReverseReferenceNodeTempletDocuments $TempletDocumentsAsDocument
     * @property-read QQReverseReferenceNodeVoucher $VoucherAsDr
     * @property-read QQReverseReferenceNodeVoucher $VoucherAsCr
     * @property-read QQReverseReferenceNodeVoucher $VoucherAsDataBy

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeLedger extends QQNode {
		protected $strTableName = 'ledger';
		protected $strPrimaryKey = 'idledger';
		protected $strClassName = 'Ledger';
		public function __get($strName) {
			switch ($strName) {
				case 'Idledger':
					return new QQNode('idledger', 'Idledger', 'Integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'VarChar', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'VarChar', $this);
				case 'Grp':
					return new QQNode('grp', 'Grp', 'Integer', $this);
				case 'GrpObject':
					return new QQNodeLedger('grp', 'GrpObject', 'Integer', $this);
				case 'IsGrp':
					return new QQNode('is_grp', 'IsGrp', 'Bit', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'VarChar', $this);
				case 'AddressAsOf':
					return new QQReverseReferenceNodeAddress($this, 'addressasof', 'reverse_reference', 'of');
				case 'AppDocsAsDocument':
					return new QQReverseReferenceNodeAppDocs($this, 'appdocsasdocument', 'reverse_reference', 'document');
				case 'FeesTempletAsFees':
					return new QQReverseReferenceNodeFeesTemplet($this, 'feestempletasfees', 'reverse_reference', 'fees');
				case 'FeesTempletAsConcession':
					return new QQReverseReferenceNodeFeesTemplet($this, 'feestempletasconcession', 'reverse_reference', 'concession');
				case 'FeesTempletAsSource':
					return new QQReverseReferenceNodeFeesTemplet($this, 'feestempletassource', 'reverse_reference', 'source');
				case 'LedgerAsGrp':
					return new QQReverseReferenceNodeLedger($this, 'ledgerasgrp', 'reverse_reference', 'grp');
				case 'LedgerDetails':
					return new QQReverseReferenceNodeLedgerDetails($this, 'ledgerdetails', 'reverse_reference', 'idledger_details', 'LedgerDetails');
				case 'Login':
					return new QQReverseReferenceNodeLogin($this, 'login', 'reverse_reference', 'idlogin', 'Login');
				case 'Profile':
					return new QQReverseReferenceNodeProfile($this, 'profile', 'reverse_reference', 'idprofile', 'Profile');
				case 'TempletDocumentsAsDocument':
					return new QQReverseReferenceNodeTempletDocuments($this, 'templetdocumentsasdocument', 'reverse_reference', 'document');
				case 'VoucherAsDr':
					return new QQReverseReferenceNodeVoucher($this, 'voucherasdr', 'reverse_reference', 'dr');
				case 'VoucherAsCr':
					return new QQReverseReferenceNodeVoucher($this, 'voucherascr', 'reverse_reference', 'cr');
				case 'VoucherAsDataBy':
					return new QQReverseReferenceNodeVoucher($this, 'voucherasdataby', 'reverse_reference', 'data_by');

				case '_PrimaryKeyNode':
					return new QQNode('idledger', 'Idledger', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idledger
     * @property-read QQNode $Code
     * @property-read QQNode $Name
     * @property-read QQNode $Grp
     * @property-read QQNodeLedger $GrpObject
     * @property-read QQNode $IsGrp
     * @property-read QQNode $Description
     *
     *
     * @property-read QQReverseReferenceNodeAddress $AddressAsOf
     * @property-read QQReverseReferenceNodeAppDocs $AppDocsAsDocument
     * @property-read QQReverseReferenceNodeFeesTemplet $FeesTempletAsFees
     * @property-read QQReverseReferenceNodeFeesTemplet $FeesTempletAsConcession
     * @property-read QQReverseReferenceNodeFeesTemplet $FeesTempletAsSource
     * @property-read QQReverseReferenceNodeLedger $LedgerAsGrp
     * @property-read QQReverseReferenceNodeLedgerDetails $LedgerDetails
     * @property-read QQReverseReferenceNodeLogin $Login
     * @property-read QQReverseReferenceNodeProfile $Profile
     * @property-read QQReverseReferenceNodeTempletDocuments $TempletDocumentsAsDocument
     * @property-read QQReverseReferenceNodeVoucher $VoucherAsDr
     * @property-read QQReverseReferenceNodeVoucher $VoucherAsCr
     * @property-read QQReverseReferenceNodeVoucher $VoucherAsDataBy

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeLedger extends QQReverseReferenceNode {
		protected $strTableName = 'ledger';
		protected $strPrimaryKey = 'idledger';
		protected $strClassName = 'Ledger';
		public function __get($strName) {
			switch ($strName) {
				case 'Idledger':
					return new QQNode('idledger', 'Idledger', 'integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'string', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'string', $this);
				case 'Grp':
					return new QQNode('grp', 'Grp', 'integer', $this);
				case 'GrpObject':
					return new QQNodeLedger('grp', 'GrpObject', 'integer', $this);
				case 'IsGrp':
					return new QQNode('is_grp', 'IsGrp', 'boolean', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'string', $this);
				case 'AddressAsOf':
					return new QQReverseReferenceNodeAddress($this, 'addressasof', 'reverse_reference', 'of');
				case 'AppDocsAsDocument':
					return new QQReverseReferenceNodeAppDocs($this, 'appdocsasdocument', 'reverse_reference', 'document');
				case 'FeesTempletAsFees':
					return new QQReverseReferenceNodeFeesTemplet($this, 'feestempletasfees', 'reverse_reference', 'fees');
				case 'FeesTempletAsConcession':
					return new QQReverseReferenceNodeFeesTemplet($this, 'feestempletasconcession', 'reverse_reference', 'concession');
				case 'FeesTempletAsSource':
					return new QQReverseReferenceNodeFeesTemplet($this, 'feestempletassource', 'reverse_reference', 'source');
				case 'LedgerAsGrp':
					return new QQReverseReferenceNodeLedger($this, 'ledgerasgrp', 'reverse_reference', 'grp');
				case 'LedgerDetails':
					return new QQReverseReferenceNodeLedgerDetails($this, 'ledgerdetails', 'reverse_reference', 'idledger_details', 'LedgerDetails');
				case 'Login':
					return new QQReverseReferenceNodeLogin($this, 'login', 'reverse_reference', 'idlogin', 'Login');
				case 'Profile':
					return new QQReverseReferenceNodeProfile($this, 'profile', 'reverse_reference', 'idprofile', 'Profile');
				case 'TempletDocumentsAsDocument':
					return new QQReverseReferenceNodeTempletDocuments($this, 'templetdocumentsasdocument', 'reverse_reference', 'document');
				case 'VoucherAsDr':
					return new QQReverseReferenceNodeVoucher($this, 'voucherasdr', 'reverse_reference', 'dr');
				case 'VoucherAsCr':
					return new QQReverseReferenceNodeVoucher($this, 'voucherascr', 'reverse_reference', 'cr');
				case 'VoucherAsDataBy':
					return new QQReverseReferenceNodeVoucher($this, 'voucherasdataby', 'reverse_reference', 'data_by');

				case '_PrimaryKeyNode':
					return new QQNode('idledger', 'Idledger', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
