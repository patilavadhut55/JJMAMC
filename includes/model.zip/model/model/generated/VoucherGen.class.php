<?php
	/**
	 * The abstract VoucherGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Voucher subclass which
	 * extends this VoucherGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Voucher class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idvoucher the value for intIdvoucher (Read-Only PK)
	 * @property string $InvNo the value for strInvNo (Unique)
	 * @property QDateTime $Date the value for dttDate (Not Null)
	 * @property integer $Dr the value for intDr 
	 * @property integer $Cr the value for intCr 
	 * @property string $Amount the value for strAmount (Not Null)
	 * @property string $Narration the value for strNarration 
	 * @property integer $Parrent the value for intParrent 
	 * @property string $RefNo the value for strRefNo 
	 * @property integer $Grp the value for intGrp (Not Null)
	 * @property integer $DataBy the value for intDataBy 
	 * @property Ledger $DrObject the value for the Ledger object referenced by intDr 
	 * @property Ledger $CrObject the value for the Ledger object referenced by intCr 
	 * @property Voucher $ParrentObject the value for the Voucher object referenced by intParrent 
	 * @property VoucherGrp $GrpObject the value for the VoucherGrp object referenced by intGrp (Not Null)
	 * @property Ledger $DataByObject the value for the Ledger object referenced by intDataBy 
	 * @property-read Voucher $_VoucherAsParrent the value for the private _objVoucherAsParrent (Read-Only) if set due to an expansion on the voucher.parrent reverse relationship
	 * @property-read Voucher[] $_VoucherAsParrentArray the value for the private _objVoucherAsParrentArray (Read-Only) if set due to an ExpandAsArray on the voucher.parrent reverse relationship
	 * @property-read VoucherHasItem $_VoucherHasItem the value for the private _objVoucherHasItem (Read-Only) if set due to an expansion on the voucher_has_item.voucher reverse relationship
	 * @property-read VoucherHasItem[] $_VoucherHasItemArray the value for the private _objVoucherHasItemArray (Read-Only) if set due to an ExpandAsArray on the voucher_has_item.voucher reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class VoucherGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column voucher.idvoucher
		 * @var integer intIdvoucher
		 */
		protected $intIdvoucher;
		const IdvoucherDefault = null;


		/**
		 * Protected member variable that maps to the database column voucher.inv_no
		 * @var string strInvNo
		 */
		protected $strInvNo;
		const InvNoMaxLength = 45;
		const InvNoDefault = null;


		/**
		 * Protected member variable that maps to the database column voucher.date
		 * @var QDateTime dttDate
		 */
		protected $dttDate;
		const DateDefault = null;


		/**
		 * Protected member variable that maps to the database column voucher.dr
		 * @var integer intDr
		 */
		protected $intDr;
		const DrDefault = null;


		/**
		 * Protected member variable that maps to the database column voucher.cr
		 * @var integer intCr
		 */
		protected $intCr;
		const CrDefault = null;


		/**
		 * Protected member variable that maps to the database column voucher.amount
		 * @var string strAmount
		 */
		protected $strAmount;
		const AmountDefault = null;


		/**
		 * Protected member variable that maps to the database column voucher.narration
		 * @var string strNarration
		 */
		protected $strNarration;
		const NarrationDefault = null;


		/**
		 * Protected member variable that maps to the database column voucher.parrent
		 * @var integer intParrent
		 */
		protected $intParrent;
		const ParrentDefault = null;


		/**
		 * Protected member variable that maps to the database column voucher.ref_no
		 * @var string strRefNo
		 */
		protected $strRefNo;
		const RefNoMaxLength = 45;
		const RefNoDefault = null;


		/**
		 * Protected member variable that maps to the database column voucher.grp
		 * @var integer intGrp
		 */
		protected $intGrp;
		const GrpDefault = null;


		/**
		 * Protected member variable that maps to the database column voucher.data_by
		 * @var integer intDataBy
		 */
		protected $intDataBy;
		const DataByDefault = null;


		/**
		 * Private member variable that stores a reference to a single VoucherAsParrent object
		 * (of type Voucher), if this Voucher object was restored with
		 * an expansion on the voucher association table.
		 * @var Voucher _objVoucherAsParrent;
		 */
		private $_objVoucherAsParrent;

		/**
		 * Private member variable that stores a reference to an array of VoucherAsParrent objects
		 * (of type Voucher[]), if this Voucher object was restored with
		 * an ExpandAsArray on the voucher association table.
		 * @var Voucher[] _objVoucherAsParrentArray;
		 */
		private $_objVoucherAsParrentArray = null;

		/**
		 * Private member variable that stores a reference to a single VoucherHasItem object
		 * (of type VoucherHasItem), if this Voucher object was restored with
		 * an expansion on the voucher_has_item association table.
		 * @var VoucherHasItem _objVoucherHasItem;
		 */
		private $_objVoucherHasItem;

		/**
		 * Private member variable that stores a reference to an array of VoucherHasItem objects
		 * (of type VoucherHasItem[]), if this Voucher object was restored with
		 * an ExpandAsArray on the voucher_has_item association table.
		 * @var VoucherHasItem[] _objVoucherHasItemArray;
		 */
		private $_objVoucherHasItemArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column voucher.dr.
		 *
		 * NOTE: Always use the DrObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objDrObject
		 */
		protected $objDrObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column voucher.cr.
		 *
		 * NOTE: Always use the CrObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objCrObject
		 */
		protected $objCrObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column voucher.parrent.
		 *
		 * NOTE: Always use the ParrentObject property getter to correctly retrieve this Voucher object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Voucher objParrentObject
		 */
		protected $objParrentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column voucher.grp.
		 *
		 * NOTE: Always use the GrpObject property getter to correctly retrieve this VoucherGrp object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var VoucherGrp objGrpObject
		 */
		protected $objGrpObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column voucher.data_by.
		 *
		 * NOTE: Always use the DataByObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objDataByObject
		 */
		protected $objDataByObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdvoucher = Voucher::IdvoucherDefault;
			$this->strInvNo = Voucher::InvNoDefault;
			$this->dttDate = (Voucher::DateDefault === null)?null:new QDateTime(Voucher::DateDefault);
			$this->intDr = Voucher::DrDefault;
			$this->intCr = Voucher::CrDefault;
			$this->strAmount = Voucher::AmountDefault;
			$this->strNarration = Voucher::NarrationDefault;
			$this->intParrent = Voucher::ParrentDefault;
			$this->strRefNo = Voucher::RefNoDefault;
			$this->intGrp = Voucher::GrpDefault;
			$this->intDataBy = Voucher::DataByDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Voucher from PK Info
		 * @param integer $intIdvoucher
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Voucher
		 */
		public static function Load($intIdvoucher, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Voucher', $intIdvoucher);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Voucher::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Voucher()->Idvoucher, $intIdvoucher)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Vouchers
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Voucher[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Voucher::QueryArray to perform the LoadAll query
			try {
				return Voucher::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Vouchers
		 * @return int
		 */
		public static function CountAll() {
			// Call Voucher::QueryCount to perform the CountAll query
			return Voucher::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();

			// Create/Build out the QueryBuilder object with Voucher-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'voucher');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Voucher::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('voucher');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Voucher object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Voucher the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Voucher::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Voucher object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Voucher::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Voucher::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Voucher objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Voucher[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Voucher::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Voucher::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Voucher::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Voucher objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Voucher::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();

			$strQuery = Voucher::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/voucher', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Voucher::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Voucher
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'voucher';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idvoucher', $strAliasPrefix . 'idvoucher');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idvoucher', $strAliasPrefix . 'idvoucher');
			    $objBuilder->AddSelectItem($strTableName, 'inv_no', $strAliasPrefix . 'inv_no');
			    $objBuilder->AddSelectItem($strTableName, 'date', $strAliasPrefix . 'date');
			    $objBuilder->AddSelectItem($strTableName, 'dr', $strAliasPrefix . 'dr');
			    $objBuilder->AddSelectItem($strTableName, 'cr', $strAliasPrefix . 'cr');
			    $objBuilder->AddSelectItem($strTableName, 'amount', $strAliasPrefix . 'amount');
			    $objBuilder->AddSelectItem($strTableName, 'narration', $strAliasPrefix . 'narration');
			    $objBuilder->AddSelectItem($strTableName, 'parrent', $strAliasPrefix . 'parrent');
			    $objBuilder->AddSelectItem($strTableName, 'ref_no', $strAliasPrefix . 'ref_no');
			    $objBuilder->AddSelectItem($strTableName, 'grp', $strAliasPrefix . 'grp');
			    $objBuilder->AddSelectItem($strTableName, 'data_by', $strAliasPrefix . 'data_by');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Voucher from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Voucher::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Voucher
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idvoucher';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdvoucher == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'voucher__';


						// Expanding reverse references: VoucherAsParrent
						$strAlias = $strAliasPrefix . 'voucherasparrent__idvoucher';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objVoucherAsParrentArray)
								$objPreviousItem->_objVoucherAsParrentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objVoucherAsParrentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objVoucherAsParrentArray;
								$objChildItem = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasparrent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objVoucherAsParrentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objVoucherAsParrentArray[] = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: VoucherHasItem
						$strAlias = $strAliasPrefix . 'voucherhasitem__idvoucher_has_item';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objVoucherHasItemArray)
								$objPreviousItem->_objVoucherHasItemArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objVoucherHasItemArray)) {
								$objPreviousChildItems = $objPreviousItem->_objVoucherHasItemArray;
								$objChildItem = VoucherHasItem::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherhasitem__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objVoucherHasItemArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objVoucherHasItemArray[] = VoucherHasItem::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherhasitem__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'voucher__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Voucher object
			$objToReturn = new Voucher();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idvoucher';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdvoucher = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'inv_no';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strInvNo = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'dr';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDr = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'cr';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCr = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'amount';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strAmount = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'narration';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strNarration = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'parrent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intParrent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'ref_no';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strRefNo = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intGrp = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'data_by';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDataBy = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idvoucher != $objPreviousItem->Idvoucher) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objVoucherAsParrentArray);
					$cnt = count($objToReturn->_objVoucherAsParrentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objVoucherAsParrentArray, $objToReturn->_objVoucherAsParrentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objVoucherHasItemArray);
					$cnt = count($objToReturn->_objVoucherHasItemArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objVoucherHasItemArray, $objToReturn->_objVoucherHasItemArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'voucher__';

			// Check for DrObject Early Binding
			$strAlias = $strAliasPrefix . 'dr__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDrObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'dr__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CrObject Early Binding
			$strAlias = $strAliasPrefix . 'cr__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCrObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'cr__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ParrentObject Early Binding
			$strAlias = $strAliasPrefix . 'parrent__idvoucher';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objParrentObject = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'parrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for GrpObject Early Binding
			$strAlias = $strAliasPrefix . 'grp__idvoucher_grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objGrpObject = VoucherGrp::InstantiateDbRow($objDbRow, $strAliasPrefix . 'grp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DataByObject Early Binding
			$strAlias = $strAliasPrefix . 'data_by__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDataByObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'data_by__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for VoucherAsParrent Virtual Binding
			$strAlias = $strAliasPrefix . 'voucherasparrent__idvoucher';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objVoucherAsParrentArray)
				$objToReturn->_objVoucherAsParrentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objVoucherAsParrentArray[] = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objVoucherAsParrent = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for VoucherHasItem Virtual Binding
			$strAlias = $strAliasPrefix . 'voucherhasitem__idvoucher_has_item';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objVoucherHasItemArray)
				$objToReturn->_objVoucherHasItemArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objVoucherHasItemArray[] = VoucherHasItem::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherhasitem__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objVoucherHasItem = VoucherHasItem::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherhasitem__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Vouchers from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Voucher[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Voucher::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Voucher::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Voucher object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Voucher next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Voucher::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Voucher object,
		 * by Idvoucher Index(es)
		 * @param integer $intIdvoucher
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Voucher
		*/
		public static function LoadByIdvoucher($intIdvoucher, $objOptionalClauses = null) {
			return Voucher::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Voucher()->Idvoucher, $intIdvoucher)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single Voucher object,
		 * by InvNo Index(es)
		 * @param string $strInvNo
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Voucher
		*/
		public static function LoadByInvNo($strInvNo, $objOptionalClauses = null) {
			return Voucher::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Voucher()->InvNo, $strInvNo)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Voucher objects,
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Voucher[]
		*/
		public static function LoadArrayByParrent($intParrent, $objOptionalClauses = null) {
			// Call Voucher::QueryArray to perform the LoadArrayByParrent query
			try {
				return Voucher::QueryArray(
					QQ::Equal(QQN::Voucher()->Parrent, $intParrent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Vouchers
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @return int
		*/
		public static function CountByParrent($intParrent) {
			// Call Voucher::QueryCount to perform the CountByParrent query
			return Voucher::QueryCount(
				QQ::Equal(QQN::Voucher()->Parrent, $intParrent)
			);
		}

		/**
		 * Load an array of Voucher objects,
		 * by Dr Index(es)
		 * @param integer $intDr
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Voucher[]
		*/
		public static function LoadArrayByDr($intDr, $objOptionalClauses = null) {
			// Call Voucher::QueryArray to perform the LoadArrayByDr query
			try {
				return Voucher::QueryArray(
					QQ::Equal(QQN::Voucher()->Dr, $intDr),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Vouchers
		 * by Dr Index(es)
		 * @param integer $intDr
		 * @return int
		*/
		public static function CountByDr($intDr) {
			// Call Voucher::QueryCount to perform the CountByDr query
			return Voucher::QueryCount(
				QQ::Equal(QQN::Voucher()->Dr, $intDr)
			);
		}

		/**
		 * Load an array of Voucher objects,
		 * by Cr Index(es)
		 * @param integer $intCr
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Voucher[]
		*/
		public static function LoadArrayByCr($intCr, $objOptionalClauses = null) {
			// Call Voucher::QueryArray to perform the LoadArrayByCr query
			try {
				return Voucher::QueryArray(
					QQ::Equal(QQN::Voucher()->Cr, $intCr),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Vouchers
		 * by Cr Index(es)
		 * @param integer $intCr
		 * @return int
		*/
		public static function CountByCr($intCr) {
			// Call Voucher::QueryCount to perform the CountByCr query
			return Voucher::QueryCount(
				QQ::Equal(QQN::Voucher()->Cr, $intCr)
			);
		}

		/**
		 * Load an array of Voucher objects,
		 * by Grp Index(es)
		 * @param integer $intGrp
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Voucher[]
		*/
		public static function LoadArrayByGrp($intGrp, $objOptionalClauses = null) {
			// Call Voucher::QueryArray to perform the LoadArrayByGrp query
			try {
				return Voucher::QueryArray(
					QQ::Equal(QQN::Voucher()->Grp, $intGrp),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Vouchers
		 * by Grp Index(es)
		 * @param integer $intGrp
		 * @return int
		*/
		public static function CountByGrp($intGrp) {
			// Call Voucher::QueryCount to perform the CountByGrp query
			return Voucher::QueryCount(
				QQ::Equal(QQN::Voucher()->Grp, $intGrp)
			);
		}

		/**
		 * Load an array of Voucher objects,
		 * by DataBy Index(es)
		 * @param integer $intDataBy
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Voucher[]
		*/
		public static function LoadArrayByDataBy($intDataBy, $objOptionalClauses = null) {
			// Call Voucher::QueryArray to perform the LoadArrayByDataBy query
			try {
				return Voucher::QueryArray(
					QQ::Equal(QQN::Voucher()->DataBy, $intDataBy),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Vouchers
		 * by DataBy Index(es)
		 * @param integer $intDataBy
		 * @return int
		*/
		public static function CountByDataBy($intDataBy) {
			// Call Voucher::QueryCount to perform the CountByDataBy query
			return Voucher::QueryCount(
				QQ::Equal(QQN::Voucher()->DataBy, $intDataBy)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Voucher
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `voucher` (
							`inv_no`,
							`date`,
							`dr`,
							`cr`,
							`amount`,
							`narration`,
							`parrent`,
							`ref_no`,
							`grp`,
							`data_by`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strInvNo) . ',
							' . $objDatabase->SqlVariable($this->dttDate) . ',
							' . $objDatabase->SqlVariable($this->intDr) . ',
							' . $objDatabase->SqlVariable($this->intCr) . ',
							' . $objDatabase->SqlVariable($this->strAmount) . ',
							' . $objDatabase->SqlVariable($this->strNarration) . ',
							' . $objDatabase->SqlVariable($this->intParrent) . ',
							' . $objDatabase->SqlVariable($this->strRefNo) . ',
							' . $objDatabase->SqlVariable($this->intGrp) . ',
							' . $objDatabase->SqlVariable($this->intDataBy) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdvoucher = $objDatabase->InsertId('voucher', 'idvoucher');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`voucher`
						SET
							`inv_no` = ' . $objDatabase->SqlVariable($this->strInvNo) . ',
							`date` = ' . $objDatabase->SqlVariable($this->dttDate) . ',
							`dr` = ' . $objDatabase->SqlVariable($this->intDr) . ',
							`cr` = ' . $objDatabase->SqlVariable($this->intCr) . ',
							`amount` = ' . $objDatabase->SqlVariable($this->strAmount) . ',
							`narration` = ' . $objDatabase->SqlVariable($this->strNarration) . ',
							`parrent` = ' . $objDatabase->SqlVariable($this->intParrent) . ',
							`ref_no` = ' . $objDatabase->SqlVariable($this->strRefNo) . ',
							`grp` = ' . $objDatabase->SqlVariable($this->intGrp) . ',
							`data_by` = ' . $objDatabase->SqlVariable($this->intDataBy) . '
						WHERE
							`idvoucher` = ' . $objDatabase->SqlVariable($this->intIdvoucher) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Voucher
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdvoucher)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Voucher with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher`
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($this->intIdvoucher) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Voucher ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Voucher', $this->intIdvoucher);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Vouchers
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate voucher table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `voucher`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Voucher from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Voucher object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Voucher::Load($this->intIdvoucher);

			// Update $this's local variables to match
			$this->strInvNo = $objReloaded->strInvNo;
			$this->dttDate = $objReloaded->dttDate;
			$this->Dr = $objReloaded->Dr;
			$this->Cr = $objReloaded->Cr;
			$this->strAmount = $objReloaded->strAmount;
			$this->strNarration = $objReloaded->strNarration;
			$this->Parrent = $objReloaded->Parrent;
			$this->strRefNo = $objReloaded->strRefNo;
			$this->Grp = $objReloaded->Grp;
			$this->DataBy = $objReloaded->DataBy;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idvoucher':
					/**
					 * Gets the value for intIdvoucher (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdvoucher;

				case 'InvNo':
					/**
					 * Gets the value for strInvNo (Unique)
					 * @return string
					 */
					return $this->strInvNo;

				case 'Date':
					/**
					 * Gets the value for dttDate (Not Null)
					 * @return QDateTime
					 */
					return $this->dttDate;

				case 'Dr':
					/**
					 * Gets the value for intDr 
					 * @return integer
					 */
					return $this->intDr;

				case 'Cr':
					/**
					 * Gets the value for intCr 
					 * @return integer
					 */
					return $this->intCr;

				case 'Amount':
					/**
					 * Gets the value for strAmount (Not Null)
					 * @return string
					 */
					return $this->strAmount;

				case 'Narration':
					/**
					 * Gets the value for strNarration 
					 * @return string
					 */
					return $this->strNarration;

				case 'Parrent':
					/**
					 * Gets the value for intParrent 
					 * @return integer
					 */
					return $this->intParrent;

				case 'RefNo':
					/**
					 * Gets the value for strRefNo 
					 * @return string
					 */
					return $this->strRefNo;

				case 'Grp':
					/**
					 * Gets the value for intGrp (Not Null)
					 * @return integer
					 */
					return $this->intGrp;

				case 'DataBy':
					/**
					 * Gets the value for intDataBy 
					 * @return integer
					 */
					return $this->intDataBy;


				///////////////////
				// Member Objects
				///////////////////
				case 'DrObject':
					/**
					 * Gets the value for the Ledger object referenced by intDr 
					 * @return Ledger
					 */
					try {
						if ((!$this->objDrObject) && (!is_null($this->intDr)))
							$this->objDrObject = Ledger::Load($this->intDr);
						return $this->objDrObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CrObject':
					/**
					 * Gets the value for the Ledger object referenced by intCr 
					 * @return Ledger
					 */
					try {
						if ((!$this->objCrObject) && (!is_null($this->intCr)))
							$this->objCrObject = Ledger::Load($this->intCr);
						return $this->objCrObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ParrentObject':
					/**
					 * Gets the value for the Voucher object referenced by intParrent 
					 * @return Voucher
					 */
					try {
						if ((!$this->objParrentObject) && (!is_null($this->intParrent)))
							$this->objParrentObject = Voucher::Load($this->intParrent);
						return $this->objParrentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GrpObject':
					/**
					 * Gets the value for the VoucherGrp object referenced by intGrp (Not Null)
					 * @return VoucherGrp
					 */
					try {
						if ((!$this->objGrpObject) && (!is_null($this->intGrp)))
							$this->objGrpObject = VoucherGrp::Load($this->intGrp);
						return $this->objGrpObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DataByObject':
					/**
					 * Gets the value for the Ledger object referenced by intDataBy 
					 * @return Ledger
					 */
					try {
						if ((!$this->objDataByObject) && (!is_null($this->intDataBy)))
							$this->objDataByObject = Ledger::Load($this->intDataBy);
						return $this->objDataByObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_VoucherAsParrent':
					/**
					 * Gets the value for the private _objVoucherAsParrent (Read-Only)
					 * if set due to an expansion on the voucher.parrent reverse relationship
					 * @return Voucher
					 */
					return $this->_objVoucherAsParrent;

				case '_VoucherAsParrentArray':
					/**
					 * Gets the value for the private _objVoucherAsParrentArray (Read-Only)
					 * if set due to an ExpandAsArray on the voucher.parrent reverse relationship
					 * @return Voucher[]
					 */
					return $this->_objVoucherAsParrentArray;

				case '_VoucherHasItem':
					/**
					 * Gets the value for the private _objVoucherHasItem (Read-Only)
					 * if set due to an expansion on the voucher_has_item.voucher reverse relationship
					 * @return VoucherHasItem
					 */
					return $this->_objVoucherHasItem;

				case '_VoucherHasItemArray':
					/**
					 * Gets the value for the private _objVoucherHasItemArray (Read-Only)
					 * if set due to an ExpandAsArray on the voucher_has_item.voucher reverse relationship
					 * @return VoucherHasItem[]
					 */
					return $this->_objVoucherHasItemArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'InvNo':
					/**
					 * Sets the value for strInvNo (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strInvNo = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Date':
					/**
					 * Sets the value for dttDate (Not Null)
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Dr':
					/**
					 * Sets the value for intDr 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDrObject = null;
						return ($this->intDr = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Cr':
					/**
					 * Sets the value for intCr 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCrObject = null;
						return ($this->intCr = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Amount':
					/**
					 * Sets the value for strAmount (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strAmount = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Narration':
					/**
					 * Sets the value for strNarration 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strNarration = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Parrent':
					/**
					 * Sets the value for intParrent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objParrentObject = null;
						return ($this->intParrent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RefNo':
					/**
					 * Sets the value for strRefNo 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strRefNo = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Grp':
					/**
					 * Sets the value for intGrp (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objGrpObject = null;
						return ($this->intGrp = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DataBy':
					/**
					 * Sets the value for intDataBy 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDataByObject = null;
						return ($this->intDataBy = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'DrObject':
					/**
					 * Sets the value for the Ledger object referenced by intDr 
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intDr = null;
						$this->objDrObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved DrObject for this Voucher');

						// Update Local Member Variables
						$this->objDrObject = $mixValue;
						$this->intDr = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CrObject':
					/**
					 * Sets the value for the Ledger object referenced by intCr 
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intCr = null;
						$this->objCrObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved CrObject for this Voucher');

						// Update Local Member Variables
						$this->objCrObject = $mixValue;
						$this->intCr = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ParrentObject':
					/**
					 * Sets the value for the Voucher object referenced by intParrent 
					 * @param Voucher $mixValue
					 * @return Voucher
					 */
					if (is_null($mixValue)) {
						$this->intParrent = null;
						$this->objParrentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Voucher object
						try {
							$mixValue = QType::Cast($mixValue, 'Voucher');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Voucher object
						if (is_null($mixValue->Idvoucher))
							throw new QCallerException('Unable to set an unsaved ParrentObject for this Voucher');

						// Update Local Member Variables
						$this->objParrentObject = $mixValue;
						$this->intParrent = $mixValue->Idvoucher;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'GrpObject':
					/**
					 * Sets the value for the VoucherGrp object referenced by intGrp (Not Null)
					 * @param VoucherGrp $mixValue
					 * @return VoucherGrp
					 */
					if (is_null($mixValue)) {
						$this->intGrp = null;
						$this->objGrpObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a VoucherGrp object
						try {
							$mixValue = QType::Cast($mixValue, 'VoucherGrp');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED VoucherGrp object
						if (is_null($mixValue->IdvoucherGrp))
							throw new QCallerException('Unable to set an unsaved GrpObject for this Voucher');

						// Update Local Member Variables
						$this->objGrpObject = $mixValue;
						$this->intGrp = $mixValue->IdvoucherGrp;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DataByObject':
					/**
					 * Sets the value for the Ledger object referenced by intDataBy 
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intDataBy = null;
						$this->objDataByObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved DataByObject for this Voucher');

						// Update Local Member Variables
						$this->objDataByObject = $mixValue;
						$this->intDataBy = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for VoucherAsParrent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated VouchersAsParrent as an array of Voucher objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Voucher[]
		*/
		public function GetVoucherAsParrentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdvoucher)))
				return array();

			try {
				return Voucher::LoadArrayByParrent($this->intIdvoucher, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated VouchersAsParrent
		 * @return int
		*/
		public function CountVouchersAsParrent() {
			if ((is_null($this->intIdvoucher)))
				return 0;

			return Voucher::CountByParrent($this->intIdvoucher);
		}

		/**
		 * Associates a VoucherAsParrent
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function AssociateVoucherAsParrent(Voucher $objVoucher) {
			if ((is_null($this->intIdvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherAsParrent on this unsaved Voucher.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherAsParrent on this Voucher with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdvoucher) . '
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . '
			');
		}

		/**
		 * Unassociates a VoucherAsParrent
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function UnassociateVoucherAsParrent(Voucher $objVoucher) {
			if ((is_null($this->intIdvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsParrent on this unsaved Voucher.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsParrent on this Voucher with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`parrent` = null
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdvoucher) . '
			');
		}

		/**
		 * Unassociates all VouchersAsParrent
		 * @return void
		*/
		public function UnassociateAllVouchersAsParrent() {
			if ((is_null($this->intIdvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsParrent on this unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`parrent` = null
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdvoucher) . '
			');
		}

		/**
		 * Deletes an associated VoucherAsParrent
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function DeleteAssociatedVoucherAsParrent(Voucher $objVoucher) {
			if ((is_null($this->intIdvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsParrent on this unsaved Voucher.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsParrent on this Voucher with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher`
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdvoucher) . '
			');
		}

		/**
		 * Deletes all associated VouchersAsParrent
		 * @return void
		*/
		public function DeleteAllVouchersAsParrent() {
			if ((is_null($this->intIdvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsParrent on this unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher`
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdvoucher) . '
			');
		}


		// Related Objects' Methods for VoucherHasItem
		//-------------------------------------------------------------------

		/**
		 * Gets all associated VoucherHasItems as an array of VoucherHasItem objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return VoucherHasItem[]
		*/
		public function GetVoucherHasItemArray($objOptionalClauses = null) {
			if ((is_null($this->intIdvoucher)))
				return array();

			try {
				return VoucherHasItem::LoadArrayByVoucher($this->intIdvoucher, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated VoucherHasItems
		 * @return int
		*/
		public function CountVoucherHasItems() {
			if ((is_null($this->intIdvoucher)))
				return 0;

			return VoucherHasItem::CountByVoucher($this->intIdvoucher);
		}

		/**
		 * Associates a VoucherHasItem
		 * @param VoucherHasItem $objVoucherHasItem
		 * @return void
		*/
		public function AssociateVoucherHasItem(VoucherHasItem $objVoucherHasItem) {
			if ((is_null($this->intIdvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherHasItem on this unsaved Voucher.');
			if ((is_null($objVoucherHasItem->IdvoucherHasItem)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherHasItem on this Voucher with an unsaved VoucherHasItem.');

			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher_has_item`
				SET
					`voucher` = ' . $objDatabase->SqlVariable($this->intIdvoucher) . '
				WHERE
					`idvoucher_has_item` = ' . $objDatabase->SqlVariable($objVoucherHasItem->IdvoucherHasItem) . '
			');
		}

		/**
		 * Unassociates a VoucherHasItem
		 * @param VoucherHasItem $objVoucherHasItem
		 * @return void
		*/
		public function UnassociateVoucherHasItem(VoucherHasItem $objVoucherHasItem) {
			if ((is_null($this->intIdvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherHasItem on this unsaved Voucher.');
			if ((is_null($objVoucherHasItem->IdvoucherHasItem)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherHasItem on this Voucher with an unsaved VoucherHasItem.');

			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher_has_item`
				SET
					`voucher` = null
				WHERE
					`idvoucher_has_item` = ' . $objDatabase->SqlVariable($objVoucherHasItem->IdvoucherHasItem) . ' AND
					`voucher` = ' . $objDatabase->SqlVariable($this->intIdvoucher) . '
			');
		}

		/**
		 * Unassociates all VoucherHasItems
		 * @return void
		*/
		public function UnassociateAllVoucherHasItems() {
			if ((is_null($this->intIdvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherHasItem on this unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher_has_item`
				SET
					`voucher` = null
				WHERE
					`voucher` = ' . $objDatabase->SqlVariable($this->intIdvoucher) . '
			');
		}

		/**
		 * Deletes an associated VoucherHasItem
		 * @param VoucherHasItem $objVoucherHasItem
		 * @return void
		*/
		public function DeleteAssociatedVoucherHasItem(VoucherHasItem $objVoucherHasItem) {
			if ((is_null($this->intIdvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherHasItem on this unsaved Voucher.');
			if ((is_null($objVoucherHasItem->IdvoucherHasItem)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherHasItem on this Voucher with an unsaved VoucherHasItem.');

			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher_has_item`
				WHERE
					`idvoucher_has_item` = ' . $objDatabase->SqlVariable($objVoucherHasItem->IdvoucherHasItem) . ' AND
					`voucher` = ' . $objDatabase->SqlVariable($this->intIdvoucher) . '
			');
		}

		/**
		 * Deletes all associated VoucherHasItems
		 * @return void
		*/
		public function DeleteAllVoucherHasItems() {
			if ((is_null($this->intIdvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherHasItem on this unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Voucher::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher_has_item`
				WHERE
					`voucher` = ' . $objDatabase->SqlVariable($this->intIdvoucher) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "voucher";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Voucher::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Voucher"><sequence>';
			$strToReturn .= '<element name="Idvoucher" type="xsd:int"/>';
			$strToReturn .= '<element name="InvNo" type="xsd:string"/>';
			$strToReturn .= '<element name="Date" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="DrObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="CrObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="Amount" type="xsd:string"/>';
			$strToReturn .= '<element name="Narration" type="xsd:string"/>';
			$strToReturn .= '<element name="ParrentObject" type="xsd1:Voucher"/>';
			$strToReturn .= '<element name="RefNo" type="xsd:string"/>';
			$strToReturn .= '<element name="GrpObject" type="xsd1:VoucherGrp"/>';
			$strToReturn .= '<element name="DataByObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Voucher', $strComplexTypeArray)) {
				$strComplexTypeArray['Voucher'] = Voucher::GetSoapComplexTypeXml();
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
				Voucher::AlterSoapComplexTypeArray($strComplexTypeArray);
				VoucherGrp::AlterSoapComplexTypeArray($strComplexTypeArray);
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Voucher::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Voucher();
			if (property_exists($objSoapObject, 'Idvoucher'))
				$objToReturn->intIdvoucher = $objSoapObject->Idvoucher;
			if (property_exists($objSoapObject, 'InvNo'))
				$objToReturn->strInvNo = $objSoapObject->InvNo;
			if (property_exists($objSoapObject, 'Date'))
				$objToReturn->dttDate = new QDateTime($objSoapObject->Date);
			if ((property_exists($objSoapObject, 'DrObject')) &&
				($objSoapObject->DrObject))
				$objToReturn->DrObject = Ledger::GetObjectFromSoapObject($objSoapObject->DrObject);
			if ((property_exists($objSoapObject, 'CrObject')) &&
				($objSoapObject->CrObject))
				$objToReturn->CrObject = Ledger::GetObjectFromSoapObject($objSoapObject->CrObject);
			if (property_exists($objSoapObject, 'Amount'))
				$objToReturn->strAmount = $objSoapObject->Amount;
			if (property_exists($objSoapObject, 'Narration'))
				$objToReturn->strNarration = $objSoapObject->Narration;
			if ((property_exists($objSoapObject, 'ParrentObject')) &&
				($objSoapObject->ParrentObject))
				$objToReturn->ParrentObject = Voucher::GetObjectFromSoapObject($objSoapObject->ParrentObject);
			if (property_exists($objSoapObject, 'RefNo'))
				$objToReturn->strRefNo = $objSoapObject->RefNo;
			if ((property_exists($objSoapObject, 'GrpObject')) &&
				($objSoapObject->GrpObject))
				$objToReturn->GrpObject = VoucherGrp::GetObjectFromSoapObject($objSoapObject->GrpObject);
			if ((property_exists($objSoapObject, 'DataByObject')) &&
				($objSoapObject->DataByObject))
				$objToReturn->DataByObject = Ledger::GetObjectFromSoapObject($objSoapObject->DataByObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Voucher::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->dttDate)
				$objObject->dttDate = $objObject->dttDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objDrObject)
				$objObject->objDrObject = Ledger::GetSoapObjectFromObject($objObject->objDrObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDr = null;
			if ($objObject->objCrObject)
				$objObject->objCrObject = Ledger::GetSoapObjectFromObject($objObject->objCrObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCr = null;
			if ($objObject->objParrentObject)
				$objObject->objParrentObject = Voucher::GetSoapObjectFromObject($objObject->objParrentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intParrent = null;
			if ($objObject->objGrpObject)
				$objObject->objGrpObject = VoucherGrp::GetSoapObjectFromObject($objObject->objGrpObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intGrp = null;
			if ($objObject->objDataByObject)
				$objObject->objDataByObject = Ledger::GetSoapObjectFromObject($objObject->objDataByObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDataBy = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idvoucher'] = $this->intIdvoucher;
			$iArray['InvNo'] = $this->strInvNo;
			$iArray['Date'] = $this->dttDate;
			$iArray['Dr'] = $this->intDr;
			$iArray['Cr'] = $this->intCr;
			$iArray['Amount'] = $this->strAmount;
			$iArray['Narration'] = $this->strNarration;
			$iArray['Parrent'] = $this->intParrent;
			$iArray['RefNo'] = $this->strRefNo;
			$iArray['Grp'] = $this->intGrp;
			$iArray['DataBy'] = $this->intDataBy;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdvoucher ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idvoucher
     * @property-read QQNode $InvNo
     * @property-read QQNode $Date
     * @property-read QQNode $Dr
     * @property-read QQNodeLedger $DrObject
     * @property-read QQNode $Cr
     * @property-read QQNodeLedger $CrObject
     * @property-read QQNode $Amount
     * @property-read QQNode $Narration
     * @property-read QQNode $Parrent
     * @property-read QQNodeVoucher $ParrentObject
     * @property-read QQNode $RefNo
     * @property-read QQNode $Grp
     * @property-read QQNodeVoucherGrp $GrpObject
     * @property-read QQNode $DataBy
     * @property-read QQNodeLedger $DataByObject
     *
     *
     * @property-read QQReverseReferenceNodeVoucher $VoucherAsParrent
     * @property-read QQReverseReferenceNodeVoucherHasItem $VoucherHasItem

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeVoucher extends QQNode {
		protected $strTableName = 'voucher';
		protected $strPrimaryKey = 'idvoucher';
		protected $strClassName = 'Voucher';
		public function __get($strName) {
			switch ($strName) {
				case 'Idvoucher':
					return new QQNode('idvoucher', 'Idvoucher', 'Integer', $this);
				case 'InvNo':
					return new QQNode('inv_no', 'InvNo', 'VarChar', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'DateTime', $this);
				case 'Dr':
					return new QQNode('dr', 'Dr', 'Integer', $this);
				case 'DrObject':
					return new QQNodeLedger('dr', 'DrObject', 'Integer', $this);
				case 'Cr':
					return new QQNode('cr', 'Cr', 'Integer', $this);
				case 'CrObject':
					return new QQNodeLedger('cr', 'CrObject', 'Integer', $this);
				case 'Amount':
					return new QQNode('amount', 'Amount', 'VarChar', $this);
				case 'Narration':
					return new QQNode('narration', 'Narration', 'Blob', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'Integer', $this);
				case 'ParrentObject':
					return new QQNodeVoucher('parrent', 'ParrentObject', 'Integer', $this);
				case 'RefNo':
					return new QQNode('ref_no', 'RefNo', 'VarChar', $this);
				case 'Grp':
					return new QQNode('grp', 'Grp', 'Integer', $this);
				case 'GrpObject':
					return new QQNodeVoucherGrp('grp', 'GrpObject', 'Integer', $this);
				case 'DataBy':
					return new QQNode('data_by', 'DataBy', 'Integer', $this);
				case 'DataByObject':
					return new QQNodeLedger('data_by', 'DataByObject', 'Integer', $this);
				case 'VoucherAsParrent':
					return new QQReverseReferenceNodeVoucher($this, 'voucherasparrent', 'reverse_reference', 'parrent');
				case 'VoucherHasItem':
					return new QQReverseReferenceNodeVoucherHasItem($this, 'voucherhasitem', 'reverse_reference', 'voucher');

				case '_PrimaryKeyNode':
					return new QQNode('idvoucher', 'Idvoucher', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idvoucher
     * @property-read QQNode $InvNo
     * @property-read QQNode $Date
     * @property-read QQNode $Dr
     * @property-read QQNodeLedger $DrObject
     * @property-read QQNode $Cr
     * @property-read QQNodeLedger $CrObject
     * @property-read QQNode $Amount
     * @property-read QQNode $Narration
     * @property-read QQNode $Parrent
     * @property-read QQNodeVoucher $ParrentObject
     * @property-read QQNode $RefNo
     * @property-read QQNode $Grp
     * @property-read QQNodeVoucherGrp $GrpObject
     * @property-read QQNode $DataBy
     * @property-read QQNodeLedger $DataByObject
     *
     *
     * @property-read QQReverseReferenceNodeVoucher $VoucherAsParrent
     * @property-read QQReverseReferenceNodeVoucherHasItem $VoucherHasItem

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeVoucher extends QQReverseReferenceNode {
		protected $strTableName = 'voucher';
		protected $strPrimaryKey = 'idvoucher';
		protected $strClassName = 'Voucher';
		public function __get($strName) {
			switch ($strName) {
				case 'Idvoucher':
					return new QQNode('idvoucher', 'Idvoucher', 'integer', $this);
				case 'InvNo':
					return new QQNode('inv_no', 'InvNo', 'string', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'QDateTime', $this);
				case 'Dr':
					return new QQNode('dr', 'Dr', 'integer', $this);
				case 'DrObject':
					return new QQNodeLedger('dr', 'DrObject', 'integer', $this);
				case 'Cr':
					return new QQNode('cr', 'Cr', 'integer', $this);
				case 'CrObject':
					return new QQNodeLedger('cr', 'CrObject', 'integer', $this);
				case 'Amount':
					return new QQNode('amount', 'Amount', 'string', $this);
				case 'Narration':
					return new QQNode('narration', 'Narration', 'string', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'integer', $this);
				case 'ParrentObject':
					return new QQNodeVoucher('parrent', 'ParrentObject', 'integer', $this);
				case 'RefNo':
					return new QQNode('ref_no', 'RefNo', 'string', $this);
				case 'Grp':
					return new QQNode('grp', 'Grp', 'integer', $this);
				case 'GrpObject':
					return new QQNodeVoucherGrp('grp', 'GrpObject', 'integer', $this);
				case 'DataBy':
					return new QQNode('data_by', 'DataBy', 'integer', $this);
				case 'DataByObject':
					return new QQNodeLedger('data_by', 'DataByObject', 'integer', $this);
				case 'VoucherAsParrent':
					return new QQReverseReferenceNodeVoucher($this, 'voucherasparrent', 'reverse_reference', 'parrent');
				case 'VoucherHasItem':
					return new QQReverseReferenceNodeVoucherHasItem($this, 'voucherhasitem', 'reverse_reference', 'voucher');

				case '_PrimaryKeyNode':
					return new QQNode('idvoucher', 'Idvoucher', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
