<?php
	/**
	 * The abstract RoleGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Role subclass which
	 * extends this RoleGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Role class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idrole the value for intIdrole (Read-Only PK)
	 * @property string $Name the value for strName (Unique)
	 * @property string $Description the value for strDescription (Not Null)
	 * @property integer $Parrent the value for intParrent 
	 * @property string $Mname the value for strMname 
	 * @property integer $Grp the value for intGrp 
	 * @property string $ShortName the value for strShortName (Unique)
	 * @property string $Abbrivation the value for strAbbrivation 
	 * @property integer $ServiceYears the value for intServiceYears 
	 * @property integer $Code the value for intCode 
	 * @property string $Count the value for strCount 
	 * @property integer $Intake the value for intIntake 
	 * @property Role $ParrentObject the value for the Role object referenced by intParrent 
	 * @property Group $GrpObject the value for the Group object referenced by intGrp 
	 * @property-read AcademicTemplet $_AcademicTempletAsDepartment the value for the private _objAcademicTempletAsDepartment (Read-Only) if set due to an expansion on the academic_templet.department reverse relationship
	 * @property-read AcademicTemplet[] $_AcademicTempletAsDepartmentArray the value for the private _objAcademicTempletAsDepartmentArray (Read-Only) if set due to an ExpandAsArray on the academic_templet.department reverse relationship
	 * @property-read Address $_AddressAsRoll the value for the private _objAddressAsRoll (Read-Only) if set due to an expansion on the address.roll reverse relationship
	 * @property-read Address[] $_AddressAsRollArray the value for the private _objAddressAsRollArray (Read-Only) if set due to an ExpandAsArray on the address.roll reverse relationship
	 * @property-read AppApproval $_AppApprovalAsRoll the value for the private _objAppApprovalAsRoll (Read-Only) if set due to an expansion on the app_approval.roll reverse relationship
	 * @property-read AppApproval[] $_AppApprovalAsRollArray the value for the private _objAppApprovalAsRollArray (Read-Only) if set due to an ExpandAsArray on the app_approval.roll reverse relationship
	 * @property-read Application $_ApplicationAsProgram the value for the private _objApplicationAsProgram (Read-Only) if set due to an expansion on the application.program reverse relationship
	 * @property-read Application[] $_ApplicationAsProgramArray the value for the private _objApplicationAsProgramArray (Read-Only) if set due to an ExpandAsArray on the application.program reverse relationship
	 * @property-read Approvel $_ApprovelAsRoll the value for the private _objApprovelAsRoll (Read-Only) if set due to an expansion on the approvel.roll reverse relationship
	 * @property-read Approvel[] $_ApprovelAsRollArray the value for the private _objApprovelAsRollArray (Read-Only) if set due to an ExpandAsArray on the approvel.roll reverse relationship
	 * @property-read DeptYear $_DeptYearAsDepartment the value for the private _objDeptYearAsDepartment (Read-Only) if set due to an expansion on the dept_year.department reverse relationship
	 * @property-read DeptYear[] $_DeptYearAsDepartmentArray the value for the private _objDeptYearAsDepartmentArray (Read-Only) if set due to an ExpandAsArray on the dept_year.department reverse relationship
	 * @property-read DeptYearEvents $_DeptYearEventsAsDepartment the value for the private _objDeptYearEventsAsDepartment (Read-Only) if set due to an expansion on the dept_year_events.department reverse relationship
	 * @property-read DeptYearEvents[] $_DeptYearEventsAsDepartmentArray the value for the private _objDeptYearEventsAsDepartmentArray (Read-Only) if set due to an ExpandAsArray on the dept_year_events.department reverse relationship
	 * @property-read Event $_EventAsDepartment the value for the private _objEventAsDepartment (Read-Only) if set due to an expansion on the event.department reverse relationship
	 * @property-read Event[] $_EventAsDepartmentArray the value for the private _objEventAsDepartmentArray (Read-Only) if set due to an ExpandAsArray on the event.department reverse relationship
	 * @property-read LoginHasRole $_LoginHasRoleAsId the value for the private _objLoginHasRoleAsId (Read-Only) if set due to an expansion on the login_has_role.role_idrole reverse relationship
	 * @property-read LoginHasRole[] $_LoginHasRoleAsIdArray the value for the private _objLoginHasRoleAsIdArray (Read-Only) if set due to an ExpandAsArray on the login_has_role.role_idrole reverse relationship
	 * @property-read Note $_Note the value for the private _objNote (Read-Only) if set due to an expansion on the note.role reverse relationship
	 * @property-read Note[] $_NoteArray the value for the private _objNoteArray (Read-Only) if set due to an ExpandAsArray on the note.role reverse relationship
	 * @property-read PriceHistory $_PriceHistoryAsGodown the value for the private _objPriceHistoryAsGodown (Read-Only) if set due to an expansion on the price_history.godown reverse relationship
	 * @property-read PriceHistory[] $_PriceHistoryAsGodownArray the value for the private _objPriceHistoryAsGodownArray (Read-Only) if set due to an ExpandAsArray on the price_history.godown reverse relationship
	 * @property-read Profile $_ProfileAsCourseOfAddmission the value for the private _objProfileAsCourseOfAddmission (Read-Only) if set due to an expansion on the profile.course_of_addmission reverse relationship
	 * @property-read Profile[] $_ProfileAsCourseOfAddmissionArray the value for the private _objProfileAsCourseOfAddmissionArray (Read-Only) if set due to an ExpandAsArray on the profile.course_of_addmission reverse relationship
	 * @property-read Profile $_ProfileAsCurrentCourse the value for the private _objProfileAsCurrentCourse (Read-Only) if set due to an expansion on the profile.current_course reverse relationship
	 * @property-read Profile[] $_ProfileAsCurrentCourseArray the value for the private _objProfileAsCurrentCourseArray (Read-Only) if set due to an ExpandAsArray on the profile.current_course reverse relationship
	 * @property-read Profile $_ProfileAsBranchOfAddmission the value for the private _objProfileAsBranchOfAddmission (Read-Only) if set due to an expansion on the profile.branch_of_addmission reverse relationship
	 * @property-read Profile[] $_ProfileAsBranchOfAddmissionArray the value for the private _objProfileAsBranchOfAddmissionArray (Read-Only) if set due to an ExpandAsArray on the profile.branch_of_addmission reverse relationship
	 * @property-read Profile $_ProfileAsCurrentBranch the value for the private _objProfileAsCurrentBranch (Read-Only) if set due to an expansion on the profile.current_branch reverse relationship
	 * @property-read Profile[] $_ProfileAsCurrentBranchArray the value for the private _objProfileAsCurrentBranchArray (Read-Only) if set due to an ExpandAsArray on the profile.current_branch reverse relationship
	 * @property-read Profile $_ProfileAsAdmissionDiv the value for the private _objProfileAsAdmissionDiv (Read-Only) if set due to an expansion on the profile.admission_div reverse relationship
	 * @property-read Profile[] $_ProfileAsAdmissionDivArray the value for the private _objProfileAsAdmissionDivArray (Read-Only) if set due to an ExpandAsArray on the profile.admission_div reverse relationship
	 * @property-read Profile $_ProfileAsCurrentDiv the value for the private _objProfileAsCurrentDiv (Read-Only) if set due to an expansion on the profile.current_div reverse relationship
	 * @property-read Profile[] $_ProfileAsCurrentDivArray the value for the private _objProfileAsCurrentDivArray (Read-Only) if set due to an ExpandAsArray on the profile.current_div reverse relationship
	 * @property-read Role $_RoleAsParrent the value for the private _objRoleAsParrent (Read-Only) if set due to an expansion on the role.parrent reverse relationship
	 * @property-read Role[] $_RoleAsParrentArray the value for the private _objRoleAsParrentArray (Read-Only) if set due to an ExpandAsArray on the role.parrent reverse relationship
	 * @property-read RoleHasMenu $_RoleHasMenuAsId the value for the private _objRoleHasMenuAsId (Read-Only) if set due to an expansion on the role_has_menu.role_idrole reverse relationship
	 * @property-read RoleHasMenu[] $_RoleHasMenuAsIdArray the value for the private _objRoleHasMenuAsIdArray (Read-Only) if set due to an ExpandAsArray on the role_has_menu.role_idrole reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class RoleGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column role.idrole
		 * @var integer intIdrole
		 */
		protected $intIdrole;
		const IdroleDefault = null;


		/**
		 * Protected member variable that maps to the database column role.name
		 * @var string strName
		 */
		protected $strName;
		const NameMaxLength = 255;
		const NameDefault = null;


		/**
		 * Protected member variable that maps to the database column role.description
		 * @var string strDescription
		 */
		protected $strDescription;
		const DescriptionDefault = null;


		/**
		 * Protected member variable that maps to the database column role.parrent
		 * @var integer intParrent
		 */
		protected $intParrent;
		const ParrentDefault = null;


		/**
		 * Protected member variable that maps to the database column role.mname
		 * @var string strMname
		 */
		protected $strMname;
		const MnameMaxLength = 255;
		const MnameDefault = null;


		/**
		 * Protected member variable that maps to the database column role.grp
		 * @var integer intGrp
		 */
		protected $intGrp;
		const GrpDefault = null;


		/**
		 * Protected member variable that maps to the database column role.short_name
		 * @var string strShortName
		 */
		protected $strShortName;
		const ShortNameMaxLength = 45;
		const ShortNameDefault = null;


		/**
		 * Protected member variable that maps to the database column role.abbrivation
		 * @var string strAbbrivation
		 */
		protected $strAbbrivation;
		const AbbrivationMaxLength = 45;
		const AbbrivationDefault = null;


		/**
		 * Protected member variable that maps to the database column role.service_years
		 * @var integer intServiceYears
		 */
		protected $intServiceYears;
		const ServiceYearsDefault = null;


		/**
		 * Protected member variable that maps to the database column role.code
		 * @var integer intCode
		 */
		protected $intCode;
		const CodeDefault = null;


		/**
		 * Protected member variable that maps to the database column role.count
		 * @var string strCount
		 */
		protected $strCount;
		const CountMaxLength = 45;
		const CountDefault = null;


		/**
		 * Protected member variable that maps to the database column role.intake
		 * @var integer intIntake
		 */
		protected $intIntake;
		const IntakeDefault = null;


		/**
		 * Private member variable that stores a reference to a single AcademicTempletAsDepartment object
		 * (of type AcademicTemplet), if this Role object was restored with
		 * an expansion on the academic_templet association table.
		 * @var AcademicTemplet _objAcademicTempletAsDepartment;
		 */
		private $_objAcademicTempletAsDepartment;

		/**
		 * Private member variable that stores a reference to an array of AcademicTempletAsDepartment objects
		 * (of type AcademicTemplet[]), if this Role object was restored with
		 * an ExpandAsArray on the academic_templet association table.
		 * @var AcademicTemplet[] _objAcademicTempletAsDepartmentArray;
		 */
		private $_objAcademicTempletAsDepartmentArray = null;

		/**
		 * Private member variable that stores a reference to a single AddressAsRoll object
		 * (of type Address), if this Role object was restored with
		 * an expansion on the address association table.
		 * @var Address _objAddressAsRoll;
		 */
		private $_objAddressAsRoll;

		/**
		 * Private member variable that stores a reference to an array of AddressAsRoll objects
		 * (of type Address[]), if this Role object was restored with
		 * an ExpandAsArray on the address association table.
		 * @var Address[] _objAddressAsRollArray;
		 */
		private $_objAddressAsRollArray = null;

		/**
		 * Private member variable that stores a reference to a single AppApprovalAsRoll object
		 * (of type AppApproval), if this Role object was restored with
		 * an expansion on the app_approval association table.
		 * @var AppApproval _objAppApprovalAsRoll;
		 */
		private $_objAppApprovalAsRoll;

		/**
		 * Private member variable that stores a reference to an array of AppApprovalAsRoll objects
		 * (of type AppApproval[]), if this Role object was restored with
		 * an ExpandAsArray on the app_approval association table.
		 * @var AppApproval[] _objAppApprovalAsRollArray;
		 */
		private $_objAppApprovalAsRollArray = null;

		/**
		 * Private member variable that stores a reference to a single ApplicationAsProgram object
		 * (of type Application), if this Role object was restored with
		 * an expansion on the application association table.
		 * @var Application _objApplicationAsProgram;
		 */
		private $_objApplicationAsProgram;

		/**
		 * Private member variable that stores a reference to an array of ApplicationAsProgram objects
		 * (of type Application[]), if this Role object was restored with
		 * an ExpandAsArray on the application association table.
		 * @var Application[] _objApplicationAsProgramArray;
		 */
		private $_objApplicationAsProgramArray = null;

		/**
		 * Private member variable that stores a reference to a single ApprovelAsRoll object
		 * (of type Approvel), if this Role object was restored with
		 * an expansion on the approvel association table.
		 * @var Approvel _objApprovelAsRoll;
		 */
		private $_objApprovelAsRoll;

		/**
		 * Private member variable that stores a reference to an array of ApprovelAsRoll objects
		 * (of type Approvel[]), if this Role object was restored with
		 * an ExpandAsArray on the approvel association table.
		 * @var Approvel[] _objApprovelAsRollArray;
		 */
		private $_objApprovelAsRollArray = null;

		/**
		 * Private member variable that stores a reference to a single DeptYearAsDepartment object
		 * (of type DeptYear), if this Role object was restored with
		 * an expansion on the dept_year association table.
		 * @var DeptYear _objDeptYearAsDepartment;
		 */
		private $_objDeptYearAsDepartment;

		/**
		 * Private member variable that stores a reference to an array of DeptYearAsDepartment objects
		 * (of type DeptYear[]), if this Role object was restored with
		 * an ExpandAsArray on the dept_year association table.
		 * @var DeptYear[] _objDeptYearAsDepartmentArray;
		 */
		private $_objDeptYearAsDepartmentArray = null;

		/**
		 * Private member variable that stores a reference to a single DeptYearEventsAsDepartment object
		 * (of type DeptYearEvents), if this Role object was restored with
		 * an expansion on the dept_year_events association table.
		 * @var DeptYearEvents _objDeptYearEventsAsDepartment;
		 */
		private $_objDeptYearEventsAsDepartment;

		/**
		 * Private member variable that stores a reference to an array of DeptYearEventsAsDepartment objects
		 * (of type DeptYearEvents[]), if this Role object was restored with
		 * an ExpandAsArray on the dept_year_events association table.
		 * @var DeptYearEvents[] _objDeptYearEventsAsDepartmentArray;
		 */
		private $_objDeptYearEventsAsDepartmentArray = null;

		/**
		 * Private member variable that stores a reference to a single EventAsDepartment object
		 * (of type Event), if this Role object was restored with
		 * an expansion on the event association table.
		 * @var Event _objEventAsDepartment;
		 */
		private $_objEventAsDepartment;

		/**
		 * Private member variable that stores a reference to an array of EventAsDepartment objects
		 * (of type Event[]), if this Role object was restored with
		 * an ExpandAsArray on the event association table.
		 * @var Event[] _objEventAsDepartmentArray;
		 */
		private $_objEventAsDepartmentArray = null;

		/**
		 * Private member variable that stores a reference to a single LoginHasRoleAsId object
		 * (of type LoginHasRole), if this Role object was restored with
		 * an expansion on the login_has_role association table.
		 * @var LoginHasRole _objLoginHasRoleAsId;
		 */
		private $_objLoginHasRoleAsId;

		/**
		 * Private member variable that stores a reference to an array of LoginHasRoleAsId objects
		 * (of type LoginHasRole[]), if this Role object was restored with
		 * an ExpandAsArray on the login_has_role association table.
		 * @var LoginHasRole[] _objLoginHasRoleAsIdArray;
		 */
		private $_objLoginHasRoleAsIdArray = null;

		/**
		 * Private member variable that stores a reference to a single Note object
		 * (of type Note), if this Role object was restored with
		 * an expansion on the note association table.
		 * @var Note _objNote;
		 */
		private $_objNote;

		/**
		 * Private member variable that stores a reference to an array of Note objects
		 * (of type Note[]), if this Role object was restored with
		 * an ExpandAsArray on the note association table.
		 * @var Note[] _objNoteArray;
		 */
		private $_objNoteArray = null;

		/**
		 * Private member variable that stores a reference to a single PriceHistoryAsGodown object
		 * (of type PriceHistory), if this Role object was restored with
		 * an expansion on the price_history association table.
		 * @var PriceHistory _objPriceHistoryAsGodown;
		 */
		private $_objPriceHistoryAsGodown;

		/**
		 * Private member variable that stores a reference to an array of PriceHistoryAsGodown objects
		 * (of type PriceHistory[]), if this Role object was restored with
		 * an ExpandAsArray on the price_history association table.
		 * @var PriceHistory[] _objPriceHistoryAsGodownArray;
		 */
		private $_objPriceHistoryAsGodownArray = null;

		/**
		 * Private member variable that stores a reference to a single ProfileAsCourseOfAddmission object
		 * (of type Profile), if this Role object was restored with
		 * an expansion on the profile association table.
		 * @var Profile _objProfileAsCourseOfAddmission;
		 */
		private $_objProfileAsCourseOfAddmission;

		/**
		 * Private member variable that stores a reference to an array of ProfileAsCourseOfAddmission objects
		 * (of type Profile[]), if this Role object was restored with
		 * an ExpandAsArray on the profile association table.
		 * @var Profile[] _objProfileAsCourseOfAddmissionArray;
		 */
		private $_objProfileAsCourseOfAddmissionArray = null;

		/**
		 * Private member variable that stores a reference to a single ProfileAsCurrentCourse object
		 * (of type Profile), if this Role object was restored with
		 * an expansion on the profile association table.
		 * @var Profile _objProfileAsCurrentCourse;
		 */
		private $_objProfileAsCurrentCourse;

		/**
		 * Private member variable that stores a reference to an array of ProfileAsCurrentCourse objects
		 * (of type Profile[]), if this Role object was restored with
		 * an ExpandAsArray on the profile association table.
		 * @var Profile[] _objProfileAsCurrentCourseArray;
		 */
		private $_objProfileAsCurrentCourseArray = null;

		/**
		 * Private member variable that stores a reference to a single ProfileAsBranchOfAddmission object
		 * (of type Profile), if this Role object was restored with
		 * an expansion on the profile association table.
		 * @var Profile _objProfileAsBranchOfAddmission;
		 */
		private $_objProfileAsBranchOfAddmission;

		/**
		 * Private member variable that stores a reference to an array of ProfileAsBranchOfAddmission objects
		 * (of type Profile[]), if this Role object was restored with
		 * an ExpandAsArray on the profile association table.
		 * @var Profile[] _objProfileAsBranchOfAddmissionArray;
		 */
		private $_objProfileAsBranchOfAddmissionArray = null;

		/**
		 * Private member variable that stores a reference to a single ProfileAsCurrentBranch object
		 * (of type Profile), if this Role object was restored with
		 * an expansion on the profile association table.
		 * @var Profile _objProfileAsCurrentBranch;
		 */
		private $_objProfileAsCurrentBranch;

		/**
		 * Private member variable that stores a reference to an array of ProfileAsCurrentBranch objects
		 * (of type Profile[]), if this Role object was restored with
		 * an ExpandAsArray on the profile association table.
		 * @var Profile[] _objProfileAsCurrentBranchArray;
		 */
		private $_objProfileAsCurrentBranchArray = null;

		/**
		 * Private member variable that stores a reference to a single ProfileAsAdmissionDiv object
		 * (of type Profile), if this Role object was restored with
		 * an expansion on the profile association table.
		 * @var Profile _objProfileAsAdmissionDiv;
		 */
		private $_objProfileAsAdmissionDiv;

		/**
		 * Private member variable that stores a reference to an array of ProfileAsAdmissionDiv objects
		 * (of type Profile[]), if this Role object was restored with
		 * an ExpandAsArray on the profile association table.
		 * @var Profile[] _objProfileAsAdmissionDivArray;
		 */
		private $_objProfileAsAdmissionDivArray = null;

		/**
		 * Private member variable that stores a reference to a single ProfileAsCurrentDiv object
		 * (of type Profile), if this Role object was restored with
		 * an expansion on the profile association table.
		 * @var Profile _objProfileAsCurrentDiv;
		 */
		private $_objProfileAsCurrentDiv;

		/**
		 * Private member variable that stores a reference to an array of ProfileAsCurrentDiv objects
		 * (of type Profile[]), if this Role object was restored with
		 * an ExpandAsArray on the profile association table.
		 * @var Profile[] _objProfileAsCurrentDivArray;
		 */
		private $_objProfileAsCurrentDivArray = null;

		/**
		 * Private member variable that stores a reference to a single RoleAsParrent object
		 * (of type Role), if this Role object was restored with
		 * an expansion on the role association table.
		 * @var Role _objRoleAsParrent;
		 */
		private $_objRoleAsParrent;

		/**
		 * Private member variable that stores a reference to an array of RoleAsParrent objects
		 * (of type Role[]), if this Role object was restored with
		 * an ExpandAsArray on the role association table.
		 * @var Role[] _objRoleAsParrentArray;
		 */
		private $_objRoleAsParrentArray = null;

		/**
		 * Private member variable that stores a reference to a single RoleHasMenuAsId object
		 * (of type RoleHasMenu), if this Role object was restored with
		 * an expansion on the role_has_menu association table.
		 * @var RoleHasMenu _objRoleHasMenuAsId;
		 */
		private $_objRoleHasMenuAsId;

		/**
		 * Private member variable that stores a reference to an array of RoleHasMenuAsId objects
		 * (of type RoleHasMenu[]), if this Role object was restored with
		 * an ExpandAsArray on the role_has_menu association table.
		 * @var RoleHasMenu[] _objRoleHasMenuAsIdArray;
		 */
		private $_objRoleHasMenuAsIdArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column role.parrent.
		 *
		 * NOTE: Always use the ParrentObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objParrentObject
		 */
		protected $objParrentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column role.grp.
		 *
		 * NOTE: Always use the GrpObject property getter to correctly retrieve this Group object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Group objGrpObject
		 */
		protected $objGrpObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdrole = Role::IdroleDefault;
			$this->strName = Role::NameDefault;
			$this->strDescription = Role::DescriptionDefault;
			$this->intParrent = Role::ParrentDefault;
			$this->strMname = Role::MnameDefault;
			$this->intGrp = Role::GrpDefault;
			$this->strShortName = Role::ShortNameDefault;
			$this->strAbbrivation = Role::AbbrivationDefault;
			$this->intServiceYears = Role::ServiceYearsDefault;
			$this->intCode = Role::CodeDefault;
			$this->strCount = Role::CountDefault;
			$this->intIntake = Role::IntakeDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Role from PK Info
		 * @param integer $intIdrole
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Role
		 */
		public static function Load($intIdrole, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Role', $intIdrole);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Role::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Role()->Idrole, $intIdrole)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Roles
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Role[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Role::QueryArray to perform the LoadAll query
			try {
				return Role::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Roles
		 * @return int
		 */
		public static function CountAll() {
			// Call Role::QueryCount to perform the CountAll query
			return Role::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Create/Build out the QueryBuilder object with Role-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'role');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Role::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('role');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Role object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Role the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Role::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Role object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Role::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Role::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Role objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Role[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Role::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Role::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Role::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Role objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Role::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			$strQuery = Role::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/role', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Role::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Role
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'role';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idrole', $strAliasPrefix . 'idrole');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idrole', $strAliasPrefix . 'idrole');
			    $objBuilder->AddSelectItem($strTableName, 'name', $strAliasPrefix . 'name');
			    $objBuilder->AddSelectItem($strTableName, 'description', $strAliasPrefix . 'description');
			    $objBuilder->AddSelectItem($strTableName, 'parrent', $strAliasPrefix . 'parrent');
			    $objBuilder->AddSelectItem($strTableName, 'mname', $strAliasPrefix . 'mname');
			    $objBuilder->AddSelectItem($strTableName, 'grp', $strAliasPrefix . 'grp');
			    $objBuilder->AddSelectItem($strTableName, 'short_name', $strAliasPrefix . 'short_name');
			    $objBuilder->AddSelectItem($strTableName, 'abbrivation', $strAliasPrefix . 'abbrivation');
			    $objBuilder->AddSelectItem($strTableName, 'service_years', $strAliasPrefix . 'service_years');
			    $objBuilder->AddSelectItem($strTableName, 'code', $strAliasPrefix . 'code');
			    $objBuilder->AddSelectItem($strTableName, 'count', $strAliasPrefix . 'count');
			    $objBuilder->AddSelectItem($strTableName, 'intake', $strAliasPrefix . 'intake');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Role from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Role::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Role
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdrole == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'role__';


						// Expanding reverse references: AcademicTempletAsDepartment
						$strAlias = $strAliasPrefix . 'academictempletasdepartment__id';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objAcademicTempletAsDepartmentArray)
								$objPreviousItem->_objAcademicTempletAsDepartmentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objAcademicTempletAsDepartmentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objAcademicTempletAsDepartmentArray;
								$objChildItem = AcademicTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'academictempletasdepartment__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objAcademicTempletAsDepartmentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objAcademicTempletAsDepartmentArray[] = AcademicTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'academictempletasdepartment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: AddressAsRoll
						$strAlias = $strAliasPrefix . 'addressasroll__idaddress';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objAddressAsRollArray)
								$objPreviousItem->_objAddressAsRollArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objAddressAsRollArray)) {
								$objPreviousChildItems = $objPreviousItem->_objAddressAsRollArray;
								$objChildItem = Address::InstantiateDbRow($objDbRow, $strAliasPrefix . 'addressasroll__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objAddressAsRollArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objAddressAsRollArray[] = Address::InstantiateDbRow($objDbRow, $strAliasPrefix . 'addressasroll__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: AppApprovalAsRoll
						$strAlias = $strAliasPrefix . 'appapprovalasroll__idapp_approval';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objAppApprovalAsRollArray)
								$objPreviousItem->_objAppApprovalAsRollArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objAppApprovalAsRollArray)) {
								$objPreviousChildItems = $objPreviousItem->_objAppApprovalAsRollArray;
								$objChildItem = AppApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appapprovalasroll__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objAppApprovalAsRollArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objAppApprovalAsRollArray[] = AppApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appapprovalasroll__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ApplicationAsProgram
						$strAlias = $strAliasPrefix . 'applicationasprogram__idapplication';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objApplicationAsProgramArray)
								$objPreviousItem->_objApplicationAsProgramArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objApplicationAsProgramArray)) {
								$objPreviousChildItems = $objPreviousItem->_objApplicationAsProgramArray;
								$objChildItem = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationasprogram__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objApplicationAsProgramArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objApplicationAsProgramArray[] = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationasprogram__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ApprovelAsRoll
						$strAlias = $strAliasPrefix . 'approvelasroll__idapprovel';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objApprovelAsRollArray)
								$objPreviousItem->_objApprovelAsRollArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objApprovelAsRollArray)) {
								$objPreviousChildItems = $objPreviousItem->_objApprovelAsRollArray;
								$objChildItem = Approvel::InstantiateDbRow($objDbRow, $strAliasPrefix . 'approvelasroll__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objApprovelAsRollArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objApprovelAsRollArray[] = Approvel::InstantiateDbRow($objDbRow, $strAliasPrefix . 'approvelasroll__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: DeptYearAsDepartment
						$strAlias = $strAliasPrefix . 'deptyearasdepartment__iddept_year';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objDeptYearAsDepartmentArray)
								$objPreviousItem->_objDeptYearAsDepartmentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objDeptYearAsDepartmentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objDeptYearAsDepartmentArray;
								$objChildItem = DeptYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearasdepartment__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objDeptYearAsDepartmentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objDeptYearAsDepartmentArray[] = DeptYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearasdepartment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: DeptYearEventsAsDepartment
						$strAlias = $strAliasPrefix . 'deptyeareventsasdepartment__iddept_year_events';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objDeptYearEventsAsDepartmentArray)
								$objPreviousItem->_objDeptYearEventsAsDepartmentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objDeptYearEventsAsDepartmentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objDeptYearEventsAsDepartmentArray;
								$objChildItem = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasdepartment__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objDeptYearEventsAsDepartmentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objDeptYearEventsAsDepartmentArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasdepartment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: EventAsDepartment
						$strAlias = $strAliasPrefix . 'eventasdepartment__idevent';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objEventAsDepartmentArray)
								$objPreviousItem->_objEventAsDepartmentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objEventAsDepartmentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objEventAsDepartmentArray;
								$objChildItem = Event::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventasdepartment__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objEventAsDepartmentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objEventAsDepartmentArray[] = Event::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventasdepartment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: LoginHasRoleAsId
						$strAlias = $strAliasPrefix . 'loginhasroleasid__login_idlogin';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objLoginHasRoleAsIdArray)
								$objPreviousItem->_objLoginHasRoleAsIdArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objLoginHasRoleAsIdArray)) {
								$objPreviousChildItems = $objPreviousItem->_objLoginHasRoleAsIdArray;
								$objChildItem = LoginHasRole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'loginhasroleasid__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objLoginHasRoleAsIdArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objLoginHasRoleAsIdArray[] = LoginHasRole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'loginhasroleasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: Note
						$strAlias = $strAliasPrefix . 'note__idnote';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objNoteArray)
								$objPreviousItem->_objNoteArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objNoteArray)) {
								$objPreviousChildItems = $objPreviousItem->_objNoteArray;
								$objChildItem = Note::InstantiateDbRow($objDbRow, $strAliasPrefix . 'note__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objNoteArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objNoteArray[] = Note::InstantiateDbRow($objDbRow, $strAliasPrefix . 'note__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: PriceHistoryAsGodown
						$strAlias = $strAliasPrefix . 'pricehistoryasgodown__idprice_history';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objPriceHistoryAsGodownArray)
								$objPreviousItem->_objPriceHistoryAsGodownArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objPriceHistoryAsGodownArray)) {
								$objPreviousChildItems = $objPreviousItem->_objPriceHistoryAsGodownArray;
								$objChildItem = PriceHistory::InstantiateDbRow($objDbRow, $strAliasPrefix . 'pricehistoryasgodown__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objPriceHistoryAsGodownArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objPriceHistoryAsGodownArray[] = PriceHistory::InstantiateDbRow($objDbRow, $strAliasPrefix . 'pricehistoryasgodown__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ProfileAsCourseOfAddmission
						$strAlias = $strAliasPrefix . 'profileascourseofaddmission__idprofile';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objProfileAsCourseOfAddmissionArray)
								$objPreviousItem->_objProfileAsCourseOfAddmissionArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objProfileAsCourseOfAddmissionArray)) {
								$objPreviousChildItems = $objPreviousItem->_objProfileAsCourseOfAddmissionArray;
								$objChildItem = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascourseofaddmission__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objProfileAsCourseOfAddmissionArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objProfileAsCourseOfAddmissionArray[] = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascourseofaddmission__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ProfileAsCurrentCourse
						$strAlias = $strAliasPrefix . 'profileascurrentcourse__idprofile';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objProfileAsCurrentCourseArray)
								$objPreviousItem->_objProfileAsCurrentCourseArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objProfileAsCurrentCourseArray)) {
								$objPreviousChildItems = $objPreviousItem->_objProfileAsCurrentCourseArray;
								$objChildItem = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascurrentcourse__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objProfileAsCurrentCourseArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objProfileAsCurrentCourseArray[] = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascurrentcourse__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ProfileAsBranchOfAddmission
						$strAlias = $strAliasPrefix . 'profileasbranchofaddmission__idprofile';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objProfileAsBranchOfAddmissionArray)
								$objPreviousItem->_objProfileAsBranchOfAddmissionArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objProfileAsBranchOfAddmissionArray)) {
								$objPreviousChildItems = $objPreviousItem->_objProfileAsBranchOfAddmissionArray;
								$objChildItem = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileasbranchofaddmission__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objProfileAsBranchOfAddmissionArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objProfileAsBranchOfAddmissionArray[] = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileasbranchofaddmission__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ProfileAsCurrentBranch
						$strAlias = $strAliasPrefix . 'profileascurrentbranch__idprofile';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objProfileAsCurrentBranchArray)
								$objPreviousItem->_objProfileAsCurrentBranchArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objProfileAsCurrentBranchArray)) {
								$objPreviousChildItems = $objPreviousItem->_objProfileAsCurrentBranchArray;
								$objChildItem = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascurrentbranch__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objProfileAsCurrentBranchArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objProfileAsCurrentBranchArray[] = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascurrentbranch__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ProfileAsAdmissionDiv
						$strAlias = $strAliasPrefix . 'profileasadmissiondiv__idprofile';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objProfileAsAdmissionDivArray)
								$objPreviousItem->_objProfileAsAdmissionDivArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objProfileAsAdmissionDivArray)) {
								$objPreviousChildItems = $objPreviousItem->_objProfileAsAdmissionDivArray;
								$objChildItem = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileasadmissiondiv__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objProfileAsAdmissionDivArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objProfileAsAdmissionDivArray[] = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileasadmissiondiv__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ProfileAsCurrentDiv
						$strAlias = $strAliasPrefix . 'profileascurrentdiv__idprofile';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objProfileAsCurrentDivArray)
								$objPreviousItem->_objProfileAsCurrentDivArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objProfileAsCurrentDivArray)) {
								$objPreviousChildItems = $objPreviousItem->_objProfileAsCurrentDivArray;
								$objChildItem = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascurrentdiv__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objProfileAsCurrentDivArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objProfileAsCurrentDivArray[] = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascurrentdiv__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: RoleAsParrent
						$strAlias = $strAliasPrefix . 'roleasparrent__idrole';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objRoleAsParrentArray)
								$objPreviousItem->_objRoleAsParrentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objRoleAsParrentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objRoleAsParrentArray;
								$objChildItem = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'roleasparrent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objRoleAsParrentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objRoleAsParrentArray[] = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'roleasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: RoleHasMenuAsId
						$strAlias = $strAliasPrefix . 'rolehasmenuasid__role_idrole';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objRoleHasMenuAsIdArray)
								$objPreviousItem->_objRoleHasMenuAsIdArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objRoleHasMenuAsIdArray)) {
								$objPreviousChildItems = $objPreviousItem->_objRoleHasMenuAsIdArray;
								$objChildItem = RoleHasMenu::InstantiateDbRow($objDbRow, $strAliasPrefix . 'rolehasmenuasid__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objRoleHasMenuAsIdArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objRoleHasMenuAsIdArray[] = RoleHasMenu::InstantiateDbRow($objDbRow, $strAliasPrefix . 'rolehasmenuasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'role__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Role object
			$objToReturn = new Role();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdrole = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'name';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strName = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'description';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strDescription = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'parrent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intParrent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'mname';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strMname = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intGrp = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'short_name';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strShortName = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'abbrivation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strAbbrivation = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'service_years';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intServiceYears = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCode = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'count';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCount = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'intake';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIntake = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idrole != $objPreviousItem->Idrole) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objAcademicTempletAsDepartmentArray);
					$cnt = count($objToReturn->_objAcademicTempletAsDepartmentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objAcademicTempletAsDepartmentArray, $objToReturn->_objAcademicTempletAsDepartmentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objAddressAsRollArray);
					$cnt = count($objToReturn->_objAddressAsRollArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objAddressAsRollArray, $objToReturn->_objAddressAsRollArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objAppApprovalAsRollArray);
					$cnt = count($objToReturn->_objAppApprovalAsRollArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objAppApprovalAsRollArray, $objToReturn->_objAppApprovalAsRollArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objApplicationAsProgramArray);
					$cnt = count($objToReturn->_objApplicationAsProgramArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objApplicationAsProgramArray, $objToReturn->_objApplicationAsProgramArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objApprovelAsRollArray);
					$cnt = count($objToReturn->_objApprovelAsRollArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objApprovelAsRollArray, $objToReturn->_objApprovelAsRollArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objDeptYearAsDepartmentArray);
					$cnt = count($objToReturn->_objDeptYearAsDepartmentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objDeptYearAsDepartmentArray, $objToReturn->_objDeptYearAsDepartmentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objDeptYearEventsAsDepartmentArray);
					$cnt = count($objToReturn->_objDeptYearEventsAsDepartmentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objDeptYearEventsAsDepartmentArray, $objToReturn->_objDeptYearEventsAsDepartmentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objEventAsDepartmentArray);
					$cnt = count($objToReturn->_objEventAsDepartmentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objEventAsDepartmentArray, $objToReturn->_objEventAsDepartmentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objLoginHasRoleAsIdArray);
					$cnt = count($objToReturn->_objLoginHasRoleAsIdArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objLoginHasRoleAsIdArray, $objToReturn->_objLoginHasRoleAsIdArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objNoteArray);
					$cnt = count($objToReturn->_objNoteArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objNoteArray, $objToReturn->_objNoteArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objPriceHistoryAsGodownArray);
					$cnt = count($objToReturn->_objPriceHistoryAsGodownArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objPriceHistoryAsGodownArray, $objToReturn->_objPriceHistoryAsGodownArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objProfileAsCourseOfAddmissionArray);
					$cnt = count($objToReturn->_objProfileAsCourseOfAddmissionArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objProfileAsCourseOfAddmissionArray, $objToReturn->_objProfileAsCourseOfAddmissionArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objProfileAsCurrentCourseArray);
					$cnt = count($objToReturn->_objProfileAsCurrentCourseArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objProfileAsCurrentCourseArray, $objToReturn->_objProfileAsCurrentCourseArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objProfileAsBranchOfAddmissionArray);
					$cnt = count($objToReturn->_objProfileAsBranchOfAddmissionArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objProfileAsBranchOfAddmissionArray, $objToReturn->_objProfileAsBranchOfAddmissionArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objProfileAsCurrentBranchArray);
					$cnt = count($objToReturn->_objProfileAsCurrentBranchArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objProfileAsCurrentBranchArray, $objToReturn->_objProfileAsCurrentBranchArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objProfileAsAdmissionDivArray);
					$cnt = count($objToReturn->_objProfileAsAdmissionDivArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objProfileAsAdmissionDivArray, $objToReturn->_objProfileAsAdmissionDivArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objProfileAsCurrentDivArray);
					$cnt = count($objToReturn->_objProfileAsCurrentDivArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objProfileAsCurrentDivArray, $objToReturn->_objProfileAsCurrentDivArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objRoleAsParrentArray);
					$cnt = count($objToReturn->_objRoleAsParrentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objRoleAsParrentArray, $objToReturn->_objRoleAsParrentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objRoleHasMenuAsIdArray);
					$cnt = count($objToReturn->_objRoleHasMenuAsIdArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objRoleHasMenuAsIdArray, $objToReturn->_objRoleHasMenuAsIdArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'role__';

			// Check for ParrentObject Early Binding
			$strAlias = $strAliasPrefix . 'parrent__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objParrentObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'parrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for GrpObject Early Binding
			$strAlias = $strAliasPrefix . 'grp__idgroup';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objGrpObject = Group::InstantiateDbRow($objDbRow, $strAliasPrefix . 'grp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for AcademicTempletAsDepartment Virtual Binding
			$strAlias = $strAliasPrefix . 'academictempletasdepartment__id';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objAcademicTempletAsDepartmentArray)
				$objToReturn->_objAcademicTempletAsDepartmentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objAcademicTempletAsDepartmentArray[] = AcademicTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'academictempletasdepartment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objAcademicTempletAsDepartment = AcademicTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'academictempletasdepartment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for AddressAsRoll Virtual Binding
			$strAlias = $strAliasPrefix . 'addressasroll__idaddress';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objAddressAsRollArray)
				$objToReturn->_objAddressAsRollArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objAddressAsRollArray[] = Address::InstantiateDbRow($objDbRow, $strAliasPrefix . 'addressasroll__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objAddressAsRoll = Address::InstantiateDbRow($objDbRow, $strAliasPrefix . 'addressasroll__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for AppApprovalAsRoll Virtual Binding
			$strAlias = $strAliasPrefix . 'appapprovalasroll__idapp_approval';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objAppApprovalAsRollArray)
				$objToReturn->_objAppApprovalAsRollArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objAppApprovalAsRollArray[] = AppApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appapprovalasroll__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objAppApprovalAsRoll = AppApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appapprovalasroll__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ApplicationAsProgram Virtual Binding
			$strAlias = $strAliasPrefix . 'applicationasprogram__idapplication';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objApplicationAsProgramArray)
				$objToReturn->_objApplicationAsProgramArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objApplicationAsProgramArray[] = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationasprogram__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objApplicationAsProgram = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationasprogram__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ApprovelAsRoll Virtual Binding
			$strAlias = $strAliasPrefix . 'approvelasroll__idapprovel';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objApprovelAsRollArray)
				$objToReturn->_objApprovelAsRollArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objApprovelAsRollArray[] = Approvel::InstantiateDbRow($objDbRow, $strAliasPrefix . 'approvelasroll__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objApprovelAsRoll = Approvel::InstantiateDbRow($objDbRow, $strAliasPrefix . 'approvelasroll__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for DeptYearAsDepartment Virtual Binding
			$strAlias = $strAliasPrefix . 'deptyearasdepartment__iddept_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objDeptYearAsDepartmentArray)
				$objToReturn->_objDeptYearAsDepartmentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objDeptYearAsDepartmentArray[] = DeptYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearasdepartment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objDeptYearAsDepartment = DeptYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearasdepartment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for DeptYearEventsAsDepartment Virtual Binding
			$strAlias = $strAliasPrefix . 'deptyeareventsasdepartment__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objDeptYearEventsAsDepartmentArray)
				$objToReturn->_objDeptYearEventsAsDepartmentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objDeptYearEventsAsDepartmentArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasdepartment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objDeptYearEventsAsDepartment = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasdepartment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for EventAsDepartment Virtual Binding
			$strAlias = $strAliasPrefix . 'eventasdepartment__idevent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objEventAsDepartmentArray)
				$objToReturn->_objEventAsDepartmentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objEventAsDepartmentArray[] = Event::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventasdepartment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objEventAsDepartment = Event::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventasdepartment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for LoginHasRoleAsId Virtual Binding
			$strAlias = $strAliasPrefix . 'loginhasroleasid__login_idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objLoginHasRoleAsIdArray)
				$objToReturn->_objLoginHasRoleAsIdArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objLoginHasRoleAsIdArray[] = LoginHasRole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'loginhasroleasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objLoginHasRoleAsId = LoginHasRole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'loginhasroleasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for Note Virtual Binding
			$strAlias = $strAliasPrefix . 'note__idnote';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objNoteArray)
				$objToReturn->_objNoteArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objNoteArray[] = Note::InstantiateDbRow($objDbRow, $strAliasPrefix . 'note__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objNote = Note::InstantiateDbRow($objDbRow, $strAliasPrefix . 'note__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for PriceHistoryAsGodown Virtual Binding
			$strAlias = $strAliasPrefix . 'pricehistoryasgodown__idprice_history';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objPriceHistoryAsGodownArray)
				$objToReturn->_objPriceHistoryAsGodownArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objPriceHistoryAsGodownArray[] = PriceHistory::InstantiateDbRow($objDbRow, $strAliasPrefix . 'pricehistoryasgodown__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objPriceHistoryAsGodown = PriceHistory::InstantiateDbRow($objDbRow, $strAliasPrefix . 'pricehistoryasgodown__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ProfileAsCourseOfAddmission Virtual Binding
			$strAlias = $strAliasPrefix . 'profileascourseofaddmission__idprofile';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objProfileAsCourseOfAddmissionArray)
				$objToReturn->_objProfileAsCourseOfAddmissionArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objProfileAsCourseOfAddmissionArray[] = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascourseofaddmission__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objProfileAsCourseOfAddmission = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascourseofaddmission__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ProfileAsCurrentCourse Virtual Binding
			$strAlias = $strAliasPrefix . 'profileascurrentcourse__idprofile';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objProfileAsCurrentCourseArray)
				$objToReturn->_objProfileAsCurrentCourseArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objProfileAsCurrentCourseArray[] = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascurrentcourse__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objProfileAsCurrentCourse = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascurrentcourse__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ProfileAsBranchOfAddmission Virtual Binding
			$strAlias = $strAliasPrefix . 'profileasbranchofaddmission__idprofile';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objProfileAsBranchOfAddmissionArray)
				$objToReturn->_objProfileAsBranchOfAddmissionArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objProfileAsBranchOfAddmissionArray[] = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileasbranchofaddmission__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objProfileAsBranchOfAddmission = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileasbranchofaddmission__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ProfileAsCurrentBranch Virtual Binding
			$strAlias = $strAliasPrefix . 'profileascurrentbranch__idprofile';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objProfileAsCurrentBranchArray)
				$objToReturn->_objProfileAsCurrentBranchArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objProfileAsCurrentBranchArray[] = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascurrentbranch__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objProfileAsCurrentBranch = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascurrentbranch__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ProfileAsAdmissionDiv Virtual Binding
			$strAlias = $strAliasPrefix . 'profileasadmissiondiv__idprofile';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objProfileAsAdmissionDivArray)
				$objToReturn->_objProfileAsAdmissionDivArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objProfileAsAdmissionDivArray[] = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileasadmissiondiv__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objProfileAsAdmissionDiv = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileasadmissiondiv__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ProfileAsCurrentDiv Virtual Binding
			$strAlias = $strAliasPrefix . 'profileascurrentdiv__idprofile';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objProfileAsCurrentDivArray)
				$objToReturn->_objProfileAsCurrentDivArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objProfileAsCurrentDivArray[] = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascurrentdiv__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objProfileAsCurrentDiv = Profile::InstantiateDbRow($objDbRow, $strAliasPrefix . 'profileascurrentdiv__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for RoleAsParrent Virtual Binding
			$strAlias = $strAliasPrefix . 'roleasparrent__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objRoleAsParrentArray)
				$objToReturn->_objRoleAsParrentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objRoleAsParrentArray[] = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'roleasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objRoleAsParrent = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'roleasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for RoleHasMenuAsId Virtual Binding
			$strAlias = $strAliasPrefix . 'rolehasmenuasid__role_idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objRoleHasMenuAsIdArray)
				$objToReturn->_objRoleHasMenuAsIdArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objRoleHasMenuAsIdArray[] = RoleHasMenu::InstantiateDbRow($objDbRow, $strAliasPrefix . 'rolehasmenuasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objRoleHasMenuAsId = RoleHasMenu::InstantiateDbRow($objDbRow, $strAliasPrefix . 'rolehasmenuasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Roles from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Role[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Role::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Role::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Role object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Role next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Role::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Role object,
		 * by Idrole Index(es)
		 * @param integer $intIdrole
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Role
		*/
		public static function LoadByIdrole($intIdrole, $objOptionalClauses = null) {
			return Role::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Role()->Idrole, $intIdrole)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single Role object,
		 * by Name Index(es)
		 * @param string $strName
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Role
		*/
		public static function LoadByName($strName, $objOptionalClauses = null) {
			return Role::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Role()->Name, $strName)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single Role object,
		 * by ShortName Index(es)
		 * @param string $strShortName
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Role
		*/
		public static function LoadByShortName($strShortName, $objOptionalClauses = null) {
			return Role::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Role()->ShortName, $strShortName)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Role objects,
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Role[]
		*/
		public static function LoadArrayByParrent($intParrent, $objOptionalClauses = null) {
			// Call Role::QueryArray to perform the LoadArrayByParrent query
			try {
				return Role::QueryArray(
					QQ::Equal(QQN::Role()->Parrent, $intParrent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Roles
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @return int
		*/
		public static function CountByParrent($intParrent) {
			// Call Role::QueryCount to perform the CountByParrent query
			return Role::QueryCount(
				QQ::Equal(QQN::Role()->Parrent, $intParrent)
			);
		}

		/**
		 * Load an array of Role objects,
		 * by Grp Index(es)
		 * @param integer $intGrp
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Role[]
		*/
		public static function LoadArrayByGrp($intGrp, $objOptionalClauses = null) {
			// Call Role::QueryArray to perform the LoadArrayByGrp query
			try {
				return Role::QueryArray(
					QQ::Equal(QQN::Role()->Grp, $intGrp),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Roles
		 * by Grp Index(es)
		 * @param integer $intGrp
		 * @return int
		*/
		public static function CountByGrp($intGrp) {
			// Call Role::QueryCount to perform the CountByGrp query
			return Role::QueryCount(
				QQ::Equal(QQN::Role()->Grp, $intGrp)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Role
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `role` (
							`name`,
							`description`,
							`parrent`,
							`mname`,
							`grp`,
							`short_name`,
							`abbrivation`,
							`service_years`,
							`code`,
							`count`,
							`intake`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strName) . ',
							' . $objDatabase->SqlVariable($this->strDescription) . ',
							' . $objDatabase->SqlVariable($this->intParrent) . ',
							' . $objDatabase->SqlVariable($this->strMname) . ',
							' . $objDatabase->SqlVariable($this->intGrp) . ',
							' . $objDatabase->SqlVariable($this->strShortName) . ',
							' . $objDatabase->SqlVariable($this->strAbbrivation) . ',
							' . $objDatabase->SqlVariable($this->intServiceYears) . ',
							' . $objDatabase->SqlVariable($this->intCode) . ',
							' . $objDatabase->SqlVariable($this->strCount) . ',
							' . $objDatabase->SqlVariable($this->intIntake) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdrole = $objDatabase->InsertId('role', 'idrole');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`role`
						SET
							`name` = ' . $objDatabase->SqlVariable($this->strName) . ',
							`description` = ' . $objDatabase->SqlVariable($this->strDescription) . ',
							`parrent` = ' . $objDatabase->SqlVariable($this->intParrent) . ',
							`mname` = ' . $objDatabase->SqlVariable($this->strMname) . ',
							`grp` = ' . $objDatabase->SqlVariable($this->intGrp) . ',
							`short_name` = ' . $objDatabase->SqlVariable($this->strShortName) . ',
							`abbrivation` = ' . $objDatabase->SqlVariable($this->strAbbrivation) . ',
							`service_years` = ' . $objDatabase->SqlVariable($this->intServiceYears) . ',
							`code` = ' . $objDatabase->SqlVariable($this->intCode) . ',
							`count` = ' . $objDatabase->SqlVariable($this->strCount) . ',
							`intake` = ' . $objDatabase->SqlVariable($this->intIntake) . '
						WHERE
							`idrole` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Role
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Role with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`role`
				WHERE
					`idrole` = ' . $objDatabase->SqlVariable($this->intIdrole) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Role ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Role', $this->intIdrole);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Roles
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`role`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate role table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `role`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Role from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Role object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Role::Load($this->intIdrole);

			// Update $this's local variables to match
			$this->strName = $objReloaded->strName;
			$this->strDescription = $objReloaded->strDescription;
			$this->Parrent = $objReloaded->Parrent;
			$this->strMname = $objReloaded->strMname;
			$this->Grp = $objReloaded->Grp;
			$this->strShortName = $objReloaded->strShortName;
			$this->strAbbrivation = $objReloaded->strAbbrivation;
			$this->intServiceYears = $objReloaded->intServiceYears;
			$this->intCode = $objReloaded->intCode;
			$this->strCount = $objReloaded->strCount;
			$this->intIntake = $objReloaded->intIntake;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idrole':
					/**
					 * Gets the value for intIdrole (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdrole;

				case 'Name':
					/**
					 * Gets the value for strName (Unique)
					 * @return string
					 */
					return $this->strName;

				case 'Description':
					/**
					 * Gets the value for strDescription (Not Null)
					 * @return string
					 */
					return $this->strDescription;

				case 'Parrent':
					/**
					 * Gets the value for intParrent 
					 * @return integer
					 */
					return $this->intParrent;

				case 'Mname':
					/**
					 * Gets the value for strMname 
					 * @return string
					 */
					return $this->strMname;

				case 'Grp':
					/**
					 * Gets the value for intGrp 
					 * @return integer
					 */
					return $this->intGrp;

				case 'ShortName':
					/**
					 * Gets the value for strShortName (Unique)
					 * @return string
					 */
					return $this->strShortName;

				case 'Abbrivation':
					/**
					 * Gets the value for strAbbrivation 
					 * @return string
					 */
					return $this->strAbbrivation;

				case 'ServiceYears':
					/**
					 * Gets the value for intServiceYears 
					 * @return integer
					 */
					return $this->intServiceYears;

				case 'Code':
					/**
					 * Gets the value for intCode 
					 * @return integer
					 */
					return $this->intCode;

				case 'Count':
					/**
					 * Gets the value for strCount 
					 * @return string
					 */
					return $this->strCount;

				case 'Intake':
					/**
					 * Gets the value for intIntake 
					 * @return integer
					 */
					return $this->intIntake;


				///////////////////
				// Member Objects
				///////////////////
				case 'ParrentObject':
					/**
					 * Gets the value for the Role object referenced by intParrent 
					 * @return Role
					 */
					try {
						if ((!$this->objParrentObject) && (!is_null($this->intParrent)))
							$this->objParrentObject = Role::Load($this->intParrent);
						return $this->objParrentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GrpObject':
					/**
					 * Gets the value for the Group object referenced by intGrp 
					 * @return Group
					 */
					try {
						if ((!$this->objGrpObject) && (!is_null($this->intGrp)))
							$this->objGrpObject = Group::Load($this->intGrp);
						return $this->objGrpObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_AcademicTempletAsDepartment':
					/**
					 * Gets the value for the private _objAcademicTempletAsDepartment (Read-Only)
					 * if set due to an expansion on the academic_templet.department reverse relationship
					 * @return AcademicTemplet
					 */
					return $this->_objAcademicTempletAsDepartment;

				case '_AcademicTempletAsDepartmentArray':
					/**
					 * Gets the value for the private _objAcademicTempletAsDepartmentArray (Read-Only)
					 * if set due to an ExpandAsArray on the academic_templet.department reverse relationship
					 * @return AcademicTemplet[]
					 */
					return $this->_objAcademicTempletAsDepartmentArray;

				case '_AddressAsRoll':
					/**
					 * Gets the value for the private _objAddressAsRoll (Read-Only)
					 * if set due to an expansion on the address.roll reverse relationship
					 * @return Address
					 */
					return $this->_objAddressAsRoll;

				case '_AddressAsRollArray':
					/**
					 * Gets the value for the private _objAddressAsRollArray (Read-Only)
					 * if set due to an ExpandAsArray on the address.roll reverse relationship
					 * @return Address[]
					 */
					return $this->_objAddressAsRollArray;

				case '_AppApprovalAsRoll':
					/**
					 * Gets the value for the private _objAppApprovalAsRoll (Read-Only)
					 * if set due to an expansion on the app_approval.roll reverse relationship
					 * @return AppApproval
					 */
					return $this->_objAppApprovalAsRoll;

				case '_AppApprovalAsRollArray':
					/**
					 * Gets the value for the private _objAppApprovalAsRollArray (Read-Only)
					 * if set due to an ExpandAsArray on the app_approval.roll reverse relationship
					 * @return AppApproval[]
					 */
					return $this->_objAppApprovalAsRollArray;

				case '_ApplicationAsProgram':
					/**
					 * Gets the value for the private _objApplicationAsProgram (Read-Only)
					 * if set due to an expansion on the application.program reverse relationship
					 * @return Application
					 */
					return $this->_objApplicationAsProgram;

				case '_ApplicationAsProgramArray':
					/**
					 * Gets the value for the private _objApplicationAsProgramArray (Read-Only)
					 * if set due to an ExpandAsArray on the application.program reverse relationship
					 * @return Application[]
					 */
					return $this->_objApplicationAsProgramArray;

				case '_ApprovelAsRoll':
					/**
					 * Gets the value for the private _objApprovelAsRoll (Read-Only)
					 * if set due to an expansion on the approvel.roll reverse relationship
					 * @return Approvel
					 */
					return $this->_objApprovelAsRoll;

				case '_ApprovelAsRollArray':
					/**
					 * Gets the value for the private _objApprovelAsRollArray (Read-Only)
					 * if set due to an ExpandAsArray on the approvel.roll reverse relationship
					 * @return Approvel[]
					 */
					return $this->_objApprovelAsRollArray;

				case '_DeptYearAsDepartment':
					/**
					 * Gets the value for the private _objDeptYearAsDepartment (Read-Only)
					 * if set due to an expansion on the dept_year.department reverse relationship
					 * @return DeptYear
					 */
					return $this->_objDeptYearAsDepartment;

				case '_DeptYearAsDepartmentArray':
					/**
					 * Gets the value for the private _objDeptYearAsDepartmentArray (Read-Only)
					 * if set due to an ExpandAsArray on the dept_year.department reverse relationship
					 * @return DeptYear[]
					 */
					return $this->_objDeptYearAsDepartmentArray;

				case '_DeptYearEventsAsDepartment':
					/**
					 * Gets the value for the private _objDeptYearEventsAsDepartment (Read-Only)
					 * if set due to an expansion on the dept_year_events.department reverse relationship
					 * @return DeptYearEvents
					 */
					return $this->_objDeptYearEventsAsDepartment;

				case '_DeptYearEventsAsDepartmentArray':
					/**
					 * Gets the value for the private _objDeptYearEventsAsDepartmentArray (Read-Only)
					 * if set due to an ExpandAsArray on the dept_year_events.department reverse relationship
					 * @return DeptYearEvents[]
					 */
					return $this->_objDeptYearEventsAsDepartmentArray;

				case '_EventAsDepartment':
					/**
					 * Gets the value for the private _objEventAsDepartment (Read-Only)
					 * if set due to an expansion on the event.department reverse relationship
					 * @return Event
					 */
					return $this->_objEventAsDepartment;

				case '_EventAsDepartmentArray':
					/**
					 * Gets the value for the private _objEventAsDepartmentArray (Read-Only)
					 * if set due to an ExpandAsArray on the event.department reverse relationship
					 * @return Event[]
					 */
					return $this->_objEventAsDepartmentArray;

				case '_LoginHasRoleAsId':
					/**
					 * Gets the value for the private _objLoginHasRoleAsId (Read-Only)
					 * if set due to an expansion on the login_has_role.role_idrole reverse relationship
					 * @return LoginHasRole
					 */
					return $this->_objLoginHasRoleAsId;

				case '_LoginHasRoleAsIdArray':
					/**
					 * Gets the value for the private _objLoginHasRoleAsIdArray (Read-Only)
					 * if set due to an ExpandAsArray on the login_has_role.role_idrole reverse relationship
					 * @return LoginHasRole[]
					 */
					return $this->_objLoginHasRoleAsIdArray;

				case '_Note':
					/**
					 * Gets the value for the private _objNote (Read-Only)
					 * if set due to an expansion on the note.role reverse relationship
					 * @return Note
					 */
					return $this->_objNote;

				case '_NoteArray':
					/**
					 * Gets the value for the private _objNoteArray (Read-Only)
					 * if set due to an ExpandAsArray on the note.role reverse relationship
					 * @return Note[]
					 */
					return $this->_objNoteArray;

				case '_PriceHistoryAsGodown':
					/**
					 * Gets the value for the private _objPriceHistoryAsGodown (Read-Only)
					 * if set due to an expansion on the price_history.godown reverse relationship
					 * @return PriceHistory
					 */
					return $this->_objPriceHistoryAsGodown;

				case '_PriceHistoryAsGodownArray':
					/**
					 * Gets the value for the private _objPriceHistoryAsGodownArray (Read-Only)
					 * if set due to an ExpandAsArray on the price_history.godown reverse relationship
					 * @return PriceHistory[]
					 */
					return $this->_objPriceHistoryAsGodownArray;

				case '_ProfileAsCourseOfAddmission':
					/**
					 * Gets the value for the private _objProfileAsCourseOfAddmission (Read-Only)
					 * if set due to an expansion on the profile.course_of_addmission reverse relationship
					 * @return Profile
					 */
					return $this->_objProfileAsCourseOfAddmission;

				case '_ProfileAsCourseOfAddmissionArray':
					/**
					 * Gets the value for the private _objProfileAsCourseOfAddmissionArray (Read-Only)
					 * if set due to an ExpandAsArray on the profile.course_of_addmission reverse relationship
					 * @return Profile[]
					 */
					return $this->_objProfileAsCourseOfAddmissionArray;

				case '_ProfileAsCurrentCourse':
					/**
					 * Gets the value for the private _objProfileAsCurrentCourse (Read-Only)
					 * if set due to an expansion on the profile.current_course reverse relationship
					 * @return Profile
					 */
					return $this->_objProfileAsCurrentCourse;

				case '_ProfileAsCurrentCourseArray':
					/**
					 * Gets the value for the private _objProfileAsCurrentCourseArray (Read-Only)
					 * if set due to an ExpandAsArray on the profile.current_course reverse relationship
					 * @return Profile[]
					 */
					return $this->_objProfileAsCurrentCourseArray;

				case '_ProfileAsBranchOfAddmission':
					/**
					 * Gets the value for the private _objProfileAsBranchOfAddmission (Read-Only)
					 * if set due to an expansion on the profile.branch_of_addmission reverse relationship
					 * @return Profile
					 */
					return $this->_objProfileAsBranchOfAddmission;

				case '_ProfileAsBranchOfAddmissionArray':
					/**
					 * Gets the value for the private _objProfileAsBranchOfAddmissionArray (Read-Only)
					 * if set due to an ExpandAsArray on the profile.branch_of_addmission reverse relationship
					 * @return Profile[]
					 */
					return $this->_objProfileAsBranchOfAddmissionArray;

				case '_ProfileAsCurrentBranch':
					/**
					 * Gets the value for the private _objProfileAsCurrentBranch (Read-Only)
					 * if set due to an expansion on the profile.current_branch reverse relationship
					 * @return Profile
					 */
					return $this->_objProfileAsCurrentBranch;

				case '_ProfileAsCurrentBranchArray':
					/**
					 * Gets the value for the private _objProfileAsCurrentBranchArray (Read-Only)
					 * if set due to an ExpandAsArray on the profile.current_branch reverse relationship
					 * @return Profile[]
					 */
					return $this->_objProfileAsCurrentBranchArray;

				case '_ProfileAsAdmissionDiv':
					/**
					 * Gets the value for the private _objProfileAsAdmissionDiv (Read-Only)
					 * if set due to an expansion on the profile.admission_div reverse relationship
					 * @return Profile
					 */
					return $this->_objProfileAsAdmissionDiv;

				case '_ProfileAsAdmissionDivArray':
					/**
					 * Gets the value for the private _objProfileAsAdmissionDivArray (Read-Only)
					 * if set due to an ExpandAsArray on the profile.admission_div reverse relationship
					 * @return Profile[]
					 */
					return $this->_objProfileAsAdmissionDivArray;

				case '_ProfileAsCurrentDiv':
					/**
					 * Gets the value for the private _objProfileAsCurrentDiv (Read-Only)
					 * if set due to an expansion on the profile.current_div reverse relationship
					 * @return Profile
					 */
					return $this->_objProfileAsCurrentDiv;

				case '_ProfileAsCurrentDivArray':
					/**
					 * Gets the value for the private _objProfileAsCurrentDivArray (Read-Only)
					 * if set due to an ExpandAsArray on the profile.current_div reverse relationship
					 * @return Profile[]
					 */
					return $this->_objProfileAsCurrentDivArray;

				case '_RoleAsParrent':
					/**
					 * Gets the value for the private _objRoleAsParrent (Read-Only)
					 * if set due to an expansion on the role.parrent reverse relationship
					 * @return Role
					 */
					return $this->_objRoleAsParrent;

				case '_RoleAsParrentArray':
					/**
					 * Gets the value for the private _objRoleAsParrentArray (Read-Only)
					 * if set due to an ExpandAsArray on the role.parrent reverse relationship
					 * @return Role[]
					 */
					return $this->_objRoleAsParrentArray;

				case '_RoleHasMenuAsId':
					/**
					 * Gets the value for the private _objRoleHasMenuAsId (Read-Only)
					 * if set due to an expansion on the role_has_menu.role_idrole reverse relationship
					 * @return RoleHasMenu
					 */
					return $this->_objRoleHasMenuAsId;

				case '_RoleHasMenuAsIdArray':
					/**
					 * Gets the value for the private _objRoleHasMenuAsIdArray (Read-Only)
					 * if set due to an ExpandAsArray on the role_has_menu.role_idrole reverse relationship
					 * @return RoleHasMenu[]
					 */
					return $this->_objRoleHasMenuAsIdArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Name':
					/**
					 * Sets the value for strName (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strName = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Description':
					/**
					 * Sets the value for strDescription (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strDescription = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Parrent':
					/**
					 * Sets the value for intParrent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objParrentObject = null;
						return ($this->intParrent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Mname':
					/**
					 * Sets the value for strMname 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strMname = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Grp':
					/**
					 * Sets the value for intGrp 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objGrpObject = null;
						return ($this->intGrp = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ShortName':
					/**
					 * Sets the value for strShortName (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strShortName = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Abbrivation':
					/**
					 * Sets the value for strAbbrivation 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strAbbrivation = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ServiceYears':
					/**
					 * Sets the value for intServiceYears 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intServiceYears = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Code':
					/**
					 * Sets the value for intCode 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intCode = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Count':
					/**
					 * Sets the value for strCount 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCount = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Intake':
					/**
					 * Sets the value for intIntake 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intIntake = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'ParrentObject':
					/**
					 * Sets the value for the Role object referenced by intParrent 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intParrent = null;
						$this->objParrentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved ParrentObject for this Role');

						// Update Local Member Variables
						$this->objParrentObject = $mixValue;
						$this->intParrent = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'GrpObject':
					/**
					 * Sets the value for the Group object referenced by intGrp 
					 * @param Group $mixValue
					 * @return Group
					 */
					if (is_null($mixValue)) {
						$this->intGrp = null;
						$this->objGrpObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Group object
						try {
							$mixValue = QType::Cast($mixValue, 'Group');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Group object
						if (is_null($mixValue->Idgroup))
							throw new QCallerException('Unable to set an unsaved GrpObject for this Role');

						// Update Local Member Variables
						$this->objGrpObject = $mixValue;
						$this->intGrp = $mixValue->Idgroup;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for AcademicTempletAsDepartment
		//-------------------------------------------------------------------

		/**
		 * Gets all associated AcademicTempletsAsDepartment as an array of AcademicTemplet objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AcademicTemplet[]
		*/
		public function GetAcademicTempletAsDepartmentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return AcademicTemplet::LoadArrayByDepartment($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated AcademicTempletsAsDepartment
		 * @return int
		*/
		public function CountAcademicTempletsAsDepartment() {
			if ((is_null($this->intIdrole)))
				return 0;

			return AcademicTemplet::CountByDepartment($this->intIdrole);
		}

		/**
		 * Associates a AcademicTempletAsDepartment
		 * @param AcademicTemplet $objAcademicTemplet
		 * @return void
		*/
		public function AssociateAcademicTempletAsDepartment(AcademicTemplet $objAcademicTemplet) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAcademicTempletAsDepartment on this unsaved Role.');
			if ((is_null($objAcademicTemplet->Id)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAcademicTempletAsDepartment on this Role with an unsaved AcademicTemplet.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`academic_templet`
				SET
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`id` = ' . $objDatabase->SqlVariable($objAcademicTemplet->Id) . '
			');
		}

		/**
		 * Unassociates a AcademicTempletAsDepartment
		 * @param AcademicTemplet $objAcademicTemplet
		 * @return void
		*/
		public function UnassociateAcademicTempletAsDepartment(AcademicTemplet $objAcademicTemplet) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAcademicTempletAsDepartment on this unsaved Role.');
			if ((is_null($objAcademicTemplet->Id)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAcademicTempletAsDepartment on this Role with an unsaved AcademicTemplet.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`academic_templet`
				SET
					`department` = null
				WHERE
					`id` = ' . $objDatabase->SqlVariable($objAcademicTemplet->Id) . ' AND
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all AcademicTempletsAsDepartment
		 * @return void
		*/
		public function UnassociateAllAcademicTempletsAsDepartment() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAcademicTempletAsDepartment on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`academic_templet`
				SET
					`department` = null
				WHERE
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated AcademicTempletAsDepartment
		 * @param AcademicTemplet $objAcademicTemplet
		 * @return void
		*/
		public function DeleteAssociatedAcademicTempletAsDepartment(AcademicTemplet $objAcademicTemplet) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAcademicTempletAsDepartment on this unsaved Role.');
			if ((is_null($objAcademicTemplet->Id)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAcademicTempletAsDepartment on this Role with an unsaved AcademicTemplet.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`academic_templet`
				WHERE
					`id` = ' . $objDatabase->SqlVariable($objAcademicTemplet->Id) . ' AND
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated AcademicTempletsAsDepartment
		 * @return void
		*/
		public function DeleteAllAcademicTempletsAsDepartment() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAcademicTempletAsDepartment on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`academic_templet`
				WHERE
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for AddressAsRoll
		//-------------------------------------------------------------------

		/**
		 * Gets all associated AddressesAsRoll as an array of Address objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Address[]
		*/
		public function GetAddressAsRollArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return Address::LoadArrayByRoll($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated AddressesAsRoll
		 * @return int
		*/
		public function CountAddressesAsRoll() {
			if ((is_null($this->intIdrole)))
				return 0;

			return Address::CountByRoll($this->intIdrole);
		}

		/**
		 * Associates a AddressAsRoll
		 * @param Address $objAddress
		 * @return void
		*/
		public function AssociateAddressAsRoll(Address $objAddress) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAddressAsRoll on this unsaved Role.');
			if ((is_null($objAddress->Idaddress)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAddressAsRoll on this Role with an unsaved Address.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`address`
				SET
					`roll` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`idaddress` = ' . $objDatabase->SqlVariable($objAddress->Idaddress) . '
			');
		}

		/**
		 * Unassociates a AddressAsRoll
		 * @param Address $objAddress
		 * @return void
		*/
		public function UnassociateAddressAsRoll(Address $objAddress) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAddressAsRoll on this unsaved Role.');
			if ((is_null($objAddress->Idaddress)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAddressAsRoll on this Role with an unsaved Address.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`address`
				SET
					`roll` = null
				WHERE
					`idaddress` = ' . $objDatabase->SqlVariable($objAddress->Idaddress) . ' AND
					`roll` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all AddressesAsRoll
		 * @return void
		*/
		public function UnassociateAllAddressesAsRoll() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAddressAsRoll on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`address`
				SET
					`roll` = null
				WHERE
					`roll` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated AddressAsRoll
		 * @param Address $objAddress
		 * @return void
		*/
		public function DeleteAssociatedAddressAsRoll(Address $objAddress) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAddressAsRoll on this unsaved Role.');
			if ((is_null($objAddress->Idaddress)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAddressAsRoll on this Role with an unsaved Address.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`address`
				WHERE
					`idaddress` = ' . $objDatabase->SqlVariable($objAddress->Idaddress) . ' AND
					`roll` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated AddressesAsRoll
		 * @return void
		*/
		public function DeleteAllAddressesAsRoll() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAddressAsRoll on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`address`
				WHERE
					`roll` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for AppApprovalAsRoll
		//-------------------------------------------------------------------

		/**
		 * Gets all associated AppApprovalsAsRoll as an array of AppApproval objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppApproval[]
		*/
		public function GetAppApprovalAsRollArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return AppApproval::LoadArrayByRoll($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated AppApprovalsAsRoll
		 * @return int
		*/
		public function CountAppApprovalsAsRoll() {
			if ((is_null($this->intIdrole)))
				return 0;

			return AppApproval::CountByRoll($this->intIdrole);
		}

		/**
		 * Associates a AppApprovalAsRoll
		 * @param AppApproval $objAppApproval
		 * @return void
		*/
		public function AssociateAppApprovalAsRoll(AppApproval $objAppApproval) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppApprovalAsRoll on this unsaved Role.');
			if ((is_null($objAppApproval->IdappApproval)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppApprovalAsRoll on this Role with an unsaved AppApproval.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`app_approval`
				SET
					`roll` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`idapp_approval` = ' . $objDatabase->SqlVariable($objAppApproval->IdappApproval) . '
			');
		}

		/**
		 * Unassociates a AppApprovalAsRoll
		 * @param AppApproval $objAppApproval
		 * @return void
		*/
		public function UnassociateAppApprovalAsRoll(AppApproval $objAppApproval) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsRoll on this unsaved Role.');
			if ((is_null($objAppApproval->IdappApproval)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsRoll on this Role with an unsaved AppApproval.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`app_approval`
				SET
					`roll` = null
				WHERE
					`idapp_approval` = ' . $objDatabase->SqlVariable($objAppApproval->IdappApproval) . ' AND
					`roll` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all AppApprovalsAsRoll
		 * @return void
		*/
		public function UnassociateAllAppApprovalsAsRoll() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsRoll on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`app_approval`
				SET
					`roll` = null
				WHERE
					`roll` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated AppApprovalAsRoll
		 * @param AppApproval $objAppApproval
		 * @return void
		*/
		public function DeleteAssociatedAppApprovalAsRoll(AppApproval $objAppApproval) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsRoll on this unsaved Role.');
			if ((is_null($objAppApproval->IdappApproval)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsRoll on this Role with an unsaved AppApproval.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`app_approval`
				WHERE
					`idapp_approval` = ' . $objDatabase->SqlVariable($objAppApproval->IdappApproval) . ' AND
					`roll` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated AppApprovalsAsRoll
		 * @return void
		*/
		public function DeleteAllAppApprovalsAsRoll() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsRoll on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`app_approval`
				WHERE
					`roll` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for ApplicationAsProgram
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ApplicationsAsProgram as an array of Application objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Application[]
		*/
		public function GetApplicationAsProgramArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return Application::LoadArrayByProgram($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ApplicationsAsProgram
		 * @return int
		*/
		public function CountApplicationsAsProgram() {
			if ((is_null($this->intIdrole)))
				return 0;

			return Application::CountByProgram($this->intIdrole);
		}

		/**
		 * Associates a ApplicationAsProgram
		 * @param Application $objApplication
		 * @return void
		*/
		public function AssociateApplicationAsProgram(Application $objApplication) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplicationAsProgram on this unsaved Role.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplicationAsProgram on this Role with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`program` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . '
			');
		}

		/**
		 * Unassociates a ApplicationAsProgram
		 * @param Application $objApplication
		 * @return void
		*/
		public function UnassociateApplicationAsProgram(Application $objApplication) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsProgram on this unsaved Role.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsProgram on this Role with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`program` = null
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . ' AND
					`program` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all ApplicationsAsProgram
		 * @return void
		*/
		public function UnassociateAllApplicationsAsProgram() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsProgram on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`program` = null
				WHERE
					`program` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated ApplicationAsProgram
		 * @param Application $objApplication
		 * @return void
		*/
		public function DeleteAssociatedApplicationAsProgram(Application $objApplication) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsProgram on this unsaved Role.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsProgram on this Role with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`application`
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . ' AND
					`program` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated ApplicationsAsProgram
		 * @return void
		*/
		public function DeleteAllApplicationsAsProgram() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsProgram on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`application`
				WHERE
					`program` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for ApprovelAsRoll
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ApprovelsAsRoll as an array of Approvel objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Approvel[]
		*/
		public function GetApprovelAsRollArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return Approvel::LoadArrayByRoll($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ApprovelsAsRoll
		 * @return int
		*/
		public function CountApprovelsAsRoll() {
			if ((is_null($this->intIdrole)))
				return 0;

			return Approvel::CountByRoll($this->intIdrole);
		}

		/**
		 * Associates a ApprovelAsRoll
		 * @param Approvel $objApprovel
		 * @return void
		*/
		public function AssociateApprovelAsRoll(Approvel $objApprovel) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApprovelAsRoll on this unsaved Role.');
			if ((is_null($objApprovel->Idapprovel)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApprovelAsRoll on this Role with an unsaved Approvel.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`approvel`
				SET
					`roll` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`idapprovel` = ' . $objDatabase->SqlVariable($objApprovel->Idapprovel) . '
			');
		}

		/**
		 * Unassociates a ApprovelAsRoll
		 * @param Approvel $objApprovel
		 * @return void
		*/
		public function UnassociateApprovelAsRoll(Approvel $objApprovel) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApprovelAsRoll on this unsaved Role.');
			if ((is_null($objApprovel->Idapprovel)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApprovelAsRoll on this Role with an unsaved Approvel.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`approvel`
				SET
					`roll` = null
				WHERE
					`idapprovel` = ' . $objDatabase->SqlVariable($objApprovel->Idapprovel) . ' AND
					`roll` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all ApprovelsAsRoll
		 * @return void
		*/
		public function UnassociateAllApprovelsAsRoll() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApprovelAsRoll on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`approvel`
				SET
					`roll` = null
				WHERE
					`roll` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated ApprovelAsRoll
		 * @param Approvel $objApprovel
		 * @return void
		*/
		public function DeleteAssociatedApprovelAsRoll(Approvel $objApprovel) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApprovelAsRoll on this unsaved Role.');
			if ((is_null($objApprovel->Idapprovel)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApprovelAsRoll on this Role with an unsaved Approvel.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`approvel`
				WHERE
					`idapprovel` = ' . $objDatabase->SqlVariable($objApprovel->Idapprovel) . ' AND
					`roll` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated ApprovelsAsRoll
		 * @return void
		*/
		public function DeleteAllApprovelsAsRoll() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApprovelAsRoll on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`approvel`
				WHERE
					`roll` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for DeptYearAsDepartment
		//-------------------------------------------------------------------

		/**
		 * Gets all associated DeptYearsAsDepartment as an array of DeptYear objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYear[]
		*/
		public function GetDeptYearAsDepartmentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return DeptYear::LoadArrayByDepartment($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated DeptYearsAsDepartment
		 * @return int
		*/
		public function CountDeptYearsAsDepartment() {
			if ((is_null($this->intIdrole)))
				return 0;

			return DeptYear::CountByDepartment($this->intIdrole);
		}

		/**
		 * Associates a DeptYearAsDepartment
		 * @param DeptYear $objDeptYear
		 * @return void
		*/
		public function AssociateDeptYearAsDepartment(DeptYear $objDeptYear) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearAsDepartment on this unsaved Role.');
			if ((is_null($objDeptYear->IddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearAsDepartment on this Role with an unsaved DeptYear.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year`
				SET
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`iddept_year` = ' . $objDatabase->SqlVariable($objDeptYear->IddeptYear) . '
			');
		}

		/**
		 * Unassociates a DeptYearAsDepartment
		 * @param DeptYear $objDeptYear
		 * @return void
		*/
		public function UnassociateDeptYearAsDepartment(DeptYear $objDeptYear) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearAsDepartment on this unsaved Role.');
			if ((is_null($objDeptYear->IddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearAsDepartment on this Role with an unsaved DeptYear.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year`
				SET
					`department` = null
				WHERE
					`iddept_year` = ' . $objDatabase->SqlVariable($objDeptYear->IddeptYear) . ' AND
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all DeptYearsAsDepartment
		 * @return void
		*/
		public function UnassociateAllDeptYearsAsDepartment() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearAsDepartment on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year`
				SET
					`department` = null
				WHERE
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated DeptYearAsDepartment
		 * @param DeptYear $objDeptYear
		 * @return void
		*/
		public function DeleteAssociatedDeptYearAsDepartment(DeptYear $objDeptYear) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearAsDepartment on this unsaved Role.');
			if ((is_null($objDeptYear->IddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearAsDepartment on this Role with an unsaved DeptYear.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year`
				WHERE
					`iddept_year` = ' . $objDatabase->SqlVariable($objDeptYear->IddeptYear) . ' AND
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated DeptYearsAsDepartment
		 * @return void
		*/
		public function DeleteAllDeptYearsAsDepartment() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearAsDepartment on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year`
				WHERE
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for DeptYearEventsAsDepartment
		//-------------------------------------------------------------------

		/**
		 * Gets all associated DeptYearEventsesAsDepartment as an array of DeptYearEvents objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public function GetDeptYearEventsAsDepartmentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return DeptYearEvents::LoadArrayByDepartment($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated DeptYearEventsesAsDepartment
		 * @return int
		*/
		public function CountDeptYearEventsesAsDepartment() {
			if ((is_null($this->intIdrole)))
				return 0;

			return DeptYearEvents::CountByDepartment($this->intIdrole);
		}

		/**
		 * Associates a DeptYearEventsAsDepartment
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function AssociateDeptYearEventsAsDepartment(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEventsAsDepartment on this unsaved Role.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEventsAsDepartment on this Role with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates a DeptYearEventsAsDepartment
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function UnassociateDeptYearEventsAsDepartment(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsDepartment on this unsaved Role.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsDepartment on this Role with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`department` = null
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all DeptYearEventsesAsDepartment
		 * @return void
		*/
		public function UnassociateAllDeptYearEventsesAsDepartment() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsDepartment on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`department` = null
				WHERE
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated DeptYearEventsAsDepartment
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function DeleteAssociatedDeptYearEventsAsDepartment(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsDepartment on this unsaved Role.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsDepartment on this Role with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated DeptYearEventsesAsDepartment
		 * @return void
		*/
		public function DeleteAllDeptYearEventsesAsDepartment() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsDepartment on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for EventAsDepartment
		//-------------------------------------------------------------------

		/**
		 * Gets all associated EventsAsDepartment as an array of Event objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Event[]
		*/
		public function GetEventAsDepartmentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return Event::LoadArrayByDepartment($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated EventsAsDepartment
		 * @return int
		*/
		public function CountEventsAsDepartment() {
			if ((is_null($this->intIdrole)))
				return 0;

			return Event::CountByDepartment($this->intIdrole);
		}

		/**
		 * Associates a EventAsDepartment
		 * @param Event $objEvent
		 * @return void
		*/
		public function AssociateEventAsDepartment(Event $objEvent) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEventAsDepartment on this unsaved Role.');
			if ((is_null($objEvent->Idevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEventAsDepartment on this Role with an unsaved Event.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event`
				SET
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`idevent` = ' . $objDatabase->SqlVariable($objEvent->Idevent) . '
			');
		}

		/**
		 * Unassociates a EventAsDepartment
		 * @param Event $objEvent
		 * @return void
		*/
		public function UnassociateEventAsDepartment(Event $objEvent) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventAsDepartment on this unsaved Role.');
			if ((is_null($objEvent->Idevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventAsDepartment on this Role with an unsaved Event.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event`
				SET
					`department` = null
				WHERE
					`idevent` = ' . $objDatabase->SqlVariable($objEvent->Idevent) . ' AND
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all EventsAsDepartment
		 * @return void
		*/
		public function UnassociateAllEventsAsDepartment() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventAsDepartment on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event`
				SET
					`department` = null
				WHERE
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated EventAsDepartment
		 * @param Event $objEvent
		 * @return void
		*/
		public function DeleteAssociatedEventAsDepartment(Event $objEvent) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventAsDepartment on this unsaved Role.');
			if ((is_null($objEvent->Idevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventAsDepartment on this Role with an unsaved Event.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event`
				WHERE
					`idevent` = ' . $objDatabase->SqlVariable($objEvent->Idevent) . ' AND
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated EventsAsDepartment
		 * @return void
		*/
		public function DeleteAllEventsAsDepartment() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventAsDepartment on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event`
				WHERE
					`department` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for LoginHasRoleAsId
		//-------------------------------------------------------------------

		/**
		 * Gets all associated LoginHasRolesAsId as an array of LoginHasRole objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LoginHasRole[]
		*/
		public function GetLoginHasRoleAsIdArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return LoginHasRole::LoadArrayByRoleIdrole($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated LoginHasRolesAsId
		 * @return int
		*/
		public function CountLoginHasRolesAsId() {
			if ((is_null($this->intIdrole)))
				return 0;

			return LoginHasRole::CountByRoleIdrole($this->intIdrole);
		}

		/**
		 * Associates a LoginHasRoleAsId
		 * @param LoginHasRole $objLoginHasRole
		 * @return void
		*/
		public function AssociateLoginHasRoleAsId(LoginHasRole $objLoginHasRole) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLoginHasRoleAsId on this unsaved Role.');
			if ((is_null($objLoginHasRole->LoginIdlogin)) || (is_null($objLoginHasRole->RoleIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLoginHasRoleAsId on this Role with an unsaved LoginHasRole.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`login_has_role`
				SET
					`role_idrole` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`login_idlogin` = ' . $objDatabase->SqlVariable($objLoginHasRole->LoginIdlogin) . ' AND
					`role_idrole` = ' . $objDatabase->SqlVariable($objLoginHasRole->RoleIdrole) . '
			');
		}

		/**
		 * Unassociates a LoginHasRoleAsId
		 * @param LoginHasRole $objLoginHasRole
		 * @return void
		*/
		public function UnassociateLoginHasRoleAsId(LoginHasRole $objLoginHasRole) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this unsaved Role.');
			if ((is_null($objLoginHasRole->LoginIdlogin)) || (is_null($objLoginHasRole->RoleIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this Role with an unsaved LoginHasRole.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`login_has_role`
				SET
					`role_idrole` = null
				WHERE
					`login_idlogin` = ' . $objDatabase->SqlVariable($objLoginHasRole->LoginIdlogin) . ' AND
					`role_idrole` = ' . $objDatabase->SqlVariable($objLoginHasRole->RoleIdrole) . ' AND
					`role_idrole` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all LoginHasRolesAsId
		 * @return void
		*/
		public function UnassociateAllLoginHasRolesAsId() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`login_has_role`
				SET
					`role_idrole` = null
				WHERE
					`role_idrole` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated LoginHasRoleAsId
		 * @param LoginHasRole $objLoginHasRole
		 * @return void
		*/
		public function DeleteAssociatedLoginHasRoleAsId(LoginHasRole $objLoginHasRole) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this unsaved Role.');
			if ((is_null($objLoginHasRole->LoginIdlogin)) || (is_null($objLoginHasRole->RoleIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this Role with an unsaved LoginHasRole.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`login_has_role`
				WHERE
					`login_idlogin` = ' . $objDatabase->SqlVariable($objLoginHasRole->LoginIdlogin) . ' AND
					`role_idrole` = ' . $objDatabase->SqlVariable($objLoginHasRole->RoleIdrole) . ' AND
					`role_idrole` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated LoginHasRolesAsId
		 * @return void
		*/
		public function DeleteAllLoginHasRolesAsId() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`login_has_role`
				WHERE
					`role_idrole` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for Note
		//-------------------------------------------------------------------

		/**
		 * Gets all associated Notes as an array of Note objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Note[]
		*/
		public function GetNoteArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return Note::LoadArrayByRole($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated Notes
		 * @return int
		*/
		public function CountNotes() {
			if ((is_null($this->intIdrole)))
				return 0;

			return Note::CountByRole($this->intIdrole);
		}

		/**
		 * Associates a Note
		 * @param Note $objNote
		 * @return void
		*/
		public function AssociateNote(Note $objNote) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateNote on this unsaved Role.');
			if ((is_null($objNote->Idnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateNote on this Role with an unsaved Note.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`note`
				SET
					`role` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`idnote` = ' . $objDatabase->SqlVariable($objNote->Idnote) . '
			');
		}

		/**
		 * Unassociates a Note
		 * @param Note $objNote
		 * @return void
		*/
		public function UnassociateNote(Note $objNote) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNote on this unsaved Role.');
			if ((is_null($objNote->Idnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNote on this Role with an unsaved Note.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`note`
				SET
					`role` = null
				WHERE
					`idnote` = ' . $objDatabase->SqlVariable($objNote->Idnote) . ' AND
					`role` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all Notes
		 * @return void
		*/
		public function UnassociateAllNotes() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNote on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`note`
				SET
					`role` = null
				WHERE
					`role` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated Note
		 * @param Note $objNote
		 * @return void
		*/
		public function DeleteAssociatedNote(Note $objNote) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNote on this unsaved Role.');
			if ((is_null($objNote->Idnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNote on this Role with an unsaved Note.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`note`
				WHERE
					`idnote` = ' . $objDatabase->SqlVariable($objNote->Idnote) . ' AND
					`role` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated Notes
		 * @return void
		*/
		public function DeleteAllNotes() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNote on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`note`
				WHERE
					`role` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for PriceHistoryAsGodown
		//-------------------------------------------------------------------

		/**
		 * Gets all associated PriceHistoriesAsGodown as an array of PriceHistory objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return PriceHistory[]
		*/
		public function GetPriceHistoryAsGodownArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return PriceHistory::LoadArrayByGodown($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated PriceHistoriesAsGodown
		 * @return int
		*/
		public function CountPriceHistoriesAsGodown() {
			if ((is_null($this->intIdrole)))
				return 0;

			return PriceHistory::CountByGodown($this->intIdrole);
		}

		/**
		 * Associates a PriceHistoryAsGodown
		 * @param PriceHistory $objPriceHistory
		 * @return void
		*/
		public function AssociatePriceHistoryAsGodown(PriceHistory $objPriceHistory) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociatePriceHistoryAsGodown on this unsaved Role.');
			if ((is_null($objPriceHistory->IdpriceHistory)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociatePriceHistoryAsGodown on this Role with an unsaved PriceHistory.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`price_history`
				SET
					`godown` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`idprice_history` = ' . $objDatabase->SqlVariable($objPriceHistory->IdpriceHistory) . '
			');
		}

		/**
		 * Unassociates a PriceHistoryAsGodown
		 * @param PriceHistory $objPriceHistory
		 * @return void
		*/
		public function UnassociatePriceHistoryAsGodown(PriceHistory $objPriceHistory) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociatePriceHistoryAsGodown on this unsaved Role.');
			if ((is_null($objPriceHistory->IdpriceHistory)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociatePriceHistoryAsGodown on this Role with an unsaved PriceHistory.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`price_history`
				SET
					`godown` = null
				WHERE
					`idprice_history` = ' . $objDatabase->SqlVariable($objPriceHistory->IdpriceHistory) . ' AND
					`godown` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all PriceHistoriesAsGodown
		 * @return void
		*/
		public function UnassociateAllPriceHistoriesAsGodown() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociatePriceHistoryAsGodown on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`price_history`
				SET
					`godown` = null
				WHERE
					`godown` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated PriceHistoryAsGodown
		 * @param PriceHistory $objPriceHistory
		 * @return void
		*/
		public function DeleteAssociatedPriceHistoryAsGodown(PriceHistory $objPriceHistory) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociatePriceHistoryAsGodown on this unsaved Role.');
			if ((is_null($objPriceHistory->IdpriceHistory)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociatePriceHistoryAsGodown on this Role with an unsaved PriceHistory.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`price_history`
				WHERE
					`idprice_history` = ' . $objDatabase->SqlVariable($objPriceHistory->IdpriceHistory) . ' AND
					`godown` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated PriceHistoriesAsGodown
		 * @return void
		*/
		public function DeleteAllPriceHistoriesAsGodown() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociatePriceHistoryAsGodown on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`price_history`
				WHERE
					`godown` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for ProfileAsCourseOfAddmission
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ProfilesAsCourseOfAddmission as an array of Profile objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public function GetProfileAsCourseOfAddmissionArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return Profile::LoadArrayByCourseOfAddmission($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ProfilesAsCourseOfAddmission
		 * @return int
		*/
		public function CountProfilesAsCourseOfAddmission() {
			if ((is_null($this->intIdrole)))
				return 0;

			return Profile::CountByCourseOfAddmission($this->intIdrole);
		}

		/**
		 * Associates a ProfileAsCourseOfAddmission
		 * @param Profile $objProfile
		 * @return void
		*/
		public function AssociateProfileAsCourseOfAddmission(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateProfileAsCourseOfAddmission on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateProfileAsCourseOfAddmission on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`course_of_addmission` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . '
			');
		}

		/**
		 * Unassociates a ProfileAsCourseOfAddmission
		 * @param Profile $objProfile
		 * @return void
		*/
		public function UnassociateProfileAsCourseOfAddmission(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCourseOfAddmission on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCourseOfAddmission on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`course_of_addmission` = null
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . ' AND
					`course_of_addmission` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all ProfilesAsCourseOfAddmission
		 * @return void
		*/
		public function UnassociateAllProfilesAsCourseOfAddmission() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCourseOfAddmission on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`course_of_addmission` = null
				WHERE
					`course_of_addmission` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated ProfileAsCourseOfAddmission
		 * @param Profile $objProfile
		 * @return void
		*/
		public function DeleteAssociatedProfileAsCourseOfAddmission(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCourseOfAddmission on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCourseOfAddmission on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`profile`
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . ' AND
					`course_of_addmission` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated ProfilesAsCourseOfAddmission
		 * @return void
		*/
		public function DeleteAllProfilesAsCourseOfAddmission() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCourseOfAddmission on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`profile`
				WHERE
					`course_of_addmission` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for ProfileAsCurrentCourse
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ProfilesAsCurrentCourse as an array of Profile objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public function GetProfileAsCurrentCourseArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return Profile::LoadArrayByCurrentCourse($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ProfilesAsCurrentCourse
		 * @return int
		*/
		public function CountProfilesAsCurrentCourse() {
			if ((is_null($this->intIdrole)))
				return 0;

			return Profile::CountByCurrentCourse($this->intIdrole);
		}

		/**
		 * Associates a ProfileAsCurrentCourse
		 * @param Profile $objProfile
		 * @return void
		*/
		public function AssociateProfileAsCurrentCourse(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateProfileAsCurrentCourse on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateProfileAsCurrentCourse on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`current_course` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . '
			');
		}

		/**
		 * Unassociates a ProfileAsCurrentCourse
		 * @param Profile $objProfile
		 * @return void
		*/
		public function UnassociateProfileAsCurrentCourse(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentCourse on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentCourse on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`current_course` = null
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . ' AND
					`current_course` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all ProfilesAsCurrentCourse
		 * @return void
		*/
		public function UnassociateAllProfilesAsCurrentCourse() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentCourse on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`current_course` = null
				WHERE
					`current_course` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated ProfileAsCurrentCourse
		 * @param Profile $objProfile
		 * @return void
		*/
		public function DeleteAssociatedProfileAsCurrentCourse(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentCourse on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentCourse on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`profile`
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . ' AND
					`current_course` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated ProfilesAsCurrentCourse
		 * @return void
		*/
		public function DeleteAllProfilesAsCurrentCourse() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentCourse on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`profile`
				WHERE
					`current_course` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for ProfileAsBranchOfAddmission
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ProfilesAsBranchOfAddmission as an array of Profile objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public function GetProfileAsBranchOfAddmissionArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return Profile::LoadArrayByBranchOfAddmission($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ProfilesAsBranchOfAddmission
		 * @return int
		*/
		public function CountProfilesAsBranchOfAddmission() {
			if ((is_null($this->intIdrole)))
				return 0;

			return Profile::CountByBranchOfAddmission($this->intIdrole);
		}

		/**
		 * Associates a ProfileAsBranchOfAddmission
		 * @param Profile $objProfile
		 * @return void
		*/
		public function AssociateProfileAsBranchOfAddmission(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateProfileAsBranchOfAddmission on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateProfileAsBranchOfAddmission on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`branch_of_addmission` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . '
			');
		}

		/**
		 * Unassociates a ProfileAsBranchOfAddmission
		 * @param Profile $objProfile
		 * @return void
		*/
		public function UnassociateProfileAsBranchOfAddmission(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsBranchOfAddmission on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsBranchOfAddmission on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`branch_of_addmission` = null
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . ' AND
					`branch_of_addmission` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all ProfilesAsBranchOfAddmission
		 * @return void
		*/
		public function UnassociateAllProfilesAsBranchOfAddmission() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsBranchOfAddmission on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`branch_of_addmission` = null
				WHERE
					`branch_of_addmission` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated ProfileAsBranchOfAddmission
		 * @param Profile $objProfile
		 * @return void
		*/
		public function DeleteAssociatedProfileAsBranchOfAddmission(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsBranchOfAddmission on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsBranchOfAddmission on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`profile`
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . ' AND
					`branch_of_addmission` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated ProfilesAsBranchOfAddmission
		 * @return void
		*/
		public function DeleteAllProfilesAsBranchOfAddmission() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsBranchOfAddmission on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`profile`
				WHERE
					`branch_of_addmission` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for ProfileAsCurrentBranch
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ProfilesAsCurrentBranch as an array of Profile objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public function GetProfileAsCurrentBranchArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return Profile::LoadArrayByCurrentBranch($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ProfilesAsCurrentBranch
		 * @return int
		*/
		public function CountProfilesAsCurrentBranch() {
			if ((is_null($this->intIdrole)))
				return 0;

			return Profile::CountByCurrentBranch($this->intIdrole);
		}

		/**
		 * Associates a ProfileAsCurrentBranch
		 * @param Profile $objProfile
		 * @return void
		*/
		public function AssociateProfileAsCurrentBranch(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateProfileAsCurrentBranch on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateProfileAsCurrentBranch on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`current_branch` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . '
			');
		}

		/**
		 * Unassociates a ProfileAsCurrentBranch
		 * @param Profile $objProfile
		 * @return void
		*/
		public function UnassociateProfileAsCurrentBranch(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentBranch on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentBranch on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`current_branch` = null
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . ' AND
					`current_branch` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all ProfilesAsCurrentBranch
		 * @return void
		*/
		public function UnassociateAllProfilesAsCurrentBranch() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentBranch on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`current_branch` = null
				WHERE
					`current_branch` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated ProfileAsCurrentBranch
		 * @param Profile $objProfile
		 * @return void
		*/
		public function DeleteAssociatedProfileAsCurrentBranch(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentBranch on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentBranch on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`profile`
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . ' AND
					`current_branch` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated ProfilesAsCurrentBranch
		 * @return void
		*/
		public function DeleteAllProfilesAsCurrentBranch() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentBranch on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`profile`
				WHERE
					`current_branch` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for ProfileAsAdmissionDiv
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ProfilesAsAdmissionDiv as an array of Profile objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public function GetProfileAsAdmissionDivArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return Profile::LoadArrayByAdmissionDiv($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ProfilesAsAdmissionDiv
		 * @return int
		*/
		public function CountProfilesAsAdmissionDiv() {
			if ((is_null($this->intIdrole)))
				return 0;

			return Profile::CountByAdmissionDiv($this->intIdrole);
		}

		/**
		 * Associates a ProfileAsAdmissionDiv
		 * @param Profile $objProfile
		 * @return void
		*/
		public function AssociateProfileAsAdmissionDiv(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateProfileAsAdmissionDiv on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateProfileAsAdmissionDiv on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`admission_div` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . '
			');
		}

		/**
		 * Unassociates a ProfileAsAdmissionDiv
		 * @param Profile $objProfile
		 * @return void
		*/
		public function UnassociateProfileAsAdmissionDiv(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsAdmissionDiv on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsAdmissionDiv on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`admission_div` = null
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . ' AND
					`admission_div` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all ProfilesAsAdmissionDiv
		 * @return void
		*/
		public function UnassociateAllProfilesAsAdmissionDiv() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsAdmissionDiv on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`admission_div` = null
				WHERE
					`admission_div` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated ProfileAsAdmissionDiv
		 * @param Profile $objProfile
		 * @return void
		*/
		public function DeleteAssociatedProfileAsAdmissionDiv(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsAdmissionDiv on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsAdmissionDiv on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`profile`
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . ' AND
					`admission_div` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated ProfilesAsAdmissionDiv
		 * @return void
		*/
		public function DeleteAllProfilesAsAdmissionDiv() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsAdmissionDiv on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`profile`
				WHERE
					`admission_div` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for ProfileAsCurrentDiv
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ProfilesAsCurrentDiv as an array of Profile objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public function GetProfileAsCurrentDivArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return Profile::LoadArrayByCurrentDiv($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ProfilesAsCurrentDiv
		 * @return int
		*/
		public function CountProfilesAsCurrentDiv() {
			if ((is_null($this->intIdrole)))
				return 0;

			return Profile::CountByCurrentDiv($this->intIdrole);
		}

		/**
		 * Associates a ProfileAsCurrentDiv
		 * @param Profile $objProfile
		 * @return void
		*/
		public function AssociateProfileAsCurrentDiv(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateProfileAsCurrentDiv on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateProfileAsCurrentDiv on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`current_div` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . '
			');
		}

		/**
		 * Unassociates a ProfileAsCurrentDiv
		 * @param Profile $objProfile
		 * @return void
		*/
		public function UnassociateProfileAsCurrentDiv(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentDiv on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentDiv on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`current_div` = null
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . ' AND
					`current_div` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all ProfilesAsCurrentDiv
		 * @return void
		*/
		public function UnassociateAllProfilesAsCurrentDiv() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentDiv on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`profile`
				SET
					`current_div` = null
				WHERE
					`current_div` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated ProfileAsCurrentDiv
		 * @param Profile $objProfile
		 * @return void
		*/
		public function DeleteAssociatedProfileAsCurrentDiv(Profile $objProfile) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentDiv on this unsaved Role.');
			if ((is_null($objProfile->Idprofile)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentDiv on this Role with an unsaved Profile.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`profile`
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($objProfile->Idprofile) . ' AND
					`current_div` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated ProfilesAsCurrentDiv
		 * @return void
		*/
		public function DeleteAllProfilesAsCurrentDiv() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateProfileAsCurrentDiv on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`profile`
				WHERE
					`current_div` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for RoleAsParrent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated RolesAsParrent as an array of Role objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Role[]
		*/
		public function GetRoleAsParrentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return Role::LoadArrayByParrent($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated RolesAsParrent
		 * @return int
		*/
		public function CountRolesAsParrent() {
			if ((is_null($this->intIdrole)))
				return 0;

			return Role::CountByParrent($this->intIdrole);
		}

		/**
		 * Associates a RoleAsParrent
		 * @param Role $objRole
		 * @return void
		*/
		public function AssociateRoleAsParrent(Role $objRole) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateRoleAsParrent on this unsaved Role.');
			if ((is_null($objRole->Idrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateRoleAsParrent on this Role with an unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`role`
				SET
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`idrole` = ' . $objDatabase->SqlVariable($objRole->Idrole) . '
			');
		}

		/**
		 * Unassociates a RoleAsParrent
		 * @param Role $objRole
		 * @return void
		*/
		public function UnassociateRoleAsParrent(Role $objRole) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRoleAsParrent on this unsaved Role.');
			if ((is_null($objRole->Idrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRoleAsParrent on this Role with an unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`role`
				SET
					`parrent` = null
				WHERE
					`idrole` = ' . $objDatabase->SqlVariable($objRole->Idrole) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all RolesAsParrent
		 * @return void
		*/
		public function UnassociateAllRolesAsParrent() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRoleAsParrent on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`role`
				SET
					`parrent` = null
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated RoleAsParrent
		 * @param Role $objRole
		 * @return void
		*/
		public function DeleteAssociatedRoleAsParrent(Role $objRole) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRoleAsParrent on this unsaved Role.');
			if ((is_null($objRole->Idrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRoleAsParrent on this Role with an unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`role`
				WHERE
					`idrole` = ' . $objDatabase->SqlVariable($objRole->Idrole) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated RolesAsParrent
		 * @return void
		*/
		public function DeleteAllRolesAsParrent() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRoleAsParrent on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`role`
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		// Related Objects' Methods for RoleHasMenuAsId
		//-------------------------------------------------------------------

		/**
		 * Gets all associated RoleHasMenusAsId as an array of RoleHasMenu objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return RoleHasMenu[]
		*/
		public function GetRoleHasMenuAsIdArray($objOptionalClauses = null) {
			if ((is_null($this->intIdrole)))
				return array();

			try {
				return RoleHasMenu::LoadArrayByRoleIdrole($this->intIdrole, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated RoleHasMenusAsId
		 * @return int
		*/
		public function CountRoleHasMenusAsId() {
			if ((is_null($this->intIdrole)))
				return 0;

			return RoleHasMenu::CountByRoleIdrole($this->intIdrole);
		}

		/**
		 * Associates a RoleHasMenuAsId
		 * @param RoleHasMenu $objRoleHasMenu
		 * @return void
		*/
		public function AssociateRoleHasMenuAsId(RoleHasMenu $objRoleHasMenu) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateRoleHasMenuAsId on this unsaved Role.');
			if ((is_null($objRoleHasMenu->RoleIdrole)) || (is_null($objRoleHasMenu->MenuIdmenu)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateRoleHasMenuAsId on this Role with an unsaved RoleHasMenu.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`role_has_menu`
				SET
					`role_idrole` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
				WHERE
					`role_idrole` = ' . $objDatabase->SqlVariable($objRoleHasMenu->RoleIdrole) . ' AND
					`menu_idmenu` = ' . $objDatabase->SqlVariable($objRoleHasMenu->MenuIdmenu) . '
			');
		}

		/**
		 * Unassociates a RoleHasMenuAsId
		 * @param RoleHasMenu $objRoleHasMenu
		 * @return void
		*/
		public function UnassociateRoleHasMenuAsId(RoleHasMenu $objRoleHasMenu) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRoleHasMenuAsId on this unsaved Role.');
			if ((is_null($objRoleHasMenu->RoleIdrole)) || (is_null($objRoleHasMenu->MenuIdmenu)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRoleHasMenuAsId on this Role with an unsaved RoleHasMenu.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`role_has_menu`
				SET
					`role_idrole` = null
				WHERE
					`role_idrole` = ' . $objDatabase->SqlVariable($objRoleHasMenu->RoleIdrole) . ' AND
					`menu_idmenu` = ' . $objDatabase->SqlVariable($objRoleHasMenu->MenuIdmenu) . ' AND
					`role_idrole` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Unassociates all RoleHasMenusAsId
		 * @return void
		*/
		public function UnassociateAllRoleHasMenusAsId() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRoleHasMenuAsId on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`role_has_menu`
				SET
					`role_idrole` = null
				WHERE
					`role_idrole` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes an associated RoleHasMenuAsId
		 * @param RoleHasMenu $objRoleHasMenu
		 * @return void
		*/
		public function DeleteAssociatedRoleHasMenuAsId(RoleHasMenu $objRoleHasMenu) {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRoleHasMenuAsId on this unsaved Role.');
			if ((is_null($objRoleHasMenu->RoleIdrole)) || (is_null($objRoleHasMenu->MenuIdmenu)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRoleHasMenuAsId on this Role with an unsaved RoleHasMenu.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`role_has_menu`
				WHERE
					`role_idrole` = ' . $objDatabase->SqlVariable($objRoleHasMenu->RoleIdrole) . ' AND
					`menu_idmenu` = ' . $objDatabase->SqlVariable($objRoleHasMenu->MenuIdmenu) . ' AND
					`role_idrole` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}

		/**
		 * Deletes all associated RoleHasMenusAsId
		 * @return void
		*/
		public function DeleteAllRoleHasMenusAsId() {
			if ((is_null($this->intIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRoleHasMenuAsId on this unsaved Role.');

			// Get the Database Object for this Class
			$objDatabase = Role::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`role_has_menu`
				WHERE
					`role_idrole` = ' . $objDatabase->SqlVariable($this->intIdrole) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "role";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Role::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Role"><sequence>';
			$strToReturn .= '<element name="Idrole" type="xsd:int"/>';
			$strToReturn .= '<element name="Name" type="xsd:string"/>';
			$strToReturn .= '<element name="Description" type="xsd:string"/>';
			$strToReturn .= '<element name="ParrentObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="Mname" type="xsd:string"/>';
			$strToReturn .= '<element name="GrpObject" type="xsd1:Group"/>';
			$strToReturn .= '<element name="ShortName" type="xsd:string"/>';
			$strToReturn .= '<element name="Abbrivation" type="xsd:string"/>';
			$strToReturn .= '<element name="ServiceYears" type="xsd:int"/>';
			$strToReturn .= '<element name="Code" type="xsd:int"/>';
			$strToReturn .= '<element name="Count" type="xsd:string"/>';
			$strToReturn .= '<element name="Intake" type="xsd:int"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Role', $strComplexTypeArray)) {
				$strComplexTypeArray['Role'] = Role::GetSoapComplexTypeXml();
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				Group::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Role::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Role();
			if (property_exists($objSoapObject, 'Idrole'))
				$objToReturn->intIdrole = $objSoapObject->Idrole;
			if (property_exists($objSoapObject, 'Name'))
				$objToReturn->strName = $objSoapObject->Name;
			if (property_exists($objSoapObject, 'Description'))
				$objToReturn->strDescription = $objSoapObject->Description;
			if ((property_exists($objSoapObject, 'ParrentObject')) &&
				($objSoapObject->ParrentObject))
				$objToReturn->ParrentObject = Role::GetObjectFromSoapObject($objSoapObject->ParrentObject);
			if (property_exists($objSoapObject, 'Mname'))
				$objToReturn->strMname = $objSoapObject->Mname;
			if ((property_exists($objSoapObject, 'GrpObject')) &&
				($objSoapObject->GrpObject))
				$objToReturn->GrpObject = Group::GetObjectFromSoapObject($objSoapObject->GrpObject);
			if (property_exists($objSoapObject, 'ShortName'))
				$objToReturn->strShortName = $objSoapObject->ShortName;
			if (property_exists($objSoapObject, 'Abbrivation'))
				$objToReturn->strAbbrivation = $objSoapObject->Abbrivation;
			if (property_exists($objSoapObject, 'ServiceYears'))
				$objToReturn->intServiceYears = $objSoapObject->ServiceYears;
			if (property_exists($objSoapObject, 'Code'))
				$objToReturn->intCode = $objSoapObject->Code;
			if (property_exists($objSoapObject, 'Count'))
				$objToReturn->strCount = $objSoapObject->Count;
			if (property_exists($objSoapObject, 'Intake'))
				$objToReturn->intIntake = $objSoapObject->Intake;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Role::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objParrentObject)
				$objObject->objParrentObject = Role::GetSoapObjectFromObject($objObject->objParrentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intParrent = null;
			if ($objObject->objGrpObject)
				$objObject->objGrpObject = Group::GetSoapObjectFromObject($objObject->objGrpObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intGrp = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idrole'] = $this->intIdrole;
			$iArray['Name'] = $this->strName;
			$iArray['Description'] = $this->strDescription;
			$iArray['Parrent'] = $this->intParrent;
			$iArray['Mname'] = $this->strMname;
			$iArray['Grp'] = $this->intGrp;
			$iArray['ShortName'] = $this->strShortName;
			$iArray['Abbrivation'] = $this->strAbbrivation;
			$iArray['ServiceYears'] = $this->intServiceYears;
			$iArray['Code'] = $this->intCode;
			$iArray['Count'] = $this->strCount;
			$iArray['Intake'] = $this->intIntake;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdrole ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idrole
     * @property-read QQNode $Name
     * @property-read QQNode $Description
     * @property-read QQNode $Parrent
     * @property-read QQNodeRole $ParrentObject
     * @property-read QQNode $Mname
     * @property-read QQNode $Grp
     * @property-read QQNodeGroup $GrpObject
     * @property-read QQNode $ShortName
     * @property-read QQNode $Abbrivation
     * @property-read QQNode $ServiceYears
     * @property-read QQNode $Code
     * @property-read QQNode $Count
     * @property-read QQNode $Intake
     *
     *
     * @property-read QQReverseReferenceNodeAcademicTemplet $AcademicTempletAsDepartment
     * @property-read QQReverseReferenceNodeAddress $AddressAsRoll
     * @property-read QQReverseReferenceNodeAppApproval $AppApprovalAsRoll
     * @property-read QQReverseReferenceNodeApplication $ApplicationAsProgram
     * @property-read QQReverseReferenceNodeApprovel $ApprovelAsRoll
     * @property-read QQReverseReferenceNodeDeptYear $DeptYearAsDepartment
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEventsAsDepartment
     * @property-read QQReverseReferenceNodeEvent $EventAsDepartment
     * @property-read QQReverseReferenceNodeLoginHasRole $LoginHasRoleAsId
     * @property-read QQReverseReferenceNodeNote $Note
     * @property-read QQReverseReferenceNodePriceHistory $PriceHistoryAsGodown
     * @property-read QQReverseReferenceNodeProfile $ProfileAsCourseOfAddmission
     * @property-read QQReverseReferenceNodeProfile $ProfileAsCurrentCourse
     * @property-read QQReverseReferenceNodeProfile $ProfileAsBranchOfAddmission
     * @property-read QQReverseReferenceNodeProfile $ProfileAsCurrentBranch
     * @property-read QQReverseReferenceNodeProfile $ProfileAsAdmissionDiv
     * @property-read QQReverseReferenceNodeProfile $ProfileAsCurrentDiv
     * @property-read QQReverseReferenceNodeRole $RoleAsParrent
     * @property-read QQReverseReferenceNodeRoleHasMenu $RoleHasMenuAsId

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeRole extends QQNode {
		protected $strTableName = 'role';
		protected $strPrimaryKey = 'idrole';
		protected $strClassName = 'Role';
		public function __get($strName) {
			switch ($strName) {
				case 'Idrole':
					return new QQNode('idrole', 'Idrole', 'Integer', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'VarChar', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'Blob', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'Integer', $this);
				case 'ParrentObject':
					return new QQNodeRole('parrent', 'ParrentObject', 'Integer', $this);
				case 'Mname':
					return new QQNode('mname', 'Mname', 'VarChar', $this);
				case 'Grp':
					return new QQNode('grp', 'Grp', 'Integer', $this);
				case 'GrpObject':
					return new QQNodeGroup('grp', 'GrpObject', 'Integer', $this);
				case 'ShortName':
					return new QQNode('short_name', 'ShortName', 'VarChar', $this);
				case 'Abbrivation':
					return new QQNode('abbrivation', 'Abbrivation', 'VarChar', $this);
				case 'ServiceYears':
					return new QQNode('service_years', 'ServiceYears', 'Integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'Integer', $this);
				case 'Count':
					return new QQNode('count', 'Count', 'VarChar', $this);
				case 'Intake':
					return new QQNode('intake', 'Intake', 'Integer', $this);
				case 'AcademicTempletAsDepartment':
					return new QQReverseReferenceNodeAcademicTemplet($this, 'academictempletasdepartment', 'reverse_reference', 'department');
				case 'AddressAsRoll':
					return new QQReverseReferenceNodeAddress($this, 'addressasroll', 'reverse_reference', 'roll');
				case 'AppApprovalAsRoll':
					return new QQReverseReferenceNodeAppApproval($this, 'appapprovalasroll', 'reverse_reference', 'roll');
				case 'ApplicationAsProgram':
					return new QQReverseReferenceNodeApplication($this, 'applicationasprogram', 'reverse_reference', 'program');
				case 'ApprovelAsRoll':
					return new QQReverseReferenceNodeApprovel($this, 'approvelasroll', 'reverse_reference', 'roll');
				case 'DeptYearAsDepartment':
					return new QQReverseReferenceNodeDeptYear($this, 'deptyearasdepartment', 'reverse_reference', 'department');
				case 'DeptYearEventsAsDepartment':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyeareventsasdepartment', 'reverse_reference', 'department');
				case 'EventAsDepartment':
					return new QQReverseReferenceNodeEvent($this, 'eventasdepartment', 'reverse_reference', 'department');
				case 'LoginHasRoleAsId':
					return new QQReverseReferenceNodeLoginHasRole($this, 'loginhasroleasid', 'reverse_reference', 'role_idrole');
				case 'Note':
					return new QQReverseReferenceNodeNote($this, 'note', 'reverse_reference', 'role');
				case 'PriceHistoryAsGodown':
					return new QQReverseReferenceNodePriceHistory($this, 'pricehistoryasgodown', 'reverse_reference', 'godown');
				case 'ProfileAsCourseOfAddmission':
					return new QQReverseReferenceNodeProfile($this, 'profileascourseofaddmission', 'reverse_reference', 'course_of_addmission');
				case 'ProfileAsCurrentCourse':
					return new QQReverseReferenceNodeProfile($this, 'profileascurrentcourse', 'reverse_reference', 'current_course');
				case 'ProfileAsBranchOfAddmission':
					return new QQReverseReferenceNodeProfile($this, 'profileasbranchofaddmission', 'reverse_reference', 'branch_of_addmission');
				case 'ProfileAsCurrentBranch':
					return new QQReverseReferenceNodeProfile($this, 'profileascurrentbranch', 'reverse_reference', 'current_branch');
				case 'ProfileAsAdmissionDiv':
					return new QQReverseReferenceNodeProfile($this, 'profileasadmissiondiv', 'reverse_reference', 'admission_div');
				case 'ProfileAsCurrentDiv':
					return new QQReverseReferenceNodeProfile($this, 'profileascurrentdiv', 'reverse_reference', 'current_div');
				case 'RoleAsParrent':
					return new QQReverseReferenceNodeRole($this, 'roleasparrent', 'reverse_reference', 'parrent');
				case 'RoleHasMenuAsId':
					return new QQReverseReferenceNodeRoleHasMenu($this, 'rolehasmenuasid', 'reverse_reference', 'role_idrole');

				case '_PrimaryKeyNode':
					return new QQNode('idrole', 'Idrole', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idrole
     * @property-read QQNode $Name
     * @property-read QQNode $Description
     * @property-read QQNode $Parrent
     * @property-read QQNodeRole $ParrentObject
     * @property-read QQNode $Mname
     * @property-read QQNode $Grp
     * @property-read QQNodeGroup $GrpObject
     * @property-read QQNode $ShortName
     * @property-read QQNode $Abbrivation
     * @property-read QQNode $ServiceYears
     * @property-read QQNode $Code
     * @property-read QQNode $Count
     * @property-read QQNode $Intake
     *
     *
     * @property-read QQReverseReferenceNodeAcademicTemplet $AcademicTempletAsDepartment
     * @property-read QQReverseReferenceNodeAddress $AddressAsRoll
     * @property-read QQReverseReferenceNodeAppApproval $AppApprovalAsRoll
     * @property-read QQReverseReferenceNodeApplication $ApplicationAsProgram
     * @property-read QQReverseReferenceNodeApprovel $ApprovelAsRoll
     * @property-read QQReverseReferenceNodeDeptYear $DeptYearAsDepartment
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEventsAsDepartment
     * @property-read QQReverseReferenceNodeEvent $EventAsDepartment
     * @property-read QQReverseReferenceNodeLoginHasRole $LoginHasRoleAsId
     * @property-read QQReverseReferenceNodeNote $Note
     * @property-read QQReverseReferenceNodePriceHistory $PriceHistoryAsGodown
     * @property-read QQReverseReferenceNodeProfile $ProfileAsCourseOfAddmission
     * @property-read QQReverseReferenceNodeProfile $ProfileAsCurrentCourse
     * @property-read QQReverseReferenceNodeProfile $ProfileAsBranchOfAddmission
     * @property-read QQReverseReferenceNodeProfile $ProfileAsCurrentBranch
     * @property-read QQReverseReferenceNodeProfile $ProfileAsAdmissionDiv
     * @property-read QQReverseReferenceNodeProfile $ProfileAsCurrentDiv
     * @property-read QQReverseReferenceNodeRole $RoleAsParrent
     * @property-read QQReverseReferenceNodeRoleHasMenu $RoleHasMenuAsId

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeRole extends QQReverseReferenceNode {
		protected $strTableName = 'role';
		protected $strPrimaryKey = 'idrole';
		protected $strClassName = 'Role';
		public function __get($strName) {
			switch ($strName) {
				case 'Idrole':
					return new QQNode('idrole', 'Idrole', 'integer', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'string', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'string', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'integer', $this);
				case 'ParrentObject':
					return new QQNodeRole('parrent', 'ParrentObject', 'integer', $this);
				case 'Mname':
					return new QQNode('mname', 'Mname', 'string', $this);
				case 'Grp':
					return new QQNode('grp', 'Grp', 'integer', $this);
				case 'GrpObject':
					return new QQNodeGroup('grp', 'GrpObject', 'integer', $this);
				case 'ShortName':
					return new QQNode('short_name', 'ShortName', 'string', $this);
				case 'Abbrivation':
					return new QQNode('abbrivation', 'Abbrivation', 'string', $this);
				case 'ServiceYears':
					return new QQNode('service_years', 'ServiceYears', 'integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'integer', $this);
				case 'Count':
					return new QQNode('count', 'Count', 'string', $this);
				case 'Intake':
					return new QQNode('intake', 'Intake', 'integer', $this);
				case 'AcademicTempletAsDepartment':
					return new QQReverseReferenceNodeAcademicTemplet($this, 'academictempletasdepartment', 'reverse_reference', 'department');
				case 'AddressAsRoll':
					return new QQReverseReferenceNodeAddress($this, 'addressasroll', 'reverse_reference', 'roll');
				case 'AppApprovalAsRoll':
					return new QQReverseReferenceNodeAppApproval($this, 'appapprovalasroll', 'reverse_reference', 'roll');
				case 'ApplicationAsProgram':
					return new QQReverseReferenceNodeApplication($this, 'applicationasprogram', 'reverse_reference', 'program');
				case 'ApprovelAsRoll':
					return new QQReverseReferenceNodeApprovel($this, 'approvelasroll', 'reverse_reference', 'roll');
				case 'DeptYearAsDepartment':
					return new QQReverseReferenceNodeDeptYear($this, 'deptyearasdepartment', 'reverse_reference', 'department');
				case 'DeptYearEventsAsDepartment':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyeareventsasdepartment', 'reverse_reference', 'department');
				case 'EventAsDepartment':
					return new QQReverseReferenceNodeEvent($this, 'eventasdepartment', 'reverse_reference', 'department');
				case 'LoginHasRoleAsId':
					return new QQReverseReferenceNodeLoginHasRole($this, 'loginhasroleasid', 'reverse_reference', 'role_idrole');
				case 'Note':
					return new QQReverseReferenceNodeNote($this, 'note', 'reverse_reference', 'role');
				case 'PriceHistoryAsGodown':
					return new QQReverseReferenceNodePriceHistory($this, 'pricehistoryasgodown', 'reverse_reference', 'godown');
				case 'ProfileAsCourseOfAddmission':
					return new QQReverseReferenceNodeProfile($this, 'profileascourseofaddmission', 'reverse_reference', 'course_of_addmission');
				case 'ProfileAsCurrentCourse':
					return new QQReverseReferenceNodeProfile($this, 'profileascurrentcourse', 'reverse_reference', 'current_course');
				case 'ProfileAsBranchOfAddmission':
					return new QQReverseReferenceNodeProfile($this, 'profileasbranchofaddmission', 'reverse_reference', 'branch_of_addmission');
				case 'ProfileAsCurrentBranch':
					return new QQReverseReferenceNodeProfile($this, 'profileascurrentbranch', 'reverse_reference', 'current_branch');
				case 'ProfileAsAdmissionDiv':
					return new QQReverseReferenceNodeProfile($this, 'profileasadmissiondiv', 'reverse_reference', 'admission_div');
				case 'ProfileAsCurrentDiv':
					return new QQReverseReferenceNodeProfile($this, 'profileascurrentdiv', 'reverse_reference', 'current_div');
				case 'RoleAsParrent':
					return new QQReverseReferenceNodeRole($this, 'roleasparrent', 'reverse_reference', 'parrent');
				case 'RoleHasMenuAsId':
					return new QQReverseReferenceNodeRoleHasMenu($this, 'rolehasmenuasid', 'reverse_reference', 'role_idrole');

				case '_PrimaryKeyNode':
					return new QQNode('idrole', 'Idrole', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
