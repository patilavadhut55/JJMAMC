<?php
	/**
	 * The abstract EstablishmentGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Establishment subclass which
	 * extends this EstablishmentGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Establishment class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idestablishment the value for intIdestablishment (Read-Only PK)
	 * @property integer $Post the value for intPost 
	 * @property string $PostInfo the value for strPostInfo 
	 * @property QDateTime $AppointmentDate the value for dttAppointmentDate (Not Null)
	 * @property string $AppointmentName the value for strAppointmentName 
	 * @property string $AppointmentDetails the value for strAppointmentDetails 
	 * @property string $BasicSalary the value for strBasicSalary (Not Null)
	 * @property QDateTime $DateOfTermination the value for dttDateOfTermination 
	 * @property string $Reason the value for strReason 
	 * @property string $TeminationDetails the value for strTeminationDetails 
	 * @property integer $Employee the value for intEmployee (Not Null)
	 * @property integer $AppointmentCategory the value for intAppointmentCategory 
	 * @property integer $SalaryTemplet the value for intSalaryTemplet 
	 * @property integer $Vacancy the value for intVacancy 
	 * @property string $VacancyDetails the value for strVacancyDetails 
	 * @property integer $Role the value for intRole 
	 * @property boolean $Active the value for blnActive 
	 * @property string $AdditonalPay the value for strAdditonalPay 
	 * @property string $PayDeatils the value for strPayDeatils 
	 * @property Role $PostObject the value for the Role object referenced by intPost 
	 * @property Address $EmployeeObject the value for the Address object referenced by intEmployee (Not Null)
	 * @property AppointmentCategory $AppointmentCategoryObject the value for the AppointmentCategory object referenced by intAppointmentCategory 
	 * @property SalaryTemplet $SalaryTempletObject the value for the SalaryTemplet object referenced by intSalaryTemplet 
	 * @property Vacancy $VacancyObject the value for the Vacancy object referenced by intVacancy 
	 * @property LoginHasRole $RoleObject the value for the LoginHasRole object referenced by intRole 
	 * @property-read Leaves $_LeavesAsRef the value for the private _objLeavesAsRef (Read-Only) if set due to an expansion on the leaves.ref_establishment reverse relationship
	 * @property-read Leaves[] $_LeavesAsRefArray the value for the private _objLeavesAsRefArray (Read-Only) if set due to an ExpandAsArray on the leaves.ref_establishment reverse relationship
	 * @property-read Reward $_RewardAsRefEstablishement the value for the private _objRewardAsRefEstablishement (Read-Only) if set due to an expansion on the reward.ref_establishement reverse relationship
	 * @property-read Reward[] $_RewardAsRefEstablishementArray the value for the private _objRewardAsRefEstablishementArray (Read-Only) if set due to an ExpandAsArray on the reward.ref_establishement reverse relationship
	 * @property-read SalaryTemplet $_SalaryTemplet the value for the private _objSalaryTemplet (Read-Only) if set due to an expansion on the salary_templet.establishment reverse relationship
	 * @property-read SalaryTemplet[] $_SalaryTempletArray the value for the private _objSalaryTempletArray (Read-Only) if set due to an ExpandAsArray on the salary_templet.establishment reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class EstablishmentGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column establishment.idestablishment
		 * @var integer intIdestablishment
		 */
		protected $intIdestablishment;
		const IdestablishmentDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.post
		 * @var integer intPost
		 */
		protected $intPost;
		const PostDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.post_info
		 * @var string strPostInfo
		 */
		protected $strPostInfo;
		const PostInfoDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.appointment_date
		 * @var QDateTime dttAppointmentDate
		 */
		protected $dttAppointmentDate;
		const AppointmentDateDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.appointment_name
		 * @var string strAppointmentName
		 */
		protected $strAppointmentName;
		const AppointmentNameMaxLength = 45;
		const AppointmentNameDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.appointment_details
		 * @var string strAppointmentDetails
		 */
		protected $strAppointmentDetails;
		const AppointmentDetailsDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.basic_salary
		 * @var string strBasicSalary
		 */
		protected $strBasicSalary;
		const BasicSalaryDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.date_of_termination
		 * @var QDateTime dttDateOfTermination
		 */
		protected $dttDateOfTermination;
		const DateOfTerminationDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.reason
		 * @var string strReason
		 */
		protected $strReason;
		const ReasonMaxLength = 255;
		const ReasonDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.temination_details
		 * @var string strTeminationDetails
		 */
		protected $strTeminationDetails;
		const TeminationDetailsDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.employee
		 * @var integer intEmployee
		 */
		protected $intEmployee;
		const EmployeeDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.appointment_category
		 * @var integer intAppointmentCategory
		 */
		protected $intAppointmentCategory;
		const AppointmentCategoryDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.salary_templet
		 * @var integer intSalaryTemplet
		 */
		protected $intSalaryTemplet;
		const SalaryTempletDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.vacancy
		 * @var integer intVacancy
		 */
		protected $intVacancy;
		const VacancyDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.vacancy_details
		 * @var string strVacancyDetails
		 */
		protected $strVacancyDetails;
		const VacancyDetailsDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.role
		 * @var integer intRole
		 */
		protected $intRole;
		const RoleDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.active
		 * @var boolean blnActive
		 */
		protected $blnActive;
		const ActiveDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.additonal_pay
		 * @var string strAdditonalPay
		 */
		protected $strAdditonalPay;
		const AdditonalPayDefault = null;


		/**
		 * Protected member variable that maps to the database column establishment.pay_deatils
		 * @var string strPayDeatils
		 */
		protected $strPayDeatils;
		const PayDeatilsDefault = null;


		/**
		 * Private member variable that stores a reference to a single LeavesAsRef object
		 * (of type Leaves), if this Establishment object was restored with
		 * an expansion on the leaves association table.
		 * @var Leaves _objLeavesAsRef;
		 */
		private $_objLeavesAsRef;

		/**
		 * Private member variable that stores a reference to an array of LeavesAsRef objects
		 * (of type Leaves[]), if this Establishment object was restored with
		 * an ExpandAsArray on the leaves association table.
		 * @var Leaves[] _objLeavesAsRefArray;
		 */
		private $_objLeavesAsRefArray = null;

		/**
		 * Private member variable that stores a reference to a single RewardAsRefEstablishement object
		 * (of type Reward), if this Establishment object was restored with
		 * an expansion on the reward association table.
		 * @var Reward _objRewardAsRefEstablishement;
		 */
		private $_objRewardAsRefEstablishement;

		/**
		 * Private member variable that stores a reference to an array of RewardAsRefEstablishement objects
		 * (of type Reward[]), if this Establishment object was restored with
		 * an ExpandAsArray on the reward association table.
		 * @var Reward[] _objRewardAsRefEstablishementArray;
		 */
		private $_objRewardAsRefEstablishementArray = null;

		/**
		 * Private member variable that stores a reference to a single SalaryTemplet object
		 * (of type SalaryTemplet), if this Establishment object was restored with
		 * an expansion on the salary_templet association table.
		 * @var SalaryTemplet _objSalaryTemplet;
		 */
		private $_objSalaryTemplet;

		/**
		 * Private member variable that stores a reference to an array of SalaryTemplet objects
		 * (of type SalaryTemplet[]), if this Establishment object was restored with
		 * an ExpandAsArray on the salary_templet association table.
		 * @var SalaryTemplet[] _objSalaryTempletArray;
		 */
		private $_objSalaryTempletArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column establishment.post.
		 *
		 * NOTE: Always use the PostObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objPostObject
		 */
		protected $objPostObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column establishment.employee.
		 *
		 * NOTE: Always use the EmployeeObject property getter to correctly retrieve this Address object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Address objEmployeeObject
		 */
		protected $objEmployeeObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column establishment.appointment_category.
		 *
		 * NOTE: Always use the AppointmentCategoryObject property getter to correctly retrieve this AppointmentCategory object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var AppointmentCategory objAppointmentCategoryObject
		 */
		protected $objAppointmentCategoryObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column establishment.salary_templet.
		 *
		 * NOTE: Always use the SalaryTempletObject property getter to correctly retrieve this SalaryTemplet object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var SalaryTemplet objSalaryTempletObject
		 */
		protected $objSalaryTempletObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column establishment.vacancy.
		 *
		 * NOTE: Always use the VacancyObject property getter to correctly retrieve this Vacancy object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Vacancy objVacancyObject
		 */
		protected $objVacancyObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column establishment.role.
		 *
		 * NOTE: Always use the RoleObject property getter to correctly retrieve this LoginHasRole object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var LoginHasRole objRoleObject
		 */
		protected $objRoleObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdestablishment = Establishment::IdestablishmentDefault;
			$this->intPost = Establishment::PostDefault;
			$this->strPostInfo = Establishment::PostInfoDefault;
			$this->dttAppointmentDate = (Establishment::AppointmentDateDefault === null)?null:new QDateTime(Establishment::AppointmentDateDefault);
			$this->strAppointmentName = Establishment::AppointmentNameDefault;
			$this->strAppointmentDetails = Establishment::AppointmentDetailsDefault;
			$this->strBasicSalary = Establishment::BasicSalaryDefault;
			$this->dttDateOfTermination = (Establishment::DateOfTerminationDefault === null)?null:new QDateTime(Establishment::DateOfTerminationDefault);
			$this->strReason = Establishment::ReasonDefault;
			$this->strTeminationDetails = Establishment::TeminationDetailsDefault;
			$this->intEmployee = Establishment::EmployeeDefault;
			$this->intAppointmentCategory = Establishment::AppointmentCategoryDefault;
			$this->intSalaryTemplet = Establishment::SalaryTempletDefault;
			$this->intVacancy = Establishment::VacancyDefault;
			$this->strVacancyDetails = Establishment::VacancyDetailsDefault;
			$this->intRole = Establishment::RoleDefault;
			$this->blnActive = Establishment::ActiveDefault;
			$this->strAdditonalPay = Establishment::AdditonalPayDefault;
			$this->strPayDeatils = Establishment::PayDeatilsDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Establishment from PK Info
		 * @param integer $intIdestablishment
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Establishment
		 */
		public static function Load($intIdestablishment, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Establishment', $intIdestablishment);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Establishment::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Establishment()->Idestablishment, $intIdestablishment)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Establishments
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Establishment[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Establishment::QueryArray to perform the LoadAll query
			try {
				return Establishment::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Establishments
		 * @return int
		 */
		public static function CountAll() {
			// Call Establishment::QueryCount to perform the CountAll query
			return Establishment::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Create/Build out the QueryBuilder object with Establishment-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'establishment');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Establishment::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('establishment');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Establishment object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Establishment the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Establishment::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Establishment object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Establishment::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Establishment::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Establishment objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Establishment[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Establishment::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Establishment::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Establishment::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Establishment objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Establishment::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			$strQuery = Establishment::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/establishment', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Establishment::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Establishment
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'establishment';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idestablishment', $strAliasPrefix . 'idestablishment');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idestablishment', $strAliasPrefix . 'idestablishment');
			    $objBuilder->AddSelectItem($strTableName, 'post', $strAliasPrefix . 'post');
			    $objBuilder->AddSelectItem($strTableName, 'post_info', $strAliasPrefix . 'post_info');
			    $objBuilder->AddSelectItem($strTableName, 'appointment_date', $strAliasPrefix . 'appointment_date');
			    $objBuilder->AddSelectItem($strTableName, 'appointment_name', $strAliasPrefix . 'appointment_name');
			    $objBuilder->AddSelectItem($strTableName, 'appointment_details', $strAliasPrefix . 'appointment_details');
			    $objBuilder->AddSelectItem($strTableName, 'basic_salary', $strAliasPrefix . 'basic_salary');
			    $objBuilder->AddSelectItem($strTableName, 'date_of_termination', $strAliasPrefix . 'date_of_termination');
			    $objBuilder->AddSelectItem($strTableName, 'reason', $strAliasPrefix . 'reason');
			    $objBuilder->AddSelectItem($strTableName, 'temination_details', $strAliasPrefix . 'temination_details');
			    $objBuilder->AddSelectItem($strTableName, 'employee', $strAliasPrefix . 'employee');
			    $objBuilder->AddSelectItem($strTableName, 'appointment_category', $strAliasPrefix . 'appointment_category');
			    $objBuilder->AddSelectItem($strTableName, 'salary_templet', $strAliasPrefix . 'salary_templet');
			    $objBuilder->AddSelectItem($strTableName, 'vacancy', $strAliasPrefix . 'vacancy');
			    $objBuilder->AddSelectItem($strTableName, 'vacancy_details', $strAliasPrefix . 'vacancy_details');
			    $objBuilder->AddSelectItem($strTableName, 'role', $strAliasPrefix . 'role');
			    $objBuilder->AddSelectItem($strTableName, 'active', $strAliasPrefix . 'active');
			    $objBuilder->AddSelectItem($strTableName, 'additonal_pay', $strAliasPrefix . 'additonal_pay');
			    $objBuilder->AddSelectItem($strTableName, 'pay_deatils', $strAliasPrefix . 'pay_deatils');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Establishment from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Establishment::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Establishment
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idestablishment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdestablishment == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'establishment__';


						// Expanding reverse references: LeavesAsRef
						$strAlias = $strAliasPrefix . 'leavesasref__idleaves';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objLeavesAsRefArray)
								$objPreviousItem->_objLeavesAsRefArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objLeavesAsRefArray)) {
								$objPreviousChildItems = $objPreviousItem->_objLeavesAsRefArray;
								$objChildItem = Leaves::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavesasref__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objLeavesAsRefArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objLeavesAsRefArray[] = Leaves::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavesasref__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: RewardAsRefEstablishement
						$strAlias = $strAliasPrefix . 'rewardasrefestablishement__idreward';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objRewardAsRefEstablishementArray)
								$objPreviousItem->_objRewardAsRefEstablishementArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objRewardAsRefEstablishementArray)) {
								$objPreviousChildItems = $objPreviousItem->_objRewardAsRefEstablishementArray;
								$objChildItem = Reward::InstantiateDbRow($objDbRow, $strAliasPrefix . 'rewardasrefestablishement__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objRewardAsRefEstablishementArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objRewardAsRefEstablishementArray[] = Reward::InstantiateDbRow($objDbRow, $strAliasPrefix . 'rewardasrefestablishement__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: SalaryTemplet
						$strAlias = $strAliasPrefix . 'salarytemplet__idsalary_templet';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objSalaryTempletArray)
								$objPreviousItem->_objSalaryTempletArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objSalaryTempletArray)) {
								$objPreviousChildItems = $objPreviousItem->_objSalaryTempletArray;
								$objChildItem = SalaryTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarytemplet__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objSalaryTempletArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objSalaryTempletArray[] = SalaryTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarytemplet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'establishment__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Establishment object
			$objToReturn = new Establishment();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idestablishment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdestablishment = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'post';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intPost = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'post_info';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strPostInfo = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'appointment_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttAppointmentDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'appointment_name';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strAppointmentName = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'appointment_details';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strAppointmentDetails = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'basic_salary';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strBasicSalary = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'date_of_termination';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDateOfTermination = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'reason';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strReason = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'temination_details';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTeminationDetails = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'employee';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intEmployee = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'appointment_category';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intAppointmentCategory = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'salary_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSalaryTemplet = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'vacancy';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intVacancy = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'vacancy_details';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strVacancyDetails = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'role';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intRole = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'active';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnActive = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'additonal_pay';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strAdditonalPay = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'pay_deatils';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strPayDeatils = $objDbRow->GetColumn($strAliasName, 'Blob');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idestablishment != $objPreviousItem->Idestablishment) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objLeavesAsRefArray);
					$cnt = count($objToReturn->_objLeavesAsRefArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objLeavesAsRefArray, $objToReturn->_objLeavesAsRefArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objRewardAsRefEstablishementArray);
					$cnt = count($objToReturn->_objRewardAsRefEstablishementArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objRewardAsRefEstablishementArray, $objToReturn->_objRewardAsRefEstablishementArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objSalaryTempletArray);
					$cnt = count($objToReturn->_objSalaryTempletArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objSalaryTempletArray, $objToReturn->_objSalaryTempletArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'establishment__';

			// Check for PostObject Early Binding
			$strAlias = $strAliasPrefix . 'post__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objPostObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'post__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for EmployeeObject Early Binding
			$strAlias = $strAliasPrefix . 'employee__idaddress';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objEmployeeObject = Address::InstantiateDbRow($objDbRow, $strAliasPrefix . 'employee__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for AppointmentCategoryObject Early Binding
			$strAlias = $strAliasPrefix . 'appointment_category__idappointment_category';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objAppointmentCategoryObject = AppointmentCategory::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appointment_category__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for SalaryTempletObject Early Binding
			$strAlias = $strAliasPrefix . 'salary_templet__idsalary_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSalaryTempletObject = SalaryTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salary_templet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for VacancyObject Early Binding
			$strAlias = $strAliasPrefix . 'vacancy__idvacancy';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objVacancyObject = Vacancy::InstantiateDbRow($objDbRow, $strAliasPrefix . 'vacancy__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for RoleObject Early Binding
			$strAlias = $strAliasPrefix . 'role__id';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objRoleObject = LoginHasRole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'role__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for LeavesAsRef Virtual Binding
			$strAlias = $strAliasPrefix . 'leavesasref__idleaves';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objLeavesAsRefArray)
				$objToReturn->_objLeavesAsRefArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objLeavesAsRefArray[] = Leaves::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavesasref__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objLeavesAsRef = Leaves::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavesasref__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for RewardAsRefEstablishement Virtual Binding
			$strAlias = $strAliasPrefix . 'rewardasrefestablishement__idreward';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objRewardAsRefEstablishementArray)
				$objToReturn->_objRewardAsRefEstablishementArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objRewardAsRefEstablishementArray[] = Reward::InstantiateDbRow($objDbRow, $strAliasPrefix . 'rewardasrefestablishement__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objRewardAsRefEstablishement = Reward::InstantiateDbRow($objDbRow, $strAliasPrefix . 'rewardasrefestablishement__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for SalaryTemplet Virtual Binding
			$strAlias = $strAliasPrefix . 'salarytemplet__idsalary_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objSalaryTempletArray)
				$objToReturn->_objSalaryTempletArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objSalaryTempletArray[] = SalaryTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarytemplet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objSalaryTemplet = SalaryTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarytemplet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Establishments from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Establishment[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Establishment::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Establishment::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Establishment object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Establishment next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Establishment::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Establishment object,
		 * by Idestablishment Index(es)
		 * @param integer $intIdestablishment
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Establishment
		*/
		public static function LoadByIdestablishment($intIdestablishment, $objOptionalClauses = null) {
			return Establishment::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Establishment()->Idestablishment, $intIdestablishment)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Establishment objects,
		 * by Employee Index(es)
		 * @param integer $intEmployee
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Establishment[]
		*/
		public static function LoadArrayByEmployee($intEmployee, $objOptionalClauses = null) {
			// Call Establishment::QueryArray to perform the LoadArrayByEmployee query
			try {
				return Establishment::QueryArray(
					QQ::Equal(QQN::Establishment()->Employee, $intEmployee),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Establishments
		 * by Employee Index(es)
		 * @param integer $intEmployee
		 * @return int
		*/
		public static function CountByEmployee($intEmployee) {
			// Call Establishment::QueryCount to perform the CountByEmployee query
			return Establishment::QueryCount(
				QQ::Equal(QQN::Establishment()->Employee, $intEmployee)
			);
		}

		/**
		 * Load an array of Establishment objects,
		 * by AppointmentCategory Index(es)
		 * @param integer $intAppointmentCategory
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Establishment[]
		*/
		public static function LoadArrayByAppointmentCategory($intAppointmentCategory, $objOptionalClauses = null) {
			// Call Establishment::QueryArray to perform the LoadArrayByAppointmentCategory query
			try {
				return Establishment::QueryArray(
					QQ::Equal(QQN::Establishment()->AppointmentCategory, $intAppointmentCategory),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Establishments
		 * by AppointmentCategory Index(es)
		 * @param integer $intAppointmentCategory
		 * @return int
		*/
		public static function CountByAppointmentCategory($intAppointmentCategory) {
			// Call Establishment::QueryCount to perform the CountByAppointmentCategory query
			return Establishment::QueryCount(
				QQ::Equal(QQN::Establishment()->AppointmentCategory, $intAppointmentCategory)
			);
		}

		/**
		 * Load an array of Establishment objects,
		 * by SalaryTemplet Index(es)
		 * @param integer $intSalaryTemplet
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Establishment[]
		*/
		public static function LoadArrayBySalaryTemplet($intSalaryTemplet, $objOptionalClauses = null) {
			// Call Establishment::QueryArray to perform the LoadArrayBySalaryTemplet query
			try {
				return Establishment::QueryArray(
					QQ::Equal(QQN::Establishment()->SalaryTemplet, $intSalaryTemplet),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Establishments
		 * by SalaryTemplet Index(es)
		 * @param integer $intSalaryTemplet
		 * @return int
		*/
		public static function CountBySalaryTemplet($intSalaryTemplet) {
			// Call Establishment::QueryCount to perform the CountBySalaryTemplet query
			return Establishment::QueryCount(
				QQ::Equal(QQN::Establishment()->SalaryTemplet, $intSalaryTemplet)
			);
		}

		/**
		 * Load an array of Establishment objects,
		 * by Vacancy Index(es)
		 * @param integer $intVacancy
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Establishment[]
		*/
		public static function LoadArrayByVacancy($intVacancy, $objOptionalClauses = null) {
			// Call Establishment::QueryArray to perform the LoadArrayByVacancy query
			try {
				return Establishment::QueryArray(
					QQ::Equal(QQN::Establishment()->Vacancy, $intVacancy),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Establishments
		 * by Vacancy Index(es)
		 * @param integer $intVacancy
		 * @return int
		*/
		public static function CountByVacancy($intVacancy) {
			// Call Establishment::QueryCount to perform the CountByVacancy query
			return Establishment::QueryCount(
				QQ::Equal(QQN::Establishment()->Vacancy, $intVacancy)
			);
		}

		/**
		 * Load an array of Establishment objects,
		 * by Post Index(es)
		 * @param integer $intPost
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Establishment[]
		*/
		public static function LoadArrayByPost($intPost, $objOptionalClauses = null) {
			// Call Establishment::QueryArray to perform the LoadArrayByPost query
			try {
				return Establishment::QueryArray(
					QQ::Equal(QQN::Establishment()->Post, $intPost),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Establishments
		 * by Post Index(es)
		 * @param integer $intPost
		 * @return int
		*/
		public static function CountByPost($intPost) {
			// Call Establishment::QueryCount to perform the CountByPost query
			return Establishment::QueryCount(
				QQ::Equal(QQN::Establishment()->Post, $intPost)
			);
		}

		/**
		 * Load an array of Establishment objects,
		 * by Role Index(es)
		 * @param integer $intRole
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Establishment[]
		*/
		public static function LoadArrayByRole($intRole, $objOptionalClauses = null) {
			// Call Establishment::QueryArray to perform the LoadArrayByRole query
			try {
				return Establishment::QueryArray(
					QQ::Equal(QQN::Establishment()->Role, $intRole),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Establishments
		 * by Role Index(es)
		 * @param integer $intRole
		 * @return int
		*/
		public static function CountByRole($intRole) {
			// Call Establishment::QueryCount to perform the CountByRole query
			return Establishment::QueryCount(
				QQ::Equal(QQN::Establishment()->Role, $intRole)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Establishment
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `establishment` (
							`post`,
							`post_info`,
							`appointment_date`,
							`appointment_name`,
							`appointment_details`,
							`basic_salary`,
							`date_of_termination`,
							`reason`,
							`temination_details`,
							`employee`,
							`appointment_category`,
							`salary_templet`,
							`vacancy`,
							`vacancy_details`,
							`role`,
							`active`,
							`additonal_pay`,
							`pay_deatils`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intPost) . ',
							' . $objDatabase->SqlVariable($this->strPostInfo) . ',
							' . $objDatabase->SqlVariable($this->dttAppointmentDate) . ',
							' . $objDatabase->SqlVariable($this->strAppointmentName) . ',
							' . $objDatabase->SqlVariable($this->strAppointmentDetails) . ',
							' . $objDatabase->SqlVariable($this->strBasicSalary) . ',
							' . $objDatabase->SqlVariable($this->dttDateOfTermination) . ',
							' . $objDatabase->SqlVariable($this->strReason) . ',
							' . $objDatabase->SqlVariable($this->strTeminationDetails) . ',
							' . $objDatabase->SqlVariable($this->intEmployee) . ',
							' . $objDatabase->SqlVariable($this->intAppointmentCategory) . ',
							' . $objDatabase->SqlVariable($this->intSalaryTemplet) . ',
							' . $objDatabase->SqlVariable($this->intVacancy) . ',
							' . $objDatabase->SqlVariable($this->strVacancyDetails) . ',
							' . $objDatabase->SqlVariable($this->intRole) . ',
							' . $objDatabase->SqlVariable($this->blnActive) . ',
							' . $objDatabase->SqlVariable($this->strAdditonalPay) . ',
							' . $objDatabase->SqlVariable($this->strPayDeatils) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdestablishment = $objDatabase->InsertId('establishment', 'idestablishment');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`establishment`
						SET
							`post` = ' . $objDatabase->SqlVariable($this->intPost) . ',
							`post_info` = ' . $objDatabase->SqlVariable($this->strPostInfo) . ',
							`appointment_date` = ' . $objDatabase->SqlVariable($this->dttAppointmentDate) . ',
							`appointment_name` = ' . $objDatabase->SqlVariable($this->strAppointmentName) . ',
							`appointment_details` = ' . $objDatabase->SqlVariable($this->strAppointmentDetails) . ',
							`basic_salary` = ' . $objDatabase->SqlVariable($this->strBasicSalary) . ',
							`date_of_termination` = ' . $objDatabase->SqlVariable($this->dttDateOfTermination) . ',
							`reason` = ' . $objDatabase->SqlVariable($this->strReason) . ',
							`temination_details` = ' . $objDatabase->SqlVariable($this->strTeminationDetails) . ',
							`employee` = ' . $objDatabase->SqlVariable($this->intEmployee) . ',
							`appointment_category` = ' . $objDatabase->SqlVariable($this->intAppointmentCategory) . ',
							`salary_templet` = ' . $objDatabase->SqlVariable($this->intSalaryTemplet) . ',
							`vacancy` = ' . $objDatabase->SqlVariable($this->intVacancy) . ',
							`vacancy_details` = ' . $objDatabase->SqlVariable($this->strVacancyDetails) . ',
							`role` = ' . $objDatabase->SqlVariable($this->intRole) . ',
							`active` = ' . $objDatabase->SqlVariable($this->blnActive) . ',
							`additonal_pay` = ' . $objDatabase->SqlVariable($this->strAdditonalPay) . ',
							`pay_deatils` = ' . $objDatabase->SqlVariable($this->strPayDeatils) . '
						WHERE
							`idestablishment` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Establishment
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Establishment with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`establishment`
				WHERE
					`idestablishment` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Establishment ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Establishment', $this->intIdestablishment);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Establishments
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`establishment`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate establishment table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `establishment`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Establishment from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Establishment object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Establishment::Load($this->intIdestablishment);

			// Update $this's local variables to match
			$this->Post = $objReloaded->Post;
			$this->strPostInfo = $objReloaded->strPostInfo;
			$this->dttAppointmentDate = $objReloaded->dttAppointmentDate;
			$this->strAppointmentName = $objReloaded->strAppointmentName;
			$this->strAppointmentDetails = $objReloaded->strAppointmentDetails;
			$this->strBasicSalary = $objReloaded->strBasicSalary;
			$this->dttDateOfTermination = $objReloaded->dttDateOfTermination;
			$this->strReason = $objReloaded->strReason;
			$this->strTeminationDetails = $objReloaded->strTeminationDetails;
			$this->Employee = $objReloaded->Employee;
			$this->AppointmentCategory = $objReloaded->AppointmentCategory;
			$this->SalaryTemplet = $objReloaded->SalaryTemplet;
			$this->Vacancy = $objReloaded->Vacancy;
			$this->strVacancyDetails = $objReloaded->strVacancyDetails;
			$this->Role = $objReloaded->Role;
			$this->blnActive = $objReloaded->blnActive;
			$this->strAdditonalPay = $objReloaded->strAdditonalPay;
			$this->strPayDeatils = $objReloaded->strPayDeatils;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idestablishment':
					/**
					 * Gets the value for intIdestablishment (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdestablishment;

				case 'Post':
					/**
					 * Gets the value for intPost 
					 * @return integer
					 */
					return $this->intPost;

				case 'PostInfo':
					/**
					 * Gets the value for strPostInfo 
					 * @return string
					 */
					return $this->strPostInfo;

				case 'AppointmentDate':
					/**
					 * Gets the value for dttAppointmentDate (Not Null)
					 * @return QDateTime
					 */
					return $this->dttAppointmentDate;

				case 'AppointmentName':
					/**
					 * Gets the value for strAppointmentName 
					 * @return string
					 */
					return $this->strAppointmentName;

				case 'AppointmentDetails':
					/**
					 * Gets the value for strAppointmentDetails 
					 * @return string
					 */
					return $this->strAppointmentDetails;

				case 'BasicSalary':
					/**
					 * Gets the value for strBasicSalary (Not Null)
					 * @return string
					 */
					return $this->strBasicSalary;

				case 'DateOfTermination':
					/**
					 * Gets the value for dttDateOfTermination 
					 * @return QDateTime
					 */
					return $this->dttDateOfTermination;

				case 'Reason':
					/**
					 * Gets the value for strReason 
					 * @return string
					 */
					return $this->strReason;

				case 'TeminationDetails':
					/**
					 * Gets the value for strTeminationDetails 
					 * @return string
					 */
					return $this->strTeminationDetails;

				case 'Employee':
					/**
					 * Gets the value for intEmployee (Not Null)
					 * @return integer
					 */
					return $this->intEmployee;

				case 'AppointmentCategory':
					/**
					 * Gets the value for intAppointmentCategory 
					 * @return integer
					 */
					return $this->intAppointmentCategory;

				case 'SalaryTemplet':
					/**
					 * Gets the value for intSalaryTemplet 
					 * @return integer
					 */
					return $this->intSalaryTemplet;

				case 'Vacancy':
					/**
					 * Gets the value for intVacancy 
					 * @return integer
					 */
					return $this->intVacancy;

				case 'VacancyDetails':
					/**
					 * Gets the value for strVacancyDetails 
					 * @return string
					 */
					return $this->strVacancyDetails;

				case 'Role':
					/**
					 * Gets the value for intRole 
					 * @return integer
					 */
					return $this->intRole;

				case 'Active':
					/**
					 * Gets the value for blnActive 
					 * @return boolean
					 */
					return $this->blnActive;

				case 'AdditonalPay':
					/**
					 * Gets the value for strAdditonalPay 
					 * @return string
					 */
					return $this->strAdditonalPay;

				case 'PayDeatils':
					/**
					 * Gets the value for strPayDeatils 
					 * @return string
					 */
					return $this->strPayDeatils;


				///////////////////
				// Member Objects
				///////////////////
				case 'PostObject':
					/**
					 * Gets the value for the Role object referenced by intPost 
					 * @return Role
					 */
					try {
						if ((!$this->objPostObject) && (!is_null($this->intPost)))
							$this->objPostObject = Role::Load($this->intPost);
						return $this->objPostObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'EmployeeObject':
					/**
					 * Gets the value for the Address object referenced by intEmployee (Not Null)
					 * @return Address
					 */
					try {
						if ((!$this->objEmployeeObject) && (!is_null($this->intEmployee)))
							$this->objEmployeeObject = Address::Load($this->intEmployee);
						return $this->objEmployeeObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AppointmentCategoryObject':
					/**
					 * Gets the value for the AppointmentCategory object referenced by intAppointmentCategory 
					 * @return AppointmentCategory
					 */
					try {
						if ((!$this->objAppointmentCategoryObject) && (!is_null($this->intAppointmentCategory)))
							$this->objAppointmentCategoryObject = AppointmentCategory::Load($this->intAppointmentCategory);
						return $this->objAppointmentCategoryObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SalaryTempletObject':
					/**
					 * Gets the value for the SalaryTemplet object referenced by intSalaryTemplet 
					 * @return SalaryTemplet
					 */
					try {
						if ((!$this->objSalaryTempletObject) && (!is_null($this->intSalaryTemplet)))
							$this->objSalaryTempletObject = SalaryTemplet::Load($this->intSalaryTemplet);
						return $this->objSalaryTempletObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'VacancyObject':
					/**
					 * Gets the value for the Vacancy object referenced by intVacancy 
					 * @return Vacancy
					 */
					try {
						if ((!$this->objVacancyObject) && (!is_null($this->intVacancy)))
							$this->objVacancyObject = Vacancy::Load($this->intVacancy);
						return $this->objVacancyObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RoleObject':
					/**
					 * Gets the value for the LoginHasRole object referenced by intRole 
					 * @return LoginHasRole
					 */
					try {
						if ((!$this->objRoleObject) && (!is_null($this->intRole)))
							$this->objRoleObject = LoginHasRole::Load($this->intRole);
						return $this->objRoleObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_LeavesAsRef':
					/**
					 * Gets the value for the private _objLeavesAsRef (Read-Only)
					 * if set due to an expansion on the leaves.ref_establishment reverse relationship
					 * @return Leaves
					 */
					return $this->_objLeavesAsRef;

				case '_LeavesAsRefArray':
					/**
					 * Gets the value for the private _objLeavesAsRefArray (Read-Only)
					 * if set due to an ExpandAsArray on the leaves.ref_establishment reverse relationship
					 * @return Leaves[]
					 */
					return $this->_objLeavesAsRefArray;

				case '_RewardAsRefEstablishement':
					/**
					 * Gets the value for the private _objRewardAsRefEstablishement (Read-Only)
					 * if set due to an expansion on the reward.ref_establishement reverse relationship
					 * @return Reward
					 */
					return $this->_objRewardAsRefEstablishement;

				case '_RewardAsRefEstablishementArray':
					/**
					 * Gets the value for the private _objRewardAsRefEstablishementArray (Read-Only)
					 * if set due to an ExpandAsArray on the reward.ref_establishement reverse relationship
					 * @return Reward[]
					 */
					return $this->_objRewardAsRefEstablishementArray;

				case '_SalaryTemplet':
					/**
					 * Gets the value for the private _objSalaryTemplet (Read-Only)
					 * if set due to an expansion on the salary_templet.establishment reverse relationship
					 * @return SalaryTemplet
					 */
					return $this->_objSalaryTemplet;

				case '_SalaryTempletArray':
					/**
					 * Gets the value for the private _objSalaryTempletArray (Read-Only)
					 * if set due to an ExpandAsArray on the salary_templet.establishment reverse relationship
					 * @return SalaryTemplet[]
					 */
					return $this->_objSalaryTempletArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Post':
					/**
					 * Sets the value for intPost 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objPostObject = null;
						return ($this->intPost = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'PostInfo':
					/**
					 * Sets the value for strPostInfo 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strPostInfo = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AppointmentDate':
					/**
					 * Sets the value for dttAppointmentDate (Not Null)
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttAppointmentDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AppointmentName':
					/**
					 * Sets the value for strAppointmentName 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strAppointmentName = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AppointmentDetails':
					/**
					 * Sets the value for strAppointmentDetails 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strAppointmentDetails = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'BasicSalary':
					/**
					 * Sets the value for strBasicSalary (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strBasicSalary = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DateOfTermination':
					/**
					 * Sets the value for dttDateOfTermination 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDateOfTermination = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Reason':
					/**
					 * Sets the value for strReason 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strReason = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TeminationDetails':
					/**
					 * Sets the value for strTeminationDetails 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTeminationDetails = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Employee':
					/**
					 * Sets the value for intEmployee (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objEmployeeObject = null;
						return ($this->intEmployee = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AppointmentCategory':
					/**
					 * Sets the value for intAppointmentCategory 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objAppointmentCategoryObject = null;
						return ($this->intAppointmentCategory = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SalaryTemplet':
					/**
					 * Sets the value for intSalaryTemplet 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSalaryTempletObject = null;
						return ($this->intSalaryTemplet = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Vacancy':
					/**
					 * Sets the value for intVacancy 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objVacancyObject = null;
						return ($this->intVacancy = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'VacancyDetails':
					/**
					 * Sets the value for strVacancyDetails 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strVacancyDetails = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Role':
					/**
					 * Sets the value for intRole 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objRoleObject = null;
						return ($this->intRole = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Active':
					/**
					 * Sets the value for blnActive 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnActive = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AdditonalPay':
					/**
					 * Sets the value for strAdditonalPay 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strAdditonalPay = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'PayDeatils':
					/**
					 * Sets the value for strPayDeatils 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strPayDeatils = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'PostObject':
					/**
					 * Sets the value for the Role object referenced by intPost 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intPost = null;
						$this->objPostObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved PostObject for this Establishment');

						// Update Local Member Variables
						$this->objPostObject = $mixValue;
						$this->intPost = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'EmployeeObject':
					/**
					 * Sets the value for the Address object referenced by intEmployee (Not Null)
					 * @param Address $mixValue
					 * @return Address
					 */
					if (is_null($mixValue)) {
						$this->intEmployee = null;
						$this->objEmployeeObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Address object
						try {
							$mixValue = QType::Cast($mixValue, 'Address');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Address object
						if (is_null($mixValue->Idaddress))
							throw new QCallerException('Unable to set an unsaved EmployeeObject for this Establishment');

						// Update Local Member Variables
						$this->objEmployeeObject = $mixValue;
						$this->intEmployee = $mixValue->Idaddress;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'AppointmentCategoryObject':
					/**
					 * Sets the value for the AppointmentCategory object referenced by intAppointmentCategory 
					 * @param AppointmentCategory $mixValue
					 * @return AppointmentCategory
					 */
					if (is_null($mixValue)) {
						$this->intAppointmentCategory = null;
						$this->objAppointmentCategoryObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a AppointmentCategory object
						try {
							$mixValue = QType::Cast($mixValue, 'AppointmentCategory');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED AppointmentCategory object
						if (is_null($mixValue->IdappointmentCategory))
							throw new QCallerException('Unable to set an unsaved AppointmentCategoryObject for this Establishment');

						// Update Local Member Variables
						$this->objAppointmentCategoryObject = $mixValue;
						$this->intAppointmentCategory = $mixValue->IdappointmentCategory;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'SalaryTempletObject':
					/**
					 * Sets the value for the SalaryTemplet object referenced by intSalaryTemplet 
					 * @param SalaryTemplet $mixValue
					 * @return SalaryTemplet
					 */
					if (is_null($mixValue)) {
						$this->intSalaryTemplet = null;
						$this->objSalaryTempletObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a SalaryTemplet object
						try {
							$mixValue = QType::Cast($mixValue, 'SalaryTemplet');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED SalaryTemplet object
						if (is_null($mixValue->IdsalaryTemplet))
							throw new QCallerException('Unable to set an unsaved SalaryTempletObject for this Establishment');

						// Update Local Member Variables
						$this->objSalaryTempletObject = $mixValue;
						$this->intSalaryTemplet = $mixValue->IdsalaryTemplet;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'VacancyObject':
					/**
					 * Sets the value for the Vacancy object referenced by intVacancy 
					 * @param Vacancy $mixValue
					 * @return Vacancy
					 */
					if (is_null($mixValue)) {
						$this->intVacancy = null;
						$this->objVacancyObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Vacancy object
						try {
							$mixValue = QType::Cast($mixValue, 'Vacancy');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Vacancy object
						if (is_null($mixValue->Idvacancy))
							throw new QCallerException('Unable to set an unsaved VacancyObject for this Establishment');

						// Update Local Member Variables
						$this->objVacancyObject = $mixValue;
						$this->intVacancy = $mixValue->Idvacancy;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'RoleObject':
					/**
					 * Sets the value for the LoginHasRole object referenced by intRole 
					 * @param LoginHasRole $mixValue
					 * @return LoginHasRole
					 */
					if (is_null($mixValue)) {
						$this->intRole = null;
						$this->objRoleObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a LoginHasRole object
						try {
							$mixValue = QType::Cast($mixValue, 'LoginHasRole');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED LoginHasRole object
						if (is_null($mixValue->Id))
							throw new QCallerException('Unable to set an unsaved RoleObject for this Establishment');

						// Update Local Member Variables
						$this->objRoleObject = $mixValue;
						$this->intRole = $mixValue->Id;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for LeavesAsRef
		//-------------------------------------------------------------------

		/**
		 * Gets all associated LeavesesAsRef as an array of Leaves objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Leaves[]
		*/
		public function GetLeavesAsRefArray($objOptionalClauses = null) {
			if ((is_null($this->intIdestablishment)))
				return array();

			try {
				return Leaves::LoadArrayByRefEstablishment($this->intIdestablishment, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated LeavesesAsRef
		 * @return int
		*/
		public function CountLeavesesAsRef() {
			if ((is_null($this->intIdestablishment)))
				return 0;

			return Leaves::CountByRefEstablishment($this->intIdestablishment);
		}

		/**
		 * Associates a LeavesAsRef
		 * @param Leaves $objLeaves
		 * @return void
		*/
		public function AssociateLeavesAsRef(Leaves $objLeaves) {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLeavesAsRef on this unsaved Establishment.');
			if ((is_null($objLeaves->Idleaves)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLeavesAsRef on this Establishment with an unsaved Leaves.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`leaves`
				SET
					`ref_establishment` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
				WHERE
					`idleaves` = ' . $objDatabase->SqlVariable($objLeaves->Idleaves) . '
			');
		}

		/**
		 * Unassociates a LeavesAsRef
		 * @param Leaves $objLeaves
		 * @return void
		*/
		public function UnassociateLeavesAsRef(Leaves $objLeaves) {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeavesAsRef on this unsaved Establishment.');
			if ((is_null($objLeaves->Idleaves)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeavesAsRef on this Establishment with an unsaved Leaves.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`leaves`
				SET
					`ref_establishment` = null
				WHERE
					`idleaves` = ' . $objDatabase->SqlVariable($objLeaves->Idleaves) . ' AND
					`ref_establishment` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
			');
		}

		/**
		 * Unassociates all LeavesesAsRef
		 * @return void
		*/
		public function UnassociateAllLeavesesAsRef() {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeavesAsRef on this unsaved Establishment.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`leaves`
				SET
					`ref_establishment` = null
				WHERE
					`ref_establishment` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
			');
		}

		/**
		 * Deletes an associated LeavesAsRef
		 * @param Leaves $objLeaves
		 * @return void
		*/
		public function DeleteAssociatedLeavesAsRef(Leaves $objLeaves) {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeavesAsRef on this unsaved Establishment.');
			if ((is_null($objLeaves->Idleaves)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeavesAsRef on this Establishment with an unsaved Leaves.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leaves`
				WHERE
					`idleaves` = ' . $objDatabase->SqlVariable($objLeaves->Idleaves) . ' AND
					`ref_establishment` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
			');
		}

		/**
		 * Deletes all associated LeavesesAsRef
		 * @return void
		*/
		public function DeleteAllLeavesesAsRef() {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeavesAsRef on this unsaved Establishment.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leaves`
				WHERE
					`ref_establishment` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
			');
		}


		// Related Objects' Methods for RewardAsRefEstablishement
		//-------------------------------------------------------------------

		/**
		 * Gets all associated RewardsAsRefEstablishement as an array of Reward objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Reward[]
		*/
		public function GetRewardAsRefEstablishementArray($objOptionalClauses = null) {
			if ((is_null($this->intIdestablishment)))
				return array();

			try {
				return Reward::LoadArrayByRefEstablishement($this->intIdestablishment, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated RewardsAsRefEstablishement
		 * @return int
		*/
		public function CountRewardsAsRefEstablishement() {
			if ((is_null($this->intIdestablishment)))
				return 0;

			return Reward::CountByRefEstablishement($this->intIdestablishment);
		}

		/**
		 * Associates a RewardAsRefEstablishement
		 * @param Reward $objReward
		 * @return void
		*/
		public function AssociateRewardAsRefEstablishement(Reward $objReward) {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateRewardAsRefEstablishement on this unsaved Establishment.');
			if ((is_null($objReward->Idreward)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateRewardAsRefEstablishement on this Establishment with an unsaved Reward.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`reward`
				SET
					`ref_establishement` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
				WHERE
					`idreward` = ' . $objDatabase->SqlVariable($objReward->Idreward) . '
			');
		}

		/**
		 * Unassociates a RewardAsRefEstablishement
		 * @param Reward $objReward
		 * @return void
		*/
		public function UnassociateRewardAsRefEstablishement(Reward $objReward) {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRewardAsRefEstablishement on this unsaved Establishment.');
			if ((is_null($objReward->Idreward)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRewardAsRefEstablishement on this Establishment with an unsaved Reward.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`reward`
				SET
					`ref_establishement` = null
				WHERE
					`idreward` = ' . $objDatabase->SqlVariable($objReward->Idreward) . ' AND
					`ref_establishement` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
			');
		}

		/**
		 * Unassociates all RewardsAsRefEstablishement
		 * @return void
		*/
		public function UnassociateAllRewardsAsRefEstablishement() {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRewardAsRefEstablishement on this unsaved Establishment.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`reward`
				SET
					`ref_establishement` = null
				WHERE
					`ref_establishement` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
			');
		}

		/**
		 * Deletes an associated RewardAsRefEstablishement
		 * @param Reward $objReward
		 * @return void
		*/
		public function DeleteAssociatedRewardAsRefEstablishement(Reward $objReward) {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRewardAsRefEstablishement on this unsaved Establishment.');
			if ((is_null($objReward->Idreward)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRewardAsRefEstablishement on this Establishment with an unsaved Reward.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`reward`
				WHERE
					`idreward` = ' . $objDatabase->SqlVariable($objReward->Idreward) . ' AND
					`ref_establishement` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
			');
		}

		/**
		 * Deletes all associated RewardsAsRefEstablishement
		 * @return void
		*/
		public function DeleteAllRewardsAsRefEstablishement() {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateRewardAsRefEstablishement on this unsaved Establishment.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`reward`
				WHERE
					`ref_establishement` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
			');
		}


		// Related Objects' Methods for SalaryTemplet
		//-------------------------------------------------------------------

		/**
		 * Gets all associated SalaryTemplets as an array of SalaryTemplet objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryTemplet[]
		*/
		public function GetSalaryTempletArray($objOptionalClauses = null) {
			if ((is_null($this->intIdestablishment)))
				return array();

			try {
				return SalaryTemplet::LoadArrayByEstablishment($this->intIdestablishment, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated SalaryTemplets
		 * @return int
		*/
		public function CountSalaryTemplets() {
			if ((is_null($this->intIdestablishment)))
				return 0;

			return SalaryTemplet::CountByEstablishment($this->intIdestablishment);
		}

		/**
		 * Associates a SalaryTemplet
		 * @param SalaryTemplet $objSalaryTemplet
		 * @return void
		*/
		public function AssociateSalaryTemplet(SalaryTemplet $objSalaryTemplet) {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSalaryTemplet on this unsaved Establishment.');
			if ((is_null($objSalaryTemplet->IdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSalaryTemplet on this Establishment with an unsaved SalaryTemplet.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salary_templet`
				SET
					`establishment` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
				WHERE
					`idsalary_templet` = ' . $objDatabase->SqlVariable($objSalaryTemplet->IdsalaryTemplet) . '
			');
		}

		/**
		 * Unassociates a SalaryTemplet
		 * @param SalaryTemplet $objSalaryTemplet
		 * @return void
		*/
		public function UnassociateSalaryTemplet(SalaryTemplet $objSalaryTemplet) {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryTemplet on this unsaved Establishment.');
			if ((is_null($objSalaryTemplet->IdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryTemplet on this Establishment with an unsaved SalaryTemplet.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salary_templet`
				SET
					`establishment` = null
				WHERE
					`idsalary_templet` = ' . $objDatabase->SqlVariable($objSalaryTemplet->IdsalaryTemplet) . ' AND
					`establishment` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
			');
		}

		/**
		 * Unassociates all SalaryTemplets
		 * @return void
		*/
		public function UnassociateAllSalaryTemplets() {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryTemplet on this unsaved Establishment.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salary_templet`
				SET
					`establishment` = null
				WHERE
					`establishment` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
			');
		}

		/**
		 * Deletes an associated SalaryTemplet
		 * @param SalaryTemplet $objSalaryTemplet
		 * @return void
		*/
		public function DeleteAssociatedSalaryTemplet(SalaryTemplet $objSalaryTemplet) {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryTemplet on this unsaved Establishment.');
			if ((is_null($objSalaryTemplet->IdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryTemplet on this Establishment with an unsaved SalaryTemplet.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salary_templet`
				WHERE
					`idsalary_templet` = ' . $objDatabase->SqlVariable($objSalaryTemplet->IdsalaryTemplet) . ' AND
					`establishment` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
			');
		}

		/**
		 * Deletes all associated SalaryTemplets
		 * @return void
		*/
		public function DeleteAllSalaryTemplets() {
			if ((is_null($this->intIdestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryTemplet on this unsaved Establishment.');

			// Get the Database Object for this Class
			$objDatabase = Establishment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salary_templet`
				WHERE
					`establishment` = ' . $objDatabase->SqlVariable($this->intIdestablishment) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "establishment";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Establishment::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Establishment"><sequence>';
			$strToReturn .= '<element name="Idestablishment" type="xsd:int"/>';
			$strToReturn .= '<element name="PostObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="PostInfo" type="xsd:string"/>';
			$strToReturn .= '<element name="AppointmentDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="AppointmentName" type="xsd:string"/>';
			$strToReturn .= '<element name="AppointmentDetails" type="xsd:string"/>';
			$strToReturn .= '<element name="BasicSalary" type="xsd:string"/>';
			$strToReturn .= '<element name="DateOfTermination" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Reason" type="xsd:string"/>';
			$strToReturn .= '<element name="TeminationDetails" type="xsd:string"/>';
			$strToReturn .= '<element name="EmployeeObject" type="xsd1:Address"/>';
			$strToReturn .= '<element name="AppointmentCategoryObject" type="xsd1:AppointmentCategory"/>';
			$strToReturn .= '<element name="SalaryTempletObject" type="xsd1:SalaryTemplet"/>';
			$strToReturn .= '<element name="VacancyObject" type="xsd1:Vacancy"/>';
			$strToReturn .= '<element name="VacancyDetails" type="xsd:string"/>';
			$strToReturn .= '<element name="RoleObject" type="xsd1:LoginHasRole"/>';
			$strToReturn .= '<element name="Active" type="xsd:boolean"/>';
			$strToReturn .= '<element name="AdditonalPay" type="xsd:string"/>';
			$strToReturn .= '<element name="PayDeatils" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Establishment', $strComplexTypeArray)) {
				$strComplexTypeArray['Establishment'] = Establishment::GetSoapComplexTypeXml();
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				Address::AlterSoapComplexTypeArray($strComplexTypeArray);
				AppointmentCategory::AlterSoapComplexTypeArray($strComplexTypeArray);
				SalaryTemplet::AlterSoapComplexTypeArray($strComplexTypeArray);
				Vacancy::AlterSoapComplexTypeArray($strComplexTypeArray);
				LoginHasRole::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Establishment::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Establishment();
			if (property_exists($objSoapObject, 'Idestablishment'))
				$objToReturn->intIdestablishment = $objSoapObject->Idestablishment;
			if ((property_exists($objSoapObject, 'PostObject')) &&
				($objSoapObject->PostObject))
				$objToReturn->PostObject = Role::GetObjectFromSoapObject($objSoapObject->PostObject);
			if (property_exists($objSoapObject, 'PostInfo'))
				$objToReturn->strPostInfo = $objSoapObject->PostInfo;
			if (property_exists($objSoapObject, 'AppointmentDate'))
				$objToReturn->dttAppointmentDate = new QDateTime($objSoapObject->AppointmentDate);
			if (property_exists($objSoapObject, 'AppointmentName'))
				$objToReturn->strAppointmentName = $objSoapObject->AppointmentName;
			if (property_exists($objSoapObject, 'AppointmentDetails'))
				$objToReturn->strAppointmentDetails = $objSoapObject->AppointmentDetails;
			if (property_exists($objSoapObject, 'BasicSalary'))
				$objToReturn->strBasicSalary = $objSoapObject->BasicSalary;
			if (property_exists($objSoapObject, 'DateOfTermination'))
				$objToReturn->dttDateOfTermination = new QDateTime($objSoapObject->DateOfTermination);
			if (property_exists($objSoapObject, 'Reason'))
				$objToReturn->strReason = $objSoapObject->Reason;
			if (property_exists($objSoapObject, 'TeminationDetails'))
				$objToReturn->strTeminationDetails = $objSoapObject->TeminationDetails;
			if ((property_exists($objSoapObject, 'EmployeeObject')) &&
				($objSoapObject->EmployeeObject))
				$objToReturn->EmployeeObject = Address::GetObjectFromSoapObject($objSoapObject->EmployeeObject);
			if ((property_exists($objSoapObject, 'AppointmentCategoryObject')) &&
				($objSoapObject->AppointmentCategoryObject))
				$objToReturn->AppointmentCategoryObject = AppointmentCategory::GetObjectFromSoapObject($objSoapObject->AppointmentCategoryObject);
			if ((property_exists($objSoapObject, 'SalaryTempletObject')) &&
				($objSoapObject->SalaryTempletObject))
				$objToReturn->SalaryTempletObject = SalaryTemplet::GetObjectFromSoapObject($objSoapObject->SalaryTempletObject);
			if ((property_exists($objSoapObject, 'VacancyObject')) &&
				($objSoapObject->VacancyObject))
				$objToReturn->VacancyObject = Vacancy::GetObjectFromSoapObject($objSoapObject->VacancyObject);
			if (property_exists($objSoapObject, 'VacancyDetails'))
				$objToReturn->strVacancyDetails = $objSoapObject->VacancyDetails;
			if ((property_exists($objSoapObject, 'RoleObject')) &&
				($objSoapObject->RoleObject))
				$objToReturn->RoleObject = LoginHasRole::GetObjectFromSoapObject($objSoapObject->RoleObject);
			if (property_exists($objSoapObject, 'Active'))
				$objToReturn->blnActive = $objSoapObject->Active;
			if (property_exists($objSoapObject, 'AdditonalPay'))
				$objToReturn->strAdditonalPay = $objSoapObject->AdditonalPay;
			if (property_exists($objSoapObject, 'PayDeatils'))
				$objToReturn->strPayDeatils = $objSoapObject->PayDeatils;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Establishment::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objPostObject)
				$objObject->objPostObject = Role::GetSoapObjectFromObject($objObject->objPostObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intPost = null;
			if ($objObject->dttAppointmentDate)
				$objObject->dttAppointmentDate = $objObject->dttAppointmentDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttDateOfTermination)
				$objObject->dttDateOfTermination = $objObject->dttDateOfTermination->qFormat(QDateTime::FormatSoap);
			if ($objObject->objEmployeeObject)
				$objObject->objEmployeeObject = Address::GetSoapObjectFromObject($objObject->objEmployeeObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intEmployee = null;
			if ($objObject->objAppointmentCategoryObject)
				$objObject->objAppointmentCategoryObject = AppointmentCategory::GetSoapObjectFromObject($objObject->objAppointmentCategoryObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intAppointmentCategory = null;
			if ($objObject->objSalaryTempletObject)
				$objObject->objSalaryTempletObject = SalaryTemplet::GetSoapObjectFromObject($objObject->objSalaryTempletObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSalaryTemplet = null;
			if ($objObject->objVacancyObject)
				$objObject->objVacancyObject = Vacancy::GetSoapObjectFromObject($objObject->objVacancyObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intVacancy = null;
			if ($objObject->objRoleObject)
				$objObject->objRoleObject = LoginHasRole::GetSoapObjectFromObject($objObject->objRoleObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intRole = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idestablishment'] = $this->intIdestablishment;
			$iArray['Post'] = $this->intPost;
			$iArray['PostInfo'] = $this->strPostInfo;
			$iArray['AppointmentDate'] = $this->dttAppointmentDate;
			$iArray['AppointmentName'] = $this->strAppointmentName;
			$iArray['AppointmentDetails'] = $this->strAppointmentDetails;
			$iArray['BasicSalary'] = $this->strBasicSalary;
			$iArray['DateOfTermination'] = $this->dttDateOfTermination;
			$iArray['Reason'] = $this->strReason;
			$iArray['TeminationDetails'] = $this->strTeminationDetails;
			$iArray['Employee'] = $this->intEmployee;
			$iArray['AppointmentCategory'] = $this->intAppointmentCategory;
			$iArray['SalaryTemplet'] = $this->intSalaryTemplet;
			$iArray['Vacancy'] = $this->intVacancy;
			$iArray['VacancyDetails'] = $this->strVacancyDetails;
			$iArray['Role'] = $this->intRole;
			$iArray['Active'] = $this->blnActive;
			$iArray['AdditonalPay'] = $this->strAdditonalPay;
			$iArray['PayDeatils'] = $this->strPayDeatils;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdestablishment ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idestablishment
     * @property-read QQNode $Post
     * @property-read QQNodeRole $PostObject
     * @property-read QQNode $PostInfo
     * @property-read QQNode $AppointmentDate
     * @property-read QQNode $AppointmentName
     * @property-read QQNode $AppointmentDetails
     * @property-read QQNode $BasicSalary
     * @property-read QQNode $DateOfTermination
     * @property-read QQNode $Reason
     * @property-read QQNode $TeminationDetails
     * @property-read QQNode $Employee
     * @property-read QQNodeAddress $EmployeeObject
     * @property-read QQNode $AppointmentCategory
     * @property-read QQNodeAppointmentCategory $AppointmentCategoryObject
     * @property-read QQNode $SalaryTemplet
     * @property-read QQNodeSalaryTemplet $SalaryTempletObject
     * @property-read QQNode $Vacancy
     * @property-read QQNodeVacancy $VacancyObject
     * @property-read QQNode $VacancyDetails
     * @property-read QQNode $Role
     * @property-read QQNodeLoginHasRole $RoleObject
     * @property-read QQNode $Active
     * @property-read QQNode $AdditonalPay
     * @property-read QQNode $PayDeatils
     *
     *
     * @property-read QQReverseReferenceNodeLeaves $LeavesAsRef
     * @property-read QQReverseReferenceNodeReward $RewardAsRefEstablishement
     * @property-read QQReverseReferenceNodeSalaryTemplet $SalaryTemplet

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeEstablishment extends QQNode {
		protected $strTableName = 'establishment';
		protected $strPrimaryKey = 'idestablishment';
		protected $strClassName = 'Establishment';
		public function __get($strName) {
			switch ($strName) {
				case 'Idestablishment':
					return new QQNode('idestablishment', 'Idestablishment', 'Integer', $this);
				case 'Post':
					return new QQNode('post', 'Post', 'Integer', $this);
				case 'PostObject':
					return new QQNodeRole('post', 'PostObject', 'Integer', $this);
				case 'PostInfo':
					return new QQNode('post_info', 'PostInfo', 'Blob', $this);
				case 'AppointmentDate':
					return new QQNode('appointment_date', 'AppointmentDate', 'Date', $this);
				case 'AppointmentName':
					return new QQNode('appointment_name', 'AppointmentName', 'VarChar', $this);
				case 'AppointmentDetails':
					return new QQNode('appointment_details', 'AppointmentDetails', 'Blob', $this);
				case 'BasicSalary':
					return new QQNode('basic_salary', 'BasicSalary', 'VarChar', $this);
				case 'DateOfTermination':
					return new QQNode('date_of_termination', 'DateOfTermination', 'Date', $this);
				case 'Reason':
					return new QQNode('reason', 'Reason', 'VarChar', $this);
				case 'TeminationDetails':
					return new QQNode('temination_details', 'TeminationDetails', 'Blob', $this);
				case 'Employee':
					return new QQNode('employee', 'Employee', 'Integer', $this);
				case 'EmployeeObject':
					return new QQNodeAddress('employee', 'EmployeeObject', 'Integer', $this);
				case 'AppointmentCategory':
					return new QQNode('appointment_category', 'AppointmentCategory', 'Integer', $this);
				case 'AppointmentCategoryObject':
					return new QQNodeAppointmentCategory('appointment_category', 'AppointmentCategoryObject', 'Integer', $this);
				case 'SalaryTemplet':
					return new QQNode('salary_templet', 'SalaryTemplet', 'Integer', $this);
				case 'SalaryTempletObject':
					return new QQNodeSalaryTemplet('salary_templet', 'SalaryTempletObject', 'Integer', $this);
				case 'Vacancy':
					return new QQNode('vacancy', 'Vacancy', 'Integer', $this);
				case 'VacancyObject':
					return new QQNodeVacancy('vacancy', 'VacancyObject', 'Integer', $this);
				case 'VacancyDetails':
					return new QQNode('vacancy_details', 'VacancyDetails', 'Blob', $this);
				case 'Role':
					return new QQNode('role', 'Role', 'Integer', $this);
				case 'RoleObject':
					return new QQNodeLoginHasRole('role', 'RoleObject', 'Integer', $this);
				case 'Active':
					return new QQNode('active', 'Active', 'Bit', $this);
				case 'AdditonalPay':
					return new QQNode('additonal_pay', 'AdditonalPay', 'Blob', $this);
				case 'PayDeatils':
					return new QQNode('pay_deatils', 'PayDeatils', 'Blob', $this);
				case 'LeavesAsRef':
					return new QQReverseReferenceNodeLeaves($this, 'leavesasref', 'reverse_reference', 'ref_establishment');
				case 'RewardAsRefEstablishement':
					return new QQReverseReferenceNodeReward($this, 'rewardasrefestablishement', 'reverse_reference', 'ref_establishement');
				case 'SalaryTemplet':
					return new QQReverseReferenceNodeSalaryTemplet($this, 'salarytemplet', 'reverse_reference', 'establishment');

				case '_PrimaryKeyNode':
					return new QQNode('idestablishment', 'Idestablishment', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idestablishment
     * @property-read QQNode $Post
     * @property-read QQNodeRole $PostObject
     * @property-read QQNode $PostInfo
     * @property-read QQNode $AppointmentDate
     * @property-read QQNode $AppointmentName
     * @property-read QQNode $AppointmentDetails
     * @property-read QQNode $BasicSalary
     * @property-read QQNode $DateOfTermination
     * @property-read QQNode $Reason
     * @property-read QQNode $TeminationDetails
     * @property-read QQNode $Employee
     * @property-read QQNodeAddress $EmployeeObject
     * @property-read QQNode $AppointmentCategory
     * @property-read QQNodeAppointmentCategory $AppointmentCategoryObject
     * @property-read QQNode $SalaryTemplet
     * @property-read QQNodeSalaryTemplet $SalaryTempletObject
     * @property-read QQNode $Vacancy
     * @property-read QQNodeVacancy $VacancyObject
     * @property-read QQNode $VacancyDetails
     * @property-read QQNode $Role
     * @property-read QQNodeLoginHasRole $RoleObject
     * @property-read QQNode $Active
     * @property-read QQNode $AdditonalPay
     * @property-read QQNode $PayDeatils
     *
     *
     * @property-read QQReverseReferenceNodeLeaves $LeavesAsRef
     * @property-read QQReverseReferenceNodeReward $RewardAsRefEstablishement
     * @property-read QQReverseReferenceNodeSalaryTemplet $SalaryTemplet

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeEstablishment extends QQReverseReferenceNode {
		protected $strTableName = 'establishment';
		protected $strPrimaryKey = 'idestablishment';
		protected $strClassName = 'Establishment';
		public function __get($strName) {
			switch ($strName) {
				case 'Idestablishment':
					return new QQNode('idestablishment', 'Idestablishment', 'integer', $this);
				case 'Post':
					return new QQNode('post', 'Post', 'integer', $this);
				case 'PostObject':
					return new QQNodeRole('post', 'PostObject', 'integer', $this);
				case 'PostInfo':
					return new QQNode('post_info', 'PostInfo', 'string', $this);
				case 'AppointmentDate':
					return new QQNode('appointment_date', 'AppointmentDate', 'QDateTime', $this);
				case 'AppointmentName':
					return new QQNode('appointment_name', 'AppointmentName', 'string', $this);
				case 'AppointmentDetails':
					return new QQNode('appointment_details', 'AppointmentDetails', 'string', $this);
				case 'BasicSalary':
					return new QQNode('basic_salary', 'BasicSalary', 'string', $this);
				case 'DateOfTermination':
					return new QQNode('date_of_termination', 'DateOfTermination', 'QDateTime', $this);
				case 'Reason':
					return new QQNode('reason', 'Reason', 'string', $this);
				case 'TeminationDetails':
					return new QQNode('temination_details', 'TeminationDetails', 'string', $this);
				case 'Employee':
					return new QQNode('employee', 'Employee', 'integer', $this);
				case 'EmployeeObject':
					return new QQNodeAddress('employee', 'EmployeeObject', 'integer', $this);
				case 'AppointmentCategory':
					return new QQNode('appointment_category', 'AppointmentCategory', 'integer', $this);
				case 'AppointmentCategoryObject':
					return new QQNodeAppointmentCategory('appointment_category', 'AppointmentCategoryObject', 'integer', $this);
				case 'SalaryTemplet':
					return new QQNode('salary_templet', 'SalaryTemplet', 'integer', $this);
				case 'SalaryTempletObject':
					return new QQNodeSalaryTemplet('salary_templet', 'SalaryTempletObject', 'integer', $this);
				case 'Vacancy':
					return new QQNode('vacancy', 'Vacancy', 'integer', $this);
				case 'VacancyObject':
					return new QQNodeVacancy('vacancy', 'VacancyObject', 'integer', $this);
				case 'VacancyDetails':
					return new QQNode('vacancy_details', 'VacancyDetails', 'string', $this);
				case 'Role':
					return new QQNode('role', 'Role', 'integer', $this);
				case 'RoleObject':
					return new QQNodeLoginHasRole('role', 'RoleObject', 'integer', $this);
				case 'Active':
					return new QQNode('active', 'Active', 'boolean', $this);
				case 'AdditonalPay':
					return new QQNode('additonal_pay', 'AdditonalPay', 'string', $this);
				case 'PayDeatils':
					return new QQNode('pay_deatils', 'PayDeatils', 'string', $this);
				case 'LeavesAsRef':
					return new QQReverseReferenceNodeLeaves($this, 'leavesasref', 'reverse_reference', 'ref_establishment');
				case 'RewardAsRefEstablishement':
					return new QQReverseReferenceNodeReward($this, 'rewardasrefestablishement', 'reverse_reference', 'ref_establishement');
				case 'SalaryTemplet':
					return new QQReverseReferenceNodeSalaryTemplet($this, 'salarytemplet', 'reverse_reference', 'establishment');

				case '_PrimaryKeyNode':
					return new QQNode('idestablishment', 'Idestablishment', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
