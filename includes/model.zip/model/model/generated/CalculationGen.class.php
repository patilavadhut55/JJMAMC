<?php
	/**
	 * The abstract CalculationGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Calculation subclass which
	 * extends this CalculationGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Calculation class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idcalculation the value for intIdcalculation (Read-Only PK)
	 * @property integer $SalaryHead the value for intSalaryHead (Not Null)
	 * @property integer $SalaryHead1 the value for intSalaryHead1 
	 * @property string $Operation the value for strOperation (Not Null)
	 * @property integer $SalaryHead2 the value for intSalaryHead2 (Not Null)
	 * @property SalaryHead $SalaryHeadObject the value for the SalaryHead object referenced by intSalaryHead (Not Null)
	 * @property SalaryHead $SalaryHead1Object the value for the SalaryHead object referenced by intSalaryHead1 
	 * @property SalaryHead $SalaryHead2Object the value for the SalaryHead object referenced by intSalaryHead2 (Not Null)
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class CalculationGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column calculation.idcalculation
		 * @var integer intIdcalculation
		 */
		protected $intIdcalculation;
		const IdcalculationDefault = null;


		/**
		 * Protected member variable that maps to the database column calculation.salary_head
		 * @var integer intSalaryHead
		 */
		protected $intSalaryHead;
		const SalaryHeadDefault = null;


		/**
		 * Protected member variable that maps to the database column calculation.salary_head_1
		 * @var integer intSalaryHead1
		 */
		protected $intSalaryHead1;
		const SalaryHead1Default = null;


		/**
		 * Protected member variable that maps to the database column calculation.operation
		 * @var string strOperation
		 */
		protected $strOperation;
		const OperationMaxLength = 1;
		const OperationDefault = null;


		/**
		 * Protected member variable that maps to the database column calculation.salary_head_2
		 * @var integer intSalaryHead2
		 */
		protected $intSalaryHead2;
		const SalaryHead2Default = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column calculation.salary_head.
		 *
		 * NOTE: Always use the SalaryHeadObject property getter to correctly retrieve this SalaryHead object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var SalaryHead objSalaryHeadObject
		 */
		protected $objSalaryHeadObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column calculation.salary_head_1.
		 *
		 * NOTE: Always use the SalaryHead1Object property getter to correctly retrieve this SalaryHead object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var SalaryHead objSalaryHead1Object
		 */
		protected $objSalaryHead1Object;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column calculation.salary_head_2.
		 *
		 * NOTE: Always use the SalaryHead2Object property getter to correctly retrieve this SalaryHead object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var SalaryHead objSalaryHead2Object
		 */
		protected $objSalaryHead2Object;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdcalculation = Calculation::IdcalculationDefault;
			$this->intSalaryHead = Calculation::SalaryHeadDefault;
			$this->intSalaryHead1 = Calculation::SalaryHead1Default;
			$this->strOperation = Calculation::OperationDefault;
			$this->intSalaryHead2 = Calculation::SalaryHead2Default;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Calculation from PK Info
		 * @param integer $intIdcalculation
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Calculation
		 */
		public static function Load($intIdcalculation, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Calculation', $intIdcalculation);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Calculation::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Calculation()->Idcalculation, $intIdcalculation)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Calculations
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Calculation[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Calculation::QueryArray to perform the LoadAll query
			try {
				return Calculation::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Calculations
		 * @return int
		 */
		public static function CountAll() {
			// Call Calculation::QueryCount to perform the CountAll query
			return Calculation::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Calculation::GetDatabase();

			// Create/Build out the QueryBuilder object with Calculation-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'calculation');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Calculation::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('calculation');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Calculation object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Calculation the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Calculation::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Calculation object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Calculation::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Calculation::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Calculation objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Calculation[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Calculation::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Calculation::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Calculation::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Calculation objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Calculation::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Calculation::GetDatabase();

			$strQuery = Calculation::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/calculation', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Calculation::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Calculation
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'calculation';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idcalculation', $strAliasPrefix . 'idcalculation');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idcalculation', $strAliasPrefix . 'idcalculation');
			    $objBuilder->AddSelectItem($strTableName, 'salary_head', $strAliasPrefix . 'salary_head');
			    $objBuilder->AddSelectItem($strTableName, 'salary_head_1', $strAliasPrefix . 'salary_head_1');
			    $objBuilder->AddSelectItem($strTableName, 'operation', $strAliasPrefix . 'operation');
			    $objBuilder->AddSelectItem($strTableName, 'salary_head_2', $strAliasPrefix . 'salary_head_2');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Calculation from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Calculation::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Calculation
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the Calculation object
			$objToReturn = new Calculation();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idcalculation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdcalculation = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'salary_head';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSalaryHead = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'salary_head_1';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSalaryHead1 = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'operation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strOperation = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'salary_head_2';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSalaryHead2 = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idcalculation != $objPreviousItem->Idcalculation) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'calculation__';

			// Check for SalaryHeadObject Early Binding
			$strAlias = $strAliasPrefix . 'salary_head__idsalary_head';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSalaryHeadObject = SalaryHead::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salary_head__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for SalaryHead1Object Early Binding
			$strAlias = $strAliasPrefix . 'salary_head_1__idsalary_head';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSalaryHead1Object = SalaryHead::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salary_head_1__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for SalaryHead2Object Early Binding
			$strAlias = $strAliasPrefix . 'salary_head_2__idsalary_head';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSalaryHead2Object = SalaryHead::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salary_head_2__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of Calculations from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Calculation[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Calculation::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Calculation::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Calculation object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Calculation next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Calculation::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Calculation object,
		 * by Idcalculation Index(es)
		 * @param integer $intIdcalculation
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Calculation
		*/
		public static function LoadByIdcalculation($intIdcalculation, $objOptionalClauses = null) {
			return Calculation::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Calculation()->Idcalculation, $intIdcalculation)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Calculation objects,
		 * by SalaryHead Index(es)
		 * @param integer $intSalaryHead
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Calculation[]
		*/
		public static function LoadArrayBySalaryHead($intSalaryHead, $objOptionalClauses = null) {
			// Call Calculation::QueryArray to perform the LoadArrayBySalaryHead query
			try {
				return Calculation::QueryArray(
					QQ::Equal(QQN::Calculation()->SalaryHead, $intSalaryHead),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Calculations
		 * by SalaryHead Index(es)
		 * @param integer $intSalaryHead
		 * @return int
		*/
		public static function CountBySalaryHead($intSalaryHead) {
			// Call Calculation::QueryCount to perform the CountBySalaryHead query
			return Calculation::QueryCount(
				QQ::Equal(QQN::Calculation()->SalaryHead, $intSalaryHead)
			);
		}

		/**
		 * Load an array of Calculation objects,
		 * by SalaryHead1 Index(es)
		 * @param integer $intSalaryHead1
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Calculation[]
		*/
		public static function LoadArrayBySalaryHead1($intSalaryHead1, $objOptionalClauses = null) {
			// Call Calculation::QueryArray to perform the LoadArrayBySalaryHead1 query
			try {
				return Calculation::QueryArray(
					QQ::Equal(QQN::Calculation()->SalaryHead1, $intSalaryHead1),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Calculations
		 * by SalaryHead1 Index(es)
		 * @param integer $intSalaryHead1
		 * @return int
		*/
		public static function CountBySalaryHead1($intSalaryHead1) {
			// Call Calculation::QueryCount to perform the CountBySalaryHead1 query
			return Calculation::QueryCount(
				QQ::Equal(QQN::Calculation()->SalaryHead1, $intSalaryHead1)
			);
		}

		/**
		 * Load an array of Calculation objects,
		 * by SalaryHead2 Index(es)
		 * @param integer $intSalaryHead2
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Calculation[]
		*/
		public static function LoadArrayBySalaryHead2($intSalaryHead2, $objOptionalClauses = null) {
			// Call Calculation::QueryArray to perform the LoadArrayBySalaryHead2 query
			try {
				return Calculation::QueryArray(
					QQ::Equal(QQN::Calculation()->SalaryHead2, $intSalaryHead2),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Calculations
		 * by SalaryHead2 Index(es)
		 * @param integer $intSalaryHead2
		 * @return int
		*/
		public static function CountBySalaryHead2($intSalaryHead2) {
			// Call Calculation::QueryCount to perform the CountBySalaryHead2 query
			return Calculation::QueryCount(
				QQ::Equal(QQN::Calculation()->SalaryHead2, $intSalaryHead2)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Calculation
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Calculation::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `calculation` (
							`salary_head`,
							`salary_head_1`,
							`operation`,
							`salary_head_2`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intSalaryHead) . ',
							' . $objDatabase->SqlVariable($this->intSalaryHead1) . ',
							' . $objDatabase->SqlVariable($this->strOperation) . ',
							' . $objDatabase->SqlVariable($this->intSalaryHead2) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdcalculation = $objDatabase->InsertId('calculation', 'idcalculation');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`calculation`
						SET
							`salary_head` = ' . $objDatabase->SqlVariable($this->intSalaryHead) . ',
							`salary_head_1` = ' . $objDatabase->SqlVariable($this->intSalaryHead1) . ',
							`operation` = ' . $objDatabase->SqlVariable($this->strOperation) . ',
							`salary_head_2` = ' . $objDatabase->SqlVariable($this->intSalaryHead2) . '
						WHERE
							`idcalculation` = ' . $objDatabase->SqlVariable($this->intIdcalculation) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Calculation
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdcalculation)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Calculation with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Calculation::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`calculation`
				WHERE
					`idcalculation` = ' . $objDatabase->SqlVariable($this->intIdcalculation) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Calculation ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Calculation', $this->intIdcalculation);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Calculations
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Calculation::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`calculation`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate calculation table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Calculation::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `calculation`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Calculation from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Calculation object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Calculation::Load($this->intIdcalculation);

			// Update $this's local variables to match
			$this->SalaryHead = $objReloaded->SalaryHead;
			$this->SalaryHead1 = $objReloaded->SalaryHead1;
			$this->strOperation = $objReloaded->strOperation;
			$this->SalaryHead2 = $objReloaded->SalaryHead2;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idcalculation':
					/**
					 * Gets the value for intIdcalculation (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdcalculation;

				case 'SalaryHead':
					/**
					 * Gets the value for intSalaryHead (Not Null)
					 * @return integer
					 */
					return $this->intSalaryHead;

				case 'SalaryHead1':
					/**
					 * Gets the value for intSalaryHead1 
					 * @return integer
					 */
					return $this->intSalaryHead1;

				case 'Operation':
					/**
					 * Gets the value for strOperation (Not Null)
					 * @return string
					 */
					return $this->strOperation;

				case 'SalaryHead2':
					/**
					 * Gets the value for intSalaryHead2 (Not Null)
					 * @return integer
					 */
					return $this->intSalaryHead2;


				///////////////////
				// Member Objects
				///////////////////
				case 'SalaryHeadObject':
					/**
					 * Gets the value for the SalaryHead object referenced by intSalaryHead (Not Null)
					 * @return SalaryHead
					 */
					try {
						if ((!$this->objSalaryHeadObject) && (!is_null($this->intSalaryHead)))
							$this->objSalaryHeadObject = SalaryHead::Load($this->intSalaryHead);
						return $this->objSalaryHeadObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SalaryHead1Object':
					/**
					 * Gets the value for the SalaryHead object referenced by intSalaryHead1 
					 * @return SalaryHead
					 */
					try {
						if ((!$this->objSalaryHead1Object) && (!is_null($this->intSalaryHead1)))
							$this->objSalaryHead1Object = SalaryHead::Load($this->intSalaryHead1);
						return $this->objSalaryHead1Object;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SalaryHead2Object':
					/**
					 * Gets the value for the SalaryHead object referenced by intSalaryHead2 (Not Null)
					 * @return SalaryHead
					 */
					try {
						if ((!$this->objSalaryHead2Object) && (!is_null($this->intSalaryHead2)))
							$this->objSalaryHead2Object = SalaryHead::Load($this->intSalaryHead2);
						return $this->objSalaryHead2Object;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'SalaryHead':
					/**
					 * Sets the value for intSalaryHead (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSalaryHeadObject = null;
						return ($this->intSalaryHead = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SalaryHead1':
					/**
					 * Sets the value for intSalaryHead1 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSalaryHead1Object = null;
						return ($this->intSalaryHead1 = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Operation':
					/**
					 * Sets the value for strOperation (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strOperation = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SalaryHead2':
					/**
					 * Sets the value for intSalaryHead2 (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSalaryHead2Object = null;
						return ($this->intSalaryHead2 = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'SalaryHeadObject':
					/**
					 * Sets the value for the SalaryHead object referenced by intSalaryHead (Not Null)
					 * @param SalaryHead $mixValue
					 * @return SalaryHead
					 */
					if (is_null($mixValue)) {
						$this->intSalaryHead = null;
						$this->objSalaryHeadObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a SalaryHead object
						try {
							$mixValue = QType::Cast($mixValue, 'SalaryHead');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED SalaryHead object
						if (is_null($mixValue->IdsalaryHead))
							throw new QCallerException('Unable to set an unsaved SalaryHeadObject for this Calculation');

						// Update Local Member Variables
						$this->objSalaryHeadObject = $mixValue;
						$this->intSalaryHead = $mixValue->IdsalaryHead;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'SalaryHead1Object':
					/**
					 * Sets the value for the SalaryHead object referenced by intSalaryHead1 
					 * @param SalaryHead $mixValue
					 * @return SalaryHead
					 */
					if (is_null($mixValue)) {
						$this->intSalaryHead1 = null;
						$this->objSalaryHead1Object = null;
						return null;
					} else {
						// Make sure $mixValue actually is a SalaryHead object
						try {
							$mixValue = QType::Cast($mixValue, 'SalaryHead');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED SalaryHead object
						if (is_null($mixValue->IdsalaryHead))
							throw new QCallerException('Unable to set an unsaved SalaryHead1Object for this Calculation');

						// Update Local Member Variables
						$this->objSalaryHead1Object = $mixValue;
						$this->intSalaryHead1 = $mixValue->IdsalaryHead;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'SalaryHead2Object':
					/**
					 * Sets the value for the SalaryHead object referenced by intSalaryHead2 (Not Null)
					 * @param SalaryHead $mixValue
					 * @return SalaryHead
					 */
					if (is_null($mixValue)) {
						$this->intSalaryHead2 = null;
						$this->objSalaryHead2Object = null;
						return null;
					} else {
						// Make sure $mixValue actually is a SalaryHead object
						try {
							$mixValue = QType::Cast($mixValue, 'SalaryHead');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED SalaryHead object
						if (is_null($mixValue->IdsalaryHead))
							throw new QCallerException('Unable to set an unsaved SalaryHead2Object for this Calculation');

						// Update Local Member Variables
						$this->objSalaryHead2Object = $mixValue;
						$this->intSalaryHead2 = $mixValue->IdsalaryHead;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "calculation";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Calculation::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Calculation"><sequence>';
			$strToReturn .= '<element name="Idcalculation" type="xsd:int"/>';
			$strToReturn .= '<element name="SalaryHeadObject" type="xsd1:SalaryHead"/>';
			$strToReturn .= '<element name="SalaryHead1Object" type="xsd1:SalaryHead"/>';
			$strToReturn .= '<element name="Operation" type="xsd:string"/>';
			$strToReturn .= '<element name="SalaryHead2Object" type="xsd1:SalaryHead"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Calculation', $strComplexTypeArray)) {
				$strComplexTypeArray['Calculation'] = Calculation::GetSoapComplexTypeXml();
				SalaryHead::AlterSoapComplexTypeArray($strComplexTypeArray);
				SalaryHead::AlterSoapComplexTypeArray($strComplexTypeArray);
				SalaryHead::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Calculation::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Calculation();
			if (property_exists($objSoapObject, 'Idcalculation'))
				$objToReturn->intIdcalculation = $objSoapObject->Idcalculation;
			if ((property_exists($objSoapObject, 'SalaryHeadObject')) &&
				($objSoapObject->SalaryHeadObject))
				$objToReturn->SalaryHeadObject = SalaryHead::GetObjectFromSoapObject($objSoapObject->SalaryHeadObject);
			if ((property_exists($objSoapObject, 'SalaryHead1Object')) &&
				($objSoapObject->SalaryHead1Object))
				$objToReturn->SalaryHead1Object = SalaryHead::GetObjectFromSoapObject($objSoapObject->SalaryHead1Object);
			if (property_exists($objSoapObject, 'Operation'))
				$objToReturn->strOperation = $objSoapObject->Operation;
			if ((property_exists($objSoapObject, 'SalaryHead2Object')) &&
				($objSoapObject->SalaryHead2Object))
				$objToReturn->SalaryHead2Object = SalaryHead::GetObjectFromSoapObject($objSoapObject->SalaryHead2Object);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Calculation::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objSalaryHeadObject)
				$objObject->objSalaryHeadObject = SalaryHead::GetSoapObjectFromObject($objObject->objSalaryHeadObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSalaryHead = null;
			if ($objObject->objSalaryHead1Object)
				$objObject->objSalaryHead1Object = SalaryHead::GetSoapObjectFromObject($objObject->objSalaryHead1Object, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSalaryHead1 = null;
			if ($objObject->objSalaryHead2Object)
				$objObject->objSalaryHead2Object = SalaryHead::GetSoapObjectFromObject($objObject->objSalaryHead2Object, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSalaryHead2 = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idcalculation'] = $this->intIdcalculation;
			$iArray['SalaryHead'] = $this->intSalaryHead;
			$iArray['SalaryHead1'] = $this->intSalaryHead1;
			$iArray['Operation'] = $this->strOperation;
			$iArray['SalaryHead2'] = $this->intSalaryHead2;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdcalculation ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idcalculation
     * @property-read QQNode $SalaryHead
     * @property-read QQNodeSalaryHead $SalaryHeadObject
     * @property-read QQNode $SalaryHead1
     * @property-read QQNodeSalaryHead $SalaryHead1Object
     * @property-read QQNode $Operation
     * @property-read QQNode $SalaryHead2
     * @property-read QQNodeSalaryHead $SalaryHead2Object
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeCalculation extends QQNode {
		protected $strTableName = 'calculation';
		protected $strPrimaryKey = 'idcalculation';
		protected $strClassName = 'Calculation';
		public function __get($strName) {
			switch ($strName) {
				case 'Idcalculation':
					return new QQNode('idcalculation', 'Idcalculation', 'Integer', $this);
				case 'SalaryHead':
					return new QQNode('salary_head', 'SalaryHead', 'Integer', $this);
				case 'SalaryHeadObject':
					return new QQNodeSalaryHead('salary_head', 'SalaryHeadObject', 'Integer', $this);
				case 'SalaryHead1':
					return new QQNode('salary_head_1', 'SalaryHead1', 'Integer', $this);
				case 'SalaryHead1Object':
					return new QQNodeSalaryHead('salary_head_1', 'SalaryHead1Object', 'Integer', $this);
				case 'Operation':
					return new QQNode('operation', 'Operation', 'VarChar', $this);
				case 'SalaryHead2':
					return new QQNode('salary_head_2', 'SalaryHead2', 'Integer', $this);
				case 'SalaryHead2Object':
					return new QQNodeSalaryHead('salary_head_2', 'SalaryHead2Object', 'Integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idcalculation', 'Idcalculation', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idcalculation
     * @property-read QQNode $SalaryHead
     * @property-read QQNodeSalaryHead $SalaryHeadObject
     * @property-read QQNode $SalaryHead1
     * @property-read QQNodeSalaryHead $SalaryHead1Object
     * @property-read QQNode $Operation
     * @property-read QQNode $SalaryHead2
     * @property-read QQNodeSalaryHead $SalaryHead2Object
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeCalculation extends QQReverseReferenceNode {
		protected $strTableName = 'calculation';
		protected $strPrimaryKey = 'idcalculation';
		protected $strClassName = 'Calculation';
		public function __get($strName) {
			switch ($strName) {
				case 'Idcalculation':
					return new QQNode('idcalculation', 'Idcalculation', 'integer', $this);
				case 'SalaryHead':
					return new QQNode('salary_head', 'SalaryHead', 'integer', $this);
				case 'SalaryHeadObject':
					return new QQNodeSalaryHead('salary_head', 'SalaryHeadObject', 'integer', $this);
				case 'SalaryHead1':
					return new QQNode('salary_head_1', 'SalaryHead1', 'integer', $this);
				case 'SalaryHead1Object':
					return new QQNodeSalaryHead('salary_head_1', 'SalaryHead1Object', 'integer', $this);
				case 'Operation':
					return new QQNode('operation', 'Operation', 'string', $this);
				case 'SalaryHead2':
					return new QQNode('salary_head_2', 'SalaryHead2', 'integer', $this);
				case 'SalaryHead2Object':
					return new QQNodeSalaryHead('salary_head_2', 'SalaryHead2Object', 'integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idcalculation', 'Idcalculation', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
