<?php
	/**
	 * The abstract ProfileGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Profile subclass which
	 * extends this ProfileGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Profile class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property integer $Idprofile the value for intIdprofile (PK)
	 * @property string $OldPrn the value for strOldPrn 
	 * @property string $ApplicationNo the value for strApplicationNo 
	 * @property string $MeritNo the value for strMeritNo 
	 * @property double $MeritMark the value for fltMeritMark 
	 * @property QDateTime $AddmissionDate the value for dttAddmissionDate 
	 * @property QDateTime $LeaveDate the value for dttLeaveDate 
	 * @property integer $MarrtialStatus the value for intMarrtialStatus 
	 * @property integer $Handicaped the value for intHandicaped 
	 * @property boolean $AdharStatus the value for blnAdharStatus 
	 * @property string $AdharNo the value for strAdharNo 
	 * @property string $IdentificationMark the value for strIdentificationMark 
	 * @property boolean $FeeConcessionApplicable the value for blnFeeConcessionApplicable 
	 * @property string $FeeConcessionType the value for strFeeConcessionType 
	 * @property string $AnnualFamilyIncome the value for strAnnualFamilyIncome 
	 * @property integer $BloodGroup the value for intBloodGroup 
	 * @property integer $MotherTongue the value for intMotherTongue 
	 * @property integer $Religion the value for intReligion 
	 * @property integer $Caste the value for intCaste 
	 * @property integer $Nationality the value for intNationality 
	 * @property integer $CourseOfAddmission the value for intCourseOfAddmission 
	 * @property integer $CurrentCourse the value for intCurrentCourse 
	 * @property integer $BranchOfAddmission the value for intBranchOfAddmission 
	 * @property integer $CurrentBranch the value for intCurrentBranch 
	 * @property integer $AdmissionDiv the value for intAdmissionDiv 
	 * @property integer $CurrentDiv the value for intCurrentDiv 
	 * @property integer $HandicapedCat the value for intHandicapedCat 
	 * @property Ledger $IdprofileObject the value for the Ledger object referenced by intIdprofile (PK)
	 * @property MarrialStatus $MarrtialStatusObject the value for the MarrialStatus object referenced by intMarrtialStatus 
	 * @property BloodGroup $BloodGroupObject the value for the BloodGroup object referenced by intBloodGroup 
	 * @property MotherTongue $MotherTongueObject the value for the MotherTongue object referenced by intMotherTongue 
	 * @property Religion $ReligionObject the value for the Religion object referenced by intReligion 
	 * @property Caste $CasteObject the value for the Caste object referenced by intCaste 
	 * @property Nationality $NationalityObject the value for the Nationality object referenced by intNationality 
	 * @property Role $CourseOfAddmissionObject the value for the Role object referenced by intCourseOfAddmission 
	 * @property Role $CurrentCourseObject the value for the Role object referenced by intCurrentCourse 
	 * @property Role $BranchOfAddmissionObject the value for the Role object referenced by intBranchOfAddmission 
	 * @property Role $CurrentBranchObject the value for the Role object referenced by intCurrentBranch 
	 * @property Role $AdmissionDivObject the value for the Role object referenced by intAdmissionDiv 
	 * @property Role $CurrentDivObject the value for the Role object referenced by intCurrentDiv 
	 * @property HandicapedCat $HandicapedCatObject the value for the HandicapedCat object referenced by intHandicapedCat 
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class ProfileGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK column profile.idprofile
		 * @var integer intIdprofile
		 */
		protected $intIdprofile;
		const IdprofileDefault = null;


		/**
		 * Protected internal member variable that stores the original version of the PK column value (if restored)
		 * Used by Save() to update a PK column during UPDATE
		 * @var integer __intIdprofile;
		 */
		protected $__intIdprofile;

		/**
		 * Protected member variable that maps to the database column profile.old_prn
		 * @var string strOldPrn
		 */
		protected $strOldPrn;
		const OldPrnMaxLength = 45;
		const OldPrnDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.application_no
		 * @var string strApplicationNo
		 */
		protected $strApplicationNo;
		const ApplicationNoMaxLength = 45;
		const ApplicationNoDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.merit_no
		 * @var string strMeritNo
		 */
		protected $strMeritNo;
		const MeritNoMaxLength = 45;
		const MeritNoDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.merit_mark
		 * @var double fltMeritMark
		 */
		protected $fltMeritMark;
		const MeritMarkDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.addmission_date
		 * @var QDateTime dttAddmissionDate
		 */
		protected $dttAddmissionDate;
		const AddmissionDateDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.leave_date
		 * @var QDateTime dttLeaveDate
		 */
		protected $dttLeaveDate;
		const LeaveDateDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.marrtial_status
		 * @var integer intMarrtialStatus
		 */
		protected $intMarrtialStatus;
		const MarrtialStatusDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.handicaped
		 * @var integer intHandicaped
		 */
		protected $intHandicaped;
		const HandicapedDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.adhar_status
		 * @var boolean blnAdharStatus
		 */
		protected $blnAdharStatus;
		const AdharStatusDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.adhar_no
		 * @var string strAdharNo
		 */
		protected $strAdharNo;
		const AdharNoMaxLength = 45;
		const AdharNoDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.identification_mark
		 * @var string strIdentificationMark
		 */
		protected $strIdentificationMark;
		const IdentificationMarkMaxLength = 45;
		const IdentificationMarkDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.fee_concession_applicable
		 * @var boolean blnFeeConcessionApplicable
		 */
		protected $blnFeeConcessionApplicable;
		const FeeConcessionApplicableDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.fee_concession_type
		 * @var string strFeeConcessionType
		 */
		protected $strFeeConcessionType;
		const FeeConcessionTypeMaxLength = 45;
		const FeeConcessionTypeDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.annual_family_income
		 * @var string strAnnualFamilyIncome
		 */
		protected $strAnnualFamilyIncome;
		const AnnualFamilyIncomeDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.blood_group
		 * @var integer intBloodGroup
		 */
		protected $intBloodGroup;
		const BloodGroupDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.mother_tongue
		 * @var integer intMotherTongue
		 */
		protected $intMotherTongue;
		const MotherTongueDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.religion
		 * @var integer intReligion
		 */
		protected $intReligion;
		const ReligionDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.caste
		 * @var integer intCaste
		 */
		protected $intCaste;
		const CasteDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.nationality
		 * @var integer intNationality
		 */
		protected $intNationality;
		const NationalityDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.course_of_addmission
		 * @var integer intCourseOfAddmission
		 */
		protected $intCourseOfAddmission;
		const CourseOfAddmissionDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.current_course
		 * @var integer intCurrentCourse
		 */
		protected $intCurrentCourse;
		const CurrentCourseDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.branch_of_addmission
		 * @var integer intBranchOfAddmission
		 */
		protected $intBranchOfAddmission;
		const BranchOfAddmissionDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.current_branch
		 * @var integer intCurrentBranch
		 */
		protected $intCurrentBranch;
		const CurrentBranchDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.admission_div
		 * @var integer intAdmissionDiv
		 */
		protected $intAdmissionDiv;
		const AdmissionDivDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.current_div
		 * @var integer intCurrentDiv
		 */
		protected $intCurrentDiv;
		const CurrentDivDefault = null;


		/**
		 * Protected member variable that maps to the database column profile.handicaped_cat
		 * @var integer intHandicapedCat
		 */
		protected $intHandicapedCat;
		const HandicapedCatDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column profile.idprofile.
		 *
		 * NOTE: Always use the IdprofileObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objIdprofileObject
		 */
		protected $objIdprofileObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column profile.marrtial_status.
		 *
		 * NOTE: Always use the MarrtialStatusObject property getter to correctly retrieve this MarrialStatus object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var MarrialStatus objMarrtialStatusObject
		 */
		protected $objMarrtialStatusObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column profile.blood_group.
		 *
		 * NOTE: Always use the BloodGroupObject property getter to correctly retrieve this BloodGroup object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var BloodGroup objBloodGroupObject
		 */
		protected $objBloodGroupObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column profile.mother_tongue.
		 *
		 * NOTE: Always use the MotherTongueObject property getter to correctly retrieve this MotherTongue object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var MotherTongue objMotherTongueObject
		 */
		protected $objMotherTongueObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column profile.religion.
		 *
		 * NOTE: Always use the ReligionObject property getter to correctly retrieve this Religion object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Religion objReligionObject
		 */
		protected $objReligionObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column profile.caste.
		 *
		 * NOTE: Always use the CasteObject property getter to correctly retrieve this Caste object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Caste objCasteObject
		 */
		protected $objCasteObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column profile.nationality.
		 *
		 * NOTE: Always use the NationalityObject property getter to correctly retrieve this Nationality object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Nationality objNationalityObject
		 */
		protected $objNationalityObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column profile.course_of_addmission.
		 *
		 * NOTE: Always use the CourseOfAddmissionObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objCourseOfAddmissionObject
		 */
		protected $objCourseOfAddmissionObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column profile.current_course.
		 *
		 * NOTE: Always use the CurrentCourseObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objCurrentCourseObject
		 */
		protected $objCurrentCourseObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column profile.branch_of_addmission.
		 *
		 * NOTE: Always use the BranchOfAddmissionObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objBranchOfAddmissionObject
		 */
		protected $objBranchOfAddmissionObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column profile.current_branch.
		 *
		 * NOTE: Always use the CurrentBranchObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objCurrentBranchObject
		 */
		protected $objCurrentBranchObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column profile.admission_div.
		 *
		 * NOTE: Always use the AdmissionDivObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objAdmissionDivObject
		 */
		protected $objAdmissionDivObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column profile.current_div.
		 *
		 * NOTE: Always use the CurrentDivObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objCurrentDivObject
		 */
		protected $objCurrentDivObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column profile.handicaped_cat.
		 *
		 * NOTE: Always use the HandicapedCatObject property getter to correctly retrieve this HandicapedCat object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var HandicapedCat objHandicapedCatObject
		 */
		protected $objHandicapedCatObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdprofile = Profile::IdprofileDefault;
			$this->strOldPrn = Profile::OldPrnDefault;
			$this->strApplicationNo = Profile::ApplicationNoDefault;
			$this->strMeritNo = Profile::MeritNoDefault;
			$this->fltMeritMark = Profile::MeritMarkDefault;
			$this->dttAddmissionDate = (Profile::AddmissionDateDefault === null)?null:new QDateTime(Profile::AddmissionDateDefault);
			$this->dttLeaveDate = (Profile::LeaveDateDefault === null)?null:new QDateTime(Profile::LeaveDateDefault);
			$this->intMarrtialStatus = Profile::MarrtialStatusDefault;
			$this->intHandicaped = Profile::HandicapedDefault;
			$this->blnAdharStatus = Profile::AdharStatusDefault;
			$this->strAdharNo = Profile::AdharNoDefault;
			$this->strIdentificationMark = Profile::IdentificationMarkDefault;
			$this->blnFeeConcessionApplicable = Profile::FeeConcessionApplicableDefault;
			$this->strFeeConcessionType = Profile::FeeConcessionTypeDefault;
			$this->strAnnualFamilyIncome = Profile::AnnualFamilyIncomeDefault;
			$this->intBloodGroup = Profile::BloodGroupDefault;
			$this->intMotherTongue = Profile::MotherTongueDefault;
			$this->intReligion = Profile::ReligionDefault;
			$this->intCaste = Profile::CasteDefault;
			$this->intNationality = Profile::NationalityDefault;
			$this->intCourseOfAddmission = Profile::CourseOfAddmissionDefault;
			$this->intCurrentCourse = Profile::CurrentCourseDefault;
			$this->intBranchOfAddmission = Profile::BranchOfAddmissionDefault;
			$this->intCurrentBranch = Profile::CurrentBranchDefault;
			$this->intAdmissionDiv = Profile::AdmissionDivDefault;
			$this->intCurrentDiv = Profile::CurrentDivDefault;
			$this->intHandicapedCat = Profile::HandicapedCatDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Profile from PK Info
		 * @param integer $intIdprofile
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile
		 */
		public static function Load($intIdprofile, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Profile', $intIdprofile);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Profile::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Profile()->Idprofile, $intIdprofile)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Profiles
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Profile::QueryArray to perform the LoadAll query
			try {
				return Profile::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Profiles
		 * @return int
		 */
		public static function CountAll() {
			// Call Profile::QueryCount to perform the CountAll query
			return Profile::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Profile::GetDatabase();

			// Create/Build out the QueryBuilder object with Profile-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'profile');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Profile::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('profile');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Profile object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Profile the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Profile::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Profile object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Profile::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Profile::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Profile objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Profile[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Profile::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Profile::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Profile::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Profile objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Profile::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Profile::GetDatabase();

			$strQuery = Profile::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/profile', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Profile::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Profile
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'profile';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idprofile', $strAliasPrefix . 'idprofile');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idprofile', $strAliasPrefix . 'idprofile');
			    $objBuilder->AddSelectItem($strTableName, 'old_prn', $strAliasPrefix . 'old_prn');
			    $objBuilder->AddSelectItem($strTableName, 'application_no', $strAliasPrefix . 'application_no');
			    $objBuilder->AddSelectItem($strTableName, 'merit_no', $strAliasPrefix . 'merit_no');
			    $objBuilder->AddSelectItem($strTableName, 'merit_mark', $strAliasPrefix . 'merit_mark');
			    $objBuilder->AddSelectItem($strTableName, 'addmission_date', $strAliasPrefix . 'addmission_date');
			    $objBuilder->AddSelectItem($strTableName, 'leave_date', $strAliasPrefix . 'leave_date');
			    $objBuilder->AddSelectItem($strTableName, 'marrtial_status', $strAliasPrefix . 'marrtial_status');
			    $objBuilder->AddSelectItem($strTableName, 'handicaped', $strAliasPrefix . 'handicaped');
			    $objBuilder->AddSelectItem($strTableName, 'adhar_status', $strAliasPrefix . 'adhar_status');
			    $objBuilder->AddSelectItem($strTableName, 'adhar_no', $strAliasPrefix . 'adhar_no');
			    $objBuilder->AddSelectItem($strTableName, 'identification_mark', $strAliasPrefix . 'identification_mark');
			    $objBuilder->AddSelectItem($strTableName, 'fee_concession_applicable', $strAliasPrefix . 'fee_concession_applicable');
			    $objBuilder->AddSelectItem($strTableName, 'fee_concession_type', $strAliasPrefix . 'fee_concession_type');
			    $objBuilder->AddSelectItem($strTableName, 'annual_family_income', $strAliasPrefix . 'annual_family_income');
			    $objBuilder->AddSelectItem($strTableName, 'blood_group', $strAliasPrefix . 'blood_group');
			    $objBuilder->AddSelectItem($strTableName, 'mother_tongue', $strAliasPrefix . 'mother_tongue');
			    $objBuilder->AddSelectItem($strTableName, 'religion', $strAliasPrefix . 'religion');
			    $objBuilder->AddSelectItem($strTableName, 'caste', $strAliasPrefix . 'caste');
			    $objBuilder->AddSelectItem($strTableName, 'nationality', $strAliasPrefix . 'nationality');
			    $objBuilder->AddSelectItem($strTableName, 'course_of_addmission', $strAliasPrefix . 'course_of_addmission');
			    $objBuilder->AddSelectItem($strTableName, 'current_course', $strAliasPrefix . 'current_course');
			    $objBuilder->AddSelectItem($strTableName, 'branch_of_addmission', $strAliasPrefix . 'branch_of_addmission');
			    $objBuilder->AddSelectItem($strTableName, 'current_branch', $strAliasPrefix . 'current_branch');
			    $objBuilder->AddSelectItem($strTableName, 'admission_div', $strAliasPrefix . 'admission_div');
			    $objBuilder->AddSelectItem($strTableName, 'current_div', $strAliasPrefix . 'current_div');
			    $objBuilder->AddSelectItem($strTableName, 'handicaped_cat', $strAliasPrefix . 'handicaped_cat');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Profile from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Profile::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Profile
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the Profile object
			$objToReturn = new Profile();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idprofile';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdprofile = $objDbRow->GetColumn($strAliasName, 'Integer');
			$objToReturn->__intIdprofile = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'old_prn';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strOldPrn = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'application_no';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strApplicationNo = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'merit_no';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strMeritNo = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'merit_mark';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->fltMeritMark = $objDbRow->GetColumn($strAliasName, 'Float');
			$strAlias = $strAliasPrefix . 'addmission_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttAddmissionDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'leave_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttLeaveDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'marrtial_status';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMarrtialStatus = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'handicaped';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intHandicaped = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'adhar_status';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnAdharStatus = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'adhar_no';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strAdharNo = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'identification_mark';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strIdentificationMark = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'fee_concession_applicable';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnFeeConcessionApplicable = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'fee_concession_type';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strFeeConcessionType = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'annual_family_income';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strAnnualFamilyIncome = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'blood_group';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intBloodGroup = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'mother_tongue';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMotherTongue = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'religion';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intReligion = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'caste';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCaste = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'nationality';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intNationality = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'course_of_addmission';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCourseOfAddmission = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'current_course';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCurrentCourse = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'branch_of_addmission';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intBranchOfAddmission = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'current_branch';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCurrentBranch = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'admission_div';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intAdmissionDiv = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'current_div';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCurrentDiv = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'handicaped_cat';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intHandicapedCat = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idprofile != $objPreviousItem->Idprofile) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'profile__';

			// Check for IdprofileObject Early Binding
			$strAlias = $strAliasPrefix . 'idprofile__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objIdprofileObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'idprofile__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for MarrtialStatusObject Early Binding
			$strAlias = $strAliasPrefix . 'marrtial_status__idmarrial_status';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objMarrtialStatusObject = MarrialStatus::InstantiateDbRow($objDbRow, $strAliasPrefix . 'marrtial_status__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for BloodGroupObject Early Binding
			$strAlias = $strAliasPrefix . 'blood_group__idblood_group';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objBloodGroupObject = BloodGroup::InstantiateDbRow($objDbRow, $strAliasPrefix . 'blood_group__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for MotherTongueObject Early Binding
			$strAlias = $strAliasPrefix . 'mother_tongue__idmother_tongue';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objMotherTongueObject = MotherTongue::InstantiateDbRow($objDbRow, $strAliasPrefix . 'mother_tongue__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ReligionObject Early Binding
			$strAlias = $strAliasPrefix . 'religion__idreligion';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objReligionObject = Religion::InstantiateDbRow($objDbRow, $strAliasPrefix . 'religion__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CasteObject Early Binding
			$strAlias = $strAliasPrefix . 'caste__idcaste';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCasteObject = Caste::InstantiateDbRow($objDbRow, $strAliasPrefix . 'caste__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for NationalityObject Early Binding
			$strAlias = $strAliasPrefix . 'nationality__idnationality';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objNationalityObject = Nationality::InstantiateDbRow($objDbRow, $strAliasPrefix . 'nationality__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CourseOfAddmissionObject Early Binding
			$strAlias = $strAliasPrefix . 'course_of_addmission__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCourseOfAddmissionObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'course_of_addmission__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CurrentCourseObject Early Binding
			$strAlias = $strAliasPrefix . 'current_course__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCurrentCourseObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'current_course__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for BranchOfAddmissionObject Early Binding
			$strAlias = $strAliasPrefix . 'branch_of_addmission__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objBranchOfAddmissionObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'branch_of_addmission__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CurrentBranchObject Early Binding
			$strAlias = $strAliasPrefix . 'current_branch__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCurrentBranchObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'current_branch__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for AdmissionDivObject Early Binding
			$strAlias = $strAliasPrefix . 'admission_div__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objAdmissionDivObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'admission_div__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CurrentDivObject Early Binding
			$strAlias = $strAliasPrefix . 'current_div__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCurrentDivObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'current_div__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for HandicapedCatObject Early Binding
			$strAlias = $strAliasPrefix . 'handicaped_cat__idhandicaped_cat';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objHandicapedCatObject = HandicapedCat::InstantiateDbRow($objDbRow, $strAliasPrefix . 'handicaped_cat__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of Profiles from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Profile[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Profile::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Profile::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Profile object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Profile next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Profile::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Profile object,
		 * by Idprofile Index(es)
		 * @param integer $intIdprofile
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile
		*/
		public static function LoadByIdprofile($intIdprofile, $objOptionalClauses = null) {
			return Profile::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Profile()->Idprofile, $intIdprofile)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Profile objects,
		 * by MotherTongue Index(es)
		 * @param integer $intMotherTongue
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public static function LoadArrayByMotherTongue($intMotherTongue, $objOptionalClauses = null) {
			// Call Profile::QueryArray to perform the LoadArrayByMotherTongue query
			try {
				return Profile::QueryArray(
					QQ::Equal(QQN::Profile()->MotherTongue, $intMotherTongue),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Profiles
		 * by MotherTongue Index(es)
		 * @param integer $intMotherTongue
		 * @return int
		*/
		public static function CountByMotherTongue($intMotherTongue) {
			// Call Profile::QueryCount to perform the CountByMotherTongue query
			return Profile::QueryCount(
				QQ::Equal(QQN::Profile()->MotherTongue, $intMotherTongue)
			);
		}

		/**
		 * Load an array of Profile objects,
		 * by BloodGroup Index(es)
		 * @param integer $intBloodGroup
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public static function LoadArrayByBloodGroup($intBloodGroup, $objOptionalClauses = null) {
			// Call Profile::QueryArray to perform the LoadArrayByBloodGroup query
			try {
				return Profile::QueryArray(
					QQ::Equal(QQN::Profile()->BloodGroup, $intBloodGroup),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Profiles
		 * by BloodGroup Index(es)
		 * @param integer $intBloodGroup
		 * @return int
		*/
		public static function CountByBloodGroup($intBloodGroup) {
			// Call Profile::QueryCount to perform the CountByBloodGroup query
			return Profile::QueryCount(
				QQ::Equal(QQN::Profile()->BloodGroup, $intBloodGroup)
			);
		}

		/**
		 * Load an array of Profile objects,
		 * by Religion Index(es)
		 * @param integer $intReligion
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public static function LoadArrayByReligion($intReligion, $objOptionalClauses = null) {
			// Call Profile::QueryArray to perform the LoadArrayByReligion query
			try {
				return Profile::QueryArray(
					QQ::Equal(QQN::Profile()->Religion, $intReligion),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Profiles
		 * by Religion Index(es)
		 * @param integer $intReligion
		 * @return int
		*/
		public static function CountByReligion($intReligion) {
			// Call Profile::QueryCount to perform the CountByReligion query
			return Profile::QueryCount(
				QQ::Equal(QQN::Profile()->Religion, $intReligion)
			);
		}

		/**
		 * Load an array of Profile objects,
		 * by Nationality Index(es)
		 * @param integer $intNationality
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public static function LoadArrayByNationality($intNationality, $objOptionalClauses = null) {
			// Call Profile::QueryArray to perform the LoadArrayByNationality query
			try {
				return Profile::QueryArray(
					QQ::Equal(QQN::Profile()->Nationality, $intNationality),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Profiles
		 * by Nationality Index(es)
		 * @param integer $intNationality
		 * @return int
		*/
		public static function CountByNationality($intNationality) {
			// Call Profile::QueryCount to perform the CountByNationality query
			return Profile::QueryCount(
				QQ::Equal(QQN::Profile()->Nationality, $intNationality)
			);
		}

		/**
		 * Load an array of Profile objects,
		 * by Caste Index(es)
		 * @param integer $intCaste
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public static function LoadArrayByCaste($intCaste, $objOptionalClauses = null) {
			// Call Profile::QueryArray to perform the LoadArrayByCaste query
			try {
				return Profile::QueryArray(
					QQ::Equal(QQN::Profile()->Caste, $intCaste),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Profiles
		 * by Caste Index(es)
		 * @param integer $intCaste
		 * @return int
		*/
		public static function CountByCaste($intCaste) {
			// Call Profile::QueryCount to perform the CountByCaste query
			return Profile::QueryCount(
				QQ::Equal(QQN::Profile()->Caste, $intCaste)
			);
		}

		/**
		 * Load an array of Profile objects,
		 * by MarrtialStatus Index(es)
		 * @param integer $intMarrtialStatus
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public static function LoadArrayByMarrtialStatus($intMarrtialStatus, $objOptionalClauses = null) {
			// Call Profile::QueryArray to perform the LoadArrayByMarrtialStatus query
			try {
				return Profile::QueryArray(
					QQ::Equal(QQN::Profile()->MarrtialStatus, $intMarrtialStatus),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Profiles
		 * by MarrtialStatus Index(es)
		 * @param integer $intMarrtialStatus
		 * @return int
		*/
		public static function CountByMarrtialStatus($intMarrtialStatus) {
			// Call Profile::QueryCount to perform the CountByMarrtialStatus query
			return Profile::QueryCount(
				QQ::Equal(QQN::Profile()->MarrtialStatus, $intMarrtialStatus)
			);
		}

		/**
		 * Load an array of Profile objects,
		 * by CourseOfAddmission Index(es)
		 * @param integer $intCourseOfAddmission
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public static function LoadArrayByCourseOfAddmission($intCourseOfAddmission, $objOptionalClauses = null) {
			// Call Profile::QueryArray to perform the LoadArrayByCourseOfAddmission query
			try {
				return Profile::QueryArray(
					QQ::Equal(QQN::Profile()->CourseOfAddmission, $intCourseOfAddmission),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Profiles
		 * by CourseOfAddmission Index(es)
		 * @param integer $intCourseOfAddmission
		 * @return int
		*/
		public static function CountByCourseOfAddmission($intCourseOfAddmission) {
			// Call Profile::QueryCount to perform the CountByCourseOfAddmission query
			return Profile::QueryCount(
				QQ::Equal(QQN::Profile()->CourseOfAddmission, $intCourseOfAddmission)
			);
		}

		/**
		 * Load an array of Profile objects,
		 * by CurrentCourse Index(es)
		 * @param integer $intCurrentCourse
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public static function LoadArrayByCurrentCourse($intCurrentCourse, $objOptionalClauses = null) {
			// Call Profile::QueryArray to perform the LoadArrayByCurrentCourse query
			try {
				return Profile::QueryArray(
					QQ::Equal(QQN::Profile()->CurrentCourse, $intCurrentCourse),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Profiles
		 * by CurrentCourse Index(es)
		 * @param integer $intCurrentCourse
		 * @return int
		*/
		public static function CountByCurrentCourse($intCurrentCourse) {
			// Call Profile::QueryCount to perform the CountByCurrentCourse query
			return Profile::QueryCount(
				QQ::Equal(QQN::Profile()->CurrentCourse, $intCurrentCourse)
			);
		}

		/**
		 * Load an array of Profile objects,
		 * by BranchOfAddmission Index(es)
		 * @param integer $intBranchOfAddmission
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public static function LoadArrayByBranchOfAddmission($intBranchOfAddmission, $objOptionalClauses = null) {
			// Call Profile::QueryArray to perform the LoadArrayByBranchOfAddmission query
			try {
				return Profile::QueryArray(
					QQ::Equal(QQN::Profile()->BranchOfAddmission, $intBranchOfAddmission),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Profiles
		 * by BranchOfAddmission Index(es)
		 * @param integer $intBranchOfAddmission
		 * @return int
		*/
		public static function CountByBranchOfAddmission($intBranchOfAddmission) {
			// Call Profile::QueryCount to perform the CountByBranchOfAddmission query
			return Profile::QueryCount(
				QQ::Equal(QQN::Profile()->BranchOfAddmission, $intBranchOfAddmission)
			);
		}

		/**
		 * Load an array of Profile objects,
		 * by CurrentBranch Index(es)
		 * @param integer $intCurrentBranch
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public static function LoadArrayByCurrentBranch($intCurrentBranch, $objOptionalClauses = null) {
			// Call Profile::QueryArray to perform the LoadArrayByCurrentBranch query
			try {
				return Profile::QueryArray(
					QQ::Equal(QQN::Profile()->CurrentBranch, $intCurrentBranch),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Profiles
		 * by CurrentBranch Index(es)
		 * @param integer $intCurrentBranch
		 * @return int
		*/
		public static function CountByCurrentBranch($intCurrentBranch) {
			// Call Profile::QueryCount to perform the CountByCurrentBranch query
			return Profile::QueryCount(
				QQ::Equal(QQN::Profile()->CurrentBranch, $intCurrentBranch)
			);
		}

		/**
		 * Load an array of Profile objects,
		 * by AdmissionDiv Index(es)
		 * @param integer $intAdmissionDiv
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public static function LoadArrayByAdmissionDiv($intAdmissionDiv, $objOptionalClauses = null) {
			// Call Profile::QueryArray to perform the LoadArrayByAdmissionDiv query
			try {
				return Profile::QueryArray(
					QQ::Equal(QQN::Profile()->AdmissionDiv, $intAdmissionDiv),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Profiles
		 * by AdmissionDiv Index(es)
		 * @param integer $intAdmissionDiv
		 * @return int
		*/
		public static function CountByAdmissionDiv($intAdmissionDiv) {
			// Call Profile::QueryCount to perform the CountByAdmissionDiv query
			return Profile::QueryCount(
				QQ::Equal(QQN::Profile()->AdmissionDiv, $intAdmissionDiv)
			);
		}

		/**
		 * Load an array of Profile objects,
		 * by CurrentDiv Index(es)
		 * @param integer $intCurrentDiv
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public static function LoadArrayByCurrentDiv($intCurrentDiv, $objOptionalClauses = null) {
			// Call Profile::QueryArray to perform the LoadArrayByCurrentDiv query
			try {
				return Profile::QueryArray(
					QQ::Equal(QQN::Profile()->CurrentDiv, $intCurrentDiv),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Profiles
		 * by CurrentDiv Index(es)
		 * @param integer $intCurrentDiv
		 * @return int
		*/
		public static function CountByCurrentDiv($intCurrentDiv) {
			// Call Profile::QueryCount to perform the CountByCurrentDiv query
			return Profile::QueryCount(
				QQ::Equal(QQN::Profile()->CurrentDiv, $intCurrentDiv)
			);
		}

		/**
		 * Load an array of Profile objects,
		 * by HandicapedCat Index(es)
		 * @param integer $intHandicapedCat
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Profile[]
		*/
		public static function LoadArrayByHandicapedCat($intHandicapedCat, $objOptionalClauses = null) {
			// Call Profile::QueryArray to perform the LoadArrayByHandicapedCat query
			try {
				return Profile::QueryArray(
					QQ::Equal(QQN::Profile()->HandicapedCat, $intHandicapedCat),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Profiles
		 * by HandicapedCat Index(es)
		 * @param integer $intHandicapedCat
		 * @return int
		*/
		public static function CountByHandicapedCat($intHandicapedCat) {
			// Call Profile::QueryCount to perform the CountByHandicapedCat query
			return Profile::QueryCount(
				QQ::Equal(QQN::Profile()->HandicapedCat, $intHandicapedCat)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Profile
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return void
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Profile::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `profile` (
							`idprofile`,
							`old_prn`,
							`application_no`,
							`merit_no`,
							`merit_mark`,
							`addmission_date`,
							`leave_date`,
							`marrtial_status`,
							`handicaped`,
							`adhar_status`,
							`adhar_no`,
							`identification_mark`,
							`fee_concession_applicable`,
							`fee_concession_type`,
							`annual_family_income`,
							`blood_group`,
							`mother_tongue`,
							`religion`,
							`caste`,
							`nationality`,
							`course_of_addmission`,
							`current_course`,
							`branch_of_addmission`,
							`current_branch`,
							`admission_div`,
							`current_div`,
							`handicaped_cat`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intIdprofile) . ',
							' . $objDatabase->SqlVariable($this->strOldPrn) . ',
							' . $objDatabase->SqlVariable($this->strApplicationNo) . ',
							' . $objDatabase->SqlVariable($this->strMeritNo) . ',
							' . $objDatabase->SqlVariable($this->fltMeritMark) . ',
							' . $objDatabase->SqlVariable($this->dttAddmissionDate) . ',
							' . $objDatabase->SqlVariable($this->dttLeaveDate) . ',
							' . $objDatabase->SqlVariable($this->intMarrtialStatus) . ',
							' . $objDatabase->SqlVariable($this->intHandicaped) . ',
							' . $objDatabase->SqlVariable($this->blnAdharStatus) . ',
							' . $objDatabase->SqlVariable($this->strAdharNo) . ',
							' . $objDatabase->SqlVariable($this->strIdentificationMark) . ',
							' . $objDatabase->SqlVariable($this->blnFeeConcessionApplicable) . ',
							' . $objDatabase->SqlVariable($this->strFeeConcessionType) . ',
							' . $objDatabase->SqlVariable($this->strAnnualFamilyIncome) . ',
							' . $objDatabase->SqlVariable($this->intBloodGroup) . ',
							' . $objDatabase->SqlVariable($this->intMotherTongue) . ',
							' . $objDatabase->SqlVariable($this->intReligion) . ',
							' . $objDatabase->SqlVariable($this->intCaste) . ',
							' . $objDatabase->SqlVariable($this->intNationality) . ',
							' . $objDatabase->SqlVariable($this->intCourseOfAddmission) . ',
							' . $objDatabase->SqlVariable($this->intCurrentCourse) . ',
							' . $objDatabase->SqlVariable($this->intBranchOfAddmission) . ',
							' . $objDatabase->SqlVariable($this->intCurrentBranch) . ',
							' . $objDatabase->SqlVariable($this->intAdmissionDiv) . ',
							' . $objDatabase->SqlVariable($this->intCurrentDiv) . ',
							' . $objDatabase->SqlVariable($this->intHandicapedCat) . '
						)
					');


				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`profile`
						SET
							`idprofile` = ' . $objDatabase->SqlVariable($this->intIdprofile) . ',
							`old_prn` = ' . $objDatabase->SqlVariable($this->strOldPrn) . ',
							`application_no` = ' . $objDatabase->SqlVariable($this->strApplicationNo) . ',
							`merit_no` = ' . $objDatabase->SqlVariable($this->strMeritNo) . ',
							`merit_mark` = ' . $objDatabase->SqlVariable($this->fltMeritMark) . ',
							`addmission_date` = ' . $objDatabase->SqlVariable($this->dttAddmissionDate) . ',
							`leave_date` = ' . $objDatabase->SqlVariable($this->dttLeaveDate) . ',
							`marrtial_status` = ' . $objDatabase->SqlVariable($this->intMarrtialStatus) . ',
							`handicaped` = ' . $objDatabase->SqlVariable($this->intHandicaped) . ',
							`adhar_status` = ' . $objDatabase->SqlVariable($this->blnAdharStatus) . ',
							`adhar_no` = ' . $objDatabase->SqlVariable($this->strAdharNo) . ',
							`identification_mark` = ' . $objDatabase->SqlVariable($this->strIdentificationMark) . ',
							`fee_concession_applicable` = ' . $objDatabase->SqlVariable($this->blnFeeConcessionApplicable) . ',
							`fee_concession_type` = ' . $objDatabase->SqlVariable($this->strFeeConcessionType) . ',
							`annual_family_income` = ' . $objDatabase->SqlVariable($this->strAnnualFamilyIncome) . ',
							`blood_group` = ' . $objDatabase->SqlVariable($this->intBloodGroup) . ',
							`mother_tongue` = ' . $objDatabase->SqlVariable($this->intMotherTongue) . ',
							`religion` = ' . $objDatabase->SqlVariable($this->intReligion) . ',
							`caste` = ' . $objDatabase->SqlVariable($this->intCaste) . ',
							`nationality` = ' . $objDatabase->SqlVariable($this->intNationality) . ',
							`course_of_addmission` = ' . $objDatabase->SqlVariable($this->intCourseOfAddmission) . ',
							`current_course` = ' . $objDatabase->SqlVariable($this->intCurrentCourse) . ',
							`branch_of_addmission` = ' . $objDatabase->SqlVariable($this->intBranchOfAddmission) . ',
							`current_branch` = ' . $objDatabase->SqlVariable($this->intCurrentBranch) . ',
							`admission_div` = ' . $objDatabase->SqlVariable($this->intAdmissionDiv) . ',
							`current_div` = ' . $objDatabase->SqlVariable($this->intCurrentDiv) . ',
							`handicaped_cat` = ' . $objDatabase->SqlVariable($this->intHandicapedCat) . '
						WHERE
							`idprofile` = ' . $objDatabase->SqlVariable($this->__intIdprofile) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;
			$this->__intIdprofile = $this->intIdprofile;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Profile
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdprofile)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Profile with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Profile::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`profile`
				WHERE
					`idprofile` = ' . $objDatabase->SqlVariable($this->intIdprofile) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Profile ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Profile', $this->intIdprofile);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Profiles
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Profile::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`profile`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate profile table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Profile::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `profile`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Profile from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Profile object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Profile::Load($this->intIdprofile);

			// Update $this's local variables to match
			$this->Idprofile = $objReloaded->Idprofile;
			$this->__intIdprofile = $this->intIdprofile;
			$this->strOldPrn = $objReloaded->strOldPrn;
			$this->strApplicationNo = $objReloaded->strApplicationNo;
			$this->strMeritNo = $objReloaded->strMeritNo;
			$this->fltMeritMark = $objReloaded->fltMeritMark;
			$this->dttAddmissionDate = $objReloaded->dttAddmissionDate;
			$this->dttLeaveDate = $objReloaded->dttLeaveDate;
			$this->MarrtialStatus = $objReloaded->MarrtialStatus;
			$this->intHandicaped = $objReloaded->intHandicaped;
			$this->blnAdharStatus = $objReloaded->blnAdharStatus;
			$this->strAdharNo = $objReloaded->strAdharNo;
			$this->strIdentificationMark = $objReloaded->strIdentificationMark;
			$this->blnFeeConcessionApplicable = $objReloaded->blnFeeConcessionApplicable;
			$this->strFeeConcessionType = $objReloaded->strFeeConcessionType;
			$this->strAnnualFamilyIncome = $objReloaded->strAnnualFamilyIncome;
			$this->BloodGroup = $objReloaded->BloodGroup;
			$this->MotherTongue = $objReloaded->MotherTongue;
			$this->Religion = $objReloaded->Religion;
			$this->Caste = $objReloaded->Caste;
			$this->Nationality = $objReloaded->Nationality;
			$this->CourseOfAddmission = $objReloaded->CourseOfAddmission;
			$this->CurrentCourse = $objReloaded->CurrentCourse;
			$this->BranchOfAddmission = $objReloaded->BranchOfAddmission;
			$this->CurrentBranch = $objReloaded->CurrentBranch;
			$this->AdmissionDiv = $objReloaded->AdmissionDiv;
			$this->CurrentDiv = $objReloaded->CurrentDiv;
			$this->HandicapedCat = $objReloaded->HandicapedCat;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idprofile':
					/**
					 * Gets the value for intIdprofile (PK)
					 * @return integer
					 */
					return $this->intIdprofile;

				case 'OldPrn':
					/**
					 * Gets the value for strOldPrn 
					 * @return string
					 */
					return $this->strOldPrn;

				case 'ApplicationNo':
					/**
					 * Gets the value for strApplicationNo 
					 * @return string
					 */
					return $this->strApplicationNo;

				case 'MeritNo':
					/**
					 * Gets the value for strMeritNo 
					 * @return string
					 */
					return $this->strMeritNo;

				case 'MeritMark':
					/**
					 * Gets the value for fltMeritMark 
					 * @return double
					 */
					return $this->fltMeritMark;

				case 'AddmissionDate':
					/**
					 * Gets the value for dttAddmissionDate 
					 * @return QDateTime
					 */
					return $this->dttAddmissionDate;

				case 'LeaveDate':
					/**
					 * Gets the value for dttLeaveDate 
					 * @return QDateTime
					 */
					return $this->dttLeaveDate;

				case 'MarrtialStatus':
					/**
					 * Gets the value for intMarrtialStatus 
					 * @return integer
					 */
					return $this->intMarrtialStatus;

				case 'Handicaped':
					/**
					 * Gets the value for intHandicaped 
					 * @return integer
					 */
					return $this->intHandicaped;

				case 'AdharStatus':
					/**
					 * Gets the value for blnAdharStatus 
					 * @return boolean
					 */
					return $this->blnAdharStatus;

				case 'AdharNo':
					/**
					 * Gets the value for strAdharNo 
					 * @return string
					 */
					return $this->strAdharNo;

				case 'IdentificationMark':
					/**
					 * Gets the value for strIdentificationMark 
					 * @return string
					 */
					return $this->strIdentificationMark;

				case 'FeeConcessionApplicable':
					/**
					 * Gets the value for blnFeeConcessionApplicable 
					 * @return boolean
					 */
					return $this->blnFeeConcessionApplicable;

				case 'FeeConcessionType':
					/**
					 * Gets the value for strFeeConcessionType 
					 * @return string
					 */
					return $this->strFeeConcessionType;

				case 'AnnualFamilyIncome':
					/**
					 * Gets the value for strAnnualFamilyIncome 
					 * @return string
					 */
					return $this->strAnnualFamilyIncome;

				case 'BloodGroup':
					/**
					 * Gets the value for intBloodGroup 
					 * @return integer
					 */
					return $this->intBloodGroup;

				case 'MotherTongue':
					/**
					 * Gets the value for intMotherTongue 
					 * @return integer
					 */
					return $this->intMotherTongue;

				case 'Religion':
					/**
					 * Gets the value for intReligion 
					 * @return integer
					 */
					return $this->intReligion;

				case 'Caste':
					/**
					 * Gets the value for intCaste 
					 * @return integer
					 */
					return $this->intCaste;

				case 'Nationality':
					/**
					 * Gets the value for intNationality 
					 * @return integer
					 */
					return $this->intNationality;

				case 'CourseOfAddmission':
					/**
					 * Gets the value for intCourseOfAddmission 
					 * @return integer
					 */
					return $this->intCourseOfAddmission;

				case 'CurrentCourse':
					/**
					 * Gets the value for intCurrentCourse 
					 * @return integer
					 */
					return $this->intCurrentCourse;

				case 'BranchOfAddmission':
					/**
					 * Gets the value for intBranchOfAddmission 
					 * @return integer
					 */
					return $this->intBranchOfAddmission;

				case 'CurrentBranch':
					/**
					 * Gets the value for intCurrentBranch 
					 * @return integer
					 */
					return $this->intCurrentBranch;

				case 'AdmissionDiv':
					/**
					 * Gets the value for intAdmissionDiv 
					 * @return integer
					 */
					return $this->intAdmissionDiv;

				case 'CurrentDiv':
					/**
					 * Gets the value for intCurrentDiv 
					 * @return integer
					 */
					return $this->intCurrentDiv;

				case 'HandicapedCat':
					/**
					 * Gets the value for intHandicapedCat 
					 * @return integer
					 */
					return $this->intHandicapedCat;


				///////////////////
				// Member Objects
				///////////////////
				case 'IdprofileObject':
					/**
					 * Gets the value for the Ledger object referenced by intIdprofile (PK)
					 * @return Ledger
					 */
					try {
						if ((!$this->objIdprofileObject) && (!is_null($this->intIdprofile)))
							$this->objIdprofileObject = Ledger::Load($this->intIdprofile);
						return $this->objIdprofileObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'MarrtialStatusObject':
					/**
					 * Gets the value for the MarrialStatus object referenced by intMarrtialStatus 
					 * @return MarrialStatus
					 */
					try {
						if ((!$this->objMarrtialStatusObject) && (!is_null($this->intMarrtialStatus)))
							$this->objMarrtialStatusObject = MarrialStatus::Load($this->intMarrtialStatus);
						return $this->objMarrtialStatusObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'BloodGroupObject':
					/**
					 * Gets the value for the BloodGroup object referenced by intBloodGroup 
					 * @return BloodGroup
					 */
					try {
						if ((!$this->objBloodGroupObject) && (!is_null($this->intBloodGroup)))
							$this->objBloodGroupObject = BloodGroup::Load($this->intBloodGroup);
						return $this->objBloodGroupObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'MotherTongueObject':
					/**
					 * Gets the value for the MotherTongue object referenced by intMotherTongue 
					 * @return MotherTongue
					 */
					try {
						if ((!$this->objMotherTongueObject) && (!is_null($this->intMotherTongue)))
							$this->objMotherTongueObject = MotherTongue::Load($this->intMotherTongue);
						return $this->objMotherTongueObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ReligionObject':
					/**
					 * Gets the value for the Religion object referenced by intReligion 
					 * @return Religion
					 */
					try {
						if ((!$this->objReligionObject) && (!is_null($this->intReligion)))
							$this->objReligionObject = Religion::Load($this->intReligion);
						return $this->objReligionObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CasteObject':
					/**
					 * Gets the value for the Caste object referenced by intCaste 
					 * @return Caste
					 */
					try {
						if ((!$this->objCasteObject) && (!is_null($this->intCaste)))
							$this->objCasteObject = Caste::Load($this->intCaste);
						return $this->objCasteObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'NationalityObject':
					/**
					 * Gets the value for the Nationality object referenced by intNationality 
					 * @return Nationality
					 */
					try {
						if ((!$this->objNationalityObject) && (!is_null($this->intNationality)))
							$this->objNationalityObject = Nationality::Load($this->intNationality);
						return $this->objNationalityObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CourseOfAddmissionObject':
					/**
					 * Gets the value for the Role object referenced by intCourseOfAddmission 
					 * @return Role
					 */
					try {
						if ((!$this->objCourseOfAddmissionObject) && (!is_null($this->intCourseOfAddmission)))
							$this->objCourseOfAddmissionObject = Role::Load($this->intCourseOfAddmission);
						return $this->objCourseOfAddmissionObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CurrentCourseObject':
					/**
					 * Gets the value for the Role object referenced by intCurrentCourse 
					 * @return Role
					 */
					try {
						if ((!$this->objCurrentCourseObject) && (!is_null($this->intCurrentCourse)))
							$this->objCurrentCourseObject = Role::Load($this->intCurrentCourse);
						return $this->objCurrentCourseObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'BranchOfAddmissionObject':
					/**
					 * Gets the value for the Role object referenced by intBranchOfAddmission 
					 * @return Role
					 */
					try {
						if ((!$this->objBranchOfAddmissionObject) && (!is_null($this->intBranchOfAddmission)))
							$this->objBranchOfAddmissionObject = Role::Load($this->intBranchOfAddmission);
						return $this->objBranchOfAddmissionObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CurrentBranchObject':
					/**
					 * Gets the value for the Role object referenced by intCurrentBranch 
					 * @return Role
					 */
					try {
						if ((!$this->objCurrentBranchObject) && (!is_null($this->intCurrentBranch)))
							$this->objCurrentBranchObject = Role::Load($this->intCurrentBranch);
						return $this->objCurrentBranchObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AdmissionDivObject':
					/**
					 * Gets the value for the Role object referenced by intAdmissionDiv 
					 * @return Role
					 */
					try {
						if ((!$this->objAdmissionDivObject) && (!is_null($this->intAdmissionDiv)))
							$this->objAdmissionDivObject = Role::Load($this->intAdmissionDiv);
						return $this->objAdmissionDivObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CurrentDivObject':
					/**
					 * Gets the value for the Role object referenced by intCurrentDiv 
					 * @return Role
					 */
					try {
						if ((!$this->objCurrentDivObject) && (!is_null($this->intCurrentDiv)))
							$this->objCurrentDivObject = Role::Load($this->intCurrentDiv);
						return $this->objCurrentDivObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'HandicapedCatObject':
					/**
					 * Gets the value for the HandicapedCat object referenced by intHandicapedCat 
					 * @return HandicapedCat
					 */
					try {
						if ((!$this->objHandicapedCatObject) && (!is_null($this->intHandicapedCat)))
							$this->objHandicapedCatObject = HandicapedCat::Load($this->intHandicapedCat);
						return $this->objHandicapedCatObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idprofile':
					/**
					 * Sets the value for intIdprofile (PK)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objIdprofileObject = null;
						return ($this->intIdprofile = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'OldPrn':
					/**
					 * Sets the value for strOldPrn 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strOldPrn = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ApplicationNo':
					/**
					 * Sets the value for strApplicationNo 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strApplicationNo = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'MeritNo':
					/**
					 * Sets the value for strMeritNo 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strMeritNo = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'MeritMark':
					/**
					 * Sets the value for fltMeritMark 
					 * @param double $mixValue
					 * @return double
					 */
					try {
						return ($this->fltMeritMark = QType::Cast($mixValue, QType::Float));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AddmissionDate':
					/**
					 * Sets the value for dttAddmissionDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttAddmissionDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeaveDate':
					/**
					 * Sets the value for dttLeaveDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttLeaveDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'MarrtialStatus':
					/**
					 * Sets the value for intMarrtialStatus 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objMarrtialStatusObject = null;
						return ($this->intMarrtialStatus = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Handicaped':
					/**
					 * Sets the value for intHandicaped 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intHandicaped = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AdharStatus':
					/**
					 * Sets the value for blnAdharStatus 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnAdharStatus = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AdharNo':
					/**
					 * Sets the value for strAdharNo 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strAdharNo = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'IdentificationMark':
					/**
					 * Sets the value for strIdentificationMark 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strIdentificationMark = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'FeeConcessionApplicable':
					/**
					 * Sets the value for blnFeeConcessionApplicable 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnFeeConcessionApplicable = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'FeeConcessionType':
					/**
					 * Sets the value for strFeeConcessionType 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strFeeConcessionType = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AnnualFamilyIncome':
					/**
					 * Sets the value for strAnnualFamilyIncome 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strAnnualFamilyIncome = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'BloodGroup':
					/**
					 * Sets the value for intBloodGroup 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objBloodGroupObject = null;
						return ($this->intBloodGroup = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'MotherTongue':
					/**
					 * Sets the value for intMotherTongue 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objMotherTongueObject = null;
						return ($this->intMotherTongue = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Religion':
					/**
					 * Sets the value for intReligion 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objReligionObject = null;
						return ($this->intReligion = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Caste':
					/**
					 * Sets the value for intCaste 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCasteObject = null;
						return ($this->intCaste = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Nationality':
					/**
					 * Sets the value for intNationality 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objNationalityObject = null;
						return ($this->intNationality = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CourseOfAddmission':
					/**
					 * Sets the value for intCourseOfAddmission 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCourseOfAddmissionObject = null;
						return ($this->intCourseOfAddmission = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CurrentCourse':
					/**
					 * Sets the value for intCurrentCourse 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCurrentCourseObject = null;
						return ($this->intCurrentCourse = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'BranchOfAddmission':
					/**
					 * Sets the value for intBranchOfAddmission 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objBranchOfAddmissionObject = null;
						return ($this->intBranchOfAddmission = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CurrentBranch':
					/**
					 * Sets the value for intCurrentBranch 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCurrentBranchObject = null;
						return ($this->intCurrentBranch = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AdmissionDiv':
					/**
					 * Sets the value for intAdmissionDiv 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objAdmissionDivObject = null;
						return ($this->intAdmissionDiv = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CurrentDiv':
					/**
					 * Sets the value for intCurrentDiv 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCurrentDivObject = null;
						return ($this->intCurrentDiv = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'HandicapedCat':
					/**
					 * Sets the value for intHandicapedCat 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objHandicapedCatObject = null;
						return ($this->intHandicapedCat = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'IdprofileObject':
					/**
					 * Sets the value for the Ledger object referenced by intIdprofile (PK)
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intIdprofile = null;
						$this->objIdprofileObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved IdprofileObject for this Profile');

						// Update Local Member Variables
						$this->objIdprofileObject = $mixValue;
						$this->intIdprofile = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'MarrtialStatusObject':
					/**
					 * Sets the value for the MarrialStatus object referenced by intMarrtialStatus 
					 * @param MarrialStatus $mixValue
					 * @return MarrialStatus
					 */
					if (is_null($mixValue)) {
						$this->intMarrtialStatus = null;
						$this->objMarrtialStatusObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a MarrialStatus object
						try {
							$mixValue = QType::Cast($mixValue, 'MarrialStatus');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED MarrialStatus object
						if (is_null($mixValue->IdmarrialStatus))
							throw new QCallerException('Unable to set an unsaved MarrtialStatusObject for this Profile');

						// Update Local Member Variables
						$this->objMarrtialStatusObject = $mixValue;
						$this->intMarrtialStatus = $mixValue->IdmarrialStatus;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'BloodGroupObject':
					/**
					 * Sets the value for the BloodGroup object referenced by intBloodGroup 
					 * @param BloodGroup $mixValue
					 * @return BloodGroup
					 */
					if (is_null($mixValue)) {
						$this->intBloodGroup = null;
						$this->objBloodGroupObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a BloodGroup object
						try {
							$mixValue = QType::Cast($mixValue, 'BloodGroup');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED BloodGroup object
						if (is_null($mixValue->IdbloodGroup))
							throw new QCallerException('Unable to set an unsaved BloodGroupObject for this Profile');

						// Update Local Member Variables
						$this->objBloodGroupObject = $mixValue;
						$this->intBloodGroup = $mixValue->IdbloodGroup;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'MotherTongueObject':
					/**
					 * Sets the value for the MotherTongue object referenced by intMotherTongue 
					 * @param MotherTongue $mixValue
					 * @return MotherTongue
					 */
					if (is_null($mixValue)) {
						$this->intMotherTongue = null;
						$this->objMotherTongueObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a MotherTongue object
						try {
							$mixValue = QType::Cast($mixValue, 'MotherTongue');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED MotherTongue object
						if (is_null($mixValue->IdmotherTongue))
							throw new QCallerException('Unable to set an unsaved MotherTongueObject for this Profile');

						// Update Local Member Variables
						$this->objMotherTongueObject = $mixValue;
						$this->intMotherTongue = $mixValue->IdmotherTongue;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ReligionObject':
					/**
					 * Sets the value for the Religion object referenced by intReligion 
					 * @param Religion $mixValue
					 * @return Religion
					 */
					if (is_null($mixValue)) {
						$this->intReligion = null;
						$this->objReligionObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Religion object
						try {
							$mixValue = QType::Cast($mixValue, 'Religion');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Religion object
						if (is_null($mixValue->Idreligion))
							throw new QCallerException('Unable to set an unsaved ReligionObject for this Profile');

						// Update Local Member Variables
						$this->objReligionObject = $mixValue;
						$this->intReligion = $mixValue->Idreligion;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CasteObject':
					/**
					 * Sets the value for the Caste object referenced by intCaste 
					 * @param Caste $mixValue
					 * @return Caste
					 */
					if (is_null($mixValue)) {
						$this->intCaste = null;
						$this->objCasteObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Caste object
						try {
							$mixValue = QType::Cast($mixValue, 'Caste');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Caste object
						if (is_null($mixValue->Idcaste))
							throw new QCallerException('Unable to set an unsaved CasteObject for this Profile');

						// Update Local Member Variables
						$this->objCasteObject = $mixValue;
						$this->intCaste = $mixValue->Idcaste;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'NationalityObject':
					/**
					 * Sets the value for the Nationality object referenced by intNationality 
					 * @param Nationality $mixValue
					 * @return Nationality
					 */
					if (is_null($mixValue)) {
						$this->intNationality = null;
						$this->objNationalityObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Nationality object
						try {
							$mixValue = QType::Cast($mixValue, 'Nationality');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Nationality object
						if (is_null($mixValue->Idnationality))
							throw new QCallerException('Unable to set an unsaved NationalityObject for this Profile');

						// Update Local Member Variables
						$this->objNationalityObject = $mixValue;
						$this->intNationality = $mixValue->Idnationality;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CourseOfAddmissionObject':
					/**
					 * Sets the value for the Role object referenced by intCourseOfAddmission 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intCourseOfAddmission = null;
						$this->objCourseOfAddmissionObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved CourseOfAddmissionObject for this Profile');

						// Update Local Member Variables
						$this->objCourseOfAddmissionObject = $mixValue;
						$this->intCourseOfAddmission = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CurrentCourseObject':
					/**
					 * Sets the value for the Role object referenced by intCurrentCourse 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intCurrentCourse = null;
						$this->objCurrentCourseObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved CurrentCourseObject for this Profile');

						// Update Local Member Variables
						$this->objCurrentCourseObject = $mixValue;
						$this->intCurrentCourse = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'BranchOfAddmissionObject':
					/**
					 * Sets the value for the Role object referenced by intBranchOfAddmission 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intBranchOfAddmission = null;
						$this->objBranchOfAddmissionObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved BranchOfAddmissionObject for this Profile');

						// Update Local Member Variables
						$this->objBranchOfAddmissionObject = $mixValue;
						$this->intBranchOfAddmission = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CurrentBranchObject':
					/**
					 * Sets the value for the Role object referenced by intCurrentBranch 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intCurrentBranch = null;
						$this->objCurrentBranchObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved CurrentBranchObject for this Profile');

						// Update Local Member Variables
						$this->objCurrentBranchObject = $mixValue;
						$this->intCurrentBranch = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'AdmissionDivObject':
					/**
					 * Sets the value for the Role object referenced by intAdmissionDiv 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intAdmissionDiv = null;
						$this->objAdmissionDivObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved AdmissionDivObject for this Profile');

						// Update Local Member Variables
						$this->objAdmissionDivObject = $mixValue;
						$this->intAdmissionDiv = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CurrentDivObject':
					/**
					 * Sets the value for the Role object referenced by intCurrentDiv 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intCurrentDiv = null;
						$this->objCurrentDivObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved CurrentDivObject for this Profile');

						// Update Local Member Variables
						$this->objCurrentDivObject = $mixValue;
						$this->intCurrentDiv = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'HandicapedCatObject':
					/**
					 * Sets the value for the HandicapedCat object referenced by intHandicapedCat 
					 * @param HandicapedCat $mixValue
					 * @return HandicapedCat
					 */
					if (is_null($mixValue)) {
						$this->intHandicapedCat = null;
						$this->objHandicapedCatObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a HandicapedCat object
						try {
							$mixValue = QType::Cast($mixValue, 'HandicapedCat');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED HandicapedCat object
						if (is_null($mixValue->IdhandicapedCat))
							throw new QCallerException('Unable to set an unsaved HandicapedCatObject for this Profile');

						// Update Local Member Variables
						$this->objHandicapedCatObject = $mixValue;
						$this->intHandicapedCat = $mixValue->IdhandicapedCat;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "profile";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Profile::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Profile"><sequence>';
			$strToReturn .= '<element name="IdprofileObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="OldPrn" type="xsd:string"/>';
			$strToReturn .= '<element name="ApplicationNo" type="xsd:string"/>';
			$strToReturn .= '<element name="MeritNo" type="xsd:string"/>';
			$strToReturn .= '<element name="MeritMark" type="xsd:float"/>';
			$strToReturn .= '<element name="AddmissionDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="LeaveDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="MarrtialStatusObject" type="xsd1:MarrialStatus"/>';
			$strToReturn .= '<element name="Handicaped" type="xsd:int"/>';
			$strToReturn .= '<element name="AdharStatus" type="xsd:boolean"/>';
			$strToReturn .= '<element name="AdharNo" type="xsd:string"/>';
			$strToReturn .= '<element name="IdentificationMark" type="xsd:string"/>';
			$strToReturn .= '<element name="FeeConcessionApplicable" type="xsd:boolean"/>';
			$strToReturn .= '<element name="FeeConcessionType" type="xsd:string"/>';
			$strToReturn .= '<element name="AnnualFamilyIncome" type="xsd:string"/>';
			$strToReturn .= '<element name="BloodGroupObject" type="xsd1:BloodGroup"/>';
			$strToReturn .= '<element name="MotherTongueObject" type="xsd1:MotherTongue"/>';
			$strToReturn .= '<element name="ReligionObject" type="xsd1:Religion"/>';
			$strToReturn .= '<element name="CasteObject" type="xsd1:Caste"/>';
			$strToReturn .= '<element name="NationalityObject" type="xsd1:Nationality"/>';
			$strToReturn .= '<element name="CourseOfAddmissionObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="CurrentCourseObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="BranchOfAddmissionObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="CurrentBranchObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="AdmissionDivObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="CurrentDivObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="HandicapedCatObject" type="xsd1:HandicapedCat"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Profile', $strComplexTypeArray)) {
				$strComplexTypeArray['Profile'] = Profile::GetSoapComplexTypeXml();
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
				MarrialStatus::AlterSoapComplexTypeArray($strComplexTypeArray);
				BloodGroup::AlterSoapComplexTypeArray($strComplexTypeArray);
				MotherTongue::AlterSoapComplexTypeArray($strComplexTypeArray);
				Religion::AlterSoapComplexTypeArray($strComplexTypeArray);
				Caste::AlterSoapComplexTypeArray($strComplexTypeArray);
				Nationality::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				HandicapedCat::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Profile::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Profile();
			if ((property_exists($objSoapObject, 'IdprofileObject')) &&
				($objSoapObject->IdprofileObject))
				$objToReturn->IdprofileObject = Ledger::GetObjectFromSoapObject($objSoapObject->IdprofileObject);
			if (property_exists($objSoapObject, 'OldPrn'))
				$objToReturn->strOldPrn = $objSoapObject->OldPrn;
			if (property_exists($objSoapObject, 'ApplicationNo'))
				$objToReturn->strApplicationNo = $objSoapObject->ApplicationNo;
			if (property_exists($objSoapObject, 'MeritNo'))
				$objToReturn->strMeritNo = $objSoapObject->MeritNo;
			if (property_exists($objSoapObject, 'MeritMark'))
				$objToReturn->fltMeritMark = $objSoapObject->MeritMark;
			if (property_exists($objSoapObject, 'AddmissionDate'))
				$objToReturn->dttAddmissionDate = new QDateTime($objSoapObject->AddmissionDate);
			if (property_exists($objSoapObject, 'LeaveDate'))
				$objToReturn->dttLeaveDate = new QDateTime($objSoapObject->LeaveDate);
			if ((property_exists($objSoapObject, 'MarrtialStatusObject')) &&
				($objSoapObject->MarrtialStatusObject))
				$objToReturn->MarrtialStatusObject = MarrialStatus::GetObjectFromSoapObject($objSoapObject->MarrtialStatusObject);
			if (property_exists($objSoapObject, 'Handicaped'))
				$objToReturn->intHandicaped = $objSoapObject->Handicaped;
			if (property_exists($objSoapObject, 'AdharStatus'))
				$objToReturn->blnAdharStatus = $objSoapObject->AdharStatus;
			if (property_exists($objSoapObject, 'AdharNo'))
				$objToReturn->strAdharNo = $objSoapObject->AdharNo;
			if (property_exists($objSoapObject, 'IdentificationMark'))
				$objToReturn->strIdentificationMark = $objSoapObject->IdentificationMark;
			if (property_exists($objSoapObject, 'FeeConcessionApplicable'))
				$objToReturn->blnFeeConcessionApplicable = $objSoapObject->FeeConcessionApplicable;
			if (property_exists($objSoapObject, 'FeeConcessionType'))
				$objToReturn->strFeeConcessionType = $objSoapObject->FeeConcessionType;
			if (property_exists($objSoapObject, 'AnnualFamilyIncome'))
				$objToReturn->strAnnualFamilyIncome = $objSoapObject->AnnualFamilyIncome;
			if ((property_exists($objSoapObject, 'BloodGroupObject')) &&
				($objSoapObject->BloodGroupObject))
				$objToReturn->BloodGroupObject = BloodGroup::GetObjectFromSoapObject($objSoapObject->BloodGroupObject);
			if ((property_exists($objSoapObject, 'MotherTongueObject')) &&
				($objSoapObject->MotherTongueObject))
				$objToReturn->MotherTongueObject = MotherTongue::GetObjectFromSoapObject($objSoapObject->MotherTongueObject);
			if ((property_exists($objSoapObject, 'ReligionObject')) &&
				($objSoapObject->ReligionObject))
				$objToReturn->ReligionObject = Religion::GetObjectFromSoapObject($objSoapObject->ReligionObject);
			if ((property_exists($objSoapObject, 'CasteObject')) &&
				($objSoapObject->CasteObject))
				$objToReturn->CasteObject = Caste::GetObjectFromSoapObject($objSoapObject->CasteObject);
			if ((property_exists($objSoapObject, 'NationalityObject')) &&
				($objSoapObject->NationalityObject))
				$objToReturn->NationalityObject = Nationality::GetObjectFromSoapObject($objSoapObject->NationalityObject);
			if ((property_exists($objSoapObject, 'CourseOfAddmissionObject')) &&
				($objSoapObject->CourseOfAddmissionObject))
				$objToReturn->CourseOfAddmissionObject = Role::GetObjectFromSoapObject($objSoapObject->CourseOfAddmissionObject);
			if ((property_exists($objSoapObject, 'CurrentCourseObject')) &&
				($objSoapObject->CurrentCourseObject))
				$objToReturn->CurrentCourseObject = Role::GetObjectFromSoapObject($objSoapObject->CurrentCourseObject);
			if ((property_exists($objSoapObject, 'BranchOfAddmissionObject')) &&
				($objSoapObject->BranchOfAddmissionObject))
				$objToReturn->BranchOfAddmissionObject = Role::GetObjectFromSoapObject($objSoapObject->BranchOfAddmissionObject);
			if ((property_exists($objSoapObject, 'CurrentBranchObject')) &&
				($objSoapObject->CurrentBranchObject))
				$objToReturn->CurrentBranchObject = Role::GetObjectFromSoapObject($objSoapObject->CurrentBranchObject);
			if ((property_exists($objSoapObject, 'AdmissionDivObject')) &&
				($objSoapObject->AdmissionDivObject))
				$objToReturn->AdmissionDivObject = Role::GetObjectFromSoapObject($objSoapObject->AdmissionDivObject);
			if ((property_exists($objSoapObject, 'CurrentDivObject')) &&
				($objSoapObject->CurrentDivObject))
				$objToReturn->CurrentDivObject = Role::GetObjectFromSoapObject($objSoapObject->CurrentDivObject);
			if ((property_exists($objSoapObject, 'HandicapedCatObject')) &&
				($objSoapObject->HandicapedCatObject))
				$objToReturn->HandicapedCatObject = HandicapedCat::GetObjectFromSoapObject($objSoapObject->HandicapedCatObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Profile::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objIdprofileObject)
				$objObject->objIdprofileObject = Ledger::GetSoapObjectFromObject($objObject->objIdprofileObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intIdprofile = null;
			if ($objObject->dttAddmissionDate)
				$objObject->dttAddmissionDate = $objObject->dttAddmissionDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttLeaveDate)
				$objObject->dttLeaveDate = $objObject->dttLeaveDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objMarrtialStatusObject)
				$objObject->objMarrtialStatusObject = MarrialStatus::GetSoapObjectFromObject($objObject->objMarrtialStatusObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intMarrtialStatus = null;
			if ($objObject->objBloodGroupObject)
				$objObject->objBloodGroupObject = BloodGroup::GetSoapObjectFromObject($objObject->objBloodGroupObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intBloodGroup = null;
			if ($objObject->objMotherTongueObject)
				$objObject->objMotherTongueObject = MotherTongue::GetSoapObjectFromObject($objObject->objMotherTongueObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intMotherTongue = null;
			if ($objObject->objReligionObject)
				$objObject->objReligionObject = Religion::GetSoapObjectFromObject($objObject->objReligionObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intReligion = null;
			if ($objObject->objCasteObject)
				$objObject->objCasteObject = Caste::GetSoapObjectFromObject($objObject->objCasteObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCaste = null;
			if ($objObject->objNationalityObject)
				$objObject->objNationalityObject = Nationality::GetSoapObjectFromObject($objObject->objNationalityObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intNationality = null;
			if ($objObject->objCourseOfAddmissionObject)
				$objObject->objCourseOfAddmissionObject = Role::GetSoapObjectFromObject($objObject->objCourseOfAddmissionObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCourseOfAddmission = null;
			if ($objObject->objCurrentCourseObject)
				$objObject->objCurrentCourseObject = Role::GetSoapObjectFromObject($objObject->objCurrentCourseObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCurrentCourse = null;
			if ($objObject->objBranchOfAddmissionObject)
				$objObject->objBranchOfAddmissionObject = Role::GetSoapObjectFromObject($objObject->objBranchOfAddmissionObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intBranchOfAddmission = null;
			if ($objObject->objCurrentBranchObject)
				$objObject->objCurrentBranchObject = Role::GetSoapObjectFromObject($objObject->objCurrentBranchObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCurrentBranch = null;
			if ($objObject->objAdmissionDivObject)
				$objObject->objAdmissionDivObject = Role::GetSoapObjectFromObject($objObject->objAdmissionDivObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intAdmissionDiv = null;
			if ($objObject->objCurrentDivObject)
				$objObject->objCurrentDivObject = Role::GetSoapObjectFromObject($objObject->objCurrentDivObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCurrentDiv = null;
			if ($objObject->objHandicapedCatObject)
				$objObject->objHandicapedCatObject = HandicapedCat::GetSoapObjectFromObject($objObject->objHandicapedCatObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intHandicapedCat = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idprofile'] = $this->intIdprofile;
			$iArray['OldPrn'] = $this->strOldPrn;
			$iArray['ApplicationNo'] = $this->strApplicationNo;
			$iArray['MeritNo'] = $this->strMeritNo;
			$iArray['MeritMark'] = $this->fltMeritMark;
			$iArray['AddmissionDate'] = $this->dttAddmissionDate;
			$iArray['LeaveDate'] = $this->dttLeaveDate;
			$iArray['MarrtialStatus'] = $this->intMarrtialStatus;
			$iArray['Handicaped'] = $this->intHandicaped;
			$iArray['AdharStatus'] = $this->blnAdharStatus;
			$iArray['AdharNo'] = $this->strAdharNo;
			$iArray['IdentificationMark'] = $this->strIdentificationMark;
			$iArray['FeeConcessionApplicable'] = $this->blnFeeConcessionApplicable;
			$iArray['FeeConcessionType'] = $this->strFeeConcessionType;
			$iArray['AnnualFamilyIncome'] = $this->strAnnualFamilyIncome;
			$iArray['BloodGroup'] = $this->intBloodGroup;
			$iArray['MotherTongue'] = $this->intMotherTongue;
			$iArray['Religion'] = $this->intReligion;
			$iArray['Caste'] = $this->intCaste;
			$iArray['Nationality'] = $this->intNationality;
			$iArray['CourseOfAddmission'] = $this->intCourseOfAddmission;
			$iArray['CurrentCourse'] = $this->intCurrentCourse;
			$iArray['BranchOfAddmission'] = $this->intBranchOfAddmission;
			$iArray['CurrentBranch'] = $this->intCurrentBranch;
			$iArray['AdmissionDiv'] = $this->intAdmissionDiv;
			$iArray['CurrentDiv'] = $this->intCurrentDiv;
			$iArray['HandicapedCat'] = $this->intHandicapedCat;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdprofile ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idprofile
     * @property-read QQNodeLedger $IdprofileObject
     * @property-read QQNode $OldPrn
     * @property-read QQNode $ApplicationNo
     * @property-read QQNode $MeritNo
     * @property-read QQNode $MeritMark
     * @property-read QQNode $AddmissionDate
     * @property-read QQNode $LeaveDate
     * @property-read QQNode $MarrtialStatus
     * @property-read QQNodeMarrialStatus $MarrtialStatusObject
     * @property-read QQNode $Handicaped
     * @property-read QQNode $AdharStatus
     * @property-read QQNode $AdharNo
     * @property-read QQNode $IdentificationMark
     * @property-read QQNode $FeeConcessionApplicable
     * @property-read QQNode $FeeConcessionType
     * @property-read QQNode $AnnualFamilyIncome
     * @property-read QQNode $BloodGroup
     * @property-read QQNodeBloodGroup $BloodGroupObject
     * @property-read QQNode $MotherTongue
     * @property-read QQNodeMotherTongue $MotherTongueObject
     * @property-read QQNode $Religion
     * @property-read QQNodeReligion $ReligionObject
     * @property-read QQNode $Caste
     * @property-read QQNodeCaste $CasteObject
     * @property-read QQNode $Nationality
     * @property-read QQNodeNationality $NationalityObject
     * @property-read QQNode $CourseOfAddmission
     * @property-read QQNodeRole $CourseOfAddmissionObject
     * @property-read QQNode $CurrentCourse
     * @property-read QQNodeRole $CurrentCourseObject
     * @property-read QQNode $BranchOfAddmission
     * @property-read QQNodeRole $BranchOfAddmissionObject
     * @property-read QQNode $CurrentBranch
     * @property-read QQNodeRole $CurrentBranchObject
     * @property-read QQNode $AdmissionDiv
     * @property-read QQNodeRole $AdmissionDivObject
     * @property-read QQNode $CurrentDiv
     * @property-read QQNodeRole $CurrentDivObject
     * @property-read QQNode $HandicapedCat
     * @property-read QQNodeHandicapedCat $HandicapedCatObject
     *
     *

     * @property-read QQNodeLedger $_PrimaryKeyNode
     **/
	class QQNodeProfile extends QQNode {
		protected $strTableName = 'profile';
		protected $strPrimaryKey = 'idprofile';
		protected $strClassName = 'Profile';
		public function __get($strName) {
			switch ($strName) {
				case 'Idprofile':
					return new QQNode('idprofile', 'Idprofile', 'Integer', $this);
				case 'IdprofileObject':
					return new QQNodeLedger('idprofile', 'IdprofileObject', 'Integer', $this);
				case 'OldPrn':
					return new QQNode('old_prn', 'OldPrn', 'VarChar', $this);
				case 'ApplicationNo':
					return new QQNode('application_no', 'ApplicationNo', 'VarChar', $this);
				case 'MeritNo':
					return new QQNode('merit_no', 'MeritNo', 'VarChar', $this);
				case 'MeritMark':
					return new QQNode('merit_mark', 'MeritMark', 'Float', $this);
				case 'AddmissionDate':
					return new QQNode('addmission_date', 'AddmissionDate', 'DateTime', $this);
				case 'LeaveDate':
					return new QQNode('leave_date', 'LeaveDate', 'DateTime', $this);
				case 'MarrtialStatus':
					return new QQNode('marrtial_status', 'MarrtialStatus', 'Integer', $this);
				case 'MarrtialStatusObject':
					return new QQNodeMarrialStatus('marrtial_status', 'MarrtialStatusObject', 'Integer', $this);
				case 'Handicaped':
					return new QQNode('handicaped', 'Handicaped', 'Integer', $this);
				case 'AdharStatus':
					return new QQNode('adhar_status', 'AdharStatus', 'Bit', $this);
				case 'AdharNo':
					return new QQNode('adhar_no', 'AdharNo', 'VarChar', $this);
				case 'IdentificationMark':
					return new QQNode('identification_mark', 'IdentificationMark', 'VarChar', $this);
				case 'FeeConcessionApplicable':
					return new QQNode('fee_concession_applicable', 'FeeConcessionApplicable', 'Bit', $this);
				case 'FeeConcessionType':
					return new QQNode('fee_concession_type', 'FeeConcessionType', 'VarChar', $this);
				case 'AnnualFamilyIncome':
					return new QQNode('annual_family_income', 'AnnualFamilyIncome', 'VarChar', $this);
				case 'BloodGroup':
					return new QQNode('blood_group', 'BloodGroup', 'Integer', $this);
				case 'BloodGroupObject':
					return new QQNodeBloodGroup('blood_group', 'BloodGroupObject', 'Integer', $this);
				case 'MotherTongue':
					return new QQNode('mother_tongue', 'MotherTongue', 'Integer', $this);
				case 'MotherTongueObject':
					return new QQNodeMotherTongue('mother_tongue', 'MotherTongueObject', 'Integer', $this);
				case 'Religion':
					return new QQNode('religion', 'Religion', 'Integer', $this);
				case 'ReligionObject':
					return new QQNodeReligion('religion', 'ReligionObject', 'Integer', $this);
				case 'Caste':
					return new QQNode('caste', 'Caste', 'Integer', $this);
				case 'CasteObject':
					return new QQNodeCaste('caste', 'CasteObject', 'Integer', $this);
				case 'Nationality':
					return new QQNode('nationality', 'Nationality', 'Integer', $this);
				case 'NationalityObject':
					return new QQNodeNationality('nationality', 'NationalityObject', 'Integer', $this);
				case 'CourseOfAddmission':
					return new QQNode('course_of_addmission', 'CourseOfAddmission', 'Integer', $this);
				case 'CourseOfAddmissionObject':
					return new QQNodeRole('course_of_addmission', 'CourseOfAddmissionObject', 'Integer', $this);
				case 'CurrentCourse':
					return new QQNode('current_course', 'CurrentCourse', 'Integer', $this);
				case 'CurrentCourseObject':
					return new QQNodeRole('current_course', 'CurrentCourseObject', 'Integer', $this);
				case 'BranchOfAddmission':
					return new QQNode('branch_of_addmission', 'BranchOfAddmission', 'Integer', $this);
				case 'BranchOfAddmissionObject':
					return new QQNodeRole('branch_of_addmission', 'BranchOfAddmissionObject', 'Integer', $this);
				case 'CurrentBranch':
					return new QQNode('current_branch', 'CurrentBranch', 'Integer', $this);
				case 'CurrentBranchObject':
					return new QQNodeRole('current_branch', 'CurrentBranchObject', 'Integer', $this);
				case 'AdmissionDiv':
					return new QQNode('admission_div', 'AdmissionDiv', 'Integer', $this);
				case 'AdmissionDivObject':
					return new QQNodeRole('admission_div', 'AdmissionDivObject', 'Integer', $this);
				case 'CurrentDiv':
					return new QQNode('current_div', 'CurrentDiv', 'Integer', $this);
				case 'CurrentDivObject':
					return new QQNodeRole('current_div', 'CurrentDivObject', 'Integer', $this);
				case 'HandicapedCat':
					return new QQNode('handicaped_cat', 'HandicapedCat', 'Integer', $this);
				case 'HandicapedCatObject':
					return new QQNodeHandicapedCat('handicaped_cat', 'HandicapedCatObject', 'Integer', $this);

				case '_PrimaryKeyNode':
					return new QQNodeLedger('idprofile', 'Idprofile', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idprofile
     * @property-read QQNodeLedger $IdprofileObject
     * @property-read QQNode $OldPrn
     * @property-read QQNode $ApplicationNo
     * @property-read QQNode $MeritNo
     * @property-read QQNode $MeritMark
     * @property-read QQNode $AddmissionDate
     * @property-read QQNode $LeaveDate
     * @property-read QQNode $MarrtialStatus
     * @property-read QQNodeMarrialStatus $MarrtialStatusObject
     * @property-read QQNode $Handicaped
     * @property-read QQNode $AdharStatus
     * @property-read QQNode $AdharNo
     * @property-read QQNode $IdentificationMark
     * @property-read QQNode $FeeConcessionApplicable
     * @property-read QQNode $FeeConcessionType
     * @property-read QQNode $AnnualFamilyIncome
     * @property-read QQNode $BloodGroup
     * @property-read QQNodeBloodGroup $BloodGroupObject
     * @property-read QQNode $MotherTongue
     * @property-read QQNodeMotherTongue $MotherTongueObject
     * @property-read QQNode $Religion
     * @property-read QQNodeReligion $ReligionObject
     * @property-read QQNode $Caste
     * @property-read QQNodeCaste $CasteObject
     * @property-read QQNode $Nationality
     * @property-read QQNodeNationality $NationalityObject
     * @property-read QQNode $CourseOfAddmission
     * @property-read QQNodeRole $CourseOfAddmissionObject
     * @property-read QQNode $CurrentCourse
     * @property-read QQNodeRole $CurrentCourseObject
     * @property-read QQNode $BranchOfAddmission
     * @property-read QQNodeRole $BranchOfAddmissionObject
     * @property-read QQNode $CurrentBranch
     * @property-read QQNodeRole $CurrentBranchObject
     * @property-read QQNode $AdmissionDiv
     * @property-read QQNodeRole $AdmissionDivObject
     * @property-read QQNode $CurrentDiv
     * @property-read QQNodeRole $CurrentDivObject
     * @property-read QQNode $HandicapedCat
     * @property-read QQNodeHandicapedCat $HandicapedCatObject
     *
     *

     * @property-read QQNodeLedger $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeProfile extends QQReverseReferenceNode {
		protected $strTableName = 'profile';
		protected $strPrimaryKey = 'idprofile';
		protected $strClassName = 'Profile';
		public function __get($strName) {
			switch ($strName) {
				case 'Idprofile':
					return new QQNode('idprofile', 'Idprofile', 'integer', $this);
				case 'IdprofileObject':
					return new QQNodeLedger('idprofile', 'IdprofileObject', 'integer', $this);
				case 'OldPrn':
					return new QQNode('old_prn', 'OldPrn', 'string', $this);
				case 'ApplicationNo':
					return new QQNode('application_no', 'ApplicationNo', 'string', $this);
				case 'MeritNo':
					return new QQNode('merit_no', 'MeritNo', 'string', $this);
				case 'MeritMark':
					return new QQNode('merit_mark', 'MeritMark', 'double', $this);
				case 'AddmissionDate':
					return new QQNode('addmission_date', 'AddmissionDate', 'QDateTime', $this);
				case 'LeaveDate':
					return new QQNode('leave_date', 'LeaveDate', 'QDateTime', $this);
				case 'MarrtialStatus':
					return new QQNode('marrtial_status', 'MarrtialStatus', 'integer', $this);
				case 'MarrtialStatusObject':
					return new QQNodeMarrialStatus('marrtial_status', 'MarrtialStatusObject', 'integer', $this);
				case 'Handicaped':
					return new QQNode('handicaped', 'Handicaped', 'integer', $this);
				case 'AdharStatus':
					return new QQNode('adhar_status', 'AdharStatus', 'boolean', $this);
				case 'AdharNo':
					return new QQNode('adhar_no', 'AdharNo', 'string', $this);
				case 'IdentificationMark':
					return new QQNode('identification_mark', 'IdentificationMark', 'string', $this);
				case 'FeeConcessionApplicable':
					return new QQNode('fee_concession_applicable', 'FeeConcessionApplicable', 'boolean', $this);
				case 'FeeConcessionType':
					return new QQNode('fee_concession_type', 'FeeConcessionType', 'string', $this);
				case 'AnnualFamilyIncome':
					return new QQNode('annual_family_income', 'AnnualFamilyIncome', 'string', $this);
				case 'BloodGroup':
					return new QQNode('blood_group', 'BloodGroup', 'integer', $this);
				case 'BloodGroupObject':
					return new QQNodeBloodGroup('blood_group', 'BloodGroupObject', 'integer', $this);
				case 'MotherTongue':
					return new QQNode('mother_tongue', 'MotherTongue', 'integer', $this);
				case 'MotherTongueObject':
					return new QQNodeMotherTongue('mother_tongue', 'MotherTongueObject', 'integer', $this);
				case 'Religion':
					return new QQNode('religion', 'Religion', 'integer', $this);
				case 'ReligionObject':
					return new QQNodeReligion('religion', 'ReligionObject', 'integer', $this);
				case 'Caste':
					return new QQNode('caste', 'Caste', 'integer', $this);
				case 'CasteObject':
					return new QQNodeCaste('caste', 'CasteObject', 'integer', $this);
				case 'Nationality':
					return new QQNode('nationality', 'Nationality', 'integer', $this);
				case 'NationalityObject':
					return new QQNodeNationality('nationality', 'NationalityObject', 'integer', $this);
				case 'CourseOfAddmission':
					return new QQNode('course_of_addmission', 'CourseOfAddmission', 'integer', $this);
				case 'CourseOfAddmissionObject':
					return new QQNodeRole('course_of_addmission', 'CourseOfAddmissionObject', 'integer', $this);
				case 'CurrentCourse':
					return new QQNode('current_course', 'CurrentCourse', 'integer', $this);
				case 'CurrentCourseObject':
					return new QQNodeRole('current_course', 'CurrentCourseObject', 'integer', $this);
				case 'BranchOfAddmission':
					return new QQNode('branch_of_addmission', 'BranchOfAddmission', 'integer', $this);
				case 'BranchOfAddmissionObject':
					return new QQNodeRole('branch_of_addmission', 'BranchOfAddmissionObject', 'integer', $this);
				case 'CurrentBranch':
					return new QQNode('current_branch', 'CurrentBranch', 'integer', $this);
				case 'CurrentBranchObject':
					return new QQNodeRole('current_branch', 'CurrentBranchObject', 'integer', $this);
				case 'AdmissionDiv':
					return new QQNode('admission_div', 'AdmissionDiv', 'integer', $this);
				case 'AdmissionDivObject':
					return new QQNodeRole('admission_div', 'AdmissionDivObject', 'integer', $this);
				case 'CurrentDiv':
					return new QQNode('current_div', 'CurrentDiv', 'integer', $this);
				case 'CurrentDivObject':
					return new QQNodeRole('current_div', 'CurrentDivObject', 'integer', $this);
				case 'HandicapedCat':
					return new QQNode('handicaped_cat', 'HandicapedCat', 'integer', $this);
				case 'HandicapedCatObject':
					return new QQNodeHandicapedCat('handicaped_cat', 'HandicapedCatObject', 'integer', $this);

				case '_PrimaryKeyNode':
					return new QQNodeLedger('idprofile', 'Idprofile', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
