<?php
	/**
	 * The abstract SalarysheetApprovalGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the SalarysheetApproval subclass which
	 * extends this SalarysheetApprovalGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the SalarysheetApproval class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdsalarysheetApproval the value for intIdsalarysheetApproval (Read-Only PK)
	 * @property integer $Sequence the value for intSequence (Not Null)
	 * @property integer $Salarysheet the value for intSalarysheet (Not Null)
	 * @property integer $Role the value for intRole (Not Null)
	 * @property QDateTime $Date the value for dttDate 
	 * @property integer $Status the value for intStatus (Not Null)
	 * @property string $Note the value for strNote 
	 * @property integer $ApprovedBy the value for intApprovedBy 
	 * @property string $Ds the value for strDs 
	 * @property boolean $Edit the value for blnEdit 
	 * @property boolean $PreviousApproval the value for blnPreviousApproval 
	 * @property Salarysheet $SalarysheetObject the value for the Salarysheet object referenced by intSalarysheet (Not Null)
	 * @property Role $RoleObject the value for the Role object referenced by intRole (Not Null)
	 * @property Status $StatusObject the value for the Status object referenced by intStatus (Not Null)
	 * @property Login $ApprovedByObject the value for the Login object referenced by intApprovedBy 
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class SalarysheetApprovalGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column salarysheet_approval.idsalarysheet_approval
		 * @var integer intIdsalarysheetApproval
		 */
		protected $intIdsalarysheetApproval;
		const IdsalarysheetApprovalDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_approval.sequence
		 * @var integer intSequence
		 */
		protected $intSequence;
		const SequenceDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_approval.salarysheet
		 * @var integer intSalarysheet
		 */
		protected $intSalarysheet;
		const SalarysheetDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_approval.role
		 * @var integer intRole
		 */
		protected $intRole;
		const RoleDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_approval.date
		 * @var QDateTime dttDate
		 */
		protected $dttDate;
		const DateDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_approval.status
		 * @var integer intStatus
		 */
		protected $intStatus;
		const StatusDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_approval.note
		 * @var string strNote
		 */
		protected $strNote;
		const NoteDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_approval.approved_by
		 * @var integer intApprovedBy
		 */
		protected $intApprovedBy;
		const ApprovedByDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_approval.ds
		 * @var string strDs
		 */
		protected $strDs;
		const DsDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_approval.edit
		 * @var boolean blnEdit
		 */
		protected $blnEdit;
		const EditDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_approval.previous_approval
		 * @var boolean blnPreviousApproval
		 */
		protected $blnPreviousApproval;
		const PreviousApprovalDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salarysheet_approval.salarysheet.
		 *
		 * NOTE: Always use the SalarysheetObject property getter to correctly retrieve this Salarysheet object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Salarysheet objSalarysheetObject
		 */
		protected $objSalarysheetObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salarysheet_approval.role.
		 *
		 * NOTE: Always use the RoleObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objRoleObject
		 */
		protected $objRoleObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salarysheet_approval.status.
		 *
		 * NOTE: Always use the StatusObject property getter to correctly retrieve this Status object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Status objStatusObject
		 */
		protected $objStatusObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salarysheet_approval.approved_by.
		 *
		 * NOTE: Always use the ApprovedByObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objApprovedByObject
		 */
		protected $objApprovedByObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdsalarysheetApproval = SalarysheetApproval::IdsalarysheetApprovalDefault;
			$this->intSequence = SalarysheetApproval::SequenceDefault;
			$this->intSalarysheet = SalarysheetApproval::SalarysheetDefault;
			$this->intRole = SalarysheetApproval::RoleDefault;
			$this->dttDate = (SalarysheetApproval::DateDefault === null)?null:new QDateTime(SalarysheetApproval::DateDefault);
			$this->intStatus = SalarysheetApproval::StatusDefault;
			$this->strNote = SalarysheetApproval::NoteDefault;
			$this->intApprovedBy = SalarysheetApproval::ApprovedByDefault;
			$this->strDs = SalarysheetApproval::DsDefault;
			$this->blnEdit = SalarysheetApproval::EditDefault;
			$this->blnPreviousApproval = SalarysheetApproval::PreviousApprovalDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a SalarysheetApproval from PK Info
		 * @param integer $intIdsalarysheetApproval
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalarysheetApproval
		 */
		public static function Load($intIdsalarysheetApproval, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'SalarysheetApproval', $intIdsalarysheetApproval);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = SalarysheetApproval::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::SalarysheetApproval()->IdsalarysheetApproval, $intIdsalarysheetApproval)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all SalarysheetApprovals
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalarysheetApproval[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call SalarysheetApproval::QueryArray to perform the LoadAll query
			try {
				return SalarysheetApproval::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all SalarysheetApprovals
		 * @return int
		 */
		public static function CountAll() {
			// Call SalarysheetApproval::QueryCount to perform the CountAll query
			return SalarysheetApproval::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = SalarysheetApproval::GetDatabase();

			// Create/Build out the QueryBuilder object with SalarysheetApproval-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'salarysheet_approval');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				SalarysheetApproval::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('salarysheet_approval');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single SalarysheetApproval object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return SalarysheetApproval the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = SalarysheetApproval::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new SalarysheetApproval object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = SalarysheetApproval::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return SalarysheetApproval::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of SalarysheetApproval objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return SalarysheetApproval[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = SalarysheetApproval::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return SalarysheetApproval::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = SalarysheetApproval::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of SalarysheetApproval objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = SalarysheetApproval::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = SalarysheetApproval::GetDatabase();

			$strQuery = SalarysheetApproval::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/salarysheetapproval', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = SalarysheetApproval::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this SalarysheetApproval
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'salarysheet_approval';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idsalarysheet_approval', $strAliasPrefix . 'idsalarysheet_approval');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idsalarysheet_approval', $strAliasPrefix . 'idsalarysheet_approval');
			    $objBuilder->AddSelectItem($strTableName, 'sequence', $strAliasPrefix . 'sequence');
			    $objBuilder->AddSelectItem($strTableName, 'salarysheet', $strAliasPrefix . 'salarysheet');
			    $objBuilder->AddSelectItem($strTableName, 'role', $strAliasPrefix . 'role');
			    $objBuilder->AddSelectItem($strTableName, 'date', $strAliasPrefix . 'date');
			    $objBuilder->AddSelectItem($strTableName, 'status', $strAliasPrefix . 'status');
			    $objBuilder->AddSelectItem($strTableName, 'note', $strAliasPrefix . 'note');
			    $objBuilder->AddSelectItem($strTableName, 'approved_by', $strAliasPrefix . 'approved_by');
			    $objBuilder->AddSelectItem($strTableName, 'ds', $strAliasPrefix . 'ds');
			    $objBuilder->AddSelectItem($strTableName, 'edit', $strAliasPrefix . 'edit');
			    $objBuilder->AddSelectItem($strTableName, 'previous_approval', $strAliasPrefix . 'previous_approval');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a SalarysheetApproval from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this SalarysheetApproval::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return SalarysheetApproval
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the SalarysheetApproval object
			$objToReturn = new SalarysheetApproval();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idsalarysheet_approval';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdsalarysheetApproval = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'sequence';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSequence = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'salarysheet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSalarysheet = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'role';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intRole = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'status';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intStatus = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'note';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strNote = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'approved_by';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intApprovedBy = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'ds';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strDs = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'edit';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnEdit = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'previous_approval';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnPreviousApproval = $objDbRow->GetColumn($strAliasName, 'Bit');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdsalarysheetApproval != $objPreviousItem->IdsalarysheetApproval) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'salarysheet_approval__';

			// Check for SalarysheetObject Early Binding
			$strAlias = $strAliasPrefix . 'salarysheet__idsalarysheet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSalarysheetObject = Salarysheet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarysheet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for RoleObject Early Binding
			$strAlias = $strAliasPrefix . 'role__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objRoleObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'role__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for StatusObject Early Binding
			$strAlias = $strAliasPrefix . 'status__idstatus';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objStatusObject = Status::InstantiateDbRow($objDbRow, $strAliasPrefix . 'status__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ApprovedByObject Early Binding
			$strAlias = $strAliasPrefix . 'approved_by__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objApprovedByObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'approved_by__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of SalarysheetApprovals from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return SalarysheetApproval[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = SalarysheetApproval::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = SalarysheetApproval::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single SalarysheetApproval object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return SalarysheetApproval next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return SalarysheetApproval::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single SalarysheetApproval object,
		 * by IdsalarysheetApproval Index(es)
		 * @param integer $intIdsalarysheetApproval
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalarysheetApproval
		*/
		public static function LoadByIdsalarysheetApproval($intIdsalarysheetApproval, $objOptionalClauses = null) {
			return SalarysheetApproval::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::SalarysheetApproval()->IdsalarysheetApproval, $intIdsalarysheetApproval)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of SalarysheetApproval objects,
		 * by Salarysheet Index(es)
		 * @param integer $intSalarysheet
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalarysheetApproval[]
		*/
		public static function LoadArrayBySalarysheet($intSalarysheet, $objOptionalClauses = null) {
			// Call SalarysheetApproval::QueryArray to perform the LoadArrayBySalarysheet query
			try {
				return SalarysheetApproval::QueryArray(
					QQ::Equal(QQN::SalarysheetApproval()->Salarysheet, $intSalarysheet),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count SalarysheetApprovals
		 * by Salarysheet Index(es)
		 * @param integer $intSalarysheet
		 * @return int
		*/
		public static function CountBySalarysheet($intSalarysheet) {
			// Call SalarysheetApproval::QueryCount to perform the CountBySalarysheet query
			return SalarysheetApproval::QueryCount(
				QQ::Equal(QQN::SalarysheetApproval()->Salarysheet, $intSalarysheet)
			);
		}

		/**
		 * Load an array of SalarysheetApproval objects,
		 * by Role Index(es)
		 * @param integer $intRole
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalarysheetApproval[]
		*/
		public static function LoadArrayByRole($intRole, $objOptionalClauses = null) {
			// Call SalarysheetApproval::QueryArray to perform the LoadArrayByRole query
			try {
				return SalarysheetApproval::QueryArray(
					QQ::Equal(QQN::SalarysheetApproval()->Role, $intRole),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count SalarysheetApprovals
		 * by Role Index(es)
		 * @param integer $intRole
		 * @return int
		*/
		public static function CountByRole($intRole) {
			// Call SalarysheetApproval::QueryCount to perform the CountByRole query
			return SalarysheetApproval::QueryCount(
				QQ::Equal(QQN::SalarysheetApproval()->Role, $intRole)
			);
		}

		/**
		 * Load an array of SalarysheetApproval objects,
		 * by Status Index(es)
		 * @param integer $intStatus
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalarysheetApproval[]
		*/
		public static function LoadArrayByStatus($intStatus, $objOptionalClauses = null) {
			// Call SalarysheetApproval::QueryArray to perform the LoadArrayByStatus query
			try {
				return SalarysheetApproval::QueryArray(
					QQ::Equal(QQN::SalarysheetApproval()->Status, $intStatus),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count SalarysheetApprovals
		 * by Status Index(es)
		 * @param integer $intStatus
		 * @return int
		*/
		public static function CountByStatus($intStatus) {
			// Call SalarysheetApproval::QueryCount to perform the CountByStatus query
			return SalarysheetApproval::QueryCount(
				QQ::Equal(QQN::SalarysheetApproval()->Status, $intStatus)
			);
		}

		/**
		 * Load an array of SalarysheetApproval objects,
		 * by ApprovedBy Index(es)
		 * @param integer $intApprovedBy
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalarysheetApproval[]
		*/
		public static function LoadArrayByApprovedBy($intApprovedBy, $objOptionalClauses = null) {
			// Call SalarysheetApproval::QueryArray to perform the LoadArrayByApprovedBy query
			try {
				return SalarysheetApproval::QueryArray(
					QQ::Equal(QQN::SalarysheetApproval()->ApprovedBy, $intApprovedBy),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count SalarysheetApprovals
		 * by ApprovedBy Index(es)
		 * @param integer $intApprovedBy
		 * @return int
		*/
		public static function CountByApprovedBy($intApprovedBy) {
			// Call SalarysheetApproval::QueryCount to perform the CountByApprovedBy query
			return SalarysheetApproval::QueryCount(
				QQ::Equal(QQN::SalarysheetApproval()->ApprovedBy, $intApprovedBy)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this SalarysheetApproval
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = SalarysheetApproval::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `salarysheet_approval` (
							`sequence`,
							`salarysheet`,
							`role`,
							`date`,
							`status`,
							`note`,
							`approved_by`,
							`ds`,
							`edit`,
							`previous_approval`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intSequence) . ',
							' . $objDatabase->SqlVariable($this->intSalarysheet) . ',
							' . $objDatabase->SqlVariable($this->intRole) . ',
							' . $objDatabase->SqlVariable($this->dttDate) . ',
							' . $objDatabase->SqlVariable($this->intStatus) . ',
							' . $objDatabase->SqlVariable($this->strNote) . ',
							' . $objDatabase->SqlVariable($this->intApprovedBy) . ',
							' . $objDatabase->SqlVariable($this->strDs) . ',
							' . $objDatabase->SqlVariable($this->blnEdit) . ',
							' . $objDatabase->SqlVariable($this->blnPreviousApproval) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdsalarysheetApproval = $objDatabase->InsertId('salarysheet_approval', 'idsalarysheet_approval');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`salarysheet_approval`
						SET
							`sequence` = ' . $objDatabase->SqlVariable($this->intSequence) . ',
							`salarysheet` = ' . $objDatabase->SqlVariable($this->intSalarysheet) . ',
							`role` = ' . $objDatabase->SqlVariable($this->intRole) . ',
							`date` = ' . $objDatabase->SqlVariable($this->dttDate) . ',
							`status` = ' . $objDatabase->SqlVariable($this->intStatus) . ',
							`note` = ' . $objDatabase->SqlVariable($this->strNote) . ',
							`approved_by` = ' . $objDatabase->SqlVariable($this->intApprovedBy) . ',
							`ds` = ' . $objDatabase->SqlVariable($this->strDs) . ',
							`edit` = ' . $objDatabase->SqlVariable($this->blnEdit) . ',
							`previous_approval` = ' . $objDatabase->SqlVariable($this->blnPreviousApproval) . '
						WHERE
							`idsalarysheet_approval` = ' . $objDatabase->SqlVariable($this->intIdsalarysheetApproval) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this SalarysheetApproval
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdsalarysheetApproval)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this SalarysheetApproval with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = SalarysheetApproval::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salarysheet_approval`
				WHERE
					`idsalarysheet_approval` = ' . $objDatabase->SqlVariable($this->intIdsalarysheetApproval) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this SalarysheetApproval ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'SalarysheetApproval', $this->intIdsalarysheetApproval);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all SalarysheetApprovals
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = SalarysheetApproval::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salarysheet_approval`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate salarysheet_approval table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = SalarysheetApproval::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `salarysheet_approval`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this SalarysheetApproval from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved SalarysheetApproval object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = SalarysheetApproval::Load($this->intIdsalarysheetApproval);

			// Update $this's local variables to match
			$this->intSequence = $objReloaded->intSequence;
			$this->Salarysheet = $objReloaded->Salarysheet;
			$this->Role = $objReloaded->Role;
			$this->dttDate = $objReloaded->dttDate;
			$this->Status = $objReloaded->Status;
			$this->strNote = $objReloaded->strNote;
			$this->ApprovedBy = $objReloaded->ApprovedBy;
			$this->strDs = $objReloaded->strDs;
			$this->blnEdit = $objReloaded->blnEdit;
			$this->blnPreviousApproval = $objReloaded->blnPreviousApproval;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdsalarysheetApproval':
					/**
					 * Gets the value for intIdsalarysheetApproval (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdsalarysheetApproval;

				case 'Sequence':
					/**
					 * Gets the value for intSequence (Not Null)
					 * @return integer
					 */
					return $this->intSequence;

				case 'Salarysheet':
					/**
					 * Gets the value for intSalarysheet (Not Null)
					 * @return integer
					 */
					return $this->intSalarysheet;

				case 'Role':
					/**
					 * Gets the value for intRole (Not Null)
					 * @return integer
					 */
					return $this->intRole;

				case 'Date':
					/**
					 * Gets the value for dttDate 
					 * @return QDateTime
					 */
					return $this->dttDate;

				case 'Status':
					/**
					 * Gets the value for intStatus (Not Null)
					 * @return integer
					 */
					return $this->intStatus;

				case 'Note':
					/**
					 * Gets the value for strNote 
					 * @return string
					 */
					return $this->strNote;

				case 'ApprovedBy':
					/**
					 * Gets the value for intApprovedBy 
					 * @return integer
					 */
					return $this->intApprovedBy;

				case 'Ds':
					/**
					 * Gets the value for strDs 
					 * @return string
					 */
					return $this->strDs;

				case 'Edit':
					/**
					 * Gets the value for blnEdit 
					 * @return boolean
					 */
					return $this->blnEdit;

				case 'PreviousApproval':
					/**
					 * Gets the value for blnPreviousApproval 
					 * @return boolean
					 */
					return $this->blnPreviousApproval;


				///////////////////
				// Member Objects
				///////////////////
				case 'SalarysheetObject':
					/**
					 * Gets the value for the Salarysheet object referenced by intSalarysheet (Not Null)
					 * @return Salarysheet
					 */
					try {
						if ((!$this->objSalarysheetObject) && (!is_null($this->intSalarysheet)))
							$this->objSalarysheetObject = Salarysheet::Load($this->intSalarysheet);
						return $this->objSalarysheetObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RoleObject':
					/**
					 * Gets the value for the Role object referenced by intRole (Not Null)
					 * @return Role
					 */
					try {
						if ((!$this->objRoleObject) && (!is_null($this->intRole)))
							$this->objRoleObject = Role::Load($this->intRole);
						return $this->objRoleObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'StatusObject':
					/**
					 * Gets the value for the Status object referenced by intStatus (Not Null)
					 * @return Status
					 */
					try {
						if ((!$this->objStatusObject) && (!is_null($this->intStatus)))
							$this->objStatusObject = Status::Load($this->intStatus);
						return $this->objStatusObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ApprovedByObject':
					/**
					 * Gets the value for the Login object referenced by intApprovedBy 
					 * @return Login
					 */
					try {
						if ((!$this->objApprovedByObject) && (!is_null($this->intApprovedBy)))
							$this->objApprovedByObject = Login::Load($this->intApprovedBy);
						return $this->objApprovedByObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Sequence':
					/**
					 * Sets the value for intSequence (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intSequence = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Salarysheet':
					/**
					 * Sets the value for intSalarysheet (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSalarysheetObject = null;
						return ($this->intSalarysheet = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Role':
					/**
					 * Sets the value for intRole (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objRoleObject = null;
						return ($this->intRole = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Date':
					/**
					 * Sets the value for dttDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Status':
					/**
					 * Sets the value for intStatus (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objStatusObject = null;
						return ($this->intStatus = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Note':
					/**
					 * Sets the value for strNote 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strNote = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ApprovedBy':
					/**
					 * Sets the value for intApprovedBy 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objApprovedByObject = null;
						return ($this->intApprovedBy = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Ds':
					/**
					 * Sets the value for strDs 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strDs = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Edit':
					/**
					 * Sets the value for blnEdit 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnEdit = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'PreviousApproval':
					/**
					 * Sets the value for blnPreviousApproval 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnPreviousApproval = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'SalarysheetObject':
					/**
					 * Sets the value for the Salarysheet object referenced by intSalarysheet (Not Null)
					 * @param Salarysheet $mixValue
					 * @return Salarysheet
					 */
					if (is_null($mixValue)) {
						$this->intSalarysheet = null;
						$this->objSalarysheetObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Salarysheet object
						try {
							$mixValue = QType::Cast($mixValue, 'Salarysheet');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Salarysheet object
						if (is_null($mixValue->Idsalarysheet))
							throw new QCallerException('Unable to set an unsaved SalarysheetObject for this SalarysheetApproval');

						// Update Local Member Variables
						$this->objSalarysheetObject = $mixValue;
						$this->intSalarysheet = $mixValue->Idsalarysheet;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'RoleObject':
					/**
					 * Sets the value for the Role object referenced by intRole (Not Null)
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intRole = null;
						$this->objRoleObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved RoleObject for this SalarysheetApproval');

						// Update Local Member Variables
						$this->objRoleObject = $mixValue;
						$this->intRole = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'StatusObject':
					/**
					 * Sets the value for the Status object referenced by intStatus (Not Null)
					 * @param Status $mixValue
					 * @return Status
					 */
					if (is_null($mixValue)) {
						$this->intStatus = null;
						$this->objStatusObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Status object
						try {
							$mixValue = QType::Cast($mixValue, 'Status');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Status object
						if (is_null($mixValue->Idstatus))
							throw new QCallerException('Unable to set an unsaved StatusObject for this SalarysheetApproval');

						// Update Local Member Variables
						$this->objStatusObject = $mixValue;
						$this->intStatus = $mixValue->Idstatus;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ApprovedByObject':
					/**
					 * Sets the value for the Login object referenced by intApprovedBy 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intApprovedBy = null;
						$this->objApprovedByObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved ApprovedByObject for this SalarysheetApproval');

						// Update Local Member Variables
						$this->objApprovedByObject = $mixValue;
						$this->intApprovedBy = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "salarysheet_approval";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[SalarysheetApproval::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="SalarysheetApproval"><sequence>';
			$strToReturn .= '<element name="IdsalarysheetApproval" type="xsd:int"/>';
			$strToReturn .= '<element name="Sequence" type="xsd:int"/>';
			$strToReturn .= '<element name="SalarysheetObject" type="xsd1:Salarysheet"/>';
			$strToReturn .= '<element name="RoleObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="Date" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="StatusObject" type="xsd1:Status"/>';
			$strToReturn .= '<element name="Note" type="xsd:string"/>';
			$strToReturn .= '<element name="ApprovedByObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="Ds" type="xsd:string"/>';
			$strToReturn .= '<element name="Edit" type="xsd:boolean"/>';
			$strToReturn .= '<element name="PreviousApproval" type="xsd:boolean"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('SalarysheetApproval', $strComplexTypeArray)) {
				$strComplexTypeArray['SalarysheetApproval'] = SalarysheetApproval::GetSoapComplexTypeXml();
				Salarysheet::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				Status::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, SalarysheetApproval::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new SalarysheetApproval();
			if (property_exists($objSoapObject, 'IdsalarysheetApproval'))
				$objToReturn->intIdsalarysheetApproval = $objSoapObject->IdsalarysheetApproval;
			if (property_exists($objSoapObject, 'Sequence'))
				$objToReturn->intSequence = $objSoapObject->Sequence;
			if ((property_exists($objSoapObject, 'SalarysheetObject')) &&
				($objSoapObject->SalarysheetObject))
				$objToReturn->SalarysheetObject = Salarysheet::GetObjectFromSoapObject($objSoapObject->SalarysheetObject);
			if ((property_exists($objSoapObject, 'RoleObject')) &&
				($objSoapObject->RoleObject))
				$objToReturn->RoleObject = Role::GetObjectFromSoapObject($objSoapObject->RoleObject);
			if (property_exists($objSoapObject, 'Date'))
				$objToReturn->dttDate = new QDateTime($objSoapObject->Date);
			if ((property_exists($objSoapObject, 'StatusObject')) &&
				($objSoapObject->StatusObject))
				$objToReturn->StatusObject = Status::GetObjectFromSoapObject($objSoapObject->StatusObject);
			if (property_exists($objSoapObject, 'Note'))
				$objToReturn->strNote = $objSoapObject->Note;
			if ((property_exists($objSoapObject, 'ApprovedByObject')) &&
				($objSoapObject->ApprovedByObject))
				$objToReturn->ApprovedByObject = Login::GetObjectFromSoapObject($objSoapObject->ApprovedByObject);
			if (property_exists($objSoapObject, 'Ds'))
				$objToReturn->strDs = $objSoapObject->Ds;
			if (property_exists($objSoapObject, 'Edit'))
				$objToReturn->blnEdit = $objSoapObject->Edit;
			if (property_exists($objSoapObject, 'PreviousApproval'))
				$objToReturn->blnPreviousApproval = $objSoapObject->PreviousApproval;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, SalarysheetApproval::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objSalarysheetObject)
				$objObject->objSalarysheetObject = Salarysheet::GetSoapObjectFromObject($objObject->objSalarysheetObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSalarysheet = null;
			if ($objObject->objRoleObject)
				$objObject->objRoleObject = Role::GetSoapObjectFromObject($objObject->objRoleObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intRole = null;
			if ($objObject->dttDate)
				$objObject->dttDate = $objObject->dttDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objStatusObject)
				$objObject->objStatusObject = Status::GetSoapObjectFromObject($objObject->objStatusObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intStatus = null;
			if ($objObject->objApprovedByObject)
				$objObject->objApprovedByObject = Login::GetSoapObjectFromObject($objObject->objApprovedByObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intApprovedBy = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdsalarysheetApproval'] = $this->intIdsalarysheetApproval;
			$iArray['Sequence'] = $this->intSequence;
			$iArray['Salarysheet'] = $this->intSalarysheet;
			$iArray['Role'] = $this->intRole;
			$iArray['Date'] = $this->dttDate;
			$iArray['Status'] = $this->intStatus;
			$iArray['Note'] = $this->strNote;
			$iArray['ApprovedBy'] = $this->intApprovedBy;
			$iArray['Ds'] = $this->strDs;
			$iArray['Edit'] = $this->blnEdit;
			$iArray['PreviousApproval'] = $this->blnPreviousApproval;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdsalarysheetApproval ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdsalarysheetApproval
     * @property-read QQNode $Sequence
     * @property-read QQNode $Salarysheet
     * @property-read QQNodeSalarysheet $SalarysheetObject
     * @property-read QQNode $Role
     * @property-read QQNodeRole $RoleObject
     * @property-read QQNode $Date
     * @property-read QQNode $Status
     * @property-read QQNodeStatus $StatusObject
     * @property-read QQNode $Note
     * @property-read QQNode $ApprovedBy
     * @property-read QQNodeLogin $ApprovedByObject
     * @property-read QQNode $Ds
     * @property-read QQNode $Edit
     * @property-read QQNode $PreviousApproval
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeSalarysheetApproval extends QQNode {
		protected $strTableName = 'salarysheet_approval';
		protected $strPrimaryKey = 'idsalarysheet_approval';
		protected $strClassName = 'SalarysheetApproval';
		public function __get($strName) {
			switch ($strName) {
				case 'IdsalarysheetApproval':
					return new QQNode('idsalarysheet_approval', 'IdsalarysheetApproval', 'Integer', $this);
				case 'Sequence':
					return new QQNode('sequence', 'Sequence', 'Integer', $this);
				case 'Salarysheet':
					return new QQNode('salarysheet', 'Salarysheet', 'Integer', $this);
				case 'SalarysheetObject':
					return new QQNodeSalarysheet('salarysheet', 'SalarysheetObject', 'Integer', $this);
				case 'Role':
					return new QQNode('role', 'Role', 'Integer', $this);
				case 'RoleObject':
					return new QQNodeRole('role', 'RoleObject', 'Integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'Date', $this);
				case 'Status':
					return new QQNode('status', 'Status', 'Integer', $this);
				case 'StatusObject':
					return new QQNodeStatus('status', 'StatusObject', 'Integer', $this);
				case 'Note':
					return new QQNode('note', 'Note', 'Blob', $this);
				case 'ApprovedBy':
					return new QQNode('approved_by', 'ApprovedBy', 'Integer', $this);
				case 'ApprovedByObject':
					return new QQNodeLogin('approved_by', 'ApprovedByObject', 'Integer', $this);
				case 'Ds':
					return new QQNode('ds', 'Ds', 'Blob', $this);
				case 'Edit':
					return new QQNode('edit', 'Edit', 'Bit', $this);
				case 'PreviousApproval':
					return new QQNode('previous_approval', 'PreviousApproval', 'Bit', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idsalarysheet_approval', 'IdsalarysheetApproval', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdsalarysheetApproval
     * @property-read QQNode $Sequence
     * @property-read QQNode $Salarysheet
     * @property-read QQNodeSalarysheet $SalarysheetObject
     * @property-read QQNode $Role
     * @property-read QQNodeRole $RoleObject
     * @property-read QQNode $Date
     * @property-read QQNode $Status
     * @property-read QQNodeStatus $StatusObject
     * @property-read QQNode $Note
     * @property-read QQNode $ApprovedBy
     * @property-read QQNodeLogin $ApprovedByObject
     * @property-read QQNode $Ds
     * @property-read QQNode $Edit
     * @property-read QQNode $PreviousApproval
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeSalarysheetApproval extends QQReverseReferenceNode {
		protected $strTableName = 'salarysheet_approval';
		protected $strPrimaryKey = 'idsalarysheet_approval';
		protected $strClassName = 'SalarysheetApproval';
		public function __get($strName) {
			switch ($strName) {
				case 'IdsalarysheetApproval':
					return new QQNode('idsalarysheet_approval', 'IdsalarysheetApproval', 'integer', $this);
				case 'Sequence':
					return new QQNode('sequence', 'Sequence', 'integer', $this);
				case 'Salarysheet':
					return new QQNode('salarysheet', 'Salarysheet', 'integer', $this);
				case 'SalarysheetObject':
					return new QQNodeSalarysheet('salarysheet', 'SalarysheetObject', 'integer', $this);
				case 'Role':
					return new QQNode('role', 'Role', 'integer', $this);
				case 'RoleObject':
					return new QQNodeRole('role', 'RoleObject', 'integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'QDateTime', $this);
				case 'Status':
					return new QQNode('status', 'Status', 'integer', $this);
				case 'StatusObject':
					return new QQNodeStatus('status', 'StatusObject', 'integer', $this);
				case 'Note':
					return new QQNode('note', 'Note', 'string', $this);
				case 'ApprovedBy':
					return new QQNode('approved_by', 'ApprovedBy', 'integer', $this);
				case 'ApprovedByObject':
					return new QQNodeLogin('approved_by', 'ApprovedByObject', 'integer', $this);
				case 'Ds':
					return new QQNode('ds', 'Ds', 'string', $this);
				case 'Edit':
					return new QQNode('edit', 'Edit', 'boolean', $this);
				case 'PreviousApproval':
					return new QQNode('previous_approval', 'PreviousApproval', 'boolean', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idsalarysheet_approval', 'IdsalarysheetApproval', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
