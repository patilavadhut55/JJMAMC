<?php
	// ClassPaths for the AcademicTemplet class
		QApplicationBase::$ClassFile['academictemplet'] = __MODEL__ . '/AcademicTemplet.class.php';
		QApplicationBase::$ClassFile['qqnodeacademictemplet'] = __MODEL__ . '/AcademicTemplet.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeacademictemplet'] = __MODEL__ . '/AcademicTemplet.class.php';
		QApplicationBase::$ClassFile['academictempletmetacontrol'] = __META_CONTROLS__ . '/AcademicTempletMetaControl.class.php';
		QApplicationBase::$ClassFile['academictempletdatagrid'] = __META_CONTROLS__ . '/AcademicTempletDataGrid.class.php';

	// ClassPaths for the AcademicYear class
		QApplicationBase::$ClassFile['academicyear'] = __MODEL__ . '/AcademicYear.class.php';
		QApplicationBase::$ClassFile['qqnodeacademicyear'] = __MODEL__ . '/AcademicYear.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeacademicyear'] = __MODEL__ . '/AcademicYear.class.php';
		QApplicationBase::$ClassFile['academicyearmetacontrol'] = __META_CONTROLS__ . '/AcademicYearMetaControl.class.php';
		QApplicationBase::$ClassFile['academicyeardatagrid'] = __META_CONTROLS__ . '/AcademicYearDataGrid.class.php';

	// ClassPaths for the Address class
		QApplicationBase::$ClassFile['address'] = __MODEL__ . '/Address.class.php';
		QApplicationBase::$ClassFile['qqnodeaddress'] = __MODEL__ . '/Address.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeaddress'] = __MODEL__ . '/Address.class.php';
		QApplicationBase::$ClassFile['addressmetacontrol'] = __META_CONTROLS__ . '/AddressMetaControl.class.php';
		QApplicationBase::$ClassFile['addressdatagrid'] = __META_CONTROLS__ . '/AddressDataGrid.class.php';

	// ClassPaths for the AppApproval class
		QApplicationBase::$ClassFile['appapproval'] = __MODEL__ . '/AppApproval.class.php';
		QApplicationBase::$ClassFile['qqnodeappapproval'] = __MODEL__ . '/AppApproval.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeappapproval'] = __MODEL__ . '/AppApproval.class.php';
		QApplicationBase::$ClassFile['appapprovalmetacontrol'] = __META_CONTROLS__ . '/AppApprovalMetaControl.class.php';
		QApplicationBase::$ClassFile['appapprovaldatagrid'] = __META_CONTROLS__ . '/AppApprovalDataGrid.class.php';

	// ClassPaths for the AppApprovalHasRemark class
		QApplicationBase::$ClassFile['appapprovalhasremark'] = __MODEL__ . '/AppApprovalHasRemark.class.php';
		QApplicationBase::$ClassFile['qqnodeappapprovalhasremark'] = __MODEL__ . '/AppApprovalHasRemark.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeappapprovalhasremark'] = __MODEL__ . '/AppApprovalHasRemark.class.php';
		QApplicationBase::$ClassFile['appapprovalhasremarkmetacontrol'] = __META_CONTROLS__ . '/AppApprovalHasRemarkMetaControl.class.php';
		QApplicationBase::$ClassFile['appapprovalhasremarkdatagrid'] = __META_CONTROLS__ . '/AppApprovalHasRemarkDataGrid.class.php';

	// ClassPaths for the AppDocs class
		QApplicationBase::$ClassFile['appdocs'] = __MODEL__ . '/AppDocs.class.php';
		QApplicationBase::$ClassFile['qqnodeappdocs'] = __MODEL__ . '/AppDocs.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeappdocs'] = __MODEL__ . '/AppDocs.class.php';
		QApplicationBase::$ClassFile['appdocsmetacontrol'] = __META_CONTROLS__ . '/AppDocsMetaControl.class.php';
		QApplicationBase::$ClassFile['appdocsdatagrid'] = __META_CONTROLS__ . '/AppDocsDataGrid.class.php';

	// ClassPaths for the AppStatus class
		QApplicationBase::$ClassFile['appstatus'] = __MODEL__ . '/AppStatus.class.php';
		QApplicationBase::$ClassFile['qqnodeappstatus'] = __MODEL__ . '/AppStatus.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeappstatus'] = __MODEL__ . '/AppStatus.class.php';
		QApplicationBase::$ClassFile['appstatusmetacontrol'] = __META_CONTROLS__ . '/AppStatusMetaControl.class.php';
		QApplicationBase::$ClassFile['appstatusdatagrid'] = __META_CONTROLS__ . '/AppStatusDataGrid.class.php';

	// ClassPaths for the Application class
		QApplicationBase::$ClassFile['application'] = __MODEL__ . '/Application.class.php';
		QApplicationBase::$ClassFile['qqnodeapplication'] = __MODEL__ . '/Application.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeapplication'] = __MODEL__ . '/Application.class.php';
		QApplicationBase::$ClassFile['applicationmetacontrol'] = __META_CONTROLS__ . '/ApplicationMetaControl.class.php';
		QApplicationBase::$ClassFile['applicationdatagrid'] = __META_CONTROLS__ . '/ApplicationDataGrid.class.php';

	// ClassPaths for the Approvel class
		QApplicationBase::$ClassFile['approvel'] = __MODEL__ . '/Approvel.class.php';
		QApplicationBase::$ClassFile['qqnodeapprovel'] = __MODEL__ . '/Approvel.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeapprovel'] = __MODEL__ . '/Approvel.class.php';
		QApplicationBase::$ClassFile['approvelmetacontrol'] = __META_CONTROLS__ . '/ApprovelMetaControl.class.php';
		QApplicationBase::$ClassFile['approveldatagrid'] = __META_CONTROLS__ . '/ApprovelDataGrid.class.php';

	// ClassPaths for the Article class
		QApplicationBase::$ClassFile['article'] = __MODEL__ . '/Article.class.php';
		QApplicationBase::$ClassFile['qqnodearticle'] = __MODEL__ . '/Article.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodearticle'] = __MODEL__ . '/Article.class.php';
		QApplicationBase::$ClassFile['articlemetacontrol'] = __META_CONTROLS__ . '/ArticleMetaControl.class.php';
		QApplicationBase::$ClassFile['articledatagrid'] = __META_CONTROLS__ . '/ArticleDataGrid.class.php';

	// ClassPaths for the ArticleGrp class
		QApplicationBase::$ClassFile['articlegrp'] = __MODEL__ . '/ArticleGrp.class.php';
		QApplicationBase::$ClassFile['qqnodearticlegrp'] = __MODEL__ . '/ArticleGrp.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodearticlegrp'] = __MODEL__ . '/ArticleGrp.class.php';
		QApplicationBase::$ClassFile['articlegrpmetacontrol'] = __META_CONTROLS__ . '/ArticleGrpMetaControl.class.php';
		QApplicationBase::$ClassFile['articlegrpdatagrid'] = __META_CONTROLS__ . '/ArticleGrpDataGrid.class.php';

	// ClassPaths for the BloodGroup class
		QApplicationBase::$ClassFile['bloodgroup'] = __MODEL__ . '/BloodGroup.class.php';
		QApplicationBase::$ClassFile['qqnodebloodgroup'] = __MODEL__ . '/BloodGroup.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodebloodgroup'] = __MODEL__ . '/BloodGroup.class.php';
		QApplicationBase::$ClassFile['bloodgroupmetacontrol'] = __META_CONTROLS__ . '/BloodGroupMetaControl.class.php';
		QApplicationBase::$ClassFile['bloodgroupdatagrid'] = __META_CONTROLS__ . '/BloodGroupDataGrid.class.php';

	// ClassPaths for the CalenderYear class
		QApplicationBase::$ClassFile['calenderyear'] = __MODEL__ . '/CalenderYear.class.php';
		QApplicationBase::$ClassFile['qqnodecalenderyear'] = __MODEL__ . '/CalenderYear.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodecalenderyear'] = __MODEL__ . '/CalenderYear.class.php';
		QApplicationBase::$ClassFile['calenderyearmetacontrol'] = __META_CONTROLS__ . '/CalenderYearMetaControl.class.php';
		QApplicationBase::$ClassFile['calenderyeardatagrid'] = __META_CONTROLS__ . '/CalenderYearDataGrid.class.php';

	// ClassPaths for the Cast class
		QApplicationBase::$ClassFile['cast'] = __MODEL__ . '/Cast.class.php';
		QApplicationBase::$ClassFile['qqnodecast'] = __MODEL__ . '/Cast.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodecast'] = __MODEL__ . '/Cast.class.php';
		QApplicationBase::$ClassFile['castmetacontrol'] = __META_CONTROLS__ . '/CastMetaControl.class.php';
		QApplicationBase::$ClassFile['castdatagrid'] = __META_CONTROLS__ . '/CastDataGrid.class.php';

	// ClassPaths for the Caste class
		QApplicationBase::$ClassFile['caste'] = __MODEL__ . '/Caste.class.php';
		QApplicationBase::$ClassFile['qqnodecaste'] = __MODEL__ . '/Caste.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodecaste'] = __MODEL__ . '/Caste.class.php';
		QApplicationBase::$ClassFile['castemetacontrol'] = __META_CONTROLS__ . '/CasteMetaControl.class.php';
		QApplicationBase::$ClassFile['castedatagrid'] = __META_CONTROLS__ . '/CasteDataGrid.class.php';

	// ClassPaths for the CertificateGroup class
		QApplicationBase::$ClassFile['certificategroup'] = __MODEL__ . '/CertificateGroup.class.php';
		QApplicationBase::$ClassFile['qqnodecertificategroup'] = __MODEL__ . '/CertificateGroup.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodecertificategroup'] = __MODEL__ . '/CertificateGroup.class.php';
		QApplicationBase::$ClassFile['certificategroupmetacontrol'] = __META_CONTROLS__ . '/CertificateGroupMetaControl.class.php';
		QApplicationBase::$ClassFile['certificategroupdatagrid'] = __META_CONTROLS__ . '/CertificateGroupDataGrid.class.php';

	// ClassPaths for the CertificateTemplet class
		QApplicationBase::$ClassFile['certificatetemplet'] = __MODEL__ . '/CertificateTemplet.class.php';
		QApplicationBase::$ClassFile['qqnodecertificatetemplet'] = __MODEL__ . '/CertificateTemplet.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodecertificatetemplet'] = __MODEL__ . '/CertificateTemplet.class.php';
		QApplicationBase::$ClassFile['certificatetempletmetacontrol'] = __META_CONTROLS__ . '/CertificateTempletMetaControl.class.php';
		QApplicationBase::$ClassFile['certificatetempletdatagrid'] = __META_CONTROLS__ . '/CertificateTempletDataGrid.class.php';

	// ClassPaths for the CertificateTempletHasRemark class
		QApplicationBase::$ClassFile['certificatetemplethasremark'] = __MODEL__ . '/CertificateTempletHasRemark.class.php';
		QApplicationBase::$ClassFile['qqnodecertificatetemplethasremark'] = __MODEL__ . '/CertificateTempletHasRemark.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodecertificatetemplethasremark'] = __MODEL__ . '/CertificateTempletHasRemark.class.php';
		QApplicationBase::$ClassFile['certificatetemplethasremarkmetacontrol'] = __META_CONTROLS__ . '/CertificateTempletHasRemarkMetaControl.class.php';
		QApplicationBase::$ClassFile['certificatetemplethasremarkdatagrid'] = __META_CONTROLS__ . '/CertificateTempletHasRemarkDataGrid.class.php';

	// ClassPaths for the CourseGrp class
		QApplicationBase::$ClassFile['coursegrp'] = __MODEL__ . '/CourseGrp.class.php';
		QApplicationBase::$ClassFile['qqnodecoursegrp'] = __MODEL__ . '/CourseGrp.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodecoursegrp'] = __MODEL__ . '/CourseGrp.class.php';
		QApplicationBase::$ClassFile['coursegrpmetacontrol'] = __META_CONTROLS__ . '/CourseGrpMetaControl.class.php';
		QApplicationBase::$ClassFile['coursegrpdatagrid'] = __META_CONTROLS__ . '/CourseGrpDataGrid.class.php';

	// ClassPaths for the Css class
		QApplicationBase::$ClassFile['css'] = __MODEL__ . '/Css.class.php';
		QApplicationBase::$ClassFile['qqnodecss'] = __MODEL__ . '/Css.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodecss'] = __MODEL__ . '/Css.class.php';
		QApplicationBase::$ClassFile['cssmetacontrol'] = __META_CONTROLS__ . '/CssMetaControl.class.php';
		QApplicationBase::$ClassFile['cssdatagrid'] = __META_CONTROLS__ . '/CssDataGrid.class.php';

	// ClassPaths for the Decision class
		QApplicationBase::$ClassFile['decision'] = __MODEL__ . '/Decision.class.php';
		QApplicationBase::$ClassFile['qqnodedecision'] = __MODEL__ . '/Decision.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodedecision'] = __MODEL__ . '/Decision.class.php';
		QApplicationBase::$ClassFile['decisionmetacontrol'] = __META_CONTROLS__ . '/DecisionMetaControl.class.php';
		QApplicationBase::$ClassFile['decisiondatagrid'] = __META_CONTROLS__ . '/DecisionDataGrid.class.php';

	// ClassPaths for the DeptYear class
		QApplicationBase::$ClassFile['deptyear'] = __MODEL__ . '/DeptYear.class.php';
		QApplicationBase::$ClassFile['qqnodedeptyear'] = __MODEL__ . '/DeptYear.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodedeptyear'] = __MODEL__ . '/DeptYear.class.php';
		QApplicationBase::$ClassFile['deptyearmetacontrol'] = __META_CONTROLS__ . '/DeptYearMetaControl.class.php';
		QApplicationBase::$ClassFile['deptyeardatagrid'] = __META_CONTROLS__ . '/DeptYearDataGrid.class.php';

	// ClassPaths for the DeptYearEvents class
		QApplicationBase::$ClassFile['deptyearevents'] = __MODEL__ . '/DeptYearEvents.class.php';
		QApplicationBase::$ClassFile['qqnodedeptyearevents'] = __MODEL__ . '/DeptYearEvents.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodedeptyearevents'] = __MODEL__ . '/DeptYearEvents.class.php';
		QApplicationBase::$ClassFile['deptyeareventsmetacontrol'] = __META_CONTROLS__ . '/DeptYearEventsMetaControl.class.php';
		QApplicationBase::$ClassFile['deptyeareventsdatagrid'] = __META_CONTROLS__ . '/DeptYearEventsDataGrid.class.php';

	// ClassPaths for the DeptYearExam class
		QApplicationBase::$ClassFile['deptyearexam'] = __MODEL__ . '/DeptYearExam.class.php';
		QApplicationBase::$ClassFile['qqnodedeptyearexam'] = __MODEL__ . '/DeptYearExam.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodedeptyearexam'] = __MODEL__ . '/DeptYearExam.class.php';
		QApplicationBase::$ClassFile['deptyearexammetacontrol'] = __META_CONTROLS__ . '/DeptYearExamMetaControl.class.php';
		QApplicationBase::$ClassFile['deptyearexamdatagrid'] = __META_CONTROLS__ . '/DeptYearExamDataGrid.class.php';

	// ClassPaths for the Event class
		QApplicationBase::$ClassFile['event'] = __MODEL__ . '/Event.class.php';
		QApplicationBase::$ClassFile['qqnodeevent'] = __MODEL__ . '/Event.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeevent'] = __MODEL__ . '/Event.class.php';
		QApplicationBase::$ClassFile['eventmetacontrol'] = __META_CONTROLS__ . '/EventMetaControl.class.php';
		QApplicationBase::$ClassFile['eventdatagrid'] = __META_CONTROLS__ . '/EventDataGrid.class.php';

	// ClassPaths for the Exam class
		QApplicationBase::$ClassFile['exam'] = __MODEL__ . '/Exam.class.php';
		QApplicationBase::$ClassFile['qqnodeexam'] = __MODEL__ . '/Exam.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeexam'] = __MODEL__ . '/Exam.class.php';
		QApplicationBase::$ClassFile['exammetacontrol'] = __META_CONTROLS__ . '/ExamMetaControl.class.php';
		QApplicationBase::$ClassFile['examdatagrid'] = __META_CONTROLS__ . '/ExamDataGrid.class.php';

	// ClassPaths for the ExamGroup class
		QApplicationBase::$ClassFile['examgroup'] = __MODEL__ . '/ExamGroup.class.php';
		QApplicationBase::$ClassFile['qqnodeexamgroup'] = __MODEL__ . '/ExamGroup.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeexamgroup'] = __MODEL__ . '/ExamGroup.class.php';
		QApplicationBase::$ClassFile['examgroupmetacontrol'] = __META_CONTROLS__ . '/ExamGroupMetaControl.class.php';
		QApplicationBase::$ClassFile['examgroupdatagrid'] = __META_CONTROLS__ . '/ExamGroupDataGrid.class.php';

	// ClassPaths for the FeesTemplet class
		QApplicationBase::$ClassFile['feestemplet'] = __MODEL__ . '/FeesTemplet.class.php';
		QApplicationBase::$ClassFile['qqnodefeestemplet'] = __MODEL__ . '/FeesTemplet.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodefeestemplet'] = __MODEL__ . '/FeesTemplet.class.php';
		QApplicationBase::$ClassFile['feestempletmetacontrol'] = __META_CONTROLS__ . '/FeesTempletMetaControl.class.php';
		QApplicationBase::$ClassFile['feestempletdatagrid'] = __META_CONTROLS__ . '/FeesTempletDataGrid.class.php';

	// ClassPaths for the Gardian class
		QApplicationBase::$ClassFile['gardian'] = __MODEL__ . '/Gardian.class.php';
		QApplicationBase::$ClassFile['qqnodegardian'] = __MODEL__ . '/Gardian.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodegardian'] = __MODEL__ . '/Gardian.class.php';
		QApplicationBase::$ClassFile['gardianmetacontrol'] = __META_CONTROLS__ . '/GardianMetaControl.class.php';
		QApplicationBase::$ClassFile['gardiandatagrid'] = __META_CONTROLS__ . '/GardianDataGrid.class.php';

	// ClassPaths for the GardianCat class
		QApplicationBase::$ClassFile['gardiancat'] = __MODEL__ . '/GardianCat.class.php';
		QApplicationBase::$ClassFile['qqnodegardiancat'] = __MODEL__ . '/GardianCat.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodegardiancat'] = __MODEL__ . '/GardianCat.class.php';
		QApplicationBase::$ClassFile['gardiancatmetacontrol'] = __META_CONTROLS__ . '/GardianCatMetaControl.class.php';
		QApplicationBase::$ClassFile['gardiancatdatagrid'] = __META_CONTROLS__ . '/GardianCatDataGrid.class.php';

	// ClassPaths for the Gender class
		QApplicationBase::$ClassFile['gender'] = __MODEL__ . '/Gender.class.php';
		QApplicationBase::$ClassFile['qqnodegender'] = __MODEL__ . '/Gender.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodegender'] = __MODEL__ . '/Gender.class.php';
		QApplicationBase::$ClassFile['gendermetacontrol'] = __META_CONTROLS__ . '/GenderMetaControl.class.php';
		QApplicationBase::$ClassFile['genderdatagrid'] = __META_CONTROLS__ . '/GenderDataGrid.class.php';

	// ClassPaths for the Group class
		QApplicationBase::$ClassFile['group'] = __MODEL__ . '/Group.class.php';
		QApplicationBase::$ClassFile['qqnodegroup'] = __MODEL__ . '/Group.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodegroup'] = __MODEL__ . '/Group.class.php';
		QApplicationBase::$ClassFile['groupmetacontrol'] = __META_CONTROLS__ . '/GroupMetaControl.class.php';
		QApplicationBase::$ClassFile['groupdatagrid'] = __META_CONTROLS__ . '/GroupDataGrid.class.php';

	// ClassPaths for the HandicapedCat class
		QApplicationBase::$ClassFile['handicapedcat'] = __MODEL__ . '/HandicapedCat.class.php';
		QApplicationBase::$ClassFile['qqnodehandicapedcat'] = __MODEL__ . '/HandicapedCat.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodehandicapedcat'] = __MODEL__ . '/HandicapedCat.class.php';
		QApplicationBase::$ClassFile['handicapedcatmetacontrol'] = __META_CONTROLS__ . '/HandicapedCatMetaControl.class.php';
		QApplicationBase::$ClassFile['handicapedcatdatagrid'] = __META_CONTROLS__ . '/HandicapedCatDataGrid.class.php';

	// ClassPaths for the History class
		QApplicationBase::$ClassFile['history'] = __MODEL__ . '/History.class.php';
		QApplicationBase::$ClassFile['qqnodehistory'] = __MODEL__ . '/History.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodehistory'] = __MODEL__ . '/History.class.php';
		QApplicationBase::$ClassFile['historymetacontrol'] = __META_CONTROLS__ . '/HistoryMetaControl.class.php';
		QApplicationBase::$ClassFile['historydatagrid'] = __META_CONTROLS__ . '/HistoryDataGrid.class.php';

	// ClassPaths for the Impact class
		QApplicationBase::$ClassFile['impact'] = __MODEL__ . '/Impact.class.php';
		QApplicationBase::$ClassFile['qqnodeimpact'] = __MODEL__ . '/Impact.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeimpact'] = __MODEL__ . '/Impact.class.php';
		QApplicationBase::$ClassFile['impactmetacontrol'] = __META_CONTROLS__ . '/ImpactMetaControl.class.php';
		QApplicationBase::$ClassFile['impactdatagrid'] = __META_CONTROLS__ . '/ImpactDataGrid.class.php';

	// ClassPaths for the Ledger class
		QApplicationBase::$ClassFile['ledger'] = __MODEL__ . '/Ledger.class.php';
		QApplicationBase::$ClassFile['qqnodeledger'] = __MODEL__ . '/Ledger.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeledger'] = __MODEL__ . '/Ledger.class.php';
		QApplicationBase::$ClassFile['ledgermetacontrol'] = __META_CONTROLS__ . '/LedgerMetaControl.class.php';
		QApplicationBase::$ClassFile['ledgerdatagrid'] = __META_CONTROLS__ . '/LedgerDataGrid.class.php';

	// ClassPaths for the LedgerDetails class
		QApplicationBase::$ClassFile['ledgerdetails'] = __MODEL__ . '/LedgerDetails.class.php';
		QApplicationBase::$ClassFile['qqnodeledgerdetails'] = __MODEL__ . '/LedgerDetails.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeledgerdetails'] = __MODEL__ . '/LedgerDetails.class.php';
		QApplicationBase::$ClassFile['ledgerdetailsmetacontrol'] = __META_CONTROLS__ . '/LedgerDetailsMetaControl.class.php';
		QApplicationBase::$ClassFile['ledgerdetailsdatagrid'] = __META_CONTROLS__ . '/LedgerDetailsDataGrid.class.php';

	// ClassPaths for the Log class
		QApplicationBase::$ClassFile['log'] = __MODEL__ . '/Log.class.php';
		QApplicationBase::$ClassFile['qqnodelog'] = __MODEL__ . '/Log.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodelog'] = __MODEL__ . '/Log.class.php';
		QApplicationBase::$ClassFile['logmetacontrol'] = __META_CONTROLS__ . '/LogMetaControl.class.php';
		QApplicationBase::$ClassFile['logdatagrid'] = __META_CONTROLS__ . '/LogDataGrid.class.php';

	// ClassPaths for the LogGrp class
		QApplicationBase::$ClassFile['loggrp'] = __MODEL__ . '/LogGrp.class.php';
		QApplicationBase::$ClassFile['qqnodeloggrp'] = __MODEL__ . '/LogGrp.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeloggrp'] = __MODEL__ . '/LogGrp.class.php';
		QApplicationBase::$ClassFile['loggrpmetacontrol'] = __META_CONTROLS__ . '/LogGrpMetaControl.class.php';
		QApplicationBase::$ClassFile['loggrpdatagrid'] = __META_CONTROLS__ . '/LogGrpDataGrid.class.php';

	// ClassPaths for the Login class
		QApplicationBase::$ClassFile['login'] = __MODEL__ . '/Login.class.php';
		QApplicationBase::$ClassFile['qqnodelogin'] = __MODEL__ . '/Login.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodelogin'] = __MODEL__ . '/Login.class.php';
		QApplicationBase::$ClassFile['loginmetacontrol'] = __META_CONTROLS__ . '/LoginMetaControl.class.php';
		QApplicationBase::$ClassFile['logindatagrid'] = __META_CONTROLS__ . '/LoginDataGrid.class.php';

	// ClassPaths for the LoginHasRole class
		QApplicationBase::$ClassFile['loginhasrole'] = __MODEL__ . '/LoginHasRole.class.php';
		QApplicationBase::$ClassFile['qqnodeloginhasrole'] = __MODEL__ . '/LoginHasRole.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeloginhasrole'] = __MODEL__ . '/LoginHasRole.class.php';
		QApplicationBase::$ClassFile['loginhasrolemetacontrol'] = __META_CONTROLS__ . '/LoginHasRoleMetaControl.class.php';
		QApplicationBase::$ClassFile['loginhasroledatagrid'] = __META_CONTROLS__ . '/LoginHasRoleDataGrid.class.php';

	// ClassPaths for the MarrialStatus class
		QApplicationBase::$ClassFile['marrialstatus'] = __MODEL__ . '/MarrialStatus.class.php';
		QApplicationBase::$ClassFile['qqnodemarrialstatus'] = __MODEL__ . '/MarrialStatus.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodemarrialstatus'] = __MODEL__ . '/MarrialStatus.class.php';
		QApplicationBase::$ClassFile['marrialstatusmetacontrol'] = __META_CONTROLS__ . '/MarrialStatusMetaControl.class.php';
		QApplicationBase::$ClassFile['marrialstatusdatagrid'] = __META_CONTROLS__ . '/MarrialStatusDataGrid.class.php';

	// ClassPaths for the Menu class
		QApplicationBase::$ClassFile['menu'] = __MODEL__ . '/Menu.class.php';
		QApplicationBase::$ClassFile['qqnodemenu'] = __MODEL__ . '/Menu.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodemenu'] = __MODEL__ . '/Menu.class.php';
		QApplicationBase::$ClassFile['menumetacontrol'] = __META_CONTROLS__ . '/MenuMetaControl.class.php';
		QApplicationBase::$ClassFile['menudatagrid'] = __META_CONTROLS__ . '/MenuDataGrid.class.php';

	// ClassPaths for the MenuHasArticle class
		QApplicationBase::$ClassFile['menuhasarticle'] = __MODEL__ . '/MenuHasArticle.class.php';
		QApplicationBase::$ClassFile['qqnodemenuhasarticle'] = __MODEL__ . '/MenuHasArticle.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodemenuhasarticle'] = __MODEL__ . '/MenuHasArticle.class.php';
		QApplicationBase::$ClassFile['menuhasarticlemetacontrol'] = __META_CONTROLS__ . '/MenuHasArticleMetaControl.class.php';
		QApplicationBase::$ClassFile['menuhasarticledatagrid'] = __META_CONTROLS__ . '/MenuHasArticleDataGrid.class.php';

	// ClassPaths for the MenuPosition class
		QApplicationBase::$ClassFile['menuposition'] = __MODEL__ . '/MenuPosition.class.php';
		QApplicationBase::$ClassFile['qqnodemenuposition'] = __MODEL__ . '/MenuPosition.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodemenuposition'] = __MODEL__ . '/MenuPosition.class.php';
		QApplicationBase::$ClassFile['menupositionmetacontrol'] = __META_CONTROLS__ . '/MenuPositionMetaControl.class.php';
		QApplicationBase::$ClassFile['menupositiondatagrid'] = __META_CONTROLS__ . '/MenuPositionDataGrid.class.php';

	// ClassPaths for the MotherTongue class
		QApplicationBase::$ClassFile['mothertongue'] = __MODEL__ . '/MotherTongue.class.php';
		QApplicationBase::$ClassFile['qqnodemothertongue'] = __MODEL__ . '/MotherTongue.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodemothertongue'] = __MODEL__ . '/MotherTongue.class.php';
		QApplicationBase::$ClassFile['mothertonguemetacontrol'] = __META_CONTROLS__ . '/MotherTongueMetaControl.class.php';
		QApplicationBase::$ClassFile['mothertonguedatagrid'] = __META_CONTROLS__ . '/MotherTongueDataGrid.class.php';

	// ClassPaths for the Nationality class
		QApplicationBase::$ClassFile['nationality'] = __MODEL__ . '/Nationality.class.php';
		QApplicationBase::$ClassFile['qqnodenationality'] = __MODEL__ . '/Nationality.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodenationality'] = __MODEL__ . '/Nationality.class.php';
		QApplicationBase::$ClassFile['nationalitymetacontrol'] = __META_CONTROLS__ . '/NationalityMetaControl.class.php';
		QApplicationBase::$ClassFile['nationalitydatagrid'] = __META_CONTROLS__ . '/NationalityDataGrid.class.php';

	// ClassPaths for the Note class
		QApplicationBase::$ClassFile['note'] = __MODEL__ . '/Note.class.php';
		QApplicationBase::$ClassFile['qqnodenote'] = __MODEL__ . '/Note.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodenote'] = __MODEL__ . '/Note.class.php';
		QApplicationBase::$ClassFile['notemetacontrol'] = __META_CONTROLS__ . '/NoteMetaControl.class.php';
		QApplicationBase::$ClassFile['notedatagrid'] = __META_CONTROLS__ . '/NoteDataGrid.class.php';

	// ClassPaths for the Occurance class
		QApplicationBase::$ClassFile['occurance'] = __MODEL__ . '/Occurance.class.php';
		QApplicationBase::$ClassFile['qqnodeoccurance'] = __MODEL__ . '/Occurance.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeoccurance'] = __MODEL__ . '/Occurance.class.php';
		QApplicationBase::$ClassFile['occurancemetacontrol'] = __META_CONTROLS__ . '/OccuranceMetaControl.class.php';
		QApplicationBase::$ClassFile['occurancedatagrid'] = __META_CONTROLS__ . '/OccuranceDataGrid.class.php';

	// ClassPaths for the Place class
		QApplicationBase::$ClassFile['place'] = __MODEL__ . '/Place.class.php';
		QApplicationBase::$ClassFile['qqnodeplace'] = __MODEL__ . '/Place.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeplace'] = __MODEL__ . '/Place.class.php';
		QApplicationBase::$ClassFile['placemetacontrol'] = __META_CONTROLS__ . '/PlaceMetaControl.class.php';
		QApplicationBase::$ClassFile['placedatagrid'] = __META_CONTROLS__ . '/PlaceDataGrid.class.php';

	// ClassPaths for the PlaceGrp class
		QApplicationBase::$ClassFile['placegrp'] = __MODEL__ . '/PlaceGrp.class.php';
		QApplicationBase::$ClassFile['qqnodeplacegrp'] = __MODEL__ . '/PlaceGrp.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeplacegrp'] = __MODEL__ . '/PlaceGrp.class.php';
		QApplicationBase::$ClassFile['placegrpmetacontrol'] = __META_CONTROLS__ . '/PlaceGrpMetaControl.class.php';
		QApplicationBase::$ClassFile['placegrpdatagrid'] = __META_CONTROLS__ . '/PlaceGrpDataGrid.class.php';

	// ClassPaths for the Prefix class
		QApplicationBase::$ClassFile['prefix'] = __MODEL__ . '/Prefix.class.php';
		QApplicationBase::$ClassFile['qqnodeprefix'] = __MODEL__ . '/Prefix.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeprefix'] = __MODEL__ . '/Prefix.class.php';
		QApplicationBase::$ClassFile['prefixmetacontrol'] = __META_CONTROLS__ . '/PrefixMetaControl.class.php';
		QApplicationBase::$ClassFile['prefixdatagrid'] = __META_CONTROLS__ . '/PrefixDataGrid.class.php';

	// ClassPaths for the PriceHistory class
		QApplicationBase::$ClassFile['pricehistory'] = __MODEL__ . '/PriceHistory.class.php';
		QApplicationBase::$ClassFile['qqnodepricehistory'] = __MODEL__ . '/PriceHistory.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodepricehistory'] = __MODEL__ . '/PriceHistory.class.php';
		QApplicationBase::$ClassFile['pricehistorymetacontrol'] = __META_CONTROLS__ . '/PriceHistoryMetaControl.class.php';
		QApplicationBase::$ClassFile['pricehistorydatagrid'] = __META_CONTROLS__ . '/PriceHistoryDataGrid.class.php';

	// ClassPaths for the Profile class
		QApplicationBase::$ClassFile['profile'] = __MODEL__ . '/Profile.class.php';
		QApplicationBase::$ClassFile['qqnodeprofile'] = __MODEL__ . '/Profile.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeprofile'] = __MODEL__ . '/Profile.class.php';
		QApplicationBase::$ClassFile['profilemetacontrol'] = __META_CONTROLS__ . '/ProfileMetaControl.class.php';
		QApplicationBase::$ClassFile['profiledatagrid'] = __META_CONTROLS__ . '/ProfileDataGrid.class.php';

	// ClassPaths for the Religion class
		QApplicationBase::$ClassFile['religion'] = __MODEL__ . '/Religion.class.php';
		QApplicationBase::$ClassFile['qqnodereligion'] = __MODEL__ . '/Religion.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodereligion'] = __MODEL__ . '/Religion.class.php';
		QApplicationBase::$ClassFile['religionmetacontrol'] = __META_CONTROLS__ . '/ReligionMetaControl.class.php';
		QApplicationBase::$ClassFile['religiondatagrid'] = __META_CONTROLS__ . '/ReligionDataGrid.class.php';

	// ClassPaths for the Remark class
		QApplicationBase::$ClassFile['remark'] = __MODEL__ . '/Remark.class.php';
		QApplicationBase::$ClassFile['qqnoderemark'] = __MODEL__ . '/Remark.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenoderemark'] = __MODEL__ . '/Remark.class.php';
		QApplicationBase::$ClassFile['remarkmetacontrol'] = __META_CONTROLS__ . '/RemarkMetaControl.class.php';
		QApplicationBase::$ClassFile['remarkdatagrid'] = __META_CONTROLS__ . '/RemarkDataGrid.class.php';

	// ClassPaths for the Reproducible class
		QApplicationBase::$ClassFile['reproducible'] = __MODEL__ . '/Reproducible.class.php';
		QApplicationBase::$ClassFile['qqnodereproducible'] = __MODEL__ . '/Reproducible.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodereproducible'] = __MODEL__ . '/Reproducible.class.php';
		QApplicationBase::$ClassFile['reproduciblemetacontrol'] = __META_CONTROLS__ . '/ReproducibleMetaControl.class.php';
		QApplicationBase::$ClassFile['reproducibledatagrid'] = __META_CONTROLS__ . '/ReproducibleDataGrid.class.php';

	// ClassPaths for the Role class
		QApplicationBase::$ClassFile['role'] = __MODEL__ . '/Role.class.php';
		QApplicationBase::$ClassFile['qqnoderole'] = __MODEL__ . '/Role.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenoderole'] = __MODEL__ . '/Role.class.php';
		QApplicationBase::$ClassFile['rolemetacontrol'] = __META_CONTROLS__ . '/RoleMetaControl.class.php';
		QApplicationBase::$ClassFile['roledatagrid'] = __META_CONTROLS__ . '/RoleDataGrid.class.php';

	// ClassPaths for the RoleHasMenu class
		QApplicationBase::$ClassFile['rolehasmenu'] = __MODEL__ . '/RoleHasMenu.class.php';
		QApplicationBase::$ClassFile['qqnoderolehasmenu'] = __MODEL__ . '/RoleHasMenu.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenoderolehasmenu'] = __MODEL__ . '/RoleHasMenu.class.php';
		QApplicationBase::$ClassFile['rolehasmenumetacontrol'] = __META_CONTROLS__ . '/RoleHasMenuMetaControl.class.php';
		QApplicationBase::$ClassFile['rolehasmenudatagrid'] = __META_CONTROLS__ . '/RoleHasMenuDataGrid.class.php';

	// ClassPaths for the Scan class
		QApplicationBase::$ClassFile['scan'] = __MODEL__ . '/Scan.class.php';
		QApplicationBase::$ClassFile['qqnodescan'] = __MODEL__ . '/Scan.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodescan'] = __MODEL__ . '/Scan.class.php';
		QApplicationBase::$ClassFile['scanmetacontrol'] = __META_CONTROLS__ . '/ScanMetaControl.class.php';
		QApplicationBase::$ClassFile['scandatagrid'] = __META_CONTROLS__ . '/ScanDataGrid.class.php';

	// ClassPaths for the Serials class
		QApplicationBase::$ClassFile['serials'] = __MODEL__ . '/Serials.class.php';
		QApplicationBase::$ClassFile['qqnodeserials'] = __MODEL__ . '/Serials.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeserials'] = __MODEL__ . '/Serials.class.php';
		QApplicationBase::$ClassFile['serialsmetacontrol'] = __META_CONTROLS__ . '/SerialsMetaControl.class.php';
		QApplicationBase::$ClassFile['serialsdatagrid'] = __META_CONTROLS__ . '/SerialsDataGrid.class.php';

	// ClassPaths for the Settings class
		QApplicationBase::$ClassFile['settings'] = __MODEL__ . '/Settings.class.php';
		QApplicationBase::$ClassFile['qqnodesettings'] = __MODEL__ . '/Settings.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodesettings'] = __MODEL__ . '/Settings.class.php';
		QApplicationBase::$ClassFile['settingsmetacontrol'] = __META_CONTROLS__ . '/SettingsMetaControl.class.php';
		QApplicationBase::$ClassFile['settingsdatagrid'] = __META_CONTROLS__ . '/SettingsDataGrid.class.php';

	// ClassPaths for the SignPatch class
		QApplicationBase::$ClassFile['signpatch'] = __MODEL__ . '/SignPatch.class.php';
		QApplicationBase::$ClassFile['qqnodesignpatch'] = __MODEL__ . '/SignPatch.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodesignpatch'] = __MODEL__ . '/SignPatch.class.php';
		QApplicationBase::$ClassFile['signpatchmetacontrol'] = __META_CONTROLS__ . '/SignPatchMetaControl.class.php';
		QApplicationBase::$ClassFile['signpatchdatagrid'] = __META_CONTROLS__ . '/SignPatchDataGrid.class.php';

	// ClassPaths for the Status class
		QApplicationBase::$ClassFile['status'] = __MODEL__ . '/Status.class.php';
		QApplicationBase::$ClassFile['qqnodestatus'] = __MODEL__ . '/Status.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodestatus'] = __MODEL__ . '/Status.class.php';
		QApplicationBase::$ClassFile['statusmetacontrol'] = __META_CONTROLS__ . '/StatusMetaControl.class.php';
		QApplicationBase::$ClassFile['statusdatagrid'] = __META_CONTROLS__ . '/StatusDataGrid.class.php';

	// ClassPaths for the Stock class
		QApplicationBase::$ClassFile['stock'] = __MODEL__ . '/Stock.class.php';
		QApplicationBase::$ClassFile['qqnodestock'] = __MODEL__ . '/Stock.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodestock'] = __MODEL__ . '/Stock.class.php';
		QApplicationBase::$ClassFile['stockmetacontrol'] = __META_CONTROLS__ . '/StockMetaControl.class.php';
		QApplicationBase::$ClassFile['stockdatagrid'] = __META_CONTROLS__ . '/StockDataGrid.class.php';

	// ClassPaths for the StockGrp class
		QApplicationBase::$ClassFile['stockgrp'] = __MODEL__ . '/StockGrp.class.php';
		QApplicationBase::$ClassFile['qqnodestockgrp'] = __MODEL__ . '/StockGrp.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodestockgrp'] = __MODEL__ . '/StockGrp.class.php';
		QApplicationBase::$ClassFile['stockgrpmetacontrol'] = __META_CONTROLS__ . '/StockGrpMetaControl.class.php';
		QApplicationBase::$ClassFile['stockgrpdatagrid'] = __META_CONTROLS__ . '/StockGrpDataGrid.class.php';

	// ClassPaths for the Subject class
		QApplicationBase::$ClassFile['subject'] = __MODEL__ . '/Subject.class.php';
		QApplicationBase::$ClassFile['qqnodesubject'] = __MODEL__ . '/Subject.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodesubject'] = __MODEL__ . '/Subject.class.php';
		QApplicationBase::$ClassFile['subjectmetacontrol'] = __META_CONTROLS__ . '/SubjectMetaControl.class.php';
		QApplicationBase::$ClassFile['subjectdatagrid'] = __META_CONTROLS__ . '/SubjectDataGrid.class.php';

	// ClassPaths for the TempletDocuments class
		QApplicationBase::$ClassFile['templetdocuments'] = __MODEL__ . '/TempletDocuments.class.php';
		QApplicationBase::$ClassFile['qqnodetempletdocuments'] = __MODEL__ . '/TempletDocuments.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodetempletdocuments'] = __MODEL__ . '/TempletDocuments.class.php';
		QApplicationBase::$ClassFile['templetdocumentsmetacontrol'] = __META_CONTROLS__ . '/TempletDocumentsMetaControl.class.php';
		QApplicationBase::$ClassFile['templetdocumentsdatagrid'] = __META_CONTROLS__ . '/TempletDocumentsDataGrid.class.php';

	// ClassPaths for the Type class
		QApplicationBase::$ClassFile['type'] = __MODEL__ . '/Type.class.php';
		QApplicationBase::$ClassFile['qqnodetype'] = __MODEL__ . '/Type.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodetype'] = __MODEL__ . '/Type.class.php';
		QApplicationBase::$ClassFile['typemetacontrol'] = __META_CONTROLS__ . '/TypeMetaControl.class.php';
		QApplicationBase::$ClassFile['typedatagrid'] = __META_CONTROLS__ . '/TypeDataGrid.class.php';

	// ClassPaths for the Unit class
		QApplicationBase::$ClassFile['unit'] = __MODEL__ . '/Unit.class.php';
		QApplicationBase::$ClassFile['qqnodeunit'] = __MODEL__ . '/Unit.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeunit'] = __MODEL__ . '/Unit.class.php';
		QApplicationBase::$ClassFile['unitmetacontrol'] = __META_CONTROLS__ . '/UnitMetaControl.class.php';
		QApplicationBase::$ClassFile['unitdatagrid'] = __META_CONTROLS__ . '/UnitDataGrid.class.php';

	// ClassPaths for the Voucher class
		QApplicationBase::$ClassFile['voucher'] = __MODEL__ . '/Voucher.class.php';
		QApplicationBase::$ClassFile['qqnodevoucher'] = __MODEL__ . '/Voucher.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodevoucher'] = __MODEL__ . '/Voucher.class.php';
		QApplicationBase::$ClassFile['vouchermetacontrol'] = __META_CONTROLS__ . '/VoucherMetaControl.class.php';
		QApplicationBase::$ClassFile['voucherdatagrid'] = __META_CONTROLS__ . '/VoucherDataGrid.class.php';

	// ClassPaths for the VoucherGrp class
		QApplicationBase::$ClassFile['vouchergrp'] = __MODEL__ . '/VoucherGrp.class.php';
		QApplicationBase::$ClassFile['qqnodevouchergrp'] = __MODEL__ . '/VoucherGrp.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodevouchergrp'] = __MODEL__ . '/VoucherGrp.class.php';
		QApplicationBase::$ClassFile['vouchergrpmetacontrol'] = __META_CONTROLS__ . '/VoucherGrpMetaControl.class.php';
		QApplicationBase::$ClassFile['vouchergrpdatagrid'] = __META_CONTROLS__ . '/VoucherGrpDataGrid.class.php';

	// ClassPaths for the VoucherHasItem class
		QApplicationBase::$ClassFile['voucherhasitem'] = __MODEL__ . '/VoucherHasItem.class.php';
		QApplicationBase::$ClassFile['qqnodevoucherhasitem'] = __MODEL__ . '/VoucherHasItem.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodevoucherhasitem'] = __MODEL__ . '/VoucherHasItem.class.php';
		QApplicationBase::$ClassFile['voucherhasitemmetacontrol'] = __META_CONTROLS__ . '/VoucherHasItemMetaControl.class.php';
		QApplicationBase::$ClassFile['voucherhasitemdatagrid'] = __META_CONTROLS__ . '/VoucherHasItemDataGrid.class.php';

	// ClassPaths for the YearlySubject class
		QApplicationBase::$ClassFile['yearlysubject'] = __MODEL__ . '/YearlySubject.class.php';
		QApplicationBase::$ClassFile['qqnodeyearlysubject'] = __MODEL__ . '/YearlySubject.class.php';
		QApplicationBase::$ClassFile['qqreversereferencenodeyearlysubject'] = __MODEL__ . '/YearlySubject.class.php';
		QApplicationBase::$ClassFile['yearlysubjectmetacontrol'] = __META_CONTROLS__ . '/YearlySubjectMetaControl.class.php';
		QApplicationBase::$ClassFile['yearlysubjectdatagrid'] = __META_CONTROLS__ . '/YearlySubjectDataGrid.class.php';

?>