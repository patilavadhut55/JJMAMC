<?php
	/**
	 * The abstract YearlySubjectGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the YearlySubject subclass which
	 * extends this YearlySubjectGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the YearlySubject class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdyearlySubject the value for intIdyearlySubject (Read-Only PK)
	 * @property string $Code the value for strCode (Unique)
	 * @property integer $Subject the value for intSubject (Not Null)
	 * @property integer $DeptYear the value for intDeptYear (Not Null)
	 * @property integer $Lab the value for intLab 
	 * @property integer $Tusion the value for intTusion 
	 * @property integer $Practical the value for intPractical 
	 * @property integer $Credit the value for intCredit 
	 * @property integer $CourseGrp the value for intCourseGrp 
	 * @property integer $MinPassing the value for intMinPassing 
	 * @property integer $Parrent the value for intParrent 
	 * @property Subject $SubjectObject the value for the Subject object referenced by intSubject (Not Null)
	 * @property DeptYear $DeptYearObject the value for the DeptYear object referenced by intDeptYear (Not Null)
	 * @property CourseGrp $CourseGrpObject the value for the CourseGrp object referenced by intCourseGrp 
	 * @property YearlySubject $ParrentObject the value for the YearlySubject object referenced by intParrent 
	 * @property-read DeptYearExam $_DeptYearExam the value for the private _objDeptYearExam (Read-Only) if set due to an expansion on the dept_year_exam.yearly_subject reverse relationship
	 * @property-read DeptYearExam[] $_DeptYearExamArray the value for the private _objDeptYearExamArray (Read-Only) if set due to an ExpandAsArray on the dept_year_exam.yearly_subject reverse relationship
	 * @property-read YearlySubject $_YearlySubjectAsParrent the value for the private _objYearlySubjectAsParrent (Read-Only) if set due to an expansion on the yearly_subject.parrent reverse relationship
	 * @property-read YearlySubject[] $_YearlySubjectAsParrentArray the value for the private _objYearlySubjectAsParrentArray (Read-Only) if set due to an ExpandAsArray on the yearly_subject.parrent reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class YearlySubjectGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column yearly_subject.idyearly_subject
		 * @var integer intIdyearlySubject
		 */
		protected $intIdyearlySubject;
		const IdyearlySubjectDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.code
		 * @var string strCode
		 */
		protected $strCode;
		const CodeMaxLength = 45;
		const CodeDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.subject
		 * @var integer intSubject
		 */
		protected $intSubject;
		const SubjectDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.dept_year
		 * @var integer intDeptYear
		 */
		protected $intDeptYear;
		const DeptYearDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.lab
		 * @var integer intLab
		 */
		protected $intLab;
		const LabDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.tusion
		 * @var integer intTusion
		 */
		protected $intTusion;
		const TusionDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.practical
		 * @var integer intPractical
		 */
		protected $intPractical;
		const PracticalDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.credit
		 * @var integer intCredit
		 */
		protected $intCredit;
		const CreditDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.course_grp
		 * @var integer intCourseGrp
		 */
		protected $intCourseGrp;
		const CourseGrpDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.min_passing
		 * @var integer intMinPassing
		 */
		protected $intMinPassing;
		const MinPassingDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.parrent
		 * @var integer intParrent
		 */
		protected $intParrent;
		const ParrentDefault = null;


		/**
		 * Private member variable that stores a reference to a single DeptYearExam object
		 * (of type DeptYearExam), if this YearlySubject object was restored with
		 * an expansion on the dept_year_exam association table.
		 * @var DeptYearExam _objDeptYearExam;
		 */
		private $_objDeptYearExam;

		/**
		 * Private member variable that stores a reference to an array of DeptYearExam objects
		 * (of type DeptYearExam[]), if this YearlySubject object was restored with
		 * an ExpandAsArray on the dept_year_exam association table.
		 * @var DeptYearExam[] _objDeptYearExamArray;
		 */
		private $_objDeptYearExamArray = null;

		/**
		 * Private member variable that stores a reference to a single YearlySubjectAsParrent object
		 * (of type YearlySubject), if this YearlySubject object was restored with
		 * an expansion on the yearly_subject association table.
		 * @var YearlySubject _objYearlySubjectAsParrent;
		 */
		private $_objYearlySubjectAsParrent;

		/**
		 * Private member variable that stores a reference to an array of YearlySubjectAsParrent objects
		 * (of type YearlySubject[]), if this YearlySubject object was restored with
		 * an ExpandAsArray on the yearly_subject association table.
		 * @var YearlySubject[] _objYearlySubjectAsParrentArray;
		 */
		private $_objYearlySubjectAsParrentArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column yearly_subject.subject.
		 *
		 * NOTE: Always use the SubjectObject property getter to correctly retrieve this Subject object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Subject objSubjectObject
		 */
		protected $objSubjectObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column yearly_subject.dept_year.
		 *
		 * NOTE: Always use the DeptYearObject property getter to correctly retrieve this DeptYear object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var DeptYear objDeptYearObject
		 */
		protected $objDeptYearObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column yearly_subject.course_grp.
		 *
		 * NOTE: Always use the CourseGrpObject property getter to correctly retrieve this CourseGrp object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var CourseGrp objCourseGrpObject
		 */
		protected $objCourseGrpObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column yearly_subject.parrent.
		 *
		 * NOTE: Always use the ParrentObject property getter to correctly retrieve this YearlySubject object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var YearlySubject objParrentObject
		 */
		protected $objParrentObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdyearlySubject = YearlySubject::IdyearlySubjectDefault;
			$this->strCode = YearlySubject::CodeDefault;
			$this->intSubject = YearlySubject::SubjectDefault;
			$this->intDeptYear = YearlySubject::DeptYearDefault;
			$this->intLab = YearlySubject::LabDefault;
			$this->intTusion = YearlySubject::TusionDefault;
			$this->intPractical = YearlySubject::PracticalDefault;
			$this->intCredit = YearlySubject::CreditDefault;
			$this->intCourseGrp = YearlySubject::CourseGrpDefault;
			$this->intMinPassing = YearlySubject::MinPassingDefault;
			$this->intParrent = YearlySubject::ParrentDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a YearlySubject from PK Info
		 * @param integer $intIdyearlySubject
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject
		 */
		public static function Load($intIdyearlySubject, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'YearlySubject', $intIdyearlySubject);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = YearlySubject::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::YearlySubject()->IdyearlySubject, $intIdyearlySubject)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all YearlySubjects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call YearlySubject::QueryArray to perform the LoadAll query
			try {
				return YearlySubject::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all YearlySubjects
		 * @return int
		 */
		public static function CountAll() {
			// Call YearlySubject::QueryCount to perform the CountAll query
			return YearlySubject::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Create/Build out the QueryBuilder object with YearlySubject-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'yearly_subject');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				YearlySubject::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('yearly_subject');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single YearlySubject object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return YearlySubject the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = YearlySubject::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new YearlySubject object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = YearlySubject::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return YearlySubject::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of YearlySubject objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return YearlySubject[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = YearlySubject::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return YearlySubject::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = YearlySubject::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of YearlySubject objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = YearlySubject::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			$strQuery = YearlySubject::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/yearlysubject', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = YearlySubject::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this YearlySubject
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'yearly_subject';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idyearly_subject', $strAliasPrefix . 'idyearly_subject');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idyearly_subject', $strAliasPrefix . 'idyearly_subject');
			    $objBuilder->AddSelectItem($strTableName, 'code', $strAliasPrefix . 'code');
			    $objBuilder->AddSelectItem($strTableName, 'subject', $strAliasPrefix . 'subject');
			    $objBuilder->AddSelectItem($strTableName, 'dept_year', $strAliasPrefix . 'dept_year');
			    $objBuilder->AddSelectItem($strTableName, 'lab', $strAliasPrefix . 'lab');
			    $objBuilder->AddSelectItem($strTableName, 'tusion', $strAliasPrefix . 'tusion');
			    $objBuilder->AddSelectItem($strTableName, 'practical', $strAliasPrefix . 'practical');
			    $objBuilder->AddSelectItem($strTableName, 'credit', $strAliasPrefix . 'credit');
			    $objBuilder->AddSelectItem($strTableName, 'course_grp', $strAliasPrefix . 'course_grp');
			    $objBuilder->AddSelectItem($strTableName, 'min_passing', $strAliasPrefix . 'min_passing');
			    $objBuilder->AddSelectItem($strTableName, 'parrent', $strAliasPrefix . 'parrent');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a YearlySubject from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this YearlySubject::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return YearlySubject
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idyearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdyearlySubject == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'yearly_subject__';


						// Expanding reverse references: DeptYearExam
						$strAlias = $strAliasPrefix . 'deptyearexam__yearly_subject';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objDeptYearExamArray)
								$objPreviousItem->_objDeptYearExamArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objDeptYearExamArray)) {
								$objPreviousChildItems = $objPreviousItem->_objDeptYearExamArray;
								$objChildItem = DeptYearExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearexam__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objDeptYearExamArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objDeptYearExamArray[] = DeptYearExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearexam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: YearlySubjectAsParrent
						$strAlias = $strAliasPrefix . 'yearlysubjectasparrent__idyearly_subject';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objYearlySubjectAsParrentArray)
								$objPreviousItem->_objYearlySubjectAsParrentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objYearlySubjectAsParrentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objYearlySubjectAsParrentArray;
								$objChildItem = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearlysubjectasparrent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objYearlySubjectAsParrentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objYearlySubjectAsParrentArray[] = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearlysubjectasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'yearly_subject__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the YearlySubject object
			$objToReturn = new YearlySubject();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idyearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdyearlySubject = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSubject = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'dept_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDeptYear = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'lab';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intLab = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'tusion';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intTusion = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'practical';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intPractical = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'credit';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCredit = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'course_grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCourseGrp = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'min_passing';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMinPassing = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'parrent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intParrent = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdyearlySubject != $objPreviousItem->IdyearlySubject) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objDeptYearExamArray);
					$cnt = count($objToReturn->_objDeptYearExamArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objDeptYearExamArray, $objToReturn->_objDeptYearExamArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objYearlySubjectAsParrentArray);
					$cnt = count($objToReturn->_objYearlySubjectAsParrentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objYearlySubjectAsParrentArray, $objToReturn->_objYearlySubjectAsParrentArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'yearly_subject__';

			// Check for SubjectObject Early Binding
			$strAlias = $strAliasPrefix . 'subject__idsubject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSubjectObject = Subject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'subject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DeptYearObject Early Binding
			$strAlias = $strAliasPrefix . 'dept_year__iddept_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDeptYearObject = DeptYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'dept_year__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CourseGrpObject Early Binding
			$strAlias = $strAliasPrefix . 'course_grp__idcourse_grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCourseGrpObject = CourseGrp::InstantiateDbRow($objDbRow, $strAliasPrefix . 'course_grp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ParrentObject Early Binding
			$strAlias = $strAliasPrefix . 'parrent__idyearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objParrentObject = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'parrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for DeptYearExam Virtual Binding
			$strAlias = $strAliasPrefix . 'deptyearexam__yearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objDeptYearExamArray)
				$objToReturn->_objDeptYearExamArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objDeptYearExamArray[] = DeptYearExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearexam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objDeptYearExam = DeptYearExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearexam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for YearlySubjectAsParrent Virtual Binding
			$strAlias = $strAliasPrefix . 'yearlysubjectasparrent__idyearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objYearlySubjectAsParrentArray)
				$objToReturn->_objYearlySubjectAsParrentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objYearlySubjectAsParrentArray[] = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearlysubjectasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objYearlySubjectAsParrent = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearlysubjectasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of YearlySubjects from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return YearlySubject[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = YearlySubject::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = YearlySubject::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single YearlySubject object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return YearlySubject next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return YearlySubject::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single YearlySubject object,
		 * by IdyearlySubject Index(es)
		 * @param integer $intIdyearlySubject
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject
		*/
		public static function LoadByIdyearlySubject($intIdyearlySubject, $objOptionalClauses = null) {
			return YearlySubject::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::YearlySubject()->IdyearlySubject, $intIdyearlySubject)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single YearlySubject object,
		 * by Code Index(es)
		 * @param string $strCode
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject
		*/
		public static function LoadByCode($strCode, $objOptionalClauses = null) {
			return YearlySubject::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::YearlySubject()->Code, $strCode)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of YearlySubject objects,
		 * by DeptYear Index(es)
		 * @param integer $intDeptYear
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject[]
		*/
		public static function LoadArrayByDeptYear($intDeptYear, $objOptionalClauses = null) {
			// Call YearlySubject::QueryArray to perform the LoadArrayByDeptYear query
			try {
				return YearlySubject::QueryArray(
					QQ::Equal(QQN::YearlySubject()->DeptYear, $intDeptYear),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count YearlySubjects
		 * by DeptYear Index(es)
		 * @param integer $intDeptYear
		 * @return int
		*/
		public static function CountByDeptYear($intDeptYear) {
			// Call YearlySubject::QueryCount to perform the CountByDeptYear query
			return YearlySubject::QueryCount(
				QQ::Equal(QQN::YearlySubject()->DeptYear, $intDeptYear)
			);
		}

		/**
		 * Load an array of YearlySubject objects,
		 * by Subject Index(es)
		 * @param integer $intSubject
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject[]
		*/
		public static function LoadArrayBySubject($intSubject, $objOptionalClauses = null) {
			// Call YearlySubject::QueryArray to perform the LoadArrayBySubject query
			try {
				return YearlySubject::QueryArray(
					QQ::Equal(QQN::YearlySubject()->Subject, $intSubject),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count YearlySubjects
		 * by Subject Index(es)
		 * @param integer $intSubject
		 * @return int
		*/
		public static function CountBySubject($intSubject) {
			// Call YearlySubject::QueryCount to perform the CountBySubject query
			return YearlySubject::QueryCount(
				QQ::Equal(QQN::YearlySubject()->Subject, $intSubject)
			);
		}

		/**
		 * Load an array of YearlySubject objects,
		 * by CourseGrp Index(es)
		 * @param integer $intCourseGrp
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject[]
		*/
		public static function LoadArrayByCourseGrp($intCourseGrp, $objOptionalClauses = null) {
			// Call YearlySubject::QueryArray to perform the LoadArrayByCourseGrp query
			try {
				return YearlySubject::QueryArray(
					QQ::Equal(QQN::YearlySubject()->CourseGrp, $intCourseGrp),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count YearlySubjects
		 * by CourseGrp Index(es)
		 * @param integer $intCourseGrp
		 * @return int
		*/
		public static function CountByCourseGrp($intCourseGrp) {
			// Call YearlySubject::QueryCount to perform the CountByCourseGrp query
			return YearlySubject::QueryCount(
				QQ::Equal(QQN::YearlySubject()->CourseGrp, $intCourseGrp)
			);
		}

		/**
		 * Load an array of YearlySubject objects,
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject[]
		*/
		public static function LoadArrayByParrent($intParrent, $objOptionalClauses = null) {
			// Call YearlySubject::QueryArray to perform the LoadArrayByParrent query
			try {
				return YearlySubject::QueryArray(
					QQ::Equal(QQN::YearlySubject()->Parrent, $intParrent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count YearlySubjects
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @return int
		*/
		public static function CountByParrent($intParrent) {
			// Call YearlySubject::QueryCount to perform the CountByParrent query
			return YearlySubject::QueryCount(
				QQ::Equal(QQN::YearlySubject()->Parrent, $intParrent)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this YearlySubject
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `yearly_subject` (
							`code`,
							`subject`,
							`dept_year`,
							`lab`,
							`tusion`,
							`practical`,
							`credit`,
							`course_grp`,
							`min_passing`,
							`parrent`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strCode) . ',
							' . $objDatabase->SqlVariable($this->intSubject) . ',
							' . $objDatabase->SqlVariable($this->intDeptYear) . ',
							' . $objDatabase->SqlVariable($this->intLab) . ',
							' . $objDatabase->SqlVariable($this->intTusion) . ',
							' . $objDatabase->SqlVariable($this->intPractical) . ',
							' . $objDatabase->SqlVariable($this->intCredit) . ',
							' . $objDatabase->SqlVariable($this->intCourseGrp) . ',
							' . $objDatabase->SqlVariable($this->intMinPassing) . ',
							' . $objDatabase->SqlVariable($this->intParrent) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdyearlySubject = $objDatabase->InsertId('yearly_subject', 'idyearly_subject');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`yearly_subject`
						SET
							`code` = ' . $objDatabase->SqlVariable($this->strCode) . ',
							`subject` = ' . $objDatabase->SqlVariable($this->intSubject) . ',
							`dept_year` = ' . $objDatabase->SqlVariable($this->intDeptYear) . ',
							`lab` = ' . $objDatabase->SqlVariable($this->intLab) . ',
							`tusion` = ' . $objDatabase->SqlVariable($this->intTusion) . ',
							`practical` = ' . $objDatabase->SqlVariable($this->intPractical) . ',
							`credit` = ' . $objDatabase->SqlVariable($this->intCredit) . ',
							`course_grp` = ' . $objDatabase->SqlVariable($this->intCourseGrp) . ',
							`min_passing` = ' . $objDatabase->SqlVariable($this->intMinPassing) . ',
							`parrent` = ' . $objDatabase->SqlVariable($this->intParrent) . '
						WHERE
							`idyearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this YearlySubject
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this YearlySubject with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`yearly_subject`
				WHERE
					`idyearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this YearlySubject ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'YearlySubject', $this->intIdyearlySubject);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all YearlySubjects
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`yearly_subject`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate yearly_subject table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `yearly_subject`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this YearlySubject from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved YearlySubject object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = YearlySubject::Load($this->intIdyearlySubject);

			// Update $this's local variables to match
			$this->strCode = $objReloaded->strCode;
			$this->Subject = $objReloaded->Subject;
			$this->DeptYear = $objReloaded->DeptYear;
			$this->intLab = $objReloaded->intLab;
			$this->intTusion = $objReloaded->intTusion;
			$this->intPractical = $objReloaded->intPractical;
			$this->intCredit = $objReloaded->intCredit;
			$this->CourseGrp = $objReloaded->CourseGrp;
			$this->intMinPassing = $objReloaded->intMinPassing;
			$this->Parrent = $objReloaded->Parrent;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdyearlySubject':
					/**
					 * Gets the value for intIdyearlySubject (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdyearlySubject;

				case 'Code':
					/**
					 * Gets the value for strCode (Unique)
					 * @return string
					 */
					return $this->strCode;

				case 'Subject':
					/**
					 * Gets the value for intSubject (Not Null)
					 * @return integer
					 */
					return $this->intSubject;

				case 'DeptYear':
					/**
					 * Gets the value for intDeptYear (Not Null)
					 * @return integer
					 */
					return $this->intDeptYear;

				case 'Lab':
					/**
					 * Gets the value for intLab 
					 * @return integer
					 */
					return $this->intLab;

				case 'Tusion':
					/**
					 * Gets the value for intTusion 
					 * @return integer
					 */
					return $this->intTusion;

				case 'Practical':
					/**
					 * Gets the value for intPractical 
					 * @return integer
					 */
					return $this->intPractical;

				case 'Credit':
					/**
					 * Gets the value for intCredit 
					 * @return integer
					 */
					return $this->intCredit;

				case 'CourseGrp':
					/**
					 * Gets the value for intCourseGrp 
					 * @return integer
					 */
					return $this->intCourseGrp;

				case 'MinPassing':
					/**
					 * Gets the value for intMinPassing 
					 * @return integer
					 */
					return $this->intMinPassing;

				case 'Parrent':
					/**
					 * Gets the value for intParrent 
					 * @return integer
					 */
					return $this->intParrent;


				///////////////////
				// Member Objects
				///////////////////
				case 'SubjectObject':
					/**
					 * Gets the value for the Subject object referenced by intSubject (Not Null)
					 * @return Subject
					 */
					try {
						if ((!$this->objSubjectObject) && (!is_null($this->intSubject)))
							$this->objSubjectObject = Subject::Load($this->intSubject);
						return $this->objSubjectObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DeptYearObject':
					/**
					 * Gets the value for the DeptYear object referenced by intDeptYear (Not Null)
					 * @return DeptYear
					 */
					try {
						if ((!$this->objDeptYearObject) && (!is_null($this->intDeptYear)))
							$this->objDeptYearObject = DeptYear::Load($this->intDeptYear);
						return $this->objDeptYearObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CourseGrpObject':
					/**
					 * Gets the value for the CourseGrp object referenced by intCourseGrp 
					 * @return CourseGrp
					 */
					try {
						if ((!$this->objCourseGrpObject) && (!is_null($this->intCourseGrp)))
							$this->objCourseGrpObject = CourseGrp::Load($this->intCourseGrp);
						return $this->objCourseGrpObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ParrentObject':
					/**
					 * Gets the value for the YearlySubject object referenced by intParrent 
					 * @return YearlySubject
					 */
					try {
						if ((!$this->objParrentObject) && (!is_null($this->intParrent)))
							$this->objParrentObject = YearlySubject::Load($this->intParrent);
						return $this->objParrentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_DeptYearExam':
					/**
					 * Gets the value for the private _objDeptYearExam (Read-Only)
					 * if set due to an expansion on the dept_year_exam.yearly_subject reverse relationship
					 * @return DeptYearExam
					 */
					return $this->_objDeptYearExam;

				case '_DeptYearExamArray':
					/**
					 * Gets the value for the private _objDeptYearExamArray (Read-Only)
					 * if set due to an ExpandAsArray on the dept_year_exam.yearly_subject reverse relationship
					 * @return DeptYearExam[]
					 */
					return $this->_objDeptYearExamArray;

				case '_YearlySubjectAsParrent':
					/**
					 * Gets the value for the private _objYearlySubjectAsParrent (Read-Only)
					 * if set due to an expansion on the yearly_subject.parrent reverse relationship
					 * @return YearlySubject
					 */
					return $this->_objYearlySubjectAsParrent;

				case '_YearlySubjectAsParrentArray':
					/**
					 * Gets the value for the private _objYearlySubjectAsParrentArray (Read-Only)
					 * if set due to an ExpandAsArray on the yearly_subject.parrent reverse relationship
					 * @return YearlySubject[]
					 */
					return $this->_objYearlySubjectAsParrentArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Code':
					/**
					 * Sets the value for strCode (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Subject':
					/**
					 * Sets the value for intSubject (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSubjectObject = null;
						return ($this->intSubject = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DeptYear':
					/**
					 * Sets the value for intDeptYear (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDeptYearObject = null;
						return ($this->intDeptYear = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Lab':
					/**
					 * Sets the value for intLab 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intLab = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Tusion':
					/**
					 * Sets the value for intTusion 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intTusion = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Practical':
					/**
					 * Sets the value for intPractical 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intPractical = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Credit':
					/**
					 * Sets the value for intCredit 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intCredit = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CourseGrp':
					/**
					 * Sets the value for intCourseGrp 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCourseGrpObject = null;
						return ($this->intCourseGrp = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'MinPassing':
					/**
					 * Sets the value for intMinPassing 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intMinPassing = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Parrent':
					/**
					 * Sets the value for intParrent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objParrentObject = null;
						return ($this->intParrent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'SubjectObject':
					/**
					 * Sets the value for the Subject object referenced by intSubject (Not Null)
					 * @param Subject $mixValue
					 * @return Subject
					 */
					if (is_null($mixValue)) {
						$this->intSubject = null;
						$this->objSubjectObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Subject object
						try {
							$mixValue = QType::Cast($mixValue, 'Subject');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Subject object
						if (is_null($mixValue->Idsubject))
							throw new QCallerException('Unable to set an unsaved SubjectObject for this YearlySubject');

						// Update Local Member Variables
						$this->objSubjectObject = $mixValue;
						$this->intSubject = $mixValue->Idsubject;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DeptYearObject':
					/**
					 * Sets the value for the DeptYear object referenced by intDeptYear (Not Null)
					 * @param DeptYear $mixValue
					 * @return DeptYear
					 */
					if (is_null($mixValue)) {
						$this->intDeptYear = null;
						$this->objDeptYearObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a DeptYear object
						try {
							$mixValue = QType::Cast($mixValue, 'DeptYear');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED DeptYear object
						if (is_null($mixValue->IddeptYear))
							throw new QCallerException('Unable to set an unsaved DeptYearObject for this YearlySubject');

						// Update Local Member Variables
						$this->objDeptYearObject = $mixValue;
						$this->intDeptYear = $mixValue->IddeptYear;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CourseGrpObject':
					/**
					 * Sets the value for the CourseGrp object referenced by intCourseGrp 
					 * @param CourseGrp $mixValue
					 * @return CourseGrp
					 */
					if (is_null($mixValue)) {
						$this->intCourseGrp = null;
						$this->objCourseGrpObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a CourseGrp object
						try {
							$mixValue = QType::Cast($mixValue, 'CourseGrp');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED CourseGrp object
						if (is_null($mixValue->IdcourseGrp))
							throw new QCallerException('Unable to set an unsaved CourseGrpObject for this YearlySubject');

						// Update Local Member Variables
						$this->objCourseGrpObject = $mixValue;
						$this->intCourseGrp = $mixValue->IdcourseGrp;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ParrentObject':
					/**
					 * Sets the value for the YearlySubject object referenced by intParrent 
					 * @param YearlySubject $mixValue
					 * @return YearlySubject
					 */
					if (is_null($mixValue)) {
						$this->intParrent = null;
						$this->objParrentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a YearlySubject object
						try {
							$mixValue = QType::Cast($mixValue, 'YearlySubject');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED YearlySubject object
						if (is_null($mixValue->IdyearlySubject))
							throw new QCallerException('Unable to set an unsaved ParrentObject for this YearlySubject');

						// Update Local Member Variables
						$this->objParrentObject = $mixValue;
						$this->intParrent = $mixValue->IdyearlySubject;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for DeptYearExam
		//-------------------------------------------------------------------

		/**
		 * Gets all associated DeptYearExams as an array of DeptYearExam objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearExam[]
		*/
		public function GetDeptYearExamArray($objOptionalClauses = null) {
			if ((is_null($this->intIdyearlySubject)))
				return array();

			try {
				return DeptYearExam::LoadArrayByYearlySubject($this->intIdyearlySubject, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated DeptYearExams
		 * @return int
		*/
		public function CountDeptYearExams() {
			if ((is_null($this->intIdyearlySubject)))
				return 0;

			return DeptYearExam::CountByYearlySubject($this->intIdyearlySubject);
		}

		/**
		 * Associates a DeptYearExam
		 * @param DeptYearExam $objDeptYearExam
		 * @return void
		*/
		public function AssociateDeptYearExam(DeptYearExam $objDeptYearExam) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearExam on this unsaved YearlySubject.');
			if ((is_null($objDeptYearExam->YearlySubject)) || (is_null($objDeptYearExam->Exam)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearExam on this YearlySubject with an unsaved DeptYearExam.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_exam`
				SET
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($objDeptYearExam->YearlySubject) . ' AND
					`exam` = ' . $objDatabase->SqlVariable($objDeptYearExam->Exam) . '
			');
		}

		/**
		 * Unassociates a DeptYearExam
		 * @param DeptYearExam $objDeptYearExam
		 * @return void
		*/
		public function UnassociateDeptYearExam(DeptYearExam $objDeptYearExam) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearExam on this unsaved YearlySubject.');
			if ((is_null($objDeptYearExam->YearlySubject)) || (is_null($objDeptYearExam->Exam)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearExam on this YearlySubject with an unsaved DeptYearExam.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_exam`
				SET
					`yearly_subject` = null
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($objDeptYearExam->YearlySubject) . ' AND
					`exam` = ' . $objDatabase->SqlVariable($objDeptYearExam->Exam) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Unassociates all DeptYearExams
		 * @return void
		*/
		public function UnassociateAllDeptYearExams() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearExam on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_exam`
				SET
					`yearly_subject` = null
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes an associated DeptYearExam
		 * @param DeptYearExam $objDeptYearExam
		 * @return void
		*/
		public function DeleteAssociatedDeptYearExam(DeptYearExam $objDeptYearExam) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearExam on this unsaved YearlySubject.');
			if ((is_null($objDeptYearExam->YearlySubject)) || (is_null($objDeptYearExam->Exam)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearExam on this YearlySubject with an unsaved DeptYearExam.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_exam`
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($objDeptYearExam->YearlySubject) . ' AND
					`exam` = ' . $objDatabase->SqlVariable($objDeptYearExam->Exam) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes all associated DeptYearExams
		 * @return void
		*/
		public function DeleteAllDeptYearExams() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearExam on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_exam`
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}


		// Related Objects' Methods for YearlySubjectAsParrent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated YearlySubjectsAsParrent as an array of YearlySubject objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject[]
		*/
		public function GetYearlySubjectAsParrentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdyearlySubject)))
				return array();

			try {
				return YearlySubject::LoadArrayByParrent($this->intIdyearlySubject, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated YearlySubjectsAsParrent
		 * @return int
		*/
		public function CountYearlySubjectsAsParrent() {
			if ((is_null($this->intIdyearlySubject)))
				return 0;

			return YearlySubject::CountByParrent($this->intIdyearlySubject);
		}

		/**
		 * Associates a YearlySubjectAsParrent
		 * @param YearlySubject $objYearlySubject
		 * @return void
		*/
		public function AssociateYearlySubjectAsParrent(YearlySubject $objYearlySubject) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateYearlySubjectAsParrent on this unsaved YearlySubject.');
			if ((is_null($objYearlySubject->IdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateYearlySubjectAsParrent on this YearlySubject with an unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`yearly_subject`
				SET
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
				WHERE
					`idyearly_subject` = ' . $objDatabase->SqlVariable($objYearlySubject->IdyearlySubject) . '
			');
		}

		/**
		 * Unassociates a YearlySubjectAsParrent
		 * @param YearlySubject $objYearlySubject
		 * @return void
		*/
		public function UnassociateYearlySubjectAsParrent(YearlySubject $objYearlySubject) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubjectAsParrent on this unsaved YearlySubject.');
			if ((is_null($objYearlySubject->IdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubjectAsParrent on this YearlySubject with an unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`yearly_subject`
				SET
					`parrent` = null
				WHERE
					`idyearly_subject` = ' . $objDatabase->SqlVariable($objYearlySubject->IdyearlySubject) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Unassociates all YearlySubjectsAsParrent
		 * @return void
		*/
		public function UnassociateAllYearlySubjectsAsParrent() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubjectAsParrent on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`yearly_subject`
				SET
					`parrent` = null
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes an associated YearlySubjectAsParrent
		 * @param YearlySubject $objYearlySubject
		 * @return void
		*/
		public function DeleteAssociatedYearlySubjectAsParrent(YearlySubject $objYearlySubject) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubjectAsParrent on this unsaved YearlySubject.');
			if ((is_null($objYearlySubject->IdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubjectAsParrent on this YearlySubject with an unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`yearly_subject`
				WHERE
					`idyearly_subject` = ' . $objDatabase->SqlVariable($objYearlySubject->IdyearlySubject) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes all associated YearlySubjectsAsParrent
		 * @return void
		*/
		public function DeleteAllYearlySubjectsAsParrent() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubjectAsParrent on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`yearly_subject`
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "yearly_subject";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[YearlySubject::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="YearlySubject"><sequence>';
			$strToReturn .= '<element name="IdyearlySubject" type="xsd:int"/>';
			$strToReturn .= '<element name="Code" type="xsd:string"/>';
			$strToReturn .= '<element name="SubjectObject" type="xsd1:Subject"/>';
			$strToReturn .= '<element name="DeptYearObject" type="xsd1:DeptYear"/>';
			$strToReturn .= '<element name="Lab" type="xsd:int"/>';
			$strToReturn .= '<element name="Tusion" type="xsd:int"/>';
			$strToReturn .= '<element name="Practical" type="xsd:int"/>';
			$strToReturn .= '<element name="Credit" type="xsd:int"/>';
			$strToReturn .= '<element name="CourseGrpObject" type="xsd1:CourseGrp"/>';
			$strToReturn .= '<element name="MinPassing" type="xsd:int"/>';
			$strToReturn .= '<element name="ParrentObject" type="xsd1:YearlySubject"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('YearlySubject', $strComplexTypeArray)) {
				$strComplexTypeArray['YearlySubject'] = YearlySubject::GetSoapComplexTypeXml();
				Subject::AlterSoapComplexTypeArray($strComplexTypeArray);
				DeptYear::AlterSoapComplexTypeArray($strComplexTypeArray);
				CourseGrp::AlterSoapComplexTypeArray($strComplexTypeArray);
				YearlySubject::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, YearlySubject::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new YearlySubject();
			if (property_exists($objSoapObject, 'IdyearlySubject'))
				$objToReturn->intIdyearlySubject = $objSoapObject->IdyearlySubject;
			if (property_exists($objSoapObject, 'Code'))
				$objToReturn->strCode = $objSoapObject->Code;
			if ((property_exists($objSoapObject, 'SubjectObject')) &&
				($objSoapObject->SubjectObject))
				$objToReturn->SubjectObject = Subject::GetObjectFromSoapObject($objSoapObject->SubjectObject);
			if ((property_exists($objSoapObject, 'DeptYearObject')) &&
				($objSoapObject->DeptYearObject))
				$objToReturn->DeptYearObject = DeptYear::GetObjectFromSoapObject($objSoapObject->DeptYearObject);
			if (property_exists($objSoapObject, 'Lab'))
				$objToReturn->intLab = $objSoapObject->Lab;
			if (property_exists($objSoapObject, 'Tusion'))
				$objToReturn->intTusion = $objSoapObject->Tusion;
			if (property_exists($objSoapObject, 'Practical'))
				$objToReturn->intPractical = $objSoapObject->Practical;
			if (property_exists($objSoapObject, 'Credit'))
				$objToReturn->intCredit = $objSoapObject->Credit;
			if ((property_exists($objSoapObject, 'CourseGrpObject')) &&
				($objSoapObject->CourseGrpObject))
				$objToReturn->CourseGrpObject = CourseGrp::GetObjectFromSoapObject($objSoapObject->CourseGrpObject);
			if (property_exists($objSoapObject, 'MinPassing'))
				$objToReturn->intMinPassing = $objSoapObject->MinPassing;
			if ((property_exists($objSoapObject, 'ParrentObject')) &&
				($objSoapObject->ParrentObject))
				$objToReturn->ParrentObject = YearlySubject::GetObjectFromSoapObject($objSoapObject->ParrentObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, YearlySubject::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objSubjectObject)
				$objObject->objSubjectObject = Subject::GetSoapObjectFromObject($objObject->objSubjectObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSubject = null;
			if ($objObject->objDeptYearObject)
				$objObject->objDeptYearObject = DeptYear::GetSoapObjectFromObject($objObject->objDeptYearObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDeptYear = null;
			if ($objObject->objCourseGrpObject)
				$objObject->objCourseGrpObject = CourseGrp::GetSoapObjectFromObject($objObject->objCourseGrpObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCourseGrp = null;
			if ($objObject->objParrentObject)
				$objObject->objParrentObject = YearlySubject::GetSoapObjectFromObject($objObject->objParrentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intParrent = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdyearlySubject'] = $this->intIdyearlySubject;
			$iArray['Code'] = $this->strCode;
			$iArray['Subject'] = $this->intSubject;
			$iArray['DeptYear'] = $this->intDeptYear;
			$iArray['Lab'] = $this->intLab;
			$iArray['Tusion'] = $this->intTusion;
			$iArray['Practical'] = $this->intPractical;
			$iArray['Credit'] = $this->intCredit;
			$iArray['CourseGrp'] = $this->intCourseGrp;
			$iArray['MinPassing'] = $this->intMinPassing;
			$iArray['Parrent'] = $this->intParrent;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdyearlySubject ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdyearlySubject
     * @property-read QQNode $Code
     * @property-read QQNode $Subject
     * @property-read QQNodeSubject $SubjectObject
     * @property-read QQNode $DeptYear
     * @property-read QQNodeDeptYear $DeptYearObject
     * @property-read QQNode $Lab
     * @property-read QQNode $Tusion
     * @property-read QQNode $Practical
     * @property-read QQNode $Credit
     * @property-read QQNode $CourseGrp
     * @property-read QQNodeCourseGrp $CourseGrpObject
     * @property-read QQNode $MinPassing
     * @property-read QQNode $Parrent
     * @property-read QQNodeYearlySubject $ParrentObject
     *
     *
     * @property-read QQReverseReferenceNodeDeptYearExam $DeptYearExam
     * @property-read QQReverseReferenceNodeYearlySubject $YearlySubjectAsParrent

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeYearlySubject extends QQNode {
		protected $strTableName = 'yearly_subject';
		protected $strPrimaryKey = 'idyearly_subject';
		protected $strClassName = 'YearlySubject';
		public function __get($strName) {
			switch ($strName) {
				case 'IdyearlySubject':
					return new QQNode('idyearly_subject', 'IdyearlySubject', 'Integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'VarChar', $this);
				case 'Subject':
					return new QQNode('subject', 'Subject', 'Integer', $this);
				case 'SubjectObject':
					return new QQNodeSubject('subject', 'SubjectObject', 'Integer', $this);
				case 'DeptYear':
					return new QQNode('dept_year', 'DeptYear', 'Integer', $this);
				case 'DeptYearObject':
					return new QQNodeDeptYear('dept_year', 'DeptYearObject', 'Integer', $this);
				case 'Lab':
					return new QQNode('lab', 'Lab', 'Integer', $this);
				case 'Tusion':
					return new QQNode('tusion', 'Tusion', 'Integer', $this);
				case 'Practical':
					return new QQNode('practical', 'Practical', 'Integer', $this);
				case 'Credit':
					return new QQNode('credit', 'Credit', 'Integer', $this);
				case 'CourseGrp':
					return new QQNode('course_grp', 'CourseGrp', 'Integer', $this);
				case 'CourseGrpObject':
					return new QQNodeCourseGrp('course_grp', 'CourseGrpObject', 'Integer', $this);
				case 'MinPassing':
					return new QQNode('min_passing', 'MinPassing', 'Integer', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'Integer', $this);
				case 'ParrentObject':
					return new QQNodeYearlySubject('parrent', 'ParrentObject', 'Integer', $this);
				case 'DeptYearExam':
					return new QQReverseReferenceNodeDeptYearExam($this, 'deptyearexam', 'reverse_reference', 'yearly_subject');
				case 'YearlySubjectAsParrent':
					return new QQReverseReferenceNodeYearlySubject($this, 'yearlysubjectasparrent', 'reverse_reference', 'parrent');

				case '_PrimaryKeyNode':
					return new QQNode('idyearly_subject', 'IdyearlySubject', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdyearlySubject
     * @property-read QQNode $Code
     * @property-read QQNode $Subject
     * @property-read QQNodeSubject $SubjectObject
     * @property-read QQNode $DeptYear
     * @property-read QQNodeDeptYear $DeptYearObject
     * @property-read QQNode $Lab
     * @property-read QQNode $Tusion
     * @property-read QQNode $Practical
     * @property-read QQNode $Credit
     * @property-read QQNode $CourseGrp
     * @property-read QQNodeCourseGrp $CourseGrpObject
     * @property-read QQNode $MinPassing
     * @property-read QQNode $Parrent
     * @property-read QQNodeYearlySubject $ParrentObject
     *
     *
     * @property-read QQReverseReferenceNodeDeptYearExam $DeptYearExam
     * @property-read QQReverseReferenceNodeYearlySubject $YearlySubjectAsParrent

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeYearlySubject extends QQReverseReferenceNode {
		protected $strTableName = 'yearly_subject';
		protected $strPrimaryKey = 'idyearly_subject';
		protected $strClassName = 'YearlySubject';
		public function __get($strName) {
			switch ($strName) {
				case 'IdyearlySubject':
					return new QQNode('idyearly_subject', 'IdyearlySubject', 'integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'string', $this);
				case 'Subject':
					return new QQNode('subject', 'Subject', 'integer', $this);
				case 'SubjectObject':
					return new QQNodeSubject('subject', 'SubjectObject', 'integer', $this);
				case 'DeptYear':
					return new QQNode('dept_year', 'DeptYear', 'integer', $this);
				case 'DeptYearObject':
					return new QQNodeDeptYear('dept_year', 'DeptYearObject', 'integer', $this);
				case 'Lab':
					return new QQNode('lab', 'Lab', 'integer', $this);
				case 'Tusion':
					return new QQNode('tusion', 'Tusion', 'integer', $this);
				case 'Practical':
					return new QQNode('practical', 'Practical', 'integer', $this);
				case 'Credit':
					return new QQNode('credit', 'Credit', 'integer', $this);
				case 'CourseGrp':
					return new QQNode('course_grp', 'CourseGrp', 'integer', $this);
				case 'CourseGrpObject':
					return new QQNodeCourseGrp('course_grp', 'CourseGrpObject', 'integer', $this);
				case 'MinPassing':
					return new QQNode('min_passing', 'MinPassing', 'integer', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'integer', $this);
				case 'ParrentObject':
					return new QQNodeYearlySubject('parrent', 'ParrentObject', 'integer', $this);
				case 'DeptYearExam':
					return new QQReverseReferenceNodeDeptYearExam($this, 'deptyearexam', 'reverse_reference', 'yearly_subject');
				case 'YearlySubjectAsParrent':
					return new QQReverseReferenceNodeYearlySubject($this, 'yearlysubjectasparrent', 'reverse_reference', 'parrent');

				case '_PrimaryKeyNode':
					return new QQNode('idyearly_subject', 'IdyearlySubject', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
