<?php
	/**
	 * The abstract SerialsGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Serials subclass which
	 * extends this SerialsGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Serials class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idserials the value for intIdserials (Read-Only PK)
	 * @property integer $Item the value for intItem (Not Null)
	 * @property string $Serial the value for strSerial (Not Null)
	 * @property integer $Iw the value for intIw 
	 * @property integer $Ow the value for intOw 
	 * @property integer $Sow the value for intSow 
	 * @property QDateTime $ExpiryDate the value for dttExpiryDate 
	 * @property integer $Pr the value for intPr 
	 * @property LedgerDetails $ItemObject the value for the LedgerDetails object referenced by intItem (Not Null)
	 * @property VoucherHasItem $IwObject the value for the VoucherHasItem object referenced by intIw 
	 * @property VoucherHasItem $OwObject the value for the VoucherHasItem object referenced by intOw 
	 * @property VoucherHasItem $SowObject the value for the VoucherHasItem object referenced by intSow 
	 * @property VoucherHasItem $PrObject the value for the VoucherHasItem object referenced by intPr 
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class SerialsGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column serials.idserials
		 * @var integer intIdserials
		 */
		protected $intIdserials;
		const IdserialsDefault = null;


		/**
		 * Protected member variable that maps to the database column serials.item
		 * @var integer intItem
		 */
		protected $intItem;
		const ItemDefault = null;


		/**
		 * Protected member variable that maps to the database column serials.serial
		 * @var string strSerial
		 */
		protected $strSerial;
		const SerialMaxLength = 45;
		const SerialDefault = null;


		/**
		 * Protected member variable that maps to the database column serials.iw
		 * @var integer intIw
		 */
		protected $intIw;
		const IwDefault = null;


		/**
		 * Protected member variable that maps to the database column serials.ow
		 * @var integer intOw
		 */
		protected $intOw;
		const OwDefault = null;


		/**
		 * Protected member variable that maps to the database column serials.sow
		 * @var integer intSow
		 */
		protected $intSow;
		const SowDefault = null;


		/**
		 * Protected member variable that maps to the database column serials.expiry_date
		 * @var QDateTime dttExpiryDate
		 */
		protected $dttExpiryDate;
		const ExpiryDateDefault = null;


		/**
		 * Protected member variable that maps to the database column serials.pr
		 * @var integer intPr
		 */
		protected $intPr;
		const PrDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column serials.item.
		 *
		 * NOTE: Always use the ItemObject property getter to correctly retrieve this LedgerDetails object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var LedgerDetails objItemObject
		 */
		protected $objItemObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column serials.iw.
		 *
		 * NOTE: Always use the IwObject property getter to correctly retrieve this VoucherHasItem object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var VoucherHasItem objIwObject
		 */
		protected $objIwObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column serials.ow.
		 *
		 * NOTE: Always use the OwObject property getter to correctly retrieve this VoucherHasItem object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var VoucherHasItem objOwObject
		 */
		protected $objOwObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column serials.sow.
		 *
		 * NOTE: Always use the SowObject property getter to correctly retrieve this VoucherHasItem object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var VoucherHasItem objSowObject
		 */
		protected $objSowObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column serials.pr.
		 *
		 * NOTE: Always use the PrObject property getter to correctly retrieve this VoucherHasItem object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var VoucherHasItem objPrObject
		 */
		protected $objPrObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdserials = Serials::IdserialsDefault;
			$this->intItem = Serials::ItemDefault;
			$this->strSerial = Serials::SerialDefault;
			$this->intIw = Serials::IwDefault;
			$this->intOw = Serials::OwDefault;
			$this->intSow = Serials::SowDefault;
			$this->dttExpiryDate = (Serials::ExpiryDateDefault === null)?null:new QDateTime(Serials::ExpiryDateDefault);
			$this->intPr = Serials::PrDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Serials from PK Info
		 * @param integer $intIdserials
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Serials
		 */
		public static function Load($intIdserials, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Serials', $intIdserials);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Serials::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Serials()->Idserials, $intIdserials)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Serialses
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Serials[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Serials::QueryArray to perform the LoadAll query
			try {
				return Serials::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Serialses
		 * @return int
		 */
		public static function CountAll() {
			// Call Serials::QueryCount to perform the CountAll query
			return Serials::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Serials::GetDatabase();

			// Create/Build out the QueryBuilder object with Serials-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'serials');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Serials::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('serials');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Serials object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Serials the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Serials::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Serials object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Serials::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Serials::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Serials objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Serials[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Serials::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Serials::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Serials::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Serials objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Serials::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Serials::GetDatabase();

			$strQuery = Serials::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/serials', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Serials::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Serials
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'serials';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idserials', $strAliasPrefix . 'idserials');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idserials', $strAliasPrefix . 'idserials');
			    $objBuilder->AddSelectItem($strTableName, 'item', $strAliasPrefix . 'item');
			    $objBuilder->AddSelectItem($strTableName, 'serial', $strAliasPrefix . 'serial');
			    $objBuilder->AddSelectItem($strTableName, 'iw', $strAliasPrefix . 'iw');
			    $objBuilder->AddSelectItem($strTableName, 'ow', $strAliasPrefix . 'ow');
			    $objBuilder->AddSelectItem($strTableName, 'sow', $strAliasPrefix . 'sow');
			    $objBuilder->AddSelectItem($strTableName, 'expiry_date', $strAliasPrefix . 'expiry_date');
			    $objBuilder->AddSelectItem($strTableName, 'pr', $strAliasPrefix . 'pr');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Serials from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Serials::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Serials
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the Serials object
			$objToReturn = new Serials();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idserials';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdserials = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'item';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intItem = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'serial';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strSerial = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'iw';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIw = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'ow';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intOw = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'sow';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSow = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'expiry_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttExpiryDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'pr';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intPr = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idserials != $objPreviousItem->Idserials) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'serials__';

			// Check for ItemObject Early Binding
			$strAlias = $strAliasPrefix . 'item__idledger_details';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objItemObject = LedgerDetails::InstantiateDbRow($objDbRow, $strAliasPrefix . 'item__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for IwObject Early Binding
			$strAlias = $strAliasPrefix . 'iw__idvoucher_has_item';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objIwObject = VoucherHasItem::InstantiateDbRow($objDbRow, $strAliasPrefix . 'iw__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for OwObject Early Binding
			$strAlias = $strAliasPrefix . 'ow__idvoucher_has_item';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objOwObject = VoucherHasItem::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ow__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for SowObject Early Binding
			$strAlias = $strAliasPrefix . 'sow__idvoucher_has_item';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSowObject = VoucherHasItem::InstantiateDbRow($objDbRow, $strAliasPrefix . 'sow__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for PrObject Early Binding
			$strAlias = $strAliasPrefix . 'pr__idvoucher_has_item';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objPrObject = VoucherHasItem::InstantiateDbRow($objDbRow, $strAliasPrefix . 'pr__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of Serialses from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Serials[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Serials::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Serials::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Serials object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Serials next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Serials::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Serials object,
		 * by Idserials Index(es)
		 * @param integer $intIdserials
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Serials
		*/
		public static function LoadByIdserials($intIdserials, $objOptionalClauses = null) {
			return Serials::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Serials()->Idserials, $intIdserials)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Serials objects,
		 * by Item Index(es)
		 * @param integer $intItem
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Serials[]
		*/
		public static function LoadArrayByItem($intItem, $objOptionalClauses = null) {
			// Call Serials::QueryArray to perform the LoadArrayByItem query
			try {
				return Serials::QueryArray(
					QQ::Equal(QQN::Serials()->Item, $intItem),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Serialses
		 * by Item Index(es)
		 * @param integer $intItem
		 * @return int
		*/
		public static function CountByItem($intItem) {
			// Call Serials::QueryCount to perform the CountByItem query
			return Serials::QueryCount(
				QQ::Equal(QQN::Serials()->Item, $intItem)
			);
		}

		/**
		 * Load an array of Serials objects,
		 * by Iw Index(es)
		 * @param integer $intIw
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Serials[]
		*/
		public static function LoadArrayByIw($intIw, $objOptionalClauses = null) {
			// Call Serials::QueryArray to perform the LoadArrayByIw query
			try {
				return Serials::QueryArray(
					QQ::Equal(QQN::Serials()->Iw, $intIw),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Serialses
		 * by Iw Index(es)
		 * @param integer $intIw
		 * @return int
		*/
		public static function CountByIw($intIw) {
			// Call Serials::QueryCount to perform the CountByIw query
			return Serials::QueryCount(
				QQ::Equal(QQN::Serials()->Iw, $intIw)
			);
		}

		/**
		 * Load an array of Serials objects,
		 * by Ow Index(es)
		 * @param integer $intOw
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Serials[]
		*/
		public static function LoadArrayByOw($intOw, $objOptionalClauses = null) {
			// Call Serials::QueryArray to perform the LoadArrayByOw query
			try {
				return Serials::QueryArray(
					QQ::Equal(QQN::Serials()->Ow, $intOw),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Serialses
		 * by Ow Index(es)
		 * @param integer $intOw
		 * @return int
		*/
		public static function CountByOw($intOw) {
			// Call Serials::QueryCount to perform the CountByOw query
			return Serials::QueryCount(
				QQ::Equal(QQN::Serials()->Ow, $intOw)
			);
		}

		/**
		 * Load an array of Serials objects,
		 * by Sow Index(es)
		 * @param integer $intSow
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Serials[]
		*/
		public static function LoadArrayBySow($intSow, $objOptionalClauses = null) {
			// Call Serials::QueryArray to perform the LoadArrayBySow query
			try {
				return Serials::QueryArray(
					QQ::Equal(QQN::Serials()->Sow, $intSow),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Serialses
		 * by Sow Index(es)
		 * @param integer $intSow
		 * @return int
		*/
		public static function CountBySow($intSow) {
			// Call Serials::QueryCount to perform the CountBySow query
			return Serials::QueryCount(
				QQ::Equal(QQN::Serials()->Sow, $intSow)
			);
		}

		/**
		 * Load an array of Serials objects,
		 * by Pr Index(es)
		 * @param integer $intPr
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Serials[]
		*/
		public static function LoadArrayByPr($intPr, $objOptionalClauses = null) {
			// Call Serials::QueryArray to perform the LoadArrayByPr query
			try {
				return Serials::QueryArray(
					QQ::Equal(QQN::Serials()->Pr, $intPr),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Serialses
		 * by Pr Index(es)
		 * @param integer $intPr
		 * @return int
		*/
		public static function CountByPr($intPr) {
			// Call Serials::QueryCount to perform the CountByPr query
			return Serials::QueryCount(
				QQ::Equal(QQN::Serials()->Pr, $intPr)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Serials
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Serials::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `serials` (
							`item`,
							`serial`,
							`iw`,
							`ow`,
							`sow`,
							`expiry_date`,
							`pr`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intItem) . ',
							' . $objDatabase->SqlVariable($this->strSerial) . ',
							' . $objDatabase->SqlVariable($this->intIw) . ',
							' . $objDatabase->SqlVariable($this->intOw) . ',
							' . $objDatabase->SqlVariable($this->intSow) . ',
							' . $objDatabase->SqlVariable($this->dttExpiryDate) . ',
							' . $objDatabase->SqlVariable($this->intPr) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdserials = $objDatabase->InsertId('serials', 'idserials');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`serials`
						SET
							`item` = ' . $objDatabase->SqlVariable($this->intItem) . ',
							`serial` = ' . $objDatabase->SqlVariable($this->strSerial) . ',
							`iw` = ' . $objDatabase->SqlVariable($this->intIw) . ',
							`ow` = ' . $objDatabase->SqlVariable($this->intOw) . ',
							`sow` = ' . $objDatabase->SqlVariable($this->intSow) . ',
							`expiry_date` = ' . $objDatabase->SqlVariable($this->dttExpiryDate) . ',
							`pr` = ' . $objDatabase->SqlVariable($this->intPr) . '
						WHERE
							`idserials` = ' . $objDatabase->SqlVariable($this->intIdserials) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Serials
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdserials)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Serials with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Serials::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`serials`
				WHERE
					`idserials` = ' . $objDatabase->SqlVariable($this->intIdserials) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Serials ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Serials', $this->intIdserials);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Serialses
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Serials::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`serials`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate serials table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Serials::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `serials`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Serials from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Serials object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Serials::Load($this->intIdserials);

			// Update $this's local variables to match
			$this->Item = $objReloaded->Item;
			$this->strSerial = $objReloaded->strSerial;
			$this->Iw = $objReloaded->Iw;
			$this->Ow = $objReloaded->Ow;
			$this->Sow = $objReloaded->Sow;
			$this->dttExpiryDate = $objReloaded->dttExpiryDate;
			$this->Pr = $objReloaded->Pr;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idserials':
					/**
					 * Gets the value for intIdserials (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdserials;

				case 'Item':
					/**
					 * Gets the value for intItem (Not Null)
					 * @return integer
					 */
					return $this->intItem;

				case 'Serial':
					/**
					 * Gets the value for strSerial (Not Null)
					 * @return string
					 */
					return $this->strSerial;

				case 'Iw':
					/**
					 * Gets the value for intIw 
					 * @return integer
					 */
					return $this->intIw;

				case 'Ow':
					/**
					 * Gets the value for intOw 
					 * @return integer
					 */
					return $this->intOw;

				case 'Sow':
					/**
					 * Gets the value for intSow 
					 * @return integer
					 */
					return $this->intSow;

				case 'ExpiryDate':
					/**
					 * Gets the value for dttExpiryDate 
					 * @return QDateTime
					 */
					return $this->dttExpiryDate;

				case 'Pr':
					/**
					 * Gets the value for intPr 
					 * @return integer
					 */
					return $this->intPr;


				///////////////////
				// Member Objects
				///////////////////
				case 'ItemObject':
					/**
					 * Gets the value for the LedgerDetails object referenced by intItem (Not Null)
					 * @return LedgerDetails
					 */
					try {
						if ((!$this->objItemObject) && (!is_null($this->intItem)))
							$this->objItemObject = LedgerDetails::Load($this->intItem);
						return $this->objItemObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'IwObject':
					/**
					 * Gets the value for the VoucherHasItem object referenced by intIw 
					 * @return VoucherHasItem
					 */
					try {
						if ((!$this->objIwObject) && (!is_null($this->intIw)))
							$this->objIwObject = VoucherHasItem::Load($this->intIw);
						return $this->objIwObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'OwObject':
					/**
					 * Gets the value for the VoucherHasItem object referenced by intOw 
					 * @return VoucherHasItem
					 */
					try {
						if ((!$this->objOwObject) && (!is_null($this->intOw)))
							$this->objOwObject = VoucherHasItem::Load($this->intOw);
						return $this->objOwObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SowObject':
					/**
					 * Gets the value for the VoucherHasItem object referenced by intSow 
					 * @return VoucherHasItem
					 */
					try {
						if ((!$this->objSowObject) && (!is_null($this->intSow)))
							$this->objSowObject = VoucherHasItem::Load($this->intSow);
						return $this->objSowObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'PrObject':
					/**
					 * Gets the value for the VoucherHasItem object referenced by intPr 
					 * @return VoucherHasItem
					 */
					try {
						if ((!$this->objPrObject) && (!is_null($this->intPr)))
							$this->objPrObject = VoucherHasItem::Load($this->intPr);
						return $this->objPrObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Item':
					/**
					 * Sets the value for intItem (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objItemObject = null;
						return ($this->intItem = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Serial':
					/**
					 * Sets the value for strSerial (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strSerial = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Iw':
					/**
					 * Sets the value for intIw 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objIwObject = null;
						return ($this->intIw = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Ow':
					/**
					 * Sets the value for intOw 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objOwObject = null;
						return ($this->intOw = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Sow':
					/**
					 * Sets the value for intSow 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSowObject = null;
						return ($this->intSow = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ExpiryDate':
					/**
					 * Sets the value for dttExpiryDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttExpiryDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Pr':
					/**
					 * Sets the value for intPr 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objPrObject = null;
						return ($this->intPr = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'ItemObject':
					/**
					 * Sets the value for the LedgerDetails object referenced by intItem (Not Null)
					 * @param LedgerDetails $mixValue
					 * @return LedgerDetails
					 */
					if (is_null($mixValue)) {
						$this->intItem = null;
						$this->objItemObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a LedgerDetails object
						try {
							$mixValue = QType::Cast($mixValue, 'LedgerDetails');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED LedgerDetails object
						if (is_null($mixValue->IdledgerDetails))
							throw new QCallerException('Unable to set an unsaved ItemObject for this Serials');

						// Update Local Member Variables
						$this->objItemObject = $mixValue;
						$this->intItem = $mixValue->IdledgerDetails;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'IwObject':
					/**
					 * Sets the value for the VoucherHasItem object referenced by intIw 
					 * @param VoucherHasItem $mixValue
					 * @return VoucherHasItem
					 */
					if (is_null($mixValue)) {
						$this->intIw = null;
						$this->objIwObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a VoucherHasItem object
						try {
							$mixValue = QType::Cast($mixValue, 'VoucherHasItem');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED VoucherHasItem object
						if (is_null($mixValue->IdvoucherHasItem))
							throw new QCallerException('Unable to set an unsaved IwObject for this Serials');

						// Update Local Member Variables
						$this->objIwObject = $mixValue;
						$this->intIw = $mixValue->IdvoucherHasItem;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'OwObject':
					/**
					 * Sets the value for the VoucherHasItem object referenced by intOw 
					 * @param VoucherHasItem $mixValue
					 * @return VoucherHasItem
					 */
					if (is_null($mixValue)) {
						$this->intOw = null;
						$this->objOwObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a VoucherHasItem object
						try {
							$mixValue = QType::Cast($mixValue, 'VoucherHasItem');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED VoucherHasItem object
						if (is_null($mixValue->IdvoucherHasItem))
							throw new QCallerException('Unable to set an unsaved OwObject for this Serials');

						// Update Local Member Variables
						$this->objOwObject = $mixValue;
						$this->intOw = $mixValue->IdvoucherHasItem;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'SowObject':
					/**
					 * Sets the value for the VoucherHasItem object referenced by intSow 
					 * @param VoucherHasItem $mixValue
					 * @return VoucherHasItem
					 */
					if (is_null($mixValue)) {
						$this->intSow = null;
						$this->objSowObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a VoucherHasItem object
						try {
							$mixValue = QType::Cast($mixValue, 'VoucherHasItem');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED VoucherHasItem object
						if (is_null($mixValue->IdvoucherHasItem))
							throw new QCallerException('Unable to set an unsaved SowObject for this Serials');

						// Update Local Member Variables
						$this->objSowObject = $mixValue;
						$this->intSow = $mixValue->IdvoucherHasItem;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'PrObject':
					/**
					 * Sets the value for the VoucherHasItem object referenced by intPr 
					 * @param VoucherHasItem $mixValue
					 * @return VoucherHasItem
					 */
					if (is_null($mixValue)) {
						$this->intPr = null;
						$this->objPrObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a VoucherHasItem object
						try {
							$mixValue = QType::Cast($mixValue, 'VoucherHasItem');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED VoucherHasItem object
						if (is_null($mixValue->IdvoucherHasItem))
							throw new QCallerException('Unable to set an unsaved PrObject for this Serials');

						// Update Local Member Variables
						$this->objPrObject = $mixValue;
						$this->intPr = $mixValue->IdvoucherHasItem;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "serials";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Serials::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Serials"><sequence>';
			$strToReturn .= '<element name="Idserials" type="xsd:int"/>';
			$strToReturn .= '<element name="ItemObject" type="xsd1:LedgerDetails"/>';
			$strToReturn .= '<element name="Serial" type="xsd:string"/>';
			$strToReturn .= '<element name="IwObject" type="xsd1:VoucherHasItem"/>';
			$strToReturn .= '<element name="OwObject" type="xsd1:VoucherHasItem"/>';
			$strToReturn .= '<element name="SowObject" type="xsd1:VoucherHasItem"/>';
			$strToReturn .= '<element name="ExpiryDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="PrObject" type="xsd1:VoucherHasItem"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Serials', $strComplexTypeArray)) {
				$strComplexTypeArray['Serials'] = Serials::GetSoapComplexTypeXml();
				LedgerDetails::AlterSoapComplexTypeArray($strComplexTypeArray);
				VoucherHasItem::AlterSoapComplexTypeArray($strComplexTypeArray);
				VoucherHasItem::AlterSoapComplexTypeArray($strComplexTypeArray);
				VoucherHasItem::AlterSoapComplexTypeArray($strComplexTypeArray);
				VoucherHasItem::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Serials::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Serials();
			if (property_exists($objSoapObject, 'Idserials'))
				$objToReturn->intIdserials = $objSoapObject->Idserials;
			if ((property_exists($objSoapObject, 'ItemObject')) &&
				($objSoapObject->ItemObject))
				$objToReturn->ItemObject = LedgerDetails::GetObjectFromSoapObject($objSoapObject->ItemObject);
			if (property_exists($objSoapObject, 'Serial'))
				$objToReturn->strSerial = $objSoapObject->Serial;
			if ((property_exists($objSoapObject, 'IwObject')) &&
				($objSoapObject->IwObject))
				$objToReturn->IwObject = VoucherHasItem::GetObjectFromSoapObject($objSoapObject->IwObject);
			if ((property_exists($objSoapObject, 'OwObject')) &&
				($objSoapObject->OwObject))
				$objToReturn->OwObject = VoucherHasItem::GetObjectFromSoapObject($objSoapObject->OwObject);
			if ((property_exists($objSoapObject, 'SowObject')) &&
				($objSoapObject->SowObject))
				$objToReturn->SowObject = VoucherHasItem::GetObjectFromSoapObject($objSoapObject->SowObject);
			if (property_exists($objSoapObject, 'ExpiryDate'))
				$objToReturn->dttExpiryDate = new QDateTime($objSoapObject->ExpiryDate);
			if ((property_exists($objSoapObject, 'PrObject')) &&
				($objSoapObject->PrObject))
				$objToReturn->PrObject = VoucherHasItem::GetObjectFromSoapObject($objSoapObject->PrObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Serials::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objItemObject)
				$objObject->objItemObject = LedgerDetails::GetSoapObjectFromObject($objObject->objItemObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intItem = null;
			if ($objObject->objIwObject)
				$objObject->objIwObject = VoucherHasItem::GetSoapObjectFromObject($objObject->objIwObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intIw = null;
			if ($objObject->objOwObject)
				$objObject->objOwObject = VoucherHasItem::GetSoapObjectFromObject($objObject->objOwObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intOw = null;
			if ($objObject->objSowObject)
				$objObject->objSowObject = VoucherHasItem::GetSoapObjectFromObject($objObject->objSowObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSow = null;
			if ($objObject->dttExpiryDate)
				$objObject->dttExpiryDate = $objObject->dttExpiryDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objPrObject)
				$objObject->objPrObject = VoucherHasItem::GetSoapObjectFromObject($objObject->objPrObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intPr = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idserials'] = $this->intIdserials;
			$iArray['Item'] = $this->intItem;
			$iArray['Serial'] = $this->strSerial;
			$iArray['Iw'] = $this->intIw;
			$iArray['Ow'] = $this->intOw;
			$iArray['Sow'] = $this->intSow;
			$iArray['ExpiryDate'] = $this->dttExpiryDate;
			$iArray['Pr'] = $this->intPr;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdserials ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idserials
     * @property-read QQNode $Item
     * @property-read QQNodeLedgerDetails $ItemObject
     * @property-read QQNode $Serial
     * @property-read QQNode $Iw
     * @property-read QQNodeVoucherHasItem $IwObject
     * @property-read QQNode $Ow
     * @property-read QQNodeVoucherHasItem $OwObject
     * @property-read QQNode $Sow
     * @property-read QQNodeVoucherHasItem $SowObject
     * @property-read QQNode $ExpiryDate
     * @property-read QQNode $Pr
     * @property-read QQNodeVoucherHasItem $PrObject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeSerials extends QQNode {
		protected $strTableName = 'serials';
		protected $strPrimaryKey = 'idserials';
		protected $strClassName = 'Serials';
		public function __get($strName) {
			switch ($strName) {
				case 'Idserials':
					return new QQNode('idserials', 'Idserials', 'Integer', $this);
				case 'Item':
					return new QQNode('item', 'Item', 'Integer', $this);
				case 'ItemObject':
					return new QQNodeLedgerDetails('item', 'ItemObject', 'Integer', $this);
				case 'Serial':
					return new QQNode('serial', 'Serial', 'VarChar', $this);
				case 'Iw':
					return new QQNode('iw', 'Iw', 'Integer', $this);
				case 'IwObject':
					return new QQNodeVoucherHasItem('iw', 'IwObject', 'Integer', $this);
				case 'Ow':
					return new QQNode('ow', 'Ow', 'Integer', $this);
				case 'OwObject':
					return new QQNodeVoucherHasItem('ow', 'OwObject', 'Integer', $this);
				case 'Sow':
					return new QQNode('sow', 'Sow', 'Integer', $this);
				case 'SowObject':
					return new QQNodeVoucherHasItem('sow', 'SowObject', 'Integer', $this);
				case 'ExpiryDate':
					return new QQNode('expiry_date', 'ExpiryDate', 'Date', $this);
				case 'Pr':
					return new QQNode('pr', 'Pr', 'Integer', $this);
				case 'PrObject':
					return new QQNodeVoucherHasItem('pr', 'PrObject', 'Integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idserials', 'Idserials', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idserials
     * @property-read QQNode $Item
     * @property-read QQNodeLedgerDetails $ItemObject
     * @property-read QQNode $Serial
     * @property-read QQNode $Iw
     * @property-read QQNodeVoucherHasItem $IwObject
     * @property-read QQNode $Ow
     * @property-read QQNodeVoucherHasItem $OwObject
     * @property-read QQNode $Sow
     * @property-read QQNodeVoucherHasItem $SowObject
     * @property-read QQNode $ExpiryDate
     * @property-read QQNode $Pr
     * @property-read QQNodeVoucherHasItem $PrObject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeSerials extends QQReverseReferenceNode {
		protected $strTableName = 'serials';
		protected $strPrimaryKey = 'idserials';
		protected $strClassName = 'Serials';
		public function __get($strName) {
			switch ($strName) {
				case 'Idserials':
					return new QQNode('idserials', 'Idserials', 'integer', $this);
				case 'Item':
					return new QQNode('item', 'Item', 'integer', $this);
				case 'ItemObject':
					return new QQNodeLedgerDetails('item', 'ItemObject', 'integer', $this);
				case 'Serial':
					return new QQNode('serial', 'Serial', 'string', $this);
				case 'Iw':
					return new QQNode('iw', 'Iw', 'integer', $this);
				case 'IwObject':
					return new QQNodeVoucherHasItem('iw', 'IwObject', 'integer', $this);
				case 'Ow':
					return new QQNode('ow', 'Ow', 'integer', $this);
				case 'OwObject':
					return new QQNodeVoucherHasItem('ow', 'OwObject', 'integer', $this);
				case 'Sow':
					return new QQNode('sow', 'Sow', 'integer', $this);
				case 'SowObject':
					return new QQNodeVoucherHasItem('sow', 'SowObject', 'integer', $this);
				case 'ExpiryDate':
					return new QQNode('expiry_date', 'ExpiryDate', 'QDateTime', $this);
				case 'Pr':
					return new QQNode('pr', 'Pr', 'integer', $this);
				case 'PrObject':
					return new QQNodeVoucherHasItem('pr', 'PrObject', 'integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idserials', 'Idserials', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
