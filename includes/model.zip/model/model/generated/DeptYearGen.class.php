<?php
	/**
	 * The abstract DeptYearGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the DeptYear subclass which
	 * extends this DeptYearGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the DeptYear class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IddeptYear the value for intIddeptYear (Read-Only PK)
	 * @property string $Name the value for strName (Unique)
	 * @property integer $Department the value for intDepartment (Not Null)
	 * @property integer $Calender the value for intCalender (Not Null)
	 * @property integer $Academic the value for intAcademic (Not Null)
	 * @property integer $Intake the value for intIntake 
	 * @property integer $Semister the value for intSemister (Not Null)
	 * @property Role $DepartmentObject the value for the Role object referenced by intDepartment (Not Null)
	 * @property CalenderYear $CalenderObject the value for the CalenderYear object referenced by intCalender (Not Null)
	 * @property AcademicYear $AcademicObject the value for the AcademicYear object referenced by intAcademic (Not Null)
	 * @property AcademicYear $SemisterObject the value for the AcademicYear object referenced by intSemister (Not Null)
	 * @property-read DeptYearEvents $_DeptYearEvents the value for the private _objDeptYearEvents (Read-Only) if set due to an expansion on the dept_year_events.dept_year reverse relationship
	 * @property-read DeptYearEvents[] $_DeptYearEventsArray the value for the private _objDeptYearEventsArray (Read-Only) if set due to an ExpandAsArray on the dept_year_events.dept_year reverse relationship
	 * @property-read FeesTemplet $_FeesTempletAsDeprtYear the value for the private _objFeesTempletAsDeprtYear (Read-Only) if set due to an expansion on the fees_templet.deprt_year reverse relationship
	 * @property-read FeesTemplet[] $_FeesTempletAsDeprtYearArray the value for the private _objFeesTempletAsDeprtYearArray (Read-Only) if set due to an ExpandAsArray on the fees_templet.deprt_year reverse relationship
	 * @property-read YearlySubject $_YearlySubject the value for the private _objYearlySubject (Read-Only) if set due to an expansion on the yearly_subject.dept_year reverse relationship
	 * @property-read YearlySubject[] $_YearlySubjectArray the value for the private _objYearlySubjectArray (Read-Only) if set due to an ExpandAsArray on the yearly_subject.dept_year reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class DeptYearGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column dept_year.iddept_year
		 * @var integer intIddeptYear
		 */
		protected $intIddeptYear;
		const IddeptYearDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year.name
		 * @var string strName
		 */
		protected $strName;
		const NameMaxLength = 45;
		const NameDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year.department
		 * @var integer intDepartment
		 */
		protected $intDepartment;
		const DepartmentDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year.calender
		 * @var integer intCalender
		 */
		protected $intCalender;
		const CalenderDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year.academic
		 * @var integer intAcademic
		 */
		protected $intAcademic;
		const AcademicDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year.intake
		 * @var integer intIntake
		 */
		protected $intIntake;
		const IntakeDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year.semister
		 * @var integer intSemister
		 */
		protected $intSemister;
		const SemisterDefault = null;


		/**
		 * Private member variable that stores a reference to a single DeptYearEvents object
		 * (of type DeptYearEvents), if this DeptYear object was restored with
		 * an expansion on the dept_year_events association table.
		 * @var DeptYearEvents _objDeptYearEvents;
		 */
		private $_objDeptYearEvents;

		/**
		 * Private member variable that stores a reference to an array of DeptYearEvents objects
		 * (of type DeptYearEvents[]), if this DeptYear object was restored with
		 * an ExpandAsArray on the dept_year_events association table.
		 * @var DeptYearEvents[] _objDeptYearEventsArray;
		 */
		private $_objDeptYearEventsArray = null;

		/**
		 * Private member variable that stores a reference to a single FeesTempletAsDeprtYear object
		 * (of type FeesTemplet), if this DeptYear object was restored with
		 * an expansion on the fees_templet association table.
		 * @var FeesTemplet _objFeesTempletAsDeprtYear;
		 */
		private $_objFeesTempletAsDeprtYear;

		/**
		 * Private member variable that stores a reference to an array of FeesTempletAsDeprtYear objects
		 * (of type FeesTemplet[]), if this DeptYear object was restored with
		 * an ExpandAsArray on the fees_templet association table.
		 * @var FeesTemplet[] _objFeesTempletAsDeprtYearArray;
		 */
		private $_objFeesTempletAsDeprtYearArray = null;

		/**
		 * Private member variable that stores a reference to a single YearlySubject object
		 * (of type YearlySubject), if this DeptYear object was restored with
		 * an expansion on the yearly_subject association table.
		 * @var YearlySubject _objYearlySubject;
		 */
		private $_objYearlySubject;

		/**
		 * Private member variable that stores a reference to an array of YearlySubject objects
		 * (of type YearlySubject[]), if this DeptYear object was restored with
		 * an ExpandAsArray on the yearly_subject association table.
		 * @var YearlySubject[] _objYearlySubjectArray;
		 */
		private $_objYearlySubjectArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year.department.
		 *
		 * NOTE: Always use the DepartmentObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objDepartmentObject
		 */
		protected $objDepartmentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year.calender.
		 *
		 * NOTE: Always use the CalenderObject property getter to correctly retrieve this CalenderYear object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var CalenderYear objCalenderObject
		 */
		protected $objCalenderObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year.academic.
		 *
		 * NOTE: Always use the AcademicObject property getter to correctly retrieve this AcademicYear object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var AcademicYear objAcademicObject
		 */
		protected $objAcademicObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year.semister.
		 *
		 * NOTE: Always use the SemisterObject property getter to correctly retrieve this AcademicYear object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var AcademicYear objSemisterObject
		 */
		protected $objSemisterObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIddeptYear = DeptYear::IddeptYearDefault;
			$this->strName = DeptYear::NameDefault;
			$this->intDepartment = DeptYear::DepartmentDefault;
			$this->intCalender = DeptYear::CalenderDefault;
			$this->intAcademic = DeptYear::AcademicDefault;
			$this->intIntake = DeptYear::IntakeDefault;
			$this->intSemister = DeptYear::SemisterDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a DeptYear from PK Info
		 * @param integer $intIddeptYear
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYear
		 */
		public static function Load($intIddeptYear, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'DeptYear', $intIddeptYear);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = DeptYear::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::DeptYear()->IddeptYear, $intIddeptYear)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all DeptYears
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYear[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call DeptYear::QueryArray to perform the LoadAll query
			try {
				return DeptYear::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all DeptYears
		 * @return int
		 */
		public static function CountAll() {
			// Call DeptYear::QueryCount to perform the CountAll query
			return DeptYear::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Create/Build out the QueryBuilder object with DeptYear-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'dept_year');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				DeptYear::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('dept_year');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single DeptYear object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return DeptYear the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = DeptYear::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new DeptYear object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = DeptYear::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return DeptYear::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of DeptYear objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return DeptYear[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = DeptYear::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return DeptYear::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = DeptYear::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of DeptYear objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = DeptYear::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			$strQuery = DeptYear::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/deptyear', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = DeptYear::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this DeptYear
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'dept_year';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'iddept_year', $strAliasPrefix . 'iddept_year');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'iddept_year', $strAliasPrefix . 'iddept_year');
			    $objBuilder->AddSelectItem($strTableName, 'name', $strAliasPrefix . 'name');
			    $objBuilder->AddSelectItem($strTableName, 'department', $strAliasPrefix . 'department');
			    $objBuilder->AddSelectItem($strTableName, 'calender', $strAliasPrefix . 'calender');
			    $objBuilder->AddSelectItem($strTableName, 'academic', $strAliasPrefix . 'academic');
			    $objBuilder->AddSelectItem($strTableName, 'intake', $strAliasPrefix . 'intake');
			    $objBuilder->AddSelectItem($strTableName, 'semister', $strAliasPrefix . 'semister');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a DeptYear from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this DeptYear::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return DeptYear
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'iddept_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIddeptYear == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'dept_year__';


						// Expanding reverse references: DeptYearEvents
						$strAlias = $strAliasPrefix . 'deptyearevents__iddept_year_events';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objDeptYearEventsArray)
								$objPreviousItem->_objDeptYearEventsArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objDeptYearEventsArray)) {
								$objPreviousChildItems = $objPreviousItem->_objDeptYearEventsArray;
								$objChildItem = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearevents__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objDeptYearEventsArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objDeptYearEventsArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearevents__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: FeesTempletAsDeprtYear
						$strAlias = $strAliasPrefix . 'feestempletasdeprtyear__idfees_templet';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objFeesTempletAsDeprtYearArray)
								$objPreviousItem->_objFeesTempletAsDeprtYearArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objFeesTempletAsDeprtYearArray)) {
								$objPreviousChildItems = $objPreviousItem->_objFeesTempletAsDeprtYearArray;
								$objChildItem = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletasdeprtyear__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objFeesTempletAsDeprtYearArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objFeesTempletAsDeprtYearArray[] = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletasdeprtyear__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: YearlySubject
						$strAlias = $strAliasPrefix . 'yearlysubject__idyearly_subject';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objYearlySubjectArray)
								$objPreviousItem->_objYearlySubjectArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objYearlySubjectArray)) {
								$objPreviousChildItems = $objPreviousItem->_objYearlySubjectArray;
								$objChildItem = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearlysubject__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objYearlySubjectArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objYearlySubjectArray[] = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearlysubject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'dept_year__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the DeptYear object
			$objToReturn = new DeptYear();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'iddept_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIddeptYear = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'name';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strName = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'department';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDepartment = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'calender';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCalender = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'academic';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intAcademic = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'intake';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIntake = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'semister';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSemister = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IddeptYear != $objPreviousItem->IddeptYear) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objDeptYearEventsArray);
					$cnt = count($objToReturn->_objDeptYearEventsArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objDeptYearEventsArray, $objToReturn->_objDeptYearEventsArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objFeesTempletAsDeprtYearArray);
					$cnt = count($objToReturn->_objFeesTempletAsDeprtYearArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objFeesTempletAsDeprtYearArray, $objToReturn->_objFeesTempletAsDeprtYearArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objYearlySubjectArray);
					$cnt = count($objToReturn->_objYearlySubjectArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objYearlySubjectArray, $objToReturn->_objYearlySubjectArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'dept_year__';

			// Check for DepartmentObject Early Binding
			$strAlias = $strAliasPrefix . 'department__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDepartmentObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'department__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CalenderObject Early Binding
			$strAlias = $strAliasPrefix . 'calender__idcalender_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCalenderObject = CalenderYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calender__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for AcademicObject Early Binding
			$strAlias = $strAliasPrefix . 'academic__idacademic_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objAcademicObject = AcademicYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'academic__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for SemisterObject Early Binding
			$strAlias = $strAliasPrefix . 'semister__idacademic_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSemisterObject = AcademicYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'semister__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for DeptYearEvents Virtual Binding
			$strAlias = $strAliasPrefix . 'deptyearevents__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objDeptYearEventsArray)
				$objToReturn->_objDeptYearEventsArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objDeptYearEventsArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearevents__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objDeptYearEvents = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearevents__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for FeesTempletAsDeprtYear Virtual Binding
			$strAlias = $strAliasPrefix . 'feestempletasdeprtyear__idfees_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objFeesTempletAsDeprtYearArray)
				$objToReturn->_objFeesTempletAsDeprtYearArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objFeesTempletAsDeprtYearArray[] = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletasdeprtyear__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objFeesTempletAsDeprtYear = FeesTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feestempletasdeprtyear__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for YearlySubject Virtual Binding
			$strAlias = $strAliasPrefix . 'yearlysubject__idyearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objYearlySubjectArray)
				$objToReturn->_objYearlySubjectArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objYearlySubjectArray[] = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearlysubject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objYearlySubject = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearlysubject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of DeptYears from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return DeptYear[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = DeptYear::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = DeptYear::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single DeptYear object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return DeptYear next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return DeptYear::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single DeptYear object,
		 * by IddeptYear Index(es)
		 * @param integer $intIddeptYear
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYear
		*/
		public static function LoadByIddeptYear($intIddeptYear, $objOptionalClauses = null) {
			return DeptYear::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::DeptYear()->IddeptYear, $intIddeptYear)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single DeptYear object,
		 * by Name Index(es)
		 * @param string $strName
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYear
		*/
		public static function LoadByName($strName, $objOptionalClauses = null) {
			return DeptYear::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::DeptYear()->Name, $strName)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of DeptYear objects,
		 * by Calender Index(es)
		 * @param integer $intCalender
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYear[]
		*/
		public static function LoadArrayByCalender($intCalender, $objOptionalClauses = null) {
			// Call DeptYear::QueryArray to perform the LoadArrayByCalender query
			try {
				return DeptYear::QueryArray(
					QQ::Equal(QQN::DeptYear()->Calender, $intCalender),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYears
		 * by Calender Index(es)
		 * @param integer $intCalender
		 * @return int
		*/
		public static function CountByCalender($intCalender) {
			// Call DeptYear::QueryCount to perform the CountByCalender query
			return DeptYear::QueryCount(
				QQ::Equal(QQN::DeptYear()->Calender, $intCalender)
			);
		}

		/**
		 * Load an array of DeptYear objects,
		 * by Academic Index(es)
		 * @param integer $intAcademic
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYear[]
		*/
		public static function LoadArrayByAcademic($intAcademic, $objOptionalClauses = null) {
			// Call DeptYear::QueryArray to perform the LoadArrayByAcademic query
			try {
				return DeptYear::QueryArray(
					QQ::Equal(QQN::DeptYear()->Academic, $intAcademic),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYears
		 * by Academic Index(es)
		 * @param integer $intAcademic
		 * @return int
		*/
		public static function CountByAcademic($intAcademic) {
			// Call DeptYear::QueryCount to perform the CountByAcademic query
			return DeptYear::QueryCount(
				QQ::Equal(QQN::DeptYear()->Academic, $intAcademic)
			);
		}

		/**
		 * Load an array of DeptYear objects,
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYear[]
		*/
		public static function LoadArrayByDepartment($intDepartment, $objOptionalClauses = null) {
			// Call DeptYear::QueryArray to perform the LoadArrayByDepartment query
			try {
				return DeptYear::QueryArray(
					QQ::Equal(QQN::DeptYear()->Department, $intDepartment),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYears
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @return int
		*/
		public static function CountByDepartment($intDepartment) {
			// Call DeptYear::QueryCount to perform the CountByDepartment query
			return DeptYear::QueryCount(
				QQ::Equal(QQN::DeptYear()->Department, $intDepartment)
			);
		}

		/**
		 * Load an array of DeptYear objects,
		 * by Semister Index(es)
		 * @param integer $intSemister
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYear[]
		*/
		public static function LoadArrayBySemister($intSemister, $objOptionalClauses = null) {
			// Call DeptYear::QueryArray to perform the LoadArrayBySemister query
			try {
				return DeptYear::QueryArray(
					QQ::Equal(QQN::DeptYear()->Semister, $intSemister),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYears
		 * by Semister Index(es)
		 * @param integer $intSemister
		 * @return int
		*/
		public static function CountBySemister($intSemister) {
			// Call DeptYear::QueryCount to perform the CountBySemister query
			return DeptYear::QueryCount(
				QQ::Equal(QQN::DeptYear()->Semister, $intSemister)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this DeptYear
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `dept_year` (
							`name`,
							`department`,
							`calender`,
							`academic`,
							`intake`,
							`semister`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strName) . ',
							' . $objDatabase->SqlVariable($this->intDepartment) . ',
							' . $objDatabase->SqlVariable($this->intCalender) . ',
							' . $objDatabase->SqlVariable($this->intAcademic) . ',
							' . $objDatabase->SqlVariable($this->intIntake) . ',
							' . $objDatabase->SqlVariable($this->intSemister) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIddeptYear = $objDatabase->InsertId('dept_year', 'iddept_year');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`dept_year`
						SET
							`name` = ' . $objDatabase->SqlVariable($this->strName) . ',
							`department` = ' . $objDatabase->SqlVariable($this->intDepartment) . ',
							`calender` = ' . $objDatabase->SqlVariable($this->intCalender) . ',
							`academic` = ' . $objDatabase->SqlVariable($this->intAcademic) . ',
							`intake` = ' . $objDatabase->SqlVariable($this->intIntake) . ',
							`semister` = ' . $objDatabase->SqlVariable($this->intSemister) . '
						WHERE
							`iddept_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this DeptYear
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this DeptYear with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year`
				WHERE
					`iddept_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this DeptYear ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'DeptYear', $this->intIddeptYear);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all DeptYears
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate dept_year table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `dept_year`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this DeptYear from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved DeptYear object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = DeptYear::Load($this->intIddeptYear);

			// Update $this's local variables to match
			$this->strName = $objReloaded->strName;
			$this->Department = $objReloaded->Department;
			$this->Calender = $objReloaded->Calender;
			$this->Academic = $objReloaded->Academic;
			$this->intIntake = $objReloaded->intIntake;
			$this->Semister = $objReloaded->Semister;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IddeptYear':
					/**
					 * Gets the value for intIddeptYear (Read-Only PK)
					 * @return integer
					 */
					return $this->intIddeptYear;

				case 'Name':
					/**
					 * Gets the value for strName (Unique)
					 * @return string
					 */
					return $this->strName;

				case 'Department':
					/**
					 * Gets the value for intDepartment (Not Null)
					 * @return integer
					 */
					return $this->intDepartment;

				case 'Calender':
					/**
					 * Gets the value for intCalender (Not Null)
					 * @return integer
					 */
					return $this->intCalender;

				case 'Academic':
					/**
					 * Gets the value for intAcademic (Not Null)
					 * @return integer
					 */
					return $this->intAcademic;

				case 'Intake':
					/**
					 * Gets the value for intIntake 
					 * @return integer
					 */
					return $this->intIntake;

				case 'Semister':
					/**
					 * Gets the value for intSemister (Not Null)
					 * @return integer
					 */
					return $this->intSemister;


				///////////////////
				// Member Objects
				///////////////////
				case 'DepartmentObject':
					/**
					 * Gets the value for the Role object referenced by intDepartment (Not Null)
					 * @return Role
					 */
					try {
						if ((!$this->objDepartmentObject) && (!is_null($this->intDepartment)))
							$this->objDepartmentObject = Role::Load($this->intDepartment);
						return $this->objDepartmentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CalenderObject':
					/**
					 * Gets the value for the CalenderYear object referenced by intCalender (Not Null)
					 * @return CalenderYear
					 */
					try {
						if ((!$this->objCalenderObject) && (!is_null($this->intCalender)))
							$this->objCalenderObject = CalenderYear::Load($this->intCalender);
						return $this->objCalenderObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AcademicObject':
					/**
					 * Gets the value for the AcademicYear object referenced by intAcademic (Not Null)
					 * @return AcademicYear
					 */
					try {
						if ((!$this->objAcademicObject) && (!is_null($this->intAcademic)))
							$this->objAcademicObject = AcademicYear::Load($this->intAcademic);
						return $this->objAcademicObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SemisterObject':
					/**
					 * Gets the value for the AcademicYear object referenced by intSemister (Not Null)
					 * @return AcademicYear
					 */
					try {
						if ((!$this->objSemisterObject) && (!is_null($this->intSemister)))
							$this->objSemisterObject = AcademicYear::Load($this->intSemister);
						return $this->objSemisterObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_DeptYearEvents':
					/**
					 * Gets the value for the private _objDeptYearEvents (Read-Only)
					 * if set due to an expansion on the dept_year_events.dept_year reverse relationship
					 * @return DeptYearEvents
					 */
					return $this->_objDeptYearEvents;

				case '_DeptYearEventsArray':
					/**
					 * Gets the value for the private _objDeptYearEventsArray (Read-Only)
					 * if set due to an ExpandAsArray on the dept_year_events.dept_year reverse relationship
					 * @return DeptYearEvents[]
					 */
					return $this->_objDeptYearEventsArray;

				case '_FeesTempletAsDeprtYear':
					/**
					 * Gets the value for the private _objFeesTempletAsDeprtYear (Read-Only)
					 * if set due to an expansion on the fees_templet.deprt_year reverse relationship
					 * @return FeesTemplet
					 */
					return $this->_objFeesTempletAsDeprtYear;

				case '_FeesTempletAsDeprtYearArray':
					/**
					 * Gets the value for the private _objFeesTempletAsDeprtYearArray (Read-Only)
					 * if set due to an ExpandAsArray on the fees_templet.deprt_year reverse relationship
					 * @return FeesTemplet[]
					 */
					return $this->_objFeesTempletAsDeprtYearArray;

				case '_YearlySubject':
					/**
					 * Gets the value for the private _objYearlySubject (Read-Only)
					 * if set due to an expansion on the yearly_subject.dept_year reverse relationship
					 * @return YearlySubject
					 */
					return $this->_objYearlySubject;

				case '_YearlySubjectArray':
					/**
					 * Gets the value for the private _objYearlySubjectArray (Read-Only)
					 * if set due to an ExpandAsArray on the yearly_subject.dept_year reverse relationship
					 * @return YearlySubject[]
					 */
					return $this->_objYearlySubjectArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Name':
					/**
					 * Sets the value for strName (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strName = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Department':
					/**
					 * Sets the value for intDepartment (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDepartmentObject = null;
						return ($this->intDepartment = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Calender':
					/**
					 * Sets the value for intCalender (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCalenderObject = null;
						return ($this->intCalender = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Academic':
					/**
					 * Sets the value for intAcademic (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objAcademicObject = null;
						return ($this->intAcademic = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Intake':
					/**
					 * Sets the value for intIntake 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intIntake = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Semister':
					/**
					 * Sets the value for intSemister (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSemisterObject = null;
						return ($this->intSemister = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'DepartmentObject':
					/**
					 * Sets the value for the Role object referenced by intDepartment (Not Null)
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intDepartment = null;
						$this->objDepartmentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved DepartmentObject for this DeptYear');

						// Update Local Member Variables
						$this->objDepartmentObject = $mixValue;
						$this->intDepartment = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CalenderObject':
					/**
					 * Sets the value for the CalenderYear object referenced by intCalender (Not Null)
					 * @param CalenderYear $mixValue
					 * @return CalenderYear
					 */
					if (is_null($mixValue)) {
						$this->intCalender = null;
						$this->objCalenderObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a CalenderYear object
						try {
							$mixValue = QType::Cast($mixValue, 'CalenderYear');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED CalenderYear object
						if (is_null($mixValue->IdcalenderYear))
							throw new QCallerException('Unable to set an unsaved CalenderObject for this DeptYear');

						// Update Local Member Variables
						$this->objCalenderObject = $mixValue;
						$this->intCalender = $mixValue->IdcalenderYear;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'AcademicObject':
					/**
					 * Sets the value for the AcademicYear object referenced by intAcademic (Not Null)
					 * @param AcademicYear $mixValue
					 * @return AcademicYear
					 */
					if (is_null($mixValue)) {
						$this->intAcademic = null;
						$this->objAcademicObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a AcademicYear object
						try {
							$mixValue = QType::Cast($mixValue, 'AcademicYear');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED AcademicYear object
						if (is_null($mixValue->IdacademicYear))
							throw new QCallerException('Unable to set an unsaved AcademicObject for this DeptYear');

						// Update Local Member Variables
						$this->objAcademicObject = $mixValue;
						$this->intAcademic = $mixValue->IdacademicYear;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'SemisterObject':
					/**
					 * Sets the value for the AcademicYear object referenced by intSemister (Not Null)
					 * @param AcademicYear $mixValue
					 * @return AcademicYear
					 */
					if (is_null($mixValue)) {
						$this->intSemister = null;
						$this->objSemisterObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a AcademicYear object
						try {
							$mixValue = QType::Cast($mixValue, 'AcademicYear');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED AcademicYear object
						if (is_null($mixValue->IdacademicYear))
							throw new QCallerException('Unable to set an unsaved SemisterObject for this DeptYear');

						// Update Local Member Variables
						$this->objSemisterObject = $mixValue;
						$this->intSemister = $mixValue->IdacademicYear;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for DeptYearEvents
		//-------------------------------------------------------------------

		/**
		 * Gets all associated DeptYearEventses as an array of DeptYearEvents objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public function GetDeptYearEventsArray($objOptionalClauses = null) {
			if ((is_null($this->intIddeptYear)))
				return array();

			try {
				return DeptYearEvents::LoadArrayByDeptYear($this->intIddeptYear, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated DeptYearEventses
		 * @return int
		*/
		public function CountDeptYearEventses() {
			if ((is_null($this->intIddeptYear)))
				return 0;

			return DeptYearEvents::CountByDeptYear($this->intIddeptYear);
		}

		/**
		 * Associates a DeptYearEvents
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function AssociateDeptYearEvents(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEvents on this unsaved DeptYear.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEvents on this DeptYear with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`dept_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates a DeptYearEvents
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function UnassociateDeptYearEvents(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this unsaved DeptYear.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this DeptYear with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`dept_year` = null
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`dept_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
			');
		}

		/**
		 * Unassociates all DeptYearEventses
		 * @return void
		*/
		public function UnassociateAllDeptYearEventses() {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this unsaved DeptYear.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`dept_year` = null
				WHERE
					`dept_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
			');
		}

		/**
		 * Deletes an associated DeptYearEvents
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function DeleteAssociatedDeptYearEvents(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this unsaved DeptYear.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this DeptYear with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`dept_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
			');
		}

		/**
		 * Deletes all associated DeptYearEventses
		 * @return void
		*/
		public function DeleteAllDeptYearEventses() {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this unsaved DeptYear.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`dept_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
			');
		}


		// Related Objects' Methods for FeesTempletAsDeprtYear
		//-------------------------------------------------------------------

		/**
		 * Gets all associated FeesTempletsAsDeprtYear as an array of FeesTemplet objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return FeesTemplet[]
		*/
		public function GetFeesTempletAsDeprtYearArray($objOptionalClauses = null) {
			if ((is_null($this->intIddeptYear)))
				return array();

			try {
				return FeesTemplet::LoadArrayByDeprtYear($this->intIddeptYear, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated FeesTempletsAsDeprtYear
		 * @return int
		*/
		public function CountFeesTempletsAsDeprtYear() {
			if ((is_null($this->intIddeptYear)))
				return 0;

			return FeesTemplet::CountByDeprtYear($this->intIddeptYear);
		}

		/**
		 * Associates a FeesTempletAsDeprtYear
		 * @param FeesTemplet $objFeesTemplet
		 * @return void
		*/
		public function AssociateFeesTempletAsDeprtYear(FeesTemplet $objFeesTemplet) {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateFeesTempletAsDeprtYear on this unsaved DeptYear.');
			if ((is_null($objFeesTemplet->IdfeesTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateFeesTempletAsDeprtYear on this DeptYear with an unsaved FeesTemplet.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`fees_templet`
				SET
					`deprt_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
				WHERE
					`idfees_templet` = ' . $objDatabase->SqlVariable($objFeesTemplet->IdfeesTemplet) . '
			');
		}

		/**
		 * Unassociates a FeesTempletAsDeprtYear
		 * @param FeesTemplet $objFeesTemplet
		 * @return void
		*/
		public function UnassociateFeesTempletAsDeprtYear(FeesTemplet $objFeesTemplet) {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsDeprtYear on this unsaved DeptYear.');
			if ((is_null($objFeesTemplet->IdfeesTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsDeprtYear on this DeptYear with an unsaved FeesTemplet.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`fees_templet`
				SET
					`deprt_year` = null
				WHERE
					`idfees_templet` = ' . $objDatabase->SqlVariable($objFeesTemplet->IdfeesTemplet) . ' AND
					`deprt_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
			');
		}

		/**
		 * Unassociates all FeesTempletsAsDeprtYear
		 * @return void
		*/
		public function UnassociateAllFeesTempletsAsDeprtYear() {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsDeprtYear on this unsaved DeptYear.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`fees_templet`
				SET
					`deprt_year` = null
				WHERE
					`deprt_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
			');
		}

		/**
		 * Deletes an associated FeesTempletAsDeprtYear
		 * @param FeesTemplet $objFeesTemplet
		 * @return void
		*/
		public function DeleteAssociatedFeesTempletAsDeprtYear(FeesTemplet $objFeesTemplet) {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsDeprtYear on this unsaved DeptYear.');
			if ((is_null($objFeesTemplet->IdfeesTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsDeprtYear on this DeptYear with an unsaved FeesTemplet.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`fees_templet`
				WHERE
					`idfees_templet` = ' . $objDatabase->SqlVariable($objFeesTemplet->IdfeesTemplet) . ' AND
					`deprt_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
			');
		}

		/**
		 * Deletes all associated FeesTempletsAsDeprtYear
		 * @return void
		*/
		public function DeleteAllFeesTempletsAsDeprtYear() {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeesTempletAsDeprtYear on this unsaved DeptYear.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`fees_templet`
				WHERE
					`deprt_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
			');
		}


		// Related Objects' Methods for YearlySubject
		//-------------------------------------------------------------------

		/**
		 * Gets all associated YearlySubjects as an array of YearlySubject objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject[]
		*/
		public function GetYearlySubjectArray($objOptionalClauses = null) {
			if ((is_null($this->intIddeptYear)))
				return array();

			try {
				return YearlySubject::LoadArrayByDeptYear($this->intIddeptYear, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated YearlySubjects
		 * @return int
		*/
		public function CountYearlySubjects() {
			if ((is_null($this->intIddeptYear)))
				return 0;

			return YearlySubject::CountByDeptYear($this->intIddeptYear);
		}

		/**
		 * Associates a YearlySubject
		 * @param YearlySubject $objYearlySubject
		 * @return void
		*/
		public function AssociateYearlySubject(YearlySubject $objYearlySubject) {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateYearlySubject on this unsaved DeptYear.');
			if ((is_null($objYearlySubject->IdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateYearlySubject on this DeptYear with an unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`yearly_subject`
				SET
					`dept_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
				WHERE
					`idyearly_subject` = ' . $objDatabase->SqlVariable($objYearlySubject->IdyearlySubject) . '
			');
		}

		/**
		 * Unassociates a YearlySubject
		 * @param YearlySubject $objYearlySubject
		 * @return void
		*/
		public function UnassociateYearlySubject(YearlySubject $objYearlySubject) {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubject on this unsaved DeptYear.');
			if ((is_null($objYearlySubject->IdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubject on this DeptYear with an unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`yearly_subject`
				SET
					`dept_year` = null
				WHERE
					`idyearly_subject` = ' . $objDatabase->SqlVariable($objYearlySubject->IdyearlySubject) . ' AND
					`dept_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
			');
		}

		/**
		 * Unassociates all YearlySubjects
		 * @return void
		*/
		public function UnassociateAllYearlySubjects() {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubject on this unsaved DeptYear.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`yearly_subject`
				SET
					`dept_year` = null
				WHERE
					`dept_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
			');
		}

		/**
		 * Deletes an associated YearlySubject
		 * @param YearlySubject $objYearlySubject
		 * @return void
		*/
		public function DeleteAssociatedYearlySubject(YearlySubject $objYearlySubject) {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubject on this unsaved DeptYear.');
			if ((is_null($objYearlySubject->IdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubject on this DeptYear with an unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`yearly_subject`
				WHERE
					`idyearly_subject` = ' . $objDatabase->SqlVariable($objYearlySubject->IdyearlySubject) . ' AND
					`dept_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
			');
		}

		/**
		 * Deletes all associated YearlySubjects
		 * @return void
		*/
		public function DeleteAllYearlySubjects() {
			if ((is_null($this->intIddeptYear)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubject on this unsaved DeptYear.');

			// Get the Database Object for this Class
			$objDatabase = DeptYear::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`yearly_subject`
				WHERE
					`dept_year` = ' . $objDatabase->SqlVariable($this->intIddeptYear) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "dept_year";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[DeptYear::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="DeptYear"><sequence>';
			$strToReturn .= '<element name="IddeptYear" type="xsd:int"/>';
			$strToReturn .= '<element name="Name" type="xsd:string"/>';
			$strToReturn .= '<element name="DepartmentObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="CalenderObject" type="xsd1:CalenderYear"/>';
			$strToReturn .= '<element name="AcademicObject" type="xsd1:AcademicYear"/>';
			$strToReturn .= '<element name="Intake" type="xsd:int"/>';
			$strToReturn .= '<element name="SemisterObject" type="xsd1:AcademicYear"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('DeptYear', $strComplexTypeArray)) {
				$strComplexTypeArray['DeptYear'] = DeptYear::GetSoapComplexTypeXml();
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				CalenderYear::AlterSoapComplexTypeArray($strComplexTypeArray);
				AcademicYear::AlterSoapComplexTypeArray($strComplexTypeArray);
				AcademicYear::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, DeptYear::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new DeptYear();
			if (property_exists($objSoapObject, 'IddeptYear'))
				$objToReturn->intIddeptYear = $objSoapObject->IddeptYear;
			if (property_exists($objSoapObject, 'Name'))
				$objToReturn->strName = $objSoapObject->Name;
			if ((property_exists($objSoapObject, 'DepartmentObject')) &&
				($objSoapObject->DepartmentObject))
				$objToReturn->DepartmentObject = Role::GetObjectFromSoapObject($objSoapObject->DepartmentObject);
			if ((property_exists($objSoapObject, 'CalenderObject')) &&
				($objSoapObject->CalenderObject))
				$objToReturn->CalenderObject = CalenderYear::GetObjectFromSoapObject($objSoapObject->CalenderObject);
			if ((property_exists($objSoapObject, 'AcademicObject')) &&
				($objSoapObject->AcademicObject))
				$objToReturn->AcademicObject = AcademicYear::GetObjectFromSoapObject($objSoapObject->AcademicObject);
			if (property_exists($objSoapObject, 'Intake'))
				$objToReturn->intIntake = $objSoapObject->Intake;
			if ((property_exists($objSoapObject, 'SemisterObject')) &&
				($objSoapObject->SemisterObject))
				$objToReturn->SemisterObject = AcademicYear::GetObjectFromSoapObject($objSoapObject->SemisterObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, DeptYear::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objDepartmentObject)
				$objObject->objDepartmentObject = Role::GetSoapObjectFromObject($objObject->objDepartmentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDepartment = null;
			if ($objObject->objCalenderObject)
				$objObject->objCalenderObject = CalenderYear::GetSoapObjectFromObject($objObject->objCalenderObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCalender = null;
			if ($objObject->objAcademicObject)
				$objObject->objAcademicObject = AcademicYear::GetSoapObjectFromObject($objObject->objAcademicObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intAcademic = null;
			if ($objObject->objSemisterObject)
				$objObject->objSemisterObject = AcademicYear::GetSoapObjectFromObject($objObject->objSemisterObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSemister = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IddeptYear'] = $this->intIddeptYear;
			$iArray['Name'] = $this->strName;
			$iArray['Department'] = $this->intDepartment;
			$iArray['Calender'] = $this->intCalender;
			$iArray['Academic'] = $this->intAcademic;
			$iArray['Intake'] = $this->intIntake;
			$iArray['Semister'] = $this->intSemister;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIddeptYear ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IddeptYear
     * @property-read QQNode $Name
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $Calender
     * @property-read QQNodeCalenderYear $CalenderObject
     * @property-read QQNode $Academic
     * @property-read QQNodeAcademicYear $AcademicObject
     * @property-read QQNode $Intake
     * @property-read QQNode $Semister
     * @property-read QQNodeAcademicYear $SemisterObject
     *
     *
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEvents
     * @property-read QQReverseReferenceNodeFeesTemplet $FeesTempletAsDeprtYear
     * @property-read QQReverseReferenceNodeYearlySubject $YearlySubject

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeDeptYear extends QQNode {
		protected $strTableName = 'dept_year';
		protected $strPrimaryKey = 'iddept_year';
		protected $strClassName = 'DeptYear';
		public function __get($strName) {
			switch ($strName) {
				case 'IddeptYear':
					return new QQNode('iddept_year', 'IddeptYear', 'Integer', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'VarChar', $this);
				case 'Department':
					return new QQNode('department', 'Department', 'Integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'Integer', $this);
				case 'Calender':
					return new QQNode('calender', 'Calender', 'Integer', $this);
				case 'CalenderObject':
					return new QQNodeCalenderYear('calender', 'CalenderObject', 'Integer', $this);
				case 'Academic':
					return new QQNode('academic', 'Academic', 'Integer', $this);
				case 'AcademicObject':
					return new QQNodeAcademicYear('academic', 'AcademicObject', 'Integer', $this);
				case 'Intake':
					return new QQNode('intake', 'Intake', 'Integer', $this);
				case 'Semister':
					return new QQNode('semister', 'Semister', 'Integer', $this);
				case 'SemisterObject':
					return new QQNodeAcademicYear('semister', 'SemisterObject', 'Integer', $this);
				case 'DeptYearEvents':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyearevents', 'reverse_reference', 'dept_year');
				case 'FeesTempletAsDeprtYear':
					return new QQReverseReferenceNodeFeesTemplet($this, 'feestempletasdeprtyear', 'reverse_reference', 'deprt_year');
				case 'YearlySubject':
					return new QQReverseReferenceNodeYearlySubject($this, 'yearlysubject', 'reverse_reference', 'dept_year');

				case '_PrimaryKeyNode':
					return new QQNode('iddept_year', 'IddeptYear', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IddeptYear
     * @property-read QQNode $Name
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $Calender
     * @property-read QQNodeCalenderYear $CalenderObject
     * @property-read QQNode $Academic
     * @property-read QQNodeAcademicYear $AcademicObject
     * @property-read QQNode $Intake
     * @property-read QQNode $Semister
     * @property-read QQNodeAcademicYear $SemisterObject
     *
     *
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEvents
     * @property-read QQReverseReferenceNodeFeesTemplet $FeesTempletAsDeprtYear
     * @property-read QQReverseReferenceNodeYearlySubject $YearlySubject

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeDeptYear extends QQReverseReferenceNode {
		protected $strTableName = 'dept_year';
		protected $strPrimaryKey = 'iddept_year';
		protected $strClassName = 'DeptYear';
		public function __get($strName) {
			switch ($strName) {
				case 'IddeptYear':
					return new QQNode('iddept_year', 'IddeptYear', 'integer', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'string', $this);
				case 'Department':
					return new QQNode('department', 'Department', 'integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'integer', $this);
				case 'Calender':
					return new QQNode('calender', 'Calender', 'integer', $this);
				case 'CalenderObject':
					return new QQNodeCalenderYear('calender', 'CalenderObject', 'integer', $this);
				case 'Academic':
					return new QQNode('academic', 'Academic', 'integer', $this);
				case 'AcademicObject':
					return new QQNodeAcademicYear('academic', 'AcademicObject', 'integer', $this);
				case 'Intake':
					return new QQNode('intake', 'Intake', 'integer', $this);
				case 'Semister':
					return new QQNode('semister', 'Semister', 'integer', $this);
				case 'SemisterObject':
					return new QQNodeAcademicYear('semister', 'SemisterObject', 'integer', $this);
				case 'DeptYearEvents':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyearevents', 'reverse_reference', 'dept_year');
				case 'FeesTempletAsDeprtYear':
					return new QQReverseReferenceNodeFeesTemplet($this, 'feestempletasdeprtyear', 'reverse_reference', 'deprt_year');
				case 'YearlySubject':
					return new QQReverseReferenceNodeYearlySubject($this, 'yearlysubject', 'reverse_reference', 'dept_year');

				case '_PrimaryKeyNode':
					return new QQNode('iddept_year', 'IddeptYear', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
