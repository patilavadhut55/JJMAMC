<?php
	/**
	 * The abstract DeptYearExamGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the DeptYearExam subclass which
	 * extends this DeptYearExamGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the DeptYearExam class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property integer $YearlySubject the value for intYearlySubject (PK)
	 * @property integer $Exam the value for intExam (PK)
	 * @property integer $Marks the value for intMarks (Not Null)
	 * @property integer $ExamGrp the value for intExamGrp 
	 * @property integer $Max the value for intMax 
	 * @property YearlySubject $YearlySubjectObject the value for the YearlySubject object referenced by intYearlySubject (PK)
	 * @property Exam $ExamObject the value for the Exam object referenced by intExam (PK)
	 * @property ExamGroup $ExamGrpObject the value for the ExamGroup object referenced by intExamGrp 
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class DeptYearExamGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK column dept_year_exam.yearly_subject
		 * @var integer intYearlySubject
		 */
		protected $intYearlySubject;
		const YearlySubjectDefault = null;


		/**
		 * Protected internal member variable that stores the original version of the PK column value (if restored)
		 * Used by Save() to update a PK column during UPDATE
		 * @var integer __intYearlySubject;
		 */
		protected $__intYearlySubject;

		/**
		 * Protected member variable that maps to the database PK column dept_year_exam.exam
		 * @var integer intExam
		 */
		protected $intExam;
		const ExamDefault = null;


		/**
		 * Protected internal member variable that stores the original version of the PK column value (if restored)
		 * Used by Save() to update a PK column during UPDATE
		 * @var integer __intExam;
		 */
		protected $__intExam;

		/**
		 * Protected member variable that maps to the database column dept_year_exam.marks
		 * @var integer intMarks
		 */
		protected $intMarks;
		const MarksDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_exam.exam_grp
		 * @var integer intExamGrp
		 */
		protected $intExamGrp;
		const ExamGrpDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_exam.max
		 * @var integer intMax
		 */
		protected $intMax;
		const MaxDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_exam.yearly_subject.
		 *
		 * NOTE: Always use the YearlySubjectObject property getter to correctly retrieve this YearlySubject object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var YearlySubject objYearlySubjectObject
		 */
		protected $objYearlySubjectObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_exam.exam.
		 *
		 * NOTE: Always use the ExamObject property getter to correctly retrieve this Exam object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Exam objExamObject
		 */
		protected $objExamObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_exam.exam_grp.
		 *
		 * NOTE: Always use the ExamGrpObject property getter to correctly retrieve this ExamGroup object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var ExamGroup objExamGrpObject
		 */
		protected $objExamGrpObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intYearlySubject = DeptYearExam::YearlySubjectDefault;
			$this->intExam = DeptYearExam::ExamDefault;
			$this->intMarks = DeptYearExam::MarksDefault;
			$this->intExamGrp = DeptYearExam::ExamGrpDefault;
			$this->intMax = DeptYearExam::MaxDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a DeptYearExam from PK Info
		 * @param integer $intYearlySubject		 * @param integer $intExam
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearExam
		 */
		public static function Load($intYearlySubject, $intExam, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'DeptYearExam', $intYearlySubject, $intExam);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = DeptYearExam::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::DeptYearExam()->YearlySubject, $intYearlySubject),
					QQ::Equal(QQN::DeptYearExam()->Exam, $intExam)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all DeptYearExams
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearExam[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call DeptYearExam::QueryArray to perform the LoadAll query
			try {
				return DeptYearExam::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all DeptYearExams
		 * @return int
		 */
		public static function CountAll() {
			// Call DeptYearExam::QueryCount to perform the CountAll query
			return DeptYearExam::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = DeptYearExam::GetDatabase();

			// Create/Build out the QueryBuilder object with DeptYearExam-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'dept_year_exam');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				DeptYearExam::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('dept_year_exam');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single DeptYearExam object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return DeptYearExam the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = DeptYearExam::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new DeptYearExam object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = DeptYearExam::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return DeptYearExam::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of DeptYearExam objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return DeptYearExam[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = DeptYearExam::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return DeptYearExam::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = DeptYearExam::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of DeptYearExam objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = DeptYearExam::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = DeptYearExam::GetDatabase();

			$strQuery = DeptYearExam::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/deptyearexam', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = DeptYearExam::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this DeptYearExam
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'dept_year_exam';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'yearly_subject', $strAliasPrefix . 'yearly_subject');
			    $objBuilder->AddSelectItem($strTableName, 'exam', $strAliasPrefix . 'exam');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'yearly_subject', $strAliasPrefix . 'yearly_subject');
			    $objBuilder->AddSelectItem($strTableName, 'exam', $strAliasPrefix . 'exam');
			    $objBuilder->AddSelectItem($strTableName, 'marks', $strAliasPrefix . 'marks');
			    $objBuilder->AddSelectItem($strTableName, 'exam_grp', $strAliasPrefix . 'exam_grp');
			    $objBuilder->AddSelectItem($strTableName, 'max', $strAliasPrefix . 'max');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a DeptYearExam from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this DeptYearExam::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return DeptYearExam
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the DeptYearExam object
			$objToReturn = new DeptYearExam();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'yearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intYearlySubject = $objDbRow->GetColumn($strAliasName, 'Integer');
			$objToReturn->__intYearlySubject = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'exam';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intExam = $objDbRow->GetColumn($strAliasName, 'Integer');
			$objToReturn->__intExam = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'marks';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMarks = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'exam_grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intExamGrp = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'max';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMax = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->YearlySubject != $objPreviousItem->YearlySubject) {
						continue;
					}
					if ($objToReturn->Exam != $objPreviousItem->Exam) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'dept_year_exam__';

			// Check for YearlySubjectObject Early Binding
			$strAlias = $strAliasPrefix . 'yearly_subject__idyearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objYearlySubjectObject = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearly_subject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ExamObject Early Binding
			$strAlias = $strAliasPrefix . 'exam__idexam';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objExamObject = Exam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'exam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ExamGrpObject Early Binding
			$strAlias = $strAliasPrefix . 'exam_grp__idexam_group';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objExamGrpObject = ExamGroup::InstantiateDbRow($objDbRow, $strAliasPrefix . 'exam_grp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of DeptYearExams from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return DeptYearExam[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = DeptYearExam::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = DeptYearExam::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single DeptYearExam object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return DeptYearExam next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return DeptYearExam::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single DeptYearExam object,
		 * by YearlySubject, Exam Index(es)
		 * @param integer $intYearlySubject
		 * @param integer $intExam
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearExam
		*/
		public static function LoadByYearlySubjectExam($intYearlySubject, $intExam, $objOptionalClauses = null) {
			return DeptYearExam::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::DeptYearExam()->YearlySubject, $intYearlySubject),
					QQ::Equal(QQN::DeptYearExam()->Exam, $intExam)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of DeptYearExam objects,
		 * by Exam Index(es)
		 * @param integer $intExam
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearExam[]
		*/
		public static function LoadArrayByExam($intExam, $objOptionalClauses = null) {
			// Call DeptYearExam::QueryArray to perform the LoadArrayByExam query
			try {
				return DeptYearExam::QueryArray(
					QQ::Equal(QQN::DeptYearExam()->Exam, $intExam),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearExams
		 * by Exam Index(es)
		 * @param integer $intExam
		 * @return int
		*/
		public static function CountByExam($intExam) {
			// Call DeptYearExam::QueryCount to perform the CountByExam query
			return DeptYearExam::QueryCount(
				QQ::Equal(QQN::DeptYearExam()->Exam, $intExam)
			);
		}

		/**
		 * Load an array of DeptYearExam objects,
		 * by YearlySubject Index(es)
		 * @param integer $intYearlySubject
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearExam[]
		*/
		public static function LoadArrayByYearlySubject($intYearlySubject, $objOptionalClauses = null) {
			// Call DeptYearExam::QueryArray to perform the LoadArrayByYearlySubject query
			try {
				return DeptYearExam::QueryArray(
					QQ::Equal(QQN::DeptYearExam()->YearlySubject, $intYearlySubject),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearExams
		 * by YearlySubject Index(es)
		 * @param integer $intYearlySubject
		 * @return int
		*/
		public static function CountByYearlySubject($intYearlySubject) {
			// Call DeptYearExam::QueryCount to perform the CountByYearlySubject query
			return DeptYearExam::QueryCount(
				QQ::Equal(QQN::DeptYearExam()->YearlySubject, $intYearlySubject)
			);
		}

		/**
		 * Load an array of DeptYearExam objects,
		 * by ExamGrp Index(es)
		 * @param integer $intExamGrp
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearExam[]
		*/
		public static function LoadArrayByExamGrp($intExamGrp, $objOptionalClauses = null) {
			// Call DeptYearExam::QueryArray to perform the LoadArrayByExamGrp query
			try {
				return DeptYearExam::QueryArray(
					QQ::Equal(QQN::DeptYearExam()->ExamGrp, $intExamGrp),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearExams
		 * by ExamGrp Index(es)
		 * @param integer $intExamGrp
		 * @return int
		*/
		public static function CountByExamGrp($intExamGrp) {
			// Call DeptYearExam::QueryCount to perform the CountByExamGrp query
			return DeptYearExam::QueryCount(
				QQ::Equal(QQN::DeptYearExam()->ExamGrp, $intExamGrp)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this DeptYearExam
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return void
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = DeptYearExam::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `dept_year_exam` (
							`yearly_subject`,
							`exam`,
							`marks`,
							`exam_grp`,
							`max`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intYearlySubject) . ',
							' . $objDatabase->SqlVariable($this->intExam) . ',
							' . $objDatabase->SqlVariable($this->intMarks) . ',
							' . $objDatabase->SqlVariable($this->intExamGrp) . ',
							' . $objDatabase->SqlVariable($this->intMax) . '
						)
					');


				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`dept_year_exam`
						SET
							`yearly_subject` = ' . $objDatabase->SqlVariable($this->intYearlySubject) . ',
							`exam` = ' . $objDatabase->SqlVariable($this->intExam) . ',
							`marks` = ' . $objDatabase->SqlVariable($this->intMarks) . ',
							`exam_grp` = ' . $objDatabase->SqlVariable($this->intExamGrp) . ',
							`max` = ' . $objDatabase->SqlVariable($this->intMax) . '
						WHERE
							`yearly_subject` = ' . $objDatabase->SqlVariable($this->__intYearlySubject) . ' AND 
							`exam` = ' . $objDatabase->SqlVariable($this->__intExam) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;
			$this->__intYearlySubject = $this->intYearlySubject;
			$this->__intExam = $this->intExam;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this DeptYearExam
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intYearlySubject)) || (is_null($this->intExam)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this DeptYearExam with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearExam::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_exam`
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intYearlySubject) . ' AND
					`exam` = ' . $objDatabase->SqlVariable($this->intExam) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this DeptYearExam ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'DeptYearExam', $this->intYearlySubject, $this->intExam);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all DeptYearExams
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = DeptYearExam::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_exam`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate dept_year_exam table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = DeptYearExam::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `dept_year_exam`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this DeptYearExam from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved DeptYearExam object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = DeptYearExam::Load($this->intYearlySubject, $this->intExam);

			// Update $this's local variables to match
			$this->YearlySubject = $objReloaded->YearlySubject;
			$this->__intYearlySubject = $this->intYearlySubject;
			$this->Exam = $objReloaded->Exam;
			$this->__intExam = $this->intExam;
			$this->intMarks = $objReloaded->intMarks;
			$this->ExamGrp = $objReloaded->ExamGrp;
			$this->intMax = $objReloaded->intMax;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'YearlySubject':
					/**
					 * Gets the value for intYearlySubject (PK)
					 * @return integer
					 */
					return $this->intYearlySubject;

				case 'Exam':
					/**
					 * Gets the value for intExam (PK)
					 * @return integer
					 */
					return $this->intExam;

				case 'Marks':
					/**
					 * Gets the value for intMarks (Not Null)
					 * @return integer
					 */
					return $this->intMarks;

				case 'ExamGrp':
					/**
					 * Gets the value for intExamGrp 
					 * @return integer
					 */
					return $this->intExamGrp;

				case 'Max':
					/**
					 * Gets the value for intMax 
					 * @return integer
					 */
					return $this->intMax;


				///////////////////
				// Member Objects
				///////////////////
				case 'YearlySubjectObject':
					/**
					 * Gets the value for the YearlySubject object referenced by intYearlySubject (PK)
					 * @return YearlySubject
					 */
					try {
						if ((!$this->objYearlySubjectObject) && (!is_null($this->intYearlySubject)))
							$this->objYearlySubjectObject = YearlySubject::Load($this->intYearlySubject);
						return $this->objYearlySubjectObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ExamObject':
					/**
					 * Gets the value for the Exam object referenced by intExam (PK)
					 * @return Exam
					 */
					try {
						if ((!$this->objExamObject) && (!is_null($this->intExam)))
							$this->objExamObject = Exam::Load($this->intExam);
						return $this->objExamObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ExamGrpObject':
					/**
					 * Gets the value for the ExamGroup object referenced by intExamGrp 
					 * @return ExamGroup
					 */
					try {
						if ((!$this->objExamGrpObject) && (!is_null($this->intExamGrp)))
							$this->objExamGrpObject = ExamGroup::Load($this->intExamGrp);
						return $this->objExamGrpObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'YearlySubject':
					/**
					 * Sets the value for intYearlySubject (PK)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objYearlySubjectObject = null;
						return ($this->intYearlySubject = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Exam':
					/**
					 * Sets the value for intExam (PK)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objExamObject = null;
						return ($this->intExam = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Marks':
					/**
					 * Sets the value for intMarks (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intMarks = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ExamGrp':
					/**
					 * Sets the value for intExamGrp 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objExamGrpObject = null;
						return ($this->intExamGrp = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Max':
					/**
					 * Sets the value for intMax 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intMax = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'YearlySubjectObject':
					/**
					 * Sets the value for the YearlySubject object referenced by intYearlySubject (PK)
					 * @param YearlySubject $mixValue
					 * @return YearlySubject
					 */
					if (is_null($mixValue)) {
						$this->intYearlySubject = null;
						$this->objYearlySubjectObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a YearlySubject object
						try {
							$mixValue = QType::Cast($mixValue, 'YearlySubject');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED YearlySubject object
						if (is_null($mixValue->IdyearlySubject))
							throw new QCallerException('Unable to set an unsaved YearlySubjectObject for this DeptYearExam');

						// Update Local Member Variables
						$this->objYearlySubjectObject = $mixValue;
						$this->intYearlySubject = $mixValue->IdyearlySubject;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ExamObject':
					/**
					 * Sets the value for the Exam object referenced by intExam (PK)
					 * @param Exam $mixValue
					 * @return Exam
					 */
					if (is_null($mixValue)) {
						$this->intExam = null;
						$this->objExamObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Exam object
						try {
							$mixValue = QType::Cast($mixValue, 'Exam');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Exam object
						if (is_null($mixValue->Idexam))
							throw new QCallerException('Unable to set an unsaved ExamObject for this DeptYearExam');

						// Update Local Member Variables
						$this->objExamObject = $mixValue;
						$this->intExam = $mixValue->Idexam;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ExamGrpObject':
					/**
					 * Sets the value for the ExamGroup object referenced by intExamGrp 
					 * @param ExamGroup $mixValue
					 * @return ExamGroup
					 */
					if (is_null($mixValue)) {
						$this->intExamGrp = null;
						$this->objExamGrpObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a ExamGroup object
						try {
							$mixValue = QType::Cast($mixValue, 'ExamGroup');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED ExamGroup object
						if (is_null($mixValue->IdexamGroup))
							throw new QCallerException('Unable to set an unsaved ExamGrpObject for this DeptYearExam');

						// Update Local Member Variables
						$this->objExamGrpObject = $mixValue;
						$this->intExamGrp = $mixValue->IdexamGroup;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "dept_year_exam";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[DeptYearExam::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="DeptYearExam"><sequence>';
			$strToReturn .= '<element name="YearlySubjectObject" type="xsd1:YearlySubject"/>';
			$strToReturn .= '<element name="ExamObject" type="xsd1:Exam"/>';
			$strToReturn .= '<element name="Marks" type="xsd:int"/>';
			$strToReturn .= '<element name="ExamGrpObject" type="xsd1:ExamGroup"/>';
			$strToReturn .= '<element name="Max" type="xsd:int"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('DeptYearExam', $strComplexTypeArray)) {
				$strComplexTypeArray['DeptYearExam'] = DeptYearExam::GetSoapComplexTypeXml();
				YearlySubject::AlterSoapComplexTypeArray($strComplexTypeArray);
				Exam::AlterSoapComplexTypeArray($strComplexTypeArray);
				ExamGroup::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, DeptYearExam::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new DeptYearExam();
			if ((property_exists($objSoapObject, 'YearlySubjectObject')) &&
				($objSoapObject->YearlySubjectObject))
				$objToReturn->YearlySubjectObject = YearlySubject::GetObjectFromSoapObject($objSoapObject->YearlySubjectObject);
			if ((property_exists($objSoapObject, 'ExamObject')) &&
				($objSoapObject->ExamObject))
				$objToReturn->ExamObject = Exam::GetObjectFromSoapObject($objSoapObject->ExamObject);
			if (property_exists($objSoapObject, 'Marks'))
				$objToReturn->intMarks = $objSoapObject->Marks;
			if ((property_exists($objSoapObject, 'ExamGrpObject')) &&
				($objSoapObject->ExamGrpObject))
				$objToReturn->ExamGrpObject = ExamGroup::GetObjectFromSoapObject($objSoapObject->ExamGrpObject);
			if (property_exists($objSoapObject, 'Max'))
				$objToReturn->intMax = $objSoapObject->Max;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, DeptYearExam::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objYearlySubjectObject)
				$objObject->objYearlySubjectObject = YearlySubject::GetSoapObjectFromObject($objObject->objYearlySubjectObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intYearlySubject = null;
			if ($objObject->objExamObject)
				$objObject->objExamObject = Exam::GetSoapObjectFromObject($objObject->objExamObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intExam = null;
			if ($objObject->objExamGrpObject)
				$objObject->objExamGrpObject = ExamGroup::GetSoapObjectFromObject($objObject->objExamGrpObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intExamGrp = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['YearlySubject'] = $this->intYearlySubject;
			$iArray['Exam'] = $this->intExam;
			$iArray['Marks'] = $this->intMarks;
			$iArray['ExamGrp'] = $this->intExamGrp;
			$iArray['Max'] = $this->intMax;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  array( $this->intYearlySubject,  $this->intExam) ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $YearlySubject
     * @property-read QQNodeYearlySubject $YearlySubjectObject
     * @property-read QQNode $Exam
     * @property-read QQNodeExam $ExamObject
     * @property-read QQNode $Marks
     * @property-read QQNode $ExamGrp
     * @property-read QQNodeExamGroup $ExamGrpObject
     * @property-read QQNode $Max
     *
     *

     * @property-read QQNodeYearlySubject $_PrimaryKeyNode
     **/
	class QQNodeDeptYearExam extends QQNode {
		protected $strTableName = 'dept_year_exam';
		protected $strPrimaryKey = 'yearly_subject';
		protected $strClassName = 'DeptYearExam';
		public function __get($strName) {
			switch ($strName) {
				case 'YearlySubject':
					return new QQNode('yearly_subject', 'YearlySubject', 'Integer', $this);
				case 'YearlySubjectObject':
					return new QQNodeYearlySubject('yearly_subject', 'YearlySubjectObject', 'Integer', $this);
				case 'Exam':
					return new QQNode('exam', 'Exam', 'Integer', $this);
				case 'ExamObject':
					return new QQNodeExam('exam', 'ExamObject', 'Integer', $this);
				case 'Marks':
					return new QQNode('marks', 'Marks', 'Integer', $this);
				case 'ExamGrp':
					return new QQNode('exam_grp', 'ExamGrp', 'Integer', $this);
				case 'ExamGrpObject':
					return new QQNodeExamGroup('exam_grp', 'ExamGrpObject', 'Integer', $this);
				case 'Max':
					return new QQNode('max', 'Max', 'Integer', $this);

				case '_PrimaryKeyNode':
					return new QQNodeYearlySubject('yearly_subject', 'YearlySubject', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $YearlySubject
     * @property-read QQNodeYearlySubject $YearlySubjectObject
     * @property-read QQNode $Exam
     * @property-read QQNodeExam $ExamObject
     * @property-read QQNode $Marks
     * @property-read QQNode $ExamGrp
     * @property-read QQNodeExamGroup $ExamGrpObject
     * @property-read QQNode $Max
     *
     *

     * @property-read QQNodeYearlySubject $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeDeptYearExam extends QQReverseReferenceNode {
		protected $strTableName = 'dept_year_exam';
		protected $strPrimaryKey = 'yearly_subject';
		protected $strClassName = 'DeptYearExam';
		public function __get($strName) {
			switch ($strName) {
				case 'YearlySubject':
					return new QQNode('yearly_subject', 'YearlySubject', 'integer', $this);
				case 'YearlySubjectObject':
					return new QQNodeYearlySubject('yearly_subject', 'YearlySubjectObject', 'integer', $this);
				case 'Exam':
					return new QQNode('exam', 'Exam', 'integer', $this);
				case 'ExamObject':
					return new QQNodeExam('exam', 'ExamObject', 'integer', $this);
				case 'Marks':
					return new QQNode('marks', 'Marks', 'integer', $this);
				case 'ExamGrp':
					return new QQNode('exam_grp', 'ExamGrp', 'integer', $this);
				case 'ExamGrpObject':
					return new QQNodeExamGroup('exam_grp', 'ExamGrpObject', 'integer', $this);
				case 'Max':
					return new QQNode('max', 'Max', 'integer', $this);

				case '_PrimaryKeyNode':
					return new QQNodeYearlySubject('yearly_subject', 'YearlySubject', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
