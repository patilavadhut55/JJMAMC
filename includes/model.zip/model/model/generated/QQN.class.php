<?php
	class QQN {
		/**
		 * @return QQNodeAcademicTemplet
		 */
		static public function AcademicTemplet() {
			return new QQNodeAcademicTemplet('academic_templet', null, null);
		}
		/**
		 * @return QQNodeAcademicYear
		 */
		static public function AcademicYear() {
			return new QQNodeAcademicYear('academic_year', null, null);
		}
		/**
		 * @return QQNodeAddress
		 */
		static public function Address() {
			return new QQNodeAddress('address', null, null);
		}
		/**
		 * @return QQNodeAppApproval
		 */
		static public function AppApproval() {
			return new QQNodeAppApproval('app_approval', null, null);
		}
		/**
		 * @return QQNodeAppApprovalHasRemark
		 */
		static public function AppApprovalHasRemark() {
			return new QQNodeAppApprovalHasRemark('app_approval_has_remark', null, null);
		}
		/**
		 * @return QQNodeAppDocs
		 */
		static public function AppDocs() {
			return new QQNodeAppDocs('app_docs', null, null);
		}
		/**
		 * @return QQNodeAppStatus
		 */
		static public function AppStatus() {
			return new QQNodeAppStatus('app_status', null, null);
		}
		/**
		 * @return QQNodeApplication
		 */
		static public function Application() {
			return new QQNodeApplication('application', null, null);
		}
		/**
		 * @return QQNodeApprovel
		 */
		static public function Approvel() {
			return new QQNodeApprovel('approvel', null, null);
		}
		/**
		 * @return QQNodeArticle
		 */
		static public function Article() {
			return new QQNodeArticle('article', null, null);
		}
		/**
		 * @return QQNodeArticleGrp
		 */
		static public function ArticleGrp() {
			return new QQNodeArticleGrp('article_grp', null, null);
		}
		/**
		 * @return QQNodeBloodGroup
		 */
		static public function BloodGroup() {
			return new QQNodeBloodGroup('blood_group', null, null);
		}
		/**
		 * @return QQNodeCalenderYear
		 */
		static public function CalenderYear() {
			return new QQNodeCalenderYear('calender_year', null, null);
		}
		/**
		 * @return QQNodeCast
		 */
		static public function Cast() {
			return new QQNodeCast('cast', null, null);
		}
		/**
		 * @return QQNodeCaste
		 */
		static public function Caste() {
			return new QQNodeCaste('caste', null, null);
		}
		/**
		 * @return QQNodeCertificateGroup
		 */
		static public function CertificateGroup() {
			return new QQNodeCertificateGroup('certificate_group', null, null);
		}
		/**
		 * @return QQNodeCertificateTemplet
		 */
		static public function CertificateTemplet() {
			return new QQNodeCertificateTemplet('certificate_templet', null, null);
		}
		/**
		 * @return QQNodeCertificateTempletHasRemark
		 */
		static public function CertificateTempletHasRemark() {
			return new QQNodeCertificateTempletHasRemark('certificate_templet_has_remark', null, null);
		}
		/**
		 * @return QQNodeCourseGrp
		 */
		static public function CourseGrp() {
			return new QQNodeCourseGrp('course_grp', null, null);
		}
		/**
		 * @return QQNodeCss
		 */
		static public function Css() {
			return new QQNodeCss('css', null, null);
		}
		/**
		 * @return QQNodeDecision
		 */
		static public function Decision() {
			return new QQNodeDecision('decision', null, null);
		}
		/**
		 * @return QQNodeDeptYear
		 */
		static public function DeptYear() {
			return new QQNodeDeptYear('dept_year', null, null);
		}
		/**
		 * @return QQNodeDeptYearEvents
		 */
		static public function DeptYearEvents() {
			return new QQNodeDeptYearEvents('dept_year_events', null, null);
		}
		/**
		 * @return QQNodeDeptYearExam
		 */
		static public function DeptYearExam() {
			return new QQNodeDeptYearExam('dept_year_exam', null, null);
		}
		/**
		 * @return QQNodeEvent
		 */
		static public function Event() {
			return new QQNodeEvent('event', null, null);
		}
		/**
		 * @return QQNodeExam
		 */
		static public function Exam() {
			return new QQNodeExam('exam', null, null);
		}
		/**
		 * @return QQNodeExamGroup
		 */
		static public function ExamGroup() {
			return new QQNodeExamGroup('exam_group', null, null);
		}
		/**
		 * @return QQNodeFeesTemplet
		 */
		static public function FeesTemplet() {
			return new QQNodeFeesTemplet('fees_templet', null, null);
		}
		/**
		 * @return QQNodeGardian
		 */
		static public function Gardian() {
			return new QQNodeGardian('gardian', null, null);
		}
		/**
		 * @return QQNodeGardianCat
		 */
		static public function GardianCat() {
			return new QQNodeGardianCat('gardian_cat', null, null);
		}
		/**
		 * @return QQNodeGender
		 */
		static public function Gender() {
			return new QQNodeGender('gender', null, null);
		}
		/**
		 * @return QQNodeGroup
		 */
		static public function Group() {
			return new QQNodeGroup('group', null, null);
		}
		/**
		 * @return QQNodeHandicapedCat
		 */
		static public function HandicapedCat() {
			return new QQNodeHandicapedCat('handicaped_cat', null, null);
		}
		/**
		 * @return QQNodeHistory
		 */
		static public function History() {
			return new QQNodeHistory('history', null, null);
		}
		/**
		 * @return QQNodeImpact
		 */
		static public function Impact() {
			return new QQNodeImpact('impact', null, null);
		}
		/**
		 * @return QQNodeLedger
		 */
		static public function Ledger() {
			return new QQNodeLedger('ledger', null, null);
		}
		/**
		 * @return QQNodeLedgerDetails
		 */
		static public function LedgerDetails() {
			return new QQNodeLedgerDetails('ledger_details', null, null);
		}
		/**
		 * @return QQNodeLog
		 */
		static public function Log() {
			return new QQNodeLog('log', null, null);
		}
		/**
		 * @return QQNodeLogGrp
		 */
		static public function LogGrp() {
			return new QQNodeLogGrp('log_grp', null, null);
		}
		/**
		 * @return QQNodeLogin
		 */
		static public function Login() {
			return new QQNodeLogin('login', null, null);
		}
		/**
		 * @return QQNodeLoginHasRole
		 */
		static public function LoginHasRole() {
			return new QQNodeLoginHasRole('login_has_role', null, null);
		}
		/**
		 * @return QQNodeMarrialStatus
		 */
		static public function MarrialStatus() {
			return new QQNodeMarrialStatus('marrial_status', null, null);
		}
		/**
		 * @return QQNodeMenu
		 */
		static public function Menu() {
			return new QQNodeMenu('menu', null, null);
		}
		/**
		 * @return QQNodeMenuHasArticle
		 */
		static public function MenuHasArticle() {
			return new QQNodeMenuHasArticle('menu_has_article', null, null);
		}
		/**
		 * @return QQNodeMenuPosition
		 */
		static public function MenuPosition() {
			return new QQNodeMenuPosition('menu_position', null, null);
		}
		/**
		 * @return QQNodeMotherTongue
		 */
		static public function MotherTongue() {
			return new QQNodeMotherTongue('mother_tongue', null, null);
		}
		/**
		 * @return QQNodeNationality
		 */
		static public function Nationality() {
			return new QQNodeNationality('nationality', null, null);
		}
		/**
		 * @return QQNodeNote
		 */
		static public function Note() {
			return new QQNodeNote('note', null, null);
		}
		/**
		 * @return QQNodeOccurance
		 */
		static public function Occurance() {
			return new QQNodeOccurance('occurance', null, null);
		}
		/**
		 * @return QQNodePlace
		 */
		static public function Place() {
			return new QQNodePlace('place', null, null);
		}
		/**
		 * @return QQNodePlaceGrp
		 */
		static public function PlaceGrp() {
			return new QQNodePlaceGrp('place_grp', null, null);
		}
		/**
		 * @return QQNodePrefix
		 */
		static public function Prefix() {
			return new QQNodePrefix('prefix', null, null);
		}
		/**
		 * @return QQNodePriceHistory
		 */
		static public function PriceHistory() {
			return new QQNodePriceHistory('price_history', null, null);
		}
		/**
		 * @return QQNodeProfile
		 */
		static public function Profile() {
			return new QQNodeProfile('profile', null, null);
		}
		/**
		 * @return QQNodeReligion
		 */
		static public function Religion() {
			return new QQNodeReligion('religion', null, null);
		}
		/**
		 * @return QQNodeRemark
		 */
		static public function Remark() {
			return new QQNodeRemark('remark', null, null);
		}
		/**
		 * @return QQNodeReproducible
		 */
		static public function Reproducible() {
			return new QQNodeReproducible('reproducible', null, null);
		}
		/**
		 * @return QQNodeRole
		 */
		static public function Role() {
			return new QQNodeRole('role', null, null);
		}
		/**
		 * @return QQNodeRoleHasMenu
		 */
		static public function RoleHasMenu() {
			return new QQNodeRoleHasMenu('role_has_menu', null, null);
		}
		/**
		 * @return QQNodeScan
		 */
		static public function Scan() {
			return new QQNodeScan('scan', null, null);
		}
		/**
		 * @return QQNodeSerials
		 */
		static public function Serials() {
			return new QQNodeSerials('serials', null, null);
		}
		/**
		 * @return QQNodeSettings
		 */
		static public function Settings() {
			return new QQNodeSettings('settings', null, null);
		}
		/**
		 * @return QQNodeSignPatch
		 */
		static public function SignPatch() {
			return new QQNodeSignPatch('sign_patch', null, null);
		}
		/**
		 * @return QQNodeStatus
		 */
		static public function Status() {
			return new QQNodeStatus('status', null, null);
		}
		/**
		 * @return QQNodeStock
		 */
		static public function Stock() {
			return new QQNodeStock('stock', null, null);
		}
		/**
		 * @return QQNodeStockGrp
		 */
		static public function StockGrp() {
			return new QQNodeStockGrp('stock_grp', null, null);
		}
		/**
		 * @return QQNodeSubject
		 */
		static public function Subject() {
			return new QQNodeSubject('subject', null, null);
		}
		/**
		 * @return QQNodeTempletDocuments
		 */
		static public function TempletDocuments() {
			return new QQNodeTempletDocuments('templet_documents', null, null);
		}
		/**
		 * @return QQNodeType
		 */
		static public function Type() {
			return new QQNodeType('type', null, null);
		}
		/**
		 * @return QQNodeUnit
		 */
		static public function Unit() {
			return new QQNodeUnit('unit', null, null);
		}
		/**
		 * @return QQNodeVoucher
		 */
		static public function Voucher() {
			return new QQNodeVoucher('voucher', null, null);
		}
		/**
		 * @return QQNodeVoucherGrp
		 */
		static public function VoucherGrp() {
			return new QQNodeVoucherGrp('voucher_grp', null, null);
		}
		/**
		 * @return QQNodeVoucherHasItem
		 */
		static public function VoucherHasItem() {
			return new QQNodeVoucherHasItem('voucher_has_item', null, null);
		}
		/**
		 * @return QQNodeYearlySubject
		 */
		static public function YearlySubject() {
			return new QQNodeYearlySubject('yearly_subject', null, null);
		}
	}
?>