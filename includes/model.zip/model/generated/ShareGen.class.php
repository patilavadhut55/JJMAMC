<?php
	/**
	 * The abstract ShareGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Share subclass which
	 * extends this ShareGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Share class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idshare the value for intIdshare (Read-Only PK)
	 * @property-read string $Date the value for strDate (Read-Only Timestamp)
	 * @property integer $Note the value for intNote (Not Null)
	 * @property integer $From the value for intFrom (Not Null)
	 * @property integer $To the value for intTo (Not Null)
	 * @property integer $Reminder the value for intReminder 
	 * @property string $Data the value for strData 
	 * @property Notes $NoteObject the value for the Notes object referenced by intNote (Not Null)
	 * @property Ledger $FromObject the value for the Ledger object referenced by intFrom (Not Null)
	 * @property Ledger $ToObject the value for the Ledger object referenced by intTo (Not Null)
	 * @property Share $ReminderObject the value for the Share object referenced by intReminder 
	 * @property-read Share $_ShareAsReminder the value for the private _objShareAsReminder (Read-Only) if set due to an expansion on the share.reminder reverse relationship
	 * @property-read Share[] $_ShareAsReminderArray the value for the private _objShareAsReminderArray (Read-Only) if set due to an ExpandAsArray on the share.reminder reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class ShareGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column share.idshare
		 * @var integer intIdshare
		 */
		protected $intIdshare;
		const IdshareDefault = null;


		/**
		 * Protected member variable that maps to the database column share.date
		 * @var string strDate
		 */
		protected $strDate;
		const DateDefault = null;


		/**
		 * Protected member variable that maps to the database column share.note
		 * @var integer intNote
		 */
		protected $intNote;
		const NoteDefault = null;


		/**
		 * Protected member variable that maps to the database column share.from
		 * @var integer intFrom
		 */
		protected $intFrom;
		const FromDefault = null;


		/**
		 * Protected member variable that maps to the database column share.to
		 * @var integer intTo
		 */
		protected $intTo;
		const ToDefault = null;


		/**
		 * Protected member variable that maps to the database column share.reminder
		 * @var integer intReminder
		 */
		protected $intReminder;
		const ReminderDefault = null;


		/**
		 * Protected member variable that maps to the database column share.data
		 * @var string strData
		 */
		protected $strData;
		const DataMaxLength = 45;
		const DataDefault = null;


		/**
		 * Private member variable that stores a reference to a single ShareAsReminder object
		 * (of type Share), if this Share object was restored with
		 * an expansion on the share association table.
		 * @var Share _objShareAsReminder;
		 */
		private $_objShareAsReminder;

		/**
		 * Private member variable that stores a reference to an array of ShareAsReminder objects
		 * (of type Share[]), if this Share object was restored with
		 * an ExpandAsArray on the share association table.
		 * @var Share[] _objShareAsReminderArray;
		 */
		private $_objShareAsReminderArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column share.note.
		 *
		 * NOTE: Always use the NoteObject property getter to correctly retrieve this Notes object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Notes objNoteObject
		 */
		protected $objNoteObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column share.from.
		 *
		 * NOTE: Always use the FromObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objFromObject
		 */
		protected $objFromObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column share.to.
		 *
		 * NOTE: Always use the ToObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objToObject
		 */
		protected $objToObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column share.reminder.
		 *
		 * NOTE: Always use the ReminderObject property getter to correctly retrieve this Share object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Share objReminderObject
		 */
		protected $objReminderObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdshare = Share::IdshareDefault;
			$this->strDate = Share::DateDefault;
			$this->intNote = Share::NoteDefault;
			$this->intFrom = Share::FromDefault;
			$this->intTo = Share::ToDefault;
			$this->intReminder = Share::ReminderDefault;
			$this->strData = Share::DataDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Share from PK Info
		 * @param integer $intIdshare
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Share
		 */
		public static function Load($intIdshare, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Share', $intIdshare);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Share::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Share()->Idshare, $intIdshare)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Shares
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Share[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Share::QueryArray to perform the LoadAll query
			try {
				return Share::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Shares
		 * @return int
		 */
		public static function CountAll() {
			// Call Share::QueryCount to perform the CountAll query
			return Share::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Share::GetDatabase();

			// Create/Build out the QueryBuilder object with Share-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'share');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Share::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('share');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Share object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Share the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Share::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Share object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Share::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Share::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Share objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Share[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Share::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Share::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Share::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Share objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Share::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Share::GetDatabase();

			$strQuery = Share::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/share', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Share::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Share
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'share';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idshare', $strAliasPrefix . 'idshare');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idshare', $strAliasPrefix . 'idshare');
			    $objBuilder->AddSelectItem($strTableName, 'date', $strAliasPrefix . 'date');
			    $objBuilder->AddSelectItem($strTableName, 'note', $strAliasPrefix . 'note');
			    $objBuilder->AddSelectItem($strTableName, 'from', $strAliasPrefix . 'from');
			    $objBuilder->AddSelectItem($strTableName, 'to', $strAliasPrefix . 'to');
			    $objBuilder->AddSelectItem($strTableName, 'reminder', $strAliasPrefix . 'reminder');
			    $objBuilder->AddSelectItem($strTableName, 'data', $strAliasPrefix . 'data');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Share from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Share::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Share
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idshare';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdshare == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'share__';


						// Expanding reverse references: ShareAsReminder
						$strAlias = $strAliasPrefix . 'shareasreminder__idshare';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objShareAsReminderArray)
								$objPreviousItem->_objShareAsReminderArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objShareAsReminderArray)) {
								$objPreviousChildItems = $objPreviousItem->_objShareAsReminderArray;
								$objChildItem = Share::InstantiateDbRow($objDbRow, $strAliasPrefix . 'shareasreminder__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objShareAsReminderArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objShareAsReminderArray[] = Share::InstantiateDbRow($objDbRow, $strAliasPrefix . 'shareasreminder__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'share__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Share object
			$objToReturn = new Share();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idshare';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdshare = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strDate = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'note';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intNote = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'from';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intFrom = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intTo = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'reminder';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intReminder = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'data';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strData = $objDbRow->GetColumn($strAliasName, 'VarChar');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idshare != $objPreviousItem->Idshare) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objShareAsReminderArray);
					$cnt = count($objToReturn->_objShareAsReminderArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objShareAsReminderArray, $objToReturn->_objShareAsReminderArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'share__';

			// Check for NoteObject Early Binding
			$strAlias = $strAliasPrefix . 'note__idnotes';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objNoteObject = Notes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'note__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for FromObject Early Binding
			$strAlias = $strAliasPrefix . 'from__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objFromObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'from__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ToObject Early Binding
			$strAlias = $strAliasPrefix . 'to__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objToObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'to__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ReminderObject Early Binding
			$strAlias = $strAliasPrefix . 'reminder__idshare';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objReminderObject = Share::InstantiateDbRow($objDbRow, $strAliasPrefix . 'reminder__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for ShareAsReminder Virtual Binding
			$strAlias = $strAliasPrefix . 'shareasreminder__idshare';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objShareAsReminderArray)
				$objToReturn->_objShareAsReminderArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objShareAsReminderArray[] = Share::InstantiateDbRow($objDbRow, $strAliasPrefix . 'shareasreminder__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objShareAsReminder = Share::InstantiateDbRow($objDbRow, $strAliasPrefix . 'shareasreminder__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Shares from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Share[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Share::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Share::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Share object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Share next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Share::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Share object,
		 * by Idshare Index(es)
		 * @param integer $intIdshare
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Share
		*/
		public static function LoadByIdshare($intIdshare, $objOptionalClauses = null) {
			return Share::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Share()->Idshare, $intIdshare)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Share objects,
		 * by Note Index(es)
		 * @param integer $intNote
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Share[]
		*/
		public static function LoadArrayByNote($intNote, $objOptionalClauses = null) {
			// Call Share::QueryArray to perform the LoadArrayByNote query
			try {
				return Share::QueryArray(
					QQ::Equal(QQN::Share()->Note, $intNote),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Shares
		 * by Note Index(es)
		 * @param integer $intNote
		 * @return int
		*/
		public static function CountByNote($intNote) {
			// Call Share::QueryCount to perform the CountByNote query
			return Share::QueryCount(
				QQ::Equal(QQN::Share()->Note, $intNote)
			);
		}

		/**
		 * Load an array of Share objects,
		 * by From Index(es)
		 * @param integer $intFrom
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Share[]
		*/
		public static function LoadArrayByFrom($intFrom, $objOptionalClauses = null) {
			// Call Share::QueryArray to perform the LoadArrayByFrom query
			try {
				return Share::QueryArray(
					QQ::Equal(QQN::Share()->From, $intFrom),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Shares
		 * by From Index(es)
		 * @param integer $intFrom
		 * @return int
		*/
		public static function CountByFrom($intFrom) {
			// Call Share::QueryCount to perform the CountByFrom query
			return Share::QueryCount(
				QQ::Equal(QQN::Share()->From, $intFrom)
			);
		}

		/**
		 * Load an array of Share objects,
		 * by To Index(es)
		 * @param integer $intTo
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Share[]
		*/
		public static function LoadArrayByTo($intTo, $objOptionalClauses = null) {
			// Call Share::QueryArray to perform the LoadArrayByTo query
			try {
				return Share::QueryArray(
					QQ::Equal(QQN::Share()->To, $intTo),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Shares
		 * by To Index(es)
		 * @param integer $intTo
		 * @return int
		*/
		public static function CountByTo($intTo) {
			// Call Share::QueryCount to perform the CountByTo query
			return Share::QueryCount(
				QQ::Equal(QQN::Share()->To, $intTo)
			);
		}

		/**
		 * Load an array of Share objects,
		 * by Reminder Index(es)
		 * @param integer $intReminder
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Share[]
		*/
		public static function LoadArrayByReminder($intReminder, $objOptionalClauses = null) {
			// Call Share::QueryArray to perform the LoadArrayByReminder query
			try {
				return Share::QueryArray(
					QQ::Equal(QQN::Share()->Reminder, $intReminder),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Shares
		 * by Reminder Index(es)
		 * @param integer $intReminder
		 * @return int
		*/
		public static function CountByReminder($intReminder) {
			// Call Share::QueryCount to perform the CountByReminder query
			return Share::QueryCount(
				QQ::Equal(QQN::Share()->Reminder, $intReminder)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Share
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Share::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `share` (
							`note`,
							`from`,
							`to`,
							`reminder`,
							`data`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intNote) . ',
							' . $objDatabase->SqlVariable($this->intFrom) . ',
							' . $objDatabase->SqlVariable($this->intTo) . ',
							' . $objDatabase->SqlVariable($this->intReminder) . ',
							' . $objDatabase->SqlVariable($this->strData) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdshare = $objDatabase->InsertId('share', 'idshare');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)
					if (!$blnForceUpdate) {
						// Perform the Optimistic Locking check
						$objResult = $objDatabase->Query('
							SELECT
								`date`
							FROM
								`share`
							WHERE
							`idshare` = ' . $objDatabase->SqlVariable($this->intIdshare) . '
						');

						$objRow = $objResult->FetchArray();
						if ($objRow[0] != $this->strDate)
							throw new QOptimisticLockingException('Share');
					}

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`share`
						SET
							`note` = ' . $objDatabase->SqlVariable($this->intNote) . ',
							`from` = ' . $objDatabase->SqlVariable($this->intFrom) . ',
							`to` = ' . $objDatabase->SqlVariable($this->intTo) . ',
							`reminder` = ' . $objDatabase->SqlVariable($this->intReminder) . ',
							`data` = ' . $objDatabase->SqlVariable($this->strData) . '
						WHERE
							`idshare` = ' . $objDatabase->SqlVariable($this->intIdshare) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;

			// Update Local Timestamp
			$objResult = $objDatabase->Query('
				SELECT
					`date`
				FROM
					`share`
				WHERE
							`idshare` = ' . $objDatabase->SqlVariable($this->intIdshare) . '
			');

			$objRow = $objResult->FetchArray();
			$this->strDate = $objRow[0];

			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Share
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdshare)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Share with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Share::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`share`
				WHERE
					`idshare` = ' . $objDatabase->SqlVariable($this->intIdshare) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Share ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Share', $this->intIdshare);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Shares
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Share::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`share`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate share table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Share::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `share`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Share from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Share object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Share::Load($this->intIdshare);

			// Update $this's local variables to match
			$this->strDate = $objReloaded->strDate;
			$this->Note = $objReloaded->Note;
			$this->From = $objReloaded->From;
			$this->To = $objReloaded->To;
			$this->Reminder = $objReloaded->Reminder;
			$this->strData = $objReloaded->strData;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idshare':
					/**
					 * Gets the value for intIdshare (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdshare;

				case 'Date':
					/**
					 * Gets the value for strDate (Read-Only Timestamp)
					 * @return string
					 */
					return $this->strDate;

				case 'Note':
					/**
					 * Gets the value for intNote (Not Null)
					 * @return integer
					 */
					return $this->intNote;

				case 'From':
					/**
					 * Gets the value for intFrom (Not Null)
					 * @return integer
					 */
					return $this->intFrom;

				case 'To':
					/**
					 * Gets the value for intTo (Not Null)
					 * @return integer
					 */
					return $this->intTo;

				case 'Reminder':
					/**
					 * Gets the value for intReminder 
					 * @return integer
					 */
					return $this->intReminder;

				case 'Data':
					/**
					 * Gets the value for strData 
					 * @return string
					 */
					return $this->strData;


				///////////////////
				// Member Objects
				///////////////////
				case 'NoteObject':
					/**
					 * Gets the value for the Notes object referenced by intNote (Not Null)
					 * @return Notes
					 */
					try {
						if ((!$this->objNoteObject) && (!is_null($this->intNote)))
							$this->objNoteObject = Notes::Load($this->intNote);
						return $this->objNoteObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'FromObject':
					/**
					 * Gets the value for the Ledger object referenced by intFrom (Not Null)
					 * @return Ledger
					 */
					try {
						if ((!$this->objFromObject) && (!is_null($this->intFrom)))
							$this->objFromObject = Ledger::Load($this->intFrom);
						return $this->objFromObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ToObject':
					/**
					 * Gets the value for the Ledger object referenced by intTo (Not Null)
					 * @return Ledger
					 */
					try {
						if ((!$this->objToObject) && (!is_null($this->intTo)))
							$this->objToObject = Ledger::Load($this->intTo);
						return $this->objToObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ReminderObject':
					/**
					 * Gets the value for the Share object referenced by intReminder 
					 * @return Share
					 */
					try {
						if ((!$this->objReminderObject) && (!is_null($this->intReminder)))
							$this->objReminderObject = Share::Load($this->intReminder);
						return $this->objReminderObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_ShareAsReminder':
					/**
					 * Gets the value for the private _objShareAsReminder (Read-Only)
					 * if set due to an expansion on the share.reminder reverse relationship
					 * @return Share
					 */
					return $this->_objShareAsReminder;

				case '_ShareAsReminderArray':
					/**
					 * Gets the value for the private _objShareAsReminderArray (Read-Only)
					 * if set due to an ExpandAsArray on the share.reminder reverse relationship
					 * @return Share[]
					 */
					return $this->_objShareAsReminderArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Note':
					/**
					 * Sets the value for intNote (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objNoteObject = null;
						return ($this->intNote = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'From':
					/**
					 * Sets the value for intFrom (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objFromObject = null;
						return ($this->intFrom = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'To':
					/**
					 * Sets the value for intTo (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objToObject = null;
						return ($this->intTo = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Reminder':
					/**
					 * Sets the value for intReminder 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objReminderObject = null;
						return ($this->intReminder = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Data':
					/**
					 * Sets the value for strData 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strData = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'NoteObject':
					/**
					 * Sets the value for the Notes object referenced by intNote (Not Null)
					 * @param Notes $mixValue
					 * @return Notes
					 */
					if (is_null($mixValue)) {
						$this->intNote = null;
						$this->objNoteObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Notes object
						try {
							$mixValue = QType::Cast($mixValue, 'Notes');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Notes object
						if (is_null($mixValue->Idnotes))
							throw new QCallerException('Unable to set an unsaved NoteObject for this Share');

						// Update Local Member Variables
						$this->objNoteObject = $mixValue;
						$this->intNote = $mixValue->Idnotes;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'FromObject':
					/**
					 * Sets the value for the Ledger object referenced by intFrom (Not Null)
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intFrom = null;
						$this->objFromObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved FromObject for this Share');

						// Update Local Member Variables
						$this->objFromObject = $mixValue;
						$this->intFrom = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ToObject':
					/**
					 * Sets the value for the Ledger object referenced by intTo (Not Null)
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intTo = null;
						$this->objToObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved ToObject for this Share');

						// Update Local Member Variables
						$this->objToObject = $mixValue;
						$this->intTo = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ReminderObject':
					/**
					 * Sets the value for the Share object referenced by intReminder 
					 * @param Share $mixValue
					 * @return Share
					 */
					if (is_null($mixValue)) {
						$this->intReminder = null;
						$this->objReminderObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Share object
						try {
							$mixValue = QType::Cast($mixValue, 'Share');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Share object
						if (is_null($mixValue->Idshare))
							throw new QCallerException('Unable to set an unsaved ReminderObject for this Share');

						// Update Local Member Variables
						$this->objReminderObject = $mixValue;
						$this->intReminder = $mixValue->Idshare;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for ShareAsReminder
		//-------------------------------------------------------------------

		/**
		 * Gets all associated SharesAsReminder as an array of Share objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Share[]
		*/
		public function GetShareAsReminderArray($objOptionalClauses = null) {
			if ((is_null($this->intIdshare)))
				return array();

			try {
				return Share::LoadArrayByReminder($this->intIdshare, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated SharesAsReminder
		 * @return int
		*/
		public function CountSharesAsReminder() {
			if ((is_null($this->intIdshare)))
				return 0;

			return Share::CountByReminder($this->intIdshare);
		}

		/**
		 * Associates a ShareAsReminder
		 * @param Share $objShare
		 * @return void
		*/
		public function AssociateShareAsReminder(Share $objShare) {
			if ((is_null($this->intIdshare)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateShareAsReminder on this unsaved Share.');
			if ((is_null($objShare->Idshare)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateShareAsReminder on this Share with an unsaved Share.');

			// Get the Database Object for this Class
			$objDatabase = Share::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`share`
				SET
					`reminder` = ' . $objDatabase->SqlVariable($this->intIdshare) . '
				WHERE
					`idshare` = ' . $objDatabase->SqlVariable($objShare->Idshare) . '
			');
		}

		/**
		 * Unassociates a ShareAsReminder
		 * @param Share $objShare
		 * @return void
		*/
		public function UnassociateShareAsReminder(Share $objShare) {
			if ((is_null($this->intIdshare)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateShareAsReminder on this unsaved Share.');
			if ((is_null($objShare->Idshare)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateShareAsReminder on this Share with an unsaved Share.');

			// Get the Database Object for this Class
			$objDatabase = Share::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`share`
				SET
					`reminder` = null
				WHERE
					`idshare` = ' . $objDatabase->SqlVariable($objShare->Idshare) . ' AND
					`reminder` = ' . $objDatabase->SqlVariable($this->intIdshare) . '
			');
		}

		/**
		 * Unassociates all SharesAsReminder
		 * @return void
		*/
		public function UnassociateAllSharesAsReminder() {
			if ((is_null($this->intIdshare)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateShareAsReminder on this unsaved Share.');

			// Get the Database Object for this Class
			$objDatabase = Share::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`share`
				SET
					`reminder` = null
				WHERE
					`reminder` = ' . $objDatabase->SqlVariable($this->intIdshare) . '
			');
		}

		/**
		 * Deletes an associated ShareAsReminder
		 * @param Share $objShare
		 * @return void
		*/
		public function DeleteAssociatedShareAsReminder(Share $objShare) {
			if ((is_null($this->intIdshare)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateShareAsReminder on this unsaved Share.');
			if ((is_null($objShare->Idshare)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateShareAsReminder on this Share with an unsaved Share.');

			// Get the Database Object for this Class
			$objDatabase = Share::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`share`
				WHERE
					`idshare` = ' . $objDatabase->SqlVariable($objShare->Idshare) . ' AND
					`reminder` = ' . $objDatabase->SqlVariable($this->intIdshare) . '
			');
		}

		/**
		 * Deletes all associated SharesAsReminder
		 * @return void
		*/
		public function DeleteAllSharesAsReminder() {
			if ((is_null($this->intIdshare)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateShareAsReminder on this unsaved Share.');

			// Get the Database Object for this Class
			$objDatabase = Share::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`share`
				WHERE
					`reminder` = ' . $objDatabase->SqlVariable($this->intIdshare) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "share";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Share::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Share"><sequence>';
			$strToReturn .= '<element name="Idshare" type="xsd:int"/>';
			$strToReturn .= '<element name="Date" type="xsd:string"/>';
			$strToReturn .= '<element name="NoteObject" type="xsd1:Notes"/>';
			$strToReturn .= '<element name="FromObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="ToObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="ReminderObject" type="xsd1:Share"/>';
			$strToReturn .= '<element name="Data" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Share', $strComplexTypeArray)) {
				$strComplexTypeArray['Share'] = Share::GetSoapComplexTypeXml();
				Notes::AlterSoapComplexTypeArray($strComplexTypeArray);
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
				Share::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Share::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Share();
			if (property_exists($objSoapObject, 'Idshare'))
				$objToReturn->intIdshare = $objSoapObject->Idshare;
			if (property_exists($objSoapObject, 'Date'))
				$objToReturn->strDate = $objSoapObject->Date;
			if ((property_exists($objSoapObject, 'NoteObject')) &&
				($objSoapObject->NoteObject))
				$objToReturn->NoteObject = Notes::GetObjectFromSoapObject($objSoapObject->NoteObject);
			if ((property_exists($objSoapObject, 'FromObject')) &&
				($objSoapObject->FromObject))
				$objToReturn->FromObject = Ledger::GetObjectFromSoapObject($objSoapObject->FromObject);
			if ((property_exists($objSoapObject, 'ToObject')) &&
				($objSoapObject->ToObject))
				$objToReturn->ToObject = Ledger::GetObjectFromSoapObject($objSoapObject->ToObject);
			if ((property_exists($objSoapObject, 'ReminderObject')) &&
				($objSoapObject->ReminderObject))
				$objToReturn->ReminderObject = Share::GetObjectFromSoapObject($objSoapObject->ReminderObject);
			if (property_exists($objSoapObject, 'Data'))
				$objToReturn->strData = $objSoapObject->Data;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Share::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objNoteObject)
				$objObject->objNoteObject = Notes::GetSoapObjectFromObject($objObject->objNoteObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intNote = null;
			if ($objObject->objFromObject)
				$objObject->objFromObject = Ledger::GetSoapObjectFromObject($objObject->objFromObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intFrom = null;
			if ($objObject->objToObject)
				$objObject->objToObject = Ledger::GetSoapObjectFromObject($objObject->objToObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intTo = null;
			if ($objObject->objReminderObject)
				$objObject->objReminderObject = Share::GetSoapObjectFromObject($objObject->objReminderObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intReminder = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idshare'] = $this->intIdshare;
			$iArray['Date'] = $this->strDate;
			$iArray['Note'] = $this->intNote;
			$iArray['From'] = $this->intFrom;
			$iArray['To'] = $this->intTo;
			$iArray['Reminder'] = $this->intReminder;
			$iArray['Data'] = $this->strData;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdshare ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idshare
     * @property-read QQNode $Date
     * @property-read QQNode $Note
     * @property-read QQNodeNotes $NoteObject
     * @property-read QQNode $From
     * @property-read QQNodeLedger $FromObject
     * @property-read QQNode $To
     * @property-read QQNodeLedger $ToObject
     * @property-read QQNode $Reminder
     * @property-read QQNodeShare $ReminderObject
     * @property-read QQNode $Data
     *
     *
     * @property-read QQReverseReferenceNodeShare $ShareAsReminder

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeShare extends QQNode {
		protected $strTableName = 'share';
		protected $strPrimaryKey = 'idshare';
		protected $strClassName = 'Share';
		public function __get($strName) {
			switch ($strName) {
				case 'Idshare':
					return new QQNode('idshare', 'Idshare', 'Integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'VarChar', $this);
				case 'Note':
					return new QQNode('note', 'Note', 'Integer', $this);
				case 'NoteObject':
					return new QQNodeNotes('note', 'NoteObject', 'Integer', $this);
				case 'From':
					return new QQNode('from', 'From', 'Integer', $this);
				case 'FromObject':
					return new QQNodeLedger('from', 'FromObject', 'Integer', $this);
				case 'To':
					return new QQNode('to', 'To', 'Integer', $this);
				case 'ToObject':
					return new QQNodeLedger('to', 'ToObject', 'Integer', $this);
				case 'Reminder':
					return new QQNode('reminder', 'Reminder', 'Integer', $this);
				case 'ReminderObject':
					return new QQNodeShare('reminder', 'ReminderObject', 'Integer', $this);
				case 'Data':
					return new QQNode('data', 'Data', 'VarChar', $this);
				case 'ShareAsReminder':
					return new QQReverseReferenceNodeShare($this, 'shareasreminder', 'reverse_reference', 'reminder');

				case '_PrimaryKeyNode':
					return new QQNode('idshare', 'Idshare', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idshare
     * @property-read QQNode $Date
     * @property-read QQNode $Note
     * @property-read QQNodeNotes $NoteObject
     * @property-read QQNode $From
     * @property-read QQNodeLedger $FromObject
     * @property-read QQNode $To
     * @property-read QQNodeLedger $ToObject
     * @property-read QQNode $Reminder
     * @property-read QQNodeShare $ReminderObject
     * @property-read QQNode $Data
     *
     *
     * @property-read QQReverseReferenceNodeShare $ShareAsReminder

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeShare extends QQReverseReferenceNode {
		protected $strTableName = 'share';
		protected $strPrimaryKey = 'idshare';
		protected $strClassName = 'Share';
		public function __get($strName) {
			switch ($strName) {
				case 'Idshare':
					return new QQNode('idshare', 'Idshare', 'integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'string', $this);
				case 'Note':
					return new QQNode('note', 'Note', 'integer', $this);
				case 'NoteObject':
					return new QQNodeNotes('note', 'NoteObject', 'integer', $this);
				case 'From':
					return new QQNode('from', 'From', 'integer', $this);
				case 'FromObject':
					return new QQNodeLedger('from', 'FromObject', 'integer', $this);
				case 'To':
					return new QQNode('to', 'To', 'integer', $this);
				case 'ToObject':
					return new QQNodeLedger('to', 'ToObject', 'integer', $this);
				case 'Reminder':
					return new QQNode('reminder', 'Reminder', 'integer', $this);
				case 'ReminderObject':
					return new QQNodeShare('reminder', 'ReminderObject', 'integer', $this);
				case 'Data':
					return new QQNode('data', 'Data', 'string', $this);
				case 'ShareAsReminder':
					return new QQReverseReferenceNodeShare($this, 'shareasreminder', 'reverse_reference', 'reminder');

				case '_PrimaryKeyNode':
					return new QQNode('idshare', 'Idshare', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
