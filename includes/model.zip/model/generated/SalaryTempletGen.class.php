<?php
	/**
	 * The abstract SalaryTempletGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the SalaryTemplet subclass which
	 * extends this SalaryTempletGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the SalaryTemplet class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdsalaryTemplet the value for intIdsalaryTemplet (Read-Only PK)
	 * @property string $Code the value for strCode (Unique)
	 * @property QDateTime $Date the value for dttDate 
	 * @property integer $Employee the value for intEmployee 
	 * @property integer $Department the value for intDepartment 
	 * @property integer $Designation the value for intDesignation 
	 * @property boolean $Active the value for blnActive 
	 * @property integer $RefTemplet the value for intRefTemplet 
	 * @property integer $Establishment the value for intEstablishment 
	 * @property Address $EmployeeObject the value for the Address object referenced by intEmployee 
	 * @property Role $DepartmentObject the value for the Role object referenced by intDepartment 
	 * @property Role $DesignationObject the value for the Role object referenced by intDesignation 
	 * @property SalaryTemplet $RefTempletObject the value for the SalaryTemplet object referenced by intRefTemplet 
	 * @property Establishment $EstablishmentObject the value for the Establishment object referenced by intEstablishment 
	 * @property-read Establishment $_Establishment the value for the private _objEstablishment (Read-Only) if set due to an expansion on the establishment.salary_templet reverse relationship
	 * @property-read Establishment[] $_EstablishmentArray the value for the private _objEstablishmentArray (Read-Only) if set due to an ExpandAsArray on the establishment.salary_templet reverse relationship
	 * @property-read SalaryHead $_SalaryHead the value for the private _objSalaryHead (Read-Only) if set due to an expansion on the salary_head.salary_templet reverse relationship
	 * @property-read SalaryHead[] $_SalaryHeadArray the value for the private _objSalaryHeadArray (Read-Only) if set due to an ExpandAsArray on the salary_head.salary_templet reverse relationship
	 * @property-read SalaryTemplet $_SalaryTempletAsRefTemplet the value for the private _objSalaryTempletAsRefTemplet (Read-Only) if set due to an expansion on the salary_templet.ref_templet reverse relationship
	 * @property-read SalaryTemplet[] $_SalaryTempletAsRefTempletArray the value for the private _objSalaryTempletAsRefTempletArray (Read-Only) if set due to an ExpandAsArray on the salary_templet.ref_templet reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class SalaryTempletGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column salary_templet.idsalary_templet
		 * @var integer intIdsalaryTemplet
		 */
		protected $intIdsalaryTemplet;
		const IdsalaryTempletDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_templet.code
		 * @var string strCode
		 */
		protected $strCode;
		const CodeMaxLength = 45;
		const CodeDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_templet.date
		 * @var QDateTime dttDate
		 */
		protected $dttDate;
		const DateDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_templet.employee
		 * @var integer intEmployee
		 */
		protected $intEmployee;
		const EmployeeDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_templet.department
		 * @var integer intDepartment
		 */
		protected $intDepartment;
		const DepartmentDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_templet.designation
		 * @var integer intDesignation
		 */
		protected $intDesignation;
		const DesignationDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_templet.active
		 * @var boolean blnActive
		 */
		protected $blnActive;
		const ActiveDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_templet.ref_templet
		 * @var integer intRefTemplet
		 */
		protected $intRefTemplet;
		const RefTempletDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_templet.establishment
		 * @var integer intEstablishment
		 */
		protected $intEstablishment;
		const EstablishmentDefault = null;


		/**
		 * Private member variable that stores a reference to a single Establishment object
		 * (of type Establishment), if this SalaryTemplet object was restored with
		 * an expansion on the establishment association table.
		 * @var Establishment _objEstablishment;
		 */
		private $_objEstablishment;

		/**
		 * Private member variable that stores a reference to an array of Establishment objects
		 * (of type Establishment[]), if this SalaryTemplet object was restored with
		 * an ExpandAsArray on the establishment association table.
		 * @var Establishment[] _objEstablishmentArray;
		 */
		private $_objEstablishmentArray = null;

		/**
		 * Private member variable that stores a reference to a single SalaryHead object
		 * (of type SalaryHead), if this SalaryTemplet object was restored with
		 * an expansion on the salary_head association table.
		 * @var SalaryHead _objSalaryHead;
		 */
		private $_objSalaryHead;

		/**
		 * Private member variable that stores a reference to an array of SalaryHead objects
		 * (of type SalaryHead[]), if this SalaryTemplet object was restored with
		 * an ExpandAsArray on the salary_head association table.
		 * @var SalaryHead[] _objSalaryHeadArray;
		 */
		private $_objSalaryHeadArray = null;

		/**
		 * Private member variable that stores a reference to a single SalaryTempletAsRefTemplet object
		 * (of type SalaryTemplet), if this SalaryTemplet object was restored with
		 * an expansion on the salary_templet association table.
		 * @var SalaryTemplet _objSalaryTempletAsRefTemplet;
		 */
		private $_objSalaryTempletAsRefTemplet;

		/**
		 * Private member variable that stores a reference to an array of SalaryTempletAsRefTemplet objects
		 * (of type SalaryTemplet[]), if this SalaryTemplet object was restored with
		 * an ExpandAsArray on the salary_templet association table.
		 * @var SalaryTemplet[] _objSalaryTempletAsRefTempletArray;
		 */
		private $_objSalaryTempletAsRefTempletArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salary_templet.employee.
		 *
		 * NOTE: Always use the EmployeeObject property getter to correctly retrieve this Address object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Address objEmployeeObject
		 */
		protected $objEmployeeObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salary_templet.department.
		 *
		 * NOTE: Always use the DepartmentObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objDepartmentObject
		 */
		protected $objDepartmentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salary_templet.designation.
		 *
		 * NOTE: Always use the DesignationObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objDesignationObject
		 */
		protected $objDesignationObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salary_templet.ref_templet.
		 *
		 * NOTE: Always use the RefTempletObject property getter to correctly retrieve this SalaryTemplet object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var SalaryTemplet objRefTempletObject
		 */
		protected $objRefTempletObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salary_templet.establishment.
		 *
		 * NOTE: Always use the EstablishmentObject property getter to correctly retrieve this Establishment object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Establishment objEstablishmentObject
		 */
		protected $objEstablishmentObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdsalaryTemplet = SalaryTemplet::IdsalaryTempletDefault;
			$this->strCode = SalaryTemplet::CodeDefault;
			$this->dttDate = (SalaryTemplet::DateDefault === null)?null:new QDateTime(SalaryTemplet::DateDefault);
			$this->intEmployee = SalaryTemplet::EmployeeDefault;
			$this->intDepartment = SalaryTemplet::DepartmentDefault;
			$this->intDesignation = SalaryTemplet::DesignationDefault;
			$this->blnActive = SalaryTemplet::ActiveDefault;
			$this->intRefTemplet = SalaryTemplet::RefTempletDefault;
			$this->intEstablishment = SalaryTemplet::EstablishmentDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a SalaryTemplet from PK Info
		 * @param integer $intIdsalaryTemplet
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryTemplet
		 */
		public static function Load($intIdsalaryTemplet, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'SalaryTemplet', $intIdsalaryTemplet);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = SalaryTemplet::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::SalaryTemplet()->IdsalaryTemplet, $intIdsalaryTemplet)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all SalaryTemplets
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryTemplet[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call SalaryTemplet::QueryArray to perform the LoadAll query
			try {
				return SalaryTemplet::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all SalaryTemplets
		 * @return int
		 */
		public static function CountAll() {
			// Call SalaryTemplet::QueryCount to perform the CountAll query
			return SalaryTemplet::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Create/Build out the QueryBuilder object with SalaryTemplet-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'salary_templet');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				SalaryTemplet::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('salary_templet');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single SalaryTemplet object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return SalaryTemplet the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = SalaryTemplet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new SalaryTemplet object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = SalaryTemplet::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return SalaryTemplet::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of SalaryTemplet objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return SalaryTemplet[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = SalaryTemplet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return SalaryTemplet::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = SalaryTemplet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of SalaryTemplet objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = SalaryTemplet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			$strQuery = SalaryTemplet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/salarytemplet', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = SalaryTemplet::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this SalaryTemplet
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'salary_templet';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idsalary_templet', $strAliasPrefix . 'idsalary_templet');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idsalary_templet', $strAliasPrefix . 'idsalary_templet');
			    $objBuilder->AddSelectItem($strTableName, 'code', $strAliasPrefix . 'code');
			    $objBuilder->AddSelectItem($strTableName, 'date', $strAliasPrefix . 'date');
			    $objBuilder->AddSelectItem($strTableName, 'employee', $strAliasPrefix . 'employee');
			    $objBuilder->AddSelectItem($strTableName, 'department', $strAliasPrefix . 'department');
			    $objBuilder->AddSelectItem($strTableName, 'designation', $strAliasPrefix . 'designation');
			    $objBuilder->AddSelectItem($strTableName, 'active', $strAliasPrefix . 'active');
			    $objBuilder->AddSelectItem($strTableName, 'ref_templet', $strAliasPrefix . 'ref_templet');
			    $objBuilder->AddSelectItem($strTableName, 'establishment', $strAliasPrefix . 'establishment');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a SalaryTemplet from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this SalaryTemplet::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return SalaryTemplet
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idsalary_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdsalaryTemplet == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'salary_templet__';


						// Expanding reverse references: Establishment
						$strAlias = $strAliasPrefix . 'establishment__idestablishment';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objEstablishmentArray)
								$objPreviousItem->_objEstablishmentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objEstablishmentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objEstablishmentArray;
								$objChildItem = Establishment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'establishment__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objEstablishmentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objEstablishmentArray[] = Establishment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'establishment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: SalaryHead
						$strAlias = $strAliasPrefix . 'salaryhead__idsalary_head';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objSalaryHeadArray)
								$objPreviousItem->_objSalaryHeadArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objSalaryHeadArray)) {
								$objPreviousChildItems = $objPreviousItem->_objSalaryHeadArray;
								$objChildItem = SalaryHead::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salaryhead__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objSalaryHeadArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objSalaryHeadArray[] = SalaryHead::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salaryhead__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: SalaryTempletAsRefTemplet
						$strAlias = $strAliasPrefix . 'salarytempletasreftemplet__idsalary_templet';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objSalaryTempletAsRefTempletArray)
								$objPreviousItem->_objSalaryTempletAsRefTempletArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objSalaryTempletAsRefTempletArray)) {
								$objPreviousChildItems = $objPreviousItem->_objSalaryTempletAsRefTempletArray;
								$objChildItem = SalaryTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarytempletasreftemplet__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objSalaryTempletAsRefTempletArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objSalaryTempletAsRefTempletArray[] = SalaryTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarytempletasreftemplet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'salary_templet__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the SalaryTemplet object
			$objToReturn = new SalaryTemplet();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idsalary_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdsalaryTemplet = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'employee';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intEmployee = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'department';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDepartment = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'designation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDesignation = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'active';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnActive = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'ref_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intRefTemplet = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'establishment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intEstablishment = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdsalaryTemplet != $objPreviousItem->IdsalaryTemplet) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objEstablishmentArray);
					$cnt = count($objToReturn->_objEstablishmentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objEstablishmentArray, $objToReturn->_objEstablishmentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objSalaryHeadArray);
					$cnt = count($objToReturn->_objSalaryHeadArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objSalaryHeadArray, $objToReturn->_objSalaryHeadArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objSalaryTempletAsRefTempletArray);
					$cnt = count($objToReturn->_objSalaryTempletAsRefTempletArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objSalaryTempletAsRefTempletArray, $objToReturn->_objSalaryTempletAsRefTempletArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'salary_templet__';

			// Check for EmployeeObject Early Binding
			$strAlias = $strAliasPrefix . 'employee__idaddress';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objEmployeeObject = Address::InstantiateDbRow($objDbRow, $strAliasPrefix . 'employee__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DepartmentObject Early Binding
			$strAlias = $strAliasPrefix . 'department__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDepartmentObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'department__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DesignationObject Early Binding
			$strAlias = $strAliasPrefix . 'designation__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDesignationObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'designation__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for RefTempletObject Early Binding
			$strAlias = $strAliasPrefix . 'ref_templet__idsalary_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objRefTempletObject = SalaryTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ref_templet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for EstablishmentObject Early Binding
			$strAlias = $strAliasPrefix . 'establishment__idestablishment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objEstablishmentObject = Establishment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'establishment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for Establishment Virtual Binding
			$strAlias = $strAliasPrefix . 'establishment__idestablishment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objEstablishmentArray)
				$objToReturn->_objEstablishmentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objEstablishmentArray[] = Establishment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'establishment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objEstablishment = Establishment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'establishment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for SalaryHead Virtual Binding
			$strAlias = $strAliasPrefix . 'salaryhead__idsalary_head';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objSalaryHeadArray)
				$objToReturn->_objSalaryHeadArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objSalaryHeadArray[] = SalaryHead::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salaryhead__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objSalaryHead = SalaryHead::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salaryhead__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for SalaryTempletAsRefTemplet Virtual Binding
			$strAlias = $strAliasPrefix . 'salarytempletasreftemplet__idsalary_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objSalaryTempletAsRefTempletArray)
				$objToReturn->_objSalaryTempletAsRefTempletArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objSalaryTempletAsRefTempletArray[] = SalaryTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarytempletasreftemplet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objSalaryTempletAsRefTemplet = SalaryTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarytempletasreftemplet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of SalaryTemplets from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return SalaryTemplet[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = SalaryTemplet::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = SalaryTemplet::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single SalaryTemplet object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return SalaryTemplet next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return SalaryTemplet::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single SalaryTemplet object,
		 * by IdsalaryTemplet Index(es)
		 * @param integer $intIdsalaryTemplet
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryTemplet
		*/
		public static function LoadByIdsalaryTemplet($intIdsalaryTemplet, $objOptionalClauses = null) {
			return SalaryTemplet::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::SalaryTemplet()->IdsalaryTemplet, $intIdsalaryTemplet)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single SalaryTemplet object,
		 * by Code Index(es)
		 * @param string $strCode
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryTemplet
		*/
		public static function LoadByCode($strCode, $objOptionalClauses = null) {
			return SalaryTemplet::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::SalaryTemplet()->Code, $strCode)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of SalaryTemplet objects,
		 * by Employee Index(es)
		 * @param integer $intEmployee
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryTemplet[]
		*/
		public static function LoadArrayByEmployee($intEmployee, $objOptionalClauses = null) {
			// Call SalaryTemplet::QueryArray to perform the LoadArrayByEmployee query
			try {
				return SalaryTemplet::QueryArray(
					QQ::Equal(QQN::SalaryTemplet()->Employee, $intEmployee),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count SalaryTemplets
		 * by Employee Index(es)
		 * @param integer $intEmployee
		 * @return int
		*/
		public static function CountByEmployee($intEmployee) {
			// Call SalaryTemplet::QueryCount to perform the CountByEmployee query
			return SalaryTemplet::QueryCount(
				QQ::Equal(QQN::SalaryTemplet()->Employee, $intEmployee)
			);
		}

		/**
		 * Load an array of SalaryTemplet objects,
		 * by Designation Index(es)
		 * @param integer $intDesignation
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryTemplet[]
		*/
		public static function LoadArrayByDesignation($intDesignation, $objOptionalClauses = null) {
			// Call SalaryTemplet::QueryArray to perform the LoadArrayByDesignation query
			try {
				return SalaryTemplet::QueryArray(
					QQ::Equal(QQN::SalaryTemplet()->Designation, $intDesignation),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count SalaryTemplets
		 * by Designation Index(es)
		 * @param integer $intDesignation
		 * @return int
		*/
		public static function CountByDesignation($intDesignation) {
			// Call SalaryTemplet::QueryCount to perform the CountByDesignation query
			return SalaryTemplet::QueryCount(
				QQ::Equal(QQN::SalaryTemplet()->Designation, $intDesignation)
			);
		}

		/**
		 * Load an array of SalaryTemplet objects,
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryTemplet[]
		*/
		public static function LoadArrayByDepartment($intDepartment, $objOptionalClauses = null) {
			// Call SalaryTemplet::QueryArray to perform the LoadArrayByDepartment query
			try {
				return SalaryTemplet::QueryArray(
					QQ::Equal(QQN::SalaryTemplet()->Department, $intDepartment),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count SalaryTemplets
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @return int
		*/
		public static function CountByDepartment($intDepartment) {
			// Call SalaryTemplet::QueryCount to perform the CountByDepartment query
			return SalaryTemplet::QueryCount(
				QQ::Equal(QQN::SalaryTemplet()->Department, $intDepartment)
			);
		}

		/**
		 * Load an array of SalaryTemplet objects,
		 * by RefTemplet Index(es)
		 * @param integer $intRefTemplet
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryTemplet[]
		*/
		public static function LoadArrayByRefTemplet($intRefTemplet, $objOptionalClauses = null) {
			// Call SalaryTemplet::QueryArray to perform the LoadArrayByRefTemplet query
			try {
				return SalaryTemplet::QueryArray(
					QQ::Equal(QQN::SalaryTemplet()->RefTemplet, $intRefTemplet),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count SalaryTemplets
		 * by RefTemplet Index(es)
		 * @param integer $intRefTemplet
		 * @return int
		*/
		public static function CountByRefTemplet($intRefTemplet) {
			// Call SalaryTemplet::QueryCount to perform the CountByRefTemplet query
			return SalaryTemplet::QueryCount(
				QQ::Equal(QQN::SalaryTemplet()->RefTemplet, $intRefTemplet)
			);
		}

		/**
		 * Load an array of SalaryTemplet objects,
		 * by Establishment Index(es)
		 * @param integer $intEstablishment
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryTemplet[]
		*/
		public static function LoadArrayByEstablishment($intEstablishment, $objOptionalClauses = null) {
			// Call SalaryTemplet::QueryArray to perform the LoadArrayByEstablishment query
			try {
				return SalaryTemplet::QueryArray(
					QQ::Equal(QQN::SalaryTemplet()->Establishment, $intEstablishment),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count SalaryTemplets
		 * by Establishment Index(es)
		 * @param integer $intEstablishment
		 * @return int
		*/
		public static function CountByEstablishment($intEstablishment) {
			// Call SalaryTemplet::QueryCount to perform the CountByEstablishment query
			return SalaryTemplet::QueryCount(
				QQ::Equal(QQN::SalaryTemplet()->Establishment, $intEstablishment)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this SalaryTemplet
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `salary_templet` (
							`code`,
							`date`,
							`employee`,
							`department`,
							`designation`,
							`active`,
							`ref_templet`,
							`establishment`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strCode) . ',
							' . $objDatabase->SqlVariable($this->dttDate) . ',
							' . $objDatabase->SqlVariable($this->intEmployee) . ',
							' . $objDatabase->SqlVariable($this->intDepartment) . ',
							' . $objDatabase->SqlVariable($this->intDesignation) . ',
							' . $objDatabase->SqlVariable($this->blnActive) . ',
							' . $objDatabase->SqlVariable($this->intRefTemplet) . ',
							' . $objDatabase->SqlVariable($this->intEstablishment) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdsalaryTemplet = $objDatabase->InsertId('salary_templet', 'idsalary_templet');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`salary_templet`
						SET
							`code` = ' . $objDatabase->SqlVariable($this->strCode) . ',
							`date` = ' . $objDatabase->SqlVariable($this->dttDate) . ',
							`employee` = ' . $objDatabase->SqlVariable($this->intEmployee) . ',
							`department` = ' . $objDatabase->SqlVariable($this->intDepartment) . ',
							`designation` = ' . $objDatabase->SqlVariable($this->intDesignation) . ',
							`active` = ' . $objDatabase->SqlVariable($this->blnActive) . ',
							`ref_templet` = ' . $objDatabase->SqlVariable($this->intRefTemplet) . ',
							`establishment` = ' . $objDatabase->SqlVariable($this->intEstablishment) . '
						WHERE
							`idsalary_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this SalaryTemplet
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this SalaryTemplet with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salary_templet`
				WHERE
					`idsalary_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this SalaryTemplet ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'SalaryTemplet', $this->intIdsalaryTemplet);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all SalaryTemplets
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salary_templet`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate salary_templet table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `salary_templet`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this SalaryTemplet from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved SalaryTemplet object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = SalaryTemplet::Load($this->intIdsalaryTemplet);

			// Update $this's local variables to match
			$this->strCode = $objReloaded->strCode;
			$this->dttDate = $objReloaded->dttDate;
			$this->Employee = $objReloaded->Employee;
			$this->Department = $objReloaded->Department;
			$this->Designation = $objReloaded->Designation;
			$this->blnActive = $objReloaded->blnActive;
			$this->RefTemplet = $objReloaded->RefTemplet;
			$this->Establishment = $objReloaded->Establishment;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdsalaryTemplet':
					/**
					 * Gets the value for intIdsalaryTemplet (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdsalaryTemplet;

				case 'Code':
					/**
					 * Gets the value for strCode (Unique)
					 * @return string
					 */
					return $this->strCode;

				case 'Date':
					/**
					 * Gets the value for dttDate 
					 * @return QDateTime
					 */
					return $this->dttDate;

				case 'Employee':
					/**
					 * Gets the value for intEmployee 
					 * @return integer
					 */
					return $this->intEmployee;

				case 'Department':
					/**
					 * Gets the value for intDepartment 
					 * @return integer
					 */
					return $this->intDepartment;

				case 'Designation':
					/**
					 * Gets the value for intDesignation 
					 * @return integer
					 */
					return $this->intDesignation;

				case 'Active':
					/**
					 * Gets the value for blnActive 
					 * @return boolean
					 */
					return $this->blnActive;

				case 'RefTemplet':
					/**
					 * Gets the value for intRefTemplet 
					 * @return integer
					 */
					return $this->intRefTemplet;

				case 'Establishment':
					/**
					 * Gets the value for intEstablishment 
					 * @return integer
					 */
					return $this->intEstablishment;


				///////////////////
				// Member Objects
				///////////////////
				case 'EmployeeObject':
					/**
					 * Gets the value for the Address object referenced by intEmployee 
					 * @return Address
					 */
					try {
						if ((!$this->objEmployeeObject) && (!is_null($this->intEmployee)))
							$this->objEmployeeObject = Address::Load($this->intEmployee);
						return $this->objEmployeeObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DepartmentObject':
					/**
					 * Gets the value for the Role object referenced by intDepartment 
					 * @return Role
					 */
					try {
						if ((!$this->objDepartmentObject) && (!is_null($this->intDepartment)))
							$this->objDepartmentObject = Role::Load($this->intDepartment);
						return $this->objDepartmentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DesignationObject':
					/**
					 * Gets the value for the Role object referenced by intDesignation 
					 * @return Role
					 */
					try {
						if ((!$this->objDesignationObject) && (!is_null($this->intDesignation)))
							$this->objDesignationObject = Role::Load($this->intDesignation);
						return $this->objDesignationObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RefTempletObject':
					/**
					 * Gets the value for the SalaryTemplet object referenced by intRefTemplet 
					 * @return SalaryTemplet
					 */
					try {
						if ((!$this->objRefTempletObject) && (!is_null($this->intRefTemplet)))
							$this->objRefTempletObject = SalaryTemplet::Load($this->intRefTemplet);
						return $this->objRefTempletObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'EstablishmentObject':
					/**
					 * Gets the value for the Establishment object referenced by intEstablishment 
					 * @return Establishment
					 */
					try {
						if ((!$this->objEstablishmentObject) && (!is_null($this->intEstablishment)))
							$this->objEstablishmentObject = Establishment::Load($this->intEstablishment);
						return $this->objEstablishmentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_Establishment':
					/**
					 * Gets the value for the private _objEstablishment (Read-Only)
					 * if set due to an expansion on the establishment.salary_templet reverse relationship
					 * @return Establishment
					 */
					return $this->_objEstablishment;

				case '_EstablishmentArray':
					/**
					 * Gets the value for the private _objEstablishmentArray (Read-Only)
					 * if set due to an ExpandAsArray on the establishment.salary_templet reverse relationship
					 * @return Establishment[]
					 */
					return $this->_objEstablishmentArray;

				case '_SalaryHead':
					/**
					 * Gets the value for the private _objSalaryHead (Read-Only)
					 * if set due to an expansion on the salary_head.salary_templet reverse relationship
					 * @return SalaryHead
					 */
					return $this->_objSalaryHead;

				case '_SalaryHeadArray':
					/**
					 * Gets the value for the private _objSalaryHeadArray (Read-Only)
					 * if set due to an ExpandAsArray on the salary_head.salary_templet reverse relationship
					 * @return SalaryHead[]
					 */
					return $this->_objSalaryHeadArray;

				case '_SalaryTempletAsRefTemplet':
					/**
					 * Gets the value for the private _objSalaryTempletAsRefTemplet (Read-Only)
					 * if set due to an expansion on the salary_templet.ref_templet reverse relationship
					 * @return SalaryTemplet
					 */
					return $this->_objSalaryTempletAsRefTemplet;

				case '_SalaryTempletAsRefTempletArray':
					/**
					 * Gets the value for the private _objSalaryTempletAsRefTempletArray (Read-Only)
					 * if set due to an ExpandAsArray on the salary_templet.ref_templet reverse relationship
					 * @return SalaryTemplet[]
					 */
					return $this->_objSalaryTempletAsRefTempletArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Code':
					/**
					 * Sets the value for strCode (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Date':
					/**
					 * Sets the value for dttDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Employee':
					/**
					 * Sets the value for intEmployee 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objEmployeeObject = null;
						return ($this->intEmployee = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Department':
					/**
					 * Sets the value for intDepartment 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDepartmentObject = null;
						return ($this->intDepartment = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Designation':
					/**
					 * Sets the value for intDesignation 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDesignationObject = null;
						return ($this->intDesignation = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Active':
					/**
					 * Sets the value for blnActive 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnActive = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RefTemplet':
					/**
					 * Sets the value for intRefTemplet 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objRefTempletObject = null;
						return ($this->intRefTemplet = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Establishment':
					/**
					 * Sets the value for intEstablishment 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objEstablishmentObject = null;
						return ($this->intEstablishment = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'EmployeeObject':
					/**
					 * Sets the value for the Address object referenced by intEmployee 
					 * @param Address $mixValue
					 * @return Address
					 */
					if (is_null($mixValue)) {
						$this->intEmployee = null;
						$this->objEmployeeObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Address object
						try {
							$mixValue = QType::Cast($mixValue, 'Address');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Address object
						if (is_null($mixValue->Idaddress))
							throw new QCallerException('Unable to set an unsaved EmployeeObject for this SalaryTemplet');

						// Update Local Member Variables
						$this->objEmployeeObject = $mixValue;
						$this->intEmployee = $mixValue->Idaddress;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DepartmentObject':
					/**
					 * Sets the value for the Role object referenced by intDepartment 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intDepartment = null;
						$this->objDepartmentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved DepartmentObject for this SalaryTemplet');

						// Update Local Member Variables
						$this->objDepartmentObject = $mixValue;
						$this->intDepartment = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DesignationObject':
					/**
					 * Sets the value for the Role object referenced by intDesignation 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intDesignation = null;
						$this->objDesignationObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved DesignationObject for this SalaryTemplet');

						// Update Local Member Variables
						$this->objDesignationObject = $mixValue;
						$this->intDesignation = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'RefTempletObject':
					/**
					 * Sets the value for the SalaryTemplet object referenced by intRefTemplet 
					 * @param SalaryTemplet $mixValue
					 * @return SalaryTemplet
					 */
					if (is_null($mixValue)) {
						$this->intRefTemplet = null;
						$this->objRefTempletObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a SalaryTemplet object
						try {
							$mixValue = QType::Cast($mixValue, 'SalaryTemplet');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED SalaryTemplet object
						if (is_null($mixValue->IdsalaryTemplet))
							throw new QCallerException('Unable to set an unsaved RefTempletObject for this SalaryTemplet');

						// Update Local Member Variables
						$this->objRefTempletObject = $mixValue;
						$this->intRefTemplet = $mixValue->IdsalaryTemplet;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'EstablishmentObject':
					/**
					 * Sets the value for the Establishment object referenced by intEstablishment 
					 * @param Establishment $mixValue
					 * @return Establishment
					 */
					if (is_null($mixValue)) {
						$this->intEstablishment = null;
						$this->objEstablishmentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Establishment object
						try {
							$mixValue = QType::Cast($mixValue, 'Establishment');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Establishment object
						if (is_null($mixValue->Idestablishment))
							throw new QCallerException('Unable to set an unsaved EstablishmentObject for this SalaryTemplet');

						// Update Local Member Variables
						$this->objEstablishmentObject = $mixValue;
						$this->intEstablishment = $mixValue->Idestablishment;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for Establishment
		//-------------------------------------------------------------------

		/**
		 * Gets all associated Establishments as an array of Establishment objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Establishment[]
		*/
		public function GetEstablishmentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdsalaryTemplet)))
				return array();

			try {
				return Establishment::LoadArrayBySalaryTemplet($this->intIdsalaryTemplet, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated Establishments
		 * @return int
		*/
		public function CountEstablishments() {
			if ((is_null($this->intIdsalaryTemplet)))
				return 0;

			return Establishment::CountBySalaryTemplet($this->intIdsalaryTemplet);
		}

		/**
		 * Associates a Establishment
		 * @param Establishment $objEstablishment
		 * @return void
		*/
		public function AssociateEstablishment(Establishment $objEstablishment) {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEstablishment on this unsaved SalaryTemplet.');
			if ((is_null($objEstablishment->Idestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEstablishment on this SalaryTemplet with an unsaved Establishment.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`establishment`
				SET
					`salary_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
				WHERE
					`idestablishment` = ' . $objDatabase->SqlVariable($objEstablishment->Idestablishment) . '
			');
		}

		/**
		 * Unassociates a Establishment
		 * @param Establishment $objEstablishment
		 * @return void
		*/
		public function UnassociateEstablishment(Establishment $objEstablishment) {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEstablishment on this unsaved SalaryTemplet.');
			if ((is_null($objEstablishment->Idestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEstablishment on this SalaryTemplet with an unsaved Establishment.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`establishment`
				SET
					`salary_templet` = null
				WHERE
					`idestablishment` = ' . $objDatabase->SqlVariable($objEstablishment->Idestablishment) . ' AND
					`salary_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
			');
		}

		/**
		 * Unassociates all Establishments
		 * @return void
		*/
		public function UnassociateAllEstablishments() {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEstablishment on this unsaved SalaryTemplet.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`establishment`
				SET
					`salary_templet` = null
				WHERE
					`salary_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
			');
		}

		/**
		 * Deletes an associated Establishment
		 * @param Establishment $objEstablishment
		 * @return void
		*/
		public function DeleteAssociatedEstablishment(Establishment $objEstablishment) {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEstablishment on this unsaved SalaryTemplet.');
			if ((is_null($objEstablishment->Idestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEstablishment on this SalaryTemplet with an unsaved Establishment.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`establishment`
				WHERE
					`idestablishment` = ' . $objDatabase->SqlVariable($objEstablishment->Idestablishment) . ' AND
					`salary_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
			');
		}

		/**
		 * Deletes all associated Establishments
		 * @return void
		*/
		public function DeleteAllEstablishments() {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEstablishment on this unsaved SalaryTemplet.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`establishment`
				WHERE
					`salary_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
			');
		}


		// Related Objects' Methods for SalaryHead
		//-------------------------------------------------------------------

		/**
		 * Gets all associated SalaryHeads as an array of SalaryHead objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryHead[]
		*/
		public function GetSalaryHeadArray($objOptionalClauses = null) {
			if ((is_null($this->intIdsalaryTemplet)))
				return array();

			try {
				return SalaryHead::LoadArrayBySalaryTemplet($this->intIdsalaryTemplet, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated SalaryHeads
		 * @return int
		*/
		public function CountSalaryHeads() {
			if ((is_null($this->intIdsalaryTemplet)))
				return 0;

			return SalaryHead::CountBySalaryTemplet($this->intIdsalaryTemplet);
		}

		/**
		 * Associates a SalaryHead
		 * @param SalaryHead $objSalaryHead
		 * @return void
		*/
		public function AssociateSalaryHead(SalaryHead $objSalaryHead) {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSalaryHead on this unsaved SalaryTemplet.');
			if ((is_null($objSalaryHead->IdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSalaryHead on this SalaryTemplet with an unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salary_head`
				SET
					`salary_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
				WHERE
					`idsalary_head` = ' . $objDatabase->SqlVariable($objSalaryHead->IdsalaryHead) . '
			');
		}

		/**
		 * Unassociates a SalaryHead
		 * @param SalaryHead $objSalaryHead
		 * @return void
		*/
		public function UnassociateSalaryHead(SalaryHead $objSalaryHead) {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryHead on this unsaved SalaryTemplet.');
			if ((is_null($objSalaryHead->IdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryHead on this SalaryTemplet with an unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salary_head`
				SET
					`salary_templet` = null
				WHERE
					`idsalary_head` = ' . $objDatabase->SqlVariable($objSalaryHead->IdsalaryHead) . ' AND
					`salary_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
			');
		}

		/**
		 * Unassociates all SalaryHeads
		 * @return void
		*/
		public function UnassociateAllSalaryHeads() {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryHead on this unsaved SalaryTemplet.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salary_head`
				SET
					`salary_templet` = null
				WHERE
					`salary_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
			');
		}

		/**
		 * Deletes an associated SalaryHead
		 * @param SalaryHead $objSalaryHead
		 * @return void
		*/
		public function DeleteAssociatedSalaryHead(SalaryHead $objSalaryHead) {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryHead on this unsaved SalaryTemplet.');
			if ((is_null($objSalaryHead->IdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryHead on this SalaryTemplet with an unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salary_head`
				WHERE
					`idsalary_head` = ' . $objDatabase->SqlVariable($objSalaryHead->IdsalaryHead) . ' AND
					`salary_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
			');
		}

		/**
		 * Deletes all associated SalaryHeads
		 * @return void
		*/
		public function DeleteAllSalaryHeads() {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryHead on this unsaved SalaryTemplet.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salary_head`
				WHERE
					`salary_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
			');
		}


		// Related Objects' Methods for SalaryTempletAsRefTemplet
		//-------------------------------------------------------------------

		/**
		 * Gets all associated SalaryTempletsAsRefTemplet as an array of SalaryTemplet objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryTemplet[]
		*/
		public function GetSalaryTempletAsRefTempletArray($objOptionalClauses = null) {
			if ((is_null($this->intIdsalaryTemplet)))
				return array();

			try {
				return SalaryTemplet::LoadArrayByRefTemplet($this->intIdsalaryTemplet, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated SalaryTempletsAsRefTemplet
		 * @return int
		*/
		public function CountSalaryTempletsAsRefTemplet() {
			if ((is_null($this->intIdsalaryTemplet)))
				return 0;

			return SalaryTemplet::CountByRefTemplet($this->intIdsalaryTemplet);
		}

		/**
		 * Associates a SalaryTempletAsRefTemplet
		 * @param SalaryTemplet $objSalaryTemplet
		 * @return void
		*/
		public function AssociateSalaryTempletAsRefTemplet(SalaryTemplet $objSalaryTemplet) {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSalaryTempletAsRefTemplet on this unsaved SalaryTemplet.');
			if ((is_null($objSalaryTemplet->IdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSalaryTempletAsRefTemplet on this SalaryTemplet with an unsaved SalaryTemplet.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salary_templet`
				SET
					`ref_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
				WHERE
					`idsalary_templet` = ' . $objDatabase->SqlVariable($objSalaryTemplet->IdsalaryTemplet) . '
			');
		}

		/**
		 * Unassociates a SalaryTempletAsRefTemplet
		 * @param SalaryTemplet $objSalaryTemplet
		 * @return void
		*/
		public function UnassociateSalaryTempletAsRefTemplet(SalaryTemplet $objSalaryTemplet) {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryTempletAsRefTemplet on this unsaved SalaryTemplet.');
			if ((is_null($objSalaryTemplet->IdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryTempletAsRefTemplet on this SalaryTemplet with an unsaved SalaryTemplet.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salary_templet`
				SET
					`ref_templet` = null
				WHERE
					`idsalary_templet` = ' . $objDatabase->SqlVariable($objSalaryTemplet->IdsalaryTemplet) . ' AND
					`ref_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
			');
		}

		/**
		 * Unassociates all SalaryTempletsAsRefTemplet
		 * @return void
		*/
		public function UnassociateAllSalaryTempletsAsRefTemplet() {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryTempletAsRefTemplet on this unsaved SalaryTemplet.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salary_templet`
				SET
					`ref_templet` = null
				WHERE
					`ref_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
			');
		}

		/**
		 * Deletes an associated SalaryTempletAsRefTemplet
		 * @param SalaryTemplet $objSalaryTemplet
		 * @return void
		*/
		public function DeleteAssociatedSalaryTempletAsRefTemplet(SalaryTemplet $objSalaryTemplet) {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryTempletAsRefTemplet on this unsaved SalaryTemplet.');
			if ((is_null($objSalaryTemplet->IdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryTempletAsRefTemplet on this SalaryTemplet with an unsaved SalaryTemplet.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salary_templet`
				WHERE
					`idsalary_templet` = ' . $objDatabase->SqlVariable($objSalaryTemplet->IdsalaryTemplet) . ' AND
					`ref_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
			');
		}

		/**
		 * Deletes all associated SalaryTempletsAsRefTemplet
		 * @return void
		*/
		public function DeleteAllSalaryTempletsAsRefTemplet() {
			if ((is_null($this->intIdsalaryTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryTempletAsRefTemplet on this unsaved SalaryTemplet.');

			// Get the Database Object for this Class
			$objDatabase = SalaryTemplet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salary_templet`
				WHERE
					`ref_templet` = ' . $objDatabase->SqlVariable($this->intIdsalaryTemplet) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "salary_templet";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[SalaryTemplet::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="SalaryTemplet"><sequence>';
			$strToReturn .= '<element name="IdsalaryTemplet" type="xsd:int"/>';
			$strToReturn .= '<element name="Code" type="xsd:string"/>';
			$strToReturn .= '<element name="Date" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="EmployeeObject" type="xsd1:Address"/>';
			$strToReturn .= '<element name="DepartmentObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="DesignationObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="Active" type="xsd:boolean"/>';
			$strToReturn .= '<element name="RefTempletObject" type="xsd1:SalaryTemplet"/>';
			$strToReturn .= '<element name="EstablishmentObject" type="xsd1:Establishment"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('SalaryTemplet', $strComplexTypeArray)) {
				$strComplexTypeArray['SalaryTemplet'] = SalaryTemplet::GetSoapComplexTypeXml();
				Address::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				SalaryTemplet::AlterSoapComplexTypeArray($strComplexTypeArray);
				Establishment::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, SalaryTemplet::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new SalaryTemplet();
			if (property_exists($objSoapObject, 'IdsalaryTemplet'))
				$objToReturn->intIdsalaryTemplet = $objSoapObject->IdsalaryTemplet;
			if (property_exists($objSoapObject, 'Code'))
				$objToReturn->strCode = $objSoapObject->Code;
			if (property_exists($objSoapObject, 'Date'))
				$objToReturn->dttDate = new QDateTime($objSoapObject->Date);
			if ((property_exists($objSoapObject, 'EmployeeObject')) &&
				($objSoapObject->EmployeeObject))
				$objToReturn->EmployeeObject = Address::GetObjectFromSoapObject($objSoapObject->EmployeeObject);
			if ((property_exists($objSoapObject, 'DepartmentObject')) &&
				($objSoapObject->DepartmentObject))
				$objToReturn->DepartmentObject = Role::GetObjectFromSoapObject($objSoapObject->DepartmentObject);
			if ((property_exists($objSoapObject, 'DesignationObject')) &&
				($objSoapObject->DesignationObject))
				$objToReturn->DesignationObject = Role::GetObjectFromSoapObject($objSoapObject->DesignationObject);
			if (property_exists($objSoapObject, 'Active'))
				$objToReturn->blnActive = $objSoapObject->Active;
			if ((property_exists($objSoapObject, 'RefTempletObject')) &&
				($objSoapObject->RefTempletObject))
				$objToReturn->RefTempletObject = SalaryTemplet::GetObjectFromSoapObject($objSoapObject->RefTempletObject);
			if ((property_exists($objSoapObject, 'EstablishmentObject')) &&
				($objSoapObject->EstablishmentObject))
				$objToReturn->EstablishmentObject = Establishment::GetObjectFromSoapObject($objSoapObject->EstablishmentObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, SalaryTemplet::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->dttDate)
				$objObject->dttDate = $objObject->dttDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objEmployeeObject)
				$objObject->objEmployeeObject = Address::GetSoapObjectFromObject($objObject->objEmployeeObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intEmployee = null;
			if ($objObject->objDepartmentObject)
				$objObject->objDepartmentObject = Role::GetSoapObjectFromObject($objObject->objDepartmentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDepartment = null;
			if ($objObject->objDesignationObject)
				$objObject->objDesignationObject = Role::GetSoapObjectFromObject($objObject->objDesignationObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDesignation = null;
			if ($objObject->objRefTempletObject)
				$objObject->objRefTempletObject = SalaryTemplet::GetSoapObjectFromObject($objObject->objRefTempletObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intRefTemplet = null;
			if ($objObject->objEstablishmentObject)
				$objObject->objEstablishmentObject = Establishment::GetSoapObjectFromObject($objObject->objEstablishmentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intEstablishment = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdsalaryTemplet'] = $this->intIdsalaryTemplet;
			$iArray['Code'] = $this->strCode;
			$iArray['Date'] = $this->dttDate;
			$iArray['Employee'] = $this->intEmployee;
			$iArray['Department'] = $this->intDepartment;
			$iArray['Designation'] = $this->intDesignation;
			$iArray['Active'] = $this->blnActive;
			$iArray['RefTemplet'] = $this->intRefTemplet;
			$iArray['Establishment'] = $this->intEstablishment;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdsalaryTemplet ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdsalaryTemplet
     * @property-read QQNode $Code
     * @property-read QQNode $Date
     * @property-read QQNode $Employee
     * @property-read QQNodeAddress $EmployeeObject
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $Designation
     * @property-read QQNodeRole $DesignationObject
     * @property-read QQNode $Active
     * @property-read QQNode $RefTemplet
     * @property-read QQNodeSalaryTemplet $RefTempletObject
     * @property-read QQNode $Establishment
     * @property-read QQNodeEstablishment $EstablishmentObject
     *
     *
     * @property-read QQReverseReferenceNodeEstablishment $Establishment
     * @property-read QQReverseReferenceNodeSalaryHead $SalaryHead
     * @property-read QQReverseReferenceNodeSalaryTemplet $SalaryTempletAsRefTemplet

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeSalaryTemplet extends QQNode {
		protected $strTableName = 'salary_templet';
		protected $strPrimaryKey = 'idsalary_templet';
		protected $strClassName = 'SalaryTemplet';
		public function __get($strName) {
			switch ($strName) {
				case 'IdsalaryTemplet':
					return new QQNode('idsalary_templet', 'IdsalaryTemplet', 'Integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'VarChar', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'DateTime', $this);
				case 'Employee':
					return new QQNode('employee', 'Employee', 'Integer', $this);
				case 'EmployeeObject':
					return new QQNodeAddress('employee', 'EmployeeObject', 'Integer', $this);
				case 'Department':
					return new QQNode('department', 'Department', 'Integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'Integer', $this);
				case 'Designation':
					return new QQNode('designation', 'Designation', 'Integer', $this);
				case 'DesignationObject':
					return new QQNodeRole('designation', 'DesignationObject', 'Integer', $this);
				case 'Active':
					return new QQNode('active', 'Active', 'Bit', $this);
				case 'RefTemplet':
					return new QQNode('ref_templet', 'RefTemplet', 'Integer', $this);
				case 'RefTempletObject':
					return new QQNodeSalaryTemplet('ref_templet', 'RefTempletObject', 'Integer', $this);
				case 'Establishment':
					return new QQNode('establishment', 'Establishment', 'Integer', $this);
				case 'EstablishmentObject':
					return new QQNodeEstablishment('establishment', 'EstablishmentObject', 'Integer', $this);
				case 'Establishment':
					return new QQReverseReferenceNodeEstablishment($this, 'establishment', 'reverse_reference', 'salary_templet');
				case 'SalaryHead':
					return new QQReverseReferenceNodeSalaryHead($this, 'salaryhead', 'reverse_reference', 'salary_templet');
				case 'SalaryTempletAsRefTemplet':
					return new QQReverseReferenceNodeSalaryTemplet($this, 'salarytempletasreftemplet', 'reverse_reference', 'ref_templet');

				case '_PrimaryKeyNode':
					return new QQNode('idsalary_templet', 'IdsalaryTemplet', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdsalaryTemplet
     * @property-read QQNode $Code
     * @property-read QQNode $Date
     * @property-read QQNode $Employee
     * @property-read QQNodeAddress $EmployeeObject
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $Designation
     * @property-read QQNodeRole $DesignationObject
     * @property-read QQNode $Active
     * @property-read QQNode $RefTemplet
     * @property-read QQNodeSalaryTemplet $RefTempletObject
     * @property-read QQNode $Establishment
     * @property-read QQNodeEstablishment $EstablishmentObject
     *
     *
     * @property-read QQReverseReferenceNodeEstablishment $Establishment
     * @property-read QQReverseReferenceNodeSalaryHead $SalaryHead
     * @property-read QQReverseReferenceNodeSalaryTemplet $SalaryTempletAsRefTemplet

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeSalaryTemplet extends QQReverseReferenceNode {
		protected $strTableName = 'salary_templet';
		protected $strPrimaryKey = 'idsalary_templet';
		protected $strClassName = 'SalaryTemplet';
		public function __get($strName) {
			switch ($strName) {
				case 'IdsalaryTemplet':
					return new QQNode('idsalary_templet', 'IdsalaryTemplet', 'integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'string', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'QDateTime', $this);
				case 'Employee':
					return new QQNode('employee', 'Employee', 'integer', $this);
				case 'EmployeeObject':
					return new QQNodeAddress('employee', 'EmployeeObject', 'integer', $this);
				case 'Department':
					return new QQNode('department', 'Department', 'integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'integer', $this);
				case 'Designation':
					return new QQNode('designation', 'Designation', 'integer', $this);
				case 'DesignationObject':
					return new QQNodeRole('designation', 'DesignationObject', 'integer', $this);
				case 'Active':
					return new QQNode('active', 'Active', 'boolean', $this);
				case 'RefTemplet':
					return new QQNode('ref_templet', 'RefTemplet', 'integer', $this);
				case 'RefTempletObject':
					return new QQNodeSalaryTemplet('ref_templet', 'RefTempletObject', 'integer', $this);
				case 'Establishment':
					return new QQNode('establishment', 'Establishment', 'integer', $this);
				case 'EstablishmentObject':
					return new QQNodeEstablishment('establishment', 'EstablishmentObject', 'integer', $this);
				case 'Establishment':
					return new QQReverseReferenceNodeEstablishment($this, 'establishment', 'reverse_reference', 'salary_templet');
				case 'SalaryHead':
					return new QQReverseReferenceNodeSalaryHead($this, 'salaryhead', 'reverse_reference', 'salary_templet');
				case 'SalaryTempletAsRefTemplet':
					return new QQReverseReferenceNodeSalaryTemplet($this, 'salarytempletasreftemplet', 'reverse_reference', 'ref_templet');

				case '_PrimaryKeyNode':
					return new QQNode('idsalary_templet', 'IdsalaryTemplet', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
