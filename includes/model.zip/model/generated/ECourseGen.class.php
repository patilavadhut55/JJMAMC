<?php
	/**
	 * The abstract ECourseGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the ECourse subclass which
	 * extends this ECourseGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the ECourse class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdeCourse the value for intIdeCourse (Read-Only PK)
	 * @property string $Title the value for strTitle (Not Null)
	 * @property string $Description the value for strDescription 
	 * @property integer $Category the value for intCategory (Not Null)
	 * @property string $Photo the value for strPhoto 
	 * @property string $Tags the value for strTags 
	 * @property QDateTime $StartDate the value for dttStartDate 
	 * @property QDateTime $EndDate the value for dttEndDate 
	 * @property boolean $Enabled the value for blnEnabled 
	 * @property integer $TotalSession the value for intTotalSession 
	 * @property integer $TeacherId the value for intTeacherId 
	 * @property string $Class the value for strClass 
	 * @property string $Sem the value for strSem 
	 * @property integer $EnrollCount the value for intEnrollCount 
	 * @property string $EnrollPrns the value for strEnrollPrns 
	 * @property EcourseCategory $CategoryObject the value for the EcourseCategory object referenced by intCategory (Not Null)
	 * @property Login $Teacher the value for the Login object referenced by intTeacherId 
	 * @property-read ESession $_ESessionAsId the value for the private _objESessionAsId (Read-Only) if set due to an expansion on the e_session.ide_course reverse relationship
	 * @property-read ESession[] $_ESessionAsIdArray the value for the private _objESessionAsIdArray (Read-Only) if set due to an ExpandAsArray on the e_session.ide_course reverse relationship
	 * @property-read EStudent $_EStudentAsId the value for the private _objEStudentAsId (Read-Only) if set due to an expansion on the e_student.ide_course reverse relationship
	 * @property-read EStudent[] $_EStudentAsIdArray the value for the private _objEStudentAsIdArray (Read-Only) if set due to an ExpandAsArray on the e_student.ide_course reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class ECourseGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column e_course.ide_course
		 * @var integer intIdeCourse
		 */
		protected $intIdeCourse;
		const IdeCourseDefault = null;


		/**
		 * Protected member variable that maps to the database column e_course.title
		 * @var string strTitle
		 */
		protected $strTitle;
		const TitleMaxLength = 255;
		const TitleDefault = null;


		/**
		 * Protected member variable that maps to the database column e_course.description
		 * @var string strDescription
		 */
		protected $strDescription;
		const DescriptionDefault = null;


		/**
		 * Protected member variable that maps to the database column e_course.category
		 * @var integer intCategory
		 */
		protected $intCategory;
		const CategoryDefault = null;


		/**
		 * Protected member variable that maps to the database column e_course.photo
		 * @var string strPhoto
		 */
		protected $strPhoto;
		const PhotoDefault = null;


		/**
		 * Protected member variable that maps to the database column e_course.tags
		 * @var string strTags
		 */
		protected $strTags;
		const TagsDefault = null;


		/**
		 * Protected member variable that maps to the database column e_course.start_date
		 * @var QDateTime dttStartDate
		 */
		protected $dttStartDate;
		const StartDateDefault = null;


		/**
		 * Protected member variable that maps to the database column e_course.end_date
		 * @var QDateTime dttEndDate
		 */
		protected $dttEndDate;
		const EndDateDefault = null;


		/**
		 * Protected member variable that maps to the database column e_course.enabled
		 * @var boolean blnEnabled
		 */
		protected $blnEnabled;
		const EnabledDefault = null;


		/**
		 * Protected member variable that maps to the database column e_course.total_session
		 * @var integer intTotalSession
		 */
		protected $intTotalSession;
		const TotalSessionDefault = null;


		/**
		 * Protected member variable that maps to the database column e_course.teacher_id
		 * @var integer intTeacherId
		 */
		protected $intTeacherId;
		const TeacherIdDefault = null;


		/**
		 * Protected member variable that maps to the database column e_course.class
		 * @var string strClass
		 */
		protected $strClass;
		const ClassDefault = null;


		/**
		 * Protected member variable that maps to the database column e_course.sem
		 * @var string strSem
		 */
		protected $strSem;
		const SemDefault = null;


		/**
		 * Protected member variable that maps to the database column e_course.enroll_count
		 * @var integer intEnrollCount
		 */
		protected $intEnrollCount;
		const EnrollCountDefault = null;


		/**
		 * Protected member variable that maps to the database column e_course.enroll_prns
		 * @var string strEnrollPrns
		 */
		protected $strEnrollPrns;
		const EnrollPrnsDefault = null;


		/**
		 * Private member variable that stores a reference to a single ESessionAsId object
		 * (of type ESession), if this ECourse object was restored with
		 * an expansion on the e_session association table.
		 * @var ESession _objESessionAsId;
		 */
		private $_objESessionAsId;

		/**
		 * Private member variable that stores a reference to an array of ESessionAsId objects
		 * (of type ESession[]), if this ECourse object was restored with
		 * an ExpandAsArray on the e_session association table.
		 * @var ESession[] _objESessionAsIdArray;
		 */
		private $_objESessionAsIdArray = null;

		/**
		 * Private member variable that stores a reference to a single EStudentAsId object
		 * (of type EStudent), if this ECourse object was restored with
		 * an expansion on the e_student association table.
		 * @var EStudent _objEStudentAsId;
		 */
		private $_objEStudentAsId;

		/**
		 * Private member variable that stores a reference to an array of EStudentAsId objects
		 * (of type EStudent[]), if this ECourse object was restored with
		 * an ExpandAsArray on the e_student association table.
		 * @var EStudent[] _objEStudentAsIdArray;
		 */
		private $_objEStudentAsIdArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column e_course.category.
		 *
		 * NOTE: Always use the CategoryObject property getter to correctly retrieve this EcourseCategory object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var EcourseCategory objCategoryObject
		 */
		protected $objCategoryObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column e_course.teacher_id.
		 *
		 * NOTE: Always use the Teacher property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objTeacher
		 */
		protected $objTeacher;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdeCourse = ECourse::IdeCourseDefault;
			$this->strTitle = ECourse::TitleDefault;
			$this->strDescription = ECourse::DescriptionDefault;
			$this->intCategory = ECourse::CategoryDefault;
			$this->strPhoto = ECourse::PhotoDefault;
			$this->strTags = ECourse::TagsDefault;
			$this->dttStartDate = (ECourse::StartDateDefault === null)?null:new QDateTime(ECourse::StartDateDefault);
			$this->dttEndDate = (ECourse::EndDateDefault === null)?null:new QDateTime(ECourse::EndDateDefault);
			$this->blnEnabled = ECourse::EnabledDefault;
			$this->intTotalSession = ECourse::TotalSessionDefault;
			$this->intTeacherId = ECourse::TeacherIdDefault;
			$this->strClass = ECourse::ClassDefault;
			$this->strSem = ECourse::SemDefault;
			$this->intEnrollCount = ECourse::EnrollCountDefault;
			$this->strEnrollPrns = ECourse::EnrollPrnsDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a ECourse from PK Info
		 * @param integer $intIdeCourse
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ECourse
		 */
		public static function Load($intIdeCourse, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'ECourse', $intIdeCourse);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = ECourse::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::ECourse()->IdeCourse, $intIdeCourse)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all ECourses
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ECourse[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call ECourse::QueryArray to perform the LoadAll query
			try {
				return ECourse::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all ECourses
		 * @return int
		 */
		public static function CountAll() {
			// Call ECourse::QueryCount to perform the CountAll query
			return ECourse::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();

			// Create/Build out the QueryBuilder object with ECourse-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'e_course');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				ECourse::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('e_course');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single ECourse object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return ECourse the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = ECourse::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new ECourse object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = ECourse::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return ECourse::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of ECourse objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return ECourse[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = ECourse::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return ECourse::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = ECourse::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of ECourse objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = ECourse::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();

			$strQuery = ECourse::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/ecourse', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = ECourse::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this ECourse
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'e_course';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'ide_course', $strAliasPrefix . 'ide_course');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'ide_course', $strAliasPrefix . 'ide_course');
			    $objBuilder->AddSelectItem($strTableName, 'title', $strAliasPrefix . 'title');
			    $objBuilder->AddSelectItem($strTableName, 'description', $strAliasPrefix . 'description');
			    $objBuilder->AddSelectItem($strTableName, 'category', $strAliasPrefix . 'category');
			    $objBuilder->AddSelectItem($strTableName, 'photo', $strAliasPrefix . 'photo');
			    $objBuilder->AddSelectItem($strTableName, 'tags', $strAliasPrefix . 'tags');
			    $objBuilder->AddSelectItem($strTableName, 'start_date', $strAliasPrefix . 'start_date');
			    $objBuilder->AddSelectItem($strTableName, 'end_date', $strAliasPrefix . 'end_date');
			    $objBuilder->AddSelectItem($strTableName, 'enabled', $strAliasPrefix . 'enabled');
			    $objBuilder->AddSelectItem($strTableName, 'total_session', $strAliasPrefix . 'total_session');
			    $objBuilder->AddSelectItem($strTableName, 'teacher_id', $strAliasPrefix . 'teacher_id');
			    $objBuilder->AddSelectItem($strTableName, 'class', $strAliasPrefix . 'class');
			    $objBuilder->AddSelectItem($strTableName, 'sem', $strAliasPrefix . 'sem');
			    $objBuilder->AddSelectItem($strTableName, 'enroll_count', $strAliasPrefix . 'enroll_count');
			    $objBuilder->AddSelectItem($strTableName, 'enroll_prns', $strAliasPrefix . 'enroll_prns');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a ECourse from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this ECourse::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return ECourse
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'ide_course';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdeCourse == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'e_course__';


						// Expanding reverse references: ESessionAsId
						$strAlias = $strAliasPrefix . 'esessionasid__ide_session';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objESessionAsIdArray)
								$objPreviousItem->_objESessionAsIdArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objESessionAsIdArray)) {
								$objPreviousChildItems = $objPreviousItem->_objESessionAsIdArray;
								$objChildItem = ESession::InstantiateDbRow($objDbRow, $strAliasPrefix . 'esessionasid__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objESessionAsIdArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objESessionAsIdArray[] = ESession::InstantiateDbRow($objDbRow, $strAliasPrefix . 'esessionasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: EStudentAsId
						$strAlias = $strAliasPrefix . 'estudentasid__ide_student';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objEStudentAsIdArray)
								$objPreviousItem->_objEStudentAsIdArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objEStudentAsIdArray)) {
								$objPreviousChildItems = $objPreviousItem->_objEStudentAsIdArray;
								$objChildItem = EStudent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'estudentasid__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objEStudentAsIdArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objEStudentAsIdArray[] = EStudent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'estudentasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'e_course__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the ECourse object
			$objToReturn = new ECourse();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'ide_course';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdeCourse = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'title';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTitle = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'description';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strDescription = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'category';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCategory = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'photo';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strPhoto = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'tags';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTags = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'start_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttStartDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'end_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttEndDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'enabled';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnEnabled = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'total_session';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intTotalSession = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'teacher_id';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intTeacherId = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'class';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strClass = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'sem';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strSem = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'enroll_count';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intEnrollCount = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'enroll_prns';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strEnrollPrns = $objDbRow->GetColumn($strAliasName, 'Blob');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdeCourse != $objPreviousItem->IdeCourse) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objESessionAsIdArray);
					$cnt = count($objToReturn->_objESessionAsIdArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objESessionAsIdArray, $objToReturn->_objESessionAsIdArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objEStudentAsIdArray);
					$cnt = count($objToReturn->_objEStudentAsIdArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objEStudentAsIdArray, $objToReturn->_objEStudentAsIdArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'e_course__';

			// Check for CategoryObject Early Binding
			$strAlias = $strAliasPrefix . 'category__idecourse_category';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCategoryObject = EcourseCategory::InstantiateDbRow($objDbRow, $strAliasPrefix . 'category__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for Teacher Early Binding
			$strAlias = $strAliasPrefix . 'teacher_id__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objTeacher = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'teacher_id__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for ESessionAsId Virtual Binding
			$strAlias = $strAliasPrefix . 'esessionasid__ide_session';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objESessionAsIdArray)
				$objToReturn->_objESessionAsIdArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objESessionAsIdArray[] = ESession::InstantiateDbRow($objDbRow, $strAliasPrefix . 'esessionasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objESessionAsId = ESession::InstantiateDbRow($objDbRow, $strAliasPrefix . 'esessionasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for EStudentAsId Virtual Binding
			$strAlias = $strAliasPrefix . 'estudentasid__ide_student';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objEStudentAsIdArray)
				$objToReturn->_objEStudentAsIdArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objEStudentAsIdArray[] = EStudent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'estudentasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objEStudentAsId = EStudent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'estudentasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of ECourses from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return ECourse[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = ECourse::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = ECourse::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single ECourse object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return ECourse next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return ECourse::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single ECourse object,
		 * by IdeCourse Index(es)
		 * @param integer $intIdeCourse
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ECourse
		*/
		public static function LoadByIdeCourse($intIdeCourse, $objOptionalClauses = null) {
			return ECourse::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::ECourse()->IdeCourse, $intIdeCourse)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of ECourse objects,
		 * by Category Index(es)
		 * @param integer $intCategory
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ECourse[]
		*/
		public static function LoadArrayByCategory($intCategory, $objOptionalClauses = null) {
			// Call ECourse::QueryArray to perform the LoadArrayByCategory query
			try {
				return ECourse::QueryArray(
					QQ::Equal(QQN::ECourse()->Category, $intCategory),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ECourses
		 * by Category Index(es)
		 * @param integer $intCategory
		 * @return int
		*/
		public static function CountByCategory($intCategory) {
			// Call ECourse::QueryCount to perform the CountByCategory query
			return ECourse::QueryCount(
				QQ::Equal(QQN::ECourse()->Category, $intCategory)
			);
		}

		/**
		 * Load an array of ECourse objects,
		 * by TeacherId Index(es)
		 * @param integer $intTeacherId
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ECourse[]
		*/
		public static function LoadArrayByTeacherId($intTeacherId, $objOptionalClauses = null) {
			// Call ECourse::QueryArray to perform the LoadArrayByTeacherId query
			try {
				return ECourse::QueryArray(
					QQ::Equal(QQN::ECourse()->TeacherId, $intTeacherId),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ECourses
		 * by TeacherId Index(es)
		 * @param integer $intTeacherId
		 * @return int
		*/
		public static function CountByTeacherId($intTeacherId) {
			// Call ECourse::QueryCount to perform the CountByTeacherId query
			return ECourse::QueryCount(
				QQ::Equal(QQN::ECourse()->TeacherId, $intTeacherId)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this ECourse
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `e_course` (
							`title`,
							`description`,
							`category`,
							`photo`,
							`tags`,
							`start_date`,
							`end_date`,
							`enabled`,
							`total_session`,
							`teacher_id`,
							`class`,
							`sem`,
							`enroll_count`,
							`enroll_prns`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strTitle) . ',
							' . $objDatabase->SqlVariable($this->strDescription) . ',
							' . $objDatabase->SqlVariable($this->intCategory) . ',
							' . $objDatabase->SqlVariable($this->strPhoto) . ',
							' . $objDatabase->SqlVariable($this->strTags) . ',
							' . $objDatabase->SqlVariable($this->dttStartDate) . ',
							' . $objDatabase->SqlVariable($this->dttEndDate) . ',
							' . $objDatabase->SqlVariable($this->blnEnabled) . ',
							' . $objDatabase->SqlVariable($this->intTotalSession) . ',
							' . $objDatabase->SqlVariable($this->intTeacherId) . ',
							' . $objDatabase->SqlVariable($this->strClass) . ',
							' . $objDatabase->SqlVariable($this->strSem) . ',
							' . $objDatabase->SqlVariable($this->intEnrollCount) . ',
							' . $objDatabase->SqlVariable($this->strEnrollPrns) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdeCourse = $objDatabase->InsertId('e_course', 'ide_course');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`e_course`
						SET
							`title` = ' . $objDatabase->SqlVariable($this->strTitle) . ',
							`description` = ' . $objDatabase->SqlVariable($this->strDescription) . ',
							`category` = ' . $objDatabase->SqlVariable($this->intCategory) . ',
							`photo` = ' . $objDatabase->SqlVariable($this->strPhoto) . ',
							`tags` = ' . $objDatabase->SqlVariable($this->strTags) . ',
							`start_date` = ' . $objDatabase->SqlVariable($this->dttStartDate) . ',
							`end_date` = ' . $objDatabase->SqlVariable($this->dttEndDate) . ',
							`enabled` = ' . $objDatabase->SqlVariable($this->blnEnabled) . ',
							`total_session` = ' . $objDatabase->SqlVariable($this->intTotalSession) . ',
							`teacher_id` = ' . $objDatabase->SqlVariable($this->intTeacherId) . ',
							`class` = ' . $objDatabase->SqlVariable($this->strClass) . ',
							`sem` = ' . $objDatabase->SqlVariable($this->strSem) . ',
							`enroll_count` = ' . $objDatabase->SqlVariable($this->intEnrollCount) . ',
							`enroll_prns` = ' . $objDatabase->SqlVariable($this->strEnrollPrns) . '
						WHERE
							`ide_course` = ' . $objDatabase->SqlVariable($this->intIdeCourse) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this ECourse
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdeCourse)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this ECourse with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`e_course`
				WHERE
					`ide_course` = ' . $objDatabase->SqlVariable($this->intIdeCourse) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this ECourse ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'ECourse', $this->intIdeCourse);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all ECourses
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`e_course`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate e_course table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `e_course`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this ECourse from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved ECourse object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = ECourse::Load($this->intIdeCourse);

			// Update $this's local variables to match
			$this->strTitle = $objReloaded->strTitle;
			$this->strDescription = $objReloaded->strDescription;
			$this->Category = $objReloaded->Category;
			$this->strPhoto = $objReloaded->strPhoto;
			$this->strTags = $objReloaded->strTags;
			$this->dttStartDate = $objReloaded->dttStartDate;
			$this->dttEndDate = $objReloaded->dttEndDate;
			$this->blnEnabled = $objReloaded->blnEnabled;
			$this->intTotalSession = $objReloaded->intTotalSession;
			$this->TeacherId = $objReloaded->TeacherId;
			$this->strClass = $objReloaded->strClass;
			$this->strSem = $objReloaded->strSem;
			$this->intEnrollCount = $objReloaded->intEnrollCount;
			$this->strEnrollPrns = $objReloaded->strEnrollPrns;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdeCourse':
					/**
					 * Gets the value for intIdeCourse (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdeCourse;

				case 'Title':
					/**
					 * Gets the value for strTitle (Not Null)
					 * @return string
					 */
					return $this->strTitle;

				case 'Description':
					/**
					 * Gets the value for strDescription 
					 * @return string
					 */
					return $this->strDescription;

				case 'Category':
					/**
					 * Gets the value for intCategory (Not Null)
					 * @return integer
					 */
					return $this->intCategory;

				case 'Photo':
					/**
					 * Gets the value for strPhoto 
					 * @return string
					 */
					return $this->strPhoto;

				case 'Tags':
					/**
					 * Gets the value for strTags 
					 * @return string
					 */
					return $this->strTags;

				case 'StartDate':
					/**
					 * Gets the value for dttStartDate 
					 * @return QDateTime
					 */
					return $this->dttStartDate;

				case 'EndDate':
					/**
					 * Gets the value for dttEndDate 
					 * @return QDateTime
					 */
					return $this->dttEndDate;

				case 'Enabled':
					/**
					 * Gets the value for blnEnabled 
					 * @return boolean
					 */
					return $this->blnEnabled;

				case 'TotalSession':
					/**
					 * Gets the value for intTotalSession 
					 * @return integer
					 */
					return $this->intTotalSession;

				case 'TeacherId':
					/**
					 * Gets the value for intTeacherId 
					 * @return integer
					 */
					return $this->intTeacherId;

				case 'Class':
					/**
					 * Gets the value for strClass 
					 * @return string
					 */
					return $this->strClass;

				case 'Sem':
					/**
					 * Gets the value for strSem 
					 * @return string
					 */
					return $this->strSem;

				case 'EnrollCount':
					/**
					 * Gets the value for intEnrollCount 
					 * @return integer
					 */
					return $this->intEnrollCount;

				case 'EnrollPrns':
					/**
					 * Gets the value for strEnrollPrns 
					 * @return string
					 */
					return $this->strEnrollPrns;


				///////////////////
				// Member Objects
				///////////////////
				case 'CategoryObject':
					/**
					 * Gets the value for the EcourseCategory object referenced by intCategory (Not Null)
					 * @return EcourseCategory
					 */
					try {
						if ((!$this->objCategoryObject) && (!is_null($this->intCategory)))
							$this->objCategoryObject = EcourseCategory::Load($this->intCategory);
						return $this->objCategoryObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Teacher':
					/**
					 * Gets the value for the Login object referenced by intTeacherId 
					 * @return Login
					 */
					try {
						if ((!$this->objTeacher) && (!is_null($this->intTeacherId)))
							$this->objTeacher = Login::Load($this->intTeacherId);
						return $this->objTeacher;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_ESessionAsId':
					/**
					 * Gets the value for the private _objESessionAsId (Read-Only)
					 * if set due to an expansion on the e_session.ide_course reverse relationship
					 * @return ESession
					 */
					return $this->_objESessionAsId;

				case '_ESessionAsIdArray':
					/**
					 * Gets the value for the private _objESessionAsIdArray (Read-Only)
					 * if set due to an ExpandAsArray on the e_session.ide_course reverse relationship
					 * @return ESession[]
					 */
					return $this->_objESessionAsIdArray;

				case '_EStudentAsId':
					/**
					 * Gets the value for the private _objEStudentAsId (Read-Only)
					 * if set due to an expansion on the e_student.ide_course reverse relationship
					 * @return EStudent
					 */
					return $this->_objEStudentAsId;

				case '_EStudentAsIdArray':
					/**
					 * Gets the value for the private _objEStudentAsIdArray (Read-Only)
					 * if set due to an ExpandAsArray on the e_student.ide_course reverse relationship
					 * @return EStudent[]
					 */
					return $this->_objEStudentAsIdArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Title':
					/**
					 * Sets the value for strTitle (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTitle = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Description':
					/**
					 * Sets the value for strDescription 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strDescription = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Category':
					/**
					 * Sets the value for intCategory (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCategoryObject = null;
						return ($this->intCategory = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Photo':
					/**
					 * Sets the value for strPhoto 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strPhoto = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Tags':
					/**
					 * Sets the value for strTags 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTags = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'StartDate':
					/**
					 * Sets the value for dttStartDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttStartDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'EndDate':
					/**
					 * Sets the value for dttEndDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttEndDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Enabled':
					/**
					 * Sets the value for blnEnabled 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnEnabled = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TotalSession':
					/**
					 * Sets the value for intTotalSession 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intTotalSession = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TeacherId':
					/**
					 * Sets the value for intTeacherId 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objTeacher = null;
						return ($this->intTeacherId = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Class':
					/**
					 * Sets the value for strClass 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strClass = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Sem':
					/**
					 * Sets the value for strSem 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strSem = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'EnrollCount':
					/**
					 * Sets the value for intEnrollCount 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intEnrollCount = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'EnrollPrns':
					/**
					 * Sets the value for strEnrollPrns 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strEnrollPrns = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'CategoryObject':
					/**
					 * Sets the value for the EcourseCategory object referenced by intCategory (Not Null)
					 * @param EcourseCategory $mixValue
					 * @return EcourseCategory
					 */
					if (is_null($mixValue)) {
						$this->intCategory = null;
						$this->objCategoryObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a EcourseCategory object
						try {
							$mixValue = QType::Cast($mixValue, 'EcourseCategory');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED EcourseCategory object
						if (is_null($mixValue->IdecourseCategory))
							throw new QCallerException('Unable to set an unsaved CategoryObject for this ECourse');

						// Update Local Member Variables
						$this->objCategoryObject = $mixValue;
						$this->intCategory = $mixValue->IdecourseCategory;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'Teacher':
					/**
					 * Sets the value for the Login object referenced by intTeacherId 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intTeacherId = null;
						$this->objTeacher = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved Teacher for this ECourse');

						// Update Local Member Variables
						$this->objTeacher = $mixValue;
						$this->intTeacherId = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for ESessionAsId
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ESessionsAsId as an array of ESession objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ESession[]
		*/
		public function GetESessionAsIdArray($objOptionalClauses = null) {
			if ((is_null($this->intIdeCourse)))
				return array();

			try {
				return ESession::LoadArrayByIdeCourse($this->intIdeCourse, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ESessionsAsId
		 * @return int
		*/
		public function CountESessionsAsId() {
			if ((is_null($this->intIdeCourse)))
				return 0;

			return ESession::CountByIdeCourse($this->intIdeCourse);
		}

		/**
		 * Associates a ESessionAsId
		 * @param ESession $objESession
		 * @return void
		*/
		public function AssociateESessionAsId(ESession $objESession) {
			if ((is_null($this->intIdeCourse)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateESessionAsId on this unsaved ECourse.');
			if ((is_null($objESession->IdeSession)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateESessionAsId on this ECourse with an unsaved ESession.');

			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`e_session`
				SET
					`ide_course` = ' . $objDatabase->SqlVariable($this->intIdeCourse) . '
				WHERE
					`ide_session` = ' . $objDatabase->SqlVariable($objESession->IdeSession) . '
			');
		}

		/**
		 * Unassociates a ESessionAsId
		 * @param ESession $objESession
		 * @return void
		*/
		public function UnassociateESessionAsId(ESession $objESession) {
			if ((is_null($this->intIdeCourse)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateESessionAsId on this unsaved ECourse.');
			if ((is_null($objESession->IdeSession)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateESessionAsId on this ECourse with an unsaved ESession.');

			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`e_session`
				SET
					`ide_course` = null
				WHERE
					`ide_session` = ' . $objDatabase->SqlVariable($objESession->IdeSession) . ' AND
					`ide_course` = ' . $objDatabase->SqlVariable($this->intIdeCourse) . '
			');
		}

		/**
		 * Unassociates all ESessionsAsId
		 * @return void
		*/
		public function UnassociateAllESessionsAsId() {
			if ((is_null($this->intIdeCourse)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateESessionAsId on this unsaved ECourse.');

			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`e_session`
				SET
					`ide_course` = null
				WHERE
					`ide_course` = ' . $objDatabase->SqlVariable($this->intIdeCourse) . '
			');
		}

		/**
		 * Deletes an associated ESessionAsId
		 * @param ESession $objESession
		 * @return void
		*/
		public function DeleteAssociatedESessionAsId(ESession $objESession) {
			if ((is_null($this->intIdeCourse)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateESessionAsId on this unsaved ECourse.');
			if ((is_null($objESession->IdeSession)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateESessionAsId on this ECourse with an unsaved ESession.');

			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`e_session`
				WHERE
					`ide_session` = ' . $objDatabase->SqlVariable($objESession->IdeSession) . ' AND
					`ide_course` = ' . $objDatabase->SqlVariable($this->intIdeCourse) . '
			');
		}

		/**
		 * Deletes all associated ESessionsAsId
		 * @return void
		*/
		public function DeleteAllESessionsAsId() {
			if ((is_null($this->intIdeCourse)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateESessionAsId on this unsaved ECourse.');

			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`e_session`
				WHERE
					`ide_course` = ' . $objDatabase->SqlVariable($this->intIdeCourse) . '
			');
		}


		// Related Objects' Methods for EStudentAsId
		//-------------------------------------------------------------------

		/**
		 * Gets all associated EStudentsAsId as an array of EStudent objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EStudent[]
		*/
		public function GetEStudentAsIdArray($objOptionalClauses = null) {
			if ((is_null($this->intIdeCourse)))
				return array();

			try {
				return EStudent::LoadArrayByIdeCourse($this->intIdeCourse, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated EStudentsAsId
		 * @return int
		*/
		public function CountEStudentsAsId() {
			if ((is_null($this->intIdeCourse)))
				return 0;

			return EStudent::CountByIdeCourse($this->intIdeCourse);
		}

		/**
		 * Associates a EStudentAsId
		 * @param EStudent $objEStudent
		 * @return void
		*/
		public function AssociateEStudentAsId(EStudent $objEStudent) {
			if ((is_null($this->intIdeCourse)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEStudentAsId on this unsaved ECourse.');
			if ((is_null($objEStudent->IdeStudent)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEStudentAsId on this ECourse with an unsaved EStudent.');

			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`e_student`
				SET
					`ide_course` = ' . $objDatabase->SqlVariable($this->intIdeCourse) . '
				WHERE
					`ide_student` = ' . $objDatabase->SqlVariable($objEStudent->IdeStudent) . '
			');
		}

		/**
		 * Unassociates a EStudentAsId
		 * @param EStudent $objEStudent
		 * @return void
		*/
		public function UnassociateEStudentAsId(EStudent $objEStudent) {
			if ((is_null($this->intIdeCourse)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEStudentAsId on this unsaved ECourse.');
			if ((is_null($objEStudent->IdeStudent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEStudentAsId on this ECourse with an unsaved EStudent.');

			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`e_student`
				SET
					`ide_course` = null
				WHERE
					`ide_student` = ' . $objDatabase->SqlVariable($objEStudent->IdeStudent) . ' AND
					`ide_course` = ' . $objDatabase->SqlVariable($this->intIdeCourse) . '
			');
		}

		/**
		 * Unassociates all EStudentsAsId
		 * @return void
		*/
		public function UnassociateAllEStudentsAsId() {
			if ((is_null($this->intIdeCourse)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEStudentAsId on this unsaved ECourse.');

			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`e_student`
				SET
					`ide_course` = null
				WHERE
					`ide_course` = ' . $objDatabase->SqlVariable($this->intIdeCourse) . '
			');
		}

		/**
		 * Deletes an associated EStudentAsId
		 * @param EStudent $objEStudent
		 * @return void
		*/
		public function DeleteAssociatedEStudentAsId(EStudent $objEStudent) {
			if ((is_null($this->intIdeCourse)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEStudentAsId on this unsaved ECourse.');
			if ((is_null($objEStudent->IdeStudent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEStudentAsId on this ECourse with an unsaved EStudent.');

			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`e_student`
				WHERE
					`ide_student` = ' . $objDatabase->SqlVariable($objEStudent->IdeStudent) . ' AND
					`ide_course` = ' . $objDatabase->SqlVariable($this->intIdeCourse) . '
			');
		}

		/**
		 * Deletes all associated EStudentsAsId
		 * @return void
		*/
		public function DeleteAllEStudentsAsId() {
			if ((is_null($this->intIdeCourse)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEStudentAsId on this unsaved ECourse.');

			// Get the Database Object for this Class
			$objDatabase = ECourse::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`e_student`
				WHERE
					`ide_course` = ' . $objDatabase->SqlVariable($this->intIdeCourse) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "e_course";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[ECourse::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="ECourse"><sequence>';
			$strToReturn .= '<element name="IdeCourse" type="xsd:int"/>';
			$strToReturn .= '<element name="Title" type="xsd:string"/>';
			$strToReturn .= '<element name="Description" type="xsd:string"/>';
			$strToReturn .= '<element name="CategoryObject" type="xsd1:EcourseCategory"/>';
			$strToReturn .= '<element name="Photo" type="xsd:string"/>';
			$strToReturn .= '<element name="Tags" type="xsd:string"/>';
			$strToReturn .= '<element name="StartDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="EndDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Enabled" type="xsd:boolean"/>';
			$strToReturn .= '<element name="TotalSession" type="xsd:int"/>';
			$strToReturn .= '<element name="Teacher" type="xsd1:Login"/>';
			$strToReturn .= '<element name="Class" type="xsd:string"/>';
			$strToReturn .= '<element name="Sem" type="xsd:string"/>';
			$strToReturn .= '<element name="EnrollCount" type="xsd:int"/>';
			$strToReturn .= '<element name="EnrollPrns" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('ECourse', $strComplexTypeArray)) {
				$strComplexTypeArray['ECourse'] = ECourse::GetSoapComplexTypeXml();
				EcourseCategory::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, ECourse::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new ECourse();
			if (property_exists($objSoapObject, 'IdeCourse'))
				$objToReturn->intIdeCourse = $objSoapObject->IdeCourse;
			if (property_exists($objSoapObject, 'Title'))
				$objToReturn->strTitle = $objSoapObject->Title;
			if (property_exists($objSoapObject, 'Description'))
				$objToReturn->strDescription = $objSoapObject->Description;
			if ((property_exists($objSoapObject, 'CategoryObject')) &&
				($objSoapObject->CategoryObject))
				$objToReturn->CategoryObject = EcourseCategory::GetObjectFromSoapObject($objSoapObject->CategoryObject);
			if (property_exists($objSoapObject, 'Photo'))
				$objToReturn->strPhoto = $objSoapObject->Photo;
			if (property_exists($objSoapObject, 'Tags'))
				$objToReturn->strTags = $objSoapObject->Tags;
			if (property_exists($objSoapObject, 'StartDate'))
				$objToReturn->dttStartDate = new QDateTime($objSoapObject->StartDate);
			if (property_exists($objSoapObject, 'EndDate'))
				$objToReturn->dttEndDate = new QDateTime($objSoapObject->EndDate);
			if (property_exists($objSoapObject, 'Enabled'))
				$objToReturn->blnEnabled = $objSoapObject->Enabled;
			if (property_exists($objSoapObject, 'TotalSession'))
				$objToReturn->intTotalSession = $objSoapObject->TotalSession;
			if ((property_exists($objSoapObject, 'Teacher')) &&
				($objSoapObject->Teacher))
				$objToReturn->Teacher = Login::GetObjectFromSoapObject($objSoapObject->Teacher);
			if (property_exists($objSoapObject, 'Class'))
				$objToReturn->strClass = $objSoapObject->Class;
			if (property_exists($objSoapObject, 'Sem'))
				$objToReturn->strSem = $objSoapObject->Sem;
			if (property_exists($objSoapObject, 'EnrollCount'))
				$objToReturn->intEnrollCount = $objSoapObject->EnrollCount;
			if (property_exists($objSoapObject, 'EnrollPrns'))
				$objToReturn->strEnrollPrns = $objSoapObject->EnrollPrns;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, ECourse::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objCategoryObject)
				$objObject->objCategoryObject = EcourseCategory::GetSoapObjectFromObject($objObject->objCategoryObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCategory = null;
			if ($objObject->dttStartDate)
				$objObject->dttStartDate = $objObject->dttStartDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttEndDate)
				$objObject->dttEndDate = $objObject->dttEndDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objTeacher)
				$objObject->objTeacher = Login::GetSoapObjectFromObject($objObject->objTeacher, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intTeacherId = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdeCourse'] = $this->intIdeCourse;
			$iArray['Title'] = $this->strTitle;
			$iArray['Description'] = $this->strDescription;
			$iArray['Category'] = $this->intCategory;
			$iArray['Photo'] = $this->strPhoto;
			$iArray['Tags'] = $this->strTags;
			$iArray['StartDate'] = $this->dttStartDate;
			$iArray['EndDate'] = $this->dttEndDate;
			$iArray['Enabled'] = $this->blnEnabled;
			$iArray['TotalSession'] = $this->intTotalSession;
			$iArray['TeacherId'] = $this->intTeacherId;
			$iArray['Class'] = $this->strClass;
			$iArray['Sem'] = $this->strSem;
			$iArray['EnrollCount'] = $this->intEnrollCount;
			$iArray['EnrollPrns'] = $this->strEnrollPrns;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdeCourse ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdeCourse
     * @property-read QQNode $Title
     * @property-read QQNode $Description
     * @property-read QQNode $Category
     * @property-read QQNodeEcourseCategory $CategoryObject
     * @property-read QQNode $Photo
     * @property-read QQNode $Tags
     * @property-read QQNode $StartDate
     * @property-read QQNode $EndDate
     * @property-read QQNode $Enabled
     * @property-read QQNode $TotalSession
     * @property-read QQNode $TeacherId
     * @property-read QQNodeLogin $Teacher
     * @property-read QQNode $Class
     * @property-read QQNode $Sem
     * @property-read QQNode $EnrollCount
     * @property-read QQNode $EnrollPrns
     *
     *
     * @property-read QQReverseReferenceNodeESession $ESessionAsId
     * @property-read QQReverseReferenceNodeEStudent $EStudentAsId

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeECourse extends QQNode {
		protected $strTableName = 'e_course';
		protected $strPrimaryKey = 'ide_course';
		protected $strClassName = 'ECourse';
		public function __get($strName) {
			switch ($strName) {
				case 'IdeCourse':
					return new QQNode('ide_course', 'IdeCourse', 'Integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'VarChar', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'Blob', $this);
				case 'Category':
					return new QQNode('category', 'Category', 'Integer', $this);
				case 'CategoryObject':
					return new QQNodeEcourseCategory('category', 'CategoryObject', 'Integer', $this);
				case 'Photo':
					return new QQNode('photo', 'Photo', 'Blob', $this);
				case 'Tags':
					return new QQNode('tags', 'Tags', 'Blob', $this);
				case 'StartDate':
					return new QQNode('start_date', 'StartDate', 'Date', $this);
				case 'EndDate':
					return new QQNode('end_date', 'EndDate', 'Date', $this);
				case 'Enabled':
					return new QQNode('enabled', 'Enabled', 'Bit', $this);
				case 'TotalSession':
					return new QQNode('total_session', 'TotalSession', 'Integer', $this);
				case 'TeacherId':
					return new QQNode('teacher_id', 'TeacherId', 'Integer', $this);
				case 'Teacher':
					return new QQNodeLogin('teacher_id', 'Teacher', 'Integer', $this);
				case 'Class':
					return new QQNode('class', 'Class', 'Blob', $this);
				case 'Sem':
					return new QQNode('sem', 'Sem', 'Blob', $this);
				case 'EnrollCount':
					return new QQNode('enroll_count', 'EnrollCount', 'Integer', $this);
				case 'EnrollPrns':
					return new QQNode('enroll_prns', 'EnrollPrns', 'Blob', $this);
				case 'ESessionAsId':
					return new QQReverseReferenceNodeESession($this, 'esessionasid', 'reverse_reference', 'ide_course');
				case 'EStudentAsId':
					return new QQReverseReferenceNodeEStudent($this, 'estudentasid', 'reverse_reference', 'ide_course');

				case '_PrimaryKeyNode':
					return new QQNode('ide_course', 'IdeCourse', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdeCourse
     * @property-read QQNode $Title
     * @property-read QQNode $Description
     * @property-read QQNode $Category
     * @property-read QQNodeEcourseCategory $CategoryObject
     * @property-read QQNode $Photo
     * @property-read QQNode $Tags
     * @property-read QQNode $StartDate
     * @property-read QQNode $EndDate
     * @property-read QQNode $Enabled
     * @property-read QQNode $TotalSession
     * @property-read QQNode $TeacherId
     * @property-read QQNodeLogin $Teacher
     * @property-read QQNode $Class
     * @property-read QQNode $Sem
     * @property-read QQNode $EnrollCount
     * @property-read QQNode $EnrollPrns
     *
     *
     * @property-read QQReverseReferenceNodeESession $ESessionAsId
     * @property-read QQReverseReferenceNodeEStudent $EStudentAsId

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeECourse extends QQReverseReferenceNode {
		protected $strTableName = 'e_course';
		protected $strPrimaryKey = 'ide_course';
		protected $strClassName = 'ECourse';
		public function __get($strName) {
			switch ($strName) {
				case 'IdeCourse':
					return new QQNode('ide_course', 'IdeCourse', 'integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'string', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'string', $this);
				case 'Category':
					return new QQNode('category', 'Category', 'integer', $this);
				case 'CategoryObject':
					return new QQNodeEcourseCategory('category', 'CategoryObject', 'integer', $this);
				case 'Photo':
					return new QQNode('photo', 'Photo', 'string', $this);
				case 'Tags':
					return new QQNode('tags', 'Tags', 'string', $this);
				case 'StartDate':
					return new QQNode('start_date', 'StartDate', 'QDateTime', $this);
				case 'EndDate':
					return new QQNode('end_date', 'EndDate', 'QDateTime', $this);
				case 'Enabled':
					return new QQNode('enabled', 'Enabled', 'boolean', $this);
				case 'TotalSession':
					return new QQNode('total_session', 'TotalSession', 'integer', $this);
				case 'TeacherId':
					return new QQNode('teacher_id', 'TeacherId', 'integer', $this);
				case 'Teacher':
					return new QQNodeLogin('teacher_id', 'Teacher', 'integer', $this);
				case 'Class':
					return new QQNode('class', 'Class', 'string', $this);
				case 'Sem':
					return new QQNode('sem', 'Sem', 'string', $this);
				case 'EnrollCount':
					return new QQNode('enroll_count', 'EnrollCount', 'integer', $this);
				case 'EnrollPrns':
					return new QQNode('enroll_prns', 'EnrollPrns', 'string', $this);
				case 'ESessionAsId':
					return new QQReverseReferenceNodeESession($this, 'esessionasid', 'reverse_reference', 'ide_course');
				case 'EStudentAsId':
					return new QQReverseReferenceNodeEStudent($this, 'estudentasid', 'reverse_reference', 'ide_course');

				case '_PrimaryKeyNode':
					return new QQNode('ide_course', 'IdeCourse', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
