<?php
	/**
	 * The abstract TasksGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Tasks subclass which
	 * extends this TasksGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Tasks class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idtasks the value for intIdtasks (Read-Only PK)
	 * @property-read string $Date the value for strDate (Read-Only Timestamp)
	 * @property string $Code the value for strCode (Unique)
	 * @property integer $ItemFeature the value for intItemFeature (Not Null)
	 * @property string $Title the value for strTitle (Not Null)
	 * @property string $Data the value for strData (Not Null)
	 * @property integer $Priority the value for intPriority (Not Null)
	 * @property integer $Seq the value for intSeq (Not Null)
	 * @property integer $CurrentStatus the value for intCurrentStatus (Not Null)
	 * @property QDateTime $DueDate the value for dttDueDate 
	 * @property integer $Counter the value for intCounter 
	 * @property ItemHasFeatures $ItemFeatureObject the value for the ItemHasFeatures object referenced by intItemFeature (Not Null)
	 * @property Priority $PriorityObject the value for the Priority object referenced by intPriority (Not Null)
	 * @property Status $CurrentStatusObject the value for the Status object referenced by intCurrentStatus (Not Null)
	 * @property-read Log $_LogAsTask the value for the private _objLogAsTask (Read-Only) if set due to an expansion on the log.task reverse relationship
	 * @property-read Log[] $_LogAsTaskArray the value for the private _objLogAsTaskArray (Read-Only) if set due to an ExpandAsArray on the log.task reverse relationship
	 * @property-read Notes $_NotesAsTask the value for the private _objNotesAsTask (Read-Only) if set due to an expansion on the notes.task reverse relationship
	 * @property-read Notes[] $_NotesAsTaskArray the value for the private _objNotesAsTaskArray (Read-Only) if set due to an ExpandAsArray on the notes.task reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class TasksGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column tasks.idtasks
		 * @var integer intIdtasks
		 */
		protected $intIdtasks;
		const IdtasksDefault = null;


		/**
		 * Protected member variable that maps to the database column tasks.date
		 * @var string strDate
		 */
		protected $strDate;
		const DateDefault = null;


		/**
		 * Protected member variable that maps to the database column tasks.code
		 * @var string strCode
		 */
		protected $strCode;
		const CodeMaxLength = 45;
		const CodeDefault = null;


		/**
		 * Protected member variable that maps to the database column tasks.Item_feature
		 * @var integer intItemFeature
		 */
		protected $intItemFeature;
		const ItemFeatureDefault = null;


		/**
		 * Protected member variable that maps to the database column tasks.title
		 * @var string strTitle
		 */
		protected $strTitle;
		const TitleMaxLength = 200;
		const TitleDefault = null;


		/**
		 * Protected member variable that maps to the database column tasks.data
		 * @var string strData
		 */
		protected $strData;
		const DataDefault = null;


		/**
		 * Protected member variable that maps to the database column tasks.priority
		 * @var integer intPriority
		 */
		protected $intPriority;
		const PriorityDefault = null;


		/**
		 * Protected member variable that maps to the database column tasks.seq
		 * @var integer intSeq
		 */
		protected $intSeq;
		const SeqDefault = null;


		/**
		 * Protected member variable that maps to the database column tasks.current_status
		 * @var integer intCurrentStatus
		 */
		protected $intCurrentStatus;
		const CurrentStatusDefault = null;


		/**
		 * Protected member variable that maps to the database column tasks.due_date
		 * @var QDateTime dttDueDate
		 */
		protected $dttDueDate;
		const DueDateDefault = null;


		/**
		 * Protected member variable that maps to the database column tasks.counter
		 * @var integer intCounter
		 */
		protected $intCounter;
		const CounterDefault = null;


		/**
		 * Private member variable that stores a reference to a single LogAsTask object
		 * (of type Log), if this Tasks object was restored with
		 * an expansion on the log association table.
		 * @var Log _objLogAsTask;
		 */
		private $_objLogAsTask;

		/**
		 * Private member variable that stores a reference to an array of LogAsTask objects
		 * (of type Log[]), if this Tasks object was restored with
		 * an ExpandAsArray on the log association table.
		 * @var Log[] _objLogAsTaskArray;
		 */
		private $_objLogAsTaskArray = null;

		/**
		 * Private member variable that stores a reference to a single NotesAsTask object
		 * (of type Notes), if this Tasks object was restored with
		 * an expansion on the notes association table.
		 * @var Notes _objNotesAsTask;
		 */
		private $_objNotesAsTask;

		/**
		 * Private member variable that stores a reference to an array of NotesAsTask objects
		 * (of type Notes[]), if this Tasks object was restored with
		 * an ExpandAsArray on the notes association table.
		 * @var Notes[] _objNotesAsTaskArray;
		 */
		private $_objNotesAsTaskArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column tasks.Item_feature.
		 *
		 * NOTE: Always use the ItemFeatureObject property getter to correctly retrieve this ItemHasFeatures object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var ItemHasFeatures objItemFeatureObject
		 */
		protected $objItemFeatureObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column tasks.priority.
		 *
		 * NOTE: Always use the PriorityObject property getter to correctly retrieve this Priority object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Priority objPriorityObject
		 */
		protected $objPriorityObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column tasks.current_status.
		 *
		 * NOTE: Always use the CurrentStatusObject property getter to correctly retrieve this Status object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Status objCurrentStatusObject
		 */
		protected $objCurrentStatusObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdtasks = Tasks::IdtasksDefault;
			$this->strDate = Tasks::DateDefault;
			$this->strCode = Tasks::CodeDefault;
			$this->intItemFeature = Tasks::ItemFeatureDefault;
			$this->strTitle = Tasks::TitleDefault;
			$this->strData = Tasks::DataDefault;
			$this->intPriority = Tasks::PriorityDefault;
			$this->intSeq = Tasks::SeqDefault;
			$this->intCurrentStatus = Tasks::CurrentStatusDefault;
			$this->dttDueDate = (Tasks::DueDateDefault === null)?null:new QDateTime(Tasks::DueDateDefault);
			$this->intCounter = Tasks::CounterDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Tasks from PK Info
		 * @param integer $intIdtasks
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Tasks
		 */
		public static function Load($intIdtasks, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Tasks', $intIdtasks);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Tasks::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Tasks()->Idtasks, $intIdtasks)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Taskses
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Tasks[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Tasks::QueryArray to perform the LoadAll query
			try {
				return Tasks::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Taskses
		 * @return int
		 */
		public static function CountAll() {
			// Call Tasks::QueryCount to perform the CountAll query
			return Tasks::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();

			// Create/Build out the QueryBuilder object with Tasks-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'tasks');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Tasks::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('tasks');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Tasks object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Tasks the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Tasks::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Tasks object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Tasks::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Tasks::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Tasks objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Tasks[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Tasks::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Tasks::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Tasks::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Tasks objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Tasks::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();

			$strQuery = Tasks::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/tasks', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Tasks::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Tasks
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'tasks';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idtasks', $strAliasPrefix . 'idtasks');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idtasks', $strAliasPrefix . 'idtasks');
			    $objBuilder->AddSelectItem($strTableName, 'date', $strAliasPrefix . 'date');
			    $objBuilder->AddSelectItem($strTableName, 'code', $strAliasPrefix . 'code');
			    $objBuilder->AddSelectItem($strTableName, 'Item_feature', $strAliasPrefix . 'Item_feature');
			    $objBuilder->AddSelectItem($strTableName, 'title', $strAliasPrefix . 'title');
			    $objBuilder->AddSelectItem($strTableName, 'data', $strAliasPrefix . 'data');
			    $objBuilder->AddSelectItem($strTableName, 'priority', $strAliasPrefix . 'priority');
			    $objBuilder->AddSelectItem($strTableName, 'seq', $strAliasPrefix . 'seq');
			    $objBuilder->AddSelectItem($strTableName, 'current_status', $strAliasPrefix . 'current_status');
			    $objBuilder->AddSelectItem($strTableName, 'due_date', $strAliasPrefix . 'due_date');
			    $objBuilder->AddSelectItem($strTableName, 'counter', $strAliasPrefix . 'counter');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Tasks from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Tasks::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Tasks
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idtasks';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdtasks == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'tasks__';


						// Expanding reverse references: LogAsTask
						$strAlias = $strAliasPrefix . 'logastask__idlog';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objLogAsTaskArray)
								$objPreviousItem->_objLogAsTaskArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objLogAsTaskArray)) {
								$objPreviousChildItems = $objPreviousItem->_objLogAsTaskArray;
								$objChildItem = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logastask__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objLogAsTaskArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objLogAsTaskArray[] = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logastask__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: NotesAsTask
						$strAlias = $strAliasPrefix . 'notesastask__idnotes';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objNotesAsTaskArray)
								$objPreviousItem->_objNotesAsTaskArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objNotesAsTaskArray)) {
								$objPreviousChildItems = $objPreviousItem->_objNotesAsTaskArray;
								$objChildItem = Notes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'notesastask__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objNotesAsTaskArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objNotesAsTaskArray[] = Notes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'notesastask__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'tasks__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Tasks object
			$objToReturn = new Tasks();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idtasks';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdtasks = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strDate = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'Item_feature';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intItemFeature = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'title';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTitle = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'data';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strData = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'priority';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intPriority = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'seq';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSeq = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'current_status';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCurrentStatus = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'due_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDueDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'counter';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCounter = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idtasks != $objPreviousItem->Idtasks) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objLogAsTaskArray);
					$cnt = count($objToReturn->_objLogAsTaskArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objLogAsTaskArray, $objToReturn->_objLogAsTaskArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objNotesAsTaskArray);
					$cnt = count($objToReturn->_objNotesAsTaskArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objNotesAsTaskArray, $objToReturn->_objNotesAsTaskArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'tasks__';

			// Check for ItemFeatureObject Early Binding
			$strAlias = $strAliasPrefix . 'Item_feature__iditem_has_features';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objItemFeatureObject = ItemHasFeatures::InstantiateDbRow($objDbRow, $strAliasPrefix . 'Item_feature__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for PriorityObject Early Binding
			$strAlias = $strAliasPrefix . 'priority__idpriority';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objPriorityObject = Priority::InstantiateDbRow($objDbRow, $strAliasPrefix . 'priority__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CurrentStatusObject Early Binding
			$strAlias = $strAliasPrefix . 'current_status__idstatus';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCurrentStatusObject = Status::InstantiateDbRow($objDbRow, $strAliasPrefix . 'current_status__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for LogAsTask Virtual Binding
			$strAlias = $strAliasPrefix . 'logastask__idlog';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objLogAsTaskArray)
				$objToReturn->_objLogAsTaskArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objLogAsTaskArray[] = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logastask__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objLogAsTask = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logastask__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for NotesAsTask Virtual Binding
			$strAlias = $strAliasPrefix . 'notesastask__idnotes';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objNotesAsTaskArray)
				$objToReturn->_objNotesAsTaskArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objNotesAsTaskArray[] = Notes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'notesastask__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objNotesAsTask = Notes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'notesastask__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Taskses from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Tasks[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Tasks::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Tasks::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Tasks object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Tasks next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Tasks::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Tasks object,
		 * by Idtasks Index(es)
		 * @param integer $intIdtasks
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Tasks
		*/
		public static function LoadByIdtasks($intIdtasks, $objOptionalClauses = null) {
			return Tasks::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Tasks()->Idtasks, $intIdtasks)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single Tasks object,
		 * by Code Index(es)
		 * @param string $strCode
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Tasks
		*/
		public static function LoadByCode($strCode, $objOptionalClauses = null) {
			return Tasks::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Tasks()->Code, $strCode)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Tasks objects,
		 * by ItemFeature Index(es)
		 * @param integer $intItemFeature
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Tasks[]
		*/
		public static function LoadArrayByItemFeature($intItemFeature, $objOptionalClauses = null) {
			// Call Tasks::QueryArray to perform the LoadArrayByItemFeature query
			try {
				return Tasks::QueryArray(
					QQ::Equal(QQN::Tasks()->ItemFeature, $intItemFeature),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Taskses
		 * by ItemFeature Index(es)
		 * @param integer $intItemFeature
		 * @return int
		*/
		public static function CountByItemFeature($intItemFeature) {
			// Call Tasks::QueryCount to perform the CountByItemFeature query
			return Tasks::QueryCount(
				QQ::Equal(QQN::Tasks()->ItemFeature, $intItemFeature)
			);
		}

		/**
		 * Load an array of Tasks objects,
		 * by Priority Index(es)
		 * @param integer $intPriority
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Tasks[]
		*/
		public static function LoadArrayByPriority($intPriority, $objOptionalClauses = null) {
			// Call Tasks::QueryArray to perform the LoadArrayByPriority query
			try {
				return Tasks::QueryArray(
					QQ::Equal(QQN::Tasks()->Priority, $intPriority),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Taskses
		 * by Priority Index(es)
		 * @param integer $intPriority
		 * @return int
		*/
		public static function CountByPriority($intPriority) {
			// Call Tasks::QueryCount to perform the CountByPriority query
			return Tasks::QueryCount(
				QQ::Equal(QQN::Tasks()->Priority, $intPriority)
			);
		}

		/**
		 * Load an array of Tasks objects,
		 * by CurrentStatus Index(es)
		 * @param integer $intCurrentStatus
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Tasks[]
		*/
		public static function LoadArrayByCurrentStatus($intCurrentStatus, $objOptionalClauses = null) {
			// Call Tasks::QueryArray to perform the LoadArrayByCurrentStatus query
			try {
				return Tasks::QueryArray(
					QQ::Equal(QQN::Tasks()->CurrentStatus, $intCurrentStatus),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Taskses
		 * by CurrentStatus Index(es)
		 * @param integer $intCurrentStatus
		 * @return int
		*/
		public static function CountByCurrentStatus($intCurrentStatus) {
			// Call Tasks::QueryCount to perform the CountByCurrentStatus query
			return Tasks::QueryCount(
				QQ::Equal(QQN::Tasks()->CurrentStatus, $intCurrentStatus)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Tasks
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `tasks` (
							`code`,
							`Item_feature`,
							`title`,
							`data`,
							`priority`,
							`seq`,
							`current_status`,
							`due_date`,
							`counter`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strCode) . ',
							' . $objDatabase->SqlVariable($this->intItemFeature) . ',
							' . $objDatabase->SqlVariable($this->strTitle) . ',
							' . $objDatabase->SqlVariable($this->strData) . ',
							' . $objDatabase->SqlVariable($this->intPriority) . ',
							' . $objDatabase->SqlVariable($this->intSeq) . ',
							' . $objDatabase->SqlVariable($this->intCurrentStatus) . ',
							' . $objDatabase->SqlVariable($this->dttDueDate) . ',
							' . $objDatabase->SqlVariable($this->intCounter) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdtasks = $objDatabase->InsertId('tasks', 'idtasks');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)
					if (!$blnForceUpdate) {
						// Perform the Optimistic Locking check
						$objResult = $objDatabase->Query('
							SELECT
								`date`
							FROM
								`tasks`
							WHERE
							`idtasks` = ' . $objDatabase->SqlVariable($this->intIdtasks) . '
						');

						$objRow = $objResult->FetchArray();
						if ($objRow[0] != $this->strDate)
							throw new QOptimisticLockingException('Tasks');
					}

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`tasks`
						SET
							`code` = ' . $objDatabase->SqlVariable($this->strCode) . ',
							`Item_feature` = ' . $objDatabase->SqlVariable($this->intItemFeature) . ',
							`title` = ' . $objDatabase->SqlVariable($this->strTitle) . ',
							`data` = ' . $objDatabase->SqlVariable($this->strData) . ',
							`priority` = ' . $objDatabase->SqlVariable($this->intPriority) . ',
							`seq` = ' . $objDatabase->SqlVariable($this->intSeq) . ',
							`current_status` = ' . $objDatabase->SqlVariable($this->intCurrentStatus) . ',
							`due_date` = ' . $objDatabase->SqlVariable($this->dttDueDate) . ',
							`counter` = ' . $objDatabase->SqlVariable($this->intCounter) . '
						WHERE
							`idtasks` = ' . $objDatabase->SqlVariable($this->intIdtasks) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;

			// Update Local Timestamp
			$objResult = $objDatabase->Query('
				SELECT
					`date`
				FROM
					`tasks`
				WHERE
							`idtasks` = ' . $objDatabase->SqlVariable($this->intIdtasks) . '
			');

			$objRow = $objResult->FetchArray();
			$this->strDate = $objRow[0];

			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Tasks
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdtasks)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Tasks with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`tasks`
				WHERE
					`idtasks` = ' . $objDatabase->SqlVariable($this->intIdtasks) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Tasks ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Tasks', $this->intIdtasks);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Taskses
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`tasks`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate tasks table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `tasks`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Tasks from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Tasks object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Tasks::Load($this->intIdtasks);

			// Update $this's local variables to match
			$this->strDate = $objReloaded->strDate;
			$this->strCode = $objReloaded->strCode;
			$this->ItemFeature = $objReloaded->ItemFeature;
			$this->strTitle = $objReloaded->strTitle;
			$this->strData = $objReloaded->strData;
			$this->Priority = $objReloaded->Priority;
			$this->intSeq = $objReloaded->intSeq;
			$this->CurrentStatus = $objReloaded->CurrentStatus;
			$this->dttDueDate = $objReloaded->dttDueDate;
			$this->intCounter = $objReloaded->intCounter;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idtasks':
					/**
					 * Gets the value for intIdtasks (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdtasks;

				case 'Date':
					/**
					 * Gets the value for strDate (Read-Only Timestamp)
					 * @return string
					 */
					return $this->strDate;

				case 'Code':
					/**
					 * Gets the value for strCode (Unique)
					 * @return string
					 */
					return $this->strCode;

				case 'ItemFeature':
					/**
					 * Gets the value for intItemFeature (Not Null)
					 * @return integer
					 */
					return $this->intItemFeature;

				case 'Title':
					/**
					 * Gets the value for strTitle (Not Null)
					 * @return string
					 */
					return $this->strTitle;

				case 'Data':
					/**
					 * Gets the value for strData (Not Null)
					 * @return string
					 */
					return $this->strData;

				case 'Priority':
					/**
					 * Gets the value for intPriority (Not Null)
					 * @return integer
					 */
					return $this->intPriority;

				case 'Seq':
					/**
					 * Gets the value for intSeq (Not Null)
					 * @return integer
					 */
					return $this->intSeq;

				case 'CurrentStatus':
					/**
					 * Gets the value for intCurrentStatus (Not Null)
					 * @return integer
					 */
					return $this->intCurrentStatus;

				case 'DueDate':
					/**
					 * Gets the value for dttDueDate 
					 * @return QDateTime
					 */
					return $this->dttDueDate;

				case 'Counter':
					/**
					 * Gets the value for intCounter 
					 * @return integer
					 */
					return $this->intCounter;


				///////////////////
				// Member Objects
				///////////////////
				case 'ItemFeatureObject':
					/**
					 * Gets the value for the ItemHasFeatures object referenced by intItemFeature (Not Null)
					 * @return ItemHasFeatures
					 */
					try {
						if ((!$this->objItemFeatureObject) && (!is_null($this->intItemFeature)))
							$this->objItemFeatureObject = ItemHasFeatures::Load($this->intItemFeature);
						return $this->objItemFeatureObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'PriorityObject':
					/**
					 * Gets the value for the Priority object referenced by intPriority (Not Null)
					 * @return Priority
					 */
					try {
						if ((!$this->objPriorityObject) && (!is_null($this->intPriority)))
							$this->objPriorityObject = Priority::Load($this->intPriority);
						return $this->objPriorityObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CurrentStatusObject':
					/**
					 * Gets the value for the Status object referenced by intCurrentStatus (Not Null)
					 * @return Status
					 */
					try {
						if ((!$this->objCurrentStatusObject) && (!is_null($this->intCurrentStatus)))
							$this->objCurrentStatusObject = Status::Load($this->intCurrentStatus);
						return $this->objCurrentStatusObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_LogAsTask':
					/**
					 * Gets the value for the private _objLogAsTask (Read-Only)
					 * if set due to an expansion on the log.task reverse relationship
					 * @return Log
					 */
					return $this->_objLogAsTask;

				case '_LogAsTaskArray':
					/**
					 * Gets the value for the private _objLogAsTaskArray (Read-Only)
					 * if set due to an ExpandAsArray on the log.task reverse relationship
					 * @return Log[]
					 */
					return $this->_objLogAsTaskArray;

				case '_NotesAsTask':
					/**
					 * Gets the value for the private _objNotesAsTask (Read-Only)
					 * if set due to an expansion on the notes.task reverse relationship
					 * @return Notes
					 */
					return $this->_objNotesAsTask;

				case '_NotesAsTaskArray':
					/**
					 * Gets the value for the private _objNotesAsTaskArray (Read-Only)
					 * if set due to an ExpandAsArray on the notes.task reverse relationship
					 * @return Notes[]
					 */
					return $this->_objNotesAsTaskArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Code':
					/**
					 * Sets the value for strCode (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ItemFeature':
					/**
					 * Sets the value for intItemFeature (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objItemFeatureObject = null;
						return ($this->intItemFeature = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Title':
					/**
					 * Sets the value for strTitle (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTitle = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Data':
					/**
					 * Sets the value for strData (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strData = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Priority':
					/**
					 * Sets the value for intPriority (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objPriorityObject = null;
						return ($this->intPriority = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Seq':
					/**
					 * Sets the value for intSeq (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intSeq = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CurrentStatus':
					/**
					 * Sets the value for intCurrentStatus (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCurrentStatusObject = null;
						return ($this->intCurrentStatus = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DueDate':
					/**
					 * Sets the value for dttDueDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDueDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Counter':
					/**
					 * Sets the value for intCounter 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intCounter = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'ItemFeatureObject':
					/**
					 * Sets the value for the ItemHasFeatures object referenced by intItemFeature (Not Null)
					 * @param ItemHasFeatures $mixValue
					 * @return ItemHasFeatures
					 */
					if (is_null($mixValue)) {
						$this->intItemFeature = null;
						$this->objItemFeatureObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a ItemHasFeatures object
						try {
							$mixValue = QType::Cast($mixValue, 'ItemHasFeatures');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED ItemHasFeatures object
						if (is_null($mixValue->IditemHasFeatures))
							throw new QCallerException('Unable to set an unsaved ItemFeatureObject for this Tasks');

						// Update Local Member Variables
						$this->objItemFeatureObject = $mixValue;
						$this->intItemFeature = $mixValue->IditemHasFeatures;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'PriorityObject':
					/**
					 * Sets the value for the Priority object referenced by intPriority (Not Null)
					 * @param Priority $mixValue
					 * @return Priority
					 */
					if (is_null($mixValue)) {
						$this->intPriority = null;
						$this->objPriorityObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Priority object
						try {
							$mixValue = QType::Cast($mixValue, 'Priority');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Priority object
						if (is_null($mixValue->Idpriority))
							throw new QCallerException('Unable to set an unsaved PriorityObject for this Tasks');

						// Update Local Member Variables
						$this->objPriorityObject = $mixValue;
						$this->intPriority = $mixValue->Idpriority;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CurrentStatusObject':
					/**
					 * Sets the value for the Status object referenced by intCurrentStatus (Not Null)
					 * @param Status $mixValue
					 * @return Status
					 */
					if (is_null($mixValue)) {
						$this->intCurrentStatus = null;
						$this->objCurrentStatusObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Status object
						try {
							$mixValue = QType::Cast($mixValue, 'Status');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Status object
						if (is_null($mixValue->Idstatus))
							throw new QCallerException('Unable to set an unsaved CurrentStatusObject for this Tasks');

						// Update Local Member Variables
						$this->objCurrentStatusObject = $mixValue;
						$this->intCurrentStatus = $mixValue->Idstatus;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for LogAsTask
		//-------------------------------------------------------------------

		/**
		 * Gets all associated LogsAsTask as an array of Log objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Log[]
		*/
		public function GetLogAsTaskArray($objOptionalClauses = null) {
			if ((is_null($this->intIdtasks)))
				return array();

			try {
				return Log::LoadArrayByTask($this->intIdtasks, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated LogsAsTask
		 * @return int
		*/
		public function CountLogsAsTask() {
			if ((is_null($this->intIdtasks)))
				return 0;

			return Log::CountByTask($this->intIdtasks);
		}

		/**
		 * Associates a LogAsTask
		 * @param Log $objLog
		 * @return void
		*/
		public function AssociateLogAsTask(Log $objLog) {
			if ((is_null($this->intIdtasks)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLogAsTask on this unsaved Tasks.');
			if ((is_null($objLog->Idlog)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLogAsTask on this Tasks with an unsaved Log.');

			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`log`
				SET
					`task` = ' . $objDatabase->SqlVariable($this->intIdtasks) . '
				WHERE
					`idlog` = ' . $objDatabase->SqlVariable($objLog->Idlog) . '
			');
		}

		/**
		 * Unassociates a LogAsTask
		 * @param Log $objLog
		 * @return void
		*/
		public function UnassociateLogAsTask(Log $objLog) {
			if ((is_null($this->intIdtasks)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsTask on this unsaved Tasks.');
			if ((is_null($objLog->Idlog)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsTask on this Tasks with an unsaved Log.');

			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`log`
				SET
					`task` = null
				WHERE
					`idlog` = ' . $objDatabase->SqlVariable($objLog->Idlog) . ' AND
					`task` = ' . $objDatabase->SqlVariable($this->intIdtasks) . '
			');
		}

		/**
		 * Unassociates all LogsAsTask
		 * @return void
		*/
		public function UnassociateAllLogsAsTask() {
			if ((is_null($this->intIdtasks)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsTask on this unsaved Tasks.');

			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`log`
				SET
					`task` = null
				WHERE
					`task` = ' . $objDatabase->SqlVariable($this->intIdtasks) . '
			');
		}

		/**
		 * Deletes an associated LogAsTask
		 * @param Log $objLog
		 * @return void
		*/
		public function DeleteAssociatedLogAsTask(Log $objLog) {
			if ((is_null($this->intIdtasks)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsTask on this unsaved Tasks.');
			if ((is_null($objLog->Idlog)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsTask on this Tasks with an unsaved Log.');

			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`log`
				WHERE
					`idlog` = ' . $objDatabase->SqlVariable($objLog->Idlog) . ' AND
					`task` = ' . $objDatabase->SqlVariable($this->intIdtasks) . '
			');
		}

		/**
		 * Deletes all associated LogsAsTask
		 * @return void
		*/
		public function DeleteAllLogsAsTask() {
			if ((is_null($this->intIdtasks)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsTask on this unsaved Tasks.');

			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`log`
				WHERE
					`task` = ' . $objDatabase->SqlVariable($this->intIdtasks) . '
			');
		}


		// Related Objects' Methods for NotesAsTask
		//-------------------------------------------------------------------

		/**
		 * Gets all associated NotesesAsTask as an array of Notes objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Notes[]
		*/
		public function GetNotesAsTaskArray($objOptionalClauses = null) {
			if ((is_null($this->intIdtasks)))
				return array();

			try {
				return Notes::LoadArrayByTask($this->intIdtasks, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated NotesesAsTask
		 * @return int
		*/
		public function CountNotesesAsTask() {
			if ((is_null($this->intIdtasks)))
				return 0;

			return Notes::CountByTask($this->intIdtasks);
		}

		/**
		 * Associates a NotesAsTask
		 * @param Notes $objNotes
		 * @return void
		*/
		public function AssociateNotesAsTask(Notes $objNotes) {
			if ((is_null($this->intIdtasks)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateNotesAsTask on this unsaved Tasks.');
			if ((is_null($objNotes->Idnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateNotesAsTask on this Tasks with an unsaved Notes.');

			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`notes`
				SET
					`task` = ' . $objDatabase->SqlVariable($this->intIdtasks) . '
				WHERE
					`idnotes` = ' . $objDatabase->SqlVariable($objNotes->Idnotes) . '
			');
		}

		/**
		 * Unassociates a NotesAsTask
		 * @param Notes $objNotes
		 * @return void
		*/
		public function UnassociateNotesAsTask(Notes $objNotes) {
			if ((is_null($this->intIdtasks)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNotesAsTask on this unsaved Tasks.');
			if ((is_null($objNotes->Idnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNotesAsTask on this Tasks with an unsaved Notes.');

			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`notes`
				SET
					`task` = null
				WHERE
					`idnotes` = ' . $objDatabase->SqlVariable($objNotes->Idnotes) . ' AND
					`task` = ' . $objDatabase->SqlVariable($this->intIdtasks) . '
			');
		}

		/**
		 * Unassociates all NotesesAsTask
		 * @return void
		*/
		public function UnassociateAllNotesesAsTask() {
			if ((is_null($this->intIdtasks)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNotesAsTask on this unsaved Tasks.');

			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`notes`
				SET
					`task` = null
				WHERE
					`task` = ' . $objDatabase->SqlVariable($this->intIdtasks) . '
			');
		}

		/**
		 * Deletes an associated NotesAsTask
		 * @param Notes $objNotes
		 * @return void
		*/
		public function DeleteAssociatedNotesAsTask(Notes $objNotes) {
			if ((is_null($this->intIdtasks)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNotesAsTask on this unsaved Tasks.');
			if ((is_null($objNotes->Idnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNotesAsTask on this Tasks with an unsaved Notes.');

			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`notes`
				WHERE
					`idnotes` = ' . $objDatabase->SqlVariable($objNotes->Idnotes) . ' AND
					`task` = ' . $objDatabase->SqlVariable($this->intIdtasks) . '
			');
		}

		/**
		 * Deletes all associated NotesesAsTask
		 * @return void
		*/
		public function DeleteAllNotesesAsTask() {
			if ((is_null($this->intIdtasks)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNotesAsTask on this unsaved Tasks.');

			// Get the Database Object for this Class
			$objDatabase = Tasks::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`notes`
				WHERE
					`task` = ' . $objDatabase->SqlVariable($this->intIdtasks) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "tasks";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Tasks::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Tasks"><sequence>';
			$strToReturn .= '<element name="Idtasks" type="xsd:int"/>';
			$strToReturn .= '<element name="Date" type="xsd:string"/>';
			$strToReturn .= '<element name="Code" type="xsd:string"/>';
			$strToReturn .= '<element name="ItemFeatureObject" type="xsd1:ItemHasFeatures"/>';
			$strToReturn .= '<element name="Title" type="xsd:string"/>';
			$strToReturn .= '<element name="Data" type="xsd:string"/>';
			$strToReturn .= '<element name="PriorityObject" type="xsd1:Priority"/>';
			$strToReturn .= '<element name="Seq" type="xsd:int"/>';
			$strToReturn .= '<element name="CurrentStatusObject" type="xsd1:Status"/>';
			$strToReturn .= '<element name="DueDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Counter" type="xsd:int"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Tasks', $strComplexTypeArray)) {
				$strComplexTypeArray['Tasks'] = Tasks::GetSoapComplexTypeXml();
				ItemHasFeatures::AlterSoapComplexTypeArray($strComplexTypeArray);
				Priority::AlterSoapComplexTypeArray($strComplexTypeArray);
				Status::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Tasks::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Tasks();
			if (property_exists($objSoapObject, 'Idtasks'))
				$objToReturn->intIdtasks = $objSoapObject->Idtasks;
			if (property_exists($objSoapObject, 'Date'))
				$objToReturn->strDate = $objSoapObject->Date;
			if (property_exists($objSoapObject, 'Code'))
				$objToReturn->strCode = $objSoapObject->Code;
			if ((property_exists($objSoapObject, 'ItemFeatureObject')) &&
				($objSoapObject->ItemFeatureObject))
				$objToReturn->ItemFeatureObject = ItemHasFeatures::GetObjectFromSoapObject($objSoapObject->ItemFeatureObject);
			if (property_exists($objSoapObject, 'Title'))
				$objToReturn->strTitle = $objSoapObject->Title;
			if (property_exists($objSoapObject, 'Data'))
				$objToReturn->strData = $objSoapObject->Data;
			if ((property_exists($objSoapObject, 'PriorityObject')) &&
				($objSoapObject->PriorityObject))
				$objToReturn->PriorityObject = Priority::GetObjectFromSoapObject($objSoapObject->PriorityObject);
			if (property_exists($objSoapObject, 'Seq'))
				$objToReturn->intSeq = $objSoapObject->Seq;
			if ((property_exists($objSoapObject, 'CurrentStatusObject')) &&
				($objSoapObject->CurrentStatusObject))
				$objToReturn->CurrentStatusObject = Status::GetObjectFromSoapObject($objSoapObject->CurrentStatusObject);
			if (property_exists($objSoapObject, 'DueDate'))
				$objToReturn->dttDueDate = new QDateTime($objSoapObject->DueDate);
			if (property_exists($objSoapObject, 'Counter'))
				$objToReturn->intCounter = $objSoapObject->Counter;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Tasks::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objItemFeatureObject)
				$objObject->objItemFeatureObject = ItemHasFeatures::GetSoapObjectFromObject($objObject->objItemFeatureObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intItemFeature = null;
			if ($objObject->objPriorityObject)
				$objObject->objPriorityObject = Priority::GetSoapObjectFromObject($objObject->objPriorityObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intPriority = null;
			if ($objObject->objCurrentStatusObject)
				$objObject->objCurrentStatusObject = Status::GetSoapObjectFromObject($objObject->objCurrentStatusObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCurrentStatus = null;
			if ($objObject->dttDueDate)
				$objObject->dttDueDate = $objObject->dttDueDate->qFormat(QDateTime::FormatSoap);
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idtasks'] = $this->intIdtasks;
			$iArray['Date'] = $this->strDate;
			$iArray['Code'] = $this->strCode;
			$iArray['ItemFeature'] = $this->intItemFeature;
			$iArray['Title'] = $this->strTitle;
			$iArray['Data'] = $this->strData;
			$iArray['Priority'] = $this->intPriority;
			$iArray['Seq'] = $this->intSeq;
			$iArray['CurrentStatus'] = $this->intCurrentStatus;
			$iArray['DueDate'] = $this->dttDueDate;
			$iArray['Counter'] = $this->intCounter;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdtasks ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idtasks
     * @property-read QQNode $Date
     * @property-read QQNode $Code
     * @property-read QQNode $ItemFeature
     * @property-read QQNodeItemHasFeatures $ItemFeatureObject
     * @property-read QQNode $Title
     * @property-read QQNode $Data
     * @property-read QQNode $Priority
     * @property-read QQNodePriority $PriorityObject
     * @property-read QQNode $Seq
     * @property-read QQNode $CurrentStatus
     * @property-read QQNodeStatus $CurrentStatusObject
     * @property-read QQNode $DueDate
     * @property-read QQNode $Counter
     *
     *
     * @property-read QQReverseReferenceNodeLog $LogAsTask
     * @property-read QQReverseReferenceNodeNotes $NotesAsTask

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeTasks extends QQNode {
		protected $strTableName = 'tasks';
		protected $strPrimaryKey = 'idtasks';
		protected $strClassName = 'Tasks';
		public function __get($strName) {
			switch ($strName) {
				case 'Idtasks':
					return new QQNode('idtasks', 'Idtasks', 'Integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'VarChar', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'VarChar', $this);
				case 'ItemFeature':
					return new QQNode('Item_feature', 'ItemFeature', 'Integer', $this);
				case 'ItemFeatureObject':
					return new QQNodeItemHasFeatures('Item_feature', 'ItemFeatureObject', 'Integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'VarChar', $this);
				case 'Data':
					return new QQNode('data', 'Data', 'Blob', $this);
				case 'Priority':
					return new QQNode('priority', 'Priority', 'Integer', $this);
				case 'PriorityObject':
					return new QQNodePriority('priority', 'PriorityObject', 'Integer', $this);
				case 'Seq':
					return new QQNode('seq', 'Seq', 'Integer', $this);
				case 'CurrentStatus':
					return new QQNode('current_status', 'CurrentStatus', 'Integer', $this);
				case 'CurrentStatusObject':
					return new QQNodeStatus('current_status', 'CurrentStatusObject', 'Integer', $this);
				case 'DueDate':
					return new QQNode('due_date', 'DueDate', 'DateTime', $this);
				case 'Counter':
					return new QQNode('counter', 'Counter', 'Integer', $this);
				case 'LogAsTask':
					return new QQReverseReferenceNodeLog($this, 'logastask', 'reverse_reference', 'task');
				case 'NotesAsTask':
					return new QQReverseReferenceNodeNotes($this, 'notesastask', 'reverse_reference', 'task');

				case '_PrimaryKeyNode':
					return new QQNode('idtasks', 'Idtasks', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idtasks
     * @property-read QQNode $Date
     * @property-read QQNode $Code
     * @property-read QQNode $ItemFeature
     * @property-read QQNodeItemHasFeatures $ItemFeatureObject
     * @property-read QQNode $Title
     * @property-read QQNode $Data
     * @property-read QQNode $Priority
     * @property-read QQNodePriority $PriorityObject
     * @property-read QQNode $Seq
     * @property-read QQNode $CurrentStatus
     * @property-read QQNodeStatus $CurrentStatusObject
     * @property-read QQNode $DueDate
     * @property-read QQNode $Counter
     *
     *
     * @property-read QQReverseReferenceNodeLog $LogAsTask
     * @property-read QQReverseReferenceNodeNotes $NotesAsTask

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeTasks extends QQReverseReferenceNode {
		protected $strTableName = 'tasks';
		protected $strPrimaryKey = 'idtasks';
		protected $strClassName = 'Tasks';
		public function __get($strName) {
			switch ($strName) {
				case 'Idtasks':
					return new QQNode('idtasks', 'Idtasks', 'integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'string', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'string', $this);
				case 'ItemFeature':
					return new QQNode('Item_feature', 'ItemFeature', 'integer', $this);
				case 'ItemFeatureObject':
					return new QQNodeItemHasFeatures('Item_feature', 'ItemFeatureObject', 'integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'string', $this);
				case 'Data':
					return new QQNode('data', 'Data', 'string', $this);
				case 'Priority':
					return new QQNode('priority', 'Priority', 'integer', $this);
				case 'PriorityObject':
					return new QQNodePriority('priority', 'PriorityObject', 'integer', $this);
				case 'Seq':
					return new QQNode('seq', 'Seq', 'integer', $this);
				case 'CurrentStatus':
					return new QQNode('current_status', 'CurrentStatus', 'integer', $this);
				case 'CurrentStatusObject':
					return new QQNodeStatus('current_status', 'CurrentStatusObject', 'integer', $this);
				case 'DueDate':
					return new QQNode('due_date', 'DueDate', 'QDateTime', $this);
				case 'Counter':
					return new QQNode('counter', 'Counter', 'integer', $this);
				case 'LogAsTask':
					return new QQReverseReferenceNodeLog($this, 'logastask', 'reverse_reference', 'task');
				case 'NotesAsTask':
					return new QQReverseReferenceNodeNotes($this, 'notesastask', 'reverse_reference', 'task');

				case '_PrimaryKeyNode':
					return new QQNode('idtasks', 'Idtasks', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
