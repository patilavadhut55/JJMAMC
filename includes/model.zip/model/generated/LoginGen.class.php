<?php
	/**
	 * The abstract LoginGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Login subclass which
	 * extends this LoginGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Login class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property integer $Idlogin the value for intIdlogin (PK)
	 * @property string $Username the value for strUsername (Unique)
	 * @property string $Password the value for strPassword 
	 * @property boolean $IsEnabled the value for blnIsEnabled (Not Null)
	 * @property Ledger $IdloginObject the value for the Ledger object referenced by intIdlogin (PK)
	 * @property-read AppApproval $_AppApprovalAsDecisionBy the value for the private _objAppApprovalAsDecisionBy (Read-Only) if set due to an expansion on the app_approval.decision_by reverse relationship
	 * @property-read AppApproval[] $_AppApprovalAsDecisionByArray the value for the private _objAppApprovalAsDecisionByArray (Read-Only) if set due to an ExpandAsArray on the app_approval.decision_by reverse relationship
	 * @property-read AppDocs $_AppDocsAsMember the value for the private _objAppDocsAsMember (Read-Only) if set due to an expansion on the app_docs.member reverse relationship
	 * @property-read AppDocs[] $_AppDocsAsMemberArray the value for the private _objAppDocsAsMemberArray (Read-Only) if set due to an ExpandAsArray on the app_docs.member reverse relationship
	 * @property-read Application $_ApplicationAsDataEntryBy the value for the private _objApplicationAsDataEntryBy (Read-Only) if set due to an expansion on the application.data_entry_by reverse relationship
	 * @property-read Application[] $_ApplicationAsDataEntryByArray the value for the private _objApplicationAsDataEntryByArray (Read-Only) if set due to an ExpandAsArray on the application.data_entry_by reverse relationship
	 * @property-read Application $_ApplicationAsCertificateIssueBy the value for the private _objApplicationAsCertificateIssueBy (Read-Only) if set due to an expansion on the application.certificate_issue_by reverse relationship
	 * @property-read Application[] $_ApplicationAsCertificateIssueByArray the value for the private _objApplicationAsCertificateIssueByArray (Read-Only) if set due to an ExpandAsArray on the application.certificate_issue_by reverse relationship
	 * @property-read Application $_ApplicationAsSubstitute the value for the private _objApplicationAsSubstitute (Read-Only) if set due to an expansion on the application.substitute reverse relationship
	 * @property-read Application[] $_ApplicationAsSubstituteArray the value for the private _objApplicationAsSubstituteArray (Read-Only) if set due to an ExpandAsArray on the application.substitute reverse relationship
	 * @property-read AppliedExam $_AppliedExamAsStudent the value for the private _objAppliedExamAsStudent (Read-Only) if set due to an expansion on the applied_exam.student reverse relationship
	 * @property-read AppliedExam[] $_AppliedExamAsStudentArray the value for the private _objAppliedExamAsStudentArray (Read-Only) if set due to an ExpandAsArray on the applied_exam.student reverse relationship
	 * @property-read ApplyGradeImproment $_ApplyGradeImpromentAsStudent the value for the private _objApplyGradeImpromentAsStudent (Read-Only) if set due to an expansion on the apply_grade_improment.student reverse relationship
	 * @property-read ApplyGradeImproment[] $_ApplyGradeImpromentAsStudentArray the value for the private _objApplyGradeImpromentAsStudentArray (Read-Only) if set due to an ExpandAsArray on the apply_grade_improment.student reverse relationship
	 * @property-read ApplyGradeImproment $_ApplyGradeImpromentAsAppliedBy the value for the private _objApplyGradeImpromentAsAppliedBy (Read-Only) if set due to an expansion on the apply_grade_improment.applied_by reverse relationship
	 * @property-read ApplyGradeImproment[] $_ApplyGradeImpromentAsAppliedByArray the value for the private _objApplyGradeImpromentAsAppliedByArray (Read-Only) if set due to an ExpandAsArray on the apply_grade_improment.applied_by reverse relationship
	 * @property-read Attendence $_AttendenceAsStaff the value for the private _objAttendenceAsStaff (Read-Only) if set due to an expansion on the attendence.staff reverse relationship
	 * @property-read Attendence[] $_AttendenceAsStaffArray the value for the private _objAttendenceAsStaffArray (Read-Only) if set due to an ExpandAsArray on the attendence.staff reverse relationship
	 * @property-read CertificateDeposite $_CertificateDepositeAsVerifyBy the value for the private _objCertificateDepositeAsVerifyBy (Read-Only) if set due to an expansion on the certificate_deposite.verify_by reverse relationship
	 * @property-read CertificateDeposite[] $_CertificateDepositeAsVerifyByArray the value for the private _objCertificateDepositeAsVerifyByArray (Read-Only) if set due to an ExpandAsArray on the certificate_deposite.verify_by reverse relationship
	 * @property-read CertificateDeposite $_CertificateDepositeAsReturnBy the value for the private _objCertificateDepositeAsReturnBy (Read-Only) if set due to an expansion on the certificate_deposite.return_by reverse relationship
	 * @property-read CertificateDeposite[] $_CertificateDepositeAsReturnByArray the value for the private _objCertificateDepositeAsReturnByArray (Read-Only) if set due to an ExpandAsArray on the certificate_deposite.return_by reverse relationship
	 * @property-read Circulation $_CirculationAsDataBy the value for the private _objCirculationAsDataBy (Read-Only) if set due to an expansion on the circulation.data_by reverse relationship
	 * @property-read Circulation[] $_CirculationAsDataByArray the value for the private _objCirculationAsDataByArray (Read-Only) if set due to an ExpandAsArray on the circulation.data_by reverse relationship
	 * @property-read Circulation $_CirculationAsStaffStud the value for the private _objCirculationAsStaffStud (Read-Only) if set due to an expansion on the circulation.staff_stud reverse relationship
	 * @property-read Circulation[] $_CirculationAsStaffStudArray the value for the private _objCirculationAsStaffStudArray (Read-Only) if set due to an ExpandAsArray on the circulation.staff_stud reverse relationship
	 * @property-read CurrentStatus $_CurrentStatusAsStudent the value for the private _objCurrentStatusAsStudent (Read-Only) if set due to an expansion on the current_status.student reverse relationship
	 * @property-read CurrentStatus[] $_CurrentStatusAsStudentArray the value for the private _objCurrentStatusAsStudentArray (Read-Only) if set due to an ExpandAsArray on the current_status.student reverse relationship
	 * @property-read DeptYearEvents $_DeptYearEventsAsIntiator the value for the private _objDeptYearEventsAsIntiator (Read-Only) if set due to an expansion on the dept_year_events.intiator reverse relationship
	 * @property-read DeptYearEvents[] $_DeptYearEventsAsIntiatorArray the value for the private _objDeptYearEventsAsIntiatorArray (Read-Only) if set due to an ExpandAsArray on the dept_year_events.intiator reverse relationship
	 * @property-read DeptYearEvents $_DeptYearEventsAsOwner the value for the private _objDeptYearEventsAsOwner (Read-Only) if set due to an expansion on the dept_year_events.owner reverse relationship
	 * @property-read DeptYearEvents[] $_DeptYearEventsAsOwnerArray the value for the private _objDeptYearEventsAsOwnerArray (Read-Only) if set due to an ExpandAsArray on the dept_year_events.owner reverse relationship
	 * @property-read DocInOut $_DocInOutAsInwordBy the value for the private _objDocInOutAsInwordBy (Read-Only) if set due to an expansion on the doc_in_out.inword_by reverse relationship
	 * @property-read DocInOut[] $_DocInOutAsInwordByArray the value for the private _objDocInOutAsInwordByArray (Read-Only) if set due to an ExpandAsArray on the doc_in_out.inword_by reverse relationship
	 * @property-read ECourse $_ECourseAsTeacher the value for the private _objECourseAsTeacher (Read-Only) if set due to an expansion on the e_course.teacher_id reverse relationship
	 * @property-read ECourse[] $_ECourseAsTeacherArray the value for the private _objECourseAsTeacherArray (Read-Only) if set due to an ExpandAsArray on the e_course.teacher_id reverse relationship
	 * @property-read EStudent $_EStudentAsStudent the value for the private _objEStudentAsStudent (Read-Only) if set due to an expansion on the e_student.student reverse relationship
	 * @property-read EStudent[] $_EStudentAsStudentArray the value for the private _objEStudentAsStudentArray (Read-Only) if set due to an ExpandAsArray on the e_student.student reverse relationship
	 * @property-read ETicket $_ETicketAsRaisedBy the value for the private _objETicketAsRaisedBy (Read-Only) if set due to an expansion on the e_ticket.raised_by reverse relationship
	 * @property-read ETicket[] $_ETicketAsRaisedByArray the value for the private _objETicketAsRaisedByArray (Read-Only) if set due to an ExpandAsArray on the e_ticket.raised_by reverse relationship
	 * @property-read Establishment $_Establishment the value for the private _objEstablishment (Read-Only) if set due to an expansion on the establishment.login reverse relationship
	 * @property-read Establishment[] $_EstablishmentArray the value for the private _objEstablishmentArray (Read-Only) if set due to an ExpandAsArray on the establishment.login reverse relationship
	 * @property-read EventHasAttendent $_EventHasAttendentAsAttendent the value for the private _objEventHasAttendentAsAttendent (Read-Only) if set due to an expansion on the event_has_attendent.attendent reverse relationship
	 * @property-read EventHasAttendent[] $_EventHasAttendentAsAttendentArray the value for the private _objEventHasAttendentAsAttendentArray (Read-Only) if set due to an ExpandAsArray on the event_has_attendent.attendent reverse relationship
	 * @property-read Exampaper $_ExampaperAsSetBy the value for the private _objExampaperAsSetBy (Read-Only) if set due to an expansion on the exampaper.set_by reverse relationship
	 * @property-read Exampaper[] $_ExampaperAsSetByArray the value for the private _objExampaperAsSetByArray (Read-Only) if set due to an ExpandAsArray on the exampaper.set_by reverse relationship
	 * @property-read ForwardTo $_ForwardToAsForWhome the value for the private _objForwardToAsForWhome (Read-Only) if set due to an expansion on the forward_to.for_whome reverse relationship
	 * @property-read ForwardTo[] $_ForwardToAsForWhomeArray the value for the private _objForwardToAsForWhomeArray (Read-Only) if set due to an ExpandAsArray on the forward_to.for_whome reverse relationship
	 * @property-read ForwardTo $_ForwardToAsForwardedTo the value for the private _objForwardToAsForwardedTo (Read-Only) if set due to an expansion on the forward_to.forwarded_to reverse relationship
	 * @property-read ForwardTo[] $_ForwardToAsForwardedToArray the value for the private _objForwardToAsForwardedToArray (Read-Only) if set due to an ExpandAsArray on the forward_to.forwarded_to reverse relationship
	 * @property-read GradeCard $_GradeCardAsStudent the value for the private _objGradeCardAsStudent (Read-Only) if set due to an expansion on the grade_card.student reverse relationship
	 * @property-read GradeCard[] $_GradeCardAsStudentArray the value for the private _objGradeCardAsStudentArray (Read-Only) if set due to an ExpandAsArray on the grade_card.student reverse relationship
	 * @property-read GradeCard $_GradeCardAsChangeInEseBy the value for the private _objGradeCardAsChangeInEseBy (Read-Only) if set due to an expansion on the grade_card.change_in_ese_by reverse relationship
	 * @property-read GradeCard[] $_GradeCardAsChangeInEseByArray the value for the private _objGradeCardAsChangeInEseByArray (Read-Only) if set due to an ExpandAsArray on the grade_card.change_in_ese_by reverse relationship
	 * @property-read IssuedItems $_IssuedItemsAsMember the value for the private _objIssuedItemsAsMember (Read-Only) if set due to an expansion on the issued_items.member reverse relationship
	 * @property-read IssuedItems[] $_IssuedItemsAsMemberArray the value for the private _objIssuedItemsAsMemberArray (Read-Only) if set due to an ExpandAsArray on the issued_items.member reverse relationship
	 * @property-read Iwow $_IwowAsDataBy the value for the private _objIwowAsDataBy (Read-Only) if set due to an expansion on the iwow.data_by reverse relationship
	 * @property-read Iwow[] $_IwowAsDataByArray the value for the private _objIwowAsDataByArray (Read-Only) if set due to an ExpandAsArray on the iwow.data_by reverse relationship
	 * @property-read Iwow $_IwowAsInspectedBy the value for the private _objIwowAsInspectedBy (Read-Only) if set due to an expansion on the iwow.inspected_by reverse relationship
	 * @property-read Iwow[] $_IwowAsInspectedByArray the value for the private _objIwowAsInspectedByArray (Read-Only) if set due to an ExpandAsArray on the iwow.inspected_by reverse relationship
	 * @property-read LeaveBalance $_LeaveBalanceAsMember the value for the private _objLeaveBalanceAsMember (Read-Only) if set due to an expansion on the leave_balance.member reverse relationship
	 * @property-read LeaveBalance[] $_LeaveBalanceAsMemberArray the value for the private _objLeaveBalanceAsMemberArray (Read-Only) if set due to an ExpandAsArray on the leave_balance.member reverse relationship
	 * @property-read Log $_LogAsDataBy the value for the private _objLogAsDataBy (Read-Only) if set due to an expansion on the log.data_by reverse relationship
	 * @property-read Log[] $_LogAsDataByArray the value for the private _objLogAsDataByArray (Read-Only) if set due to an ExpandAsArray on the log.data_by reverse relationship
	 * @property-read LoginHasRole $_LoginHasRoleAsId the value for the private _objLoginHasRoleAsId (Read-Only) if set due to an expansion on the login_has_role.login_idlogin reverse relationship
	 * @property-read LoginHasRole[] $_LoginHasRoleAsIdArray the value for the private _objLoginHasRoleAsIdArray (Read-Only) if set due to an ExpandAsArray on the login_has_role.login_idlogin reverse relationship
	 * @property-read MarkTo $_MarkToAsTo the value for the private _objMarkToAsTo (Read-Only) if set due to an expansion on the mark_to.to reverse relationship
	 * @property-read MarkTo[] $_MarkToAsToArray the value for the private _objMarkToAsToArray (Read-Only) if set due to an ExpandAsArray on the mark_to.to reverse relationship
	 * @property-read MarkTo $_MarkToAsFrom the value for the private _objMarkToAsFrom (Read-Only) if set due to an expansion on the mark_to.from reverse relationship
	 * @property-read MarkTo[] $_MarkToAsFromArray the value for the private _objMarkToAsFromArray (Read-Only) if set due to an ExpandAsArray on the mark_to.from reverse relationship
	 * @property-read MeetingAgendaPole $_MeetingAgendaPoleAsAttendees the value for the private _objMeetingAgendaPoleAsAttendees (Read-Only) if set due to an expansion on the meeting_agenda_pole.attendees reverse relationship
	 * @property-read MeetingAgendaPole[] $_MeetingAgendaPoleAsAttendeesArray the value for the private _objMeetingAgendaPoleAsAttendeesArray (Read-Only) if set due to an ExpandAsArray on the meeting_agenda_pole.attendees reverse relationship
	 * @property-read MeetingGroupHasMembers $_MeetingGroupHasMembersAsMember the value for the private _objMeetingGroupHasMembersAsMember (Read-Only) if set due to an expansion on the meeting_group_has_members.member reverse relationship
	 * @property-read MeetingGroupHasMembers[] $_MeetingGroupHasMembersAsMemberArray the value for the private _objMeetingGroupHasMembersAsMemberArray (Read-Only) if set due to an ExpandAsArray on the meeting_group_has_members.member reverse relationship
	 * @property-read MeetingNotes $_MeetingNotesAsReferedBy the value for the private _objMeetingNotesAsReferedBy (Read-Only) if set due to an expansion on the meeting_notes.refered_by reverse relationship
	 * @property-read MeetingNotes[] $_MeetingNotesAsReferedByArray the value for the private _objMeetingNotesAsReferedByArray (Read-Only) if set due to an ExpandAsArray on the meeting_notes.refered_by reverse relationship
	 * @property-read MeetingNotes $_MeetingNotesAsActionOn the value for the private _objMeetingNotesAsActionOn (Read-Only) if set due to an expansion on the meeting_notes.action_on reverse relationship
	 * @property-read MeetingNotes[] $_MeetingNotesAsActionOnArray the value for the private _objMeetingNotesAsActionOnArray (Read-Only) if set due to an ExpandAsArray on the meeting_notes.action_on reverse relationship
	 * @property-read Note $_NoteAsDataby the value for the private _objNoteAsDataby (Read-Only) if set due to an expansion on the note.databy reverse relationship
	 * @property-read Note[] $_NoteAsDatabyArray the value for the private _objNoteAsDatabyArray (Read-Only) if set due to an ExpandAsArray on the note.databy reverse relationship
	 * @property-read ReEvaluation $_ReEvaluationAsStudent the value for the private _objReEvaluationAsStudent (Read-Only) if set due to an expansion on the re_evaluation.student reverse relationship
	 * @property-read ReEvaluation[] $_ReEvaluationAsStudentArray the value for the private _objReEvaluationAsStudentArray (Read-Only) if set due to an ExpandAsArray on the re_evaluation.student reverse relationship
	 * @property-read SalarysheetApproval $_SalarysheetApprovalAsApprovedBy the value for the private _objSalarysheetApprovalAsApprovedBy (Read-Only) if set due to an expansion on the salarysheet_approval.approved_by reverse relationship
	 * @property-read SalarysheetApproval[] $_SalarysheetApprovalAsApprovedByArray the value for the private _objSalarysheetApprovalAsApprovedByArray (Read-Only) if set due to an ExpandAsArray on the salarysheet_approval.approved_by reverse relationship
	 * @property-read SignPatch $_SignPatch the value for the private _objSignPatch (Read-Only) if set due to an expansion on the sign_patch.login reverse relationship
	 * @property-read SignPatch[] $_SignPatchArray the value for the private _objSignPatchArray (Read-Only) if set due to an ExpandAsArray on the sign_patch.login reverse relationship
	 * @property-read StudAttendence $_StudAttendenceAsStudent the value for the private _objStudAttendenceAsStudent (Read-Only) if set due to an expansion on the stud_attendence.student reverse relationship
	 * @property-read StudAttendence[] $_StudAttendenceAsStudentArray the value for the private _objStudAttendenceAsStudentArray (Read-Only) if set due to an ExpandAsArray on the stud_attendence.student reverse relationship
	 * @property-read StudAttendence $_StudAttendenceAsStaff the value for the private _objStudAttendenceAsStaff (Read-Only) if set due to an expansion on the stud_attendence.staff reverse relationship
	 * @property-read StudAttendence[] $_StudAttendenceAsStaffArray the value for the private _objStudAttendenceAsStaffArray (Read-Only) if set due to an ExpandAsArray on the stud_attendence.staff reverse relationship
	 * @property-read SubjectTought $_SubjectTought the value for the private _objSubjectTought (Read-Only) if set due to an expansion on the subject_tought.login reverse relationship
	 * @property-read SubjectTought[] $_SubjectToughtArray the value for the private _objSubjectToughtArray (Read-Only) if set due to an ExpandAsArray on the subject_tought.login reverse relationship
	 * @property-read Timetable $_TimetableAsAttendant the value for the private _objTimetableAsAttendant (Read-Only) if set due to an expansion on the timetable.attendant reverse relationship
	 * @property-read Timetable[] $_TimetableAsAttendantArray the value for the private _objTimetableAsAttendantArray (Read-Only) if set due to an ExpandAsArray on the timetable.attendant reverse relationship
	 * @property-read VisitorPass $_VisitorPassAsForWhome the value for the private _objVisitorPassAsForWhome (Read-Only) if set due to an expansion on the visitor_pass.for_whome reverse relationship
	 * @property-read VisitorPass[] $_VisitorPassAsForWhomeArray the value for the private _objVisitorPassAsForWhomeArray (Read-Only) if set due to an ExpandAsArray on the visitor_pass.for_whome reverse relationship
	 * @property-read Voucher $_VoucherAsApprovedBy the value for the private _objVoucherAsApprovedBy (Read-Only) if set due to an expansion on the voucher.approved_by reverse relationship
	 * @property-read Voucher[] $_VoucherAsApprovedByArray the value for the private _objVoucherAsApprovedByArray (Read-Only) if set due to an ExpandAsArray on the voucher.approved_by reverse relationship
	 * @property-read Voucher $_VoucherAsCancelBy the value for the private _objVoucherAsCancelBy (Read-Only) if set due to an expansion on the voucher.cancel_by reverse relationship
	 * @property-read Voucher[] $_VoucherAsCancelByArray the value for the private _objVoucherAsCancelByArray (Read-Only) if set due to an ExpandAsArray on the voucher.cancel_by reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class LoginGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK column login.idlogin
		 * @var integer intIdlogin
		 */
		protected $intIdlogin;
		const IdloginDefault = null;


		/**
		 * Protected internal member variable that stores the original version of the PK column value (if restored)
		 * Used by Save() to update a PK column during UPDATE
		 * @var integer __intIdlogin;
		 */
		protected $__intIdlogin;

		/**
		 * Protected member variable that maps to the database column login.username
		 * @var string strUsername
		 */
		protected $strUsername;
		const UsernameMaxLength = 20;
		const UsernameDefault = null;


		/**
		 * Protected member variable that maps to the database column login.password
		 * @var string strPassword
		 */
		protected $strPassword;
		const PasswordMaxLength = 20;
		const PasswordDefault = null;


		/**
		 * Protected member variable that maps to the database column login.is_enabled
		 * @var boolean blnIsEnabled
		 */
		protected $blnIsEnabled;
		const IsEnabledDefault = null;


		/**
		 * Private member variable that stores a reference to a single AppApprovalAsDecisionBy object
		 * (of type AppApproval), if this Login object was restored with
		 * an expansion on the app_approval association table.
		 * @var AppApproval _objAppApprovalAsDecisionBy;
		 */
		private $_objAppApprovalAsDecisionBy;

		/**
		 * Private member variable that stores a reference to an array of AppApprovalAsDecisionBy objects
		 * (of type AppApproval[]), if this Login object was restored with
		 * an ExpandAsArray on the app_approval association table.
		 * @var AppApproval[] _objAppApprovalAsDecisionByArray;
		 */
		private $_objAppApprovalAsDecisionByArray = null;

		/**
		 * Private member variable that stores a reference to a single AppDocsAsMember object
		 * (of type AppDocs), if this Login object was restored with
		 * an expansion on the app_docs association table.
		 * @var AppDocs _objAppDocsAsMember;
		 */
		private $_objAppDocsAsMember;

		/**
		 * Private member variable that stores a reference to an array of AppDocsAsMember objects
		 * (of type AppDocs[]), if this Login object was restored with
		 * an ExpandAsArray on the app_docs association table.
		 * @var AppDocs[] _objAppDocsAsMemberArray;
		 */
		private $_objAppDocsAsMemberArray = null;

		/**
		 * Private member variable that stores a reference to a single ApplicationAsDataEntryBy object
		 * (of type Application), if this Login object was restored with
		 * an expansion on the application association table.
		 * @var Application _objApplicationAsDataEntryBy;
		 */
		private $_objApplicationAsDataEntryBy;

		/**
		 * Private member variable that stores a reference to an array of ApplicationAsDataEntryBy objects
		 * (of type Application[]), if this Login object was restored with
		 * an ExpandAsArray on the application association table.
		 * @var Application[] _objApplicationAsDataEntryByArray;
		 */
		private $_objApplicationAsDataEntryByArray = null;

		/**
		 * Private member variable that stores a reference to a single ApplicationAsCertificateIssueBy object
		 * (of type Application), if this Login object was restored with
		 * an expansion on the application association table.
		 * @var Application _objApplicationAsCertificateIssueBy;
		 */
		private $_objApplicationAsCertificateIssueBy;

		/**
		 * Private member variable that stores a reference to an array of ApplicationAsCertificateIssueBy objects
		 * (of type Application[]), if this Login object was restored with
		 * an ExpandAsArray on the application association table.
		 * @var Application[] _objApplicationAsCertificateIssueByArray;
		 */
		private $_objApplicationAsCertificateIssueByArray = null;

		/**
		 * Private member variable that stores a reference to a single ApplicationAsSubstitute object
		 * (of type Application), if this Login object was restored with
		 * an expansion on the application association table.
		 * @var Application _objApplicationAsSubstitute;
		 */
		private $_objApplicationAsSubstitute;

		/**
		 * Private member variable that stores a reference to an array of ApplicationAsSubstitute objects
		 * (of type Application[]), if this Login object was restored with
		 * an ExpandAsArray on the application association table.
		 * @var Application[] _objApplicationAsSubstituteArray;
		 */
		private $_objApplicationAsSubstituteArray = null;

		/**
		 * Private member variable that stores a reference to a single AppliedExamAsStudent object
		 * (of type AppliedExam), if this Login object was restored with
		 * an expansion on the applied_exam association table.
		 * @var AppliedExam _objAppliedExamAsStudent;
		 */
		private $_objAppliedExamAsStudent;

		/**
		 * Private member variable that stores a reference to an array of AppliedExamAsStudent objects
		 * (of type AppliedExam[]), if this Login object was restored with
		 * an ExpandAsArray on the applied_exam association table.
		 * @var AppliedExam[] _objAppliedExamAsStudentArray;
		 */
		private $_objAppliedExamAsStudentArray = null;

		/**
		 * Private member variable that stores a reference to a single ApplyGradeImpromentAsStudent object
		 * (of type ApplyGradeImproment), if this Login object was restored with
		 * an expansion on the apply_grade_improment association table.
		 * @var ApplyGradeImproment _objApplyGradeImpromentAsStudent;
		 */
		private $_objApplyGradeImpromentAsStudent;

		/**
		 * Private member variable that stores a reference to an array of ApplyGradeImpromentAsStudent objects
		 * (of type ApplyGradeImproment[]), if this Login object was restored with
		 * an ExpandAsArray on the apply_grade_improment association table.
		 * @var ApplyGradeImproment[] _objApplyGradeImpromentAsStudentArray;
		 */
		private $_objApplyGradeImpromentAsStudentArray = null;

		/**
		 * Private member variable that stores a reference to a single ApplyGradeImpromentAsAppliedBy object
		 * (of type ApplyGradeImproment), if this Login object was restored with
		 * an expansion on the apply_grade_improment association table.
		 * @var ApplyGradeImproment _objApplyGradeImpromentAsAppliedBy;
		 */
		private $_objApplyGradeImpromentAsAppliedBy;

		/**
		 * Private member variable that stores a reference to an array of ApplyGradeImpromentAsAppliedBy objects
		 * (of type ApplyGradeImproment[]), if this Login object was restored with
		 * an ExpandAsArray on the apply_grade_improment association table.
		 * @var ApplyGradeImproment[] _objApplyGradeImpromentAsAppliedByArray;
		 */
		private $_objApplyGradeImpromentAsAppliedByArray = null;

		/**
		 * Private member variable that stores a reference to a single AttendenceAsStaff object
		 * (of type Attendence), if this Login object was restored with
		 * an expansion on the attendence association table.
		 * @var Attendence _objAttendenceAsStaff;
		 */
		private $_objAttendenceAsStaff;

		/**
		 * Private member variable that stores a reference to an array of AttendenceAsStaff objects
		 * (of type Attendence[]), if this Login object was restored with
		 * an ExpandAsArray on the attendence association table.
		 * @var Attendence[] _objAttendenceAsStaffArray;
		 */
		private $_objAttendenceAsStaffArray = null;

		/**
		 * Private member variable that stores a reference to a single CertificateDepositeAsVerifyBy object
		 * (of type CertificateDeposite), if this Login object was restored with
		 * an expansion on the certificate_deposite association table.
		 * @var CertificateDeposite _objCertificateDepositeAsVerifyBy;
		 */
		private $_objCertificateDepositeAsVerifyBy;

		/**
		 * Private member variable that stores a reference to an array of CertificateDepositeAsVerifyBy objects
		 * (of type CertificateDeposite[]), if this Login object was restored with
		 * an ExpandAsArray on the certificate_deposite association table.
		 * @var CertificateDeposite[] _objCertificateDepositeAsVerifyByArray;
		 */
		private $_objCertificateDepositeAsVerifyByArray = null;

		/**
		 * Private member variable that stores a reference to a single CertificateDepositeAsReturnBy object
		 * (of type CertificateDeposite), if this Login object was restored with
		 * an expansion on the certificate_deposite association table.
		 * @var CertificateDeposite _objCertificateDepositeAsReturnBy;
		 */
		private $_objCertificateDepositeAsReturnBy;

		/**
		 * Private member variable that stores a reference to an array of CertificateDepositeAsReturnBy objects
		 * (of type CertificateDeposite[]), if this Login object was restored with
		 * an ExpandAsArray on the certificate_deposite association table.
		 * @var CertificateDeposite[] _objCertificateDepositeAsReturnByArray;
		 */
		private $_objCertificateDepositeAsReturnByArray = null;

		/**
		 * Private member variable that stores a reference to a single CirculationAsDataBy object
		 * (of type Circulation), if this Login object was restored with
		 * an expansion on the circulation association table.
		 * @var Circulation _objCirculationAsDataBy;
		 */
		private $_objCirculationAsDataBy;

		/**
		 * Private member variable that stores a reference to an array of CirculationAsDataBy objects
		 * (of type Circulation[]), if this Login object was restored with
		 * an ExpandAsArray on the circulation association table.
		 * @var Circulation[] _objCirculationAsDataByArray;
		 */
		private $_objCirculationAsDataByArray = null;

		/**
		 * Private member variable that stores a reference to a single CirculationAsStaffStud object
		 * (of type Circulation), if this Login object was restored with
		 * an expansion on the circulation association table.
		 * @var Circulation _objCirculationAsStaffStud;
		 */
		private $_objCirculationAsStaffStud;

		/**
		 * Private member variable that stores a reference to an array of CirculationAsStaffStud objects
		 * (of type Circulation[]), if this Login object was restored with
		 * an ExpandAsArray on the circulation association table.
		 * @var Circulation[] _objCirculationAsStaffStudArray;
		 */
		private $_objCirculationAsStaffStudArray = null;

		/**
		 * Private member variable that stores a reference to a single CurrentStatusAsStudent object
		 * (of type CurrentStatus), if this Login object was restored with
		 * an expansion on the current_status association table.
		 * @var CurrentStatus _objCurrentStatusAsStudent;
		 */
		private $_objCurrentStatusAsStudent;

		/**
		 * Private member variable that stores a reference to an array of CurrentStatusAsStudent objects
		 * (of type CurrentStatus[]), if this Login object was restored with
		 * an ExpandAsArray on the current_status association table.
		 * @var CurrentStatus[] _objCurrentStatusAsStudentArray;
		 */
		private $_objCurrentStatusAsStudentArray = null;

		/**
		 * Private member variable that stores a reference to a single DeptYearEventsAsIntiator object
		 * (of type DeptYearEvents), if this Login object was restored with
		 * an expansion on the dept_year_events association table.
		 * @var DeptYearEvents _objDeptYearEventsAsIntiator;
		 */
		private $_objDeptYearEventsAsIntiator;

		/**
		 * Private member variable that stores a reference to an array of DeptYearEventsAsIntiator objects
		 * (of type DeptYearEvents[]), if this Login object was restored with
		 * an ExpandAsArray on the dept_year_events association table.
		 * @var DeptYearEvents[] _objDeptYearEventsAsIntiatorArray;
		 */
		private $_objDeptYearEventsAsIntiatorArray = null;

		/**
		 * Private member variable that stores a reference to a single DeptYearEventsAsOwner object
		 * (of type DeptYearEvents), if this Login object was restored with
		 * an expansion on the dept_year_events association table.
		 * @var DeptYearEvents _objDeptYearEventsAsOwner;
		 */
		private $_objDeptYearEventsAsOwner;

		/**
		 * Private member variable that stores a reference to an array of DeptYearEventsAsOwner objects
		 * (of type DeptYearEvents[]), if this Login object was restored with
		 * an ExpandAsArray on the dept_year_events association table.
		 * @var DeptYearEvents[] _objDeptYearEventsAsOwnerArray;
		 */
		private $_objDeptYearEventsAsOwnerArray = null;

		/**
		 * Private member variable that stores a reference to a single DocInOutAsInwordBy object
		 * (of type DocInOut), if this Login object was restored with
		 * an expansion on the doc_in_out association table.
		 * @var DocInOut _objDocInOutAsInwordBy;
		 */
		private $_objDocInOutAsInwordBy;

		/**
		 * Private member variable that stores a reference to an array of DocInOutAsInwordBy objects
		 * (of type DocInOut[]), if this Login object was restored with
		 * an ExpandAsArray on the doc_in_out association table.
		 * @var DocInOut[] _objDocInOutAsInwordByArray;
		 */
		private $_objDocInOutAsInwordByArray = null;

		/**
		 * Private member variable that stores a reference to a single ECourseAsTeacher object
		 * (of type ECourse), if this Login object was restored with
		 * an expansion on the e_course association table.
		 * @var ECourse _objECourseAsTeacher;
		 */
		private $_objECourseAsTeacher;

		/**
		 * Private member variable that stores a reference to an array of ECourseAsTeacher objects
		 * (of type ECourse[]), if this Login object was restored with
		 * an ExpandAsArray on the e_course association table.
		 * @var ECourse[] _objECourseAsTeacherArray;
		 */
		private $_objECourseAsTeacherArray = null;

		/**
		 * Private member variable that stores a reference to a single EStudentAsStudent object
		 * (of type EStudent), if this Login object was restored with
		 * an expansion on the e_student association table.
		 * @var EStudent _objEStudentAsStudent;
		 */
		private $_objEStudentAsStudent;

		/**
		 * Private member variable that stores a reference to an array of EStudentAsStudent objects
		 * (of type EStudent[]), if this Login object was restored with
		 * an ExpandAsArray on the e_student association table.
		 * @var EStudent[] _objEStudentAsStudentArray;
		 */
		private $_objEStudentAsStudentArray = null;

		/**
		 * Private member variable that stores a reference to a single ETicketAsRaisedBy object
		 * (of type ETicket), if this Login object was restored with
		 * an expansion on the e_ticket association table.
		 * @var ETicket _objETicketAsRaisedBy;
		 */
		private $_objETicketAsRaisedBy;

		/**
		 * Private member variable that stores a reference to an array of ETicketAsRaisedBy objects
		 * (of type ETicket[]), if this Login object was restored with
		 * an ExpandAsArray on the e_ticket association table.
		 * @var ETicket[] _objETicketAsRaisedByArray;
		 */
		private $_objETicketAsRaisedByArray = null;

		/**
		 * Private member variable that stores a reference to a single Establishment object
		 * (of type Establishment), if this Login object was restored with
		 * an expansion on the establishment association table.
		 * @var Establishment _objEstablishment;
		 */
		private $_objEstablishment;

		/**
		 * Private member variable that stores a reference to an array of Establishment objects
		 * (of type Establishment[]), if this Login object was restored with
		 * an ExpandAsArray on the establishment association table.
		 * @var Establishment[] _objEstablishmentArray;
		 */
		private $_objEstablishmentArray = null;

		/**
		 * Private member variable that stores a reference to a single EventHasAttendentAsAttendent object
		 * (of type EventHasAttendent), if this Login object was restored with
		 * an expansion on the event_has_attendent association table.
		 * @var EventHasAttendent _objEventHasAttendentAsAttendent;
		 */
		private $_objEventHasAttendentAsAttendent;

		/**
		 * Private member variable that stores a reference to an array of EventHasAttendentAsAttendent objects
		 * (of type EventHasAttendent[]), if this Login object was restored with
		 * an ExpandAsArray on the event_has_attendent association table.
		 * @var EventHasAttendent[] _objEventHasAttendentAsAttendentArray;
		 */
		private $_objEventHasAttendentAsAttendentArray = null;

		/**
		 * Private member variable that stores a reference to a single ExampaperAsSetBy object
		 * (of type Exampaper), if this Login object was restored with
		 * an expansion on the exampaper association table.
		 * @var Exampaper _objExampaperAsSetBy;
		 */
		private $_objExampaperAsSetBy;

		/**
		 * Private member variable that stores a reference to an array of ExampaperAsSetBy objects
		 * (of type Exampaper[]), if this Login object was restored with
		 * an ExpandAsArray on the exampaper association table.
		 * @var Exampaper[] _objExampaperAsSetByArray;
		 */
		private $_objExampaperAsSetByArray = null;

		/**
		 * Private member variable that stores a reference to a single ForwardToAsForWhome object
		 * (of type ForwardTo), if this Login object was restored with
		 * an expansion on the forward_to association table.
		 * @var ForwardTo _objForwardToAsForWhome;
		 */
		private $_objForwardToAsForWhome;

		/**
		 * Private member variable that stores a reference to an array of ForwardToAsForWhome objects
		 * (of type ForwardTo[]), if this Login object was restored with
		 * an ExpandAsArray on the forward_to association table.
		 * @var ForwardTo[] _objForwardToAsForWhomeArray;
		 */
		private $_objForwardToAsForWhomeArray = null;

		/**
		 * Private member variable that stores a reference to a single ForwardToAsForwardedTo object
		 * (of type ForwardTo), if this Login object was restored with
		 * an expansion on the forward_to association table.
		 * @var ForwardTo _objForwardToAsForwardedTo;
		 */
		private $_objForwardToAsForwardedTo;

		/**
		 * Private member variable that stores a reference to an array of ForwardToAsForwardedTo objects
		 * (of type ForwardTo[]), if this Login object was restored with
		 * an ExpandAsArray on the forward_to association table.
		 * @var ForwardTo[] _objForwardToAsForwardedToArray;
		 */
		private $_objForwardToAsForwardedToArray = null;

		/**
		 * Private member variable that stores a reference to a single GradeCardAsStudent object
		 * (of type GradeCard), if this Login object was restored with
		 * an expansion on the grade_card association table.
		 * @var GradeCard _objGradeCardAsStudent;
		 */
		private $_objGradeCardAsStudent;

		/**
		 * Private member variable that stores a reference to an array of GradeCardAsStudent objects
		 * (of type GradeCard[]), if this Login object was restored with
		 * an ExpandAsArray on the grade_card association table.
		 * @var GradeCard[] _objGradeCardAsStudentArray;
		 */
		private $_objGradeCardAsStudentArray = null;

		/**
		 * Private member variable that stores a reference to a single GradeCardAsChangeInEseBy object
		 * (of type GradeCard), if this Login object was restored with
		 * an expansion on the grade_card association table.
		 * @var GradeCard _objGradeCardAsChangeInEseBy;
		 */
		private $_objGradeCardAsChangeInEseBy;

		/**
		 * Private member variable that stores a reference to an array of GradeCardAsChangeInEseBy objects
		 * (of type GradeCard[]), if this Login object was restored with
		 * an ExpandAsArray on the grade_card association table.
		 * @var GradeCard[] _objGradeCardAsChangeInEseByArray;
		 */
		private $_objGradeCardAsChangeInEseByArray = null;

		/**
		 * Private member variable that stores a reference to a single IssuedItemsAsMember object
		 * (of type IssuedItems), if this Login object was restored with
		 * an expansion on the issued_items association table.
		 * @var IssuedItems _objIssuedItemsAsMember;
		 */
		private $_objIssuedItemsAsMember;

		/**
		 * Private member variable that stores a reference to an array of IssuedItemsAsMember objects
		 * (of type IssuedItems[]), if this Login object was restored with
		 * an ExpandAsArray on the issued_items association table.
		 * @var IssuedItems[] _objIssuedItemsAsMemberArray;
		 */
		private $_objIssuedItemsAsMemberArray = null;

		/**
		 * Private member variable that stores a reference to a single IwowAsDataBy object
		 * (of type Iwow), if this Login object was restored with
		 * an expansion on the iwow association table.
		 * @var Iwow _objIwowAsDataBy;
		 */
		private $_objIwowAsDataBy;

		/**
		 * Private member variable that stores a reference to an array of IwowAsDataBy objects
		 * (of type Iwow[]), if this Login object was restored with
		 * an ExpandAsArray on the iwow association table.
		 * @var Iwow[] _objIwowAsDataByArray;
		 */
		private $_objIwowAsDataByArray = null;

		/**
		 * Private member variable that stores a reference to a single IwowAsInspectedBy object
		 * (of type Iwow), if this Login object was restored with
		 * an expansion on the iwow association table.
		 * @var Iwow _objIwowAsInspectedBy;
		 */
		private $_objIwowAsInspectedBy;

		/**
		 * Private member variable that stores a reference to an array of IwowAsInspectedBy objects
		 * (of type Iwow[]), if this Login object was restored with
		 * an ExpandAsArray on the iwow association table.
		 * @var Iwow[] _objIwowAsInspectedByArray;
		 */
		private $_objIwowAsInspectedByArray = null;

		/**
		 * Private member variable that stores a reference to a single LeaveBalanceAsMember object
		 * (of type LeaveBalance), if this Login object was restored with
		 * an expansion on the leave_balance association table.
		 * @var LeaveBalance _objLeaveBalanceAsMember;
		 */
		private $_objLeaveBalanceAsMember;

		/**
		 * Private member variable that stores a reference to an array of LeaveBalanceAsMember objects
		 * (of type LeaveBalance[]), if this Login object was restored with
		 * an ExpandAsArray on the leave_balance association table.
		 * @var LeaveBalance[] _objLeaveBalanceAsMemberArray;
		 */
		private $_objLeaveBalanceAsMemberArray = null;

		/**
		 * Private member variable that stores a reference to a single LogAsDataBy object
		 * (of type Log), if this Login object was restored with
		 * an expansion on the log association table.
		 * @var Log _objLogAsDataBy;
		 */
		private $_objLogAsDataBy;

		/**
		 * Private member variable that stores a reference to an array of LogAsDataBy objects
		 * (of type Log[]), if this Login object was restored with
		 * an ExpandAsArray on the log association table.
		 * @var Log[] _objLogAsDataByArray;
		 */
		private $_objLogAsDataByArray = null;

		/**
		 * Private member variable that stores a reference to a single LoginHasRoleAsId object
		 * (of type LoginHasRole), if this Login object was restored with
		 * an expansion on the login_has_role association table.
		 * @var LoginHasRole _objLoginHasRoleAsId;
		 */
		private $_objLoginHasRoleAsId;

		/**
		 * Private member variable that stores a reference to an array of LoginHasRoleAsId objects
		 * (of type LoginHasRole[]), if this Login object was restored with
		 * an ExpandAsArray on the login_has_role association table.
		 * @var LoginHasRole[] _objLoginHasRoleAsIdArray;
		 */
		private $_objLoginHasRoleAsIdArray = null;

		/**
		 * Private member variable that stores a reference to a single MarkToAsTo object
		 * (of type MarkTo), if this Login object was restored with
		 * an expansion on the mark_to association table.
		 * @var MarkTo _objMarkToAsTo;
		 */
		private $_objMarkToAsTo;

		/**
		 * Private member variable that stores a reference to an array of MarkToAsTo objects
		 * (of type MarkTo[]), if this Login object was restored with
		 * an ExpandAsArray on the mark_to association table.
		 * @var MarkTo[] _objMarkToAsToArray;
		 */
		private $_objMarkToAsToArray = null;

		/**
		 * Private member variable that stores a reference to a single MarkToAsFrom object
		 * (of type MarkTo), if this Login object was restored with
		 * an expansion on the mark_to association table.
		 * @var MarkTo _objMarkToAsFrom;
		 */
		private $_objMarkToAsFrom;

		/**
		 * Private member variable that stores a reference to an array of MarkToAsFrom objects
		 * (of type MarkTo[]), if this Login object was restored with
		 * an ExpandAsArray on the mark_to association table.
		 * @var MarkTo[] _objMarkToAsFromArray;
		 */
		private $_objMarkToAsFromArray = null;

		/**
		 * Private member variable that stores a reference to a single MeetingAgendaPoleAsAttendees object
		 * (of type MeetingAgendaPole), if this Login object was restored with
		 * an expansion on the meeting_agenda_pole association table.
		 * @var MeetingAgendaPole _objMeetingAgendaPoleAsAttendees;
		 */
		private $_objMeetingAgendaPoleAsAttendees;

		/**
		 * Private member variable that stores a reference to an array of MeetingAgendaPoleAsAttendees objects
		 * (of type MeetingAgendaPole[]), if this Login object was restored with
		 * an ExpandAsArray on the meeting_agenda_pole association table.
		 * @var MeetingAgendaPole[] _objMeetingAgendaPoleAsAttendeesArray;
		 */
		private $_objMeetingAgendaPoleAsAttendeesArray = null;

		/**
		 * Private member variable that stores a reference to a single MeetingGroupHasMembersAsMember object
		 * (of type MeetingGroupHasMembers), if this Login object was restored with
		 * an expansion on the meeting_group_has_members association table.
		 * @var MeetingGroupHasMembers _objMeetingGroupHasMembersAsMember;
		 */
		private $_objMeetingGroupHasMembersAsMember;

		/**
		 * Private member variable that stores a reference to an array of MeetingGroupHasMembersAsMember objects
		 * (of type MeetingGroupHasMembers[]), if this Login object was restored with
		 * an ExpandAsArray on the meeting_group_has_members association table.
		 * @var MeetingGroupHasMembers[] _objMeetingGroupHasMembersAsMemberArray;
		 */
		private $_objMeetingGroupHasMembersAsMemberArray = null;

		/**
		 * Private member variable that stores a reference to a single MeetingNotesAsReferedBy object
		 * (of type MeetingNotes), if this Login object was restored with
		 * an expansion on the meeting_notes association table.
		 * @var MeetingNotes _objMeetingNotesAsReferedBy;
		 */
		private $_objMeetingNotesAsReferedBy;

		/**
		 * Private member variable that stores a reference to an array of MeetingNotesAsReferedBy objects
		 * (of type MeetingNotes[]), if this Login object was restored with
		 * an ExpandAsArray on the meeting_notes association table.
		 * @var MeetingNotes[] _objMeetingNotesAsReferedByArray;
		 */
		private $_objMeetingNotesAsReferedByArray = null;

		/**
		 * Private member variable that stores a reference to a single MeetingNotesAsActionOn object
		 * (of type MeetingNotes), if this Login object was restored with
		 * an expansion on the meeting_notes association table.
		 * @var MeetingNotes _objMeetingNotesAsActionOn;
		 */
		private $_objMeetingNotesAsActionOn;

		/**
		 * Private member variable that stores a reference to an array of MeetingNotesAsActionOn objects
		 * (of type MeetingNotes[]), if this Login object was restored with
		 * an ExpandAsArray on the meeting_notes association table.
		 * @var MeetingNotes[] _objMeetingNotesAsActionOnArray;
		 */
		private $_objMeetingNotesAsActionOnArray = null;

		/**
		 * Private member variable that stores a reference to a single NoteAsDataby object
		 * (of type Note), if this Login object was restored with
		 * an expansion on the note association table.
		 * @var Note _objNoteAsDataby;
		 */
		private $_objNoteAsDataby;

		/**
		 * Private member variable that stores a reference to an array of NoteAsDataby objects
		 * (of type Note[]), if this Login object was restored with
		 * an ExpandAsArray on the note association table.
		 * @var Note[] _objNoteAsDatabyArray;
		 */
		private $_objNoteAsDatabyArray = null;

		/**
		 * Private member variable that stores a reference to a single ReEvaluationAsStudent object
		 * (of type ReEvaluation), if this Login object was restored with
		 * an expansion on the re_evaluation association table.
		 * @var ReEvaluation _objReEvaluationAsStudent;
		 */
		private $_objReEvaluationAsStudent;

		/**
		 * Private member variable that stores a reference to an array of ReEvaluationAsStudent objects
		 * (of type ReEvaluation[]), if this Login object was restored with
		 * an ExpandAsArray on the re_evaluation association table.
		 * @var ReEvaluation[] _objReEvaluationAsStudentArray;
		 */
		private $_objReEvaluationAsStudentArray = null;

		/**
		 * Private member variable that stores a reference to a single SalarysheetApprovalAsApprovedBy object
		 * (of type SalarysheetApproval), if this Login object was restored with
		 * an expansion on the salarysheet_approval association table.
		 * @var SalarysheetApproval _objSalarysheetApprovalAsApprovedBy;
		 */
		private $_objSalarysheetApprovalAsApprovedBy;

		/**
		 * Private member variable that stores a reference to an array of SalarysheetApprovalAsApprovedBy objects
		 * (of type SalarysheetApproval[]), if this Login object was restored with
		 * an ExpandAsArray on the salarysheet_approval association table.
		 * @var SalarysheetApproval[] _objSalarysheetApprovalAsApprovedByArray;
		 */
		private $_objSalarysheetApprovalAsApprovedByArray = null;

		/**
		 * Private member variable that stores a reference to a single SignPatch object
		 * (of type SignPatch), if this Login object was restored with
		 * an expansion on the sign_patch association table.
		 * @var SignPatch _objSignPatch;
		 */
		private $_objSignPatch;

		/**
		 * Private member variable that stores a reference to an array of SignPatch objects
		 * (of type SignPatch[]), if this Login object was restored with
		 * an ExpandAsArray on the sign_patch association table.
		 * @var SignPatch[] _objSignPatchArray;
		 */
		private $_objSignPatchArray = null;

		/**
		 * Private member variable that stores a reference to a single StudAttendenceAsStudent object
		 * (of type StudAttendence), if this Login object was restored with
		 * an expansion on the stud_attendence association table.
		 * @var StudAttendence _objStudAttendenceAsStudent;
		 */
		private $_objStudAttendenceAsStudent;

		/**
		 * Private member variable that stores a reference to an array of StudAttendenceAsStudent objects
		 * (of type StudAttendence[]), if this Login object was restored with
		 * an ExpandAsArray on the stud_attendence association table.
		 * @var StudAttendence[] _objStudAttendenceAsStudentArray;
		 */
		private $_objStudAttendenceAsStudentArray = null;

		/**
		 * Private member variable that stores a reference to a single StudAttendenceAsStaff object
		 * (of type StudAttendence), if this Login object was restored with
		 * an expansion on the stud_attendence association table.
		 * @var StudAttendence _objStudAttendenceAsStaff;
		 */
		private $_objStudAttendenceAsStaff;

		/**
		 * Private member variable that stores a reference to an array of StudAttendenceAsStaff objects
		 * (of type StudAttendence[]), if this Login object was restored with
		 * an ExpandAsArray on the stud_attendence association table.
		 * @var StudAttendence[] _objStudAttendenceAsStaffArray;
		 */
		private $_objStudAttendenceAsStaffArray = null;

		/**
		 * Private member variable that stores a reference to a single SubjectTought object
		 * (of type SubjectTought), if this Login object was restored with
		 * an expansion on the subject_tought association table.
		 * @var SubjectTought _objSubjectTought;
		 */
		private $_objSubjectTought;

		/**
		 * Private member variable that stores a reference to an array of SubjectTought objects
		 * (of type SubjectTought[]), if this Login object was restored with
		 * an ExpandAsArray on the subject_tought association table.
		 * @var SubjectTought[] _objSubjectToughtArray;
		 */
		private $_objSubjectToughtArray = null;

		/**
		 * Private member variable that stores a reference to a single TimetableAsAttendant object
		 * (of type Timetable), if this Login object was restored with
		 * an expansion on the timetable association table.
		 * @var Timetable _objTimetableAsAttendant;
		 */
		private $_objTimetableAsAttendant;

		/**
		 * Private member variable that stores a reference to an array of TimetableAsAttendant objects
		 * (of type Timetable[]), if this Login object was restored with
		 * an ExpandAsArray on the timetable association table.
		 * @var Timetable[] _objTimetableAsAttendantArray;
		 */
		private $_objTimetableAsAttendantArray = null;

		/**
		 * Private member variable that stores a reference to a single VisitorPassAsForWhome object
		 * (of type VisitorPass), if this Login object was restored with
		 * an expansion on the visitor_pass association table.
		 * @var VisitorPass _objVisitorPassAsForWhome;
		 */
		private $_objVisitorPassAsForWhome;

		/**
		 * Private member variable that stores a reference to an array of VisitorPassAsForWhome objects
		 * (of type VisitorPass[]), if this Login object was restored with
		 * an ExpandAsArray on the visitor_pass association table.
		 * @var VisitorPass[] _objVisitorPassAsForWhomeArray;
		 */
		private $_objVisitorPassAsForWhomeArray = null;

		/**
		 * Private member variable that stores a reference to a single VoucherAsApprovedBy object
		 * (of type Voucher), if this Login object was restored with
		 * an expansion on the voucher association table.
		 * @var Voucher _objVoucherAsApprovedBy;
		 */
		private $_objVoucherAsApprovedBy;

		/**
		 * Private member variable that stores a reference to an array of VoucherAsApprovedBy objects
		 * (of type Voucher[]), if this Login object was restored with
		 * an ExpandAsArray on the voucher association table.
		 * @var Voucher[] _objVoucherAsApprovedByArray;
		 */
		private $_objVoucherAsApprovedByArray = null;

		/**
		 * Private member variable that stores a reference to a single VoucherAsCancelBy object
		 * (of type Voucher), if this Login object was restored with
		 * an expansion on the voucher association table.
		 * @var Voucher _objVoucherAsCancelBy;
		 */
		private $_objVoucherAsCancelBy;

		/**
		 * Private member variable that stores a reference to an array of VoucherAsCancelBy objects
		 * (of type Voucher[]), if this Login object was restored with
		 * an ExpandAsArray on the voucher association table.
		 * @var Voucher[] _objVoucherAsCancelByArray;
		 */
		private $_objVoucherAsCancelByArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column login.idlogin.
		 *
		 * NOTE: Always use the IdloginObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objIdloginObject
		 */
		protected $objIdloginObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdlogin = Login::IdloginDefault;
			$this->strUsername = Login::UsernameDefault;
			$this->strPassword = Login::PasswordDefault;
			$this->blnIsEnabled = Login::IsEnabledDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Login from PK Info
		 * @param integer $intIdlogin
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Login
		 */
		public static function Load($intIdlogin, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Login', $intIdlogin);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Login::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Login()->Idlogin, $intIdlogin)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Logins
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Login[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Login::QueryArray to perform the LoadAll query
			try {
				return Login::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Logins
		 * @return int
		 */
		public static function CountAll() {
			// Call Login::QueryCount to perform the CountAll query
			return Login::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Create/Build out the QueryBuilder object with Login-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'login');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Login::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('login');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Login object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Login the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Login::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Login object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Login::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Login::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Login objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Login[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Login::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Login::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Login::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Login objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Login::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			$strQuery = Login::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/login', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Login::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Login
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'login';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idlogin', $strAliasPrefix . 'idlogin');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idlogin', $strAliasPrefix . 'idlogin');
			    $objBuilder->AddSelectItem($strTableName, 'username', $strAliasPrefix . 'username');
			    $objBuilder->AddSelectItem($strTableName, 'password', $strAliasPrefix . 'password');
			    $objBuilder->AddSelectItem($strTableName, 'is_enabled', $strAliasPrefix . 'is_enabled');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Login from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Login::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Login
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdlogin == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'login__';


						// Expanding reverse references: AppApprovalAsDecisionBy
						$strAlias = $strAliasPrefix . 'appapprovalasdecisionby__idapp_approval';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objAppApprovalAsDecisionByArray)
								$objPreviousItem->_objAppApprovalAsDecisionByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objAppApprovalAsDecisionByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objAppApprovalAsDecisionByArray;
								$objChildItem = AppApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appapprovalasdecisionby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objAppApprovalAsDecisionByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objAppApprovalAsDecisionByArray[] = AppApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appapprovalasdecisionby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: AppDocsAsMember
						$strAlias = $strAliasPrefix . 'appdocsasmember__idapp_docs';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objAppDocsAsMemberArray)
								$objPreviousItem->_objAppDocsAsMemberArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objAppDocsAsMemberArray)) {
								$objPreviousChildItems = $objPreviousItem->_objAppDocsAsMemberArray;
								$objChildItem = AppDocs::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appdocsasmember__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objAppDocsAsMemberArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objAppDocsAsMemberArray[] = AppDocs::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appdocsasmember__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ApplicationAsDataEntryBy
						$strAlias = $strAliasPrefix . 'applicationasdataentryby__idapplication';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objApplicationAsDataEntryByArray)
								$objPreviousItem->_objApplicationAsDataEntryByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objApplicationAsDataEntryByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objApplicationAsDataEntryByArray;
								$objChildItem = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationasdataentryby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objApplicationAsDataEntryByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objApplicationAsDataEntryByArray[] = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationasdataentryby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ApplicationAsCertificateIssueBy
						$strAlias = $strAliasPrefix . 'applicationascertificateissueby__idapplication';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objApplicationAsCertificateIssueByArray)
								$objPreviousItem->_objApplicationAsCertificateIssueByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objApplicationAsCertificateIssueByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objApplicationAsCertificateIssueByArray;
								$objChildItem = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationascertificateissueby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objApplicationAsCertificateIssueByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objApplicationAsCertificateIssueByArray[] = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationascertificateissueby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ApplicationAsSubstitute
						$strAlias = $strAliasPrefix . 'applicationassubstitute__idapplication';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objApplicationAsSubstituteArray)
								$objPreviousItem->_objApplicationAsSubstituteArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objApplicationAsSubstituteArray)) {
								$objPreviousChildItems = $objPreviousItem->_objApplicationAsSubstituteArray;
								$objChildItem = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationassubstitute__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objApplicationAsSubstituteArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objApplicationAsSubstituteArray[] = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationassubstitute__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: AppliedExamAsStudent
						$strAlias = $strAliasPrefix . 'appliedexamasstudent__idapplied_exam';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objAppliedExamAsStudentArray)
								$objPreviousItem->_objAppliedExamAsStudentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objAppliedExamAsStudentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objAppliedExamAsStudentArray;
								$objChildItem = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamasstudent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objAppliedExamAsStudentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objAppliedExamAsStudentArray[] = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ApplyGradeImpromentAsStudent
						$strAlias = $strAliasPrefix . 'applygradeimpromentasstudent__idapply_grade_improment';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objApplyGradeImpromentAsStudentArray)
								$objPreviousItem->_objApplyGradeImpromentAsStudentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objApplyGradeImpromentAsStudentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objApplyGradeImpromentAsStudentArray;
								$objChildItem = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentasstudent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objApplyGradeImpromentAsStudentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objApplyGradeImpromentAsStudentArray[] = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ApplyGradeImpromentAsAppliedBy
						$strAlias = $strAliasPrefix . 'applygradeimpromentasappliedby__idapply_grade_improment';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objApplyGradeImpromentAsAppliedByArray)
								$objPreviousItem->_objApplyGradeImpromentAsAppliedByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objApplyGradeImpromentAsAppliedByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objApplyGradeImpromentAsAppliedByArray;
								$objChildItem = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentasappliedby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objApplyGradeImpromentAsAppliedByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objApplyGradeImpromentAsAppliedByArray[] = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentasappliedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: AttendenceAsStaff
						$strAlias = $strAliasPrefix . 'attendenceasstaff__idattendence';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objAttendenceAsStaffArray)
								$objPreviousItem->_objAttendenceAsStaffArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objAttendenceAsStaffArray)) {
								$objPreviousChildItems = $objPreviousItem->_objAttendenceAsStaffArray;
								$objChildItem = Attendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'attendenceasstaff__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objAttendenceAsStaffArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objAttendenceAsStaffArray[] = Attendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'attendenceasstaff__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: CertificateDepositeAsVerifyBy
						$strAlias = $strAliasPrefix . 'certificatedepositeasverifyby__idcertificate_deposite';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objCertificateDepositeAsVerifyByArray)
								$objPreviousItem->_objCertificateDepositeAsVerifyByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objCertificateDepositeAsVerifyByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objCertificateDepositeAsVerifyByArray;
								$objChildItem = CertificateDeposite::InstantiateDbRow($objDbRow, $strAliasPrefix . 'certificatedepositeasverifyby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objCertificateDepositeAsVerifyByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objCertificateDepositeAsVerifyByArray[] = CertificateDeposite::InstantiateDbRow($objDbRow, $strAliasPrefix . 'certificatedepositeasverifyby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: CertificateDepositeAsReturnBy
						$strAlias = $strAliasPrefix . 'certificatedepositeasreturnby__idcertificate_deposite';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objCertificateDepositeAsReturnByArray)
								$objPreviousItem->_objCertificateDepositeAsReturnByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objCertificateDepositeAsReturnByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objCertificateDepositeAsReturnByArray;
								$objChildItem = CertificateDeposite::InstantiateDbRow($objDbRow, $strAliasPrefix . 'certificatedepositeasreturnby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objCertificateDepositeAsReturnByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objCertificateDepositeAsReturnByArray[] = CertificateDeposite::InstantiateDbRow($objDbRow, $strAliasPrefix . 'certificatedepositeasreturnby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: CirculationAsDataBy
						$strAlias = $strAliasPrefix . 'circulationasdataby__idcirculation';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objCirculationAsDataByArray)
								$objPreviousItem->_objCirculationAsDataByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objCirculationAsDataByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objCirculationAsDataByArray;
								$objChildItem = Circulation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'circulationasdataby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objCirculationAsDataByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objCirculationAsDataByArray[] = Circulation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'circulationasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: CirculationAsStaffStud
						$strAlias = $strAliasPrefix . 'circulationasstaffstud__idcirculation';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objCirculationAsStaffStudArray)
								$objPreviousItem->_objCirculationAsStaffStudArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objCirculationAsStaffStudArray)) {
								$objPreviousChildItems = $objPreviousItem->_objCirculationAsStaffStudArray;
								$objChildItem = Circulation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'circulationasstaffstud__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objCirculationAsStaffStudArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objCirculationAsStaffStudArray[] = Circulation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'circulationasstaffstud__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: CurrentStatusAsStudent
						$strAlias = $strAliasPrefix . 'currentstatusasstudent__idcurrent_status';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objCurrentStatusAsStudentArray)
								$objPreviousItem->_objCurrentStatusAsStudentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objCurrentStatusAsStudentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objCurrentStatusAsStudentArray;
								$objChildItem = CurrentStatus::InstantiateDbRow($objDbRow, $strAliasPrefix . 'currentstatusasstudent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objCurrentStatusAsStudentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objCurrentStatusAsStudentArray[] = CurrentStatus::InstantiateDbRow($objDbRow, $strAliasPrefix . 'currentstatusasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: DeptYearEventsAsIntiator
						$strAlias = $strAliasPrefix . 'deptyeareventsasintiator__iddept_year_events';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objDeptYearEventsAsIntiatorArray)
								$objPreviousItem->_objDeptYearEventsAsIntiatorArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objDeptYearEventsAsIntiatorArray)) {
								$objPreviousChildItems = $objPreviousItem->_objDeptYearEventsAsIntiatorArray;
								$objChildItem = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasintiator__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objDeptYearEventsAsIntiatorArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objDeptYearEventsAsIntiatorArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasintiator__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: DeptYearEventsAsOwner
						$strAlias = $strAliasPrefix . 'deptyeareventsasowner__iddept_year_events';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objDeptYearEventsAsOwnerArray)
								$objPreviousItem->_objDeptYearEventsAsOwnerArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objDeptYearEventsAsOwnerArray)) {
								$objPreviousChildItems = $objPreviousItem->_objDeptYearEventsAsOwnerArray;
								$objChildItem = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasowner__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objDeptYearEventsAsOwnerArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objDeptYearEventsAsOwnerArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasowner__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: DocInOutAsInwordBy
						$strAlias = $strAliasPrefix . 'docinoutasinwordby__iddoc_in_out';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objDocInOutAsInwordByArray)
								$objPreviousItem->_objDocInOutAsInwordByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objDocInOutAsInwordByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objDocInOutAsInwordByArray;
								$objChildItem = DocInOut::InstantiateDbRow($objDbRow, $strAliasPrefix . 'docinoutasinwordby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objDocInOutAsInwordByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objDocInOutAsInwordByArray[] = DocInOut::InstantiateDbRow($objDbRow, $strAliasPrefix . 'docinoutasinwordby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ECourseAsTeacher
						$strAlias = $strAliasPrefix . 'ecourseasteacher__ide_course';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objECourseAsTeacherArray)
								$objPreviousItem->_objECourseAsTeacherArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objECourseAsTeacherArray)) {
								$objPreviousChildItems = $objPreviousItem->_objECourseAsTeacherArray;
								$objChildItem = ECourse::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ecourseasteacher__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objECourseAsTeacherArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objECourseAsTeacherArray[] = ECourse::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ecourseasteacher__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: EStudentAsStudent
						$strAlias = $strAliasPrefix . 'estudentasstudent__ide_student';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objEStudentAsStudentArray)
								$objPreviousItem->_objEStudentAsStudentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objEStudentAsStudentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objEStudentAsStudentArray;
								$objChildItem = EStudent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'estudentasstudent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objEStudentAsStudentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objEStudentAsStudentArray[] = EStudent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'estudentasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ETicketAsRaisedBy
						$strAlias = $strAliasPrefix . 'eticketasraisedby__ide_ticket';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objETicketAsRaisedByArray)
								$objPreviousItem->_objETicketAsRaisedByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objETicketAsRaisedByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objETicketAsRaisedByArray;
								$objChildItem = ETicket::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eticketasraisedby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objETicketAsRaisedByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objETicketAsRaisedByArray[] = ETicket::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eticketasraisedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: Establishment
						$strAlias = $strAliasPrefix . 'establishment__idestablishment';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objEstablishmentArray)
								$objPreviousItem->_objEstablishmentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objEstablishmentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objEstablishmentArray;
								$objChildItem = Establishment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'establishment__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objEstablishmentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objEstablishmentArray[] = Establishment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'establishment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: EventHasAttendentAsAttendent
						$strAlias = $strAliasPrefix . 'eventhasattendentasattendent__idevent_has_attendent';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objEventHasAttendentAsAttendentArray)
								$objPreviousItem->_objEventHasAttendentAsAttendentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objEventHasAttendentAsAttendentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objEventHasAttendentAsAttendentArray;
								$objChildItem = EventHasAttendent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasattendentasattendent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objEventHasAttendentAsAttendentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objEventHasAttendentAsAttendentArray[] = EventHasAttendent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasattendentasattendent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ExampaperAsSetBy
						$strAlias = $strAliasPrefix . 'exampaperassetby__idexampaper';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objExampaperAsSetByArray)
								$objPreviousItem->_objExampaperAsSetByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objExampaperAsSetByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objExampaperAsSetByArray;
								$objChildItem = Exampaper::InstantiateDbRow($objDbRow, $strAliasPrefix . 'exampaperassetby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objExampaperAsSetByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objExampaperAsSetByArray[] = Exampaper::InstantiateDbRow($objDbRow, $strAliasPrefix . 'exampaperassetby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ForwardToAsForWhome
						$strAlias = $strAliasPrefix . 'forwardtoasforwhome__idforward_to';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objForwardToAsForWhomeArray)
								$objPreviousItem->_objForwardToAsForWhomeArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objForwardToAsForWhomeArray)) {
								$objPreviousChildItems = $objPreviousItem->_objForwardToAsForWhomeArray;
								$objChildItem = ForwardTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'forwardtoasforwhome__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objForwardToAsForWhomeArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objForwardToAsForWhomeArray[] = ForwardTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'forwardtoasforwhome__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ForwardToAsForwardedTo
						$strAlias = $strAliasPrefix . 'forwardtoasforwardedto__idforward_to';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objForwardToAsForwardedToArray)
								$objPreviousItem->_objForwardToAsForwardedToArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objForwardToAsForwardedToArray)) {
								$objPreviousChildItems = $objPreviousItem->_objForwardToAsForwardedToArray;
								$objChildItem = ForwardTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'forwardtoasforwardedto__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objForwardToAsForwardedToArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objForwardToAsForwardedToArray[] = ForwardTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'forwardtoasforwardedto__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: GradeCardAsStudent
						$strAlias = $strAliasPrefix . 'gradecardasstudent__idgrade_card';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objGradeCardAsStudentArray)
								$objPreviousItem->_objGradeCardAsStudentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objGradeCardAsStudentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objGradeCardAsStudentArray;
								$objChildItem = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasstudent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objGradeCardAsStudentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objGradeCardAsStudentArray[] = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: GradeCardAsChangeInEseBy
						$strAlias = $strAliasPrefix . 'gradecardaschangeineseby__idgrade_card';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objGradeCardAsChangeInEseByArray)
								$objPreviousItem->_objGradeCardAsChangeInEseByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objGradeCardAsChangeInEseByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objGradeCardAsChangeInEseByArray;
								$objChildItem = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardaschangeineseby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objGradeCardAsChangeInEseByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objGradeCardAsChangeInEseByArray[] = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardaschangeineseby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: IssuedItemsAsMember
						$strAlias = $strAliasPrefix . 'issueditemsasmember__idissued_items';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objIssuedItemsAsMemberArray)
								$objPreviousItem->_objIssuedItemsAsMemberArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objIssuedItemsAsMemberArray)) {
								$objPreviousChildItems = $objPreviousItem->_objIssuedItemsAsMemberArray;
								$objChildItem = IssuedItems::InstantiateDbRow($objDbRow, $strAliasPrefix . 'issueditemsasmember__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objIssuedItemsAsMemberArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objIssuedItemsAsMemberArray[] = IssuedItems::InstantiateDbRow($objDbRow, $strAliasPrefix . 'issueditemsasmember__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: IwowAsDataBy
						$strAlias = $strAliasPrefix . 'iwowasdataby__idiwow';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objIwowAsDataByArray)
								$objPreviousItem->_objIwowAsDataByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objIwowAsDataByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objIwowAsDataByArray;
								$objChildItem = Iwow::InstantiateDbRow($objDbRow, $strAliasPrefix . 'iwowasdataby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objIwowAsDataByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objIwowAsDataByArray[] = Iwow::InstantiateDbRow($objDbRow, $strAliasPrefix . 'iwowasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: IwowAsInspectedBy
						$strAlias = $strAliasPrefix . 'iwowasinspectedby__idiwow';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objIwowAsInspectedByArray)
								$objPreviousItem->_objIwowAsInspectedByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objIwowAsInspectedByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objIwowAsInspectedByArray;
								$objChildItem = Iwow::InstantiateDbRow($objDbRow, $strAliasPrefix . 'iwowasinspectedby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objIwowAsInspectedByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objIwowAsInspectedByArray[] = Iwow::InstantiateDbRow($objDbRow, $strAliasPrefix . 'iwowasinspectedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: LeaveBalanceAsMember
						$strAlias = $strAliasPrefix . 'leavebalanceasmember__idleave_balance';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objLeaveBalanceAsMemberArray)
								$objPreviousItem->_objLeaveBalanceAsMemberArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objLeaveBalanceAsMemberArray)) {
								$objPreviousChildItems = $objPreviousItem->_objLeaveBalanceAsMemberArray;
								$objChildItem = LeaveBalance::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavebalanceasmember__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objLeaveBalanceAsMemberArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objLeaveBalanceAsMemberArray[] = LeaveBalance::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavebalanceasmember__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: LogAsDataBy
						$strAlias = $strAliasPrefix . 'logasdataby__idlog';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objLogAsDataByArray)
								$objPreviousItem->_objLogAsDataByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objLogAsDataByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objLogAsDataByArray;
								$objChildItem = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logasdataby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objLogAsDataByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objLogAsDataByArray[] = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: LoginHasRoleAsId
						$strAlias = $strAliasPrefix . 'loginhasroleasid__login_idlogin';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objLoginHasRoleAsIdArray)
								$objPreviousItem->_objLoginHasRoleAsIdArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objLoginHasRoleAsIdArray)) {
								$objPreviousChildItems = $objPreviousItem->_objLoginHasRoleAsIdArray;
								$objChildItem = LoginHasRole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'loginhasroleasid__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objLoginHasRoleAsIdArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objLoginHasRoleAsIdArray[] = LoginHasRole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'loginhasroleasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: MarkToAsTo
						$strAlias = $strAliasPrefix . 'marktoasto__idmark_to';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objMarkToAsToArray)
								$objPreviousItem->_objMarkToAsToArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objMarkToAsToArray)) {
								$objPreviousChildItems = $objPreviousItem->_objMarkToAsToArray;
								$objChildItem = MarkTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'marktoasto__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objMarkToAsToArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objMarkToAsToArray[] = MarkTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'marktoasto__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: MarkToAsFrom
						$strAlias = $strAliasPrefix . 'marktoasfrom__idmark_to';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objMarkToAsFromArray)
								$objPreviousItem->_objMarkToAsFromArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objMarkToAsFromArray)) {
								$objPreviousChildItems = $objPreviousItem->_objMarkToAsFromArray;
								$objChildItem = MarkTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'marktoasfrom__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objMarkToAsFromArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objMarkToAsFromArray[] = MarkTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'marktoasfrom__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: MeetingAgendaPoleAsAttendees
						$strAlias = $strAliasPrefix . 'meetingagendapoleasattendees__idmeeting_agenda_pole';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objMeetingAgendaPoleAsAttendeesArray)
								$objPreviousItem->_objMeetingAgendaPoleAsAttendeesArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objMeetingAgendaPoleAsAttendeesArray)) {
								$objPreviousChildItems = $objPreviousItem->_objMeetingAgendaPoleAsAttendeesArray;
								$objChildItem = MeetingAgendaPole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingagendapoleasattendees__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objMeetingAgendaPoleAsAttendeesArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objMeetingAgendaPoleAsAttendeesArray[] = MeetingAgendaPole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingagendapoleasattendees__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: MeetingGroupHasMembersAsMember
						$strAlias = $strAliasPrefix . 'meetinggrouphasmembersasmember__idmeeting_group_has_members';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objMeetingGroupHasMembersAsMemberArray)
								$objPreviousItem->_objMeetingGroupHasMembersAsMemberArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objMeetingGroupHasMembersAsMemberArray)) {
								$objPreviousChildItems = $objPreviousItem->_objMeetingGroupHasMembersAsMemberArray;
								$objChildItem = MeetingGroupHasMembers::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetinggrouphasmembersasmember__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objMeetingGroupHasMembersAsMemberArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objMeetingGroupHasMembersAsMemberArray[] = MeetingGroupHasMembers::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetinggrouphasmembersasmember__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: MeetingNotesAsReferedBy
						$strAlias = $strAliasPrefix . 'meetingnotesasreferedby__idmeeting_notes';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objMeetingNotesAsReferedByArray)
								$objPreviousItem->_objMeetingNotesAsReferedByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objMeetingNotesAsReferedByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objMeetingNotesAsReferedByArray;
								$objChildItem = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasreferedby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objMeetingNotesAsReferedByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objMeetingNotesAsReferedByArray[] = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasreferedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: MeetingNotesAsActionOn
						$strAlias = $strAliasPrefix . 'meetingnotesasactionon__idmeeting_notes';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objMeetingNotesAsActionOnArray)
								$objPreviousItem->_objMeetingNotesAsActionOnArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objMeetingNotesAsActionOnArray)) {
								$objPreviousChildItems = $objPreviousItem->_objMeetingNotesAsActionOnArray;
								$objChildItem = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasactionon__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objMeetingNotesAsActionOnArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objMeetingNotesAsActionOnArray[] = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasactionon__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: NoteAsDataby
						$strAlias = $strAliasPrefix . 'noteasdataby__idnote';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objNoteAsDatabyArray)
								$objPreviousItem->_objNoteAsDatabyArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objNoteAsDatabyArray)) {
								$objPreviousChildItems = $objPreviousItem->_objNoteAsDatabyArray;
								$objChildItem = Note::InstantiateDbRow($objDbRow, $strAliasPrefix . 'noteasdataby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objNoteAsDatabyArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objNoteAsDatabyArray[] = Note::InstantiateDbRow($objDbRow, $strAliasPrefix . 'noteasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ReEvaluationAsStudent
						$strAlias = $strAliasPrefix . 'reevaluationasstudent__idre_evaluation';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objReEvaluationAsStudentArray)
								$objPreviousItem->_objReEvaluationAsStudentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objReEvaluationAsStudentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objReEvaluationAsStudentArray;
								$objChildItem = ReEvaluation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'reevaluationasstudent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objReEvaluationAsStudentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objReEvaluationAsStudentArray[] = ReEvaluation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'reevaluationasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: SalarysheetApprovalAsApprovedBy
						$strAlias = $strAliasPrefix . 'salarysheetapprovalasapprovedby__idsalarysheet_approval';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objSalarysheetApprovalAsApprovedByArray)
								$objPreviousItem->_objSalarysheetApprovalAsApprovedByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objSalarysheetApprovalAsApprovedByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objSalarysheetApprovalAsApprovedByArray;
								$objChildItem = SalarysheetApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarysheetapprovalasapprovedby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objSalarysheetApprovalAsApprovedByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objSalarysheetApprovalAsApprovedByArray[] = SalarysheetApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarysheetapprovalasapprovedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: SignPatch
						$strAlias = $strAliasPrefix . 'signpatch__idsign_patch';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objSignPatchArray)
								$objPreviousItem->_objSignPatchArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objSignPatchArray)) {
								$objPreviousChildItems = $objPreviousItem->_objSignPatchArray;
								$objChildItem = SignPatch::InstantiateDbRow($objDbRow, $strAliasPrefix . 'signpatch__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objSignPatchArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objSignPatchArray[] = SignPatch::InstantiateDbRow($objDbRow, $strAliasPrefix . 'signpatch__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: StudAttendenceAsStudent
						$strAlias = $strAliasPrefix . 'studattendenceasstudent__idstud_attendence';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objStudAttendenceAsStudentArray)
								$objPreviousItem->_objStudAttendenceAsStudentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objStudAttendenceAsStudentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objStudAttendenceAsStudentArray;
								$objChildItem = StudAttendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'studattendenceasstudent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objStudAttendenceAsStudentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objStudAttendenceAsStudentArray[] = StudAttendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'studattendenceasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: StudAttendenceAsStaff
						$strAlias = $strAliasPrefix . 'studattendenceasstaff__idstud_attendence';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objStudAttendenceAsStaffArray)
								$objPreviousItem->_objStudAttendenceAsStaffArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objStudAttendenceAsStaffArray)) {
								$objPreviousChildItems = $objPreviousItem->_objStudAttendenceAsStaffArray;
								$objChildItem = StudAttendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'studattendenceasstaff__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objStudAttendenceAsStaffArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objStudAttendenceAsStaffArray[] = StudAttendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'studattendenceasstaff__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: SubjectTought
						$strAlias = $strAliasPrefix . 'subjecttought__idsubject_tought';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objSubjectToughtArray)
								$objPreviousItem->_objSubjectToughtArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objSubjectToughtArray)) {
								$objPreviousChildItems = $objPreviousItem->_objSubjectToughtArray;
								$objChildItem = SubjectTought::InstantiateDbRow($objDbRow, $strAliasPrefix . 'subjecttought__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objSubjectToughtArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objSubjectToughtArray[] = SubjectTought::InstantiateDbRow($objDbRow, $strAliasPrefix . 'subjecttought__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: TimetableAsAttendant
						$strAlias = $strAliasPrefix . 'timetableasattendant__idtimetable';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objTimetableAsAttendantArray)
								$objPreviousItem->_objTimetableAsAttendantArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objTimetableAsAttendantArray)) {
								$objPreviousChildItems = $objPreviousItem->_objTimetableAsAttendantArray;
								$objChildItem = Timetable::InstantiateDbRow($objDbRow, $strAliasPrefix . 'timetableasattendant__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objTimetableAsAttendantArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objTimetableAsAttendantArray[] = Timetable::InstantiateDbRow($objDbRow, $strAliasPrefix . 'timetableasattendant__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: VisitorPassAsForWhome
						$strAlias = $strAliasPrefix . 'visitorpassasforwhome__idvisitor_pass';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objVisitorPassAsForWhomeArray)
								$objPreviousItem->_objVisitorPassAsForWhomeArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objVisitorPassAsForWhomeArray)) {
								$objPreviousChildItems = $objPreviousItem->_objVisitorPassAsForWhomeArray;
								$objChildItem = VisitorPass::InstantiateDbRow($objDbRow, $strAliasPrefix . 'visitorpassasforwhome__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objVisitorPassAsForWhomeArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objVisitorPassAsForWhomeArray[] = VisitorPass::InstantiateDbRow($objDbRow, $strAliasPrefix . 'visitorpassasforwhome__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: VoucherAsApprovedBy
						$strAlias = $strAliasPrefix . 'voucherasapprovedby__idvoucher';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objVoucherAsApprovedByArray)
								$objPreviousItem->_objVoucherAsApprovedByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objVoucherAsApprovedByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objVoucherAsApprovedByArray;
								$objChildItem = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasapprovedby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objVoucherAsApprovedByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objVoucherAsApprovedByArray[] = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasapprovedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: VoucherAsCancelBy
						$strAlias = $strAliasPrefix . 'voucherascancelby__idvoucher';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objVoucherAsCancelByArray)
								$objPreviousItem->_objVoucherAsCancelByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objVoucherAsCancelByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objVoucherAsCancelByArray;
								$objChildItem = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherascancelby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objVoucherAsCancelByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objVoucherAsCancelByArray[] = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherascancelby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'login__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Login object
			$objToReturn = new Login();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdlogin = $objDbRow->GetColumn($strAliasName, 'Integer');
			$objToReturn->__intIdlogin = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'username';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strUsername = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'password';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strPassword = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'is_enabled';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnIsEnabled = $objDbRow->GetColumn($strAliasName, 'Bit');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idlogin != $objPreviousItem->Idlogin) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objAppApprovalAsDecisionByArray);
					$cnt = count($objToReturn->_objAppApprovalAsDecisionByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objAppApprovalAsDecisionByArray, $objToReturn->_objAppApprovalAsDecisionByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objAppDocsAsMemberArray);
					$cnt = count($objToReturn->_objAppDocsAsMemberArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objAppDocsAsMemberArray, $objToReturn->_objAppDocsAsMemberArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objApplicationAsDataEntryByArray);
					$cnt = count($objToReturn->_objApplicationAsDataEntryByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objApplicationAsDataEntryByArray, $objToReturn->_objApplicationAsDataEntryByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objApplicationAsCertificateIssueByArray);
					$cnt = count($objToReturn->_objApplicationAsCertificateIssueByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objApplicationAsCertificateIssueByArray, $objToReturn->_objApplicationAsCertificateIssueByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objApplicationAsSubstituteArray);
					$cnt = count($objToReturn->_objApplicationAsSubstituteArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objApplicationAsSubstituteArray, $objToReturn->_objApplicationAsSubstituteArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objAppliedExamAsStudentArray);
					$cnt = count($objToReturn->_objAppliedExamAsStudentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objAppliedExamAsStudentArray, $objToReturn->_objAppliedExamAsStudentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objApplyGradeImpromentAsStudentArray);
					$cnt = count($objToReturn->_objApplyGradeImpromentAsStudentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objApplyGradeImpromentAsStudentArray, $objToReturn->_objApplyGradeImpromentAsStudentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objApplyGradeImpromentAsAppliedByArray);
					$cnt = count($objToReturn->_objApplyGradeImpromentAsAppliedByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objApplyGradeImpromentAsAppliedByArray, $objToReturn->_objApplyGradeImpromentAsAppliedByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objAttendenceAsStaffArray);
					$cnt = count($objToReturn->_objAttendenceAsStaffArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objAttendenceAsStaffArray, $objToReturn->_objAttendenceAsStaffArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objCertificateDepositeAsVerifyByArray);
					$cnt = count($objToReturn->_objCertificateDepositeAsVerifyByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objCertificateDepositeAsVerifyByArray, $objToReturn->_objCertificateDepositeAsVerifyByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objCertificateDepositeAsReturnByArray);
					$cnt = count($objToReturn->_objCertificateDepositeAsReturnByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objCertificateDepositeAsReturnByArray, $objToReturn->_objCertificateDepositeAsReturnByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objCirculationAsDataByArray);
					$cnt = count($objToReturn->_objCirculationAsDataByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objCirculationAsDataByArray, $objToReturn->_objCirculationAsDataByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objCirculationAsStaffStudArray);
					$cnt = count($objToReturn->_objCirculationAsStaffStudArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objCirculationAsStaffStudArray, $objToReturn->_objCirculationAsStaffStudArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objCurrentStatusAsStudentArray);
					$cnt = count($objToReturn->_objCurrentStatusAsStudentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objCurrentStatusAsStudentArray, $objToReturn->_objCurrentStatusAsStudentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objDeptYearEventsAsIntiatorArray);
					$cnt = count($objToReturn->_objDeptYearEventsAsIntiatorArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objDeptYearEventsAsIntiatorArray, $objToReturn->_objDeptYearEventsAsIntiatorArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objDeptYearEventsAsOwnerArray);
					$cnt = count($objToReturn->_objDeptYearEventsAsOwnerArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objDeptYearEventsAsOwnerArray, $objToReturn->_objDeptYearEventsAsOwnerArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objDocInOutAsInwordByArray);
					$cnt = count($objToReturn->_objDocInOutAsInwordByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objDocInOutAsInwordByArray, $objToReturn->_objDocInOutAsInwordByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objECourseAsTeacherArray);
					$cnt = count($objToReturn->_objECourseAsTeacherArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objECourseAsTeacherArray, $objToReturn->_objECourseAsTeacherArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objEStudentAsStudentArray);
					$cnt = count($objToReturn->_objEStudentAsStudentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objEStudentAsStudentArray, $objToReturn->_objEStudentAsStudentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objETicketAsRaisedByArray);
					$cnt = count($objToReturn->_objETicketAsRaisedByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objETicketAsRaisedByArray, $objToReturn->_objETicketAsRaisedByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objEstablishmentArray);
					$cnt = count($objToReturn->_objEstablishmentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objEstablishmentArray, $objToReturn->_objEstablishmentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objEventHasAttendentAsAttendentArray);
					$cnt = count($objToReturn->_objEventHasAttendentAsAttendentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objEventHasAttendentAsAttendentArray, $objToReturn->_objEventHasAttendentAsAttendentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objExampaperAsSetByArray);
					$cnt = count($objToReturn->_objExampaperAsSetByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objExampaperAsSetByArray, $objToReturn->_objExampaperAsSetByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objForwardToAsForWhomeArray);
					$cnt = count($objToReturn->_objForwardToAsForWhomeArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objForwardToAsForWhomeArray, $objToReturn->_objForwardToAsForWhomeArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objForwardToAsForwardedToArray);
					$cnt = count($objToReturn->_objForwardToAsForwardedToArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objForwardToAsForwardedToArray, $objToReturn->_objForwardToAsForwardedToArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objGradeCardAsStudentArray);
					$cnt = count($objToReturn->_objGradeCardAsStudentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objGradeCardAsStudentArray, $objToReturn->_objGradeCardAsStudentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objGradeCardAsChangeInEseByArray);
					$cnt = count($objToReturn->_objGradeCardAsChangeInEseByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objGradeCardAsChangeInEseByArray, $objToReturn->_objGradeCardAsChangeInEseByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objIssuedItemsAsMemberArray);
					$cnt = count($objToReturn->_objIssuedItemsAsMemberArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objIssuedItemsAsMemberArray, $objToReturn->_objIssuedItemsAsMemberArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objIwowAsDataByArray);
					$cnt = count($objToReturn->_objIwowAsDataByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objIwowAsDataByArray, $objToReturn->_objIwowAsDataByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objIwowAsInspectedByArray);
					$cnt = count($objToReturn->_objIwowAsInspectedByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objIwowAsInspectedByArray, $objToReturn->_objIwowAsInspectedByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objLeaveBalanceAsMemberArray);
					$cnt = count($objToReturn->_objLeaveBalanceAsMemberArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objLeaveBalanceAsMemberArray, $objToReturn->_objLeaveBalanceAsMemberArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objLogAsDataByArray);
					$cnt = count($objToReturn->_objLogAsDataByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objLogAsDataByArray, $objToReturn->_objLogAsDataByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objLoginHasRoleAsIdArray);
					$cnt = count($objToReturn->_objLoginHasRoleAsIdArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objLoginHasRoleAsIdArray, $objToReturn->_objLoginHasRoleAsIdArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objMarkToAsToArray);
					$cnt = count($objToReturn->_objMarkToAsToArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objMarkToAsToArray, $objToReturn->_objMarkToAsToArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objMarkToAsFromArray);
					$cnt = count($objToReturn->_objMarkToAsFromArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objMarkToAsFromArray, $objToReturn->_objMarkToAsFromArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objMeetingAgendaPoleAsAttendeesArray);
					$cnt = count($objToReturn->_objMeetingAgendaPoleAsAttendeesArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objMeetingAgendaPoleAsAttendeesArray, $objToReturn->_objMeetingAgendaPoleAsAttendeesArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objMeetingGroupHasMembersAsMemberArray);
					$cnt = count($objToReturn->_objMeetingGroupHasMembersAsMemberArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objMeetingGroupHasMembersAsMemberArray, $objToReturn->_objMeetingGroupHasMembersAsMemberArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objMeetingNotesAsReferedByArray);
					$cnt = count($objToReturn->_objMeetingNotesAsReferedByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objMeetingNotesAsReferedByArray, $objToReturn->_objMeetingNotesAsReferedByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objMeetingNotesAsActionOnArray);
					$cnt = count($objToReturn->_objMeetingNotesAsActionOnArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objMeetingNotesAsActionOnArray, $objToReturn->_objMeetingNotesAsActionOnArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objNoteAsDatabyArray);
					$cnt = count($objToReturn->_objNoteAsDatabyArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objNoteAsDatabyArray, $objToReturn->_objNoteAsDatabyArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objReEvaluationAsStudentArray);
					$cnt = count($objToReturn->_objReEvaluationAsStudentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objReEvaluationAsStudentArray, $objToReturn->_objReEvaluationAsStudentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objSalarysheetApprovalAsApprovedByArray);
					$cnt = count($objToReturn->_objSalarysheetApprovalAsApprovedByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objSalarysheetApprovalAsApprovedByArray, $objToReturn->_objSalarysheetApprovalAsApprovedByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objSignPatchArray);
					$cnt = count($objToReturn->_objSignPatchArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objSignPatchArray, $objToReturn->_objSignPatchArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objStudAttendenceAsStudentArray);
					$cnt = count($objToReturn->_objStudAttendenceAsStudentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objStudAttendenceAsStudentArray, $objToReturn->_objStudAttendenceAsStudentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objStudAttendenceAsStaffArray);
					$cnt = count($objToReturn->_objStudAttendenceAsStaffArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objStudAttendenceAsStaffArray, $objToReturn->_objStudAttendenceAsStaffArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objSubjectToughtArray);
					$cnt = count($objToReturn->_objSubjectToughtArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objSubjectToughtArray, $objToReturn->_objSubjectToughtArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objTimetableAsAttendantArray);
					$cnt = count($objToReturn->_objTimetableAsAttendantArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objTimetableAsAttendantArray, $objToReturn->_objTimetableAsAttendantArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objVisitorPassAsForWhomeArray);
					$cnt = count($objToReturn->_objVisitorPassAsForWhomeArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objVisitorPassAsForWhomeArray, $objToReturn->_objVisitorPassAsForWhomeArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objVoucherAsApprovedByArray);
					$cnt = count($objToReturn->_objVoucherAsApprovedByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objVoucherAsApprovedByArray, $objToReturn->_objVoucherAsApprovedByArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objVoucherAsCancelByArray);
					$cnt = count($objToReturn->_objVoucherAsCancelByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objVoucherAsCancelByArray, $objToReturn->_objVoucherAsCancelByArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'login__';

			// Check for IdloginObject Early Binding
			$strAlias = $strAliasPrefix . 'idlogin__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objIdloginObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'idlogin__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for AppApprovalAsDecisionBy Virtual Binding
			$strAlias = $strAliasPrefix . 'appapprovalasdecisionby__idapp_approval';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objAppApprovalAsDecisionByArray)
				$objToReturn->_objAppApprovalAsDecisionByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objAppApprovalAsDecisionByArray[] = AppApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appapprovalasdecisionby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objAppApprovalAsDecisionBy = AppApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appapprovalasdecisionby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for AppDocsAsMember Virtual Binding
			$strAlias = $strAliasPrefix . 'appdocsasmember__idapp_docs';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objAppDocsAsMemberArray)
				$objToReturn->_objAppDocsAsMemberArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objAppDocsAsMemberArray[] = AppDocs::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appdocsasmember__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objAppDocsAsMember = AppDocs::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appdocsasmember__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ApplicationAsDataEntryBy Virtual Binding
			$strAlias = $strAliasPrefix . 'applicationasdataentryby__idapplication';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objApplicationAsDataEntryByArray)
				$objToReturn->_objApplicationAsDataEntryByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objApplicationAsDataEntryByArray[] = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationasdataentryby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objApplicationAsDataEntryBy = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationasdataentryby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ApplicationAsCertificateIssueBy Virtual Binding
			$strAlias = $strAliasPrefix . 'applicationascertificateissueby__idapplication';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objApplicationAsCertificateIssueByArray)
				$objToReturn->_objApplicationAsCertificateIssueByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objApplicationAsCertificateIssueByArray[] = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationascertificateissueby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objApplicationAsCertificateIssueBy = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationascertificateissueby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ApplicationAsSubstitute Virtual Binding
			$strAlias = $strAliasPrefix . 'applicationassubstitute__idapplication';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objApplicationAsSubstituteArray)
				$objToReturn->_objApplicationAsSubstituteArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objApplicationAsSubstituteArray[] = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationassubstitute__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objApplicationAsSubstitute = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applicationassubstitute__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for AppliedExamAsStudent Virtual Binding
			$strAlias = $strAliasPrefix . 'appliedexamasstudent__idapplied_exam';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objAppliedExamAsStudentArray)
				$objToReturn->_objAppliedExamAsStudentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objAppliedExamAsStudentArray[] = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objAppliedExamAsStudent = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ApplyGradeImpromentAsStudent Virtual Binding
			$strAlias = $strAliasPrefix . 'applygradeimpromentasstudent__idapply_grade_improment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objApplyGradeImpromentAsStudentArray)
				$objToReturn->_objApplyGradeImpromentAsStudentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objApplyGradeImpromentAsStudentArray[] = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objApplyGradeImpromentAsStudent = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ApplyGradeImpromentAsAppliedBy Virtual Binding
			$strAlias = $strAliasPrefix . 'applygradeimpromentasappliedby__idapply_grade_improment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objApplyGradeImpromentAsAppliedByArray)
				$objToReturn->_objApplyGradeImpromentAsAppliedByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objApplyGradeImpromentAsAppliedByArray[] = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentasappliedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objApplyGradeImpromentAsAppliedBy = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentasappliedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for AttendenceAsStaff Virtual Binding
			$strAlias = $strAliasPrefix . 'attendenceasstaff__idattendence';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objAttendenceAsStaffArray)
				$objToReturn->_objAttendenceAsStaffArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objAttendenceAsStaffArray[] = Attendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'attendenceasstaff__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objAttendenceAsStaff = Attendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'attendenceasstaff__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for CertificateDepositeAsVerifyBy Virtual Binding
			$strAlias = $strAliasPrefix . 'certificatedepositeasverifyby__idcertificate_deposite';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objCertificateDepositeAsVerifyByArray)
				$objToReturn->_objCertificateDepositeAsVerifyByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objCertificateDepositeAsVerifyByArray[] = CertificateDeposite::InstantiateDbRow($objDbRow, $strAliasPrefix . 'certificatedepositeasverifyby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objCertificateDepositeAsVerifyBy = CertificateDeposite::InstantiateDbRow($objDbRow, $strAliasPrefix . 'certificatedepositeasverifyby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for CertificateDepositeAsReturnBy Virtual Binding
			$strAlias = $strAliasPrefix . 'certificatedepositeasreturnby__idcertificate_deposite';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objCertificateDepositeAsReturnByArray)
				$objToReturn->_objCertificateDepositeAsReturnByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objCertificateDepositeAsReturnByArray[] = CertificateDeposite::InstantiateDbRow($objDbRow, $strAliasPrefix . 'certificatedepositeasreturnby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objCertificateDepositeAsReturnBy = CertificateDeposite::InstantiateDbRow($objDbRow, $strAliasPrefix . 'certificatedepositeasreturnby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for CirculationAsDataBy Virtual Binding
			$strAlias = $strAliasPrefix . 'circulationasdataby__idcirculation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objCirculationAsDataByArray)
				$objToReturn->_objCirculationAsDataByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objCirculationAsDataByArray[] = Circulation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'circulationasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objCirculationAsDataBy = Circulation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'circulationasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for CirculationAsStaffStud Virtual Binding
			$strAlias = $strAliasPrefix . 'circulationasstaffstud__idcirculation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objCirculationAsStaffStudArray)
				$objToReturn->_objCirculationAsStaffStudArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objCirculationAsStaffStudArray[] = Circulation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'circulationasstaffstud__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objCirculationAsStaffStud = Circulation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'circulationasstaffstud__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for CurrentStatusAsStudent Virtual Binding
			$strAlias = $strAliasPrefix . 'currentstatusasstudent__idcurrent_status';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objCurrentStatusAsStudentArray)
				$objToReturn->_objCurrentStatusAsStudentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objCurrentStatusAsStudentArray[] = CurrentStatus::InstantiateDbRow($objDbRow, $strAliasPrefix . 'currentstatusasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objCurrentStatusAsStudent = CurrentStatus::InstantiateDbRow($objDbRow, $strAliasPrefix . 'currentstatusasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for DeptYearEventsAsIntiator Virtual Binding
			$strAlias = $strAliasPrefix . 'deptyeareventsasintiator__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objDeptYearEventsAsIntiatorArray)
				$objToReturn->_objDeptYearEventsAsIntiatorArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objDeptYearEventsAsIntiatorArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasintiator__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objDeptYearEventsAsIntiator = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasintiator__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for DeptYearEventsAsOwner Virtual Binding
			$strAlias = $strAliasPrefix . 'deptyeareventsasowner__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objDeptYearEventsAsOwnerArray)
				$objToReturn->_objDeptYearEventsAsOwnerArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objDeptYearEventsAsOwnerArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasowner__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objDeptYearEventsAsOwner = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasowner__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for DocInOutAsInwordBy Virtual Binding
			$strAlias = $strAliasPrefix . 'docinoutasinwordby__iddoc_in_out';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objDocInOutAsInwordByArray)
				$objToReturn->_objDocInOutAsInwordByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objDocInOutAsInwordByArray[] = DocInOut::InstantiateDbRow($objDbRow, $strAliasPrefix . 'docinoutasinwordby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objDocInOutAsInwordBy = DocInOut::InstantiateDbRow($objDbRow, $strAliasPrefix . 'docinoutasinwordby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ECourseAsTeacher Virtual Binding
			$strAlias = $strAliasPrefix . 'ecourseasteacher__ide_course';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objECourseAsTeacherArray)
				$objToReturn->_objECourseAsTeacherArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objECourseAsTeacherArray[] = ECourse::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ecourseasteacher__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objECourseAsTeacher = ECourse::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ecourseasteacher__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for EStudentAsStudent Virtual Binding
			$strAlias = $strAliasPrefix . 'estudentasstudent__ide_student';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objEStudentAsStudentArray)
				$objToReturn->_objEStudentAsStudentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objEStudentAsStudentArray[] = EStudent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'estudentasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objEStudentAsStudent = EStudent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'estudentasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ETicketAsRaisedBy Virtual Binding
			$strAlias = $strAliasPrefix . 'eticketasraisedby__ide_ticket';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objETicketAsRaisedByArray)
				$objToReturn->_objETicketAsRaisedByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objETicketAsRaisedByArray[] = ETicket::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eticketasraisedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objETicketAsRaisedBy = ETicket::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eticketasraisedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for Establishment Virtual Binding
			$strAlias = $strAliasPrefix . 'establishment__idestablishment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objEstablishmentArray)
				$objToReturn->_objEstablishmentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objEstablishmentArray[] = Establishment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'establishment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objEstablishment = Establishment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'establishment__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for EventHasAttendentAsAttendent Virtual Binding
			$strAlias = $strAliasPrefix . 'eventhasattendentasattendent__idevent_has_attendent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objEventHasAttendentAsAttendentArray)
				$objToReturn->_objEventHasAttendentAsAttendentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objEventHasAttendentAsAttendentArray[] = EventHasAttendent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasattendentasattendent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objEventHasAttendentAsAttendent = EventHasAttendent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasattendentasattendent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ExampaperAsSetBy Virtual Binding
			$strAlias = $strAliasPrefix . 'exampaperassetby__idexampaper';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objExampaperAsSetByArray)
				$objToReturn->_objExampaperAsSetByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objExampaperAsSetByArray[] = Exampaper::InstantiateDbRow($objDbRow, $strAliasPrefix . 'exampaperassetby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objExampaperAsSetBy = Exampaper::InstantiateDbRow($objDbRow, $strAliasPrefix . 'exampaperassetby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ForwardToAsForWhome Virtual Binding
			$strAlias = $strAliasPrefix . 'forwardtoasforwhome__idforward_to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objForwardToAsForWhomeArray)
				$objToReturn->_objForwardToAsForWhomeArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objForwardToAsForWhomeArray[] = ForwardTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'forwardtoasforwhome__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objForwardToAsForWhome = ForwardTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'forwardtoasforwhome__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ForwardToAsForwardedTo Virtual Binding
			$strAlias = $strAliasPrefix . 'forwardtoasforwardedto__idforward_to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objForwardToAsForwardedToArray)
				$objToReturn->_objForwardToAsForwardedToArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objForwardToAsForwardedToArray[] = ForwardTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'forwardtoasforwardedto__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objForwardToAsForwardedTo = ForwardTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'forwardtoasforwardedto__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for GradeCardAsStudent Virtual Binding
			$strAlias = $strAliasPrefix . 'gradecardasstudent__idgrade_card';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objGradeCardAsStudentArray)
				$objToReturn->_objGradeCardAsStudentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objGradeCardAsStudentArray[] = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objGradeCardAsStudent = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for GradeCardAsChangeInEseBy Virtual Binding
			$strAlias = $strAliasPrefix . 'gradecardaschangeineseby__idgrade_card';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objGradeCardAsChangeInEseByArray)
				$objToReturn->_objGradeCardAsChangeInEseByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objGradeCardAsChangeInEseByArray[] = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardaschangeineseby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objGradeCardAsChangeInEseBy = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardaschangeineseby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for IssuedItemsAsMember Virtual Binding
			$strAlias = $strAliasPrefix . 'issueditemsasmember__idissued_items';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objIssuedItemsAsMemberArray)
				$objToReturn->_objIssuedItemsAsMemberArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objIssuedItemsAsMemberArray[] = IssuedItems::InstantiateDbRow($objDbRow, $strAliasPrefix . 'issueditemsasmember__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objIssuedItemsAsMember = IssuedItems::InstantiateDbRow($objDbRow, $strAliasPrefix . 'issueditemsasmember__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for IwowAsDataBy Virtual Binding
			$strAlias = $strAliasPrefix . 'iwowasdataby__idiwow';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objIwowAsDataByArray)
				$objToReturn->_objIwowAsDataByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objIwowAsDataByArray[] = Iwow::InstantiateDbRow($objDbRow, $strAliasPrefix . 'iwowasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objIwowAsDataBy = Iwow::InstantiateDbRow($objDbRow, $strAliasPrefix . 'iwowasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for IwowAsInspectedBy Virtual Binding
			$strAlias = $strAliasPrefix . 'iwowasinspectedby__idiwow';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objIwowAsInspectedByArray)
				$objToReturn->_objIwowAsInspectedByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objIwowAsInspectedByArray[] = Iwow::InstantiateDbRow($objDbRow, $strAliasPrefix . 'iwowasinspectedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objIwowAsInspectedBy = Iwow::InstantiateDbRow($objDbRow, $strAliasPrefix . 'iwowasinspectedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for LeaveBalanceAsMember Virtual Binding
			$strAlias = $strAliasPrefix . 'leavebalanceasmember__idleave_balance';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objLeaveBalanceAsMemberArray)
				$objToReturn->_objLeaveBalanceAsMemberArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objLeaveBalanceAsMemberArray[] = LeaveBalance::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavebalanceasmember__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objLeaveBalanceAsMember = LeaveBalance::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavebalanceasmember__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for LogAsDataBy Virtual Binding
			$strAlias = $strAliasPrefix . 'logasdataby__idlog';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objLogAsDataByArray)
				$objToReturn->_objLogAsDataByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objLogAsDataByArray[] = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objLogAsDataBy = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for LoginHasRoleAsId Virtual Binding
			$strAlias = $strAliasPrefix . 'loginhasroleasid__login_idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objLoginHasRoleAsIdArray)
				$objToReturn->_objLoginHasRoleAsIdArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objLoginHasRoleAsIdArray[] = LoginHasRole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'loginhasroleasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objLoginHasRoleAsId = LoginHasRole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'loginhasroleasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for MarkToAsTo Virtual Binding
			$strAlias = $strAliasPrefix . 'marktoasto__idmark_to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objMarkToAsToArray)
				$objToReturn->_objMarkToAsToArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objMarkToAsToArray[] = MarkTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'marktoasto__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objMarkToAsTo = MarkTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'marktoasto__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for MarkToAsFrom Virtual Binding
			$strAlias = $strAliasPrefix . 'marktoasfrom__idmark_to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objMarkToAsFromArray)
				$objToReturn->_objMarkToAsFromArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objMarkToAsFromArray[] = MarkTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'marktoasfrom__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objMarkToAsFrom = MarkTo::InstantiateDbRow($objDbRow, $strAliasPrefix . 'marktoasfrom__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for MeetingAgendaPoleAsAttendees Virtual Binding
			$strAlias = $strAliasPrefix . 'meetingagendapoleasattendees__idmeeting_agenda_pole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objMeetingAgendaPoleAsAttendeesArray)
				$objToReturn->_objMeetingAgendaPoleAsAttendeesArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objMeetingAgendaPoleAsAttendeesArray[] = MeetingAgendaPole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingagendapoleasattendees__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objMeetingAgendaPoleAsAttendees = MeetingAgendaPole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingagendapoleasattendees__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for MeetingGroupHasMembersAsMember Virtual Binding
			$strAlias = $strAliasPrefix . 'meetinggrouphasmembersasmember__idmeeting_group_has_members';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objMeetingGroupHasMembersAsMemberArray)
				$objToReturn->_objMeetingGroupHasMembersAsMemberArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objMeetingGroupHasMembersAsMemberArray[] = MeetingGroupHasMembers::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetinggrouphasmembersasmember__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objMeetingGroupHasMembersAsMember = MeetingGroupHasMembers::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetinggrouphasmembersasmember__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for MeetingNotesAsReferedBy Virtual Binding
			$strAlias = $strAliasPrefix . 'meetingnotesasreferedby__idmeeting_notes';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objMeetingNotesAsReferedByArray)
				$objToReturn->_objMeetingNotesAsReferedByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objMeetingNotesAsReferedByArray[] = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasreferedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objMeetingNotesAsReferedBy = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasreferedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for MeetingNotesAsActionOn Virtual Binding
			$strAlias = $strAliasPrefix . 'meetingnotesasactionon__idmeeting_notes';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objMeetingNotesAsActionOnArray)
				$objToReturn->_objMeetingNotesAsActionOnArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objMeetingNotesAsActionOnArray[] = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasactionon__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objMeetingNotesAsActionOn = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasactionon__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for NoteAsDataby Virtual Binding
			$strAlias = $strAliasPrefix . 'noteasdataby__idnote';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objNoteAsDatabyArray)
				$objToReturn->_objNoteAsDatabyArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objNoteAsDatabyArray[] = Note::InstantiateDbRow($objDbRow, $strAliasPrefix . 'noteasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objNoteAsDataby = Note::InstantiateDbRow($objDbRow, $strAliasPrefix . 'noteasdataby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ReEvaluationAsStudent Virtual Binding
			$strAlias = $strAliasPrefix . 'reevaluationasstudent__idre_evaluation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objReEvaluationAsStudentArray)
				$objToReturn->_objReEvaluationAsStudentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objReEvaluationAsStudentArray[] = ReEvaluation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'reevaluationasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objReEvaluationAsStudent = ReEvaluation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'reevaluationasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for SalarysheetApprovalAsApprovedBy Virtual Binding
			$strAlias = $strAliasPrefix . 'salarysheetapprovalasapprovedby__idsalarysheet_approval';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objSalarysheetApprovalAsApprovedByArray)
				$objToReturn->_objSalarysheetApprovalAsApprovedByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objSalarysheetApprovalAsApprovedByArray[] = SalarysheetApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarysheetapprovalasapprovedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objSalarysheetApprovalAsApprovedBy = SalarysheetApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarysheetapprovalasapprovedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for SignPatch Virtual Binding
			$strAlias = $strAliasPrefix . 'signpatch__idsign_patch';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objSignPatchArray)
				$objToReturn->_objSignPatchArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objSignPatchArray[] = SignPatch::InstantiateDbRow($objDbRow, $strAliasPrefix . 'signpatch__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objSignPatch = SignPatch::InstantiateDbRow($objDbRow, $strAliasPrefix . 'signpatch__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for StudAttendenceAsStudent Virtual Binding
			$strAlias = $strAliasPrefix . 'studattendenceasstudent__idstud_attendence';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objStudAttendenceAsStudentArray)
				$objToReturn->_objStudAttendenceAsStudentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objStudAttendenceAsStudentArray[] = StudAttendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'studattendenceasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objStudAttendenceAsStudent = StudAttendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'studattendenceasstudent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for StudAttendenceAsStaff Virtual Binding
			$strAlias = $strAliasPrefix . 'studattendenceasstaff__idstud_attendence';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objStudAttendenceAsStaffArray)
				$objToReturn->_objStudAttendenceAsStaffArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objStudAttendenceAsStaffArray[] = StudAttendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'studattendenceasstaff__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objStudAttendenceAsStaff = StudAttendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'studattendenceasstaff__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for SubjectTought Virtual Binding
			$strAlias = $strAliasPrefix . 'subjecttought__idsubject_tought';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objSubjectToughtArray)
				$objToReturn->_objSubjectToughtArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objSubjectToughtArray[] = SubjectTought::InstantiateDbRow($objDbRow, $strAliasPrefix . 'subjecttought__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objSubjectTought = SubjectTought::InstantiateDbRow($objDbRow, $strAliasPrefix . 'subjecttought__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for TimetableAsAttendant Virtual Binding
			$strAlias = $strAliasPrefix . 'timetableasattendant__idtimetable';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objTimetableAsAttendantArray)
				$objToReturn->_objTimetableAsAttendantArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objTimetableAsAttendantArray[] = Timetable::InstantiateDbRow($objDbRow, $strAliasPrefix . 'timetableasattendant__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objTimetableAsAttendant = Timetable::InstantiateDbRow($objDbRow, $strAliasPrefix . 'timetableasattendant__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for VisitorPassAsForWhome Virtual Binding
			$strAlias = $strAliasPrefix . 'visitorpassasforwhome__idvisitor_pass';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objVisitorPassAsForWhomeArray)
				$objToReturn->_objVisitorPassAsForWhomeArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objVisitorPassAsForWhomeArray[] = VisitorPass::InstantiateDbRow($objDbRow, $strAliasPrefix . 'visitorpassasforwhome__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objVisitorPassAsForWhome = VisitorPass::InstantiateDbRow($objDbRow, $strAliasPrefix . 'visitorpassasforwhome__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for VoucherAsApprovedBy Virtual Binding
			$strAlias = $strAliasPrefix . 'voucherasapprovedby__idvoucher';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objVoucherAsApprovedByArray)
				$objToReturn->_objVoucherAsApprovedByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objVoucherAsApprovedByArray[] = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasapprovedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objVoucherAsApprovedBy = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherasapprovedby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for VoucherAsCancelBy Virtual Binding
			$strAlias = $strAliasPrefix . 'voucherascancelby__idvoucher';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objVoucherAsCancelByArray)
				$objToReturn->_objVoucherAsCancelByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objVoucherAsCancelByArray[] = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherascancelby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objVoucherAsCancelBy = Voucher::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherascancelby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Logins from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Login[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Login::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Login::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Login object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Login next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Login::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Login object,
		 * by Idlogin Index(es)
		 * @param integer $intIdlogin
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Login
		*/
		public static function LoadByIdlogin($intIdlogin, $objOptionalClauses = null) {
			return Login::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Login()->Idlogin, $intIdlogin)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single Login object,
		 * by Username Index(es)
		 * @param string $strUsername
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Login
		*/
		public static function LoadByUsername($strUsername, $objOptionalClauses = null) {
			return Login::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Login()->Username, $strUsername)
				),
				$objOptionalClauses
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Login
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return void
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `login` (
							`idlogin`,
							`username`,
							`password`,
							`is_enabled`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intIdlogin) . ',
							' . $objDatabase->SqlVariable($this->strUsername) . ',
							' . $objDatabase->SqlVariable($this->strPassword) . ',
							' . $objDatabase->SqlVariable($this->blnIsEnabled) . '
						)
					');


				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`login`
						SET
							`idlogin` = ' . $objDatabase->SqlVariable($this->intIdlogin) . ',
							`username` = ' . $objDatabase->SqlVariable($this->strUsername) . ',
							`password` = ' . $objDatabase->SqlVariable($this->strPassword) . ',
							`is_enabled` = ' . $objDatabase->SqlVariable($this->blnIsEnabled) . '
						WHERE
							`idlogin` = ' . $objDatabase->SqlVariable($this->__intIdlogin) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;
			$this->__intIdlogin = $this->intIdlogin;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Login
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Login with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`login`
				WHERE
					`idlogin` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Login ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Login', $this->intIdlogin);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Logins
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`login`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate login table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `login`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Login from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Login object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Login::Load($this->intIdlogin);

			// Update $this's local variables to match
			$this->Idlogin = $objReloaded->Idlogin;
			$this->__intIdlogin = $this->intIdlogin;
			$this->strUsername = $objReloaded->strUsername;
			$this->strPassword = $objReloaded->strPassword;
			$this->blnIsEnabled = $objReloaded->blnIsEnabled;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idlogin':
					/**
					 * Gets the value for intIdlogin (PK)
					 * @return integer
					 */
					return $this->intIdlogin;

				case 'Username':
					/**
					 * Gets the value for strUsername (Unique)
					 * @return string
					 */
					return $this->strUsername;

				case 'Password':
					/**
					 * Gets the value for strPassword 
					 * @return string
					 */
					return $this->strPassword;

				case 'IsEnabled':
					/**
					 * Gets the value for blnIsEnabled (Not Null)
					 * @return boolean
					 */
					return $this->blnIsEnabled;


				///////////////////
				// Member Objects
				///////////////////
				case 'IdloginObject':
					/**
					 * Gets the value for the Ledger object referenced by intIdlogin (PK)
					 * @return Ledger
					 */
					try {
						if ((!$this->objIdloginObject) && (!is_null($this->intIdlogin)))
							$this->objIdloginObject = Ledger::Load($this->intIdlogin);
						return $this->objIdloginObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_AppApprovalAsDecisionBy':
					/**
					 * Gets the value for the private _objAppApprovalAsDecisionBy (Read-Only)
					 * if set due to an expansion on the app_approval.decision_by reverse relationship
					 * @return AppApproval
					 */
					return $this->_objAppApprovalAsDecisionBy;

				case '_AppApprovalAsDecisionByArray':
					/**
					 * Gets the value for the private _objAppApprovalAsDecisionByArray (Read-Only)
					 * if set due to an ExpandAsArray on the app_approval.decision_by reverse relationship
					 * @return AppApproval[]
					 */
					return $this->_objAppApprovalAsDecisionByArray;

				case '_AppDocsAsMember':
					/**
					 * Gets the value for the private _objAppDocsAsMember (Read-Only)
					 * if set due to an expansion on the app_docs.member reverse relationship
					 * @return AppDocs
					 */
					return $this->_objAppDocsAsMember;

				case '_AppDocsAsMemberArray':
					/**
					 * Gets the value for the private _objAppDocsAsMemberArray (Read-Only)
					 * if set due to an ExpandAsArray on the app_docs.member reverse relationship
					 * @return AppDocs[]
					 */
					return $this->_objAppDocsAsMemberArray;

				case '_ApplicationAsDataEntryBy':
					/**
					 * Gets the value for the private _objApplicationAsDataEntryBy (Read-Only)
					 * if set due to an expansion on the application.data_entry_by reverse relationship
					 * @return Application
					 */
					return $this->_objApplicationAsDataEntryBy;

				case '_ApplicationAsDataEntryByArray':
					/**
					 * Gets the value for the private _objApplicationAsDataEntryByArray (Read-Only)
					 * if set due to an ExpandAsArray on the application.data_entry_by reverse relationship
					 * @return Application[]
					 */
					return $this->_objApplicationAsDataEntryByArray;

				case '_ApplicationAsCertificateIssueBy':
					/**
					 * Gets the value for the private _objApplicationAsCertificateIssueBy (Read-Only)
					 * if set due to an expansion on the application.certificate_issue_by reverse relationship
					 * @return Application
					 */
					return $this->_objApplicationAsCertificateIssueBy;

				case '_ApplicationAsCertificateIssueByArray':
					/**
					 * Gets the value for the private _objApplicationAsCertificateIssueByArray (Read-Only)
					 * if set due to an ExpandAsArray on the application.certificate_issue_by reverse relationship
					 * @return Application[]
					 */
					return $this->_objApplicationAsCertificateIssueByArray;

				case '_ApplicationAsSubstitute':
					/**
					 * Gets the value for the private _objApplicationAsSubstitute (Read-Only)
					 * if set due to an expansion on the application.substitute reverse relationship
					 * @return Application
					 */
					return $this->_objApplicationAsSubstitute;

				case '_ApplicationAsSubstituteArray':
					/**
					 * Gets the value for the private _objApplicationAsSubstituteArray (Read-Only)
					 * if set due to an ExpandAsArray on the application.substitute reverse relationship
					 * @return Application[]
					 */
					return $this->_objApplicationAsSubstituteArray;

				case '_AppliedExamAsStudent':
					/**
					 * Gets the value for the private _objAppliedExamAsStudent (Read-Only)
					 * if set due to an expansion on the applied_exam.student reverse relationship
					 * @return AppliedExam
					 */
					return $this->_objAppliedExamAsStudent;

				case '_AppliedExamAsStudentArray':
					/**
					 * Gets the value for the private _objAppliedExamAsStudentArray (Read-Only)
					 * if set due to an ExpandAsArray on the applied_exam.student reverse relationship
					 * @return AppliedExam[]
					 */
					return $this->_objAppliedExamAsStudentArray;

				case '_ApplyGradeImpromentAsStudent':
					/**
					 * Gets the value for the private _objApplyGradeImpromentAsStudent (Read-Only)
					 * if set due to an expansion on the apply_grade_improment.student reverse relationship
					 * @return ApplyGradeImproment
					 */
					return $this->_objApplyGradeImpromentAsStudent;

				case '_ApplyGradeImpromentAsStudentArray':
					/**
					 * Gets the value for the private _objApplyGradeImpromentAsStudentArray (Read-Only)
					 * if set due to an ExpandAsArray on the apply_grade_improment.student reverse relationship
					 * @return ApplyGradeImproment[]
					 */
					return $this->_objApplyGradeImpromentAsStudentArray;

				case '_ApplyGradeImpromentAsAppliedBy':
					/**
					 * Gets the value for the private _objApplyGradeImpromentAsAppliedBy (Read-Only)
					 * if set due to an expansion on the apply_grade_improment.applied_by reverse relationship
					 * @return ApplyGradeImproment
					 */
					return $this->_objApplyGradeImpromentAsAppliedBy;

				case '_ApplyGradeImpromentAsAppliedByArray':
					/**
					 * Gets the value for the private _objApplyGradeImpromentAsAppliedByArray (Read-Only)
					 * if set due to an ExpandAsArray on the apply_grade_improment.applied_by reverse relationship
					 * @return ApplyGradeImproment[]
					 */
					return $this->_objApplyGradeImpromentAsAppliedByArray;

				case '_AttendenceAsStaff':
					/**
					 * Gets the value for the private _objAttendenceAsStaff (Read-Only)
					 * if set due to an expansion on the attendence.staff reverse relationship
					 * @return Attendence
					 */
					return $this->_objAttendenceAsStaff;

				case '_AttendenceAsStaffArray':
					/**
					 * Gets the value for the private _objAttendenceAsStaffArray (Read-Only)
					 * if set due to an ExpandAsArray on the attendence.staff reverse relationship
					 * @return Attendence[]
					 */
					return $this->_objAttendenceAsStaffArray;

				case '_CertificateDepositeAsVerifyBy':
					/**
					 * Gets the value for the private _objCertificateDepositeAsVerifyBy (Read-Only)
					 * if set due to an expansion on the certificate_deposite.verify_by reverse relationship
					 * @return CertificateDeposite
					 */
					return $this->_objCertificateDepositeAsVerifyBy;

				case '_CertificateDepositeAsVerifyByArray':
					/**
					 * Gets the value for the private _objCertificateDepositeAsVerifyByArray (Read-Only)
					 * if set due to an ExpandAsArray on the certificate_deposite.verify_by reverse relationship
					 * @return CertificateDeposite[]
					 */
					return $this->_objCertificateDepositeAsVerifyByArray;

				case '_CertificateDepositeAsReturnBy':
					/**
					 * Gets the value for the private _objCertificateDepositeAsReturnBy (Read-Only)
					 * if set due to an expansion on the certificate_deposite.return_by reverse relationship
					 * @return CertificateDeposite
					 */
					return $this->_objCertificateDepositeAsReturnBy;

				case '_CertificateDepositeAsReturnByArray':
					/**
					 * Gets the value for the private _objCertificateDepositeAsReturnByArray (Read-Only)
					 * if set due to an ExpandAsArray on the certificate_deposite.return_by reverse relationship
					 * @return CertificateDeposite[]
					 */
					return $this->_objCertificateDepositeAsReturnByArray;

				case '_CirculationAsDataBy':
					/**
					 * Gets the value for the private _objCirculationAsDataBy (Read-Only)
					 * if set due to an expansion on the circulation.data_by reverse relationship
					 * @return Circulation
					 */
					return $this->_objCirculationAsDataBy;

				case '_CirculationAsDataByArray':
					/**
					 * Gets the value for the private _objCirculationAsDataByArray (Read-Only)
					 * if set due to an ExpandAsArray on the circulation.data_by reverse relationship
					 * @return Circulation[]
					 */
					return $this->_objCirculationAsDataByArray;

				case '_CirculationAsStaffStud':
					/**
					 * Gets the value for the private _objCirculationAsStaffStud (Read-Only)
					 * if set due to an expansion on the circulation.staff_stud reverse relationship
					 * @return Circulation
					 */
					return $this->_objCirculationAsStaffStud;

				case '_CirculationAsStaffStudArray':
					/**
					 * Gets the value for the private _objCirculationAsStaffStudArray (Read-Only)
					 * if set due to an ExpandAsArray on the circulation.staff_stud reverse relationship
					 * @return Circulation[]
					 */
					return $this->_objCirculationAsStaffStudArray;

				case '_CurrentStatusAsStudent':
					/**
					 * Gets the value for the private _objCurrentStatusAsStudent (Read-Only)
					 * if set due to an expansion on the current_status.student reverse relationship
					 * @return CurrentStatus
					 */
					return $this->_objCurrentStatusAsStudent;

				case '_CurrentStatusAsStudentArray':
					/**
					 * Gets the value for the private _objCurrentStatusAsStudentArray (Read-Only)
					 * if set due to an ExpandAsArray on the current_status.student reverse relationship
					 * @return CurrentStatus[]
					 */
					return $this->_objCurrentStatusAsStudentArray;

				case '_DeptYearEventsAsIntiator':
					/**
					 * Gets the value for the private _objDeptYearEventsAsIntiator (Read-Only)
					 * if set due to an expansion on the dept_year_events.intiator reverse relationship
					 * @return DeptYearEvents
					 */
					return $this->_objDeptYearEventsAsIntiator;

				case '_DeptYearEventsAsIntiatorArray':
					/**
					 * Gets the value for the private _objDeptYearEventsAsIntiatorArray (Read-Only)
					 * if set due to an ExpandAsArray on the dept_year_events.intiator reverse relationship
					 * @return DeptYearEvents[]
					 */
					return $this->_objDeptYearEventsAsIntiatorArray;

				case '_DeptYearEventsAsOwner':
					/**
					 * Gets the value for the private _objDeptYearEventsAsOwner (Read-Only)
					 * if set due to an expansion on the dept_year_events.owner reverse relationship
					 * @return DeptYearEvents
					 */
					return $this->_objDeptYearEventsAsOwner;

				case '_DeptYearEventsAsOwnerArray':
					/**
					 * Gets the value for the private _objDeptYearEventsAsOwnerArray (Read-Only)
					 * if set due to an ExpandAsArray on the dept_year_events.owner reverse relationship
					 * @return DeptYearEvents[]
					 */
					return $this->_objDeptYearEventsAsOwnerArray;

				case '_DocInOutAsInwordBy':
					/**
					 * Gets the value for the private _objDocInOutAsInwordBy (Read-Only)
					 * if set due to an expansion on the doc_in_out.inword_by reverse relationship
					 * @return DocInOut
					 */
					return $this->_objDocInOutAsInwordBy;

				case '_DocInOutAsInwordByArray':
					/**
					 * Gets the value for the private _objDocInOutAsInwordByArray (Read-Only)
					 * if set due to an ExpandAsArray on the doc_in_out.inword_by reverse relationship
					 * @return DocInOut[]
					 */
					return $this->_objDocInOutAsInwordByArray;

				case '_ECourseAsTeacher':
					/**
					 * Gets the value for the private _objECourseAsTeacher (Read-Only)
					 * if set due to an expansion on the e_course.teacher_id reverse relationship
					 * @return ECourse
					 */
					return $this->_objECourseAsTeacher;

				case '_ECourseAsTeacherArray':
					/**
					 * Gets the value for the private _objECourseAsTeacherArray (Read-Only)
					 * if set due to an ExpandAsArray on the e_course.teacher_id reverse relationship
					 * @return ECourse[]
					 */
					return $this->_objECourseAsTeacherArray;

				case '_EStudentAsStudent':
					/**
					 * Gets the value for the private _objEStudentAsStudent (Read-Only)
					 * if set due to an expansion on the e_student.student reverse relationship
					 * @return EStudent
					 */
					return $this->_objEStudentAsStudent;

				case '_EStudentAsStudentArray':
					/**
					 * Gets the value for the private _objEStudentAsStudentArray (Read-Only)
					 * if set due to an ExpandAsArray on the e_student.student reverse relationship
					 * @return EStudent[]
					 */
					return $this->_objEStudentAsStudentArray;

				case '_ETicketAsRaisedBy':
					/**
					 * Gets the value for the private _objETicketAsRaisedBy (Read-Only)
					 * if set due to an expansion on the e_ticket.raised_by reverse relationship
					 * @return ETicket
					 */
					return $this->_objETicketAsRaisedBy;

				case '_ETicketAsRaisedByArray':
					/**
					 * Gets the value for the private _objETicketAsRaisedByArray (Read-Only)
					 * if set due to an ExpandAsArray on the e_ticket.raised_by reverse relationship
					 * @return ETicket[]
					 */
					return $this->_objETicketAsRaisedByArray;

				case '_Establishment':
					/**
					 * Gets the value for the private _objEstablishment (Read-Only)
					 * if set due to an expansion on the establishment.login reverse relationship
					 * @return Establishment
					 */
					return $this->_objEstablishment;

				case '_EstablishmentArray':
					/**
					 * Gets the value for the private _objEstablishmentArray (Read-Only)
					 * if set due to an ExpandAsArray on the establishment.login reverse relationship
					 * @return Establishment[]
					 */
					return $this->_objEstablishmentArray;

				case '_EventHasAttendentAsAttendent':
					/**
					 * Gets the value for the private _objEventHasAttendentAsAttendent (Read-Only)
					 * if set due to an expansion on the event_has_attendent.attendent reverse relationship
					 * @return EventHasAttendent
					 */
					return $this->_objEventHasAttendentAsAttendent;

				case '_EventHasAttendentAsAttendentArray':
					/**
					 * Gets the value for the private _objEventHasAttendentAsAttendentArray (Read-Only)
					 * if set due to an ExpandAsArray on the event_has_attendent.attendent reverse relationship
					 * @return EventHasAttendent[]
					 */
					return $this->_objEventHasAttendentAsAttendentArray;

				case '_ExampaperAsSetBy':
					/**
					 * Gets the value for the private _objExampaperAsSetBy (Read-Only)
					 * if set due to an expansion on the exampaper.set_by reverse relationship
					 * @return Exampaper
					 */
					return $this->_objExampaperAsSetBy;

				case '_ExampaperAsSetByArray':
					/**
					 * Gets the value for the private _objExampaperAsSetByArray (Read-Only)
					 * if set due to an ExpandAsArray on the exampaper.set_by reverse relationship
					 * @return Exampaper[]
					 */
					return $this->_objExampaperAsSetByArray;

				case '_ForwardToAsForWhome':
					/**
					 * Gets the value for the private _objForwardToAsForWhome (Read-Only)
					 * if set due to an expansion on the forward_to.for_whome reverse relationship
					 * @return ForwardTo
					 */
					return $this->_objForwardToAsForWhome;

				case '_ForwardToAsForWhomeArray':
					/**
					 * Gets the value for the private _objForwardToAsForWhomeArray (Read-Only)
					 * if set due to an ExpandAsArray on the forward_to.for_whome reverse relationship
					 * @return ForwardTo[]
					 */
					return $this->_objForwardToAsForWhomeArray;

				case '_ForwardToAsForwardedTo':
					/**
					 * Gets the value for the private _objForwardToAsForwardedTo (Read-Only)
					 * if set due to an expansion on the forward_to.forwarded_to reverse relationship
					 * @return ForwardTo
					 */
					return $this->_objForwardToAsForwardedTo;

				case '_ForwardToAsForwardedToArray':
					/**
					 * Gets the value for the private _objForwardToAsForwardedToArray (Read-Only)
					 * if set due to an ExpandAsArray on the forward_to.forwarded_to reverse relationship
					 * @return ForwardTo[]
					 */
					return $this->_objForwardToAsForwardedToArray;

				case '_GradeCardAsStudent':
					/**
					 * Gets the value for the private _objGradeCardAsStudent (Read-Only)
					 * if set due to an expansion on the grade_card.student reverse relationship
					 * @return GradeCard
					 */
					return $this->_objGradeCardAsStudent;

				case '_GradeCardAsStudentArray':
					/**
					 * Gets the value for the private _objGradeCardAsStudentArray (Read-Only)
					 * if set due to an ExpandAsArray on the grade_card.student reverse relationship
					 * @return GradeCard[]
					 */
					return $this->_objGradeCardAsStudentArray;

				case '_GradeCardAsChangeInEseBy':
					/**
					 * Gets the value for the private _objGradeCardAsChangeInEseBy (Read-Only)
					 * if set due to an expansion on the grade_card.change_in_ese_by reverse relationship
					 * @return GradeCard
					 */
					return $this->_objGradeCardAsChangeInEseBy;

				case '_GradeCardAsChangeInEseByArray':
					/**
					 * Gets the value for the private _objGradeCardAsChangeInEseByArray (Read-Only)
					 * if set due to an ExpandAsArray on the grade_card.change_in_ese_by reverse relationship
					 * @return GradeCard[]
					 */
					return $this->_objGradeCardAsChangeInEseByArray;

				case '_IssuedItemsAsMember':
					/**
					 * Gets the value for the private _objIssuedItemsAsMember (Read-Only)
					 * if set due to an expansion on the issued_items.member reverse relationship
					 * @return IssuedItems
					 */
					return $this->_objIssuedItemsAsMember;

				case '_IssuedItemsAsMemberArray':
					/**
					 * Gets the value for the private _objIssuedItemsAsMemberArray (Read-Only)
					 * if set due to an ExpandAsArray on the issued_items.member reverse relationship
					 * @return IssuedItems[]
					 */
					return $this->_objIssuedItemsAsMemberArray;

				case '_IwowAsDataBy':
					/**
					 * Gets the value for the private _objIwowAsDataBy (Read-Only)
					 * if set due to an expansion on the iwow.data_by reverse relationship
					 * @return Iwow
					 */
					return $this->_objIwowAsDataBy;

				case '_IwowAsDataByArray':
					/**
					 * Gets the value for the private _objIwowAsDataByArray (Read-Only)
					 * if set due to an ExpandAsArray on the iwow.data_by reverse relationship
					 * @return Iwow[]
					 */
					return $this->_objIwowAsDataByArray;

				case '_IwowAsInspectedBy':
					/**
					 * Gets the value for the private _objIwowAsInspectedBy (Read-Only)
					 * if set due to an expansion on the iwow.inspected_by reverse relationship
					 * @return Iwow
					 */
					return $this->_objIwowAsInspectedBy;

				case '_IwowAsInspectedByArray':
					/**
					 * Gets the value for the private _objIwowAsInspectedByArray (Read-Only)
					 * if set due to an ExpandAsArray on the iwow.inspected_by reverse relationship
					 * @return Iwow[]
					 */
					return $this->_objIwowAsInspectedByArray;

				case '_LeaveBalanceAsMember':
					/**
					 * Gets the value for the private _objLeaveBalanceAsMember (Read-Only)
					 * if set due to an expansion on the leave_balance.member reverse relationship
					 * @return LeaveBalance
					 */
					return $this->_objLeaveBalanceAsMember;

				case '_LeaveBalanceAsMemberArray':
					/**
					 * Gets the value for the private _objLeaveBalanceAsMemberArray (Read-Only)
					 * if set due to an ExpandAsArray on the leave_balance.member reverse relationship
					 * @return LeaveBalance[]
					 */
					return $this->_objLeaveBalanceAsMemberArray;

				case '_LogAsDataBy':
					/**
					 * Gets the value for the private _objLogAsDataBy (Read-Only)
					 * if set due to an expansion on the log.data_by reverse relationship
					 * @return Log
					 */
					return $this->_objLogAsDataBy;

				case '_LogAsDataByArray':
					/**
					 * Gets the value for the private _objLogAsDataByArray (Read-Only)
					 * if set due to an ExpandAsArray on the log.data_by reverse relationship
					 * @return Log[]
					 */
					return $this->_objLogAsDataByArray;

				case '_LoginHasRoleAsId':
					/**
					 * Gets the value for the private _objLoginHasRoleAsId (Read-Only)
					 * if set due to an expansion on the login_has_role.login_idlogin reverse relationship
					 * @return LoginHasRole
					 */
					return $this->_objLoginHasRoleAsId;

				case '_LoginHasRoleAsIdArray':
					/**
					 * Gets the value for the private _objLoginHasRoleAsIdArray (Read-Only)
					 * if set due to an ExpandAsArray on the login_has_role.login_idlogin reverse relationship
					 * @return LoginHasRole[]
					 */
					return $this->_objLoginHasRoleAsIdArray;

				case '_MarkToAsTo':
					/**
					 * Gets the value for the private _objMarkToAsTo (Read-Only)
					 * if set due to an expansion on the mark_to.to reverse relationship
					 * @return MarkTo
					 */
					return $this->_objMarkToAsTo;

				case '_MarkToAsToArray':
					/**
					 * Gets the value for the private _objMarkToAsToArray (Read-Only)
					 * if set due to an ExpandAsArray on the mark_to.to reverse relationship
					 * @return MarkTo[]
					 */
					return $this->_objMarkToAsToArray;

				case '_MarkToAsFrom':
					/**
					 * Gets the value for the private _objMarkToAsFrom (Read-Only)
					 * if set due to an expansion on the mark_to.from reverse relationship
					 * @return MarkTo
					 */
					return $this->_objMarkToAsFrom;

				case '_MarkToAsFromArray':
					/**
					 * Gets the value for the private _objMarkToAsFromArray (Read-Only)
					 * if set due to an ExpandAsArray on the mark_to.from reverse relationship
					 * @return MarkTo[]
					 */
					return $this->_objMarkToAsFromArray;

				case '_MeetingAgendaPoleAsAttendees':
					/**
					 * Gets the value for the private _objMeetingAgendaPoleAsAttendees (Read-Only)
					 * if set due to an expansion on the meeting_agenda_pole.attendees reverse relationship
					 * @return MeetingAgendaPole
					 */
					return $this->_objMeetingAgendaPoleAsAttendees;

				case '_MeetingAgendaPoleAsAttendeesArray':
					/**
					 * Gets the value for the private _objMeetingAgendaPoleAsAttendeesArray (Read-Only)
					 * if set due to an ExpandAsArray on the meeting_agenda_pole.attendees reverse relationship
					 * @return MeetingAgendaPole[]
					 */
					return $this->_objMeetingAgendaPoleAsAttendeesArray;

				case '_MeetingGroupHasMembersAsMember':
					/**
					 * Gets the value for the private _objMeetingGroupHasMembersAsMember (Read-Only)
					 * if set due to an expansion on the meeting_group_has_members.member reverse relationship
					 * @return MeetingGroupHasMembers
					 */
					return $this->_objMeetingGroupHasMembersAsMember;

				case '_MeetingGroupHasMembersAsMemberArray':
					/**
					 * Gets the value for the private _objMeetingGroupHasMembersAsMemberArray (Read-Only)
					 * if set due to an ExpandAsArray on the meeting_group_has_members.member reverse relationship
					 * @return MeetingGroupHasMembers[]
					 */
					return $this->_objMeetingGroupHasMembersAsMemberArray;

				case '_MeetingNotesAsReferedBy':
					/**
					 * Gets the value for the private _objMeetingNotesAsReferedBy (Read-Only)
					 * if set due to an expansion on the meeting_notes.refered_by reverse relationship
					 * @return MeetingNotes
					 */
					return $this->_objMeetingNotesAsReferedBy;

				case '_MeetingNotesAsReferedByArray':
					/**
					 * Gets the value for the private _objMeetingNotesAsReferedByArray (Read-Only)
					 * if set due to an ExpandAsArray on the meeting_notes.refered_by reverse relationship
					 * @return MeetingNotes[]
					 */
					return $this->_objMeetingNotesAsReferedByArray;

				case '_MeetingNotesAsActionOn':
					/**
					 * Gets the value for the private _objMeetingNotesAsActionOn (Read-Only)
					 * if set due to an expansion on the meeting_notes.action_on reverse relationship
					 * @return MeetingNotes
					 */
					return $this->_objMeetingNotesAsActionOn;

				case '_MeetingNotesAsActionOnArray':
					/**
					 * Gets the value for the private _objMeetingNotesAsActionOnArray (Read-Only)
					 * if set due to an ExpandAsArray on the meeting_notes.action_on reverse relationship
					 * @return MeetingNotes[]
					 */
					return $this->_objMeetingNotesAsActionOnArray;

				case '_NoteAsDataby':
					/**
					 * Gets the value for the private _objNoteAsDataby (Read-Only)
					 * if set due to an expansion on the note.databy reverse relationship
					 * @return Note
					 */
					return $this->_objNoteAsDataby;

				case '_NoteAsDatabyArray':
					/**
					 * Gets the value for the private _objNoteAsDatabyArray (Read-Only)
					 * if set due to an ExpandAsArray on the note.databy reverse relationship
					 * @return Note[]
					 */
					return $this->_objNoteAsDatabyArray;

				case '_ReEvaluationAsStudent':
					/**
					 * Gets the value for the private _objReEvaluationAsStudent (Read-Only)
					 * if set due to an expansion on the re_evaluation.student reverse relationship
					 * @return ReEvaluation
					 */
					return $this->_objReEvaluationAsStudent;

				case '_ReEvaluationAsStudentArray':
					/**
					 * Gets the value for the private _objReEvaluationAsStudentArray (Read-Only)
					 * if set due to an ExpandAsArray on the re_evaluation.student reverse relationship
					 * @return ReEvaluation[]
					 */
					return $this->_objReEvaluationAsStudentArray;

				case '_SalarysheetApprovalAsApprovedBy':
					/**
					 * Gets the value for the private _objSalarysheetApprovalAsApprovedBy (Read-Only)
					 * if set due to an expansion on the salarysheet_approval.approved_by reverse relationship
					 * @return SalarysheetApproval
					 */
					return $this->_objSalarysheetApprovalAsApprovedBy;

				case '_SalarysheetApprovalAsApprovedByArray':
					/**
					 * Gets the value for the private _objSalarysheetApprovalAsApprovedByArray (Read-Only)
					 * if set due to an ExpandAsArray on the salarysheet_approval.approved_by reverse relationship
					 * @return SalarysheetApproval[]
					 */
					return $this->_objSalarysheetApprovalAsApprovedByArray;

				case '_SignPatch':
					/**
					 * Gets the value for the private _objSignPatch (Read-Only)
					 * if set due to an expansion on the sign_patch.login reverse relationship
					 * @return SignPatch
					 */
					return $this->_objSignPatch;

				case '_SignPatchArray':
					/**
					 * Gets the value for the private _objSignPatchArray (Read-Only)
					 * if set due to an ExpandAsArray on the sign_patch.login reverse relationship
					 * @return SignPatch[]
					 */
					return $this->_objSignPatchArray;

				case '_StudAttendenceAsStudent':
					/**
					 * Gets the value for the private _objStudAttendenceAsStudent (Read-Only)
					 * if set due to an expansion on the stud_attendence.student reverse relationship
					 * @return StudAttendence
					 */
					return $this->_objStudAttendenceAsStudent;

				case '_StudAttendenceAsStudentArray':
					/**
					 * Gets the value for the private _objStudAttendenceAsStudentArray (Read-Only)
					 * if set due to an ExpandAsArray on the stud_attendence.student reverse relationship
					 * @return StudAttendence[]
					 */
					return $this->_objStudAttendenceAsStudentArray;

				case '_StudAttendenceAsStaff':
					/**
					 * Gets the value for the private _objStudAttendenceAsStaff (Read-Only)
					 * if set due to an expansion on the stud_attendence.staff reverse relationship
					 * @return StudAttendence
					 */
					return $this->_objStudAttendenceAsStaff;

				case '_StudAttendenceAsStaffArray':
					/**
					 * Gets the value for the private _objStudAttendenceAsStaffArray (Read-Only)
					 * if set due to an ExpandAsArray on the stud_attendence.staff reverse relationship
					 * @return StudAttendence[]
					 */
					return $this->_objStudAttendenceAsStaffArray;

				case '_SubjectTought':
					/**
					 * Gets the value for the private _objSubjectTought (Read-Only)
					 * if set due to an expansion on the subject_tought.login reverse relationship
					 * @return SubjectTought
					 */
					return $this->_objSubjectTought;

				case '_SubjectToughtArray':
					/**
					 * Gets the value for the private _objSubjectToughtArray (Read-Only)
					 * if set due to an ExpandAsArray on the subject_tought.login reverse relationship
					 * @return SubjectTought[]
					 */
					return $this->_objSubjectToughtArray;

				case '_TimetableAsAttendant':
					/**
					 * Gets the value for the private _objTimetableAsAttendant (Read-Only)
					 * if set due to an expansion on the timetable.attendant reverse relationship
					 * @return Timetable
					 */
					return $this->_objTimetableAsAttendant;

				case '_TimetableAsAttendantArray':
					/**
					 * Gets the value for the private _objTimetableAsAttendantArray (Read-Only)
					 * if set due to an ExpandAsArray on the timetable.attendant reverse relationship
					 * @return Timetable[]
					 */
					return $this->_objTimetableAsAttendantArray;

				case '_VisitorPassAsForWhome':
					/**
					 * Gets the value for the private _objVisitorPassAsForWhome (Read-Only)
					 * if set due to an expansion on the visitor_pass.for_whome reverse relationship
					 * @return VisitorPass
					 */
					return $this->_objVisitorPassAsForWhome;

				case '_VisitorPassAsForWhomeArray':
					/**
					 * Gets the value for the private _objVisitorPassAsForWhomeArray (Read-Only)
					 * if set due to an ExpandAsArray on the visitor_pass.for_whome reverse relationship
					 * @return VisitorPass[]
					 */
					return $this->_objVisitorPassAsForWhomeArray;

				case '_VoucherAsApprovedBy':
					/**
					 * Gets the value for the private _objVoucherAsApprovedBy (Read-Only)
					 * if set due to an expansion on the voucher.approved_by reverse relationship
					 * @return Voucher
					 */
					return $this->_objVoucherAsApprovedBy;

				case '_VoucherAsApprovedByArray':
					/**
					 * Gets the value for the private _objVoucherAsApprovedByArray (Read-Only)
					 * if set due to an ExpandAsArray on the voucher.approved_by reverse relationship
					 * @return Voucher[]
					 */
					return $this->_objVoucherAsApprovedByArray;

				case '_VoucherAsCancelBy':
					/**
					 * Gets the value for the private _objVoucherAsCancelBy (Read-Only)
					 * if set due to an expansion on the voucher.cancel_by reverse relationship
					 * @return Voucher
					 */
					return $this->_objVoucherAsCancelBy;

				case '_VoucherAsCancelByArray':
					/**
					 * Gets the value for the private _objVoucherAsCancelByArray (Read-Only)
					 * if set due to an ExpandAsArray on the voucher.cancel_by reverse relationship
					 * @return Voucher[]
					 */
					return $this->_objVoucherAsCancelByArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idlogin':
					/**
					 * Sets the value for intIdlogin (PK)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objIdloginObject = null;
						return ($this->intIdlogin = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Username':
					/**
					 * Sets the value for strUsername (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strUsername = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Password':
					/**
					 * Sets the value for strPassword 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strPassword = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'IsEnabled':
					/**
					 * Sets the value for blnIsEnabled (Not Null)
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnIsEnabled = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'IdloginObject':
					/**
					 * Sets the value for the Ledger object referenced by intIdlogin (PK)
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intIdlogin = null;
						$this->objIdloginObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved IdloginObject for this Login');

						// Update Local Member Variables
						$this->objIdloginObject = $mixValue;
						$this->intIdlogin = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for AppApprovalAsDecisionBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated AppApprovalsAsDecisionBy as an array of AppApproval objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppApproval[]
		*/
		public function GetAppApprovalAsDecisionByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return AppApproval::LoadArrayByDecisionBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated AppApprovalsAsDecisionBy
		 * @return int
		*/
		public function CountAppApprovalsAsDecisionBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return AppApproval::CountByDecisionBy($this->intIdlogin);
		}

		/**
		 * Associates a AppApprovalAsDecisionBy
		 * @param AppApproval $objAppApproval
		 * @return void
		*/
		public function AssociateAppApprovalAsDecisionBy(AppApproval $objAppApproval) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppApprovalAsDecisionBy on this unsaved Login.');
			if ((is_null($objAppApproval->IdappApproval)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppApprovalAsDecisionBy on this Login with an unsaved AppApproval.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`app_approval`
				SET
					`decision_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idapp_approval` = ' . $objDatabase->SqlVariable($objAppApproval->IdappApproval) . '
			');
		}

		/**
		 * Unassociates a AppApprovalAsDecisionBy
		 * @param AppApproval $objAppApproval
		 * @return void
		*/
		public function UnassociateAppApprovalAsDecisionBy(AppApproval $objAppApproval) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsDecisionBy on this unsaved Login.');
			if ((is_null($objAppApproval->IdappApproval)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsDecisionBy on this Login with an unsaved AppApproval.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`app_approval`
				SET
					`decision_by` = null
				WHERE
					`idapp_approval` = ' . $objDatabase->SqlVariable($objAppApproval->IdappApproval) . ' AND
					`decision_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all AppApprovalsAsDecisionBy
		 * @return void
		*/
		public function UnassociateAllAppApprovalsAsDecisionBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsDecisionBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`app_approval`
				SET
					`decision_by` = null
				WHERE
					`decision_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated AppApprovalAsDecisionBy
		 * @param AppApproval $objAppApproval
		 * @return void
		*/
		public function DeleteAssociatedAppApprovalAsDecisionBy(AppApproval $objAppApproval) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsDecisionBy on this unsaved Login.');
			if ((is_null($objAppApproval->IdappApproval)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsDecisionBy on this Login with an unsaved AppApproval.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`app_approval`
				WHERE
					`idapp_approval` = ' . $objDatabase->SqlVariable($objAppApproval->IdappApproval) . ' AND
					`decision_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated AppApprovalsAsDecisionBy
		 * @return void
		*/
		public function DeleteAllAppApprovalsAsDecisionBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppApprovalAsDecisionBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`app_approval`
				WHERE
					`decision_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for AppDocsAsMember
		//-------------------------------------------------------------------

		/**
		 * Gets all associated AppDocsesAsMember as an array of AppDocs objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppDocs[]
		*/
		public function GetAppDocsAsMemberArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return AppDocs::LoadArrayByMember($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated AppDocsesAsMember
		 * @return int
		*/
		public function CountAppDocsesAsMember() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return AppDocs::CountByMember($this->intIdlogin);
		}

		/**
		 * Associates a AppDocsAsMember
		 * @param AppDocs $objAppDocs
		 * @return void
		*/
		public function AssociateAppDocsAsMember(AppDocs $objAppDocs) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppDocsAsMember on this unsaved Login.');
			if ((is_null($objAppDocs->IdappDocs)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppDocsAsMember on this Login with an unsaved AppDocs.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`app_docs`
				SET
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idapp_docs` = ' . $objDatabase->SqlVariable($objAppDocs->IdappDocs) . '
			');
		}

		/**
		 * Unassociates a AppDocsAsMember
		 * @param AppDocs $objAppDocs
		 * @return void
		*/
		public function UnassociateAppDocsAsMember(AppDocs $objAppDocs) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppDocsAsMember on this unsaved Login.');
			if ((is_null($objAppDocs->IdappDocs)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppDocsAsMember on this Login with an unsaved AppDocs.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`app_docs`
				SET
					`member` = null
				WHERE
					`idapp_docs` = ' . $objDatabase->SqlVariable($objAppDocs->IdappDocs) . ' AND
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all AppDocsesAsMember
		 * @return void
		*/
		public function UnassociateAllAppDocsesAsMember() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppDocsAsMember on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`app_docs`
				SET
					`member` = null
				WHERE
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated AppDocsAsMember
		 * @param AppDocs $objAppDocs
		 * @return void
		*/
		public function DeleteAssociatedAppDocsAsMember(AppDocs $objAppDocs) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppDocsAsMember on this unsaved Login.');
			if ((is_null($objAppDocs->IdappDocs)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppDocsAsMember on this Login with an unsaved AppDocs.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`app_docs`
				WHERE
					`idapp_docs` = ' . $objDatabase->SqlVariable($objAppDocs->IdappDocs) . ' AND
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated AppDocsesAsMember
		 * @return void
		*/
		public function DeleteAllAppDocsesAsMember() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppDocsAsMember on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`app_docs`
				WHERE
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for ApplicationAsDataEntryBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ApplicationsAsDataEntryBy as an array of Application objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Application[]
		*/
		public function GetApplicationAsDataEntryByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Application::LoadArrayByDataEntryBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ApplicationsAsDataEntryBy
		 * @return int
		*/
		public function CountApplicationsAsDataEntryBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Application::CountByDataEntryBy($this->intIdlogin);
		}

		/**
		 * Associates a ApplicationAsDataEntryBy
		 * @param Application $objApplication
		 * @return void
		*/
		public function AssociateApplicationAsDataEntryBy(Application $objApplication) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplicationAsDataEntryBy on this unsaved Login.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplicationAsDataEntryBy on this Login with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`data_entry_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . '
			');
		}

		/**
		 * Unassociates a ApplicationAsDataEntryBy
		 * @param Application $objApplication
		 * @return void
		*/
		public function UnassociateApplicationAsDataEntryBy(Application $objApplication) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsDataEntryBy on this unsaved Login.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsDataEntryBy on this Login with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`data_entry_by` = null
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . ' AND
					`data_entry_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all ApplicationsAsDataEntryBy
		 * @return void
		*/
		public function UnassociateAllApplicationsAsDataEntryBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsDataEntryBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`data_entry_by` = null
				WHERE
					`data_entry_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated ApplicationAsDataEntryBy
		 * @param Application $objApplication
		 * @return void
		*/
		public function DeleteAssociatedApplicationAsDataEntryBy(Application $objApplication) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsDataEntryBy on this unsaved Login.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsDataEntryBy on this Login with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`application`
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . ' AND
					`data_entry_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated ApplicationsAsDataEntryBy
		 * @return void
		*/
		public function DeleteAllApplicationsAsDataEntryBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsDataEntryBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`application`
				WHERE
					`data_entry_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for ApplicationAsCertificateIssueBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ApplicationsAsCertificateIssueBy as an array of Application objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Application[]
		*/
		public function GetApplicationAsCertificateIssueByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Application::LoadArrayByCertificateIssueBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ApplicationsAsCertificateIssueBy
		 * @return int
		*/
		public function CountApplicationsAsCertificateIssueBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Application::CountByCertificateIssueBy($this->intIdlogin);
		}

		/**
		 * Associates a ApplicationAsCertificateIssueBy
		 * @param Application $objApplication
		 * @return void
		*/
		public function AssociateApplicationAsCertificateIssueBy(Application $objApplication) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplicationAsCertificateIssueBy on this unsaved Login.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplicationAsCertificateIssueBy on this Login with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`certificate_issue_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . '
			');
		}

		/**
		 * Unassociates a ApplicationAsCertificateIssueBy
		 * @param Application $objApplication
		 * @return void
		*/
		public function UnassociateApplicationAsCertificateIssueBy(Application $objApplication) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsCertificateIssueBy on this unsaved Login.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsCertificateIssueBy on this Login with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`certificate_issue_by` = null
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . ' AND
					`certificate_issue_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all ApplicationsAsCertificateIssueBy
		 * @return void
		*/
		public function UnassociateAllApplicationsAsCertificateIssueBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsCertificateIssueBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`certificate_issue_by` = null
				WHERE
					`certificate_issue_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated ApplicationAsCertificateIssueBy
		 * @param Application $objApplication
		 * @return void
		*/
		public function DeleteAssociatedApplicationAsCertificateIssueBy(Application $objApplication) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsCertificateIssueBy on this unsaved Login.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsCertificateIssueBy on this Login with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`application`
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . ' AND
					`certificate_issue_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated ApplicationsAsCertificateIssueBy
		 * @return void
		*/
		public function DeleteAllApplicationsAsCertificateIssueBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsCertificateIssueBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`application`
				WHERE
					`certificate_issue_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for ApplicationAsSubstitute
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ApplicationsAsSubstitute as an array of Application objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Application[]
		*/
		public function GetApplicationAsSubstituteArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Application::LoadArrayBySubstitute($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ApplicationsAsSubstitute
		 * @return int
		*/
		public function CountApplicationsAsSubstitute() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Application::CountBySubstitute($this->intIdlogin);
		}

		/**
		 * Associates a ApplicationAsSubstitute
		 * @param Application $objApplication
		 * @return void
		*/
		public function AssociateApplicationAsSubstitute(Application $objApplication) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplicationAsSubstitute on this unsaved Login.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplicationAsSubstitute on this Login with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`substitute` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . '
			');
		}

		/**
		 * Unassociates a ApplicationAsSubstitute
		 * @param Application $objApplication
		 * @return void
		*/
		public function UnassociateApplicationAsSubstitute(Application $objApplication) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsSubstitute on this unsaved Login.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsSubstitute on this Login with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`substitute` = null
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . ' AND
					`substitute` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all ApplicationsAsSubstitute
		 * @return void
		*/
		public function UnassociateAllApplicationsAsSubstitute() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsSubstitute on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`application`
				SET
					`substitute` = null
				WHERE
					`substitute` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated ApplicationAsSubstitute
		 * @param Application $objApplication
		 * @return void
		*/
		public function DeleteAssociatedApplicationAsSubstitute(Application $objApplication) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsSubstitute on this unsaved Login.');
			if ((is_null($objApplication->Idapplication)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsSubstitute on this Login with an unsaved Application.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`application`
				WHERE
					`idapplication` = ' . $objDatabase->SqlVariable($objApplication->Idapplication) . ' AND
					`substitute` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated ApplicationsAsSubstitute
		 * @return void
		*/
		public function DeleteAllApplicationsAsSubstitute() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplicationAsSubstitute on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`application`
				WHERE
					`substitute` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for AppliedExamAsStudent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated AppliedExamsAsStudent as an array of AppliedExam objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppliedExam[]
		*/
		public function GetAppliedExamAsStudentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return AppliedExam::LoadArrayByStudent($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated AppliedExamsAsStudent
		 * @return int
		*/
		public function CountAppliedExamsAsStudent() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return AppliedExam::CountByStudent($this->intIdlogin);
		}

		/**
		 * Associates a AppliedExamAsStudent
		 * @param AppliedExam $objAppliedExam
		 * @return void
		*/
		public function AssociateAppliedExamAsStudent(AppliedExam $objAppliedExam) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppliedExamAsStudent on this unsaved Login.');
			if ((is_null($objAppliedExam->IdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppliedExamAsStudent on this Login with an unsaved AppliedExam.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`applied_exam`
				SET
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($objAppliedExam->IdappliedExam) . '
			');
		}

		/**
		 * Unassociates a AppliedExamAsStudent
		 * @param AppliedExam $objAppliedExam
		 * @return void
		*/
		public function UnassociateAppliedExamAsStudent(AppliedExam $objAppliedExam) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsStudent on this unsaved Login.');
			if ((is_null($objAppliedExam->IdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsStudent on this Login with an unsaved AppliedExam.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`applied_exam`
				SET
					`student` = null
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($objAppliedExam->IdappliedExam) . ' AND
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all AppliedExamsAsStudent
		 * @return void
		*/
		public function UnassociateAllAppliedExamsAsStudent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsStudent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`applied_exam`
				SET
					`student` = null
				WHERE
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated AppliedExamAsStudent
		 * @param AppliedExam $objAppliedExam
		 * @return void
		*/
		public function DeleteAssociatedAppliedExamAsStudent(AppliedExam $objAppliedExam) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsStudent on this unsaved Login.');
			if ((is_null($objAppliedExam->IdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsStudent on this Login with an unsaved AppliedExam.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`applied_exam`
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($objAppliedExam->IdappliedExam) . ' AND
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated AppliedExamsAsStudent
		 * @return void
		*/
		public function DeleteAllAppliedExamsAsStudent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsStudent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`applied_exam`
				WHERE
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for ApplyGradeImpromentAsStudent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ApplyGradeImpromentsAsStudent as an array of ApplyGradeImproment objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ApplyGradeImproment[]
		*/
		public function GetApplyGradeImpromentAsStudentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return ApplyGradeImproment::LoadArrayByStudent($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ApplyGradeImpromentsAsStudent
		 * @return int
		*/
		public function CountApplyGradeImpromentsAsStudent() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return ApplyGradeImproment::CountByStudent($this->intIdlogin);
		}

		/**
		 * Associates a ApplyGradeImpromentAsStudent
		 * @param ApplyGradeImproment $objApplyGradeImproment
		 * @return void
		*/
		public function AssociateApplyGradeImpromentAsStudent(ApplyGradeImproment $objApplyGradeImproment) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplyGradeImpromentAsStudent on this unsaved Login.');
			if ((is_null($objApplyGradeImproment->IdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplyGradeImpromentAsStudent on this Login with an unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`apply_grade_improment`
				SET
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idapply_grade_improment` = ' . $objDatabase->SqlVariable($objApplyGradeImproment->IdapplyGradeImproment) . '
			');
		}

		/**
		 * Unassociates a ApplyGradeImpromentAsStudent
		 * @param ApplyGradeImproment $objApplyGradeImproment
		 * @return void
		*/
		public function UnassociateApplyGradeImpromentAsStudent(ApplyGradeImproment $objApplyGradeImproment) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsStudent on this unsaved Login.');
			if ((is_null($objApplyGradeImproment->IdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsStudent on this Login with an unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`apply_grade_improment`
				SET
					`student` = null
				WHERE
					`idapply_grade_improment` = ' . $objDatabase->SqlVariable($objApplyGradeImproment->IdapplyGradeImproment) . ' AND
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all ApplyGradeImpromentsAsStudent
		 * @return void
		*/
		public function UnassociateAllApplyGradeImpromentsAsStudent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsStudent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`apply_grade_improment`
				SET
					`student` = null
				WHERE
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated ApplyGradeImpromentAsStudent
		 * @param ApplyGradeImproment $objApplyGradeImproment
		 * @return void
		*/
		public function DeleteAssociatedApplyGradeImpromentAsStudent(ApplyGradeImproment $objApplyGradeImproment) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsStudent on this unsaved Login.');
			if ((is_null($objApplyGradeImproment->IdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsStudent on this Login with an unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`apply_grade_improment`
				WHERE
					`idapply_grade_improment` = ' . $objDatabase->SqlVariable($objApplyGradeImproment->IdapplyGradeImproment) . ' AND
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated ApplyGradeImpromentsAsStudent
		 * @return void
		*/
		public function DeleteAllApplyGradeImpromentsAsStudent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsStudent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`apply_grade_improment`
				WHERE
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for ApplyGradeImpromentAsAppliedBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ApplyGradeImpromentsAsAppliedBy as an array of ApplyGradeImproment objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ApplyGradeImproment[]
		*/
		public function GetApplyGradeImpromentAsAppliedByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return ApplyGradeImproment::LoadArrayByAppliedBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ApplyGradeImpromentsAsAppliedBy
		 * @return int
		*/
		public function CountApplyGradeImpromentsAsAppliedBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return ApplyGradeImproment::CountByAppliedBy($this->intIdlogin);
		}

		/**
		 * Associates a ApplyGradeImpromentAsAppliedBy
		 * @param ApplyGradeImproment $objApplyGradeImproment
		 * @return void
		*/
		public function AssociateApplyGradeImpromentAsAppliedBy(ApplyGradeImproment $objApplyGradeImproment) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplyGradeImpromentAsAppliedBy on this unsaved Login.');
			if ((is_null($objApplyGradeImproment->IdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplyGradeImpromentAsAppliedBy on this Login with an unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`apply_grade_improment`
				SET
					`applied_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idapply_grade_improment` = ' . $objDatabase->SqlVariable($objApplyGradeImproment->IdapplyGradeImproment) . '
			');
		}

		/**
		 * Unassociates a ApplyGradeImpromentAsAppliedBy
		 * @param ApplyGradeImproment $objApplyGradeImproment
		 * @return void
		*/
		public function UnassociateApplyGradeImpromentAsAppliedBy(ApplyGradeImproment $objApplyGradeImproment) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsAppliedBy on this unsaved Login.');
			if ((is_null($objApplyGradeImproment->IdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsAppliedBy on this Login with an unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`apply_grade_improment`
				SET
					`applied_by` = null
				WHERE
					`idapply_grade_improment` = ' . $objDatabase->SqlVariable($objApplyGradeImproment->IdapplyGradeImproment) . ' AND
					`applied_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all ApplyGradeImpromentsAsAppliedBy
		 * @return void
		*/
		public function UnassociateAllApplyGradeImpromentsAsAppliedBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsAppliedBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`apply_grade_improment`
				SET
					`applied_by` = null
				WHERE
					`applied_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated ApplyGradeImpromentAsAppliedBy
		 * @param ApplyGradeImproment $objApplyGradeImproment
		 * @return void
		*/
		public function DeleteAssociatedApplyGradeImpromentAsAppliedBy(ApplyGradeImproment $objApplyGradeImproment) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsAppliedBy on this unsaved Login.');
			if ((is_null($objApplyGradeImproment->IdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsAppliedBy on this Login with an unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`apply_grade_improment`
				WHERE
					`idapply_grade_improment` = ' . $objDatabase->SqlVariable($objApplyGradeImproment->IdapplyGradeImproment) . ' AND
					`applied_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated ApplyGradeImpromentsAsAppliedBy
		 * @return void
		*/
		public function DeleteAllApplyGradeImpromentsAsAppliedBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsAppliedBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`apply_grade_improment`
				WHERE
					`applied_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for AttendenceAsStaff
		//-------------------------------------------------------------------

		/**
		 * Gets all associated AttendencesAsStaff as an array of Attendence objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Attendence[]
		*/
		public function GetAttendenceAsStaffArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Attendence::LoadArrayByStaff($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated AttendencesAsStaff
		 * @return int
		*/
		public function CountAttendencesAsStaff() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Attendence::CountByStaff($this->intIdlogin);
		}

		/**
		 * Associates a AttendenceAsStaff
		 * @param Attendence $objAttendence
		 * @return void
		*/
		public function AssociateAttendenceAsStaff(Attendence $objAttendence) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAttendenceAsStaff on this unsaved Login.');
			if ((is_null($objAttendence->Idattendence)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAttendenceAsStaff on this Login with an unsaved Attendence.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`attendence`
				SET
					`staff` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idattendence` = ' . $objDatabase->SqlVariable($objAttendence->Idattendence) . '
			');
		}

		/**
		 * Unassociates a AttendenceAsStaff
		 * @param Attendence $objAttendence
		 * @return void
		*/
		public function UnassociateAttendenceAsStaff(Attendence $objAttendence) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAttendenceAsStaff on this unsaved Login.');
			if ((is_null($objAttendence->Idattendence)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAttendenceAsStaff on this Login with an unsaved Attendence.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`attendence`
				SET
					`staff` = null
				WHERE
					`idattendence` = ' . $objDatabase->SqlVariable($objAttendence->Idattendence) . ' AND
					`staff` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all AttendencesAsStaff
		 * @return void
		*/
		public function UnassociateAllAttendencesAsStaff() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAttendenceAsStaff on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`attendence`
				SET
					`staff` = null
				WHERE
					`staff` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated AttendenceAsStaff
		 * @param Attendence $objAttendence
		 * @return void
		*/
		public function DeleteAssociatedAttendenceAsStaff(Attendence $objAttendence) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAttendenceAsStaff on this unsaved Login.');
			if ((is_null($objAttendence->Idattendence)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAttendenceAsStaff on this Login with an unsaved Attendence.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`attendence`
				WHERE
					`idattendence` = ' . $objDatabase->SqlVariable($objAttendence->Idattendence) . ' AND
					`staff` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated AttendencesAsStaff
		 * @return void
		*/
		public function DeleteAllAttendencesAsStaff() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAttendenceAsStaff on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`attendence`
				WHERE
					`staff` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for CertificateDepositeAsVerifyBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated CertificateDepositesAsVerifyBy as an array of CertificateDeposite objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return CertificateDeposite[]
		*/
		public function GetCertificateDepositeAsVerifyByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return CertificateDeposite::LoadArrayByVerifyBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated CertificateDepositesAsVerifyBy
		 * @return int
		*/
		public function CountCertificateDepositesAsVerifyBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return CertificateDeposite::CountByVerifyBy($this->intIdlogin);
		}

		/**
		 * Associates a CertificateDepositeAsVerifyBy
		 * @param CertificateDeposite $objCertificateDeposite
		 * @return void
		*/
		public function AssociateCertificateDepositeAsVerifyBy(CertificateDeposite $objCertificateDeposite) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCertificateDepositeAsVerifyBy on this unsaved Login.');
			if ((is_null($objCertificateDeposite->IdcertificateDeposite)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCertificateDepositeAsVerifyBy on this Login with an unsaved CertificateDeposite.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`certificate_deposite`
				SET
					`verify_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idcertificate_deposite` = ' . $objDatabase->SqlVariable($objCertificateDeposite->IdcertificateDeposite) . '
			');
		}

		/**
		 * Unassociates a CertificateDepositeAsVerifyBy
		 * @param CertificateDeposite $objCertificateDeposite
		 * @return void
		*/
		public function UnassociateCertificateDepositeAsVerifyBy(CertificateDeposite $objCertificateDeposite) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateDepositeAsVerifyBy on this unsaved Login.');
			if ((is_null($objCertificateDeposite->IdcertificateDeposite)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateDepositeAsVerifyBy on this Login with an unsaved CertificateDeposite.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`certificate_deposite`
				SET
					`verify_by` = null
				WHERE
					`idcertificate_deposite` = ' . $objDatabase->SqlVariable($objCertificateDeposite->IdcertificateDeposite) . ' AND
					`verify_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all CertificateDepositesAsVerifyBy
		 * @return void
		*/
		public function UnassociateAllCertificateDepositesAsVerifyBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateDepositeAsVerifyBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`certificate_deposite`
				SET
					`verify_by` = null
				WHERE
					`verify_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated CertificateDepositeAsVerifyBy
		 * @param CertificateDeposite $objCertificateDeposite
		 * @return void
		*/
		public function DeleteAssociatedCertificateDepositeAsVerifyBy(CertificateDeposite $objCertificateDeposite) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateDepositeAsVerifyBy on this unsaved Login.');
			if ((is_null($objCertificateDeposite->IdcertificateDeposite)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateDepositeAsVerifyBy on this Login with an unsaved CertificateDeposite.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`certificate_deposite`
				WHERE
					`idcertificate_deposite` = ' . $objDatabase->SqlVariable($objCertificateDeposite->IdcertificateDeposite) . ' AND
					`verify_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated CertificateDepositesAsVerifyBy
		 * @return void
		*/
		public function DeleteAllCertificateDepositesAsVerifyBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateDepositeAsVerifyBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`certificate_deposite`
				WHERE
					`verify_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for CertificateDepositeAsReturnBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated CertificateDepositesAsReturnBy as an array of CertificateDeposite objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return CertificateDeposite[]
		*/
		public function GetCertificateDepositeAsReturnByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return CertificateDeposite::LoadArrayByReturnBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated CertificateDepositesAsReturnBy
		 * @return int
		*/
		public function CountCertificateDepositesAsReturnBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return CertificateDeposite::CountByReturnBy($this->intIdlogin);
		}

		/**
		 * Associates a CertificateDepositeAsReturnBy
		 * @param CertificateDeposite $objCertificateDeposite
		 * @return void
		*/
		public function AssociateCertificateDepositeAsReturnBy(CertificateDeposite $objCertificateDeposite) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCertificateDepositeAsReturnBy on this unsaved Login.');
			if ((is_null($objCertificateDeposite->IdcertificateDeposite)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCertificateDepositeAsReturnBy on this Login with an unsaved CertificateDeposite.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`certificate_deposite`
				SET
					`return_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idcertificate_deposite` = ' . $objDatabase->SqlVariable($objCertificateDeposite->IdcertificateDeposite) . '
			');
		}

		/**
		 * Unassociates a CertificateDepositeAsReturnBy
		 * @param CertificateDeposite $objCertificateDeposite
		 * @return void
		*/
		public function UnassociateCertificateDepositeAsReturnBy(CertificateDeposite $objCertificateDeposite) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateDepositeAsReturnBy on this unsaved Login.');
			if ((is_null($objCertificateDeposite->IdcertificateDeposite)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateDepositeAsReturnBy on this Login with an unsaved CertificateDeposite.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`certificate_deposite`
				SET
					`return_by` = null
				WHERE
					`idcertificate_deposite` = ' . $objDatabase->SqlVariable($objCertificateDeposite->IdcertificateDeposite) . ' AND
					`return_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all CertificateDepositesAsReturnBy
		 * @return void
		*/
		public function UnassociateAllCertificateDepositesAsReturnBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateDepositeAsReturnBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`certificate_deposite`
				SET
					`return_by` = null
				WHERE
					`return_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated CertificateDepositeAsReturnBy
		 * @param CertificateDeposite $objCertificateDeposite
		 * @return void
		*/
		public function DeleteAssociatedCertificateDepositeAsReturnBy(CertificateDeposite $objCertificateDeposite) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateDepositeAsReturnBy on this unsaved Login.');
			if ((is_null($objCertificateDeposite->IdcertificateDeposite)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateDepositeAsReturnBy on this Login with an unsaved CertificateDeposite.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`certificate_deposite`
				WHERE
					`idcertificate_deposite` = ' . $objDatabase->SqlVariable($objCertificateDeposite->IdcertificateDeposite) . ' AND
					`return_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated CertificateDepositesAsReturnBy
		 * @return void
		*/
		public function DeleteAllCertificateDepositesAsReturnBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateDepositeAsReturnBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`certificate_deposite`
				WHERE
					`return_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for CirculationAsDataBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated CirculationsAsDataBy as an array of Circulation objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Circulation[]
		*/
		public function GetCirculationAsDataByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Circulation::LoadArrayByDataBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated CirculationsAsDataBy
		 * @return int
		*/
		public function CountCirculationsAsDataBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Circulation::CountByDataBy($this->intIdlogin);
		}

		/**
		 * Associates a CirculationAsDataBy
		 * @param Circulation $objCirculation
		 * @return void
		*/
		public function AssociateCirculationAsDataBy(Circulation $objCirculation) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCirculationAsDataBy on this unsaved Login.');
			if ((is_null($objCirculation->Idcirculation)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCirculationAsDataBy on this Login with an unsaved Circulation.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`circulation`
				SET
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idcirculation` = ' . $objDatabase->SqlVariable($objCirculation->Idcirculation) . '
			');
		}

		/**
		 * Unassociates a CirculationAsDataBy
		 * @param Circulation $objCirculation
		 * @return void
		*/
		public function UnassociateCirculationAsDataBy(Circulation $objCirculation) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCirculationAsDataBy on this unsaved Login.');
			if ((is_null($objCirculation->Idcirculation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCirculationAsDataBy on this Login with an unsaved Circulation.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`circulation`
				SET
					`data_by` = null
				WHERE
					`idcirculation` = ' . $objDatabase->SqlVariable($objCirculation->Idcirculation) . ' AND
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all CirculationsAsDataBy
		 * @return void
		*/
		public function UnassociateAllCirculationsAsDataBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCirculationAsDataBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`circulation`
				SET
					`data_by` = null
				WHERE
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated CirculationAsDataBy
		 * @param Circulation $objCirculation
		 * @return void
		*/
		public function DeleteAssociatedCirculationAsDataBy(Circulation $objCirculation) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCirculationAsDataBy on this unsaved Login.');
			if ((is_null($objCirculation->Idcirculation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCirculationAsDataBy on this Login with an unsaved Circulation.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`circulation`
				WHERE
					`idcirculation` = ' . $objDatabase->SqlVariable($objCirculation->Idcirculation) . ' AND
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated CirculationsAsDataBy
		 * @return void
		*/
		public function DeleteAllCirculationsAsDataBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCirculationAsDataBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`circulation`
				WHERE
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for CirculationAsStaffStud
		//-------------------------------------------------------------------

		/**
		 * Gets all associated CirculationsAsStaffStud as an array of Circulation objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Circulation[]
		*/
		public function GetCirculationAsStaffStudArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Circulation::LoadArrayByStaffStud($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated CirculationsAsStaffStud
		 * @return int
		*/
		public function CountCirculationsAsStaffStud() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Circulation::CountByStaffStud($this->intIdlogin);
		}

		/**
		 * Associates a CirculationAsStaffStud
		 * @param Circulation $objCirculation
		 * @return void
		*/
		public function AssociateCirculationAsStaffStud(Circulation $objCirculation) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCirculationAsStaffStud on this unsaved Login.');
			if ((is_null($objCirculation->Idcirculation)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCirculationAsStaffStud on this Login with an unsaved Circulation.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`circulation`
				SET
					`staff_stud` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idcirculation` = ' . $objDatabase->SqlVariable($objCirculation->Idcirculation) . '
			');
		}

		/**
		 * Unassociates a CirculationAsStaffStud
		 * @param Circulation $objCirculation
		 * @return void
		*/
		public function UnassociateCirculationAsStaffStud(Circulation $objCirculation) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCirculationAsStaffStud on this unsaved Login.');
			if ((is_null($objCirculation->Idcirculation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCirculationAsStaffStud on this Login with an unsaved Circulation.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`circulation`
				SET
					`staff_stud` = null
				WHERE
					`idcirculation` = ' . $objDatabase->SqlVariable($objCirculation->Idcirculation) . ' AND
					`staff_stud` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all CirculationsAsStaffStud
		 * @return void
		*/
		public function UnassociateAllCirculationsAsStaffStud() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCirculationAsStaffStud on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`circulation`
				SET
					`staff_stud` = null
				WHERE
					`staff_stud` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated CirculationAsStaffStud
		 * @param Circulation $objCirculation
		 * @return void
		*/
		public function DeleteAssociatedCirculationAsStaffStud(Circulation $objCirculation) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCirculationAsStaffStud on this unsaved Login.');
			if ((is_null($objCirculation->Idcirculation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCirculationAsStaffStud on this Login with an unsaved Circulation.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`circulation`
				WHERE
					`idcirculation` = ' . $objDatabase->SqlVariable($objCirculation->Idcirculation) . ' AND
					`staff_stud` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated CirculationsAsStaffStud
		 * @return void
		*/
		public function DeleteAllCirculationsAsStaffStud() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCirculationAsStaffStud on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`circulation`
				WHERE
					`staff_stud` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for CurrentStatusAsStudent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated CurrentStatusesAsStudent as an array of CurrentStatus objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return CurrentStatus[]
		*/
		public function GetCurrentStatusAsStudentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return CurrentStatus::LoadArrayByStudent($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated CurrentStatusesAsStudent
		 * @return int
		*/
		public function CountCurrentStatusesAsStudent() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return CurrentStatus::CountByStudent($this->intIdlogin);
		}

		/**
		 * Associates a CurrentStatusAsStudent
		 * @param CurrentStatus $objCurrentStatus
		 * @return void
		*/
		public function AssociateCurrentStatusAsStudent(CurrentStatus $objCurrentStatus) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCurrentStatusAsStudent on this unsaved Login.');
			if ((is_null($objCurrentStatus->IdcurrentStatus)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCurrentStatusAsStudent on this Login with an unsaved CurrentStatus.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`current_status`
				SET
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idcurrent_status` = ' . $objDatabase->SqlVariable($objCurrentStatus->IdcurrentStatus) . '
			');
		}

		/**
		 * Unassociates a CurrentStatusAsStudent
		 * @param CurrentStatus $objCurrentStatus
		 * @return void
		*/
		public function UnassociateCurrentStatusAsStudent(CurrentStatus $objCurrentStatus) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCurrentStatusAsStudent on this unsaved Login.');
			if ((is_null($objCurrentStatus->IdcurrentStatus)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCurrentStatusAsStudent on this Login with an unsaved CurrentStatus.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`current_status`
				SET
					`student` = null
				WHERE
					`idcurrent_status` = ' . $objDatabase->SqlVariable($objCurrentStatus->IdcurrentStatus) . ' AND
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all CurrentStatusesAsStudent
		 * @return void
		*/
		public function UnassociateAllCurrentStatusesAsStudent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCurrentStatusAsStudent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`current_status`
				SET
					`student` = null
				WHERE
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated CurrentStatusAsStudent
		 * @param CurrentStatus $objCurrentStatus
		 * @return void
		*/
		public function DeleteAssociatedCurrentStatusAsStudent(CurrentStatus $objCurrentStatus) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCurrentStatusAsStudent on this unsaved Login.');
			if ((is_null($objCurrentStatus->IdcurrentStatus)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCurrentStatusAsStudent on this Login with an unsaved CurrentStatus.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`current_status`
				WHERE
					`idcurrent_status` = ' . $objDatabase->SqlVariable($objCurrentStatus->IdcurrentStatus) . ' AND
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated CurrentStatusesAsStudent
		 * @return void
		*/
		public function DeleteAllCurrentStatusesAsStudent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCurrentStatusAsStudent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`current_status`
				WHERE
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for DeptYearEventsAsIntiator
		//-------------------------------------------------------------------

		/**
		 * Gets all associated DeptYearEventsesAsIntiator as an array of DeptYearEvents objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public function GetDeptYearEventsAsIntiatorArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return DeptYearEvents::LoadArrayByIntiator($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated DeptYearEventsesAsIntiator
		 * @return int
		*/
		public function CountDeptYearEventsesAsIntiator() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return DeptYearEvents::CountByIntiator($this->intIdlogin);
		}

		/**
		 * Associates a DeptYearEventsAsIntiator
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function AssociateDeptYearEventsAsIntiator(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEventsAsIntiator on this unsaved Login.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEventsAsIntiator on this Login with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`intiator` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates a DeptYearEventsAsIntiator
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function UnassociateDeptYearEventsAsIntiator(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsIntiator on this unsaved Login.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsIntiator on this Login with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`intiator` = null
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`intiator` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all DeptYearEventsesAsIntiator
		 * @return void
		*/
		public function UnassociateAllDeptYearEventsesAsIntiator() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsIntiator on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`intiator` = null
				WHERE
					`intiator` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated DeptYearEventsAsIntiator
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function DeleteAssociatedDeptYearEventsAsIntiator(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsIntiator on this unsaved Login.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsIntiator on this Login with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`intiator` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated DeptYearEventsesAsIntiator
		 * @return void
		*/
		public function DeleteAllDeptYearEventsesAsIntiator() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsIntiator on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`intiator` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for DeptYearEventsAsOwner
		//-------------------------------------------------------------------

		/**
		 * Gets all associated DeptYearEventsesAsOwner as an array of DeptYearEvents objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public function GetDeptYearEventsAsOwnerArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return DeptYearEvents::LoadArrayByOwner($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated DeptYearEventsesAsOwner
		 * @return int
		*/
		public function CountDeptYearEventsesAsOwner() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return DeptYearEvents::CountByOwner($this->intIdlogin);
		}

		/**
		 * Associates a DeptYearEventsAsOwner
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function AssociateDeptYearEventsAsOwner(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEventsAsOwner on this unsaved Login.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEventsAsOwner on this Login with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`owner` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates a DeptYearEventsAsOwner
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function UnassociateDeptYearEventsAsOwner(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsOwner on this unsaved Login.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsOwner on this Login with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`owner` = null
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`owner` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all DeptYearEventsesAsOwner
		 * @return void
		*/
		public function UnassociateAllDeptYearEventsesAsOwner() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsOwner on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`owner` = null
				WHERE
					`owner` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated DeptYearEventsAsOwner
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function DeleteAssociatedDeptYearEventsAsOwner(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsOwner on this unsaved Login.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsOwner on this Login with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`owner` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated DeptYearEventsesAsOwner
		 * @return void
		*/
		public function DeleteAllDeptYearEventsesAsOwner() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsOwner on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`owner` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for DocInOutAsInwordBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated DocInOutsAsInwordBy as an array of DocInOut objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DocInOut[]
		*/
		public function GetDocInOutAsInwordByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return DocInOut::LoadArrayByInwordBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated DocInOutsAsInwordBy
		 * @return int
		*/
		public function CountDocInOutsAsInwordBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return DocInOut::CountByInwordBy($this->intIdlogin);
		}

		/**
		 * Associates a DocInOutAsInwordBy
		 * @param DocInOut $objDocInOut
		 * @return void
		*/
		public function AssociateDocInOutAsInwordBy(DocInOut $objDocInOut) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDocInOutAsInwordBy on this unsaved Login.');
			if ((is_null($objDocInOut->IddocInOut)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDocInOutAsInwordBy on this Login with an unsaved DocInOut.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`doc_in_out`
				SET
					`inword_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`iddoc_in_out` = ' . $objDatabase->SqlVariable($objDocInOut->IddocInOut) . '
			');
		}

		/**
		 * Unassociates a DocInOutAsInwordBy
		 * @param DocInOut $objDocInOut
		 * @return void
		*/
		public function UnassociateDocInOutAsInwordBy(DocInOut $objDocInOut) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDocInOutAsInwordBy on this unsaved Login.');
			if ((is_null($objDocInOut->IddocInOut)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDocInOutAsInwordBy on this Login with an unsaved DocInOut.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`doc_in_out`
				SET
					`inword_by` = null
				WHERE
					`iddoc_in_out` = ' . $objDatabase->SqlVariable($objDocInOut->IddocInOut) . ' AND
					`inword_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all DocInOutsAsInwordBy
		 * @return void
		*/
		public function UnassociateAllDocInOutsAsInwordBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDocInOutAsInwordBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`doc_in_out`
				SET
					`inword_by` = null
				WHERE
					`inword_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated DocInOutAsInwordBy
		 * @param DocInOut $objDocInOut
		 * @return void
		*/
		public function DeleteAssociatedDocInOutAsInwordBy(DocInOut $objDocInOut) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDocInOutAsInwordBy on this unsaved Login.');
			if ((is_null($objDocInOut->IddocInOut)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDocInOutAsInwordBy on this Login with an unsaved DocInOut.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`doc_in_out`
				WHERE
					`iddoc_in_out` = ' . $objDatabase->SqlVariable($objDocInOut->IddocInOut) . ' AND
					`inword_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated DocInOutsAsInwordBy
		 * @return void
		*/
		public function DeleteAllDocInOutsAsInwordBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDocInOutAsInwordBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`doc_in_out`
				WHERE
					`inword_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for ECourseAsTeacher
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ECoursesAsTeacher as an array of ECourse objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ECourse[]
		*/
		public function GetECourseAsTeacherArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return ECourse::LoadArrayByTeacherId($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ECoursesAsTeacher
		 * @return int
		*/
		public function CountECoursesAsTeacher() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return ECourse::CountByTeacherId($this->intIdlogin);
		}

		/**
		 * Associates a ECourseAsTeacher
		 * @param ECourse $objECourse
		 * @return void
		*/
		public function AssociateECourseAsTeacher(ECourse $objECourse) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateECourseAsTeacher on this unsaved Login.');
			if ((is_null($objECourse->IdeCourse)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateECourseAsTeacher on this Login with an unsaved ECourse.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`e_course`
				SET
					`teacher_id` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`ide_course` = ' . $objDatabase->SqlVariable($objECourse->IdeCourse) . '
			');
		}

		/**
		 * Unassociates a ECourseAsTeacher
		 * @param ECourse $objECourse
		 * @return void
		*/
		public function UnassociateECourseAsTeacher(ECourse $objECourse) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateECourseAsTeacher on this unsaved Login.');
			if ((is_null($objECourse->IdeCourse)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateECourseAsTeacher on this Login with an unsaved ECourse.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`e_course`
				SET
					`teacher_id` = null
				WHERE
					`ide_course` = ' . $objDatabase->SqlVariable($objECourse->IdeCourse) . ' AND
					`teacher_id` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all ECoursesAsTeacher
		 * @return void
		*/
		public function UnassociateAllECoursesAsTeacher() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateECourseAsTeacher on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`e_course`
				SET
					`teacher_id` = null
				WHERE
					`teacher_id` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated ECourseAsTeacher
		 * @param ECourse $objECourse
		 * @return void
		*/
		public function DeleteAssociatedECourseAsTeacher(ECourse $objECourse) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateECourseAsTeacher on this unsaved Login.');
			if ((is_null($objECourse->IdeCourse)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateECourseAsTeacher on this Login with an unsaved ECourse.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`e_course`
				WHERE
					`ide_course` = ' . $objDatabase->SqlVariable($objECourse->IdeCourse) . ' AND
					`teacher_id` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated ECoursesAsTeacher
		 * @return void
		*/
		public function DeleteAllECoursesAsTeacher() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateECourseAsTeacher on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`e_course`
				WHERE
					`teacher_id` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for EStudentAsStudent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated EStudentsAsStudent as an array of EStudent objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EStudent[]
		*/
		public function GetEStudentAsStudentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return EStudent::LoadArrayByStudent($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated EStudentsAsStudent
		 * @return int
		*/
		public function CountEStudentsAsStudent() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return EStudent::CountByStudent($this->intIdlogin);
		}

		/**
		 * Associates a EStudentAsStudent
		 * @param EStudent $objEStudent
		 * @return void
		*/
		public function AssociateEStudentAsStudent(EStudent $objEStudent) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEStudentAsStudent on this unsaved Login.');
			if ((is_null($objEStudent->IdeStudent)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEStudentAsStudent on this Login with an unsaved EStudent.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`e_student`
				SET
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`ide_student` = ' . $objDatabase->SqlVariable($objEStudent->IdeStudent) . '
			');
		}

		/**
		 * Unassociates a EStudentAsStudent
		 * @param EStudent $objEStudent
		 * @return void
		*/
		public function UnassociateEStudentAsStudent(EStudent $objEStudent) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEStudentAsStudent on this unsaved Login.');
			if ((is_null($objEStudent->IdeStudent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEStudentAsStudent on this Login with an unsaved EStudent.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`e_student`
				SET
					`student` = null
				WHERE
					`ide_student` = ' . $objDatabase->SqlVariable($objEStudent->IdeStudent) . ' AND
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all EStudentsAsStudent
		 * @return void
		*/
		public function UnassociateAllEStudentsAsStudent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEStudentAsStudent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`e_student`
				SET
					`student` = null
				WHERE
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated EStudentAsStudent
		 * @param EStudent $objEStudent
		 * @return void
		*/
		public function DeleteAssociatedEStudentAsStudent(EStudent $objEStudent) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEStudentAsStudent on this unsaved Login.');
			if ((is_null($objEStudent->IdeStudent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEStudentAsStudent on this Login with an unsaved EStudent.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`e_student`
				WHERE
					`ide_student` = ' . $objDatabase->SqlVariable($objEStudent->IdeStudent) . ' AND
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated EStudentsAsStudent
		 * @return void
		*/
		public function DeleteAllEStudentsAsStudent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEStudentAsStudent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`e_student`
				WHERE
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for ETicketAsRaisedBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ETicketsAsRaisedBy as an array of ETicket objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ETicket[]
		*/
		public function GetETicketAsRaisedByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return ETicket::LoadArrayByRaisedBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ETicketsAsRaisedBy
		 * @return int
		*/
		public function CountETicketsAsRaisedBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return ETicket::CountByRaisedBy($this->intIdlogin);
		}

		/**
		 * Associates a ETicketAsRaisedBy
		 * @param ETicket $objETicket
		 * @return void
		*/
		public function AssociateETicketAsRaisedBy(ETicket $objETicket) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateETicketAsRaisedBy on this unsaved Login.');
			if ((is_null($objETicket->IdeTicket)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateETicketAsRaisedBy on this Login with an unsaved ETicket.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`e_ticket`
				SET
					`raised_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`ide_ticket` = ' . $objDatabase->SqlVariable($objETicket->IdeTicket) . '
			');
		}

		/**
		 * Unassociates a ETicketAsRaisedBy
		 * @param ETicket $objETicket
		 * @return void
		*/
		public function UnassociateETicketAsRaisedBy(ETicket $objETicket) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateETicketAsRaisedBy on this unsaved Login.');
			if ((is_null($objETicket->IdeTicket)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateETicketAsRaisedBy on this Login with an unsaved ETicket.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`e_ticket`
				SET
					`raised_by` = null
				WHERE
					`ide_ticket` = ' . $objDatabase->SqlVariable($objETicket->IdeTicket) . ' AND
					`raised_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all ETicketsAsRaisedBy
		 * @return void
		*/
		public function UnassociateAllETicketsAsRaisedBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateETicketAsRaisedBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`e_ticket`
				SET
					`raised_by` = null
				WHERE
					`raised_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated ETicketAsRaisedBy
		 * @param ETicket $objETicket
		 * @return void
		*/
		public function DeleteAssociatedETicketAsRaisedBy(ETicket $objETicket) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateETicketAsRaisedBy on this unsaved Login.');
			if ((is_null($objETicket->IdeTicket)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateETicketAsRaisedBy on this Login with an unsaved ETicket.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`e_ticket`
				WHERE
					`ide_ticket` = ' . $objDatabase->SqlVariable($objETicket->IdeTicket) . ' AND
					`raised_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated ETicketsAsRaisedBy
		 * @return void
		*/
		public function DeleteAllETicketsAsRaisedBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateETicketAsRaisedBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`e_ticket`
				WHERE
					`raised_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for Establishment
		//-------------------------------------------------------------------

		/**
		 * Gets all associated Establishments as an array of Establishment objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Establishment[]
		*/
		public function GetEstablishmentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Establishment::LoadArrayByLogin($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated Establishments
		 * @return int
		*/
		public function CountEstablishments() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Establishment::CountByLogin($this->intIdlogin);
		}

		/**
		 * Associates a Establishment
		 * @param Establishment $objEstablishment
		 * @return void
		*/
		public function AssociateEstablishment(Establishment $objEstablishment) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEstablishment on this unsaved Login.');
			if ((is_null($objEstablishment->Idestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEstablishment on this Login with an unsaved Establishment.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`establishment`
				SET
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idestablishment` = ' . $objDatabase->SqlVariable($objEstablishment->Idestablishment) . '
			');
		}

		/**
		 * Unassociates a Establishment
		 * @param Establishment $objEstablishment
		 * @return void
		*/
		public function UnassociateEstablishment(Establishment $objEstablishment) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEstablishment on this unsaved Login.');
			if ((is_null($objEstablishment->Idestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEstablishment on this Login with an unsaved Establishment.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`establishment`
				SET
					`login` = null
				WHERE
					`idestablishment` = ' . $objDatabase->SqlVariable($objEstablishment->Idestablishment) . ' AND
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all Establishments
		 * @return void
		*/
		public function UnassociateAllEstablishments() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEstablishment on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`establishment`
				SET
					`login` = null
				WHERE
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated Establishment
		 * @param Establishment $objEstablishment
		 * @return void
		*/
		public function DeleteAssociatedEstablishment(Establishment $objEstablishment) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEstablishment on this unsaved Login.');
			if ((is_null($objEstablishment->Idestablishment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEstablishment on this Login with an unsaved Establishment.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`establishment`
				WHERE
					`idestablishment` = ' . $objDatabase->SqlVariable($objEstablishment->Idestablishment) . ' AND
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated Establishments
		 * @return void
		*/
		public function DeleteAllEstablishments() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEstablishment on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`establishment`
				WHERE
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for EventHasAttendentAsAttendent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated EventHasAttendentsAsAttendent as an array of EventHasAttendent objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EventHasAttendent[]
		*/
		public function GetEventHasAttendentAsAttendentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return EventHasAttendent::LoadArrayByAttendent($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated EventHasAttendentsAsAttendent
		 * @return int
		*/
		public function CountEventHasAttendentsAsAttendent() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return EventHasAttendent::CountByAttendent($this->intIdlogin);
		}

		/**
		 * Associates a EventHasAttendentAsAttendent
		 * @param EventHasAttendent $objEventHasAttendent
		 * @return void
		*/
		public function AssociateEventHasAttendentAsAttendent(EventHasAttendent $objEventHasAttendent) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEventHasAttendentAsAttendent on this unsaved Login.');
			if ((is_null($objEventHasAttendent->IdeventHasAttendent)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEventHasAttendentAsAttendent on this Login with an unsaved EventHasAttendent.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event_has_attendent`
				SET
					`attendent` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idevent_has_attendent` = ' . $objDatabase->SqlVariable($objEventHasAttendent->IdeventHasAttendent) . '
			');
		}

		/**
		 * Unassociates a EventHasAttendentAsAttendent
		 * @param EventHasAttendent $objEventHasAttendent
		 * @return void
		*/
		public function UnassociateEventHasAttendentAsAttendent(EventHasAttendent $objEventHasAttendent) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasAttendentAsAttendent on this unsaved Login.');
			if ((is_null($objEventHasAttendent->IdeventHasAttendent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasAttendentAsAttendent on this Login with an unsaved EventHasAttendent.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event_has_attendent`
				SET
					`attendent` = null
				WHERE
					`idevent_has_attendent` = ' . $objDatabase->SqlVariable($objEventHasAttendent->IdeventHasAttendent) . ' AND
					`attendent` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all EventHasAttendentsAsAttendent
		 * @return void
		*/
		public function UnassociateAllEventHasAttendentsAsAttendent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasAttendentAsAttendent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event_has_attendent`
				SET
					`attendent` = null
				WHERE
					`attendent` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated EventHasAttendentAsAttendent
		 * @param EventHasAttendent $objEventHasAttendent
		 * @return void
		*/
		public function DeleteAssociatedEventHasAttendentAsAttendent(EventHasAttendent $objEventHasAttendent) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasAttendentAsAttendent on this unsaved Login.');
			if ((is_null($objEventHasAttendent->IdeventHasAttendent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasAttendentAsAttendent on this Login with an unsaved EventHasAttendent.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event_has_attendent`
				WHERE
					`idevent_has_attendent` = ' . $objDatabase->SqlVariable($objEventHasAttendent->IdeventHasAttendent) . ' AND
					`attendent` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated EventHasAttendentsAsAttendent
		 * @return void
		*/
		public function DeleteAllEventHasAttendentsAsAttendent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasAttendentAsAttendent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event_has_attendent`
				WHERE
					`attendent` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for ExampaperAsSetBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ExampapersAsSetBy as an array of Exampaper objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Exampaper[]
		*/
		public function GetExampaperAsSetByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Exampaper::LoadArrayBySetBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ExampapersAsSetBy
		 * @return int
		*/
		public function CountExampapersAsSetBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Exampaper::CountBySetBy($this->intIdlogin);
		}

		/**
		 * Associates a ExampaperAsSetBy
		 * @param Exampaper $objExampaper
		 * @return void
		*/
		public function AssociateExampaperAsSetBy(Exampaper $objExampaper) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateExampaperAsSetBy on this unsaved Login.');
			if ((is_null($objExampaper->Idexampaper)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateExampaperAsSetBy on this Login with an unsaved Exampaper.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`exampaper`
				SET
					`set_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idexampaper` = ' . $objDatabase->SqlVariable($objExampaper->Idexampaper) . '
			');
		}

		/**
		 * Unassociates a ExampaperAsSetBy
		 * @param Exampaper $objExampaper
		 * @return void
		*/
		public function UnassociateExampaperAsSetBy(Exampaper $objExampaper) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExampaperAsSetBy on this unsaved Login.');
			if ((is_null($objExampaper->Idexampaper)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExampaperAsSetBy on this Login with an unsaved Exampaper.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`exampaper`
				SET
					`set_by` = null
				WHERE
					`idexampaper` = ' . $objDatabase->SqlVariable($objExampaper->Idexampaper) . ' AND
					`set_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all ExampapersAsSetBy
		 * @return void
		*/
		public function UnassociateAllExampapersAsSetBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExampaperAsSetBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`exampaper`
				SET
					`set_by` = null
				WHERE
					`set_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated ExampaperAsSetBy
		 * @param Exampaper $objExampaper
		 * @return void
		*/
		public function DeleteAssociatedExampaperAsSetBy(Exampaper $objExampaper) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExampaperAsSetBy on this unsaved Login.');
			if ((is_null($objExampaper->Idexampaper)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExampaperAsSetBy on this Login with an unsaved Exampaper.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`exampaper`
				WHERE
					`idexampaper` = ' . $objDatabase->SqlVariable($objExampaper->Idexampaper) . ' AND
					`set_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated ExampapersAsSetBy
		 * @return void
		*/
		public function DeleteAllExampapersAsSetBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExampaperAsSetBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`exampaper`
				WHERE
					`set_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for ForwardToAsForWhome
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ForwardTosAsForWhome as an array of ForwardTo objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ForwardTo[]
		*/
		public function GetForwardToAsForWhomeArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return ForwardTo::LoadArrayByForWhome($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ForwardTosAsForWhome
		 * @return int
		*/
		public function CountForwardTosAsForWhome() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return ForwardTo::CountByForWhome($this->intIdlogin);
		}

		/**
		 * Associates a ForwardToAsForWhome
		 * @param ForwardTo $objForwardTo
		 * @return void
		*/
		public function AssociateForwardToAsForWhome(ForwardTo $objForwardTo) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateForwardToAsForWhome on this unsaved Login.');
			if ((is_null($objForwardTo->IdforwardTo)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateForwardToAsForWhome on this Login with an unsaved ForwardTo.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`forward_to`
				SET
					`for_whome` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idforward_to` = ' . $objDatabase->SqlVariable($objForwardTo->IdforwardTo) . '
			');
		}

		/**
		 * Unassociates a ForwardToAsForWhome
		 * @param ForwardTo $objForwardTo
		 * @return void
		*/
		public function UnassociateForwardToAsForWhome(ForwardTo $objForwardTo) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateForwardToAsForWhome on this unsaved Login.');
			if ((is_null($objForwardTo->IdforwardTo)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateForwardToAsForWhome on this Login with an unsaved ForwardTo.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`forward_to`
				SET
					`for_whome` = null
				WHERE
					`idforward_to` = ' . $objDatabase->SqlVariable($objForwardTo->IdforwardTo) . ' AND
					`for_whome` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all ForwardTosAsForWhome
		 * @return void
		*/
		public function UnassociateAllForwardTosAsForWhome() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateForwardToAsForWhome on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`forward_to`
				SET
					`for_whome` = null
				WHERE
					`for_whome` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated ForwardToAsForWhome
		 * @param ForwardTo $objForwardTo
		 * @return void
		*/
		public function DeleteAssociatedForwardToAsForWhome(ForwardTo $objForwardTo) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateForwardToAsForWhome on this unsaved Login.');
			if ((is_null($objForwardTo->IdforwardTo)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateForwardToAsForWhome on this Login with an unsaved ForwardTo.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`forward_to`
				WHERE
					`idforward_to` = ' . $objDatabase->SqlVariable($objForwardTo->IdforwardTo) . ' AND
					`for_whome` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated ForwardTosAsForWhome
		 * @return void
		*/
		public function DeleteAllForwardTosAsForWhome() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateForwardToAsForWhome on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`forward_to`
				WHERE
					`for_whome` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for ForwardToAsForwardedTo
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ForwardTosAsForwardedTo as an array of ForwardTo objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ForwardTo[]
		*/
		public function GetForwardToAsForwardedToArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return ForwardTo::LoadArrayByForwardedTo($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ForwardTosAsForwardedTo
		 * @return int
		*/
		public function CountForwardTosAsForwardedTo() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return ForwardTo::CountByForwardedTo($this->intIdlogin);
		}

		/**
		 * Associates a ForwardToAsForwardedTo
		 * @param ForwardTo $objForwardTo
		 * @return void
		*/
		public function AssociateForwardToAsForwardedTo(ForwardTo $objForwardTo) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateForwardToAsForwardedTo on this unsaved Login.');
			if ((is_null($objForwardTo->IdforwardTo)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateForwardToAsForwardedTo on this Login with an unsaved ForwardTo.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`forward_to`
				SET
					`forwarded_to` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idforward_to` = ' . $objDatabase->SqlVariable($objForwardTo->IdforwardTo) . '
			');
		}

		/**
		 * Unassociates a ForwardToAsForwardedTo
		 * @param ForwardTo $objForwardTo
		 * @return void
		*/
		public function UnassociateForwardToAsForwardedTo(ForwardTo $objForwardTo) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateForwardToAsForwardedTo on this unsaved Login.');
			if ((is_null($objForwardTo->IdforwardTo)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateForwardToAsForwardedTo on this Login with an unsaved ForwardTo.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`forward_to`
				SET
					`forwarded_to` = null
				WHERE
					`idforward_to` = ' . $objDatabase->SqlVariable($objForwardTo->IdforwardTo) . ' AND
					`forwarded_to` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all ForwardTosAsForwardedTo
		 * @return void
		*/
		public function UnassociateAllForwardTosAsForwardedTo() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateForwardToAsForwardedTo on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`forward_to`
				SET
					`forwarded_to` = null
				WHERE
					`forwarded_to` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated ForwardToAsForwardedTo
		 * @param ForwardTo $objForwardTo
		 * @return void
		*/
		public function DeleteAssociatedForwardToAsForwardedTo(ForwardTo $objForwardTo) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateForwardToAsForwardedTo on this unsaved Login.');
			if ((is_null($objForwardTo->IdforwardTo)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateForwardToAsForwardedTo on this Login with an unsaved ForwardTo.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`forward_to`
				WHERE
					`idforward_to` = ' . $objDatabase->SqlVariable($objForwardTo->IdforwardTo) . ' AND
					`forwarded_to` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated ForwardTosAsForwardedTo
		 * @return void
		*/
		public function DeleteAllForwardTosAsForwardedTo() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateForwardToAsForwardedTo on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`forward_to`
				WHERE
					`forwarded_to` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for GradeCardAsStudent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated GradeCardsAsStudent as an array of GradeCard objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		*/
		public function GetGradeCardAsStudentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return GradeCard::LoadArrayByStudent($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated GradeCardsAsStudent
		 * @return int
		*/
		public function CountGradeCardsAsStudent() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return GradeCard::CountByStudent($this->intIdlogin);
		}

		/**
		 * Associates a GradeCardAsStudent
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function AssociateGradeCardAsStudent(GradeCard $objGradeCard) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGradeCardAsStudent on this unsaved Login.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGradeCardAsStudent on this Login with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . '
			');
		}

		/**
		 * Unassociates a GradeCardAsStudent
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function UnassociateGradeCardAsStudent(GradeCard $objGradeCard) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsStudent on this unsaved Login.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsStudent on this Login with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`student` = null
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . ' AND
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all GradeCardsAsStudent
		 * @return void
		*/
		public function UnassociateAllGradeCardsAsStudent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsStudent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`student` = null
				WHERE
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated GradeCardAsStudent
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function DeleteAssociatedGradeCardAsStudent(GradeCard $objGradeCard) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsStudent on this unsaved Login.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsStudent on this Login with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . ' AND
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated GradeCardsAsStudent
		 * @return void
		*/
		public function DeleteAllGradeCardsAsStudent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsStudent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`
				WHERE
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for GradeCardAsChangeInEseBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated GradeCardsAsChangeInEseBy as an array of GradeCard objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		*/
		public function GetGradeCardAsChangeInEseByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return GradeCard::LoadArrayByChangeInEseBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated GradeCardsAsChangeInEseBy
		 * @return int
		*/
		public function CountGradeCardsAsChangeInEseBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return GradeCard::CountByChangeInEseBy($this->intIdlogin);
		}

		/**
		 * Associates a GradeCardAsChangeInEseBy
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function AssociateGradeCardAsChangeInEseBy(GradeCard $objGradeCard) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGradeCardAsChangeInEseBy on this unsaved Login.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGradeCardAsChangeInEseBy on this Login with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`change_in_ese_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . '
			');
		}

		/**
		 * Unassociates a GradeCardAsChangeInEseBy
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function UnassociateGradeCardAsChangeInEseBy(GradeCard $objGradeCard) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsChangeInEseBy on this unsaved Login.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsChangeInEseBy on this Login with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`change_in_ese_by` = null
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . ' AND
					`change_in_ese_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all GradeCardsAsChangeInEseBy
		 * @return void
		*/
		public function UnassociateAllGradeCardsAsChangeInEseBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsChangeInEseBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`change_in_ese_by` = null
				WHERE
					`change_in_ese_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated GradeCardAsChangeInEseBy
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function DeleteAssociatedGradeCardAsChangeInEseBy(GradeCard $objGradeCard) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsChangeInEseBy on this unsaved Login.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsChangeInEseBy on this Login with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . ' AND
					`change_in_ese_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated GradeCardsAsChangeInEseBy
		 * @return void
		*/
		public function DeleteAllGradeCardsAsChangeInEseBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsChangeInEseBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`
				WHERE
					`change_in_ese_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for IssuedItemsAsMember
		//-------------------------------------------------------------------

		/**
		 * Gets all associated IssuedItemsesAsMember as an array of IssuedItems objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return IssuedItems[]
		*/
		public function GetIssuedItemsAsMemberArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return IssuedItems::LoadArrayByMember($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated IssuedItemsesAsMember
		 * @return int
		*/
		public function CountIssuedItemsesAsMember() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return IssuedItems::CountByMember($this->intIdlogin);
		}

		/**
		 * Associates a IssuedItemsAsMember
		 * @param IssuedItems $objIssuedItems
		 * @return void
		*/
		public function AssociateIssuedItemsAsMember(IssuedItems $objIssuedItems) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateIssuedItemsAsMember on this unsaved Login.');
			if ((is_null($objIssuedItems->IdissuedItems)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateIssuedItemsAsMember on this Login with an unsaved IssuedItems.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`issued_items`
				SET
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idissued_items` = ' . $objDatabase->SqlVariable($objIssuedItems->IdissuedItems) . '
			');
		}

		/**
		 * Unassociates a IssuedItemsAsMember
		 * @param IssuedItems $objIssuedItems
		 * @return void
		*/
		public function UnassociateIssuedItemsAsMember(IssuedItems $objIssuedItems) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIssuedItemsAsMember on this unsaved Login.');
			if ((is_null($objIssuedItems->IdissuedItems)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIssuedItemsAsMember on this Login with an unsaved IssuedItems.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`issued_items`
				SET
					`member` = null
				WHERE
					`idissued_items` = ' . $objDatabase->SqlVariable($objIssuedItems->IdissuedItems) . ' AND
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all IssuedItemsesAsMember
		 * @return void
		*/
		public function UnassociateAllIssuedItemsesAsMember() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIssuedItemsAsMember on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`issued_items`
				SET
					`member` = null
				WHERE
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated IssuedItemsAsMember
		 * @param IssuedItems $objIssuedItems
		 * @return void
		*/
		public function DeleteAssociatedIssuedItemsAsMember(IssuedItems $objIssuedItems) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIssuedItemsAsMember on this unsaved Login.');
			if ((is_null($objIssuedItems->IdissuedItems)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIssuedItemsAsMember on this Login with an unsaved IssuedItems.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`issued_items`
				WHERE
					`idissued_items` = ' . $objDatabase->SqlVariable($objIssuedItems->IdissuedItems) . ' AND
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated IssuedItemsesAsMember
		 * @return void
		*/
		public function DeleteAllIssuedItemsesAsMember() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIssuedItemsAsMember on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`issued_items`
				WHERE
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for IwowAsDataBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated IwowsAsDataBy as an array of Iwow objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Iwow[]
		*/
		public function GetIwowAsDataByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Iwow::LoadArrayByDataBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated IwowsAsDataBy
		 * @return int
		*/
		public function CountIwowsAsDataBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Iwow::CountByDataBy($this->intIdlogin);
		}

		/**
		 * Associates a IwowAsDataBy
		 * @param Iwow $objIwow
		 * @return void
		*/
		public function AssociateIwowAsDataBy(Iwow $objIwow) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateIwowAsDataBy on this unsaved Login.');
			if ((is_null($objIwow->Idiwow)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateIwowAsDataBy on this Login with an unsaved Iwow.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`iwow`
				SET
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idiwow` = ' . $objDatabase->SqlVariable($objIwow->Idiwow) . '
			');
		}

		/**
		 * Unassociates a IwowAsDataBy
		 * @param Iwow $objIwow
		 * @return void
		*/
		public function UnassociateIwowAsDataBy(Iwow $objIwow) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIwowAsDataBy on this unsaved Login.');
			if ((is_null($objIwow->Idiwow)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIwowAsDataBy on this Login with an unsaved Iwow.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`iwow`
				SET
					`data_by` = null
				WHERE
					`idiwow` = ' . $objDatabase->SqlVariable($objIwow->Idiwow) . ' AND
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all IwowsAsDataBy
		 * @return void
		*/
		public function UnassociateAllIwowsAsDataBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIwowAsDataBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`iwow`
				SET
					`data_by` = null
				WHERE
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated IwowAsDataBy
		 * @param Iwow $objIwow
		 * @return void
		*/
		public function DeleteAssociatedIwowAsDataBy(Iwow $objIwow) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIwowAsDataBy on this unsaved Login.');
			if ((is_null($objIwow->Idiwow)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIwowAsDataBy on this Login with an unsaved Iwow.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`iwow`
				WHERE
					`idiwow` = ' . $objDatabase->SqlVariable($objIwow->Idiwow) . ' AND
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated IwowsAsDataBy
		 * @return void
		*/
		public function DeleteAllIwowsAsDataBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIwowAsDataBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`iwow`
				WHERE
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for IwowAsInspectedBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated IwowsAsInspectedBy as an array of Iwow objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Iwow[]
		*/
		public function GetIwowAsInspectedByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Iwow::LoadArrayByInspectedBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated IwowsAsInspectedBy
		 * @return int
		*/
		public function CountIwowsAsInspectedBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Iwow::CountByInspectedBy($this->intIdlogin);
		}

		/**
		 * Associates a IwowAsInspectedBy
		 * @param Iwow $objIwow
		 * @return void
		*/
		public function AssociateIwowAsInspectedBy(Iwow $objIwow) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateIwowAsInspectedBy on this unsaved Login.');
			if ((is_null($objIwow->Idiwow)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateIwowAsInspectedBy on this Login with an unsaved Iwow.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`iwow`
				SET
					`inspected_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idiwow` = ' . $objDatabase->SqlVariable($objIwow->Idiwow) . '
			');
		}

		/**
		 * Unassociates a IwowAsInspectedBy
		 * @param Iwow $objIwow
		 * @return void
		*/
		public function UnassociateIwowAsInspectedBy(Iwow $objIwow) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIwowAsInspectedBy on this unsaved Login.');
			if ((is_null($objIwow->Idiwow)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIwowAsInspectedBy on this Login with an unsaved Iwow.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`iwow`
				SET
					`inspected_by` = null
				WHERE
					`idiwow` = ' . $objDatabase->SqlVariable($objIwow->Idiwow) . ' AND
					`inspected_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all IwowsAsInspectedBy
		 * @return void
		*/
		public function UnassociateAllIwowsAsInspectedBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIwowAsInspectedBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`iwow`
				SET
					`inspected_by` = null
				WHERE
					`inspected_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated IwowAsInspectedBy
		 * @param Iwow $objIwow
		 * @return void
		*/
		public function DeleteAssociatedIwowAsInspectedBy(Iwow $objIwow) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIwowAsInspectedBy on this unsaved Login.');
			if ((is_null($objIwow->Idiwow)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIwowAsInspectedBy on this Login with an unsaved Iwow.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`iwow`
				WHERE
					`idiwow` = ' . $objDatabase->SqlVariable($objIwow->Idiwow) . ' AND
					`inspected_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated IwowsAsInspectedBy
		 * @return void
		*/
		public function DeleteAllIwowsAsInspectedBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateIwowAsInspectedBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`iwow`
				WHERE
					`inspected_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for LeaveBalanceAsMember
		//-------------------------------------------------------------------

		/**
		 * Gets all associated LeaveBalancesAsMember as an array of LeaveBalance objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveBalance[]
		*/
		public function GetLeaveBalanceAsMemberArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return LeaveBalance::LoadArrayByMember($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated LeaveBalancesAsMember
		 * @return int
		*/
		public function CountLeaveBalancesAsMember() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return LeaveBalance::CountByMember($this->intIdlogin);
		}

		/**
		 * Associates a LeaveBalanceAsMember
		 * @param LeaveBalance $objLeaveBalance
		 * @return void
		*/
		public function AssociateLeaveBalanceAsMember(LeaveBalance $objLeaveBalance) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLeaveBalanceAsMember on this unsaved Login.');
			if ((is_null($objLeaveBalance->IdleaveBalance)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLeaveBalanceAsMember on this Login with an unsaved LeaveBalance.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`leave_balance`
				SET
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idleave_balance` = ' . $objDatabase->SqlVariable($objLeaveBalance->IdleaveBalance) . '
			');
		}

		/**
		 * Unassociates a LeaveBalanceAsMember
		 * @param LeaveBalance $objLeaveBalance
		 * @return void
		*/
		public function UnassociateLeaveBalanceAsMember(LeaveBalance $objLeaveBalance) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveBalanceAsMember on this unsaved Login.');
			if ((is_null($objLeaveBalance->IdleaveBalance)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveBalanceAsMember on this Login with an unsaved LeaveBalance.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`leave_balance`
				SET
					`member` = null
				WHERE
					`idleave_balance` = ' . $objDatabase->SqlVariable($objLeaveBalance->IdleaveBalance) . ' AND
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all LeaveBalancesAsMember
		 * @return void
		*/
		public function UnassociateAllLeaveBalancesAsMember() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveBalanceAsMember on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`leave_balance`
				SET
					`member` = null
				WHERE
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated LeaveBalanceAsMember
		 * @param LeaveBalance $objLeaveBalance
		 * @return void
		*/
		public function DeleteAssociatedLeaveBalanceAsMember(LeaveBalance $objLeaveBalance) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveBalanceAsMember on this unsaved Login.');
			if ((is_null($objLeaveBalance->IdleaveBalance)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveBalanceAsMember on this Login with an unsaved LeaveBalance.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leave_balance`
				WHERE
					`idleave_balance` = ' . $objDatabase->SqlVariable($objLeaveBalance->IdleaveBalance) . ' AND
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated LeaveBalancesAsMember
		 * @return void
		*/
		public function DeleteAllLeaveBalancesAsMember() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveBalanceAsMember on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leave_balance`
				WHERE
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for LogAsDataBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated LogsAsDataBy as an array of Log objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Log[]
		*/
		public function GetLogAsDataByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Log::LoadArrayByDataBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated LogsAsDataBy
		 * @return int
		*/
		public function CountLogsAsDataBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Log::CountByDataBy($this->intIdlogin);
		}

		/**
		 * Associates a LogAsDataBy
		 * @param Log $objLog
		 * @return void
		*/
		public function AssociateLogAsDataBy(Log $objLog) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLogAsDataBy on this unsaved Login.');
			if ((is_null($objLog->Idlog)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLogAsDataBy on this Login with an unsaved Log.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`log`
				SET
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idlog` = ' . $objDatabase->SqlVariable($objLog->Idlog) . '
			');
		}

		/**
		 * Unassociates a LogAsDataBy
		 * @param Log $objLog
		 * @return void
		*/
		public function UnassociateLogAsDataBy(Log $objLog) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsDataBy on this unsaved Login.');
			if ((is_null($objLog->Idlog)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsDataBy on this Login with an unsaved Log.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`log`
				SET
					`data_by` = null
				WHERE
					`idlog` = ' . $objDatabase->SqlVariable($objLog->Idlog) . ' AND
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all LogsAsDataBy
		 * @return void
		*/
		public function UnassociateAllLogsAsDataBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsDataBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`log`
				SET
					`data_by` = null
				WHERE
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated LogAsDataBy
		 * @param Log $objLog
		 * @return void
		*/
		public function DeleteAssociatedLogAsDataBy(Log $objLog) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsDataBy on this unsaved Login.');
			if ((is_null($objLog->Idlog)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsDataBy on this Login with an unsaved Log.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`log`
				WHERE
					`idlog` = ' . $objDatabase->SqlVariable($objLog->Idlog) . ' AND
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated LogsAsDataBy
		 * @return void
		*/
		public function DeleteAllLogsAsDataBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsDataBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`log`
				WHERE
					`data_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for LoginHasRoleAsId
		//-------------------------------------------------------------------

		/**
		 * Gets all associated LoginHasRolesAsId as an array of LoginHasRole objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LoginHasRole[]
		*/
		public function GetLoginHasRoleAsIdArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return LoginHasRole::LoadArrayByLoginIdlogin($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated LoginHasRolesAsId
		 * @return int
		*/
		public function CountLoginHasRolesAsId() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return LoginHasRole::CountByLoginIdlogin($this->intIdlogin);
		}

		/**
		 * Associates a LoginHasRoleAsId
		 * @param LoginHasRole $objLoginHasRole
		 * @return void
		*/
		public function AssociateLoginHasRoleAsId(LoginHasRole $objLoginHasRole) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLoginHasRoleAsId on this unsaved Login.');
			if ((is_null($objLoginHasRole->LoginIdlogin)) || (is_null($objLoginHasRole->RoleIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLoginHasRoleAsId on this Login with an unsaved LoginHasRole.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`login_has_role`
				SET
					`login_idlogin` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`login_idlogin` = ' . $objDatabase->SqlVariable($objLoginHasRole->LoginIdlogin) . ' AND
					`role_idrole` = ' . $objDatabase->SqlVariable($objLoginHasRole->RoleIdrole) . '
			');
		}

		/**
		 * Unassociates a LoginHasRoleAsId
		 * @param LoginHasRole $objLoginHasRole
		 * @return void
		*/
		public function UnassociateLoginHasRoleAsId(LoginHasRole $objLoginHasRole) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this unsaved Login.');
			if ((is_null($objLoginHasRole->LoginIdlogin)) || (is_null($objLoginHasRole->RoleIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this Login with an unsaved LoginHasRole.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`login_has_role`
				SET
					`login_idlogin` = null
				WHERE
					`login_idlogin` = ' . $objDatabase->SqlVariable($objLoginHasRole->LoginIdlogin) . ' AND
					`role_idrole` = ' . $objDatabase->SqlVariable($objLoginHasRole->RoleIdrole) . ' AND
					`login_idlogin` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all LoginHasRolesAsId
		 * @return void
		*/
		public function UnassociateAllLoginHasRolesAsId() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`login_has_role`
				SET
					`login_idlogin` = null
				WHERE
					`login_idlogin` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated LoginHasRoleAsId
		 * @param LoginHasRole $objLoginHasRole
		 * @return void
		*/
		public function DeleteAssociatedLoginHasRoleAsId(LoginHasRole $objLoginHasRole) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this unsaved Login.');
			if ((is_null($objLoginHasRole->LoginIdlogin)) || (is_null($objLoginHasRole->RoleIdrole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this Login with an unsaved LoginHasRole.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`login_has_role`
				WHERE
					`login_idlogin` = ' . $objDatabase->SqlVariable($objLoginHasRole->LoginIdlogin) . ' AND
					`role_idrole` = ' . $objDatabase->SqlVariable($objLoginHasRole->RoleIdrole) . ' AND
					`login_idlogin` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated LoginHasRolesAsId
		 * @return void
		*/
		public function DeleteAllLoginHasRolesAsId() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLoginHasRoleAsId on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`login_has_role`
				WHERE
					`login_idlogin` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for MarkToAsTo
		//-------------------------------------------------------------------

		/**
		 * Gets all associated MarkTosAsTo as an array of MarkTo objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MarkTo[]
		*/
		public function GetMarkToAsToArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return MarkTo::LoadArrayByTo($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated MarkTosAsTo
		 * @return int
		*/
		public function CountMarkTosAsTo() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return MarkTo::CountByTo($this->intIdlogin);
		}

		/**
		 * Associates a MarkToAsTo
		 * @param MarkTo $objMarkTo
		 * @return void
		*/
		public function AssociateMarkToAsTo(MarkTo $objMarkTo) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMarkToAsTo on this unsaved Login.');
			if ((is_null($objMarkTo->IdmarkTo)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMarkToAsTo on this Login with an unsaved MarkTo.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`mark_to`
				SET
					`to` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idmark_to` = ' . $objDatabase->SqlVariable($objMarkTo->IdmarkTo) . '
			');
		}

		/**
		 * Unassociates a MarkToAsTo
		 * @param MarkTo $objMarkTo
		 * @return void
		*/
		public function UnassociateMarkToAsTo(MarkTo $objMarkTo) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMarkToAsTo on this unsaved Login.');
			if ((is_null($objMarkTo->IdmarkTo)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMarkToAsTo on this Login with an unsaved MarkTo.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`mark_to`
				SET
					`to` = null
				WHERE
					`idmark_to` = ' . $objDatabase->SqlVariable($objMarkTo->IdmarkTo) . ' AND
					`to` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all MarkTosAsTo
		 * @return void
		*/
		public function UnassociateAllMarkTosAsTo() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMarkToAsTo on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`mark_to`
				SET
					`to` = null
				WHERE
					`to` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated MarkToAsTo
		 * @param MarkTo $objMarkTo
		 * @return void
		*/
		public function DeleteAssociatedMarkToAsTo(MarkTo $objMarkTo) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMarkToAsTo on this unsaved Login.');
			if ((is_null($objMarkTo->IdmarkTo)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMarkToAsTo on this Login with an unsaved MarkTo.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`mark_to`
				WHERE
					`idmark_to` = ' . $objDatabase->SqlVariable($objMarkTo->IdmarkTo) . ' AND
					`to` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated MarkTosAsTo
		 * @return void
		*/
		public function DeleteAllMarkTosAsTo() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMarkToAsTo on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`mark_to`
				WHERE
					`to` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for MarkToAsFrom
		//-------------------------------------------------------------------

		/**
		 * Gets all associated MarkTosAsFrom as an array of MarkTo objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MarkTo[]
		*/
		public function GetMarkToAsFromArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return MarkTo::LoadArrayByFrom($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated MarkTosAsFrom
		 * @return int
		*/
		public function CountMarkTosAsFrom() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return MarkTo::CountByFrom($this->intIdlogin);
		}

		/**
		 * Associates a MarkToAsFrom
		 * @param MarkTo $objMarkTo
		 * @return void
		*/
		public function AssociateMarkToAsFrom(MarkTo $objMarkTo) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMarkToAsFrom on this unsaved Login.');
			if ((is_null($objMarkTo->IdmarkTo)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMarkToAsFrom on this Login with an unsaved MarkTo.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`mark_to`
				SET
					`from` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idmark_to` = ' . $objDatabase->SqlVariable($objMarkTo->IdmarkTo) . '
			');
		}

		/**
		 * Unassociates a MarkToAsFrom
		 * @param MarkTo $objMarkTo
		 * @return void
		*/
		public function UnassociateMarkToAsFrom(MarkTo $objMarkTo) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMarkToAsFrom on this unsaved Login.');
			if ((is_null($objMarkTo->IdmarkTo)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMarkToAsFrom on this Login with an unsaved MarkTo.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`mark_to`
				SET
					`from` = null
				WHERE
					`idmark_to` = ' . $objDatabase->SqlVariable($objMarkTo->IdmarkTo) . ' AND
					`from` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all MarkTosAsFrom
		 * @return void
		*/
		public function UnassociateAllMarkTosAsFrom() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMarkToAsFrom on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`mark_to`
				SET
					`from` = null
				WHERE
					`from` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated MarkToAsFrom
		 * @param MarkTo $objMarkTo
		 * @return void
		*/
		public function DeleteAssociatedMarkToAsFrom(MarkTo $objMarkTo) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMarkToAsFrom on this unsaved Login.');
			if ((is_null($objMarkTo->IdmarkTo)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMarkToAsFrom on this Login with an unsaved MarkTo.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`mark_to`
				WHERE
					`idmark_to` = ' . $objDatabase->SqlVariable($objMarkTo->IdmarkTo) . ' AND
					`from` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated MarkTosAsFrom
		 * @return void
		*/
		public function DeleteAllMarkTosAsFrom() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMarkToAsFrom on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`mark_to`
				WHERE
					`from` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for MeetingAgendaPoleAsAttendees
		//-------------------------------------------------------------------

		/**
		 * Gets all associated MeetingAgendaPolesAsAttendees as an array of MeetingAgendaPole objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingAgendaPole[]
		*/
		public function GetMeetingAgendaPoleAsAttendeesArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return MeetingAgendaPole::LoadArrayByAttendees($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated MeetingAgendaPolesAsAttendees
		 * @return int
		*/
		public function CountMeetingAgendaPolesAsAttendees() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return MeetingAgendaPole::CountByAttendees($this->intIdlogin);
		}

		/**
		 * Associates a MeetingAgendaPoleAsAttendees
		 * @param MeetingAgendaPole $objMeetingAgendaPole
		 * @return void
		*/
		public function AssociateMeetingAgendaPoleAsAttendees(MeetingAgendaPole $objMeetingAgendaPole) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMeetingAgendaPoleAsAttendees on this unsaved Login.');
			if ((is_null($objMeetingAgendaPole->IdmeetingAgendaPole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMeetingAgendaPoleAsAttendees on this Login with an unsaved MeetingAgendaPole.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_agenda_pole`
				SET
					`attendees` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idmeeting_agenda_pole` = ' . $objDatabase->SqlVariable($objMeetingAgendaPole->IdmeetingAgendaPole) . '
			');
		}

		/**
		 * Unassociates a MeetingAgendaPoleAsAttendees
		 * @param MeetingAgendaPole $objMeetingAgendaPole
		 * @return void
		*/
		public function UnassociateMeetingAgendaPoleAsAttendees(MeetingAgendaPole $objMeetingAgendaPole) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingAgendaPoleAsAttendees on this unsaved Login.');
			if ((is_null($objMeetingAgendaPole->IdmeetingAgendaPole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingAgendaPoleAsAttendees on this Login with an unsaved MeetingAgendaPole.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_agenda_pole`
				SET
					`attendees` = null
				WHERE
					`idmeeting_agenda_pole` = ' . $objDatabase->SqlVariable($objMeetingAgendaPole->IdmeetingAgendaPole) . ' AND
					`attendees` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all MeetingAgendaPolesAsAttendees
		 * @return void
		*/
		public function UnassociateAllMeetingAgendaPolesAsAttendees() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingAgendaPoleAsAttendees on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_agenda_pole`
				SET
					`attendees` = null
				WHERE
					`attendees` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated MeetingAgendaPoleAsAttendees
		 * @param MeetingAgendaPole $objMeetingAgendaPole
		 * @return void
		*/
		public function DeleteAssociatedMeetingAgendaPoleAsAttendees(MeetingAgendaPole $objMeetingAgendaPole) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingAgendaPoleAsAttendees on this unsaved Login.');
			if ((is_null($objMeetingAgendaPole->IdmeetingAgendaPole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingAgendaPoleAsAttendees on this Login with an unsaved MeetingAgendaPole.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_agenda_pole`
				WHERE
					`idmeeting_agenda_pole` = ' . $objDatabase->SqlVariable($objMeetingAgendaPole->IdmeetingAgendaPole) . ' AND
					`attendees` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated MeetingAgendaPolesAsAttendees
		 * @return void
		*/
		public function DeleteAllMeetingAgendaPolesAsAttendees() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingAgendaPoleAsAttendees on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_agenda_pole`
				WHERE
					`attendees` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for MeetingGroupHasMembersAsMember
		//-------------------------------------------------------------------

		/**
		 * Gets all associated MeetingGroupHasMembersesAsMember as an array of MeetingGroupHasMembers objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingGroupHasMembers[]
		*/
		public function GetMeetingGroupHasMembersAsMemberArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return MeetingGroupHasMembers::LoadArrayByMember($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated MeetingGroupHasMembersesAsMember
		 * @return int
		*/
		public function CountMeetingGroupHasMembersesAsMember() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return MeetingGroupHasMembers::CountByMember($this->intIdlogin);
		}

		/**
		 * Associates a MeetingGroupHasMembersAsMember
		 * @param MeetingGroupHasMembers $objMeetingGroupHasMembers
		 * @return void
		*/
		public function AssociateMeetingGroupHasMembersAsMember(MeetingGroupHasMembers $objMeetingGroupHasMembers) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMeetingGroupHasMembersAsMember on this unsaved Login.');
			if ((is_null($objMeetingGroupHasMembers->IdmeetingGroupHasMembers)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMeetingGroupHasMembersAsMember on this Login with an unsaved MeetingGroupHasMembers.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_group_has_members`
				SET
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idmeeting_group_has_members` = ' . $objDatabase->SqlVariable($objMeetingGroupHasMembers->IdmeetingGroupHasMembers) . '
			');
		}

		/**
		 * Unassociates a MeetingGroupHasMembersAsMember
		 * @param MeetingGroupHasMembers $objMeetingGroupHasMembers
		 * @return void
		*/
		public function UnassociateMeetingGroupHasMembersAsMember(MeetingGroupHasMembers $objMeetingGroupHasMembers) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingGroupHasMembersAsMember on this unsaved Login.');
			if ((is_null($objMeetingGroupHasMembers->IdmeetingGroupHasMembers)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingGroupHasMembersAsMember on this Login with an unsaved MeetingGroupHasMembers.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_group_has_members`
				SET
					`member` = null
				WHERE
					`idmeeting_group_has_members` = ' . $objDatabase->SqlVariable($objMeetingGroupHasMembers->IdmeetingGroupHasMembers) . ' AND
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all MeetingGroupHasMembersesAsMember
		 * @return void
		*/
		public function UnassociateAllMeetingGroupHasMembersesAsMember() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingGroupHasMembersAsMember on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_group_has_members`
				SET
					`member` = null
				WHERE
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated MeetingGroupHasMembersAsMember
		 * @param MeetingGroupHasMembers $objMeetingGroupHasMembers
		 * @return void
		*/
		public function DeleteAssociatedMeetingGroupHasMembersAsMember(MeetingGroupHasMembers $objMeetingGroupHasMembers) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingGroupHasMembersAsMember on this unsaved Login.');
			if ((is_null($objMeetingGroupHasMembers->IdmeetingGroupHasMembers)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingGroupHasMembersAsMember on this Login with an unsaved MeetingGroupHasMembers.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_group_has_members`
				WHERE
					`idmeeting_group_has_members` = ' . $objDatabase->SqlVariable($objMeetingGroupHasMembers->IdmeetingGroupHasMembers) . ' AND
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated MeetingGroupHasMembersesAsMember
		 * @return void
		*/
		public function DeleteAllMeetingGroupHasMembersesAsMember() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingGroupHasMembersAsMember on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_group_has_members`
				WHERE
					`member` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for MeetingNotesAsReferedBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated MeetingNotesesAsReferedBy as an array of MeetingNotes objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingNotes[]
		*/
		public function GetMeetingNotesAsReferedByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return MeetingNotes::LoadArrayByReferedBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated MeetingNotesesAsReferedBy
		 * @return int
		*/
		public function CountMeetingNotesesAsReferedBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return MeetingNotes::CountByReferedBy($this->intIdlogin);
		}

		/**
		 * Associates a MeetingNotesAsReferedBy
		 * @param MeetingNotes $objMeetingNotes
		 * @return void
		*/
		public function AssociateMeetingNotesAsReferedBy(MeetingNotes $objMeetingNotes) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMeetingNotesAsReferedBy on this unsaved Login.');
			if ((is_null($objMeetingNotes->IdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMeetingNotesAsReferedBy on this Login with an unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_notes`
				SET
					`refered_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idmeeting_notes` = ' . $objDatabase->SqlVariable($objMeetingNotes->IdmeetingNotes) . '
			');
		}

		/**
		 * Unassociates a MeetingNotesAsReferedBy
		 * @param MeetingNotes $objMeetingNotes
		 * @return void
		*/
		public function UnassociateMeetingNotesAsReferedBy(MeetingNotes $objMeetingNotes) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsReferedBy on this unsaved Login.');
			if ((is_null($objMeetingNotes->IdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsReferedBy on this Login with an unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_notes`
				SET
					`refered_by` = null
				WHERE
					`idmeeting_notes` = ' . $objDatabase->SqlVariable($objMeetingNotes->IdmeetingNotes) . ' AND
					`refered_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all MeetingNotesesAsReferedBy
		 * @return void
		*/
		public function UnassociateAllMeetingNotesesAsReferedBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsReferedBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_notes`
				SET
					`refered_by` = null
				WHERE
					`refered_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated MeetingNotesAsReferedBy
		 * @param MeetingNotes $objMeetingNotes
		 * @return void
		*/
		public function DeleteAssociatedMeetingNotesAsReferedBy(MeetingNotes $objMeetingNotes) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsReferedBy on this unsaved Login.');
			if ((is_null($objMeetingNotes->IdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsReferedBy on this Login with an unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_notes`
				WHERE
					`idmeeting_notes` = ' . $objDatabase->SqlVariable($objMeetingNotes->IdmeetingNotes) . ' AND
					`refered_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated MeetingNotesesAsReferedBy
		 * @return void
		*/
		public function DeleteAllMeetingNotesesAsReferedBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsReferedBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_notes`
				WHERE
					`refered_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for MeetingNotesAsActionOn
		//-------------------------------------------------------------------

		/**
		 * Gets all associated MeetingNotesesAsActionOn as an array of MeetingNotes objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingNotes[]
		*/
		public function GetMeetingNotesAsActionOnArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return MeetingNotes::LoadArrayByActionOn($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated MeetingNotesesAsActionOn
		 * @return int
		*/
		public function CountMeetingNotesesAsActionOn() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return MeetingNotes::CountByActionOn($this->intIdlogin);
		}

		/**
		 * Associates a MeetingNotesAsActionOn
		 * @param MeetingNotes $objMeetingNotes
		 * @return void
		*/
		public function AssociateMeetingNotesAsActionOn(MeetingNotes $objMeetingNotes) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMeetingNotesAsActionOn on this unsaved Login.');
			if ((is_null($objMeetingNotes->IdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMeetingNotesAsActionOn on this Login with an unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_notes`
				SET
					`action_on` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idmeeting_notes` = ' . $objDatabase->SqlVariable($objMeetingNotes->IdmeetingNotes) . '
			');
		}

		/**
		 * Unassociates a MeetingNotesAsActionOn
		 * @param MeetingNotes $objMeetingNotes
		 * @return void
		*/
		public function UnassociateMeetingNotesAsActionOn(MeetingNotes $objMeetingNotes) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsActionOn on this unsaved Login.');
			if ((is_null($objMeetingNotes->IdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsActionOn on this Login with an unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_notes`
				SET
					`action_on` = null
				WHERE
					`idmeeting_notes` = ' . $objDatabase->SqlVariable($objMeetingNotes->IdmeetingNotes) . ' AND
					`action_on` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all MeetingNotesesAsActionOn
		 * @return void
		*/
		public function UnassociateAllMeetingNotesesAsActionOn() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsActionOn on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_notes`
				SET
					`action_on` = null
				WHERE
					`action_on` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated MeetingNotesAsActionOn
		 * @param MeetingNotes $objMeetingNotes
		 * @return void
		*/
		public function DeleteAssociatedMeetingNotesAsActionOn(MeetingNotes $objMeetingNotes) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsActionOn on this unsaved Login.');
			if ((is_null($objMeetingNotes->IdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsActionOn on this Login with an unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_notes`
				WHERE
					`idmeeting_notes` = ' . $objDatabase->SqlVariable($objMeetingNotes->IdmeetingNotes) . ' AND
					`action_on` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated MeetingNotesesAsActionOn
		 * @return void
		*/
		public function DeleteAllMeetingNotesesAsActionOn() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsActionOn on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_notes`
				WHERE
					`action_on` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for NoteAsDataby
		//-------------------------------------------------------------------

		/**
		 * Gets all associated NotesAsDataby as an array of Note objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Note[]
		*/
		public function GetNoteAsDatabyArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Note::LoadArrayByDataby($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated NotesAsDataby
		 * @return int
		*/
		public function CountNotesAsDataby() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Note::CountByDataby($this->intIdlogin);
		}

		/**
		 * Associates a NoteAsDataby
		 * @param Note $objNote
		 * @return void
		*/
		public function AssociateNoteAsDataby(Note $objNote) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateNoteAsDataby on this unsaved Login.');
			if ((is_null($objNote->Idnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateNoteAsDataby on this Login with an unsaved Note.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`note`
				SET
					`databy` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idnote` = ' . $objDatabase->SqlVariable($objNote->Idnote) . '
			');
		}

		/**
		 * Unassociates a NoteAsDataby
		 * @param Note $objNote
		 * @return void
		*/
		public function UnassociateNoteAsDataby(Note $objNote) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNoteAsDataby on this unsaved Login.');
			if ((is_null($objNote->Idnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNoteAsDataby on this Login with an unsaved Note.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`note`
				SET
					`databy` = null
				WHERE
					`idnote` = ' . $objDatabase->SqlVariable($objNote->Idnote) . ' AND
					`databy` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all NotesAsDataby
		 * @return void
		*/
		public function UnassociateAllNotesAsDataby() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNoteAsDataby on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`note`
				SET
					`databy` = null
				WHERE
					`databy` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated NoteAsDataby
		 * @param Note $objNote
		 * @return void
		*/
		public function DeleteAssociatedNoteAsDataby(Note $objNote) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNoteAsDataby on this unsaved Login.');
			if ((is_null($objNote->Idnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNoteAsDataby on this Login with an unsaved Note.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`note`
				WHERE
					`idnote` = ' . $objDatabase->SqlVariable($objNote->Idnote) . ' AND
					`databy` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated NotesAsDataby
		 * @return void
		*/
		public function DeleteAllNotesAsDataby() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNoteAsDataby on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`note`
				WHERE
					`databy` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for ReEvaluationAsStudent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ReEvaluationsAsStudent as an array of ReEvaluation objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ReEvaluation[]
		*/
		public function GetReEvaluationAsStudentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return ReEvaluation::LoadArrayByStudent($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ReEvaluationsAsStudent
		 * @return int
		*/
		public function CountReEvaluationsAsStudent() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return ReEvaluation::CountByStudent($this->intIdlogin);
		}

		/**
		 * Associates a ReEvaluationAsStudent
		 * @param ReEvaluation $objReEvaluation
		 * @return void
		*/
		public function AssociateReEvaluationAsStudent(ReEvaluation $objReEvaluation) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateReEvaluationAsStudent on this unsaved Login.');
			if ((is_null($objReEvaluation->IdreEvaluation)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateReEvaluationAsStudent on this Login with an unsaved ReEvaluation.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`re_evaluation`
				SET
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idre_evaluation` = ' . $objDatabase->SqlVariable($objReEvaluation->IdreEvaluation) . '
			');
		}

		/**
		 * Unassociates a ReEvaluationAsStudent
		 * @param ReEvaluation $objReEvaluation
		 * @return void
		*/
		public function UnassociateReEvaluationAsStudent(ReEvaluation $objReEvaluation) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluationAsStudent on this unsaved Login.');
			if ((is_null($objReEvaluation->IdreEvaluation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluationAsStudent on this Login with an unsaved ReEvaluation.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`re_evaluation`
				SET
					`student` = null
				WHERE
					`idre_evaluation` = ' . $objDatabase->SqlVariable($objReEvaluation->IdreEvaluation) . ' AND
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all ReEvaluationsAsStudent
		 * @return void
		*/
		public function UnassociateAllReEvaluationsAsStudent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluationAsStudent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`re_evaluation`
				SET
					`student` = null
				WHERE
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated ReEvaluationAsStudent
		 * @param ReEvaluation $objReEvaluation
		 * @return void
		*/
		public function DeleteAssociatedReEvaluationAsStudent(ReEvaluation $objReEvaluation) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluationAsStudent on this unsaved Login.');
			if ((is_null($objReEvaluation->IdreEvaluation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluationAsStudent on this Login with an unsaved ReEvaluation.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`re_evaluation`
				WHERE
					`idre_evaluation` = ' . $objDatabase->SqlVariable($objReEvaluation->IdreEvaluation) . ' AND
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated ReEvaluationsAsStudent
		 * @return void
		*/
		public function DeleteAllReEvaluationsAsStudent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluationAsStudent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`re_evaluation`
				WHERE
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for SalarysheetApprovalAsApprovedBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated SalarysheetApprovalsAsApprovedBy as an array of SalarysheetApproval objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalarysheetApproval[]
		*/
		public function GetSalarysheetApprovalAsApprovedByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return SalarysheetApproval::LoadArrayByApprovedBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated SalarysheetApprovalsAsApprovedBy
		 * @return int
		*/
		public function CountSalarysheetApprovalsAsApprovedBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return SalarysheetApproval::CountByApprovedBy($this->intIdlogin);
		}

		/**
		 * Associates a SalarysheetApprovalAsApprovedBy
		 * @param SalarysheetApproval $objSalarysheetApproval
		 * @return void
		*/
		public function AssociateSalarysheetApprovalAsApprovedBy(SalarysheetApproval $objSalarysheetApproval) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSalarysheetApprovalAsApprovedBy on this unsaved Login.');
			if ((is_null($objSalarysheetApproval->IdsalarysheetApproval)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSalarysheetApprovalAsApprovedBy on this Login with an unsaved SalarysheetApproval.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salarysheet_approval`
				SET
					`approved_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idsalarysheet_approval` = ' . $objDatabase->SqlVariable($objSalarysheetApproval->IdsalarysheetApproval) . '
			');
		}

		/**
		 * Unassociates a SalarysheetApprovalAsApprovedBy
		 * @param SalarysheetApproval $objSalarysheetApproval
		 * @return void
		*/
		public function UnassociateSalarysheetApprovalAsApprovedBy(SalarysheetApproval $objSalarysheetApproval) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetApprovalAsApprovedBy on this unsaved Login.');
			if ((is_null($objSalarysheetApproval->IdsalarysheetApproval)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetApprovalAsApprovedBy on this Login with an unsaved SalarysheetApproval.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salarysheet_approval`
				SET
					`approved_by` = null
				WHERE
					`idsalarysheet_approval` = ' . $objDatabase->SqlVariable($objSalarysheetApproval->IdsalarysheetApproval) . ' AND
					`approved_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all SalarysheetApprovalsAsApprovedBy
		 * @return void
		*/
		public function UnassociateAllSalarysheetApprovalsAsApprovedBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetApprovalAsApprovedBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salarysheet_approval`
				SET
					`approved_by` = null
				WHERE
					`approved_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated SalarysheetApprovalAsApprovedBy
		 * @param SalarysheetApproval $objSalarysheetApproval
		 * @return void
		*/
		public function DeleteAssociatedSalarysheetApprovalAsApprovedBy(SalarysheetApproval $objSalarysheetApproval) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetApprovalAsApprovedBy on this unsaved Login.');
			if ((is_null($objSalarysheetApproval->IdsalarysheetApproval)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetApprovalAsApprovedBy on this Login with an unsaved SalarysheetApproval.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salarysheet_approval`
				WHERE
					`idsalarysheet_approval` = ' . $objDatabase->SqlVariable($objSalarysheetApproval->IdsalarysheetApproval) . ' AND
					`approved_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated SalarysheetApprovalsAsApprovedBy
		 * @return void
		*/
		public function DeleteAllSalarysheetApprovalsAsApprovedBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetApprovalAsApprovedBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salarysheet_approval`
				WHERE
					`approved_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for SignPatch
		//-------------------------------------------------------------------

		/**
		 * Gets all associated SignPatches as an array of SignPatch objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SignPatch[]
		*/
		public function GetSignPatchArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return SignPatch::LoadArrayByLogin($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated SignPatches
		 * @return int
		*/
		public function CountSignPatches() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return SignPatch::CountByLogin($this->intIdlogin);
		}

		/**
		 * Associates a SignPatch
		 * @param SignPatch $objSignPatch
		 * @return void
		*/
		public function AssociateSignPatch(SignPatch $objSignPatch) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSignPatch on this unsaved Login.');
			if ((is_null($objSignPatch->IdsignPatch)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSignPatch on this Login with an unsaved SignPatch.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`sign_patch`
				SET
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idsign_patch` = ' . $objDatabase->SqlVariable($objSignPatch->IdsignPatch) . '
			');
		}

		/**
		 * Unassociates a SignPatch
		 * @param SignPatch $objSignPatch
		 * @return void
		*/
		public function UnassociateSignPatch(SignPatch $objSignPatch) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSignPatch on this unsaved Login.');
			if ((is_null($objSignPatch->IdsignPatch)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSignPatch on this Login with an unsaved SignPatch.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`sign_patch`
				SET
					`login` = null
				WHERE
					`idsign_patch` = ' . $objDatabase->SqlVariable($objSignPatch->IdsignPatch) . ' AND
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all SignPatches
		 * @return void
		*/
		public function UnassociateAllSignPatches() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSignPatch on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`sign_patch`
				SET
					`login` = null
				WHERE
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated SignPatch
		 * @param SignPatch $objSignPatch
		 * @return void
		*/
		public function DeleteAssociatedSignPatch(SignPatch $objSignPatch) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSignPatch on this unsaved Login.');
			if ((is_null($objSignPatch->IdsignPatch)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSignPatch on this Login with an unsaved SignPatch.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`sign_patch`
				WHERE
					`idsign_patch` = ' . $objDatabase->SqlVariable($objSignPatch->IdsignPatch) . ' AND
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated SignPatches
		 * @return void
		*/
		public function DeleteAllSignPatches() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSignPatch on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`sign_patch`
				WHERE
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for StudAttendenceAsStudent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated StudAttendencesAsStudent as an array of StudAttendence objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return StudAttendence[]
		*/
		public function GetStudAttendenceAsStudentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return StudAttendence::LoadArrayByStudent($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated StudAttendencesAsStudent
		 * @return int
		*/
		public function CountStudAttendencesAsStudent() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return StudAttendence::CountByStudent($this->intIdlogin);
		}

		/**
		 * Associates a StudAttendenceAsStudent
		 * @param StudAttendence $objStudAttendence
		 * @return void
		*/
		public function AssociateStudAttendenceAsStudent(StudAttendence $objStudAttendence) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateStudAttendenceAsStudent on this unsaved Login.');
			if ((is_null($objStudAttendence->IdstudAttendence)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateStudAttendenceAsStudent on this Login with an unsaved StudAttendence.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`stud_attendence`
				SET
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idstud_attendence` = ' . $objDatabase->SqlVariable($objStudAttendence->IdstudAttendence) . '
			');
		}

		/**
		 * Unassociates a StudAttendenceAsStudent
		 * @param StudAttendence $objStudAttendence
		 * @return void
		*/
		public function UnassociateStudAttendenceAsStudent(StudAttendence $objStudAttendence) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendenceAsStudent on this unsaved Login.');
			if ((is_null($objStudAttendence->IdstudAttendence)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendenceAsStudent on this Login with an unsaved StudAttendence.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`stud_attendence`
				SET
					`student` = null
				WHERE
					`idstud_attendence` = ' . $objDatabase->SqlVariable($objStudAttendence->IdstudAttendence) . ' AND
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all StudAttendencesAsStudent
		 * @return void
		*/
		public function UnassociateAllStudAttendencesAsStudent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendenceAsStudent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`stud_attendence`
				SET
					`student` = null
				WHERE
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated StudAttendenceAsStudent
		 * @param StudAttendence $objStudAttendence
		 * @return void
		*/
		public function DeleteAssociatedStudAttendenceAsStudent(StudAttendence $objStudAttendence) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendenceAsStudent on this unsaved Login.');
			if ((is_null($objStudAttendence->IdstudAttendence)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendenceAsStudent on this Login with an unsaved StudAttendence.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`stud_attendence`
				WHERE
					`idstud_attendence` = ' . $objDatabase->SqlVariable($objStudAttendence->IdstudAttendence) . ' AND
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated StudAttendencesAsStudent
		 * @return void
		*/
		public function DeleteAllStudAttendencesAsStudent() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendenceAsStudent on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`stud_attendence`
				WHERE
					`student` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for StudAttendenceAsStaff
		//-------------------------------------------------------------------

		/**
		 * Gets all associated StudAttendencesAsStaff as an array of StudAttendence objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return StudAttendence[]
		*/
		public function GetStudAttendenceAsStaffArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return StudAttendence::LoadArrayByStaff($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated StudAttendencesAsStaff
		 * @return int
		*/
		public function CountStudAttendencesAsStaff() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return StudAttendence::CountByStaff($this->intIdlogin);
		}

		/**
		 * Associates a StudAttendenceAsStaff
		 * @param StudAttendence $objStudAttendence
		 * @return void
		*/
		public function AssociateStudAttendenceAsStaff(StudAttendence $objStudAttendence) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateStudAttendenceAsStaff on this unsaved Login.');
			if ((is_null($objStudAttendence->IdstudAttendence)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateStudAttendenceAsStaff on this Login with an unsaved StudAttendence.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`stud_attendence`
				SET
					`staff` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idstud_attendence` = ' . $objDatabase->SqlVariable($objStudAttendence->IdstudAttendence) . '
			');
		}

		/**
		 * Unassociates a StudAttendenceAsStaff
		 * @param StudAttendence $objStudAttendence
		 * @return void
		*/
		public function UnassociateStudAttendenceAsStaff(StudAttendence $objStudAttendence) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendenceAsStaff on this unsaved Login.');
			if ((is_null($objStudAttendence->IdstudAttendence)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendenceAsStaff on this Login with an unsaved StudAttendence.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`stud_attendence`
				SET
					`staff` = null
				WHERE
					`idstud_attendence` = ' . $objDatabase->SqlVariable($objStudAttendence->IdstudAttendence) . ' AND
					`staff` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all StudAttendencesAsStaff
		 * @return void
		*/
		public function UnassociateAllStudAttendencesAsStaff() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendenceAsStaff on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`stud_attendence`
				SET
					`staff` = null
				WHERE
					`staff` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated StudAttendenceAsStaff
		 * @param StudAttendence $objStudAttendence
		 * @return void
		*/
		public function DeleteAssociatedStudAttendenceAsStaff(StudAttendence $objStudAttendence) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendenceAsStaff on this unsaved Login.');
			if ((is_null($objStudAttendence->IdstudAttendence)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendenceAsStaff on this Login with an unsaved StudAttendence.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`stud_attendence`
				WHERE
					`idstud_attendence` = ' . $objDatabase->SqlVariable($objStudAttendence->IdstudAttendence) . ' AND
					`staff` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated StudAttendencesAsStaff
		 * @return void
		*/
		public function DeleteAllStudAttendencesAsStaff() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendenceAsStaff on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`stud_attendence`
				WHERE
					`staff` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for SubjectTought
		//-------------------------------------------------------------------

		/**
		 * Gets all associated SubjectToughts as an array of SubjectTought objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SubjectTought[]
		*/
		public function GetSubjectToughtArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return SubjectTought::LoadArrayByLogin($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated SubjectToughts
		 * @return int
		*/
		public function CountSubjectToughts() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return SubjectTought::CountByLogin($this->intIdlogin);
		}

		/**
		 * Associates a SubjectTought
		 * @param SubjectTought $objSubjectTought
		 * @return void
		*/
		public function AssociateSubjectTought(SubjectTought $objSubjectTought) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSubjectTought on this unsaved Login.');
			if ((is_null($objSubjectTought->IdsubjectTought)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSubjectTought on this Login with an unsaved SubjectTought.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`subject_tought`
				SET
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idsubject_tought` = ' . $objDatabase->SqlVariable($objSubjectTought->IdsubjectTought) . '
			');
		}

		/**
		 * Unassociates a SubjectTought
		 * @param SubjectTought $objSubjectTought
		 * @return void
		*/
		public function UnassociateSubjectTought(SubjectTought $objSubjectTought) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSubjectTought on this unsaved Login.');
			if ((is_null($objSubjectTought->IdsubjectTought)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSubjectTought on this Login with an unsaved SubjectTought.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`subject_tought`
				SET
					`login` = null
				WHERE
					`idsubject_tought` = ' . $objDatabase->SqlVariable($objSubjectTought->IdsubjectTought) . ' AND
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all SubjectToughts
		 * @return void
		*/
		public function UnassociateAllSubjectToughts() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSubjectTought on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`subject_tought`
				SET
					`login` = null
				WHERE
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated SubjectTought
		 * @param SubjectTought $objSubjectTought
		 * @return void
		*/
		public function DeleteAssociatedSubjectTought(SubjectTought $objSubjectTought) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSubjectTought on this unsaved Login.');
			if ((is_null($objSubjectTought->IdsubjectTought)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSubjectTought on this Login with an unsaved SubjectTought.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`subject_tought`
				WHERE
					`idsubject_tought` = ' . $objDatabase->SqlVariable($objSubjectTought->IdsubjectTought) . ' AND
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated SubjectToughts
		 * @return void
		*/
		public function DeleteAllSubjectToughts() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSubjectTought on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`subject_tought`
				WHERE
					`login` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for TimetableAsAttendant
		//-------------------------------------------------------------------

		/**
		 * Gets all associated TimetablesAsAttendant as an array of Timetable objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Timetable[]
		*/
		public function GetTimetableAsAttendantArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Timetable::LoadArrayByAttendant($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated TimetablesAsAttendant
		 * @return int
		*/
		public function CountTimetablesAsAttendant() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Timetable::CountByAttendant($this->intIdlogin);
		}

		/**
		 * Associates a TimetableAsAttendant
		 * @param Timetable $objTimetable
		 * @return void
		*/
		public function AssociateTimetableAsAttendant(Timetable $objTimetable) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateTimetableAsAttendant on this unsaved Login.');
			if ((is_null($objTimetable->Idtimetable)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateTimetableAsAttendant on this Login with an unsaved Timetable.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`timetable`
				SET
					`attendant` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idtimetable` = ' . $objDatabase->SqlVariable($objTimetable->Idtimetable) . '
			');
		}

		/**
		 * Unassociates a TimetableAsAttendant
		 * @param Timetable $objTimetable
		 * @return void
		*/
		public function UnassociateTimetableAsAttendant(Timetable $objTimetable) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTimetableAsAttendant on this unsaved Login.');
			if ((is_null($objTimetable->Idtimetable)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTimetableAsAttendant on this Login with an unsaved Timetable.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`timetable`
				SET
					`attendant` = null
				WHERE
					`idtimetable` = ' . $objDatabase->SqlVariable($objTimetable->Idtimetable) . ' AND
					`attendant` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all TimetablesAsAttendant
		 * @return void
		*/
		public function UnassociateAllTimetablesAsAttendant() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTimetableAsAttendant on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`timetable`
				SET
					`attendant` = null
				WHERE
					`attendant` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated TimetableAsAttendant
		 * @param Timetable $objTimetable
		 * @return void
		*/
		public function DeleteAssociatedTimetableAsAttendant(Timetable $objTimetable) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTimetableAsAttendant on this unsaved Login.');
			if ((is_null($objTimetable->Idtimetable)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTimetableAsAttendant on this Login with an unsaved Timetable.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`timetable`
				WHERE
					`idtimetable` = ' . $objDatabase->SqlVariable($objTimetable->Idtimetable) . ' AND
					`attendant` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated TimetablesAsAttendant
		 * @return void
		*/
		public function DeleteAllTimetablesAsAttendant() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTimetableAsAttendant on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`timetable`
				WHERE
					`attendant` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for VisitorPassAsForWhome
		//-------------------------------------------------------------------

		/**
		 * Gets all associated VisitorPassesAsForWhome as an array of VisitorPass objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return VisitorPass[]
		*/
		public function GetVisitorPassAsForWhomeArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return VisitorPass::LoadArrayByForWhome($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated VisitorPassesAsForWhome
		 * @return int
		*/
		public function CountVisitorPassesAsForWhome() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return VisitorPass::CountByForWhome($this->intIdlogin);
		}

		/**
		 * Associates a VisitorPassAsForWhome
		 * @param VisitorPass $objVisitorPass
		 * @return void
		*/
		public function AssociateVisitorPassAsForWhome(VisitorPass $objVisitorPass) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVisitorPassAsForWhome on this unsaved Login.');
			if ((is_null($objVisitorPass->IdvisitorPass)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVisitorPassAsForWhome on this Login with an unsaved VisitorPass.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`visitor_pass`
				SET
					`for_whome` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idvisitor_pass` = ' . $objDatabase->SqlVariable($objVisitorPass->IdvisitorPass) . '
			');
		}

		/**
		 * Unassociates a VisitorPassAsForWhome
		 * @param VisitorPass $objVisitorPass
		 * @return void
		*/
		public function UnassociateVisitorPassAsForWhome(VisitorPass $objVisitorPass) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVisitorPassAsForWhome on this unsaved Login.');
			if ((is_null($objVisitorPass->IdvisitorPass)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVisitorPassAsForWhome on this Login with an unsaved VisitorPass.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`visitor_pass`
				SET
					`for_whome` = null
				WHERE
					`idvisitor_pass` = ' . $objDatabase->SqlVariable($objVisitorPass->IdvisitorPass) . ' AND
					`for_whome` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all VisitorPassesAsForWhome
		 * @return void
		*/
		public function UnassociateAllVisitorPassesAsForWhome() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVisitorPassAsForWhome on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`visitor_pass`
				SET
					`for_whome` = null
				WHERE
					`for_whome` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated VisitorPassAsForWhome
		 * @param VisitorPass $objVisitorPass
		 * @return void
		*/
		public function DeleteAssociatedVisitorPassAsForWhome(VisitorPass $objVisitorPass) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVisitorPassAsForWhome on this unsaved Login.');
			if ((is_null($objVisitorPass->IdvisitorPass)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVisitorPassAsForWhome on this Login with an unsaved VisitorPass.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`visitor_pass`
				WHERE
					`idvisitor_pass` = ' . $objDatabase->SqlVariable($objVisitorPass->IdvisitorPass) . ' AND
					`for_whome` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated VisitorPassesAsForWhome
		 * @return void
		*/
		public function DeleteAllVisitorPassesAsForWhome() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVisitorPassAsForWhome on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`visitor_pass`
				WHERE
					`for_whome` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for VoucherAsApprovedBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated VouchersAsApprovedBy as an array of Voucher objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Voucher[]
		*/
		public function GetVoucherAsApprovedByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Voucher::LoadArrayByApprovedBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated VouchersAsApprovedBy
		 * @return int
		*/
		public function CountVouchersAsApprovedBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Voucher::CountByApprovedBy($this->intIdlogin);
		}

		/**
		 * Associates a VoucherAsApprovedBy
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function AssociateVoucherAsApprovedBy(Voucher $objVoucher) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherAsApprovedBy on this unsaved Login.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherAsApprovedBy on this Login with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`approved_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . '
			');
		}

		/**
		 * Unassociates a VoucherAsApprovedBy
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function UnassociateVoucherAsApprovedBy(Voucher $objVoucher) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsApprovedBy on this unsaved Login.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsApprovedBy on this Login with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`approved_by` = null
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . ' AND
					`approved_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all VouchersAsApprovedBy
		 * @return void
		*/
		public function UnassociateAllVouchersAsApprovedBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsApprovedBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`approved_by` = null
				WHERE
					`approved_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated VoucherAsApprovedBy
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function DeleteAssociatedVoucherAsApprovedBy(Voucher $objVoucher) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsApprovedBy on this unsaved Login.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsApprovedBy on this Login with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher`
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . ' AND
					`approved_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated VouchersAsApprovedBy
		 * @return void
		*/
		public function DeleteAllVouchersAsApprovedBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsApprovedBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher`
				WHERE
					`approved_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		// Related Objects' Methods for VoucherAsCancelBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated VouchersAsCancelBy as an array of Voucher objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Voucher[]
		*/
		public function GetVoucherAsCancelByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdlogin)))
				return array();

			try {
				return Voucher::LoadArrayByCancelBy($this->intIdlogin, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated VouchersAsCancelBy
		 * @return int
		*/
		public function CountVouchersAsCancelBy() {
			if ((is_null($this->intIdlogin)))
				return 0;

			return Voucher::CountByCancelBy($this->intIdlogin);
		}

		/**
		 * Associates a VoucherAsCancelBy
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function AssociateVoucherAsCancelBy(Voucher $objVoucher) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherAsCancelBy on this unsaved Login.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherAsCancelBy on this Login with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`cancel_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . '
			');
		}

		/**
		 * Unassociates a VoucherAsCancelBy
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function UnassociateVoucherAsCancelBy(Voucher $objVoucher) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsCancelBy on this unsaved Login.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsCancelBy on this Login with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`cancel_by` = null
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . ' AND
					`cancel_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Unassociates all VouchersAsCancelBy
		 * @return void
		*/
		public function UnassociateAllVouchersAsCancelBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsCancelBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher`
				SET
					`cancel_by` = null
				WHERE
					`cancel_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes an associated VoucherAsCancelBy
		 * @param Voucher $objVoucher
		 * @return void
		*/
		public function DeleteAssociatedVoucherAsCancelBy(Voucher $objVoucher) {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsCancelBy on this unsaved Login.');
			if ((is_null($objVoucher->Idvoucher)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsCancelBy on this Login with an unsaved Voucher.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher`
				WHERE
					`idvoucher` = ' . $objDatabase->SqlVariable($objVoucher->Idvoucher) . ' AND
					`cancel_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}

		/**
		 * Deletes all associated VouchersAsCancelBy
		 * @return void
		*/
		public function DeleteAllVouchersAsCancelBy() {
			if ((is_null($this->intIdlogin)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherAsCancelBy on this unsaved Login.');

			// Get the Database Object for this Class
			$objDatabase = Login::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher`
				WHERE
					`cancel_by` = ' . $objDatabase->SqlVariable($this->intIdlogin) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "login";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Login::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Login"><sequence>';
			$strToReturn .= '<element name="IdloginObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="Username" type="xsd:string"/>';
			$strToReturn .= '<element name="Password" type="xsd:string"/>';
			$strToReturn .= '<element name="IsEnabled" type="xsd:boolean"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Login', $strComplexTypeArray)) {
				$strComplexTypeArray['Login'] = Login::GetSoapComplexTypeXml();
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Login::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Login();
			if ((property_exists($objSoapObject, 'IdloginObject')) &&
				($objSoapObject->IdloginObject))
				$objToReturn->IdloginObject = Ledger::GetObjectFromSoapObject($objSoapObject->IdloginObject);
			if (property_exists($objSoapObject, 'Username'))
				$objToReturn->strUsername = $objSoapObject->Username;
			if (property_exists($objSoapObject, 'Password'))
				$objToReturn->strPassword = $objSoapObject->Password;
			if (property_exists($objSoapObject, 'IsEnabled'))
				$objToReturn->blnIsEnabled = $objSoapObject->IsEnabled;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Login::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objIdloginObject)
				$objObject->objIdloginObject = Ledger::GetSoapObjectFromObject($objObject->objIdloginObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intIdlogin = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idlogin'] = $this->intIdlogin;
			$iArray['Username'] = $this->strUsername;
			$iArray['Password'] = $this->strPassword;
			$iArray['IsEnabled'] = $this->blnIsEnabled;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdlogin ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idlogin
     * @property-read QQNodeLedger $IdloginObject
     * @property-read QQNode $Username
     * @property-read QQNode $Password
     * @property-read QQNode $IsEnabled
     *
     *
     * @property-read QQReverseReferenceNodeAppApproval $AppApprovalAsDecisionBy
     * @property-read QQReverseReferenceNodeAppDocs $AppDocsAsMember
     * @property-read QQReverseReferenceNodeApplication $ApplicationAsDataEntryBy
     * @property-read QQReverseReferenceNodeApplication $ApplicationAsCertificateIssueBy
     * @property-read QQReverseReferenceNodeApplication $ApplicationAsSubstitute
     * @property-read QQReverseReferenceNodeAppliedExam $AppliedExamAsStudent
     * @property-read QQReverseReferenceNodeApplyGradeImproment $ApplyGradeImpromentAsStudent
     * @property-read QQReverseReferenceNodeApplyGradeImproment $ApplyGradeImpromentAsAppliedBy
     * @property-read QQReverseReferenceNodeAttendence $AttendenceAsStaff
     * @property-read QQReverseReferenceNodeCertificateDeposite $CertificateDepositeAsVerifyBy
     * @property-read QQReverseReferenceNodeCertificateDeposite $CertificateDepositeAsReturnBy
     * @property-read QQReverseReferenceNodeCirculation $CirculationAsDataBy
     * @property-read QQReverseReferenceNodeCirculation $CirculationAsStaffStud
     * @property-read QQReverseReferenceNodeCurrentStatus $CurrentStatusAsStudent
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEventsAsIntiator
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEventsAsOwner
     * @property-read QQReverseReferenceNodeDocInOut $DocInOutAsInwordBy
     * @property-read QQReverseReferenceNodeECourse $ECourseAsTeacher
     * @property-read QQReverseReferenceNodeEStudent $EStudentAsStudent
     * @property-read QQReverseReferenceNodeETicket $ETicketAsRaisedBy
     * @property-read QQReverseReferenceNodeEstablishment $Establishment
     * @property-read QQReverseReferenceNodeEventHasAttendent $EventHasAttendentAsAttendent
     * @property-read QQReverseReferenceNodeExampaper $ExampaperAsSetBy
     * @property-read QQReverseReferenceNodeForwardTo $ForwardToAsForWhome
     * @property-read QQReverseReferenceNodeForwardTo $ForwardToAsForwardedTo
     * @property-read QQReverseReferenceNodeGradeCard $GradeCardAsStudent
     * @property-read QQReverseReferenceNodeGradeCard $GradeCardAsChangeInEseBy
     * @property-read QQReverseReferenceNodeIssuedItems $IssuedItemsAsMember
     * @property-read QQReverseReferenceNodeIwow $IwowAsDataBy
     * @property-read QQReverseReferenceNodeIwow $IwowAsInspectedBy
     * @property-read QQReverseReferenceNodeLeaveBalance $LeaveBalanceAsMember
     * @property-read QQReverseReferenceNodeLog $LogAsDataBy
     * @property-read QQReverseReferenceNodeLoginHasRole $LoginHasRoleAsId
     * @property-read QQReverseReferenceNodeMarkTo $MarkToAsTo
     * @property-read QQReverseReferenceNodeMarkTo $MarkToAsFrom
     * @property-read QQReverseReferenceNodeMeetingAgendaPole $MeetingAgendaPoleAsAttendees
     * @property-read QQReverseReferenceNodeMeetingGroupHasMembers $MeetingGroupHasMembersAsMember
     * @property-read QQReverseReferenceNodeMeetingNotes $MeetingNotesAsReferedBy
     * @property-read QQReverseReferenceNodeMeetingNotes $MeetingNotesAsActionOn
     * @property-read QQReverseReferenceNodeNote $NoteAsDataby
     * @property-read QQReverseReferenceNodeReEvaluation $ReEvaluationAsStudent
     * @property-read QQReverseReferenceNodeSalarysheetApproval $SalarysheetApprovalAsApprovedBy
     * @property-read QQReverseReferenceNodeSignPatch $SignPatch
     * @property-read QQReverseReferenceNodeStudAttendence $StudAttendenceAsStudent
     * @property-read QQReverseReferenceNodeStudAttendence $StudAttendenceAsStaff
     * @property-read QQReverseReferenceNodeSubjectTought $SubjectTought
     * @property-read QQReverseReferenceNodeTimetable $TimetableAsAttendant
     * @property-read QQReverseReferenceNodeVisitorPass $VisitorPassAsForWhome
     * @property-read QQReverseReferenceNodeVoucher $VoucherAsApprovedBy
     * @property-read QQReverseReferenceNodeVoucher $VoucherAsCancelBy

     * @property-read QQNodeLedger $_PrimaryKeyNode
     **/
	class QQNodeLogin extends QQNode {
		protected $strTableName = 'login';
		protected $strPrimaryKey = 'idlogin';
		protected $strClassName = 'Login';
		public function __get($strName) {
			switch ($strName) {
				case 'Idlogin':
					return new QQNode('idlogin', 'Idlogin', 'Integer', $this);
				case 'IdloginObject':
					return new QQNodeLedger('idlogin', 'IdloginObject', 'Integer', $this);
				case 'Username':
					return new QQNode('username', 'Username', 'VarChar', $this);
				case 'Password':
					return new QQNode('password', 'Password', 'VarChar', $this);
				case 'IsEnabled':
					return new QQNode('is_enabled', 'IsEnabled', 'Bit', $this);
				case 'AppApprovalAsDecisionBy':
					return new QQReverseReferenceNodeAppApproval($this, 'appapprovalasdecisionby', 'reverse_reference', 'decision_by');
				case 'AppDocsAsMember':
					return new QQReverseReferenceNodeAppDocs($this, 'appdocsasmember', 'reverse_reference', 'member');
				case 'ApplicationAsDataEntryBy':
					return new QQReverseReferenceNodeApplication($this, 'applicationasdataentryby', 'reverse_reference', 'data_entry_by');
				case 'ApplicationAsCertificateIssueBy':
					return new QQReverseReferenceNodeApplication($this, 'applicationascertificateissueby', 'reverse_reference', 'certificate_issue_by');
				case 'ApplicationAsSubstitute':
					return new QQReverseReferenceNodeApplication($this, 'applicationassubstitute', 'reverse_reference', 'substitute');
				case 'AppliedExamAsStudent':
					return new QQReverseReferenceNodeAppliedExam($this, 'appliedexamasstudent', 'reverse_reference', 'student');
				case 'ApplyGradeImpromentAsStudent':
					return new QQReverseReferenceNodeApplyGradeImproment($this, 'applygradeimpromentasstudent', 'reverse_reference', 'student');
				case 'ApplyGradeImpromentAsAppliedBy':
					return new QQReverseReferenceNodeApplyGradeImproment($this, 'applygradeimpromentasappliedby', 'reverse_reference', 'applied_by');
				case 'AttendenceAsStaff':
					return new QQReverseReferenceNodeAttendence($this, 'attendenceasstaff', 'reverse_reference', 'staff');
				case 'CertificateDepositeAsVerifyBy':
					return new QQReverseReferenceNodeCertificateDeposite($this, 'certificatedepositeasverifyby', 'reverse_reference', 'verify_by');
				case 'CertificateDepositeAsReturnBy':
					return new QQReverseReferenceNodeCertificateDeposite($this, 'certificatedepositeasreturnby', 'reverse_reference', 'return_by');
				case 'CirculationAsDataBy':
					return new QQReverseReferenceNodeCirculation($this, 'circulationasdataby', 'reverse_reference', 'data_by');
				case 'CirculationAsStaffStud':
					return new QQReverseReferenceNodeCirculation($this, 'circulationasstaffstud', 'reverse_reference', 'staff_stud');
				case 'CurrentStatusAsStudent':
					return new QQReverseReferenceNodeCurrentStatus($this, 'currentstatusasstudent', 'reverse_reference', 'student');
				case 'DeptYearEventsAsIntiator':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyeareventsasintiator', 'reverse_reference', 'intiator');
				case 'DeptYearEventsAsOwner':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyeareventsasowner', 'reverse_reference', 'owner');
				case 'DocInOutAsInwordBy':
					return new QQReverseReferenceNodeDocInOut($this, 'docinoutasinwordby', 'reverse_reference', 'inword_by');
				case 'ECourseAsTeacher':
					return new QQReverseReferenceNodeECourse($this, 'ecourseasteacher', 'reverse_reference', 'teacher_id');
				case 'EStudentAsStudent':
					return new QQReverseReferenceNodeEStudent($this, 'estudentasstudent', 'reverse_reference', 'student');
				case 'ETicketAsRaisedBy':
					return new QQReverseReferenceNodeETicket($this, 'eticketasraisedby', 'reverse_reference', 'raised_by');
				case 'Establishment':
					return new QQReverseReferenceNodeEstablishment($this, 'establishment', 'reverse_reference', 'login');
				case 'EventHasAttendentAsAttendent':
					return new QQReverseReferenceNodeEventHasAttendent($this, 'eventhasattendentasattendent', 'reverse_reference', 'attendent');
				case 'ExampaperAsSetBy':
					return new QQReverseReferenceNodeExampaper($this, 'exampaperassetby', 'reverse_reference', 'set_by');
				case 'ForwardToAsForWhome':
					return new QQReverseReferenceNodeForwardTo($this, 'forwardtoasforwhome', 'reverse_reference', 'for_whome');
				case 'ForwardToAsForwardedTo':
					return new QQReverseReferenceNodeForwardTo($this, 'forwardtoasforwardedto', 'reverse_reference', 'forwarded_to');
				case 'GradeCardAsStudent':
					return new QQReverseReferenceNodeGradeCard($this, 'gradecardasstudent', 'reverse_reference', 'student');
				case 'GradeCardAsChangeInEseBy':
					return new QQReverseReferenceNodeGradeCard($this, 'gradecardaschangeineseby', 'reverse_reference', 'change_in_ese_by');
				case 'IssuedItemsAsMember':
					return new QQReverseReferenceNodeIssuedItems($this, 'issueditemsasmember', 'reverse_reference', 'member');
				case 'IwowAsDataBy':
					return new QQReverseReferenceNodeIwow($this, 'iwowasdataby', 'reverse_reference', 'data_by');
				case 'IwowAsInspectedBy':
					return new QQReverseReferenceNodeIwow($this, 'iwowasinspectedby', 'reverse_reference', 'inspected_by');
				case 'LeaveBalanceAsMember':
					return new QQReverseReferenceNodeLeaveBalance($this, 'leavebalanceasmember', 'reverse_reference', 'member');
				case 'LogAsDataBy':
					return new QQReverseReferenceNodeLog($this, 'logasdataby', 'reverse_reference', 'data_by');
				case 'LoginHasRoleAsId':
					return new QQReverseReferenceNodeLoginHasRole($this, 'loginhasroleasid', 'reverse_reference', 'login_idlogin');
				case 'MarkToAsTo':
					return new QQReverseReferenceNodeMarkTo($this, 'marktoasto', 'reverse_reference', 'to');
				case 'MarkToAsFrom':
					return new QQReverseReferenceNodeMarkTo($this, 'marktoasfrom', 'reverse_reference', 'from');
				case 'MeetingAgendaPoleAsAttendees':
					return new QQReverseReferenceNodeMeetingAgendaPole($this, 'meetingagendapoleasattendees', 'reverse_reference', 'attendees');
				case 'MeetingGroupHasMembersAsMember':
					return new QQReverseReferenceNodeMeetingGroupHasMembers($this, 'meetinggrouphasmembersasmember', 'reverse_reference', 'member');
				case 'MeetingNotesAsReferedBy':
					return new QQReverseReferenceNodeMeetingNotes($this, 'meetingnotesasreferedby', 'reverse_reference', 'refered_by');
				case 'MeetingNotesAsActionOn':
					return new QQReverseReferenceNodeMeetingNotes($this, 'meetingnotesasactionon', 'reverse_reference', 'action_on');
				case 'NoteAsDataby':
					return new QQReverseReferenceNodeNote($this, 'noteasdataby', 'reverse_reference', 'databy');
				case 'ReEvaluationAsStudent':
					return new QQReverseReferenceNodeReEvaluation($this, 'reevaluationasstudent', 'reverse_reference', 'student');
				case 'SalarysheetApprovalAsApprovedBy':
					return new QQReverseReferenceNodeSalarysheetApproval($this, 'salarysheetapprovalasapprovedby', 'reverse_reference', 'approved_by');
				case 'SignPatch':
					return new QQReverseReferenceNodeSignPatch($this, 'signpatch', 'reverse_reference', 'login');
				case 'StudAttendenceAsStudent':
					return new QQReverseReferenceNodeStudAttendence($this, 'studattendenceasstudent', 'reverse_reference', 'student');
				case 'StudAttendenceAsStaff':
					return new QQReverseReferenceNodeStudAttendence($this, 'studattendenceasstaff', 'reverse_reference', 'staff');
				case 'SubjectTought':
					return new QQReverseReferenceNodeSubjectTought($this, 'subjecttought', 'reverse_reference', 'login');
				case 'TimetableAsAttendant':
					return new QQReverseReferenceNodeTimetable($this, 'timetableasattendant', 'reverse_reference', 'attendant');
				case 'VisitorPassAsForWhome':
					return new QQReverseReferenceNodeVisitorPass($this, 'visitorpassasforwhome', 'reverse_reference', 'for_whome');
				case 'VoucherAsApprovedBy':
					return new QQReverseReferenceNodeVoucher($this, 'voucherasapprovedby', 'reverse_reference', 'approved_by');
				case 'VoucherAsCancelBy':
					return new QQReverseReferenceNodeVoucher($this, 'voucherascancelby', 'reverse_reference', 'cancel_by');

				case '_PrimaryKeyNode':
					return new QQNodeLedger('idlogin', 'Idlogin', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idlogin
     * @property-read QQNodeLedger $IdloginObject
     * @property-read QQNode $Username
     * @property-read QQNode $Password
     * @property-read QQNode $IsEnabled
     *
     *
     * @property-read QQReverseReferenceNodeAppApproval $AppApprovalAsDecisionBy
     * @property-read QQReverseReferenceNodeAppDocs $AppDocsAsMember
     * @property-read QQReverseReferenceNodeApplication $ApplicationAsDataEntryBy
     * @property-read QQReverseReferenceNodeApplication $ApplicationAsCertificateIssueBy
     * @property-read QQReverseReferenceNodeApplication $ApplicationAsSubstitute
     * @property-read QQReverseReferenceNodeAppliedExam $AppliedExamAsStudent
     * @property-read QQReverseReferenceNodeApplyGradeImproment $ApplyGradeImpromentAsStudent
     * @property-read QQReverseReferenceNodeApplyGradeImproment $ApplyGradeImpromentAsAppliedBy
     * @property-read QQReverseReferenceNodeAttendence $AttendenceAsStaff
     * @property-read QQReverseReferenceNodeCertificateDeposite $CertificateDepositeAsVerifyBy
     * @property-read QQReverseReferenceNodeCertificateDeposite $CertificateDepositeAsReturnBy
     * @property-read QQReverseReferenceNodeCirculation $CirculationAsDataBy
     * @property-read QQReverseReferenceNodeCirculation $CirculationAsStaffStud
     * @property-read QQReverseReferenceNodeCurrentStatus $CurrentStatusAsStudent
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEventsAsIntiator
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEventsAsOwner
     * @property-read QQReverseReferenceNodeDocInOut $DocInOutAsInwordBy
     * @property-read QQReverseReferenceNodeECourse $ECourseAsTeacher
     * @property-read QQReverseReferenceNodeEStudent $EStudentAsStudent
     * @property-read QQReverseReferenceNodeETicket $ETicketAsRaisedBy
     * @property-read QQReverseReferenceNodeEstablishment $Establishment
     * @property-read QQReverseReferenceNodeEventHasAttendent $EventHasAttendentAsAttendent
     * @property-read QQReverseReferenceNodeExampaper $ExampaperAsSetBy
     * @property-read QQReverseReferenceNodeForwardTo $ForwardToAsForWhome
     * @property-read QQReverseReferenceNodeForwardTo $ForwardToAsForwardedTo
     * @property-read QQReverseReferenceNodeGradeCard $GradeCardAsStudent
     * @property-read QQReverseReferenceNodeGradeCard $GradeCardAsChangeInEseBy
     * @property-read QQReverseReferenceNodeIssuedItems $IssuedItemsAsMember
     * @property-read QQReverseReferenceNodeIwow $IwowAsDataBy
     * @property-read QQReverseReferenceNodeIwow $IwowAsInspectedBy
     * @property-read QQReverseReferenceNodeLeaveBalance $LeaveBalanceAsMember
     * @property-read QQReverseReferenceNodeLog $LogAsDataBy
     * @property-read QQReverseReferenceNodeLoginHasRole $LoginHasRoleAsId
     * @property-read QQReverseReferenceNodeMarkTo $MarkToAsTo
     * @property-read QQReverseReferenceNodeMarkTo $MarkToAsFrom
     * @property-read QQReverseReferenceNodeMeetingAgendaPole $MeetingAgendaPoleAsAttendees
     * @property-read QQReverseReferenceNodeMeetingGroupHasMembers $MeetingGroupHasMembersAsMember
     * @property-read QQReverseReferenceNodeMeetingNotes $MeetingNotesAsReferedBy
     * @property-read QQReverseReferenceNodeMeetingNotes $MeetingNotesAsActionOn
     * @property-read QQReverseReferenceNodeNote $NoteAsDataby
     * @property-read QQReverseReferenceNodeReEvaluation $ReEvaluationAsStudent
     * @property-read QQReverseReferenceNodeSalarysheetApproval $SalarysheetApprovalAsApprovedBy
     * @property-read QQReverseReferenceNodeSignPatch $SignPatch
     * @property-read QQReverseReferenceNodeStudAttendence $StudAttendenceAsStudent
     * @property-read QQReverseReferenceNodeStudAttendence $StudAttendenceAsStaff
     * @property-read QQReverseReferenceNodeSubjectTought $SubjectTought
     * @property-read QQReverseReferenceNodeTimetable $TimetableAsAttendant
     * @property-read QQReverseReferenceNodeVisitorPass $VisitorPassAsForWhome
     * @property-read QQReverseReferenceNodeVoucher $VoucherAsApprovedBy
     * @property-read QQReverseReferenceNodeVoucher $VoucherAsCancelBy

     * @property-read QQNodeLedger $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeLogin extends QQReverseReferenceNode {
		protected $strTableName = 'login';
		protected $strPrimaryKey = 'idlogin';
		protected $strClassName = 'Login';
		public function __get($strName) {
			switch ($strName) {
				case 'Idlogin':
					return new QQNode('idlogin', 'Idlogin', 'integer', $this);
				case 'IdloginObject':
					return new QQNodeLedger('idlogin', 'IdloginObject', 'integer', $this);
				case 'Username':
					return new QQNode('username', 'Username', 'string', $this);
				case 'Password':
					return new QQNode('password', 'Password', 'string', $this);
				case 'IsEnabled':
					return new QQNode('is_enabled', 'IsEnabled', 'boolean', $this);
				case 'AppApprovalAsDecisionBy':
					return new QQReverseReferenceNodeAppApproval($this, 'appapprovalasdecisionby', 'reverse_reference', 'decision_by');
				case 'AppDocsAsMember':
					return new QQReverseReferenceNodeAppDocs($this, 'appdocsasmember', 'reverse_reference', 'member');
				case 'ApplicationAsDataEntryBy':
					return new QQReverseReferenceNodeApplication($this, 'applicationasdataentryby', 'reverse_reference', 'data_entry_by');
				case 'ApplicationAsCertificateIssueBy':
					return new QQReverseReferenceNodeApplication($this, 'applicationascertificateissueby', 'reverse_reference', 'certificate_issue_by');
				case 'ApplicationAsSubstitute':
					return new QQReverseReferenceNodeApplication($this, 'applicationassubstitute', 'reverse_reference', 'substitute');
				case 'AppliedExamAsStudent':
					return new QQReverseReferenceNodeAppliedExam($this, 'appliedexamasstudent', 'reverse_reference', 'student');
				case 'ApplyGradeImpromentAsStudent':
					return new QQReverseReferenceNodeApplyGradeImproment($this, 'applygradeimpromentasstudent', 'reverse_reference', 'student');
				case 'ApplyGradeImpromentAsAppliedBy':
					return new QQReverseReferenceNodeApplyGradeImproment($this, 'applygradeimpromentasappliedby', 'reverse_reference', 'applied_by');
				case 'AttendenceAsStaff':
					return new QQReverseReferenceNodeAttendence($this, 'attendenceasstaff', 'reverse_reference', 'staff');
				case 'CertificateDepositeAsVerifyBy':
					return new QQReverseReferenceNodeCertificateDeposite($this, 'certificatedepositeasverifyby', 'reverse_reference', 'verify_by');
				case 'CertificateDepositeAsReturnBy':
					return new QQReverseReferenceNodeCertificateDeposite($this, 'certificatedepositeasreturnby', 'reverse_reference', 'return_by');
				case 'CirculationAsDataBy':
					return new QQReverseReferenceNodeCirculation($this, 'circulationasdataby', 'reverse_reference', 'data_by');
				case 'CirculationAsStaffStud':
					return new QQReverseReferenceNodeCirculation($this, 'circulationasstaffstud', 'reverse_reference', 'staff_stud');
				case 'CurrentStatusAsStudent':
					return new QQReverseReferenceNodeCurrentStatus($this, 'currentstatusasstudent', 'reverse_reference', 'student');
				case 'DeptYearEventsAsIntiator':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyeareventsasintiator', 'reverse_reference', 'intiator');
				case 'DeptYearEventsAsOwner':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyeareventsasowner', 'reverse_reference', 'owner');
				case 'DocInOutAsInwordBy':
					return new QQReverseReferenceNodeDocInOut($this, 'docinoutasinwordby', 'reverse_reference', 'inword_by');
				case 'ECourseAsTeacher':
					return new QQReverseReferenceNodeECourse($this, 'ecourseasteacher', 'reverse_reference', 'teacher_id');
				case 'EStudentAsStudent':
					return new QQReverseReferenceNodeEStudent($this, 'estudentasstudent', 'reverse_reference', 'student');
				case 'ETicketAsRaisedBy':
					return new QQReverseReferenceNodeETicket($this, 'eticketasraisedby', 'reverse_reference', 'raised_by');
				case 'Establishment':
					return new QQReverseReferenceNodeEstablishment($this, 'establishment', 'reverse_reference', 'login');
				case 'EventHasAttendentAsAttendent':
					return new QQReverseReferenceNodeEventHasAttendent($this, 'eventhasattendentasattendent', 'reverse_reference', 'attendent');
				case 'ExampaperAsSetBy':
					return new QQReverseReferenceNodeExampaper($this, 'exampaperassetby', 'reverse_reference', 'set_by');
				case 'ForwardToAsForWhome':
					return new QQReverseReferenceNodeForwardTo($this, 'forwardtoasforwhome', 'reverse_reference', 'for_whome');
				case 'ForwardToAsForwardedTo':
					return new QQReverseReferenceNodeForwardTo($this, 'forwardtoasforwardedto', 'reverse_reference', 'forwarded_to');
				case 'GradeCardAsStudent':
					return new QQReverseReferenceNodeGradeCard($this, 'gradecardasstudent', 'reverse_reference', 'student');
				case 'GradeCardAsChangeInEseBy':
					return new QQReverseReferenceNodeGradeCard($this, 'gradecardaschangeineseby', 'reverse_reference', 'change_in_ese_by');
				case 'IssuedItemsAsMember':
					return new QQReverseReferenceNodeIssuedItems($this, 'issueditemsasmember', 'reverse_reference', 'member');
				case 'IwowAsDataBy':
					return new QQReverseReferenceNodeIwow($this, 'iwowasdataby', 'reverse_reference', 'data_by');
				case 'IwowAsInspectedBy':
					return new QQReverseReferenceNodeIwow($this, 'iwowasinspectedby', 'reverse_reference', 'inspected_by');
				case 'LeaveBalanceAsMember':
					return new QQReverseReferenceNodeLeaveBalance($this, 'leavebalanceasmember', 'reverse_reference', 'member');
				case 'LogAsDataBy':
					return new QQReverseReferenceNodeLog($this, 'logasdataby', 'reverse_reference', 'data_by');
				case 'LoginHasRoleAsId':
					return new QQReverseReferenceNodeLoginHasRole($this, 'loginhasroleasid', 'reverse_reference', 'login_idlogin');
				case 'MarkToAsTo':
					return new QQReverseReferenceNodeMarkTo($this, 'marktoasto', 'reverse_reference', 'to');
				case 'MarkToAsFrom':
					return new QQReverseReferenceNodeMarkTo($this, 'marktoasfrom', 'reverse_reference', 'from');
				case 'MeetingAgendaPoleAsAttendees':
					return new QQReverseReferenceNodeMeetingAgendaPole($this, 'meetingagendapoleasattendees', 'reverse_reference', 'attendees');
				case 'MeetingGroupHasMembersAsMember':
					return new QQReverseReferenceNodeMeetingGroupHasMembers($this, 'meetinggrouphasmembersasmember', 'reverse_reference', 'member');
				case 'MeetingNotesAsReferedBy':
					return new QQReverseReferenceNodeMeetingNotes($this, 'meetingnotesasreferedby', 'reverse_reference', 'refered_by');
				case 'MeetingNotesAsActionOn':
					return new QQReverseReferenceNodeMeetingNotes($this, 'meetingnotesasactionon', 'reverse_reference', 'action_on');
				case 'NoteAsDataby':
					return new QQReverseReferenceNodeNote($this, 'noteasdataby', 'reverse_reference', 'databy');
				case 'ReEvaluationAsStudent':
					return new QQReverseReferenceNodeReEvaluation($this, 'reevaluationasstudent', 'reverse_reference', 'student');
				case 'SalarysheetApprovalAsApprovedBy':
					return new QQReverseReferenceNodeSalarysheetApproval($this, 'salarysheetapprovalasapprovedby', 'reverse_reference', 'approved_by');
				case 'SignPatch':
					return new QQReverseReferenceNodeSignPatch($this, 'signpatch', 'reverse_reference', 'login');
				case 'StudAttendenceAsStudent':
					return new QQReverseReferenceNodeStudAttendence($this, 'studattendenceasstudent', 'reverse_reference', 'student');
				case 'StudAttendenceAsStaff':
					return new QQReverseReferenceNodeStudAttendence($this, 'studattendenceasstaff', 'reverse_reference', 'staff');
				case 'SubjectTought':
					return new QQReverseReferenceNodeSubjectTought($this, 'subjecttought', 'reverse_reference', 'login');
				case 'TimetableAsAttendant':
					return new QQReverseReferenceNodeTimetable($this, 'timetableasattendant', 'reverse_reference', 'attendant');
				case 'VisitorPassAsForWhome':
					return new QQReverseReferenceNodeVisitorPass($this, 'visitorpassasforwhome', 'reverse_reference', 'for_whome');
				case 'VoucherAsApprovedBy':
					return new QQReverseReferenceNodeVoucher($this, 'voucherasapprovedby', 'reverse_reference', 'approved_by');
				case 'VoucherAsCancelBy':
					return new QQReverseReferenceNodeVoucher($this, 'voucherascancelby', 'reverse_reference', 'cancel_by');

				case '_PrimaryKeyNode':
					return new QQNodeLedger('idlogin', 'Idlogin', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
