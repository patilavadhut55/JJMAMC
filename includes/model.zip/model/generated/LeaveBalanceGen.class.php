<?php
	/**
	 * The abstract LeaveBalanceGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the LeaveBalance subclass which
	 * extends this LeaveBalanceGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the LeaveBalance class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdleaveBalance the value for intIdleaveBalance (Read-Only PK)
	 * @property integer $Member the value for intMember (Not Null)
	 * @property integer $LeaveCat the value for intLeaveCat (Not Null)
	 * @property string $LeaveBalance the value for strLeaveBalance 
	 * @property string $OpeningBalance the value for strOpeningBalance 
	 * @property string $Closing the value for strClosing 
	 * @property QDateTime $GenerateDate the value for dttGenerateDate 
	 * @property integer $LeaveGeneratePeriod the value for intLeaveGeneratePeriod 
	 * @property integer $CalendarYear the value for intCalendarYear 
	 * @property Login $MemberObject the value for the Login object referenced by intMember (Not Null)
	 * @property LeaveCat $LeaveCatObject the value for the LeaveCat object referenced by intLeaveCat (Not Null)
	 * @property LeaveGeneratePeriod $LeaveGeneratePeriodObject the value for the LeaveGeneratePeriod object referenced by intLeaveGeneratePeriod 
	 * @property CalenderYear $CalendarYearObject the value for the CalenderYear object referenced by intCalendarYear 
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class LeaveBalanceGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column leave_balance.idleave_balance
		 * @var integer intIdleaveBalance
		 */
		protected $intIdleaveBalance;
		const IdleaveBalanceDefault = null;


		/**
		 * Protected member variable that maps to the database column leave_balance.member
		 * @var integer intMember
		 */
		protected $intMember;
		const MemberDefault = null;


		/**
		 * Protected member variable that maps to the database column leave_balance.leave_cat
		 * @var integer intLeaveCat
		 */
		protected $intLeaveCat;
		const LeaveCatDefault = null;


		/**
		 * Protected member variable that maps to the database column leave_balance.leave_balance
		 * @var string strLeaveBalance
		 */
		protected $strLeaveBalance;
		const LeaveBalanceMaxLength = 45;
		const LeaveBalanceDefault = null;


		/**
		 * Protected member variable that maps to the database column leave_balance.opening_balance
		 * @var string strOpeningBalance
		 */
		protected $strOpeningBalance;
		const OpeningBalanceMaxLength = 45;
		const OpeningBalanceDefault = null;


		/**
		 * Protected member variable that maps to the database column leave_balance.closing
		 * @var string strClosing
		 */
		protected $strClosing;
		const ClosingMaxLength = 45;
		const ClosingDefault = null;


		/**
		 * Protected member variable that maps to the database column leave_balance.generate_date
		 * @var QDateTime dttGenerateDate
		 */
		protected $dttGenerateDate;
		const GenerateDateDefault = null;


		/**
		 * Protected member variable that maps to the database column leave_balance.leave_generate_period
		 * @var integer intLeaveGeneratePeriod
		 */
		protected $intLeaveGeneratePeriod;
		const LeaveGeneratePeriodDefault = null;


		/**
		 * Protected member variable that maps to the database column leave_balance.calendar_year
		 * @var integer intCalendarYear
		 */
		protected $intCalendarYear;
		const CalendarYearDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column leave_balance.member.
		 *
		 * NOTE: Always use the MemberObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objMemberObject
		 */
		protected $objMemberObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column leave_balance.leave_cat.
		 *
		 * NOTE: Always use the LeaveCatObject property getter to correctly retrieve this LeaveCat object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var LeaveCat objLeaveCatObject
		 */
		protected $objLeaveCatObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column leave_balance.leave_generate_period.
		 *
		 * NOTE: Always use the LeaveGeneratePeriodObject property getter to correctly retrieve this LeaveGeneratePeriod object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var LeaveGeneratePeriod objLeaveGeneratePeriodObject
		 */
		protected $objLeaveGeneratePeriodObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column leave_balance.calendar_year.
		 *
		 * NOTE: Always use the CalendarYearObject property getter to correctly retrieve this CalenderYear object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var CalenderYear objCalendarYearObject
		 */
		protected $objCalendarYearObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdleaveBalance = LeaveBalance::IdleaveBalanceDefault;
			$this->intMember = LeaveBalance::MemberDefault;
			$this->intLeaveCat = LeaveBalance::LeaveCatDefault;
			$this->strLeaveBalance = LeaveBalance::LeaveBalanceDefault;
			$this->strOpeningBalance = LeaveBalance::OpeningBalanceDefault;
			$this->strClosing = LeaveBalance::ClosingDefault;
			$this->dttGenerateDate = (LeaveBalance::GenerateDateDefault === null)?null:new QDateTime(LeaveBalance::GenerateDateDefault);
			$this->intLeaveGeneratePeriod = LeaveBalance::LeaveGeneratePeriodDefault;
			$this->intCalendarYear = LeaveBalance::CalendarYearDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a LeaveBalance from PK Info
		 * @param integer $intIdleaveBalance
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveBalance
		 */
		public static function Load($intIdleaveBalance, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'LeaveBalance', $intIdleaveBalance);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = LeaveBalance::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::LeaveBalance()->IdleaveBalance, $intIdleaveBalance)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all LeaveBalances
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveBalance[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call LeaveBalance::QueryArray to perform the LoadAll query
			try {
				return LeaveBalance::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all LeaveBalances
		 * @return int
		 */
		public static function CountAll() {
			// Call LeaveBalance::QueryCount to perform the CountAll query
			return LeaveBalance::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = LeaveBalance::GetDatabase();

			// Create/Build out the QueryBuilder object with LeaveBalance-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'leave_balance');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				LeaveBalance::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('leave_balance');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single LeaveBalance object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return LeaveBalance the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = LeaveBalance::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new LeaveBalance object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = LeaveBalance::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return LeaveBalance::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of LeaveBalance objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return LeaveBalance[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = LeaveBalance::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return LeaveBalance::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = LeaveBalance::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of LeaveBalance objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = LeaveBalance::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = LeaveBalance::GetDatabase();

			$strQuery = LeaveBalance::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/leavebalance', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = LeaveBalance::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this LeaveBalance
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'leave_balance';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idleave_balance', $strAliasPrefix . 'idleave_balance');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idleave_balance', $strAliasPrefix . 'idleave_balance');
			    $objBuilder->AddSelectItem($strTableName, 'member', $strAliasPrefix . 'member');
			    $objBuilder->AddSelectItem($strTableName, 'leave_cat', $strAliasPrefix . 'leave_cat');
			    $objBuilder->AddSelectItem($strTableName, 'leave_balance', $strAliasPrefix . 'leave_balance');
			    $objBuilder->AddSelectItem($strTableName, 'opening_balance', $strAliasPrefix . 'opening_balance');
			    $objBuilder->AddSelectItem($strTableName, 'closing', $strAliasPrefix . 'closing');
			    $objBuilder->AddSelectItem($strTableName, 'generate_date', $strAliasPrefix . 'generate_date');
			    $objBuilder->AddSelectItem($strTableName, 'leave_generate_period', $strAliasPrefix . 'leave_generate_period');
			    $objBuilder->AddSelectItem($strTableName, 'calendar_year', $strAliasPrefix . 'calendar_year');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a LeaveBalance from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this LeaveBalance::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return LeaveBalance
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the LeaveBalance object
			$objToReturn = new LeaveBalance();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idleave_balance';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdleaveBalance = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'member';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMember = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'leave_cat';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intLeaveCat = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'leave_balance';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strLeaveBalance = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'opening_balance';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strOpeningBalance = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'closing';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strClosing = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'generate_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttGenerateDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'leave_generate_period';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intLeaveGeneratePeriod = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'calendar_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCalendarYear = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdleaveBalance != $objPreviousItem->IdleaveBalance) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'leave_balance__';

			// Check for MemberObject Early Binding
			$strAlias = $strAliasPrefix . 'member__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objMemberObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'member__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for LeaveCatObject Early Binding
			$strAlias = $strAliasPrefix . 'leave_cat__idleave_cat';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objLeaveCatObject = LeaveCat::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leave_cat__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for LeaveGeneratePeriodObject Early Binding
			$strAlias = $strAliasPrefix . 'leave_generate_period__idleave_generate_period';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objLeaveGeneratePeriodObject = LeaveGeneratePeriod::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leave_generate_period__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CalendarYearObject Early Binding
			$strAlias = $strAliasPrefix . 'calendar_year__idcalender_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCalendarYearObject = CalenderYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calendar_year__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of LeaveBalances from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return LeaveBalance[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = LeaveBalance::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = LeaveBalance::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single LeaveBalance object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return LeaveBalance next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return LeaveBalance::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single LeaveBalance object,
		 * by IdleaveBalance Index(es)
		 * @param integer $intIdleaveBalance
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveBalance
		*/
		public static function LoadByIdleaveBalance($intIdleaveBalance, $objOptionalClauses = null) {
			return LeaveBalance::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::LeaveBalance()->IdleaveBalance, $intIdleaveBalance)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of LeaveBalance objects,
		 * by Member Index(es)
		 * @param integer $intMember
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveBalance[]
		*/
		public static function LoadArrayByMember($intMember, $objOptionalClauses = null) {
			// Call LeaveBalance::QueryArray to perform the LoadArrayByMember query
			try {
				return LeaveBalance::QueryArray(
					QQ::Equal(QQN::LeaveBalance()->Member, $intMember),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count LeaveBalances
		 * by Member Index(es)
		 * @param integer $intMember
		 * @return int
		*/
		public static function CountByMember($intMember) {
			// Call LeaveBalance::QueryCount to perform the CountByMember query
			return LeaveBalance::QueryCount(
				QQ::Equal(QQN::LeaveBalance()->Member, $intMember)
			);
		}

		/**
		 * Load an array of LeaveBalance objects,
		 * by LeaveCat Index(es)
		 * @param integer $intLeaveCat
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveBalance[]
		*/
		public static function LoadArrayByLeaveCat($intLeaveCat, $objOptionalClauses = null) {
			// Call LeaveBalance::QueryArray to perform the LoadArrayByLeaveCat query
			try {
				return LeaveBalance::QueryArray(
					QQ::Equal(QQN::LeaveBalance()->LeaveCat, $intLeaveCat),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count LeaveBalances
		 * by LeaveCat Index(es)
		 * @param integer $intLeaveCat
		 * @return int
		*/
		public static function CountByLeaveCat($intLeaveCat) {
			// Call LeaveBalance::QueryCount to perform the CountByLeaveCat query
			return LeaveBalance::QueryCount(
				QQ::Equal(QQN::LeaveBalance()->LeaveCat, $intLeaveCat)
			);
		}

		/**
		 * Load an array of LeaveBalance objects,
		 * by LeaveGeneratePeriod Index(es)
		 * @param integer $intLeaveGeneratePeriod
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveBalance[]
		*/
		public static function LoadArrayByLeaveGeneratePeriod($intLeaveGeneratePeriod, $objOptionalClauses = null) {
			// Call LeaveBalance::QueryArray to perform the LoadArrayByLeaveGeneratePeriod query
			try {
				return LeaveBalance::QueryArray(
					QQ::Equal(QQN::LeaveBalance()->LeaveGeneratePeriod, $intLeaveGeneratePeriod),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count LeaveBalances
		 * by LeaveGeneratePeriod Index(es)
		 * @param integer $intLeaveGeneratePeriod
		 * @return int
		*/
		public static function CountByLeaveGeneratePeriod($intLeaveGeneratePeriod) {
			// Call LeaveBalance::QueryCount to perform the CountByLeaveGeneratePeriod query
			return LeaveBalance::QueryCount(
				QQ::Equal(QQN::LeaveBalance()->LeaveGeneratePeriod, $intLeaveGeneratePeriod)
			);
		}

		/**
		 * Load an array of LeaveBalance objects,
		 * by CalendarYear Index(es)
		 * @param integer $intCalendarYear
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveBalance[]
		*/
		public static function LoadArrayByCalendarYear($intCalendarYear, $objOptionalClauses = null) {
			// Call LeaveBalance::QueryArray to perform the LoadArrayByCalendarYear query
			try {
				return LeaveBalance::QueryArray(
					QQ::Equal(QQN::LeaveBalance()->CalendarYear, $intCalendarYear),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count LeaveBalances
		 * by CalendarYear Index(es)
		 * @param integer $intCalendarYear
		 * @return int
		*/
		public static function CountByCalendarYear($intCalendarYear) {
			// Call LeaveBalance::QueryCount to perform the CountByCalendarYear query
			return LeaveBalance::QueryCount(
				QQ::Equal(QQN::LeaveBalance()->CalendarYear, $intCalendarYear)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this LeaveBalance
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = LeaveBalance::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `leave_balance` (
							`member`,
							`leave_cat`,
							`leave_balance`,
							`opening_balance`,
							`closing`,
							`generate_date`,
							`leave_generate_period`,
							`calendar_year`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intMember) . ',
							' . $objDatabase->SqlVariable($this->intLeaveCat) . ',
							' . $objDatabase->SqlVariable($this->strLeaveBalance) . ',
							' . $objDatabase->SqlVariable($this->strOpeningBalance) . ',
							' . $objDatabase->SqlVariable($this->strClosing) . ',
							' . $objDatabase->SqlVariable($this->dttGenerateDate) . ',
							' . $objDatabase->SqlVariable($this->intLeaveGeneratePeriod) . ',
							' . $objDatabase->SqlVariable($this->intCalendarYear) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdleaveBalance = $objDatabase->InsertId('leave_balance', 'idleave_balance');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`leave_balance`
						SET
							`member` = ' . $objDatabase->SqlVariable($this->intMember) . ',
							`leave_cat` = ' . $objDatabase->SqlVariable($this->intLeaveCat) . ',
							`leave_balance` = ' . $objDatabase->SqlVariable($this->strLeaveBalance) . ',
							`opening_balance` = ' . $objDatabase->SqlVariable($this->strOpeningBalance) . ',
							`closing` = ' . $objDatabase->SqlVariable($this->strClosing) . ',
							`generate_date` = ' . $objDatabase->SqlVariable($this->dttGenerateDate) . ',
							`leave_generate_period` = ' . $objDatabase->SqlVariable($this->intLeaveGeneratePeriod) . ',
							`calendar_year` = ' . $objDatabase->SqlVariable($this->intCalendarYear) . '
						WHERE
							`idleave_balance` = ' . $objDatabase->SqlVariable($this->intIdleaveBalance) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this LeaveBalance
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdleaveBalance)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this LeaveBalance with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = LeaveBalance::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leave_balance`
				WHERE
					`idleave_balance` = ' . $objDatabase->SqlVariable($this->intIdleaveBalance) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this LeaveBalance ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'LeaveBalance', $this->intIdleaveBalance);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all LeaveBalances
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = LeaveBalance::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leave_balance`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate leave_balance table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = LeaveBalance::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `leave_balance`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this LeaveBalance from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved LeaveBalance object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = LeaveBalance::Load($this->intIdleaveBalance);

			// Update $this's local variables to match
			$this->Member = $objReloaded->Member;
			$this->LeaveCat = $objReloaded->LeaveCat;
			$this->strLeaveBalance = $objReloaded->strLeaveBalance;
			$this->strOpeningBalance = $objReloaded->strOpeningBalance;
			$this->strClosing = $objReloaded->strClosing;
			$this->dttGenerateDate = $objReloaded->dttGenerateDate;
			$this->LeaveGeneratePeriod = $objReloaded->LeaveGeneratePeriod;
			$this->CalendarYear = $objReloaded->CalendarYear;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdleaveBalance':
					/**
					 * Gets the value for intIdleaveBalance (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdleaveBalance;

				case 'Member':
					/**
					 * Gets the value for intMember (Not Null)
					 * @return integer
					 */
					return $this->intMember;

				case 'LeaveCat':
					/**
					 * Gets the value for intLeaveCat (Not Null)
					 * @return integer
					 */
					return $this->intLeaveCat;

				case 'LeaveBalance':
					/**
					 * Gets the value for strLeaveBalance 
					 * @return string
					 */
					return $this->strLeaveBalance;

				case 'OpeningBalance':
					/**
					 * Gets the value for strOpeningBalance 
					 * @return string
					 */
					return $this->strOpeningBalance;

				case 'Closing':
					/**
					 * Gets the value for strClosing 
					 * @return string
					 */
					return $this->strClosing;

				case 'GenerateDate':
					/**
					 * Gets the value for dttGenerateDate 
					 * @return QDateTime
					 */
					return $this->dttGenerateDate;

				case 'LeaveGeneratePeriod':
					/**
					 * Gets the value for intLeaveGeneratePeriod 
					 * @return integer
					 */
					return $this->intLeaveGeneratePeriod;

				case 'CalendarYear':
					/**
					 * Gets the value for intCalendarYear 
					 * @return integer
					 */
					return $this->intCalendarYear;


				///////////////////
				// Member Objects
				///////////////////
				case 'MemberObject':
					/**
					 * Gets the value for the Login object referenced by intMember (Not Null)
					 * @return Login
					 */
					try {
						if ((!$this->objMemberObject) && (!is_null($this->intMember)))
							$this->objMemberObject = Login::Load($this->intMember);
						return $this->objMemberObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeaveCatObject':
					/**
					 * Gets the value for the LeaveCat object referenced by intLeaveCat (Not Null)
					 * @return LeaveCat
					 */
					try {
						if ((!$this->objLeaveCatObject) && (!is_null($this->intLeaveCat)))
							$this->objLeaveCatObject = LeaveCat::Load($this->intLeaveCat);
						return $this->objLeaveCatObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeaveGeneratePeriodObject':
					/**
					 * Gets the value for the LeaveGeneratePeriod object referenced by intLeaveGeneratePeriod 
					 * @return LeaveGeneratePeriod
					 */
					try {
						if ((!$this->objLeaveGeneratePeriodObject) && (!is_null($this->intLeaveGeneratePeriod)))
							$this->objLeaveGeneratePeriodObject = LeaveGeneratePeriod::Load($this->intLeaveGeneratePeriod);
						return $this->objLeaveGeneratePeriodObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CalendarYearObject':
					/**
					 * Gets the value for the CalenderYear object referenced by intCalendarYear 
					 * @return CalenderYear
					 */
					try {
						if ((!$this->objCalendarYearObject) && (!is_null($this->intCalendarYear)))
							$this->objCalendarYearObject = CalenderYear::Load($this->intCalendarYear);
						return $this->objCalendarYearObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Member':
					/**
					 * Sets the value for intMember (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objMemberObject = null;
						return ($this->intMember = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeaveCat':
					/**
					 * Sets the value for intLeaveCat (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objLeaveCatObject = null;
						return ($this->intLeaveCat = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeaveBalance':
					/**
					 * Sets the value for strLeaveBalance 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strLeaveBalance = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'OpeningBalance':
					/**
					 * Sets the value for strOpeningBalance 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strOpeningBalance = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Closing':
					/**
					 * Sets the value for strClosing 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strClosing = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GenerateDate':
					/**
					 * Sets the value for dttGenerateDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttGenerateDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeaveGeneratePeriod':
					/**
					 * Sets the value for intLeaveGeneratePeriod 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objLeaveGeneratePeriodObject = null;
						return ($this->intLeaveGeneratePeriod = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CalendarYear':
					/**
					 * Sets the value for intCalendarYear 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCalendarYearObject = null;
						return ($this->intCalendarYear = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'MemberObject':
					/**
					 * Sets the value for the Login object referenced by intMember (Not Null)
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intMember = null;
						$this->objMemberObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved MemberObject for this LeaveBalance');

						// Update Local Member Variables
						$this->objMemberObject = $mixValue;
						$this->intMember = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'LeaveCatObject':
					/**
					 * Sets the value for the LeaveCat object referenced by intLeaveCat (Not Null)
					 * @param LeaveCat $mixValue
					 * @return LeaveCat
					 */
					if (is_null($mixValue)) {
						$this->intLeaveCat = null;
						$this->objLeaveCatObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a LeaveCat object
						try {
							$mixValue = QType::Cast($mixValue, 'LeaveCat');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED LeaveCat object
						if (is_null($mixValue->IdleaveCat))
							throw new QCallerException('Unable to set an unsaved LeaveCatObject for this LeaveBalance');

						// Update Local Member Variables
						$this->objLeaveCatObject = $mixValue;
						$this->intLeaveCat = $mixValue->IdleaveCat;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'LeaveGeneratePeriodObject':
					/**
					 * Sets the value for the LeaveGeneratePeriod object referenced by intLeaveGeneratePeriod 
					 * @param LeaveGeneratePeriod $mixValue
					 * @return LeaveGeneratePeriod
					 */
					if (is_null($mixValue)) {
						$this->intLeaveGeneratePeriod = null;
						$this->objLeaveGeneratePeriodObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a LeaveGeneratePeriod object
						try {
							$mixValue = QType::Cast($mixValue, 'LeaveGeneratePeriod');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED LeaveGeneratePeriod object
						if (is_null($mixValue->IdleaveGeneratePeriod))
							throw new QCallerException('Unable to set an unsaved LeaveGeneratePeriodObject for this LeaveBalance');

						// Update Local Member Variables
						$this->objLeaveGeneratePeriodObject = $mixValue;
						$this->intLeaveGeneratePeriod = $mixValue->IdleaveGeneratePeriod;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CalendarYearObject':
					/**
					 * Sets the value for the CalenderYear object referenced by intCalendarYear 
					 * @param CalenderYear $mixValue
					 * @return CalenderYear
					 */
					if (is_null($mixValue)) {
						$this->intCalendarYear = null;
						$this->objCalendarYearObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a CalenderYear object
						try {
							$mixValue = QType::Cast($mixValue, 'CalenderYear');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED CalenderYear object
						if (is_null($mixValue->IdcalenderYear))
							throw new QCallerException('Unable to set an unsaved CalendarYearObject for this LeaveBalance');

						// Update Local Member Variables
						$this->objCalendarYearObject = $mixValue;
						$this->intCalendarYear = $mixValue->IdcalenderYear;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "leave_balance";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[LeaveBalance::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="LeaveBalance"><sequence>';
			$strToReturn .= '<element name="IdleaveBalance" type="xsd:int"/>';
			$strToReturn .= '<element name="MemberObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="LeaveCatObject" type="xsd1:LeaveCat"/>';
			$strToReturn .= '<element name="LeaveBalance" type="xsd:string"/>';
			$strToReturn .= '<element name="OpeningBalance" type="xsd:string"/>';
			$strToReturn .= '<element name="Closing" type="xsd:string"/>';
			$strToReturn .= '<element name="GenerateDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="LeaveGeneratePeriodObject" type="xsd1:LeaveGeneratePeriod"/>';
			$strToReturn .= '<element name="CalendarYearObject" type="xsd1:CalenderYear"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('LeaveBalance', $strComplexTypeArray)) {
				$strComplexTypeArray['LeaveBalance'] = LeaveBalance::GetSoapComplexTypeXml();
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				LeaveCat::AlterSoapComplexTypeArray($strComplexTypeArray);
				LeaveGeneratePeriod::AlterSoapComplexTypeArray($strComplexTypeArray);
				CalenderYear::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, LeaveBalance::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new LeaveBalance();
			if (property_exists($objSoapObject, 'IdleaveBalance'))
				$objToReturn->intIdleaveBalance = $objSoapObject->IdleaveBalance;
			if ((property_exists($objSoapObject, 'MemberObject')) &&
				($objSoapObject->MemberObject))
				$objToReturn->MemberObject = Login::GetObjectFromSoapObject($objSoapObject->MemberObject);
			if ((property_exists($objSoapObject, 'LeaveCatObject')) &&
				($objSoapObject->LeaveCatObject))
				$objToReturn->LeaveCatObject = LeaveCat::GetObjectFromSoapObject($objSoapObject->LeaveCatObject);
			if (property_exists($objSoapObject, 'LeaveBalance'))
				$objToReturn->strLeaveBalance = $objSoapObject->LeaveBalance;
			if (property_exists($objSoapObject, 'OpeningBalance'))
				$objToReturn->strOpeningBalance = $objSoapObject->OpeningBalance;
			if (property_exists($objSoapObject, 'Closing'))
				$objToReturn->strClosing = $objSoapObject->Closing;
			if (property_exists($objSoapObject, 'GenerateDate'))
				$objToReturn->dttGenerateDate = new QDateTime($objSoapObject->GenerateDate);
			if ((property_exists($objSoapObject, 'LeaveGeneratePeriodObject')) &&
				($objSoapObject->LeaveGeneratePeriodObject))
				$objToReturn->LeaveGeneratePeriodObject = LeaveGeneratePeriod::GetObjectFromSoapObject($objSoapObject->LeaveGeneratePeriodObject);
			if ((property_exists($objSoapObject, 'CalendarYearObject')) &&
				($objSoapObject->CalendarYearObject))
				$objToReturn->CalendarYearObject = CalenderYear::GetObjectFromSoapObject($objSoapObject->CalendarYearObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, LeaveBalance::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objMemberObject)
				$objObject->objMemberObject = Login::GetSoapObjectFromObject($objObject->objMemberObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intMember = null;
			if ($objObject->objLeaveCatObject)
				$objObject->objLeaveCatObject = LeaveCat::GetSoapObjectFromObject($objObject->objLeaveCatObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intLeaveCat = null;
			if ($objObject->dttGenerateDate)
				$objObject->dttGenerateDate = $objObject->dttGenerateDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objLeaveGeneratePeriodObject)
				$objObject->objLeaveGeneratePeriodObject = LeaveGeneratePeriod::GetSoapObjectFromObject($objObject->objLeaveGeneratePeriodObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intLeaveGeneratePeriod = null;
			if ($objObject->objCalendarYearObject)
				$objObject->objCalendarYearObject = CalenderYear::GetSoapObjectFromObject($objObject->objCalendarYearObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCalendarYear = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdleaveBalance'] = $this->intIdleaveBalance;
			$iArray['Member'] = $this->intMember;
			$iArray['LeaveCat'] = $this->intLeaveCat;
			$iArray['LeaveBalance'] = $this->strLeaveBalance;
			$iArray['OpeningBalance'] = $this->strOpeningBalance;
			$iArray['Closing'] = $this->strClosing;
			$iArray['GenerateDate'] = $this->dttGenerateDate;
			$iArray['LeaveGeneratePeriod'] = $this->intLeaveGeneratePeriod;
			$iArray['CalendarYear'] = $this->intCalendarYear;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdleaveBalance ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdleaveBalance
     * @property-read QQNode $Member
     * @property-read QQNodeLogin $MemberObject
     * @property-read QQNode $LeaveCat
     * @property-read QQNodeLeaveCat $LeaveCatObject
     * @property-read QQNode $LeaveBalance
     * @property-read QQNode $OpeningBalance
     * @property-read QQNode $Closing
     * @property-read QQNode $GenerateDate
     * @property-read QQNode $LeaveGeneratePeriod
     * @property-read QQNodeLeaveGeneratePeriod $LeaveGeneratePeriodObject
     * @property-read QQNode $CalendarYear
     * @property-read QQNodeCalenderYear $CalendarYearObject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeLeaveBalance extends QQNode {
		protected $strTableName = 'leave_balance';
		protected $strPrimaryKey = 'idleave_balance';
		protected $strClassName = 'LeaveBalance';
		public function __get($strName) {
			switch ($strName) {
				case 'IdleaveBalance':
					return new QQNode('idleave_balance', 'IdleaveBalance', 'Integer', $this);
				case 'Member':
					return new QQNode('member', 'Member', 'Integer', $this);
				case 'MemberObject':
					return new QQNodeLogin('member', 'MemberObject', 'Integer', $this);
				case 'LeaveCat':
					return new QQNode('leave_cat', 'LeaveCat', 'Integer', $this);
				case 'LeaveCatObject':
					return new QQNodeLeaveCat('leave_cat', 'LeaveCatObject', 'Integer', $this);
				case 'LeaveBalance':
					return new QQNode('leave_balance', 'LeaveBalance', 'VarChar', $this);
				case 'OpeningBalance':
					return new QQNode('opening_balance', 'OpeningBalance', 'VarChar', $this);
				case 'Closing':
					return new QQNode('closing', 'Closing', 'VarChar', $this);
				case 'GenerateDate':
					return new QQNode('generate_date', 'GenerateDate', 'Date', $this);
				case 'LeaveGeneratePeriod':
					return new QQNode('leave_generate_period', 'LeaveGeneratePeriod', 'Integer', $this);
				case 'LeaveGeneratePeriodObject':
					return new QQNodeLeaveGeneratePeriod('leave_generate_period', 'LeaveGeneratePeriodObject', 'Integer', $this);
				case 'CalendarYear':
					return new QQNode('calendar_year', 'CalendarYear', 'Integer', $this);
				case 'CalendarYearObject':
					return new QQNodeCalenderYear('calendar_year', 'CalendarYearObject', 'Integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idleave_balance', 'IdleaveBalance', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdleaveBalance
     * @property-read QQNode $Member
     * @property-read QQNodeLogin $MemberObject
     * @property-read QQNode $LeaveCat
     * @property-read QQNodeLeaveCat $LeaveCatObject
     * @property-read QQNode $LeaveBalance
     * @property-read QQNode $OpeningBalance
     * @property-read QQNode $Closing
     * @property-read QQNode $GenerateDate
     * @property-read QQNode $LeaveGeneratePeriod
     * @property-read QQNodeLeaveGeneratePeriod $LeaveGeneratePeriodObject
     * @property-read QQNode $CalendarYear
     * @property-read QQNodeCalenderYear $CalendarYearObject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeLeaveBalance extends QQReverseReferenceNode {
		protected $strTableName = 'leave_balance';
		protected $strPrimaryKey = 'idleave_balance';
		protected $strClassName = 'LeaveBalance';
		public function __get($strName) {
			switch ($strName) {
				case 'IdleaveBalance':
					return new QQNode('idleave_balance', 'IdleaveBalance', 'integer', $this);
				case 'Member':
					return new QQNode('member', 'Member', 'integer', $this);
				case 'MemberObject':
					return new QQNodeLogin('member', 'MemberObject', 'integer', $this);
				case 'LeaveCat':
					return new QQNode('leave_cat', 'LeaveCat', 'integer', $this);
				case 'LeaveCatObject':
					return new QQNodeLeaveCat('leave_cat', 'LeaveCatObject', 'integer', $this);
				case 'LeaveBalance':
					return new QQNode('leave_balance', 'LeaveBalance', 'string', $this);
				case 'OpeningBalance':
					return new QQNode('opening_balance', 'OpeningBalance', 'string', $this);
				case 'Closing':
					return new QQNode('closing', 'Closing', 'string', $this);
				case 'GenerateDate':
					return new QQNode('generate_date', 'GenerateDate', 'QDateTime', $this);
				case 'LeaveGeneratePeriod':
					return new QQNode('leave_generate_period', 'LeaveGeneratePeriod', 'integer', $this);
				case 'LeaveGeneratePeriodObject':
					return new QQNodeLeaveGeneratePeriod('leave_generate_period', 'LeaveGeneratePeriodObject', 'integer', $this);
				case 'CalendarYear':
					return new QQNode('calendar_year', 'CalendarYear', 'integer', $this);
				case 'CalendarYearObject':
					return new QQNodeCalenderYear('calendar_year', 'CalendarYearObject', 'integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idleave_balance', 'IdleaveBalance', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
