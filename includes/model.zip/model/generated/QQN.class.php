<?php
	class QQN {
		/**
		 * @return QQNodeAcademicTemplet
		 */
		static public function AcademicTemplet() {
			return new QQNodeAcademicTemplet('academic_templet', null, null);
		}
		/**
		 * @return QQNodeAcademicYear
		 */
		static public function AcademicYear() {
			return new QQNodeAcademicYear('academic_year', null, null);
		}
		/**
		 * @return QQNodeAccessionCat
		 */
		static public function AccessionCat() {
			return new QQNodeAccessionCat('accession_cat', null, null);
		}
		/**
		 * @return QQNodeAddress
		 */
		static public function Address() {
			return new QQNodeAddress('address', null, null);
		}
		/**
		 * @return QQNodeAdmissionStatus
		 */
		static public function AdmissionStatus() {
			return new QQNodeAdmissionStatus('admission_status', null, null);
		}
		/**
		 * @return QQNodeAppApproval
		 */
		static public function AppApproval() {
			return new QQNodeAppApproval('app_approval', null, null);
		}
		/**
		 * @return QQNodeAppApprovalHasRemark
		 */
		static public function AppApprovalHasRemark() {
			return new QQNodeAppApprovalHasRemark('app_approval_has_remark', null, null);
		}
		/**
		 * @return QQNodeAppDocs
		 */
		static public function AppDocs() {
			return new QQNodeAppDocs('app_docs', null, null);
		}
		/**
		 * @return QQNodeAppStatus
		 */
		static public function AppStatus() {
			return new QQNodeAppStatus('app_status', null, null);
		}
		/**
		 * @return QQNodeApplication
		 */
		static public function Application() {
			return new QQNodeApplication('application', null, null);
		}
		/**
		 * @return QQNodeAppliedExam
		 */
		static public function AppliedExam() {
			return new QQNodeAppliedExam('applied_exam', null, null);
		}
		/**
		 * @return QQNodeApplyGradeImproment
		 */
		static public function ApplyGradeImproment() {
			return new QQNodeApplyGradeImproment('apply_grade_improment', null, null);
		}
		/**
		 * @return QQNodeAppointmentCategory
		 */
		static public function AppointmentCategory() {
			return new QQNodeAppointmentCategory('appointment_category', null, null);
		}
		/**
		 * @return QQNodeApprovalTemplet
		 */
		static public function ApprovalTemplet() {
			return new QQNodeApprovalTemplet('approval_templet', null, null);
		}
		/**
		 * @return QQNodeApprovel
		 */
		static public function Approvel() {
			return new QQNodeApprovel('approvel', null, null);
		}
		/**
		 * @return QQNodeArticle
		 */
		static public function Article() {
			return new QQNodeArticle('article', null, null);
		}
		/**
		 * @return QQNodeArticleGrp
		 */
		static public function ArticleGrp() {
			return new QQNodeArticleGrp('article_grp', null, null);
		}
		/**
		 * @return QQNodeAssDesignation
		 */
		static public function AssDesignation() {
			return new QQNodeAssDesignation('ass_designation', null, null);
		}
		/**
		 * @return QQNodeAssMaster
		 */
		static public function AssMaster() {
			return new QQNodeAssMaster('ass_master', null, null);
		}
		/**
		 * @return QQNodeAssMember
		 */
		static public function AssMember() {
			return new QQNodeAssMember('ass_member', null, null);
		}
		/**
		 * @return QQNodeAttendence
		 */
		static public function Attendence() {
			return new QQNodeAttendence('attendence', null, null);
		}
		/**
		 * @return QQNodeBankLoan
		 */
		static public function BankLoan() {
			return new QQNodeBankLoan('bank_loan', null, null);
		}
		/**
		 * @return QQNodeBlock
		 */
		static public function Block() {
			return new QQNodeBlock('block', null, null);
		}
		/**
		 * @return QQNodeBlockDetails
		 */
		static public function BlockDetails() {
			return new QQNodeBlockDetails('block_details', null, null);
		}
		/**
		 * @return QQNodeBloodGroup
		 */
		static public function BloodGroup() {
			return new QQNodeBloodGroup('blood_group', null, null);
		}
		/**
		 * @return QQNodeBudget
		 */
		static public function Budget() {
			return new QQNodeBudget('budget', null, null);
		}
		/**
		 * @return QQNodeBudgetCat
		 */
		static public function BudgetCat() {
			return new QQNodeBudgetCat('budget_cat', null, null);
		}
		/**
		 * @return QQNodeBusinessCat
		 */
		static public function BusinessCat() {
			return new QQNodeBusinessCat('business_cat', null, null);
		}
		/**
		 * @return QQNodeCalculation
		 */
		static public function Calculation() {
			return new QQNodeCalculation('calculation', null, null);
		}
		/**
		 * @return QQNodeCalculationGrp
		 */
		static public function CalculationGrp() {
			return new QQNodeCalculationGrp('calculation_grp', null, null);
		}
		/**
		 * @return QQNodeCalenderYear
		 */
		static public function CalenderYear() {
			return new QQNodeCalenderYear('calender_year', null, null);
		}
		/**
		 * @return QQNodeCast
		 */
		static public function Cast() {
			return new QQNodeCast('cast', null, null);
		}
		/**
		 * @return QQNodeCertificateDeposite
		 */
		static public function CertificateDeposite() {
			return new QQNodeCertificateDeposite('certificate_deposite', null, null);
		}
		/**
		 * @return QQNodeCertificateGroup
		 */
		static public function CertificateGroup() {
			return new QQNodeCertificateGroup('certificate_group', null, null);
		}
		/**
		 * @return QQNodeCertificateTemplet
		 */
		static public function CertificateTemplet() {
			return new QQNodeCertificateTemplet('certificate_templet', null, null);
		}
		/**
		 * @return QQNodeCertificateTempletHasRemark
		 */
		static public function CertificateTempletHasRemark() {
			return new QQNodeCertificateTempletHasRemark('certificate_templet_has_remark', null, null);
		}
		/**
		 * @return QQNodeCirculation
		 */
		static public function Circulation() {
			return new QQNodeCirculation('circulation', null, null);
		}
		/**
		 * @return QQNodeCompanyMaster
		 */
		static public function CompanyMaster() {
			return new QQNodeCompanyMaster('company_master', null, null);
		}
		/**
		 * @return QQNodeCourseGrp
		 */
		static public function CourseGrp() {
			return new QQNodeCourseGrp('course_grp', null, null);
		}
		/**
		 * @return QQNodeCss
		 */
		static public function Css() {
			return new QQNodeCss('css', null, null);
		}
		/**
		 * @return QQNodeCurrentStatus
		 */
		static public function CurrentStatus() {
			return new QQNodeCurrentStatus('current_status', null, null);
		}
		/**
		 * @return QQNodeDayCategory
		 */
		static public function DayCategory() {
			return new QQNodeDayCategory('day_category', null, null);
		}
		/**
		 * @return QQNodeDecision
		 */
		static public function Decision() {
			return new QQNodeDecision('decision', null, null);
		}
		/**
		 * @return QQNodeDeptTransfer
		 */
		static public function DeptTransfer() {
			return new QQNodeDeptTransfer('dept_transfer', null, null);
		}
		/**
		 * @return QQNodeDeptYear
		 */
		static public function DeptYear() {
			return new QQNodeDeptYear('dept_year', null, null);
		}
		/**
		 * @return QQNodeDeptYearEvents
		 */
		static public function DeptYearEvents() {
			return new QQNodeDeptYearEvents('dept_year_events', null, null);
		}
		/**
		 * @return QQNodeDeptYearExam
		 */
		static public function DeptYearExam() {
			return new QQNodeDeptYearExam('dept_year_exam', null, null);
		}
		/**
		 * @return QQNodeDocInOut
		 */
		static public function DocInOut() {
			return new QQNodeDocInOut('doc_in_out', null, null);
		}
		/**
		 * @return QQNodeECourse
		 */
		static public function ECourse() {
			return new QQNodeECourse('e_course', null, null);
		}
		/**
		 * @return QQNodeESession
		 */
		static public function ESession() {
			return new QQNodeESession('e_session', null, null);
		}
		/**
		 * @return QQNodeEStudent
		 */
		static public function EStudent() {
			return new QQNodeEStudent('e_student', null, null);
		}
		/**
		 * @return QQNodeETicket
		 */
		static public function ETicket() {
			return new QQNodeETicket('e_ticket', null, null);
		}
		/**
		 * @return QQNodeEcourseCategory
		 */
		static public function EcourseCategory() {
			return new QQNodeEcourseCategory('ecourse_category', null, null);
		}
		/**
		 * @return QQNodeEducationDetails
		 */
		static public function EducationDetails() {
			return new QQNodeEducationDetails('education_details', null, null);
		}
		/**
		 * @return QQNodeEducationTitle
		 */
		static public function EducationTitle() {
			return new QQNodeEducationTitle('education_title', null, null);
		}
		/**
		 * @return QQNodeEmployeeHistory
		 */
		static public function EmployeeHistory() {
			return new QQNodeEmployeeHistory('employee_history', null, null);
		}
		/**
		 * @return QQNodeEsessionCat
		 */
		static public function EsessionCat() {
			return new QQNodeEsessionCat('esession_cat', null, null);
		}
		/**
		 * @return QQNodeEstablishment
		 */
		static public function Establishment() {
			return new QQNodeEstablishment('establishment', null, null);
		}
		/**
		 * @return QQNodeEvent
		 */
		static public function Event() {
			return new QQNodeEvent('event', null, null);
		}
		/**
		 * @return QQNodeEventHasAttendent
		 */
		static public function EventHasAttendent() {
			return new QQNodeEventHasAttendent('event_has_attendent', null, null);
		}
		/**
		 * @return QQNodeEventHasGrade
		 */
		static public function EventHasGrade() {
			return new QQNodeEventHasGrade('event_has_grade', null, null);
		}
		/**
		 * @return QQNodeExam
		 */
		static public function Exam() {
			return new QQNodeExam('exam', null, null);
		}
		/**
		 * @return QQNodeExamGroup
		 */
		static public function ExamGroup() {
			return new QQNodeExamGroup('exam_group', null, null);
		}
		/**
		 * @return QQNodeExamHasEventtemplet
		 */
		static public function ExamHasEventtemplet() {
			return new QQNodeExamHasEventtemplet('exam_has_eventtemplet', null, null);
		}
		/**
		 * @return QQNodeExampaper
		 */
		static public function Exampaper() {
			return new QQNodeExampaper('exampaper', null, null);
		}
		/**
		 * @return QQNodeFees
		 */
		static public function Fees() {
			return new QQNodeFees('fees', null, null);
		}
		/**
		 * @return QQNodeFeesConcession
		 */
		static public function FeesConcession() {
			return new QQNodeFeesConcession('fees_concession', null, null);
		}
		/**
		 * @return QQNodeForwardTo
		 */
		static public function ForwardTo() {
			return new QQNodeForwardTo('forward_to', null, null);
		}
		/**
		 * @return QQNodeGardian
		 */
		static public function Gardian() {
			return new QQNodeGardian('gardian', null, null);
		}
		/**
		 * @return QQNodeGardianCat
		 */
		static public function GardianCat() {
			return new QQNodeGardianCat('gardian_cat', null, null);
		}
		/**
		 * @return QQNodeGender
		 */
		static public function Gender() {
			return new QQNodeGender('gender', null, null);
		}
		/**
		 * @return QQNodeGeneratedSalary
		 */
		static public function GeneratedSalary() {
			return new QQNodeGeneratedSalary('generated_salary', null, null);
		}
		/**
		 * @return QQNodeGrade
		 */
		static public function Grade() {
			return new QQNodeGrade('grade', null, null);
		}
		/**
		 * @return QQNodeGradeCard
		 */
		static public function GradeCard() {
			return new QQNodeGradeCard('grade_card', null, null);
		}
		/**
		 * @return QQNodeGradeGrp
		 */
		static public function GradeGrp() {
			return new QQNodeGradeGrp('grade_grp', null, null);
		}
		/**
		 * @return QQNodeGroup
		 */
		static public function Group() {
			return new QQNodeGroup('group', null, null);
		}
		/**
		 * @return QQNodeHandicapedCat
		 */
		static public function HandicapedCat() {
			return new QQNodeHandicapedCat('handicaped_cat', null, null);
		}
		/**
		 * @return QQNodeHelpdeskStatus
		 */
		static public function HelpdeskStatus() {
			return new QQNodeHelpdeskStatus('helpdesk_status', null, null);
		}
		/**
		 * @return QQNodeHistory
		 */
		static public function History() {
			return new QQNodeHistory('history', null, null);
		}
		/**
		 * @return QQNodeImpact
		 */
		static public function Impact() {
			return new QQNodeImpact('impact', null, null);
		}
		/**
		 * @return QQNodeIncomeTaxDetails
		 */
		static public function IncomeTaxDetails() {
			return new QQNodeIncomeTaxDetails('income_tax_details', null, null);
		}
		/**
		 * @return QQNodeIssuedItems
		 */
		static public function IssuedItems() {
			return new QQNodeIssuedItems('issued_items', null, null);
		}
		/**
		 * @return QQNodeIwow
		 */
		static public function Iwow() {
			return new QQNodeIwow('iwow', null, null);
		}
		/**
		 * @return QQNodeIwowCat
		 */
		static public function IwowCat() {
			return new QQNodeIwowCat('iwow_cat', null, null);
		}
		/**
		 * @return QQNodeLeaveBalance
		 */
		static public function LeaveBalance() {
			return new QQNodeLeaveBalance('leave_balance', null, null);
		}
		/**
		 * @return QQNodeLeaveCat
		 */
		static public function LeaveCat() {
			return new QQNodeLeaveCat('leave_cat', null, null);
		}
		/**
		 * @return QQNodeLeaveGeneratePeriod
		 */
		static public function LeaveGeneratePeriod() {
			return new QQNodeLeaveGeneratePeriod('leave_generate_period', null, null);
		}
		/**
		 * @return QQNodeLeaveStaffGroup
		 */
		static public function LeaveStaffGroup() {
			return new QQNodeLeaveStaffGroup('leave_staff_group', null, null);
		}
		/**
		 * @return QQNodeLeaveTemplet
		 */
		static public function LeaveTemplet() {
			return new QQNodeLeaveTemplet('leave_templet', null, null);
		}
		/**
		 * @return QQNodeLeaves
		 */
		static public function Leaves() {
			return new QQNodeLeaves('leaves', null, null);
		}
		/**
		 * @return QQNodeLeavesMgnt
		 */
		static public function LeavesMgnt() {
			return new QQNodeLeavesMgnt('leaves_mgnt', null, null);
		}
		/**
		 * @return QQNodeLedger
		 */
		static public function Ledger() {
			return new QQNodeLedger('ledger', null, null);
		}
		/**
		 * @return QQNodeLedgerDetails
		 */
		static public function LedgerDetails() {
			return new QQNodeLedgerDetails('ledger_details', null, null);
		}
		/**
		 * @return QQNodeLog
		 */
		static public function Log() {
			return new QQNodeLog('log', null, null);
		}
		/**
		 * @return QQNodeLogGrp
		 */
		static public function LogGrp() {
			return new QQNodeLogGrp('log_grp', null, null);
		}
		/**
		 * @return QQNodeLogin
		 */
		static public function Login() {
			return new QQNodeLogin('login', null, null);
		}
		/**
		 * @return QQNodeLoginHasRole
		 */
		static public function LoginHasRole() {
			return new QQNodeLoginHasRole('login_has_role', null, null);
		}
		/**
		 * @return QQNodeMarkTo
		 */
		static public function MarkTo() {
			return new QQNodeMarkTo('mark_to', null, null);
		}
		/**
		 * @return QQNodeMarrialStatus
		 */
		static public function MarrialStatus() {
			return new QQNodeMarrialStatus('marrial_status', null, null);
		}
		/**
		 * @return QQNodeMeetingAgendaPole
		 */
		static public function MeetingAgendaPole() {
			return new QQNodeMeetingAgendaPole('meeting_agenda_pole', null, null);
		}
		/**
		 * @return QQNodeMeetingGroupHasMembers
		 */
		static public function MeetingGroupHasMembers() {
			return new QQNodeMeetingGroupHasMembers('meeting_group_has_members', null, null);
		}
		/**
		 * @return QQNodeMeetingMemberGroup
		 */
		static public function MeetingMemberGroup() {
			return new QQNodeMeetingMemberGroup('meeting_member_group', null, null);
		}
		/**
		 * @return QQNodeMeetingNotes
		 */
		static public function MeetingNotes() {
			return new QQNodeMeetingNotes('meeting_notes', null, null);
		}
		/**
		 * @return QQNodeMemberDoc
		 */
		static public function MemberDoc() {
			return new QQNodeMemberDoc('member_doc', null, null);
		}
		/**
		 * @return QQNodeMenu
		 */
		static public function Menu() {
			return new QQNodeMenu('menu', null, null);
		}
		/**
		 * @return QQNodeMenuHasArticle
		 */
		static public function MenuHasArticle() {
			return new QQNodeMenuHasArticle('menu_has_article', null, null);
		}
		/**
		 * @return QQNodeMenuPosition
		 */
		static public function MenuPosition() {
			return new QQNodeMenuPosition('menu_position', null, null);
		}
		/**
		 * @return QQNodeMotherTongue
		 */
		static public function MotherTongue() {
			return new QQNodeMotherTongue('mother_tongue', null, null);
		}
		/**
		 * @return QQNodeNationality
		 */
		static public function Nationality() {
			return new QQNodeNationality('nationality', null, null);
		}
		/**
		 * @return QQNodeNews
		 */
		static public function News() {
			return new QQNodeNews('news', null, null);
		}
		/**
		 * @return QQNodeNote
		 */
		static public function Note() {
			return new QQNodeNote('note', null, null);
		}
		/**
		 * @return QQNodeOccupyBy
		 */
		static public function OccupyBy() {
			return new QQNodeOccupyBy('occupy_by', null, null);
		}
		/**
		 * @return QQNodeOccurance
		 */
		static public function Occurance() {
			return new QQNodeOccurance('occurance', null, null);
		}
		/**
		 * @return QQNodePaySlabs
		 */
		static public function PaySlabs() {
			return new QQNodePaySlabs('pay_slabs', null, null);
		}
		/**
		 * @return QQNodePlace
		 */
		static public function Place() {
			return new QQNodePlace('place', null, null);
		}
		/**
		 * @return QQNodePlaceGrp
		 */
		static public function PlaceGrp() {
			return new QQNodePlaceGrp('place_grp', null, null);
		}
		/**
		 * @return QQNodePrefix
		 */
		static public function Prefix() {
			return new QQNodePrefix('prefix', null, null);
		}
		/**
		 * @return QQNodePriceHistory
		 */
		static public function PriceHistory() {
			return new QQNodePriceHistory('price_history', null, null);
		}
		/**
		 * @return QQNodeProfile
		 */
		static public function Profile() {
			return new QQNodeProfile('profile', null, null);
		}
		/**
		 * @return QQNodeProfileHasQualifiedsubject
		 */
		static public function ProfileHasQualifiedsubject() {
			return new QQNodeProfileHasQualifiedsubject('profile_has_qualifiedsubject', null, null);
		}
		/**
		 * @return QQNodeProgramHasTimeslot
		 */
		static public function ProgramHasTimeslot() {
			return new QQNodeProgramHasTimeslot('program_has_timeslot', null, null);
		}
		/**
		 * @return QQNodeQuation
		 */
		static public function Quation() {
			return new QQNodeQuation('quation', null, null);
		}
		/**
		 * @return QQNodeReEvaluation
		 */
		static public function ReEvaluation() {
			return new QQNodeReEvaluation('re_evaluation', null, null);
		}
		/**
		 * @return QQNodeReceiptCat
		 */
		static public function ReceiptCat() {
			return new QQNodeReceiptCat('receipt_cat', null, null);
		}
		/**
		 * @return QQNodeReceipts
		 */
		static public function Receipts() {
			return new QQNodeReceipts('receipts', null, null);
		}
		/**
		 * @return QQNodeRegMember
		 */
		static public function RegMember() {
			return new QQNodeRegMember('reg_member', null, null);
		}
		/**
		 * @return QQNodeReligion
		 */
		static public function Religion() {
			return new QQNodeReligion('religion', null, null);
		}
		/**
		 * @return QQNodeRemark
		 */
		static public function Remark() {
			return new QQNodeRemark('remark', null, null);
		}
		/**
		 * @return QQNodeReproducible
		 */
		static public function Reproducible() {
			return new QQNodeReproducible('reproducible', null, null);
		}
		/**
		 * @return QQNodeReward
		 */
		static public function Reward() {
			return new QQNodeReward('reward', null, null);
		}
		/**
		 * @return QQNodeRole
		 */
		static public function Role() {
			return new QQNodeRole('role', null, null);
		}
		/**
		 * @return QQNodeRoleHasMenu
		 */
		static public function RoleHasMenu() {
			return new QQNodeRoleHasMenu('role_has_menu', null, null);
		}
		/**
		 * @return QQNodeSalary
		 */
		static public function Salary() {
			return new QQNodeSalary('salary', null, null);
		}
		/**
		 * @return QQNodeSalaryHead
		 */
		static public function SalaryHead() {
			return new QQNodeSalaryHead('salary_head', null, null);
		}
		/**
		 * @return QQNodeSalaryTemplet
		 */
		static public function SalaryTemplet() {
			return new QQNodeSalaryTemplet('salary_templet', null, null);
		}
		/**
		 * @return QQNodeSalarysheet
		 */
		static public function Salarysheet() {
			return new QQNodeSalarysheet('salarysheet', null, null);
		}
		/**
		 * @return QQNodeSalarysheetApproval
		 */
		static public function SalarysheetApproval() {
			return new QQNodeSalarysheetApproval('salarysheet_approval', null, null);
		}
		/**
		 * @return QQNodeSalarysheetHasEmployee
		 */
		static public function SalarysheetHasEmployee() {
			return new QQNodeSalarysheetHasEmployee('salarysheet_has_employee', null, null);
		}
		/**
		 * @return QQNodeScan
		 */
		static public function Scan() {
			return new QQNodeScan('scan', null, null);
		}
		/**
		 * @return QQNodeSerials
		 */
		static public function Serials() {
			return new QQNodeSerials('serials', null, null);
		}
		/**
		 * @return QQNodeSettings
		 */
		static public function Settings() {
			return new QQNodeSettings('settings', null, null);
		}
		/**
		 * @return QQNodeSignPatch
		 */
		static public function SignPatch() {
			return new QQNodeSignPatch('sign_patch', null, null);
		}
		/**
		 * @return QQNodeStatus
		 */
		static public function Status() {
			return new QQNodeStatus('status', null, null);
		}
		/**
		 * @return QQNodeStock
		 */
		static public function Stock() {
			return new QQNodeStock('stock', null, null);
		}
		/**
		 * @return QQNodeStockGrp
		 */
		static public function StockGrp() {
			return new QQNodeStockGrp('stock_grp', null, null);
		}
		/**
		 * @return QQNodeStudAttendence
		 */
		static public function StudAttendence() {
			return new QQNodeStudAttendence('stud_attendence', null, null);
		}
		/**
		 * @return QQNodeSubject
		 */
		static public function Subject() {
			return new QQNodeSubject('subject', null, null);
		}
		/**
		 * @return QQNodeSubjectTought
		 */
		static public function SubjectTought() {
			return new QQNodeSubjectTought('subject_tought', null, null);
		}
		/**
		 * @return QQNodeSupplierCat
		 */
		static public function SupplierCat() {
			return new QQNodeSupplierCat('supplier_cat', null, null);
		}
		/**
		 * @return QQNodeSupplierGrp
		 */
		static public function SupplierGrp() {
			return new QQNodeSupplierGrp('supplier_grp', null, null);
		}
		/**
		 * @return QQNodeTempletDocuments
		 */
		static public function TempletDocuments() {
			return new QQNodeTempletDocuments('templet_documents', null, null);
		}
		/**
		 * @return QQNodeTimeSlot
		 */
		static public function TimeSlot() {
			return new QQNodeTimeSlot('time_slot', null, null);
		}
		/**
		 * @return QQNodeTimetable
		 */
		static public function Timetable() {
			return new QQNodeTimetable('timetable', null, null);
		}
		/**
		 * @return QQNodeTransMode
		 */
		static public function TransMode() {
			return new QQNodeTransMode('trans_mode', null, null);
		}
		/**
		 * @return QQNodeType
		 */
		static public function Type() {
			return new QQNodeType('type', null, null);
		}
		/**
		 * @return QQNodeUnit
		 */
		static public function Unit() {
			return new QQNodeUnit('unit', null, null);
		}
		/**
		 * @return QQNodeVacancy
		 */
		static public function Vacancy() {
			return new QQNodeVacancy('vacancy', null, null);
		}
		/**
		 * @return QQNodeVisitorCat
		 */
		static public function VisitorCat() {
			return new QQNodeVisitorCat('visitor_cat', null, null);
		}
		/**
		 * @return QQNodeVisitorPass
		 */
		static public function VisitorPass() {
			return new QQNodeVisitorPass('visitor_pass', null, null);
		}
		/**
		 * @return QQNodeVoucher
		 */
		static public function Voucher() {
			return new QQNodeVoucher('voucher', null, null);
		}
		/**
		 * @return QQNodeVoucherGrp
		 */
		static public function VoucherGrp() {
			return new QQNodeVoucherGrp('voucher_grp', null, null);
		}
		/**
		 * @return QQNodeVoucherHasItem
		 */
		static public function VoucherHasItem() {
			return new QQNodeVoucherHasItem('voucher_has_item', null, null);
		}
		/**
		 * @return QQNodeYearlySubject
		 */
		static public function YearlySubject() {
			return new QQNodeYearlySubject('yearly_subject', null, null);
		}
		/**
		 * @return QQNodeYearsubjectHasTopic
		 */
		static public function YearsubjectHasTopic() {
			return new QQNodeYearsubjectHasTopic('yearsubject_has_topic', null, null);
		}
	}
?>