<?php
	/**
	 * The abstract EventHasGradeGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the EventHasGrade subclass which
	 * extends this EventHasGradeGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the EventHasGrade class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdeventHasGrade the value for intIdeventHasGrade (Read-Only PK)
	 * @property integer $Grade the value for intGrade (Not Null)
	 * @property integer $DeptYearEvents the value for intDeptYearEvents 
	 * @property integer $Min the value for intMin (Not Null)
	 * @property integer $Max the value for intMax (Not Null)
	 * @property integer $Variation the value for intVariation 
	 * @property integer $Expected the value for intExpected 
	 * @property integer $Benefit the value for intBenefit 
	 * @property integer $Loss the value for intLoss 
	 * @property integer $YearlySubject the value for intYearlySubject 
	 * @property string $LowerLimit the value for strLowerLimit 
	 * @property string $UpperLimit the value for strUpperLimit 
	 * @property string $StatTh the value for strStatTh 
	 * @property Grade $GradeObject the value for the Grade object referenced by intGrade (Not Null)
	 * @property DeptYearEvents $DeptYearEventsObject the value for the DeptYearEvents object referenced by intDeptYearEvents 
	 * @property YearlySubject $YearlySubjectObject the value for the YearlySubject object referenced by intYearlySubject 
	 * @property-read Log $_LogAsRefGrade the value for the private _objLogAsRefGrade (Read-Only) if set due to an expansion on the log.ref_grade reverse relationship
	 * @property-read Log[] $_LogAsRefGradeArray the value for the private _objLogAsRefGradeArray (Read-Only) if set due to an ExpandAsArray on the log.ref_grade reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class EventHasGradeGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column event_has_grade.idevent_has_grade
		 * @var integer intIdeventHasGrade
		 */
		protected $intIdeventHasGrade;
		const IdeventHasGradeDefault = null;


		/**
		 * Protected member variable that maps to the database column event_has_grade.grade
		 * @var integer intGrade
		 */
		protected $intGrade;
		const GradeDefault = null;


		/**
		 * Protected member variable that maps to the database column event_has_grade.dept_year_events
		 * @var integer intDeptYearEvents
		 */
		protected $intDeptYearEvents;
		const DeptYearEventsDefault = null;


		/**
		 * Protected member variable that maps to the database column event_has_grade.min
		 * @var integer intMin
		 */
		protected $intMin;
		const MinDefault = null;


		/**
		 * Protected member variable that maps to the database column event_has_grade.max
		 * @var integer intMax
		 */
		protected $intMax;
		const MaxDefault = null;


		/**
		 * Protected member variable that maps to the database column event_has_grade.variation
		 * @var integer intVariation
		 */
		protected $intVariation;
		const VariationDefault = null;


		/**
		 * Protected member variable that maps to the database column event_has_grade.expected
		 * @var integer intExpected
		 */
		protected $intExpected;
		const ExpectedDefault = null;


		/**
		 * Protected member variable that maps to the database column event_has_grade.benefit
		 * @var integer intBenefit
		 */
		protected $intBenefit;
		const BenefitDefault = null;


		/**
		 * Protected member variable that maps to the database column event_has_grade.loss
		 * @var integer intLoss
		 */
		protected $intLoss;
		const LossDefault = null;


		/**
		 * Protected member variable that maps to the database column event_has_grade.yearly_subject
		 * @var integer intYearlySubject
		 */
		protected $intYearlySubject;
		const YearlySubjectDefault = null;


		/**
		 * Protected member variable that maps to the database column event_has_grade.lower_limit
		 * @var string strLowerLimit
		 */
		protected $strLowerLimit;
		const LowerLimitDefault = null;


		/**
		 * Protected member variable that maps to the database column event_has_grade.upper_limit
		 * @var string strUpperLimit
		 */
		protected $strUpperLimit;
		const UpperLimitDefault = null;


		/**
		 * Protected member variable that maps to the database column event_has_grade.stat_th
		 * @var string strStatTh
		 */
		protected $strStatTh;
		const StatThDefault = null;


		/**
		 * Private member variable that stores a reference to a single LogAsRefGrade object
		 * (of type Log), if this EventHasGrade object was restored with
		 * an expansion on the log association table.
		 * @var Log _objLogAsRefGrade;
		 */
		private $_objLogAsRefGrade;

		/**
		 * Private member variable that stores a reference to an array of LogAsRefGrade objects
		 * (of type Log[]), if this EventHasGrade object was restored with
		 * an ExpandAsArray on the log association table.
		 * @var Log[] _objLogAsRefGradeArray;
		 */
		private $_objLogAsRefGradeArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column event_has_grade.grade.
		 *
		 * NOTE: Always use the GradeObject property getter to correctly retrieve this Grade object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Grade objGradeObject
		 */
		protected $objGradeObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column event_has_grade.dept_year_events.
		 *
		 * NOTE: Always use the DeptYearEventsObject property getter to correctly retrieve this DeptYearEvents object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var DeptYearEvents objDeptYearEventsObject
		 */
		protected $objDeptYearEventsObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column event_has_grade.yearly_subject.
		 *
		 * NOTE: Always use the YearlySubjectObject property getter to correctly retrieve this YearlySubject object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var YearlySubject objYearlySubjectObject
		 */
		protected $objYearlySubjectObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdeventHasGrade = EventHasGrade::IdeventHasGradeDefault;
			$this->intGrade = EventHasGrade::GradeDefault;
			$this->intDeptYearEvents = EventHasGrade::DeptYearEventsDefault;
			$this->intMin = EventHasGrade::MinDefault;
			$this->intMax = EventHasGrade::MaxDefault;
			$this->intVariation = EventHasGrade::VariationDefault;
			$this->intExpected = EventHasGrade::ExpectedDefault;
			$this->intBenefit = EventHasGrade::BenefitDefault;
			$this->intLoss = EventHasGrade::LossDefault;
			$this->intYearlySubject = EventHasGrade::YearlySubjectDefault;
			$this->strLowerLimit = EventHasGrade::LowerLimitDefault;
			$this->strUpperLimit = EventHasGrade::UpperLimitDefault;
			$this->strStatTh = EventHasGrade::StatThDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a EventHasGrade from PK Info
		 * @param integer $intIdeventHasGrade
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EventHasGrade
		 */
		public static function Load($intIdeventHasGrade, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'EventHasGrade', $intIdeventHasGrade);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = EventHasGrade::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::EventHasGrade()->IdeventHasGrade, $intIdeventHasGrade)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all EventHasGrades
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EventHasGrade[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call EventHasGrade::QueryArray to perform the LoadAll query
			try {
				return EventHasGrade::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all EventHasGrades
		 * @return int
		 */
		public static function CountAll() {
			// Call EventHasGrade::QueryCount to perform the CountAll query
			return EventHasGrade::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = EventHasGrade::GetDatabase();

			// Create/Build out the QueryBuilder object with EventHasGrade-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'event_has_grade');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				EventHasGrade::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('event_has_grade');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single EventHasGrade object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return EventHasGrade the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = EventHasGrade::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new EventHasGrade object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = EventHasGrade::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return EventHasGrade::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of EventHasGrade objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return EventHasGrade[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = EventHasGrade::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return EventHasGrade::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = EventHasGrade::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of EventHasGrade objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = EventHasGrade::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = EventHasGrade::GetDatabase();

			$strQuery = EventHasGrade::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/eventhasgrade', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = EventHasGrade::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this EventHasGrade
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'event_has_grade';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idevent_has_grade', $strAliasPrefix . 'idevent_has_grade');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idevent_has_grade', $strAliasPrefix . 'idevent_has_grade');
			    $objBuilder->AddSelectItem($strTableName, 'grade', $strAliasPrefix . 'grade');
			    $objBuilder->AddSelectItem($strTableName, 'dept_year_events', $strAliasPrefix . 'dept_year_events');
			    $objBuilder->AddSelectItem($strTableName, 'min', $strAliasPrefix . 'min');
			    $objBuilder->AddSelectItem($strTableName, 'max', $strAliasPrefix . 'max');
			    $objBuilder->AddSelectItem($strTableName, 'variation', $strAliasPrefix . 'variation');
			    $objBuilder->AddSelectItem($strTableName, 'expected', $strAliasPrefix . 'expected');
			    $objBuilder->AddSelectItem($strTableName, 'benefit', $strAliasPrefix . 'benefit');
			    $objBuilder->AddSelectItem($strTableName, 'loss', $strAliasPrefix . 'loss');
			    $objBuilder->AddSelectItem($strTableName, 'yearly_subject', $strAliasPrefix . 'yearly_subject');
			    $objBuilder->AddSelectItem($strTableName, 'lower_limit', $strAliasPrefix . 'lower_limit');
			    $objBuilder->AddSelectItem($strTableName, 'upper_limit', $strAliasPrefix . 'upper_limit');
			    $objBuilder->AddSelectItem($strTableName, 'stat_th', $strAliasPrefix . 'stat_th');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a EventHasGrade from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this EventHasGrade::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return EventHasGrade
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idevent_has_grade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdeventHasGrade == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'event_has_grade__';


						// Expanding reverse references: LogAsRefGrade
						$strAlias = $strAliasPrefix . 'logasrefgrade__idlog';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objLogAsRefGradeArray)
								$objPreviousItem->_objLogAsRefGradeArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objLogAsRefGradeArray)) {
								$objPreviousChildItems = $objPreviousItem->_objLogAsRefGradeArray;
								$objChildItem = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logasrefgrade__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objLogAsRefGradeArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objLogAsRefGradeArray[] = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logasrefgrade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'event_has_grade__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the EventHasGrade object
			$objToReturn = new EventHasGrade();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idevent_has_grade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdeventHasGrade = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'grade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intGrade = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'dept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDeptYearEvents = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'min';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMin = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'max';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMax = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'variation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intVariation = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'expected';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intExpected = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'benefit';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intBenefit = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'loss';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intLoss = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'yearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intYearlySubject = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'lower_limit';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strLowerLimit = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'upper_limit';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strUpperLimit = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'stat_th';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strStatTh = $objDbRow->GetColumn($strAliasName, 'VarChar');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdeventHasGrade != $objPreviousItem->IdeventHasGrade) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objLogAsRefGradeArray);
					$cnt = count($objToReturn->_objLogAsRefGradeArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objLogAsRefGradeArray, $objToReturn->_objLogAsRefGradeArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'event_has_grade__';

			// Check for GradeObject Early Binding
			$strAlias = $strAliasPrefix . 'grade__idgrade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objGradeObject = Grade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'grade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DeptYearEventsObject Early Binding
			$strAlias = $strAliasPrefix . 'dept_year_events__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDeptYearEventsObject = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'dept_year_events__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for YearlySubjectObject Early Binding
			$strAlias = $strAliasPrefix . 'yearly_subject__idyearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objYearlySubjectObject = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearly_subject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for LogAsRefGrade Virtual Binding
			$strAlias = $strAliasPrefix . 'logasrefgrade__idlog';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objLogAsRefGradeArray)
				$objToReturn->_objLogAsRefGradeArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objLogAsRefGradeArray[] = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logasrefgrade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objLogAsRefGrade = Log::InstantiateDbRow($objDbRow, $strAliasPrefix . 'logasrefgrade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of EventHasGrades from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return EventHasGrade[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = EventHasGrade::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = EventHasGrade::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single EventHasGrade object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return EventHasGrade next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return EventHasGrade::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single EventHasGrade object,
		 * by IdeventHasGrade Index(es)
		 * @param integer $intIdeventHasGrade
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EventHasGrade
		*/
		public static function LoadByIdeventHasGrade($intIdeventHasGrade, $objOptionalClauses = null) {
			return EventHasGrade::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::EventHasGrade()->IdeventHasGrade, $intIdeventHasGrade)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of EventHasGrade objects,
		 * by Grade Index(es)
		 * @param integer $intGrade
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EventHasGrade[]
		*/
		public static function LoadArrayByGrade($intGrade, $objOptionalClauses = null) {
			// Call EventHasGrade::QueryArray to perform the LoadArrayByGrade query
			try {
				return EventHasGrade::QueryArray(
					QQ::Equal(QQN::EventHasGrade()->Grade, $intGrade),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count EventHasGrades
		 * by Grade Index(es)
		 * @param integer $intGrade
		 * @return int
		*/
		public static function CountByGrade($intGrade) {
			// Call EventHasGrade::QueryCount to perform the CountByGrade query
			return EventHasGrade::QueryCount(
				QQ::Equal(QQN::EventHasGrade()->Grade, $intGrade)
			);
		}

		/**
		 * Load an array of EventHasGrade objects,
		 * by DeptYearEvents Index(es)
		 * @param integer $intDeptYearEvents
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EventHasGrade[]
		*/
		public static function LoadArrayByDeptYearEvents($intDeptYearEvents, $objOptionalClauses = null) {
			// Call EventHasGrade::QueryArray to perform the LoadArrayByDeptYearEvents query
			try {
				return EventHasGrade::QueryArray(
					QQ::Equal(QQN::EventHasGrade()->DeptYearEvents, $intDeptYearEvents),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count EventHasGrades
		 * by DeptYearEvents Index(es)
		 * @param integer $intDeptYearEvents
		 * @return int
		*/
		public static function CountByDeptYearEvents($intDeptYearEvents) {
			// Call EventHasGrade::QueryCount to perform the CountByDeptYearEvents query
			return EventHasGrade::QueryCount(
				QQ::Equal(QQN::EventHasGrade()->DeptYearEvents, $intDeptYearEvents)
			);
		}

		/**
		 * Load an array of EventHasGrade objects,
		 * by YearlySubject Index(es)
		 * @param integer $intYearlySubject
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EventHasGrade[]
		*/
		public static function LoadArrayByYearlySubject($intYearlySubject, $objOptionalClauses = null) {
			// Call EventHasGrade::QueryArray to perform the LoadArrayByYearlySubject query
			try {
				return EventHasGrade::QueryArray(
					QQ::Equal(QQN::EventHasGrade()->YearlySubject, $intYearlySubject),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count EventHasGrades
		 * by YearlySubject Index(es)
		 * @param integer $intYearlySubject
		 * @return int
		*/
		public static function CountByYearlySubject($intYearlySubject) {
			// Call EventHasGrade::QueryCount to perform the CountByYearlySubject query
			return EventHasGrade::QueryCount(
				QQ::Equal(QQN::EventHasGrade()->YearlySubject, $intYearlySubject)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this EventHasGrade
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = EventHasGrade::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `event_has_grade` (
							`grade`,
							`dept_year_events`,
							`min`,
							`max`,
							`variation`,
							`expected`,
							`benefit`,
							`loss`,
							`yearly_subject`,
							`lower_limit`,
							`upper_limit`,
							`stat_th`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intGrade) . ',
							' . $objDatabase->SqlVariable($this->intDeptYearEvents) . ',
							' . $objDatabase->SqlVariable($this->intMin) . ',
							' . $objDatabase->SqlVariable($this->intMax) . ',
							' . $objDatabase->SqlVariable($this->intVariation) . ',
							' . $objDatabase->SqlVariable($this->intExpected) . ',
							' . $objDatabase->SqlVariable($this->intBenefit) . ',
							' . $objDatabase->SqlVariable($this->intLoss) . ',
							' . $objDatabase->SqlVariable($this->intYearlySubject) . ',
							' . $objDatabase->SqlVariable($this->strLowerLimit) . ',
							' . $objDatabase->SqlVariable($this->strUpperLimit) . ',
							' . $objDatabase->SqlVariable($this->strStatTh) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdeventHasGrade = $objDatabase->InsertId('event_has_grade', 'idevent_has_grade');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`event_has_grade`
						SET
							`grade` = ' . $objDatabase->SqlVariable($this->intGrade) . ',
							`dept_year_events` = ' . $objDatabase->SqlVariable($this->intDeptYearEvents) . ',
							`min` = ' . $objDatabase->SqlVariable($this->intMin) . ',
							`max` = ' . $objDatabase->SqlVariable($this->intMax) . ',
							`variation` = ' . $objDatabase->SqlVariable($this->intVariation) . ',
							`expected` = ' . $objDatabase->SqlVariable($this->intExpected) . ',
							`benefit` = ' . $objDatabase->SqlVariable($this->intBenefit) . ',
							`loss` = ' . $objDatabase->SqlVariable($this->intLoss) . ',
							`yearly_subject` = ' . $objDatabase->SqlVariable($this->intYearlySubject) . ',
							`lower_limit` = ' . $objDatabase->SqlVariable($this->strLowerLimit) . ',
							`upper_limit` = ' . $objDatabase->SqlVariable($this->strUpperLimit) . ',
							`stat_th` = ' . $objDatabase->SqlVariable($this->strStatTh) . '
						WHERE
							`idevent_has_grade` = ' . $objDatabase->SqlVariable($this->intIdeventHasGrade) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this EventHasGrade
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdeventHasGrade)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this EventHasGrade with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = EventHasGrade::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event_has_grade`
				WHERE
					`idevent_has_grade` = ' . $objDatabase->SqlVariable($this->intIdeventHasGrade) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this EventHasGrade ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'EventHasGrade', $this->intIdeventHasGrade);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all EventHasGrades
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = EventHasGrade::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event_has_grade`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate event_has_grade table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = EventHasGrade::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `event_has_grade`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this EventHasGrade from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved EventHasGrade object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = EventHasGrade::Load($this->intIdeventHasGrade);

			// Update $this's local variables to match
			$this->Grade = $objReloaded->Grade;
			$this->DeptYearEvents = $objReloaded->DeptYearEvents;
			$this->intMin = $objReloaded->intMin;
			$this->intMax = $objReloaded->intMax;
			$this->intVariation = $objReloaded->intVariation;
			$this->intExpected = $objReloaded->intExpected;
			$this->intBenefit = $objReloaded->intBenefit;
			$this->intLoss = $objReloaded->intLoss;
			$this->YearlySubject = $objReloaded->YearlySubject;
			$this->strLowerLimit = $objReloaded->strLowerLimit;
			$this->strUpperLimit = $objReloaded->strUpperLimit;
			$this->strStatTh = $objReloaded->strStatTh;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdeventHasGrade':
					/**
					 * Gets the value for intIdeventHasGrade (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdeventHasGrade;

				case 'Grade':
					/**
					 * Gets the value for intGrade (Not Null)
					 * @return integer
					 */
					return $this->intGrade;

				case 'DeptYearEvents':
					/**
					 * Gets the value for intDeptYearEvents 
					 * @return integer
					 */
					return $this->intDeptYearEvents;

				case 'Min':
					/**
					 * Gets the value for intMin (Not Null)
					 * @return integer
					 */
					return $this->intMin;

				case 'Max':
					/**
					 * Gets the value for intMax (Not Null)
					 * @return integer
					 */
					return $this->intMax;

				case 'Variation':
					/**
					 * Gets the value for intVariation 
					 * @return integer
					 */
					return $this->intVariation;

				case 'Expected':
					/**
					 * Gets the value for intExpected 
					 * @return integer
					 */
					return $this->intExpected;

				case 'Benefit':
					/**
					 * Gets the value for intBenefit 
					 * @return integer
					 */
					return $this->intBenefit;

				case 'Loss':
					/**
					 * Gets the value for intLoss 
					 * @return integer
					 */
					return $this->intLoss;

				case 'YearlySubject':
					/**
					 * Gets the value for intYearlySubject 
					 * @return integer
					 */
					return $this->intYearlySubject;

				case 'LowerLimit':
					/**
					 * Gets the value for strLowerLimit 
					 * @return string
					 */
					return $this->strLowerLimit;

				case 'UpperLimit':
					/**
					 * Gets the value for strUpperLimit 
					 * @return string
					 */
					return $this->strUpperLimit;

				case 'StatTh':
					/**
					 * Gets the value for strStatTh 
					 * @return string
					 */
					return $this->strStatTh;


				///////////////////
				// Member Objects
				///////////////////
				case 'GradeObject':
					/**
					 * Gets the value for the Grade object referenced by intGrade (Not Null)
					 * @return Grade
					 */
					try {
						if ((!$this->objGradeObject) && (!is_null($this->intGrade)))
							$this->objGradeObject = Grade::Load($this->intGrade);
						return $this->objGradeObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DeptYearEventsObject':
					/**
					 * Gets the value for the DeptYearEvents object referenced by intDeptYearEvents 
					 * @return DeptYearEvents
					 */
					try {
						if ((!$this->objDeptYearEventsObject) && (!is_null($this->intDeptYearEvents)))
							$this->objDeptYearEventsObject = DeptYearEvents::Load($this->intDeptYearEvents);
						return $this->objDeptYearEventsObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'YearlySubjectObject':
					/**
					 * Gets the value for the YearlySubject object referenced by intYearlySubject 
					 * @return YearlySubject
					 */
					try {
						if ((!$this->objYearlySubjectObject) && (!is_null($this->intYearlySubject)))
							$this->objYearlySubjectObject = YearlySubject::Load($this->intYearlySubject);
						return $this->objYearlySubjectObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_LogAsRefGrade':
					/**
					 * Gets the value for the private _objLogAsRefGrade (Read-Only)
					 * if set due to an expansion on the log.ref_grade reverse relationship
					 * @return Log
					 */
					return $this->_objLogAsRefGrade;

				case '_LogAsRefGradeArray':
					/**
					 * Gets the value for the private _objLogAsRefGradeArray (Read-Only)
					 * if set due to an ExpandAsArray on the log.ref_grade reverse relationship
					 * @return Log[]
					 */
					return $this->_objLogAsRefGradeArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Grade':
					/**
					 * Sets the value for intGrade (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objGradeObject = null;
						return ($this->intGrade = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DeptYearEvents':
					/**
					 * Sets the value for intDeptYearEvents 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDeptYearEventsObject = null;
						return ($this->intDeptYearEvents = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Min':
					/**
					 * Sets the value for intMin (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intMin = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Max':
					/**
					 * Sets the value for intMax (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intMax = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Variation':
					/**
					 * Sets the value for intVariation 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intVariation = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Expected':
					/**
					 * Sets the value for intExpected 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intExpected = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Benefit':
					/**
					 * Sets the value for intBenefit 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intBenefit = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Loss':
					/**
					 * Sets the value for intLoss 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intLoss = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'YearlySubject':
					/**
					 * Sets the value for intYearlySubject 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objYearlySubjectObject = null;
						return ($this->intYearlySubject = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LowerLimit':
					/**
					 * Sets the value for strLowerLimit 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strLowerLimit = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'UpperLimit':
					/**
					 * Sets the value for strUpperLimit 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strUpperLimit = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'StatTh':
					/**
					 * Sets the value for strStatTh 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strStatTh = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'GradeObject':
					/**
					 * Sets the value for the Grade object referenced by intGrade (Not Null)
					 * @param Grade $mixValue
					 * @return Grade
					 */
					if (is_null($mixValue)) {
						$this->intGrade = null;
						$this->objGradeObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Grade object
						try {
							$mixValue = QType::Cast($mixValue, 'Grade');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Grade object
						if (is_null($mixValue->Idgrade))
							throw new QCallerException('Unable to set an unsaved GradeObject for this EventHasGrade');

						// Update Local Member Variables
						$this->objGradeObject = $mixValue;
						$this->intGrade = $mixValue->Idgrade;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DeptYearEventsObject':
					/**
					 * Sets the value for the DeptYearEvents object referenced by intDeptYearEvents 
					 * @param DeptYearEvents $mixValue
					 * @return DeptYearEvents
					 */
					if (is_null($mixValue)) {
						$this->intDeptYearEvents = null;
						$this->objDeptYearEventsObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a DeptYearEvents object
						try {
							$mixValue = QType::Cast($mixValue, 'DeptYearEvents');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED DeptYearEvents object
						if (is_null($mixValue->IddeptYearEvents))
							throw new QCallerException('Unable to set an unsaved DeptYearEventsObject for this EventHasGrade');

						// Update Local Member Variables
						$this->objDeptYearEventsObject = $mixValue;
						$this->intDeptYearEvents = $mixValue->IddeptYearEvents;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'YearlySubjectObject':
					/**
					 * Sets the value for the YearlySubject object referenced by intYearlySubject 
					 * @param YearlySubject $mixValue
					 * @return YearlySubject
					 */
					if (is_null($mixValue)) {
						$this->intYearlySubject = null;
						$this->objYearlySubjectObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a YearlySubject object
						try {
							$mixValue = QType::Cast($mixValue, 'YearlySubject');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED YearlySubject object
						if (is_null($mixValue->IdyearlySubject))
							throw new QCallerException('Unable to set an unsaved YearlySubjectObject for this EventHasGrade');

						// Update Local Member Variables
						$this->objYearlySubjectObject = $mixValue;
						$this->intYearlySubject = $mixValue->IdyearlySubject;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for LogAsRefGrade
		//-------------------------------------------------------------------

		/**
		 * Gets all associated LogsAsRefGrade as an array of Log objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Log[]
		*/
		public function GetLogAsRefGradeArray($objOptionalClauses = null) {
			if ((is_null($this->intIdeventHasGrade)))
				return array();

			try {
				return Log::LoadArrayByRefGrade($this->intIdeventHasGrade, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated LogsAsRefGrade
		 * @return int
		*/
		public function CountLogsAsRefGrade() {
			if ((is_null($this->intIdeventHasGrade)))
				return 0;

			return Log::CountByRefGrade($this->intIdeventHasGrade);
		}

		/**
		 * Associates a LogAsRefGrade
		 * @param Log $objLog
		 * @return void
		*/
		public function AssociateLogAsRefGrade(Log $objLog) {
			if ((is_null($this->intIdeventHasGrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLogAsRefGrade on this unsaved EventHasGrade.');
			if ((is_null($objLog->Idlog)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLogAsRefGrade on this EventHasGrade with an unsaved Log.');

			// Get the Database Object for this Class
			$objDatabase = EventHasGrade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`log`
				SET
					`ref_grade` = ' . $objDatabase->SqlVariable($this->intIdeventHasGrade) . '
				WHERE
					`idlog` = ' . $objDatabase->SqlVariable($objLog->Idlog) . '
			');
		}

		/**
		 * Unassociates a LogAsRefGrade
		 * @param Log $objLog
		 * @return void
		*/
		public function UnassociateLogAsRefGrade(Log $objLog) {
			if ((is_null($this->intIdeventHasGrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsRefGrade on this unsaved EventHasGrade.');
			if ((is_null($objLog->Idlog)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsRefGrade on this EventHasGrade with an unsaved Log.');

			// Get the Database Object for this Class
			$objDatabase = EventHasGrade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`log`
				SET
					`ref_grade` = null
				WHERE
					`idlog` = ' . $objDatabase->SqlVariable($objLog->Idlog) . ' AND
					`ref_grade` = ' . $objDatabase->SqlVariable($this->intIdeventHasGrade) . '
			');
		}

		/**
		 * Unassociates all LogsAsRefGrade
		 * @return void
		*/
		public function UnassociateAllLogsAsRefGrade() {
			if ((is_null($this->intIdeventHasGrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsRefGrade on this unsaved EventHasGrade.');

			// Get the Database Object for this Class
			$objDatabase = EventHasGrade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`log`
				SET
					`ref_grade` = null
				WHERE
					`ref_grade` = ' . $objDatabase->SqlVariable($this->intIdeventHasGrade) . '
			');
		}

		/**
		 * Deletes an associated LogAsRefGrade
		 * @param Log $objLog
		 * @return void
		*/
		public function DeleteAssociatedLogAsRefGrade(Log $objLog) {
			if ((is_null($this->intIdeventHasGrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsRefGrade on this unsaved EventHasGrade.');
			if ((is_null($objLog->Idlog)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsRefGrade on this EventHasGrade with an unsaved Log.');

			// Get the Database Object for this Class
			$objDatabase = EventHasGrade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`log`
				WHERE
					`idlog` = ' . $objDatabase->SqlVariable($objLog->Idlog) . ' AND
					`ref_grade` = ' . $objDatabase->SqlVariable($this->intIdeventHasGrade) . '
			');
		}

		/**
		 * Deletes all associated LogsAsRefGrade
		 * @return void
		*/
		public function DeleteAllLogsAsRefGrade() {
			if ((is_null($this->intIdeventHasGrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLogAsRefGrade on this unsaved EventHasGrade.');

			// Get the Database Object for this Class
			$objDatabase = EventHasGrade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`log`
				WHERE
					`ref_grade` = ' . $objDatabase->SqlVariable($this->intIdeventHasGrade) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "event_has_grade";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[EventHasGrade::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="EventHasGrade"><sequence>';
			$strToReturn .= '<element name="IdeventHasGrade" type="xsd:int"/>';
			$strToReturn .= '<element name="GradeObject" type="xsd1:Grade"/>';
			$strToReturn .= '<element name="DeptYearEventsObject" type="xsd1:DeptYearEvents"/>';
			$strToReturn .= '<element name="Min" type="xsd:int"/>';
			$strToReturn .= '<element name="Max" type="xsd:int"/>';
			$strToReturn .= '<element name="Variation" type="xsd:int"/>';
			$strToReturn .= '<element name="Expected" type="xsd:int"/>';
			$strToReturn .= '<element name="Benefit" type="xsd:int"/>';
			$strToReturn .= '<element name="Loss" type="xsd:int"/>';
			$strToReturn .= '<element name="YearlySubjectObject" type="xsd1:YearlySubject"/>';
			$strToReturn .= '<element name="LowerLimit" type="xsd:string"/>';
			$strToReturn .= '<element name="UpperLimit" type="xsd:string"/>';
			$strToReturn .= '<element name="StatTh" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('EventHasGrade', $strComplexTypeArray)) {
				$strComplexTypeArray['EventHasGrade'] = EventHasGrade::GetSoapComplexTypeXml();
				Grade::AlterSoapComplexTypeArray($strComplexTypeArray);
				DeptYearEvents::AlterSoapComplexTypeArray($strComplexTypeArray);
				YearlySubject::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, EventHasGrade::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new EventHasGrade();
			if (property_exists($objSoapObject, 'IdeventHasGrade'))
				$objToReturn->intIdeventHasGrade = $objSoapObject->IdeventHasGrade;
			if ((property_exists($objSoapObject, 'GradeObject')) &&
				($objSoapObject->GradeObject))
				$objToReturn->GradeObject = Grade::GetObjectFromSoapObject($objSoapObject->GradeObject);
			if ((property_exists($objSoapObject, 'DeptYearEventsObject')) &&
				($objSoapObject->DeptYearEventsObject))
				$objToReturn->DeptYearEventsObject = DeptYearEvents::GetObjectFromSoapObject($objSoapObject->DeptYearEventsObject);
			if (property_exists($objSoapObject, 'Min'))
				$objToReturn->intMin = $objSoapObject->Min;
			if (property_exists($objSoapObject, 'Max'))
				$objToReturn->intMax = $objSoapObject->Max;
			if (property_exists($objSoapObject, 'Variation'))
				$objToReturn->intVariation = $objSoapObject->Variation;
			if (property_exists($objSoapObject, 'Expected'))
				$objToReturn->intExpected = $objSoapObject->Expected;
			if (property_exists($objSoapObject, 'Benefit'))
				$objToReturn->intBenefit = $objSoapObject->Benefit;
			if (property_exists($objSoapObject, 'Loss'))
				$objToReturn->intLoss = $objSoapObject->Loss;
			if ((property_exists($objSoapObject, 'YearlySubjectObject')) &&
				($objSoapObject->YearlySubjectObject))
				$objToReturn->YearlySubjectObject = YearlySubject::GetObjectFromSoapObject($objSoapObject->YearlySubjectObject);
			if (property_exists($objSoapObject, 'LowerLimit'))
				$objToReturn->strLowerLimit = $objSoapObject->LowerLimit;
			if (property_exists($objSoapObject, 'UpperLimit'))
				$objToReturn->strUpperLimit = $objSoapObject->UpperLimit;
			if (property_exists($objSoapObject, 'StatTh'))
				$objToReturn->strStatTh = $objSoapObject->StatTh;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, EventHasGrade::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objGradeObject)
				$objObject->objGradeObject = Grade::GetSoapObjectFromObject($objObject->objGradeObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intGrade = null;
			if ($objObject->objDeptYearEventsObject)
				$objObject->objDeptYearEventsObject = DeptYearEvents::GetSoapObjectFromObject($objObject->objDeptYearEventsObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDeptYearEvents = null;
			if ($objObject->objYearlySubjectObject)
				$objObject->objYearlySubjectObject = YearlySubject::GetSoapObjectFromObject($objObject->objYearlySubjectObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intYearlySubject = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdeventHasGrade'] = $this->intIdeventHasGrade;
			$iArray['Grade'] = $this->intGrade;
			$iArray['DeptYearEvents'] = $this->intDeptYearEvents;
			$iArray['Min'] = $this->intMin;
			$iArray['Max'] = $this->intMax;
			$iArray['Variation'] = $this->intVariation;
			$iArray['Expected'] = $this->intExpected;
			$iArray['Benefit'] = $this->intBenefit;
			$iArray['Loss'] = $this->intLoss;
			$iArray['YearlySubject'] = $this->intYearlySubject;
			$iArray['LowerLimit'] = $this->strLowerLimit;
			$iArray['UpperLimit'] = $this->strUpperLimit;
			$iArray['StatTh'] = $this->strStatTh;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdeventHasGrade ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdeventHasGrade
     * @property-read QQNode $Grade
     * @property-read QQNodeGrade $GradeObject
     * @property-read QQNode $DeptYearEvents
     * @property-read QQNodeDeptYearEvents $DeptYearEventsObject
     * @property-read QQNode $Min
     * @property-read QQNode $Max
     * @property-read QQNode $Variation
     * @property-read QQNode $Expected
     * @property-read QQNode $Benefit
     * @property-read QQNode $Loss
     * @property-read QQNode $YearlySubject
     * @property-read QQNodeYearlySubject $YearlySubjectObject
     * @property-read QQNode $LowerLimit
     * @property-read QQNode $UpperLimit
     * @property-read QQNode $StatTh
     *
     *
     * @property-read QQReverseReferenceNodeLog $LogAsRefGrade

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeEventHasGrade extends QQNode {
		protected $strTableName = 'event_has_grade';
		protected $strPrimaryKey = 'idevent_has_grade';
		protected $strClassName = 'EventHasGrade';
		public function __get($strName) {
			switch ($strName) {
				case 'IdeventHasGrade':
					return new QQNode('idevent_has_grade', 'IdeventHasGrade', 'Integer', $this);
				case 'Grade':
					return new QQNode('grade', 'Grade', 'Integer', $this);
				case 'GradeObject':
					return new QQNodeGrade('grade', 'GradeObject', 'Integer', $this);
				case 'DeptYearEvents':
					return new QQNode('dept_year_events', 'DeptYearEvents', 'Integer', $this);
				case 'DeptYearEventsObject':
					return new QQNodeDeptYearEvents('dept_year_events', 'DeptYearEventsObject', 'Integer', $this);
				case 'Min':
					return new QQNode('min', 'Min', 'Integer', $this);
				case 'Max':
					return new QQNode('max', 'Max', 'Integer', $this);
				case 'Variation':
					return new QQNode('variation', 'Variation', 'Integer', $this);
				case 'Expected':
					return new QQNode('expected', 'Expected', 'Integer', $this);
				case 'Benefit':
					return new QQNode('benefit', 'Benefit', 'Integer', $this);
				case 'Loss':
					return new QQNode('loss', 'Loss', 'Integer', $this);
				case 'YearlySubject':
					return new QQNode('yearly_subject', 'YearlySubject', 'Integer', $this);
				case 'YearlySubjectObject':
					return new QQNodeYearlySubject('yearly_subject', 'YearlySubjectObject', 'Integer', $this);
				case 'LowerLimit':
					return new QQNode('lower_limit', 'LowerLimit', 'VarChar', $this);
				case 'UpperLimit':
					return new QQNode('upper_limit', 'UpperLimit', 'VarChar', $this);
				case 'StatTh':
					return new QQNode('stat_th', 'StatTh', 'VarChar', $this);
				case 'LogAsRefGrade':
					return new QQReverseReferenceNodeLog($this, 'logasrefgrade', 'reverse_reference', 'ref_grade');

				case '_PrimaryKeyNode':
					return new QQNode('idevent_has_grade', 'IdeventHasGrade', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdeventHasGrade
     * @property-read QQNode $Grade
     * @property-read QQNodeGrade $GradeObject
     * @property-read QQNode $DeptYearEvents
     * @property-read QQNodeDeptYearEvents $DeptYearEventsObject
     * @property-read QQNode $Min
     * @property-read QQNode $Max
     * @property-read QQNode $Variation
     * @property-read QQNode $Expected
     * @property-read QQNode $Benefit
     * @property-read QQNode $Loss
     * @property-read QQNode $YearlySubject
     * @property-read QQNodeYearlySubject $YearlySubjectObject
     * @property-read QQNode $LowerLimit
     * @property-read QQNode $UpperLimit
     * @property-read QQNode $StatTh
     *
     *
     * @property-read QQReverseReferenceNodeLog $LogAsRefGrade

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeEventHasGrade extends QQReverseReferenceNode {
		protected $strTableName = 'event_has_grade';
		protected $strPrimaryKey = 'idevent_has_grade';
		protected $strClassName = 'EventHasGrade';
		public function __get($strName) {
			switch ($strName) {
				case 'IdeventHasGrade':
					return new QQNode('idevent_has_grade', 'IdeventHasGrade', 'integer', $this);
				case 'Grade':
					return new QQNode('grade', 'Grade', 'integer', $this);
				case 'GradeObject':
					return new QQNodeGrade('grade', 'GradeObject', 'integer', $this);
				case 'DeptYearEvents':
					return new QQNode('dept_year_events', 'DeptYearEvents', 'integer', $this);
				case 'DeptYearEventsObject':
					return new QQNodeDeptYearEvents('dept_year_events', 'DeptYearEventsObject', 'integer', $this);
				case 'Min':
					return new QQNode('min', 'Min', 'integer', $this);
				case 'Max':
					return new QQNode('max', 'Max', 'integer', $this);
				case 'Variation':
					return new QQNode('variation', 'Variation', 'integer', $this);
				case 'Expected':
					return new QQNode('expected', 'Expected', 'integer', $this);
				case 'Benefit':
					return new QQNode('benefit', 'Benefit', 'integer', $this);
				case 'Loss':
					return new QQNode('loss', 'Loss', 'integer', $this);
				case 'YearlySubject':
					return new QQNode('yearly_subject', 'YearlySubject', 'integer', $this);
				case 'YearlySubjectObject':
					return new QQNodeYearlySubject('yearly_subject', 'YearlySubjectObject', 'integer', $this);
				case 'LowerLimit':
					return new QQNode('lower_limit', 'LowerLimit', 'string', $this);
				case 'UpperLimit':
					return new QQNode('upper_limit', 'UpperLimit', 'string', $this);
				case 'StatTh':
					return new QQNode('stat_th', 'StatTh', 'string', $this);
				case 'LogAsRefGrade':
					return new QQReverseReferenceNodeLog($this, 'logasrefgrade', 'reverse_reference', 'ref_grade');

				case '_PrimaryKeyNode':
					return new QQNode('idevent_has_grade', 'IdeventHasGrade', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
