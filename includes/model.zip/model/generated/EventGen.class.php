<?php
	/**
	 * The abstract EventGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Event subclass which
	 * extends this EventGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Event class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idevent the value for intIdevent (Read-Only PK)
	 * @property string $Name the value for strName (Unique)
	 * @property string $Color the value for strColor 
	 * @property string $Description the value for strDescription 
	 * @property integer $Parrent the value for intParrent 
	 * @property integer $Department the value for intDepartment (Not Null)
	 * @property QDateTime $FromDate the value for dttFromDate 
	 * @property QDateTime $FixedToDate the value for dttFixedToDate 
	 * @property integer $Occurance the value for intOccurance (Not Null)
	 * @property Event $ParrentObject the value for the Event object referenced by intParrent 
	 * @property Role $DepartmentObject the value for the Role object referenced by intDepartment (Not Null)
	 * @property Occurance $OccuranceObject the value for the Occurance object referenced by intOccurance (Not Null)
	 * @property-read DeptYearEvents $_DeptYearEvents the value for the private _objDeptYearEvents (Read-Only) if set due to an expansion on the dept_year_events.event reverse relationship
	 * @property-read DeptYearEvents[] $_DeptYearEventsArray the value for the private _objDeptYearEventsArray (Read-Only) if set due to an ExpandAsArray on the dept_year_events.event reverse relationship
	 * @property-read Event $_EventAsParrent the value for the private _objEventAsParrent (Read-Only) if set due to an expansion on the event.parrent reverse relationship
	 * @property-read Event[] $_EventAsParrentArray the value for the private _objEventAsParrentArray (Read-Only) if set due to an ExpandAsArray on the event.parrent reverse relationship
	 * @property-read ExamHasEventtemplet $_ExamHasEventtempletAsTemplet the value for the private _objExamHasEventtempletAsTemplet (Read-Only) if set due to an expansion on the exam_has_eventtemplet.eventtemplet reverse relationship
	 * @property-read ExamHasEventtemplet[] $_ExamHasEventtempletAsTempletArray the value for the private _objExamHasEventtempletAsTempletArray (Read-Only) if set due to an ExpandAsArray on the exam_has_eventtemplet.eventtemplet reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class EventGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column event.idevent
		 * @var integer intIdevent
		 */
		protected $intIdevent;
		const IdeventDefault = null;


		/**
		 * Protected member variable that maps to the database column event.name
		 * @var string strName
		 */
		protected $strName;
		const NameMaxLength = 255;
		const NameDefault = null;


		/**
		 * Protected member variable that maps to the database column event.color
		 * @var string strColor
		 */
		protected $strColor;
		const ColorMaxLength = 45;
		const ColorDefault = null;


		/**
		 * Protected member variable that maps to the database column event.description
		 * @var string strDescription
		 */
		protected $strDescription;
		const DescriptionDefault = null;


		/**
		 * Protected member variable that maps to the database column event.parrent
		 * @var integer intParrent
		 */
		protected $intParrent;
		const ParrentDefault = null;


		/**
		 * Protected member variable that maps to the database column event.department
		 * @var integer intDepartment
		 */
		protected $intDepartment;
		const DepartmentDefault = null;


		/**
		 * Protected member variable that maps to the database column event.from_date
		 * @var QDateTime dttFromDate
		 */
		protected $dttFromDate;
		const FromDateDefault = null;


		/**
		 * Protected member variable that maps to the database column event.fixed_to_date
		 * @var QDateTime dttFixedToDate
		 */
		protected $dttFixedToDate;
		const FixedToDateDefault = null;


		/**
		 * Protected member variable that maps to the database column event.occurance
		 * @var integer intOccurance
		 */
		protected $intOccurance;
		const OccuranceDefault = null;


		/**
		 * Private member variable that stores a reference to a single DeptYearEvents object
		 * (of type DeptYearEvents), if this Event object was restored with
		 * an expansion on the dept_year_events association table.
		 * @var DeptYearEvents _objDeptYearEvents;
		 */
		private $_objDeptYearEvents;

		/**
		 * Private member variable that stores a reference to an array of DeptYearEvents objects
		 * (of type DeptYearEvents[]), if this Event object was restored with
		 * an ExpandAsArray on the dept_year_events association table.
		 * @var DeptYearEvents[] _objDeptYearEventsArray;
		 */
		private $_objDeptYearEventsArray = null;

		/**
		 * Private member variable that stores a reference to a single EventAsParrent object
		 * (of type Event), if this Event object was restored with
		 * an expansion on the event association table.
		 * @var Event _objEventAsParrent;
		 */
		private $_objEventAsParrent;

		/**
		 * Private member variable that stores a reference to an array of EventAsParrent objects
		 * (of type Event[]), if this Event object was restored with
		 * an ExpandAsArray on the event association table.
		 * @var Event[] _objEventAsParrentArray;
		 */
		private $_objEventAsParrentArray = null;

		/**
		 * Private member variable that stores a reference to a single ExamHasEventtempletAsTemplet object
		 * (of type ExamHasEventtemplet), if this Event object was restored with
		 * an expansion on the exam_has_eventtemplet association table.
		 * @var ExamHasEventtemplet _objExamHasEventtempletAsTemplet;
		 */
		private $_objExamHasEventtempletAsTemplet;

		/**
		 * Private member variable that stores a reference to an array of ExamHasEventtempletAsTemplet objects
		 * (of type ExamHasEventtemplet[]), if this Event object was restored with
		 * an ExpandAsArray on the exam_has_eventtemplet association table.
		 * @var ExamHasEventtemplet[] _objExamHasEventtempletAsTempletArray;
		 */
		private $_objExamHasEventtempletAsTempletArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column event.parrent.
		 *
		 * NOTE: Always use the ParrentObject property getter to correctly retrieve this Event object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Event objParrentObject
		 */
		protected $objParrentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column event.department.
		 *
		 * NOTE: Always use the DepartmentObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objDepartmentObject
		 */
		protected $objDepartmentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column event.occurance.
		 *
		 * NOTE: Always use the OccuranceObject property getter to correctly retrieve this Occurance object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Occurance objOccuranceObject
		 */
		protected $objOccuranceObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdevent = Event::IdeventDefault;
			$this->strName = Event::NameDefault;
			$this->strColor = Event::ColorDefault;
			$this->strDescription = Event::DescriptionDefault;
			$this->intParrent = Event::ParrentDefault;
			$this->intDepartment = Event::DepartmentDefault;
			$this->dttFromDate = (Event::FromDateDefault === null)?null:new QDateTime(Event::FromDateDefault);
			$this->dttFixedToDate = (Event::FixedToDateDefault === null)?null:new QDateTime(Event::FixedToDateDefault);
			$this->intOccurance = Event::OccuranceDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Event from PK Info
		 * @param integer $intIdevent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Event
		 */
		public static function Load($intIdevent, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Event', $intIdevent);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Event::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Event()->Idevent, $intIdevent)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Events
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Event[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Event::QueryArray to perform the LoadAll query
			try {
				return Event::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Events
		 * @return int
		 */
		public static function CountAll() {
			// Call Event::QueryCount to perform the CountAll query
			return Event::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Create/Build out the QueryBuilder object with Event-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'event');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Event::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('event');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Event object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Event the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Event::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Event object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Event::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Event::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Event objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Event[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Event::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Event::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Event::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Event objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Event::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			$strQuery = Event::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/event', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Event::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Event
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'event';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idevent', $strAliasPrefix . 'idevent');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idevent', $strAliasPrefix . 'idevent');
			    $objBuilder->AddSelectItem($strTableName, 'name', $strAliasPrefix . 'name');
			    $objBuilder->AddSelectItem($strTableName, 'color', $strAliasPrefix . 'color');
			    $objBuilder->AddSelectItem($strTableName, 'description', $strAliasPrefix . 'description');
			    $objBuilder->AddSelectItem($strTableName, 'parrent', $strAliasPrefix . 'parrent');
			    $objBuilder->AddSelectItem($strTableName, 'department', $strAliasPrefix . 'department');
			    $objBuilder->AddSelectItem($strTableName, 'from_date', $strAliasPrefix . 'from_date');
			    $objBuilder->AddSelectItem($strTableName, 'fixed_to_date', $strAliasPrefix . 'fixed_to_date');
			    $objBuilder->AddSelectItem($strTableName, 'occurance', $strAliasPrefix . 'occurance');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Event from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Event::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Event
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idevent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdevent == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'event__';


						// Expanding reverse references: DeptYearEvents
						$strAlias = $strAliasPrefix . 'deptyearevents__iddept_year_events';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objDeptYearEventsArray)
								$objPreviousItem->_objDeptYearEventsArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objDeptYearEventsArray)) {
								$objPreviousChildItems = $objPreviousItem->_objDeptYearEventsArray;
								$objChildItem = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearevents__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objDeptYearEventsArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objDeptYearEventsArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearevents__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: EventAsParrent
						$strAlias = $strAliasPrefix . 'eventasparrent__idevent';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objEventAsParrentArray)
								$objPreviousItem->_objEventAsParrentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objEventAsParrentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objEventAsParrentArray;
								$objChildItem = Event::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventasparrent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objEventAsParrentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objEventAsParrentArray[] = Event::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ExamHasEventtempletAsTemplet
						$strAlias = $strAliasPrefix . 'examhaseventtempletastemplet__idexam_has_eventtemplet';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objExamHasEventtempletAsTempletArray)
								$objPreviousItem->_objExamHasEventtempletAsTempletArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objExamHasEventtempletAsTempletArray)) {
								$objPreviousChildItems = $objPreviousItem->_objExamHasEventtempletAsTempletArray;
								$objChildItem = ExamHasEventtemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'examhaseventtempletastemplet__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objExamHasEventtempletAsTempletArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objExamHasEventtempletAsTempletArray[] = ExamHasEventtemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'examhaseventtempletastemplet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'event__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Event object
			$objToReturn = new Event();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idevent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdevent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'name';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strName = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'color';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strColor = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'description';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strDescription = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'parrent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intParrent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'department';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDepartment = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'from_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttFromDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'fixed_to_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttFixedToDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'occurance';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intOccurance = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idevent != $objPreviousItem->Idevent) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objDeptYearEventsArray);
					$cnt = count($objToReturn->_objDeptYearEventsArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objDeptYearEventsArray, $objToReturn->_objDeptYearEventsArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objEventAsParrentArray);
					$cnt = count($objToReturn->_objEventAsParrentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objEventAsParrentArray, $objToReturn->_objEventAsParrentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objExamHasEventtempletAsTempletArray);
					$cnt = count($objToReturn->_objExamHasEventtempletAsTempletArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objExamHasEventtempletAsTempletArray, $objToReturn->_objExamHasEventtempletAsTempletArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'event__';

			// Check for ParrentObject Early Binding
			$strAlias = $strAliasPrefix . 'parrent__idevent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objParrentObject = Event::InstantiateDbRow($objDbRow, $strAliasPrefix . 'parrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DepartmentObject Early Binding
			$strAlias = $strAliasPrefix . 'department__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDepartmentObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'department__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for OccuranceObject Early Binding
			$strAlias = $strAliasPrefix . 'occurance__idoccurance';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objOccuranceObject = Occurance::InstantiateDbRow($objDbRow, $strAliasPrefix . 'occurance__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for DeptYearEvents Virtual Binding
			$strAlias = $strAliasPrefix . 'deptyearevents__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objDeptYearEventsArray)
				$objToReturn->_objDeptYearEventsArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objDeptYearEventsArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearevents__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objDeptYearEvents = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearevents__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for EventAsParrent Virtual Binding
			$strAlias = $strAliasPrefix . 'eventasparrent__idevent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objEventAsParrentArray)
				$objToReturn->_objEventAsParrentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objEventAsParrentArray[] = Event::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objEventAsParrent = Event::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ExamHasEventtempletAsTemplet Virtual Binding
			$strAlias = $strAliasPrefix . 'examhaseventtempletastemplet__idexam_has_eventtemplet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objExamHasEventtempletAsTempletArray)
				$objToReturn->_objExamHasEventtempletAsTempletArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objExamHasEventtempletAsTempletArray[] = ExamHasEventtemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'examhaseventtempletastemplet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objExamHasEventtempletAsTemplet = ExamHasEventtemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'examhaseventtempletastemplet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Events from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Event[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Event::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Event::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Event object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Event next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Event::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Event object,
		 * by Idevent Index(es)
		 * @param integer $intIdevent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Event
		*/
		public static function LoadByIdevent($intIdevent, $objOptionalClauses = null) {
			return Event::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Event()->Idevent, $intIdevent)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single Event object,
		 * by Name Index(es)
		 * @param string $strName
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Event
		*/
		public static function LoadByName($strName, $objOptionalClauses = null) {
			return Event::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Event()->Name, $strName)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Event objects,
		 * by Occurance Index(es)
		 * @param integer $intOccurance
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Event[]
		*/
		public static function LoadArrayByOccurance($intOccurance, $objOptionalClauses = null) {
			// Call Event::QueryArray to perform the LoadArrayByOccurance query
			try {
				return Event::QueryArray(
					QQ::Equal(QQN::Event()->Occurance, $intOccurance),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Events
		 * by Occurance Index(es)
		 * @param integer $intOccurance
		 * @return int
		*/
		public static function CountByOccurance($intOccurance) {
			// Call Event::QueryCount to perform the CountByOccurance query
			return Event::QueryCount(
				QQ::Equal(QQN::Event()->Occurance, $intOccurance)
			);
		}

		/**
		 * Load an array of Event objects,
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Event[]
		*/
		public static function LoadArrayByParrent($intParrent, $objOptionalClauses = null) {
			// Call Event::QueryArray to perform the LoadArrayByParrent query
			try {
				return Event::QueryArray(
					QQ::Equal(QQN::Event()->Parrent, $intParrent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Events
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @return int
		*/
		public static function CountByParrent($intParrent) {
			// Call Event::QueryCount to perform the CountByParrent query
			return Event::QueryCount(
				QQ::Equal(QQN::Event()->Parrent, $intParrent)
			);
		}

		/**
		 * Load an array of Event objects,
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Event[]
		*/
		public static function LoadArrayByDepartment($intDepartment, $objOptionalClauses = null) {
			// Call Event::QueryArray to perform the LoadArrayByDepartment query
			try {
				return Event::QueryArray(
					QQ::Equal(QQN::Event()->Department, $intDepartment),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Events
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @return int
		*/
		public static function CountByDepartment($intDepartment) {
			// Call Event::QueryCount to perform the CountByDepartment query
			return Event::QueryCount(
				QQ::Equal(QQN::Event()->Department, $intDepartment)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Event
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `event` (
							`name`,
							`color`,
							`description`,
							`parrent`,
							`department`,
							`from_date`,
							`fixed_to_date`,
							`occurance`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strName) . ',
							' . $objDatabase->SqlVariable($this->strColor) . ',
							' . $objDatabase->SqlVariable($this->strDescription) . ',
							' . $objDatabase->SqlVariable($this->intParrent) . ',
							' . $objDatabase->SqlVariable($this->intDepartment) . ',
							' . $objDatabase->SqlVariable($this->dttFromDate) . ',
							' . $objDatabase->SqlVariable($this->dttFixedToDate) . ',
							' . $objDatabase->SqlVariable($this->intOccurance) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdevent = $objDatabase->InsertId('event', 'idevent');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`event`
						SET
							`name` = ' . $objDatabase->SqlVariable($this->strName) . ',
							`color` = ' . $objDatabase->SqlVariable($this->strColor) . ',
							`description` = ' . $objDatabase->SqlVariable($this->strDescription) . ',
							`parrent` = ' . $objDatabase->SqlVariable($this->intParrent) . ',
							`department` = ' . $objDatabase->SqlVariable($this->intDepartment) . ',
							`from_date` = ' . $objDatabase->SqlVariable($this->dttFromDate) . ',
							`fixed_to_date` = ' . $objDatabase->SqlVariable($this->dttFixedToDate) . ',
							`occurance` = ' . $objDatabase->SqlVariable($this->intOccurance) . '
						WHERE
							`idevent` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Event
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Event with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event`
				WHERE
					`idevent` = ' . $objDatabase->SqlVariable($this->intIdevent) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Event ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Event', $this->intIdevent);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Events
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate event table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `event`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Event from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Event object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Event::Load($this->intIdevent);

			// Update $this's local variables to match
			$this->strName = $objReloaded->strName;
			$this->strColor = $objReloaded->strColor;
			$this->strDescription = $objReloaded->strDescription;
			$this->Parrent = $objReloaded->Parrent;
			$this->Department = $objReloaded->Department;
			$this->dttFromDate = $objReloaded->dttFromDate;
			$this->dttFixedToDate = $objReloaded->dttFixedToDate;
			$this->Occurance = $objReloaded->Occurance;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idevent':
					/**
					 * Gets the value for intIdevent (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdevent;

				case 'Name':
					/**
					 * Gets the value for strName (Unique)
					 * @return string
					 */
					return $this->strName;

				case 'Color':
					/**
					 * Gets the value for strColor 
					 * @return string
					 */
					return $this->strColor;

				case 'Description':
					/**
					 * Gets the value for strDescription 
					 * @return string
					 */
					return $this->strDescription;

				case 'Parrent':
					/**
					 * Gets the value for intParrent 
					 * @return integer
					 */
					return $this->intParrent;

				case 'Department':
					/**
					 * Gets the value for intDepartment (Not Null)
					 * @return integer
					 */
					return $this->intDepartment;

				case 'FromDate':
					/**
					 * Gets the value for dttFromDate 
					 * @return QDateTime
					 */
					return $this->dttFromDate;

				case 'FixedToDate':
					/**
					 * Gets the value for dttFixedToDate 
					 * @return QDateTime
					 */
					return $this->dttFixedToDate;

				case 'Occurance':
					/**
					 * Gets the value for intOccurance (Not Null)
					 * @return integer
					 */
					return $this->intOccurance;


				///////////////////
				// Member Objects
				///////////////////
				case 'ParrentObject':
					/**
					 * Gets the value for the Event object referenced by intParrent 
					 * @return Event
					 */
					try {
						if ((!$this->objParrentObject) && (!is_null($this->intParrent)))
							$this->objParrentObject = Event::Load($this->intParrent);
						return $this->objParrentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DepartmentObject':
					/**
					 * Gets the value for the Role object referenced by intDepartment (Not Null)
					 * @return Role
					 */
					try {
						if ((!$this->objDepartmentObject) && (!is_null($this->intDepartment)))
							$this->objDepartmentObject = Role::Load($this->intDepartment);
						return $this->objDepartmentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'OccuranceObject':
					/**
					 * Gets the value for the Occurance object referenced by intOccurance (Not Null)
					 * @return Occurance
					 */
					try {
						if ((!$this->objOccuranceObject) && (!is_null($this->intOccurance)))
							$this->objOccuranceObject = Occurance::Load($this->intOccurance);
						return $this->objOccuranceObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_DeptYearEvents':
					/**
					 * Gets the value for the private _objDeptYearEvents (Read-Only)
					 * if set due to an expansion on the dept_year_events.event reverse relationship
					 * @return DeptYearEvents
					 */
					return $this->_objDeptYearEvents;

				case '_DeptYearEventsArray':
					/**
					 * Gets the value for the private _objDeptYearEventsArray (Read-Only)
					 * if set due to an ExpandAsArray on the dept_year_events.event reverse relationship
					 * @return DeptYearEvents[]
					 */
					return $this->_objDeptYearEventsArray;

				case '_EventAsParrent':
					/**
					 * Gets the value for the private _objEventAsParrent (Read-Only)
					 * if set due to an expansion on the event.parrent reverse relationship
					 * @return Event
					 */
					return $this->_objEventAsParrent;

				case '_EventAsParrentArray':
					/**
					 * Gets the value for the private _objEventAsParrentArray (Read-Only)
					 * if set due to an ExpandAsArray on the event.parrent reverse relationship
					 * @return Event[]
					 */
					return $this->_objEventAsParrentArray;

				case '_ExamHasEventtempletAsTemplet':
					/**
					 * Gets the value for the private _objExamHasEventtempletAsTemplet (Read-Only)
					 * if set due to an expansion on the exam_has_eventtemplet.eventtemplet reverse relationship
					 * @return ExamHasEventtemplet
					 */
					return $this->_objExamHasEventtempletAsTemplet;

				case '_ExamHasEventtempletAsTempletArray':
					/**
					 * Gets the value for the private _objExamHasEventtempletAsTempletArray (Read-Only)
					 * if set due to an ExpandAsArray on the exam_has_eventtemplet.eventtemplet reverse relationship
					 * @return ExamHasEventtemplet[]
					 */
					return $this->_objExamHasEventtempletAsTempletArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Name':
					/**
					 * Sets the value for strName (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strName = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Color':
					/**
					 * Sets the value for strColor 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strColor = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Description':
					/**
					 * Sets the value for strDescription 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strDescription = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Parrent':
					/**
					 * Sets the value for intParrent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objParrentObject = null;
						return ($this->intParrent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Department':
					/**
					 * Sets the value for intDepartment (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDepartmentObject = null;
						return ($this->intDepartment = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'FromDate':
					/**
					 * Sets the value for dttFromDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttFromDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'FixedToDate':
					/**
					 * Sets the value for dttFixedToDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttFixedToDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Occurance':
					/**
					 * Sets the value for intOccurance (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objOccuranceObject = null;
						return ($this->intOccurance = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'ParrentObject':
					/**
					 * Sets the value for the Event object referenced by intParrent 
					 * @param Event $mixValue
					 * @return Event
					 */
					if (is_null($mixValue)) {
						$this->intParrent = null;
						$this->objParrentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Event object
						try {
							$mixValue = QType::Cast($mixValue, 'Event');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Event object
						if (is_null($mixValue->Idevent))
							throw new QCallerException('Unable to set an unsaved ParrentObject for this Event');

						// Update Local Member Variables
						$this->objParrentObject = $mixValue;
						$this->intParrent = $mixValue->Idevent;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DepartmentObject':
					/**
					 * Sets the value for the Role object referenced by intDepartment (Not Null)
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intDepartment = null;
						$this->objDepartmentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved DepartmentObject for this Event');

						// Update Local Member Variables
						$this->objDepartmentObject = $mixValue;
						$this->intDepartment = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'OccuranceObject':
					/**
					 * Sets the value for the Occurance object referenced by intOccurance (Not Null)
					 * @param Occurance $mixValue
					 * @return Occurance
					 */
					if (is_null($mixValue)) {
						$this->intOccurance = null;
						$this->objOccuranceObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Occurance object
						try {
							$mixValue = QType::Cast($mixValue, 'Occurance');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Occurance object
						if (is_null($mixValue->Idoccurance))
							throw new QCallerException('Unable to set an unsaved OccuranceObject for this Event');

						// Update Local Member Variables
						$this->objOccuranceObject = $mixValue;
						$this->intOccurance = $mixValue->Idoccurance;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for DeptYearEvents
		//-------------------------------------------------------------------

		/**
		 * Gets all associated DeptYearEventses as an array of DeptYearEvents objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public function GetDeptYearEventsArray($objOptionalClauses = null) {
			if ((is_null($this->intIdevent)))
				return array();

			try {
				return DeptYearEvents::LoadArrayByEvent($this->intIdevent, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated DeptYearEventses
		 * @return int
		*/
		public function CountDeptYearEventses() {
			if ((is_null($this->intIdevent)))
				return 0;

			return DeptYearEvents::CountByEvent($this->intIdevent);
		}

		/**
		 * Associates a DeptYearEvents
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function AssociateDeptYearEvents(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEvents on this unsaved Event.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEvents on this Event with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`event` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates a DeptYearEvents
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function UnassociateDeptYearEvents(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this unsaved Event.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this Event with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`event` = null
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`event` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
			');
		}

		/**
		 * Unassociates all DeptYearEventses
		 * @return void
		*/
		public function UnassociateAllDeptYearEventses() {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this unsaved Event.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`event` = null
				WHERE
					`event` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
			');
		}

		/**
		 * Deletes an associated DeptYearEvents
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function DeleteAssociatedDeptYearEvents(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this unsaved Event.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this Event with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`event` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
			');
		}

		/**
		 * Deletes all associated DeptYearEventses
		 * @return void
		*/
		public function DeleteAllDeptYearEventses() {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this unsaved Event.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`event` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
			');
		}


		// Related Objects' Methods for EventAsParrent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated EventsAsParrent as an array of Event objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Event[]
		*/
		public function GetEventAsParrentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdevent)))
				return array();

			try {
				return Event::LoadArrayByParrent($this->intIdevent, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated EventsAsParrent
		 * @return int
		*/
		public function CountEventsAsParrent() {
			if ((is_null($this->intIdevent)))
				return 0;

			return Event::CountByParrent($this->intIdevent);
		}

		/**
		 * Associates a EventAsParrent
		 * @param Event $objEvent
		 * @return void
		*/
		public function AssociateEventAsParrent(Event $objEvent) {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEventAsParrent on this unsaved Event.');
			if ((is_null($objEvent->Idevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEventAsParrent on this Event with an unsaved Event.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event`
				SET
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
				WHERE
					`idevent` = ' . $objDatabase->SqlVariable($objEvent->Idevent) . '
			');
		}

		/**
		 * Unassociates a EventAsParrent
		 * @param Event $objEvent
		 * @return void
		*/
		public function UnassociateEventAsParrent(Event $objEvent) {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventAsParrent on this unsaved Event.');
			if ((is_null($objEvent->Idevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventAsParrent on this Event with an unsaved Event.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event`
				SET
					`parrent` = null
				WHERE
					`idevent` = ' . $objDatabase->SqlVariable($objEvent->Idevent) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
			');
		}

		/**
		 * Unassociates all EventsAsParrent
		 * @return void
		*/
		public function UnassociateAllEventsAsParrent() {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventAsParrent on this unsaved Event.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event`
				SET
					`parrent` = null
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
			');
		}

		/**
		 * Deletes an associated EventAsParrent
		 * @param Event $objEvent
		 * @return void
		*/
		public function DeleteAssociatedEventAsParrent(Event $objEvent) {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventAsParrent on this unsaved Event.');
			if ((is_null($objEvent->Idevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventAsParrent on this Event with an unsaved Event.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event`
				WHERE
					`idevent` = ' . $objDatabase->SqlVariable($objEvent->Idevent) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
			');
		}

		/**
		 * Deletes all associated EventsAsParrent
		 * @return void
		*/
		public function DeleteAllEventsAsParrent() {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventAsParrent on this unsaved Event.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event`
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
			');
		}


		// Related Objects' Methods for ExamHasEventtempletAsTemplet
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ExamHasEventtempletsAsTemplet as an array of ExamHasEventtemplet objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ExamHasEventtemplet[]
		*/
		public function GetExamHasEventtempletAsTempletArray($objOptionalClauses = null) {
			if ((is_null($this->intIdevent)))
				return array();

			try {
				return ExamHasEventtemplet::LoadArrayByEventtemplet($this->intIdevent, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ExamHasEventtempletsAsTemplet
		 * @return int
		*/
		public function CountExamHasEventtempletsAsTemplet() {
			if ((is_null($this->intIdevent)))
				return 0;

			return ExamHasEventtemplet::CountByEventtemplet($this->intIdevent);
		}

		/**
		 * Associates a ExamHasEventtempletAsTemplet
		 * @param ExamHasEventtemplet $objExamHasEventtemplet
		 * @return void
		*/
		public function AssociateExamHasEventtempletAsTemplet(ExamHasEventtemplet $objExamHasEventtemplet) {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateExamHasEventtempletAsTemplet on this unsaved Event.');
			if ((is_null($objExamHasEventtemplet->IdexamHasEventtemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateExamHasEventtempletAsTemplet on this Event with an unsaved ExamHasEventtemplet.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`exam_has_eventtemplet`
				SET
					`eventtemplet` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
				WHERE
					`idexam_has_eventtemplet` = ' . $objDatabase->SqlVariable($objExamHasEventtemplet->IdexamHasEventtemplet) . '
			');
		}

		/**
		 * Unassociates a ExamHasEventtempletAsTemplet
		 * @param ExamHasEventtemplet $objExamHasEventtemplet
		 * @return void
		*/
		public function UnassociateExamHasEventtempletAsTemplet(ExamHasEventtemplet $objExamHasEventtemplet) {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExamHasEventtempletAsTemplet on this unsaved Event.');
			if ((is_null($objExamHasEventtemplet->IdexamHasEventtemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExamHasEventtempletAsTemplet on this Event with an unsaved ExamHasEventtemplet.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`exam_has_eventtemplet`
				SET
					`eventtemplet` = null
				WHERE
					`idexam_has_eventtemplet` = ' . $objDatabase->SqlVariable($objExamHasEventtemplet->IdexamHasEventtemplet) . ' AND
					`eventtemplet` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
			');
		}

		/**
		 * Unassociates all ExamHasEventtempletsAsTemplet
		 * @return void
		*/
		public function UnassociateAllExamHasEventtempletsAsTemplet() {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExamHasEventtempletAsTemplet on this unsaved Event.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`exam_has_eventtemplet`
				SET
					`eventtemplet` = null
				WHERE
					`eventtemplet` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
			');
		}

		/**
		 * Deletes an associated ExamHasEventtempletAsTemplet
		 * @param ExamHasEventtemplet $objExamHasEventtemplet
		 * @return void
		*/
		public function DeleteAssociatedExamHasEventtempletAsTemplet(ExamHasEventtemplet $objExamHasEventtemplet) {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExamHasEventtempletAsTemplet on this unsaved Event.');
			if ((is_null($objExamHasEventtemplet->IdexamHasEventtemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExamHasEventtempletAsTemplet on this Event with an unsaved ExamHasEventtemplet.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`exam_has_eventtemplet`
				WHERE
					`idexam_has_eventtemplet` = ' . $objDatabase->SqlVariable($objExamHasEventtemplet->IdexamHasEventtemplet) . ' AND
					`eventtemplet` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
			');
		}

		/**
		 * Deletes all associated ExamHasEventtempletsAsTemplet
		 * @return void
		*/
		public function DeleteAllExamHasEventtempletsAsTemplet() {
			if ((is_null($this->intIdevent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExamHasEventtempletAsTemplet on this unsaved Event.');

			// Get the Database Object for this Class
			$objDatabase = Event::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`exam_has_eventtemplet`
				WHERE
					`eventtemplet` = ' . $objDatabase->SqlVariable($this->intIdevent) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "event";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Event::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Event"><sequence>';
			$strToReturn .= '<element name="Idevent" type="xsd:int"/>';
			$strToReturn .= '<element name="Name" type="xsd:string"/>';
			$strToReturn .= '<element name="Color" type="xsd:string"/>';
			$strToReturn .= '<element name="Description" type="xsd:string"/>';
			$strToReturn .= '<element name="ParrentObject" type="xsd1:Event"/>';
			$strToReturn .= '<element name="DepartmentObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="FromDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="FixedToDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="OccuranceObject" type="xsd1:Occurance"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Event', $strComplexTypeArray)) {
				$strComplexTypeArray['Event'] = Event::GetSoapComplexTypeXml();
				Event::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				Occurance::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Event::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Event();
			if (property_exists($objSoapObject, 'Idevent'))
				$objToReturn->intIdevent = $objSoapObject->Idevent;
			if (property_exists($objSoapObject, 'Name'))
				$objToReturn->strName = $objSoapObject->Name;
			if (property_exists($objSoapObject, 'Color'))
				$objToReturn->strColor = $objSoapObject->Color;
			if (property_exists($objSoapObject, 'Description'))
				$objToReturn->strDescription = $objSoapObject->Description;
			if ((property_exists($objSoapObject, 'ParrentObject')) &&
				($objSoapObject->ParrentObject))
				$objToReturn->ParrentObject = Event::GetObjectFromSoapObject($objSoapObject->ParrentObject);
			if ((property_exists($objSoapObject, 'DepartmentObject')) &&
				($objSoapObject->DepartmentObject))
				$objToReturn->DepartmentObject = Role::GetObjectFromSoapObject($objSoapObject->DepartmentObject);
			if (property_exists($objSoapObject, 'FromDate'))
				$objToReturn->dttFromDate = new QDateTime($objSoapObject->FromDate);
			if (property_exists($objSoapObject, 'FixedToDate'))
				$objToReturn->dttFixedToDate = new QDateTime($objSoapObject->FixedToDate);
			if ((property_exists($objSoapObject, 'OccuranceObject')) &&
				($objSoapObject->OccuranceObject))
				$objToReturn->OccuranceObject = Occurance::GetObjectFromSoapObject($objSoapObject->OccuranceObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Event::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objParrentObject)
				$objObject->objParrentObject = Event::GetSoapObjectFromObject($objObject->objParrentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intParrent = null;
			if ($objObject->objDepartmentObject)
				$objObject->objDepartmentObject = Role::GetSoapObjectFromObject($objObject->objDepartmentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDepartment = null;
			if ($objObject->dttFromDate)
				$objObject->dttFromDate = $objObject->dttFromDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttFixedToDate)
				$objObject->dttFixedToDate = $objObject->dttFixedToDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objOccuranceObject)
				$objObject->objOccuranceObject = Occurance::GetSoapObjectFromObject($objObject->objOccuranceObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intOccurance = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idevent'] = $this->intIdevent;
			$iArray['Name'] = $this->strName;
			$iArray['Color'] = $this->strColor;
			$iArray['Description'] = $this->strDescription;
			$iArray['Parrent'] = $this->intParrent;
			$iArray['Department'] = $this->intDepartment;
			$iArray['FromDate'] = $this->dttFromDate;
			$iArray['FixedToDate'] = $this->dttFixedToDate;
			$iArray['Occurance'] = $this->intOccurance;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdevent ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idevent
     * @property-read QQNode $Name
     * @property-read QQNode $Color
     * @property-read QQNode $Description
     * @property-read QQNode $Parrent
     * @property-read QQNodeEvent $ParrentObject
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $FromDate
     * @property-read QQNode $FixedToDate
     * @property-read QQNode $Occurance
     * @property-read QQNodeOccurance $OccuranceObject
     *
     *
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEvents
     * @property-read QQReverseReferenceNodeEvent $EventAsParrent
     * @property-read QQReverseReferenceNodeExamHasEventtemplet $ExamHasEventtempletAsTemplet

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeEvent extends QQNode {
		protected $strTableName = 'event';
		protected $strPrimaryKey = 'idevent';
		protected $strClassName = 'Event';
		public function __get($strName) {
			switch ($strName) {
				case 'Idevent':
					return new QQNode('idevent', 'Idevent', 'Integer', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'VarChar', $this);
				case 'Color':
					return new QQNode('color', 'Color', 'VarChar', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'Blob', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'Integer', $this);
				case 'ParrentObject':
					return new QQNodeEvent('parrent', 'ParrentObject', 'Integer', $this);
				case 'Department':
					return new QQNode('department', 'Department', 'Integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'Integer', $this);
				case 'FromDate':
					return new QQNode('from_date', 'FromDate', 'DateTime', $this);
				case 'FixedToDate':
					return new QQNode('fixed_to_date', 'FixedToDate', 'DateTime', $this);
				case 'Occurance':
					return new QQNode('occurance', 'Occurance', 'Integer', $this);
				case 'OccuranceObject':
					return new QQNodeOccurance('occurance', 'OccuranceObject', 'Integer', $this);
				case 'DeptYearEvents':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyearevents', 'reverse_reference', 'event');
				case 'EventAsParrent':
					return new QQReverseReferenceNodeEvent($this, 'eventasparrent', 'reverse_reference', 'parrent');
				case 'ExamHasEventtempletAsTemplet':
					return new QQReverseReferenceNodeExamHasEventtemplet($this, 'examhaseventtempletastemplet', 'reverse_reference', 'eventtemplet');

				case '_PrimaryKeyNode':
					return new QQNode('idevent', 'Idevent', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idevent
     * @property-read QQNode $Name
     * @property-read QQNode $Color
     * @property-read QQNode $Description
     * @property-read QQNode $Parrent
     * @property-read QQNodeEvent $ParrentObject
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $FromDate
     * @property-read QQNode $FixedToDate
     * @property-read QQNode $Occurance
     * @property-read QQNodeOccurance $OccuranceObject
     *
     *
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEvents
     * @property-read QQReverseReferenceNodeEvent $EventAsParrent
     * @property-read QQReverseReferenceNodeExamHasEventtemplet $ExamHasEventtempletAsTemplet

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeEvent extends QQReverseReferenceNode {
		protected $strTableName = 'event';
		protected $strPrimaryKey = 'idevent';
		protected $strClassName = 'Event';
		public function __get($strName) {
			switch ($strName) {
				case 'Idevent':
					return new QQNode('idevent', 'Idevent', 'integer', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'string', $this);
				case 'Color':
					return new QQNode('color', 'Color', 'string', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'string', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'integer', $this);
				case 'ParrentObject':
					return new QQNodeEvent('parrent', 'ParrentObject', 'integer', $this);
				case 'Department':
					return new QQNode('department', 'Department', 'integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'integer', $this);
				case 'FromDate':
					return new QQNode('from_date', 'FromDate', 'QDateTime', $this);
				case 'FixedToDate':
					return new QQNode('fixed_to_date', 'FixedToDate', 'QDateTime', $this);
				case 'Occurance':
					return new QQNode('occurance', 'Occurance', 'integer', $this);
				case 'OccuranceObject':
					return new QQNodeOccurance('occurance', 'OccuranceObject', 'integer', $this);
				case 'DeptYearEvents':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyearevents', 'reverse_reference', 'event');
				case 'EventAsParrent':
					return new QQReverseReferenceNodeEvent($this, 'eventasparrent', 'reverse_reference', 'parrent');
				case 'ExamHasEventtempletAsTemplet':
					return new QQReverseReferenceNodeExamHasEventtemplet($this, 'examhaseventtempletastemplet', 'reverse_reference', 'eventtemplet');

				case '_PrimaryKeyNode':
					return new QQNode('idevent', 'Idevent', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
