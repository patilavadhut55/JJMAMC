<?php
	/**
	 * The abstract AttendenceGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Attendence subclass which
	 * extends this AttendenceGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Attendence class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idattendence the value for intIdattendence (Read-Only PK)
	 * @property integer $Staff the value for intStaff (Not Null)
	 * @property QDateTime $InTime the value for dttInTime 
	 * @property QDateTime $OutTime the value for dttOutTime 
	 * @property integer $DayCategory the value for intDayCategory 
	 * @property string $Note the value for strNote 
	 * @property integer $LeaveCategory the value for intLeaveCategory 
	 * @property boolean $Presenty the value for blnPresenty 
	 * @property Login $StaffObject the value for the Login object referenced by intStaff (Not Null)
	 * @property DayCategory $DayCategoryObject the value for the DayCategory object referenced by intDayCategory 
	 * @property Ledger $LeaveCategoryObject the value for the Ledger object referenced by intLeaveCategory 
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class AttendenceGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column attendence.idattendence
		 * @var integer intIdattendence
		 */
		protected $intIdattendence;
		const IdattendenceDefault = null;


		/**
		 * Protected member variable that maps to the database column attendence.staff
		 * @var integer intStaff
		 */
		protected $intStaff;
		const StaffDefault = null;


		/**
		 * Protected member variable that maps to the database column attendence.in_time
		 * @var QDateTime dttInTime
		 */
		protected $dttInTime;
		const InTimeDefault = null;


		/**
		 * Protected member variable that maps to the database column attendence.out_time
		 * @var QDateTime dttOutTime
		 */
		protected $dttOutTime;
		const OutTimeDefault = null;


		/**
		 * Protected member variable that maps to the database column attendence.day_category
		 * @var integer intDayCategory
		 */
		protected $intDayCategory;
		const DayCategoryDefault = null;


		/**
		 * Protected member variable that maps to the database column attendence.note
		 * @var string strNote
		 */
		protected $strNote;
		const NoteDefault = null;


		/**
		 * Protected member variable that maps to the database column attendence.leave_category
		 * @var integer intLeaveCategory
		 */
		protected $intLeaveCategory;
		const LeaveCategoryDefault = null;


		/**
		 * Protected member variable that maps to the database column attendence.presenty
		 * @var boolean blnPresenty
		 */
		protected $blnPresenty;
		const PresentyDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column attendence.staff.
		 *
		 * NOTE: Always use the StaffObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objStaffObject
		 */
		protected $objStaffObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column attendence.day_category.
		 *
		 * NOTE: Always use the DayCategoryObject property getter to correctly retrieve this DayCategory object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var DayCategory objDayCategoryObject
		 */
		protected $objDayCategoryObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column attendence.leave_category.
		 *
		 * NOTE: Always use the LeaveCategoryObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objLeaveCategoryObject
		 */
		protected $objLeaveCategoryObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdattendence = Attendence::IdattendenceDefault;
			$this->intStaff = Attendence::StaffDefault;
			$this->dttInTime = (Attendence::InTimeDefault === null)?null:new QDateTime(Attendence::InTimeDefault);
			$this->dttOutTime = (Attendence::OutTimeDefault === null)?null:new QDateTime(Attendence::OutTimeDefault);
			$this->intDayCategory = Attendence::DayCategoryDefault;
			$this->strNote = Attendence::NoteDefault;
			$this->intLeaveCategory = Attendence::LeaveCategoryDefault;
			$this->blnPresenty = Attendence::PresentyDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Attendence from PK Info
		 * @param integer $intIdattendence
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Attendence
		 */
		public static function Load($intIdattendence, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Attendence', $intIdattendence);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Attendence::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Attendence()->Idattendence, $intIdattendence)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Attendences
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Attendence[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Attendence::QueryArray to perform the LoadAll query
			try {
				return Attendence::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Attendences
		 * @return int
		 */
		public static function CountAll() {
			// Call Attendence::QueryCount to perform the CountAll query
			return Attendence::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Attendence::GetDatabase();

			// Create/Build out the QueryBuilder object with Attendence-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'attendence');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Attendence::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('attendence');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Attendence object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Attendence the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Attendence::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Attendence object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Attendence::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Attendence::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Attendence objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Attendence[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Attendence::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Attendence::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Attendence::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Attendence objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Attendence::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Attendence::GetDatabase();

			$strQuery = Attendence::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/attendence', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Attendence::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Attendence
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'attendence';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idattendence', $strAliasPrefix . 'idattendence');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idattendence', $strAliasPrefix . 'idattendence');
			    $objBuilder->AddSelectItem($strTableName, 'staff', $strAliasPrefix . 'staff');
			    $objBuilder->AddSelectItem($strTableName, 'in_time', $strAliasPrefix . 'in_time');
			    $objBuilder->AddSelectItem($strTableName, 'out_time', $strAliasPrefix . 'out_time');
			    $objBuilder->AddSelectItem($strTableName, 'day_category', $strAliasPrefix . 'day_category');
			    $objBuilder->AddSelectItem($strTableName, 'note', $strAliasPrefix . 'note');
			    $objBuilder->AddSelectItem($strTableName, 'leave_category', $strAliasPrefix . 'leave_category');
			    $objBuilder->AddSelectItem($strTableName, 'presenty', $strAliasPrefix . 'presenty');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Attendence from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Attendence::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Attendence
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the Attendence object
			$objToReturn = new Attendence();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idattendence';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdattendence = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'staff';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intStaff = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'in_time';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttInTime = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'out_time';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttOutTime = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'day_category';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDayCategory = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'note';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strNote = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'leave_category';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intLeaveCategory = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'presenty';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnPresenty = $objDbRow->GetColumn($strAliasName, 'Bit');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idattendence != $objPreviousItem->Idattendence) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'attendence__';

			// Check for StaffObject Early Binding
			$strAlias = $strAliasPrefix . 'staff__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objStaffObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'staff__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DayCategoryObject Early Binding
			$strAlias = $strAliasPrefix . 'day_category__idday_category';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDayCategoryObject = DayCategory::InstantiateDbRow($objDbRow, $strAliasPrefix . 'day_category__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for LeaveCategoryObject Early Binding
			$strAlias = $strAliasPrefix . 'leave_category__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objLeaveCategoryObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leave_category__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of Attendences from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Attendence[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Attendence::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Attendence::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Attendence object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Attendence next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Attendence::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Attendence object,
		 * by Idattendence Index(es)
		 * @param integer $intIdattendence
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Attendence
		*/
		public static function LoadByIdattendence($intIdattendence, $objOptionalClauses = null) {
			return Attendence::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Attendence()->Idattendence, $intIdattendence)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Attendence objects,
		 * by DayCategory Index(es)
		 * @param integer $intDayCategory
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Attendence[]
		*/
		public static function LoadArrayByDayCategory($intDayCategory, $objOptionalClauses = null) {
			// Call Attendence::QueryArray to perform the LoadArrayByDayCategory query
			try {
				return Attendence::QueryArray(
					QQ::Equal(QQN::Attendence()->DayCategory, $intDayCategory),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Attendences
		 * by DayCategory Index(es)
		 * @param integer $intDayCategory
		 * @return int
		*/
		public static function CountByDayCategory($intDayCategory) {
			// Call Attendence::QueryCount to perform the CountByDayCategory query
			return Attendence::QueryCount(
				QQ::Equal(QQN::Attendence()->DayCategory, $intDayCategory)
			);
		}

		/**
		 * Load an array of Attendence objects,
		 * by Staff Index(es)
		 * @param integer $intStaff
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Attendence[]
		*/
		public static function LoadArrayByStaff($intStaff, $objOptionalClauses = null) {
			// Call Attendence::QueryArray to perform the LoadArrayByStaff query
			try {
				return Attendence::QueryArray(
					QQ::Equal(QQN::Attendence()->Staff, $intStaff),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Attendences
		 * by Staff Index(es)
		 * @param integer $intStaff
		 * @return int
		*/
		public static function CountByStaff($intStaff) {
			// Call Attendence::QueryCount to perform the CountByStaff query
			return Attendence::QueryCount(
				QQ::Equal(QQN::Attendence()->Staff, $intStaff)
			);
		}

		/**
		 * Load an array of Attendence objects,
		 * by LeaveCategory Index(es)
		 * @param integer $intLeaveCategory
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Attendence[]
		*/
		public static function LoadArrayByLeaveCategory($intLeaveCategory, $objOptionalClauses = null) {
			// Call Attendence::QueryArray to perform the LoadArrayByLeaveCategory query
			try {
				return Attendence::QueryArray(
					QQ::Equal(QQN::Attendence()->LeaveCategory, $intLeaveCategory),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Attendences
		 * by LeaveCategory Index(es)
		 * @param integer $intLeaveCategory
		 * @return int
		*/
		public static function CountByLeaveCategory($intLeaveCategory) {
			// Call Attendence::QueryCount to perform the CountByLeaveCategory query
			return Attendence::QueryCount(
				QQ::Equal(QQN::Attendence()->LeaveCategory, $intLeaveCategory)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Attendence
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Attendence::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `attendence` (
							`staff`,
							`in_time`,
							`out_time`,
							`day_category`,
							`note`,
							`leave_category`,
							`presenty`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intStaff) . ',
							' . $objDatabase->SqlVariable($this->dttInTime) . ',
							' . $objDatabase->SqlVariable($this->dttOutTime) . ',
							' . $objDatabase->SqlVariable($this->intDayCategory) . ',
							' . $objDatabase->SqlVariable($this->strNote) . ',
							' . $objDatabase->SqlVariable($this->intLeaveCategory) . ',
							' . $objDatabase->SqlVariable($this->blnPresenty) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdattendence = $objDatabase->InsertId('attendence', 'idattendence');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`attendence`
						SET
							`staff` = ' . $objDatabase->SqlVariable($this->intStaff) . ',
							`in_time` = ' . $objDatabase->SqlVariable($this->dttInTime) . ',
							`out_time` = ' . $objDatabase->SqlVariable($this->dttOutTime) . ',
							`day_category` = ' . $objDatabase->SqlVariable($this->intDayCategory) . ',
							`note` = ' . $objDatabase->SqlVariable($this->strNote) . ',
							`leave_category` = ' . $objDatabase->SqlVariable($this->intLeaveCategory) . ',
							`presenty` = ' . $objDatabase->SqlVariable($this->blnPresenty) . '
						WHERE
							`idattendence` = ' . $objDatabase->SqlVariable($this->intIdattendence) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Attendence
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdattendence)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Attendence with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Attendence::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`attendence`
				WHERE
					`idattendence` = ' . $objDatabase->SqlVariable($this->intIdattendence) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Attendence ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Attendence', $this->intIdattendence);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Attendences
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Attendence::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`attendence`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate attendence table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Attendence::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `attendence`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Attendence from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Attendence object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Attendence::Load($this->intIdattendence);

			// Update $this's local variables to match
			$this->Staff = $objReloaded->Staff;
			$this->dttInTime = $objReloaded->dttInTime;
			$this->dttOutTime = $objReloaded->dttOutTime;
			$this->DayCategory = $objReloaded->DayCategory;
			$this->strNote = $objReloaded->strNote;
			$this->LeaveCategory = $objReloaded->LeaveCategory;
			$this->blnPresenty = $objReloaded->blnPresenty;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idattendence':
					/**
					 * Gets the value for intIdattendence (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdattendence;

				case 'Staff':
					/**
					 * Gets the value for intStaff (Not Null)
					 * @return integer
					 */
					return $this->intStaff;

				case 'InTime':
					/**
					 * Gets the value for dttInTime 
					 * @return QDateTime
					 */
					return $this->dttInTime;

				case 'OutTime':
					/**
					 * Gets the value for dttOutTime 
					 * @return QDateTime
					 */
					return $this->dttOutTime;

				case 'DayCategory':
					/**
					 * Gets the value for intDayCategory 
					 * @return integer
					 */
					return $this->intDayCategory;

				case 'Note':
					/**
					 * Gets the value for strNote 
					 * @return string
					 */
					return $this->strNote;

				case 'LeaveCategory':
					/**
					 * Gets the value for intLeaveCategory 
					 * @return integer
					 */
					return $this->intLeaveCategory;

				case 'Presenty':
					/**
					 * Gets the value for blnPresenty 
					 * @return boolean
					 */
					return $this->blnPresenty;


				///////////////////
				// Member Objects
				///////////////////
				case 'StaffObject':
					/**
					 * Gets the value for the Login object referenced by intStaff (Not Null)
					 * @return Login
					 */
					try {
						if ((!$this->objStaffObject) && (!is_null($this->intStaff)))
							$this->objStaffObject = Login::Load($this->intStaff);
						return $this->objStaffObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DayCategoryObject':
					/**
					 * Gets the value for the DayCategory object referenced by intDayCategory 
					 * @return DayCategory
					 */
					try {
						if ((!$this->objDayCategoryObject) && (!is_null($this->intDayCategory)))
							$this->objDayCategoryObject = DayCategory::Load($this->intDayCategory);
						return $this->objDayCategoryObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeaveCategoryObject':
					/**
					 * Gets the value for the Ledger object referenced by intLeaveCategory 
					 * @return Ledger
					 */
					try {
						if ((!$this->objLeaveCategoryObject) && (!is_null($this->intLeaveCategory)))
							$this->objLeaveCategoryObject = Ledger::Load($this->intLeaveCategory);
						return $this->objLeaveCategoryObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Staff':
					/**
					 * Sets the value for intStaff (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objStaffObject = null;
						return ($this->intStaff = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'InTime':
					/**
					 * Sets the value for dttInTime 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttInTime = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'OutTime':
					/**
					 * Sets the value for dttOutTime 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttOutTime = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DayCategory':
					/**
					 * Sets the value for intDayCategory 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDayCategoryObject = null;
						return ($this->intDayCategory = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Note':
					/**
					 * Sets the value for strNote 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strNote = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeaveCategory':
					/**
					 * Sets the value for intLeaveCategory 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objLeaveCategoryObject = null;
						return ($this->intLeaveCategory = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Presenty':
					/**
					 * Sets the value for blnPresenty 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnPresenty = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'StaffObject':
					/**
					 * Sets the value for the Login object referenced by intStaff (Not Null)
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intStaff = null;
						$this->objStaffObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved StaffObject for this Attendence');

						// Update Local Member Variables
						$this->objStaffObject = $mixValue;
						$this->intStaff = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DayCategoryObject':
					/**
					 * Sets the value for the DayCategory object referenced by intDayCategory 
					 * @param DayCategory $mixValue
					 * @return DayCategory
					 */
					if (is_null($mixValue)) {
						$this->intDayCategory = null;
						$this->objDayCategoryObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a DayCategory object
						try {
							$mixValue = QType::Cast($mixValue, 'DayCategory');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED DayCategory object
						if (is_null($mixValue->IddayCategory))
							throw new QCallerException('Unable to set an unsaved DayCategoryObject for this Attendence');

						// Update Local Member Variables
						$this->objDayCategoryObject = $mixValue;
						$this->intDayCategory = $mixValue->IddayCategory;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'LeaveCategoryObject':
					/**
					 * Sets the value for the Ledger object referenced by intLeaveCategory 
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intLeaveCategory = null;
						$this->objLeaveCategoryObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved LeaveCategoryObject for this Attendence');

						// Update Local Member Variables
						$this->objLeaveCategoryObject = $mixValue;
						$this->intLeaveCategory = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "attendence";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Attendence::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Attendence"><sequence>';
			$strToReturn .= '<element name="Idattendence" type="xsd:int"/>';
			$strToReturn .= '<element name="StaffObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="InTime" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="OutTime" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="DayCategoryObject" type="xsd1:DayCategory"/>';
			$strToReturn .= '<element name="Note" type="xsd:string"/>';
			$strToReturn .= '<element name="LeaveCategoryObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="Presenty" type="xsd:boolean"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Attendence', $strComplexTypeArray)) {
				$strComplexTypeArray['Attendence'] = Attendence::GetSoapComplexTypeXml();
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				DayCategory::AlterSoapComplexTypeArray($strComplexTypeArray);
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Attendence::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Attendence();
			if (property_exists($objSoapObject, 'Idattendence'))
				$objToReturn->intIdattendence = $objSoapObject->Idattendence;
			if ((property_exists($objSoapObject, 'StaffObject')) &&
				($objSoapObject->StaffObject))
				$objToReturn->StaffObject = Login::GetObjectFromSoapObject($objSoapObject->StaffObject);
			if (property_exists($objSoapObject, 'InTime'))
				$objToReturn->dttInTime = new QDateTime($objSoapObject->InTime);
			if (property_exists($objSoapObject, 'OutTime'))
				$objToReturn->dttOutTime = new QDateTime($objSoapObject->OutTime);
			if ((property_exists($objSoapObject, 'DayCategoryObject')) &&
				($objSoapObject->DayCategoryObject))
				$objToReturn->DayCategoryObject = DayCategory::GetObjectFromSoapObject($objSoapObject->DayCategoryObject);
			if (property_exists($objSoapObject, 'Note'))
				$objToReturn->strNote = $objSoapObject->Note;
			if ((property_exists($objSoapObject, 'LeaveCategoryObject')) &&
				($objSoapObject->LeaveCategoryObject))
				$objToReturn->LeaveCategoryObject = Ledger::GetObjectFromSoapObject($objSoapObject->LeaveCategoryObject);
			if (property_exists($objSoapObject, 'Presenty'))
				$objToReturn->blnPresenty = $objSoapObject->Presenty;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Attendence::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objStaffObject)
				$objObject->objStaffObject = Login::GetSoapObjectFromObject($objObject->objStaffObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intStaff = null;
			if ($objObject->dttInTime)
				$objObject->dttInTime = $objObject->dttInTime->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttOutTime)
				$objObject->dttOutTime = $objObject->dttOutTime->qFormat(QDateTime::FormatSoap);
			if ($objObject->objDayCategoryObject)
				$objObject->objDayCategoryObject = DayCategory::GetSoapObjectFromObject($objObject->objDayCategoryObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDayCategory = null;
			if ($objObject->objLeaveCategoryObject)
				$objObject->objLeaveCategoryObject = Ledger::GetSoapObjectFromObject($objObject->objLeaveCategoryObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intLeaveCategory = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idattendence'] = $this->intIdattendence;
			$iArray['Staff'] = $this->intStaff;
			$iArray['InTime'] = $this->dttInTime;
			$iArray['OutTime'] = $this->dttOutTime;
			$iArray['DayCategory'] = $this->intDayCategory;
			$iArray['Note'] = $this->strNote;
			$iArray['LeaveCategory'] = $this->intLeaveCategory;
			$iArray['Presenty'] = $this->blnPresenty;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdattendence ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idattendence
     * @property-read QQNode $Staff
     * @property-read QQNodeLogin $StaffObject
     * @property-read QQNode $InTime
     * @property-read QQNode $OutTime
     * @property-read QQNode $DayCategory
     * @property-read QQNodeDayCategory $DayCategoryObject
     * @property-read QQNode $Note
     * @property-read QQNode $LeaveCategory
     * @property-read QQNodeLedger $LeaveCategoryObject
     * @property-read QQNode $Presenty
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeAttendence extends QQNode {
		protected $strTableName = 'attendence';
		protected $strPrimaryKey = 'idattendence';
		protected $strClassName = 'Attendence';
		public function __get($strName) {
			switch ($strName) {
				case 'Idattendence':
					return new QQNode('idattendence', 'Idattendence', 'Integer', $this);
				case 'Staff':
					return new QQNode('staff', 'Staff', 'Integer', $this);
				case 'StaffObject':
					return new QQNodeLogin('staff', 'StaffObject', 'Integer', $this);
				case 'InTime':
					return new QQNode('in_time', 'InTime', 'DateTime', $this);
				case 'OutTime':
					return new QQNode('out_time', 'OutTime', 'DateTime', $this);
				case 'DayCategory':
					return new QQNode('day_category', 'DayCategory', 'Integer', $this);
				case 'DayCategoryObject':
					return new QQNodeDayCategory('day_category', 'DayCategoryObject', 'Integer', $this);
				case 'Note':
					return new QQNode('note', 'Note', 'Blob', $this);
				case 'LeaveCategory':
					return new QQNode('leave_category', 'LeaveCategory', 'Integer', $this);
				case 'LeaveCategoryObject':
					return new QQNodeLedger('leave_category', 'LeaveCategoryObject', 'Integer', $this);
				case 'Presenty':
					return new QQNode('presenty', 'Presenty', 'Bit', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idattendence', 'Idattendence', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idattendence
     * @property-read QQNode $Staff
     * @property-read QQNodeLogin $StaffObject
     * @property-read QQNode $InTime
     * @property-read QQNode $OutTime
     * @property-read QQNode $DayCategory
     * @property-read QQNodeDayCategory $DayCategoryObject
     * @property-read QQNode $Note
     * @property-read QQNode $LeaveCategory
     * @property-read QQNodeLedger $LeaveCategoryObject
     * @property-read QQNode $Presenty
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeAttendence extends QQReverseReferenceNode {
		protected $strTableName = 'attendence';
		protected $strPrimaryKey = 'idattendence';
		protected $strClassName = 'Attendence';
		public function __get($strName) {
			switch ($strName) {
				case 'Idattendence':
					return new QQNode('idattendence', 'Idattendence', 'integer', $this);
				case 'Staff':
					return new QQNode('staff', 'Staff', 'integer', $this);
				case 'StaffObject':
					return new QQNodeLogin('staff', 'StaffObject', 'integer', $this);
				case 'InTime':
					return new QQNode('in_time', 'InTime', 'QDateTime', $this);
				case 'OutTime':
					return new QQNode('out_time', 'OutTime', 'QDateTime', $this);
				case 'DayCategory':
					return new QQNode('day_category', 'DayCategory', 'integer', $this);
				case 'DayCategoryObject':
					return new QQNodeDayCategory('day_category', 'DayCategoryObject', 'integer', $this);
				case 'Note':
					return new QQNode('note', 'Note', 'string', $this);
				case 'LeaveCategory':
					return new QQNode('leave_category', 'LeaveCategory', 'integer', $this);
				case 'LeaveCategoryObject':
					return new QQNodeLedger('leave_category', 'LeaveCategoryObject', 'integer', $this);
				case 'Presenty':
					return new QQNode('presenty', 'Presenty', 'boolean', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idattendence', 'Idattendence', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
