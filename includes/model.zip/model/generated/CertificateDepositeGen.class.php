<?php
	/**
	 * The abstract CertificateDepositeGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the CertificateDeposite subclass which
	 * extends this CertificateDepositeGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the CertificateDeposite class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdcertificateDeposite the value for intIdcertificateDeposite (Read-Only PK)
	 * @property integer $Student the value for intStudent (Not Null)
	 * @property string $PrnNo the value for strPrnNo 
	 * @property string $CertificateCode the value for strCertificateCode 
	 * @property integer $CertificateName the value for intCertificateName 
	 * @property boolean $Deposited the value for blnDeposited 
	 * @property QDateTime $DepositedDate the value for dttDepositedDate 
	 * @property boolean $Verify the value for blnVerify 
	 * @property integer $VerifyBy the value for intVerifyBy 
	 * @property string $VerifyDate the value for strVerifyDate 
	 * @property QDateTime $ReturnDate the value for dttReturnDate 
	 * @property integer $ReturnBy the value for intReturnBy 
	 * @property Ledger $StudentObject the value for the Ledger object referenced by intStudent (Not Null)
	 * @property Ledger $CertificateNameObject the value for the Ledger object referenced by intCertificateName 
	 * @property Login $VerifyByObject the value for the Login object referenced by intVerifyBy 
	 * @property Login $ReturnByObject the value for the Login object referenced by intReturnBy 
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class CertificateDepositeGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column certificate_deposite.idcertificate_deposite
		 * @var integer intIdcertificateDeposite
		 */
		protected $intIdcertificateDeposite;
		const IdcertificateDepositeDefault = null;


		/**
		 * Protected member variable that maps to the database column certificate_deposite.student
		 * @var integer intStudent
		 */
		protected $intStudent;
		const StudentDefault = null;


		/**
		 * Protected member variable that maps to the database column certificate_deposite.prn_no
		 * @var string strPrnNo
		 */
		protected $strPrnNo;
		const PrnNoMaxLength = 45;
		const PrnNoDefault = null;


		/**
		 * Protected member variable that maps to the database column certificate_deposite.certificate_code
		 * @var string strCertificateCode
		 */
		protected $strCertificateCode;
		const CertificateCodeMaxLength = 45;
		const CertificateCodeDefault = null;


		/**
		 * Protected member variable that maps to the database column certificate_deposite.certificate_name
		 * @var integer intCertificateName
		 */
		protected $intCertificateName;
		const CertificateNameDefault = null;


		/**
		 * Protected member variable that maps to the database column certificate_deposite.deposited
		 * @var boolean blnDeposited
		 */
		protected $blnDeposited;
		const DepositedDefault = null;


		/**
		 * Protected member variable that maps to the database column certificate_deposite.deposited_date
		 * @var QDateTime dttDepositedDate
		 */
		protected $dttDepositedDate;
		const DepositedDateDefault = null;


		/**
		 * Protected member variable that maps to the database column certificate_deposite.verify
		 * @var boolean blnVerify
		 */
		protected $blnVerify;
		const VerifyDefault = null;


		/**
		 * Protected member variable that maps to the database column certificate_deposite.verify_by
		 * @var integer intVerifyBy
		 */
		protected $intVerifyBy;
		const VerifyByDefault = null;


		/**
		 * Protected member variable that maps to the database column certificate_deposite.verify_date
		 * @var string strVerifyDate
		 */
		protected $strVerifyDate;
		const VerifyDateMaxLength = 45;
		const VerifyDateDefault = null;


		/**
		 * Protected member variable that maps to the database column certificate_deposite.return_date
		 * @var QDateTime dttReturnDate
		 */
		protected $dttReturnDate;
		const ReturnDateDefault = null;


		/**
		 * Protected member variable that maps to the database column certificate_deposite.return_by
		 * @var integer intReturnBy
		 */
		protected $intReturnBy;
		const ReturnByDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column certificate_deposite.student.
		 *
		 * NOTE: Always use the StudentObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objStudentObject
		 */
		protected $objStudentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column certificate_deposite.certificate_name.
		 *
		 * NOTE: Always use the CertificateNameObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objCertificateNameObject
		 */
		protected $objCertificateNameObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column certificate_deposite.verify_by.
		 *
		 * NOTE: Always use the VerifyByObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objVerifyByObject
		 */
		protected $objVerifyByObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column certificate_deposite.return_by.
		 *
		 * NOTE: Always use the ReturnByObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objReturnByObject
		 */
		protected $objReturnByObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdcertificateDeposite = CertificateDeposite::IdcertificateDepositeDefault;
			$this->intStudent = CertificateDeposite::StudentDefault;
			$this->strPrnNo = CertificateDeposite::PrnNoDefault;
			$this->strCertificateCode = CertificateDeposite::CertificateCodeDefault;
			$this->intCertificateName = CertificateDeposite::CertificateNameDefault;
			$this->blnDeposited = CertificateDeposite::DepositedDefault;
			$this->dttDepositedDate = (CertificateDeposite::DepositedDateDefault === null)?null:new QDateTime(CertificateDeposite::DepositedDateDefault);
			$this->blnVerify = CertificateDeposite::VerifyDefault;
			$this->intVerifyBy = CertificateDeposite::VerifyByDefault;
			$this->strVerifyDate = CertificateDeposite::VerifyDateDefault;
			$this->dttReturnDate = (CertificateDeposite::ReturnDateDefault === null)?null:new QDateTime(CertificateDeposite::ReturnDateDefault);
			$this->intReturnBy = CertificateDeposite::ReturnByDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a CertificateDeposite from PK Info
		 * @param integer $intIdcertificateDeposite
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return CertificateDeposite
		 */
		public static function Load($intIdcertificateDeposite, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'CertificateDeposite', $intIdcertificateDeposite);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = CertificateDeposite::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::CertificateDeposite()->IdcertificateDeposite, $intIdcertificateDeposite)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all CertificateDeposites
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return CertificateDeposite[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call CertificateDeposite::QueryArray to perform the LoadAll query
			try {
				return CertificateDeposite::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all CertificateDeposites
		 * @return int
		 */
		public static function CountAll() {
			// Call CertificateDeposite::QueryCount to perform the CountAll query
			return CertificateDeposite::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = CertificateDeposite::GetDatabase();

			// Create/Build out the QueryBuilder object with CertificateDeposite-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'certificate_deposite');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				CertificateDeposite::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('certificate_deposite');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single CertificateDeposite object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return CertificateDeposite the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = CertificateDeposite::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new CertificateDeposite object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = CertificateDeposite::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return CertificateDeposite::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of CertificateDeposite objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return CertificateDeposite[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = CertificateDeposite::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return CertificateDeposite::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = CertificateDeposite::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of CertificateDeposite objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = CertificateDeposite::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = CertificateDeposite::GetDatabase();

			$strQuery = CertificateDeposite::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/certificatedeposite', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = CertificateDeposite::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this CertificateDeposite
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'certificate_deposite';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idcertificate_deposite', $strAliasPrefix . 'idcertificate_deposite');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idcertificate_deposite', $strAliasPrefix . 'idcertificate_deposite');
			    $objBuilder->AddSelectItem($strTableName, 'student', $strAliasPrefix . 'student');
			    $objBuilder->AddSelectItem($strTableName, 'prn_no', $strAliasPrefix . 'prn_no');
			    $objBuilder->AddSelectItem($strTableName, 'certificate_code', $strAliasPrefix . 'certificate_code');
			    $objBuilder->AddSelectItem($strTableName, 'certificate_name', $strAliasPrefix . 'certificate_name');
			    $objBuilder->AddSelectItem($strTableName, 'deposited', $strAliasPrefix . 'deposited');
			    $objBuilder->AddSelectItem($strTableName, 'deposited_date', $strAliasPrefix . 'deposited_date');
			    $objBuilder->AddSelectItem($strTableName, 'verify', $strAliasPrefix . 'verify');
			    $objBuilder->AddSelectItem($strTableName, 'verify_by', $strAliasPrefix . 'verify_by');
			    $objBuilder->AddSelectItem($strTableName, 'verify_date', $strAliasPrefix . 'verify_date');
			    $objBuilder->AddSelectItem($strTableName, 'return_date', $strAliasPrefix . 'return_date');
			    $objBuilder->AddSelectItem($strTableName, 'return_by', $strAliasPrefix . 'return_by');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a CertificateDeposite from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this CertificateDeposite::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return CertificateDeposite
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the CertificateDeposite object
			$objToReturn = new CertificateDeposite();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idcertificate_deposite';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdcertificateDeposite = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'student';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intStudent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'prn_no';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strPrnNo = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'certificate_code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCertificateCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'certificate_name';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCertificateName = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'deposited';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnDeposited = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'deposited_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDepositedDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'verify';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnVerify = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'verify_by';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intVerifyBy = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'verify_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strVerifyDate = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'return_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttReturnDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'return_by';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intReturnBy = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdcertificateDeposite != $objPreviousItem->IdcertificateDeposite) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'certificate_deposite__';

			// Check for StudentObject Early Binding
			$strAlias = $strAliasPrefix . 'student__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objStudentObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'student__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CertificateNameObject Early Binding
			$strAlias = $strAliasPrefix . 'certificate_name__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCertificateNameObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'certificate_name__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for VerifyByObject Early Binding
			$strAlias = $strAliasPrefix . 'verify_by__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objVerifyByObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'verify_by__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ReturnByObject Early Binding
			$strAlias = $strAliasPrefix . 'return_by__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objReturnByObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'return_by__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of CertificateDeposites from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return CertificateDeposite[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = CertificateDeposite::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = CertificateDeposite::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single CertificateDeposite object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return CertificateDeposite next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return CertificateDeposite::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single CertificateDeposite object,
		 * by IdcertificateDeposite Index(es)
		 * @param integer $intIdcertificateDeposite
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return CertificateDeposite
		*/
		public static function LoadByIdcertificateDeposite($intIdcertificateDeposite, $objOptionalClauses = null) {
			return CertificateDeposite::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::CertificateDeposite()->IdcertificateDeposite, $intIdcertificateDeposite)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of CertificateDeposite objects,
		 * by Student Index(es)
		 * @param integer $intStudent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return CertificateDeposite[]
		*/
		public static function LoadArrayByStudent($intStudent, $objOptionalClauses = null) {
			// Call CertificateDeposite::QueryArray to perform the LoadArrayByStudent query
			try {
				return CertificateDeposite::QueryArray(
					QQ::Equal(QQN::CertificateDeposite()->Student, $intStudent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count CertificateDeposites
		 * by Student Index(es)
		 * @param integer $intStudent
		 * @return int
		*/
		public static function CountByStudent($intStudent) {
			// Call CertificateDeposite::QueryCount to perform the CountByStudent query
			return CertificateDeposite::QueryCount(
				QQ::Equal(QQN::CertificateDeposite()->Student, $intStudent)
			);
		}

		/**
		 * Load an array of CertificateDeposite objects,
		 * by CertificateName Index(es)
		 * @param integer $intCertificateName
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return CertificateDeposite[]
		*/
		public static function LoadArrayByCertificateName($intCertificateName, $objOptionalClauses = null) {
			// Call CertificateDeposite::QueryArray to perform the LoadArrayByCertificateName query
			try {
				return CertificateDeposite::QueryArray(
					QQ::Equal(QQN::CertificateDeposite()->CertificateName, $intCertificateName),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count CertificateDeposites
		 * by CertificateName Index(es)
		 * @param integer $intCertificateName
		 * @return int
		*/
		public static function CountByCertificateName($intCertificateName) {
			// Call CertificateDeposite::QueryCount to perform the CountByCertificateName query
			return CertificateDeposite::QueryCount(
				QQ::Equal(QQN::CertificateDeposite()->CertificateName, $intCertificateName)
			);
		}

		/**
		 * Load an array of CertificateDeposite objects,
		 * by VerifyBy Index(es)
		 * @param integer $intVerifyBy
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return CertificateDeposite[]
		*/
		public static function LoadArrayByVerifyBy($intVerifyBy, $objOptionalClauses = null) {
			// Call CertificateDeposite::QueryArray to perform the LoadArrayByVerifyBy query
			try {
				return CertificateDeposite::QueryArray(
					QQ::Equal(QQN::CertificateDeposite()->VerifyBy, $intVerifyBy),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count CertificateDeposites
		 * by VerifyBy Index(es)
		 * @param integer $intVerifyBy
		 * @return int
		*/
		public static function CountByVerifyBy($intVerifyBy) {
			// Call CertificateDeposite::QueryCount to perform the CountByVerifyBy query
			return CertificateDeposite::QueryCount(
				QQ::Equal(QQN::CertificateDeposite()->VerifyBy, $intVerifyBy)
			);
		}

		/**
		 * Load an array of CertificateDeposite objects,
		 * by ReturnBy Index(es)
		 * @param integer $intReturnBy
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return CertificateDeposite[]
		*/
		public static function LoadArrayByReturnBy($intReturnBy, $objOptionalClauses = null) {
			// Call CertificateDeposite::QueryArray to perform the LoadArrayByReturnBy query
			try {
				return CertificateDeposite::QueryArray(
					QQ::Equal(QQN::CertificateDeposite()->ReturnBy, $intReturnBy),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count CertificateDeposites
		 * by ReturnBy Index(es)
		 * @param integer $intReturnBy
		 * @return int
		*/
		public static function CountByReturnBy($intReturnBy) {
			// Call CertificateDeposite::QueryCount to perform the CountByReturnBy query
			return CertificateDeposite::QueryCount(
				QQ::Equal(QQN::CertificateDeposite()->ReturnBy, $intReturnBy)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this CertificateDeposite
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = CertificateDeposite::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `certificate_deposite` (
							`student`,
							`prn_no`,
							`certificate_code`,
							`certificate_name`,
							`deposited`,
							`deposited_date`,
							`verify`,
							`verify_by`,
							`verify_date`,
							`return_date`,
							`return_by`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intStudent) . ',
							' . $objDatabase->SqlVariable($this->strPrnNo) . ',
							' . $objDatabase->SqlVariable($this->strCertificateCode) . ',
							' . $objDatabase->SqlVariable($this->intCertificateName) . ',
							' . $objDatabase->SqlVariable($this->blnDeposited) . ',
							' . $objDatabase->SqlVariable($this->dttDepositedDate) . ',
							' . $objDatabase->SqlVariable($this->blnVerify) . ',
							' . $objDatabase->SqlVariable($this->intVerifyBy) . ',
							' . $objDatabase->SqlVariable($this->strVerifyDate) . ',
							' . $objDatabase->SqlVariable($this->dttReturnDate) . ',
							' . $objDatabase->SqlVariable($this->intReturnBy) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdcertificateDeposite = $objDatabase->InsertId('certificate_deposite', 'idcertificate_deposite');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`certificate_deposite`
						SET
							`student` = ' . $objDatabase->SqlVariable($this->intStudent) . ',
							`prn_no` = ' . $objDatabase->SqlVariable($this->strPrnNo) . ',
							`certificate_code` = ' . $objDatabase->SqlVariable($this->strCertificateCode) . ',
							`certificate_name` = ' . $objDatabase->SqlVariable($this->intCertificateName) . ',
							`deposited` = ' . $objDatabase->SqlVariable($this->blnDeposited) . ',
							`deposited_date` = ' . $objDatabase->SqlVariable($this->dttDepositedDate) . ',
							`verify` = ' . $objDatabase->SqlVariable($this->blnVerify) . ',
							`verify_by` = ' . $objDatabase->SqlVariable($this->intVerifyBy) . ',
							`verify_date` = ' . $objDatabase->SqlVariable($this->strVerifyDate) . ',
							`return_date` = ' . $objDatabase->SqlVariable($this->dttReturnDate) . ',
							`return_by` = ' . $objDatabase->SqlVariable($this->intReturnBy) . '
						WHERE
							`idcertificate_deposite` = ' . $objDatabase->SqlVariable($this->intIdcertificateDeposite) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this CertificateDeposite
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdcertificateDeposite)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this CertificateDeposite with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = CertificateDeposite::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`certificate_deposite`
				WHERE
					`idcertificate_deposite` = ' . $objDatabase->SqlVariable($this->intIdcertificateDeposite) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this CertificateDeposite ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'CertificateDeposite', $this->intIdcertificateDeposite);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all CertificateDeposites
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = CertificateDeposite::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`certificate_deposite`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate certificate_deposite table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = CertificateDeposite::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `certificate_deposite`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this CertificateDeposite from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved CertificateDeposite object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = CertificateDeposite::Load($this->intIdcertificateDeposite);

			// Update $this's local variables to match
			$this->Student = $objReloaded->Student;
			$this->strPrnNo = $objReloaded->strPrnNo;
			$this->strCertificateCode = $objReloaded->strCertificateCode;
			$this->CertificateName = $objReloaded->CertificateName;
			$this->blnDeposited = $objReloaded->blnDeposited;
			$this->dttDepositedDate = $objReloaded->dttDepositedDate;
			$this->blnVerify = $objReloaded->blnVerify;
			$this->VerifyBy = $objReloaded->VerifyBy;
			$this->strVerifyDate = $objReloaded->strVerifyDate;
			$this->dttReturnDate = $objReloaded->dttReturnDate;
			$this->ReturnBy = $objReloaded->ReturnBy;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdcertificateDeposite':
					/**
					 * Gets the value for intIdcertificateDeposite (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdcertificateDeposite;

				case 'Student':
					/**
					 * Gets the value for intStudent (Not Null)
					 * @return integer
					 */
					return $this->intStudent;

				case 'PrnNo':
					/**
					 * Gets the value for strPrnNo 
					 * @return string
					 */
					return $this->strPrnNo;

				case 'CertificateCode':
					/**
					 * Gets the value for strCertificateCode 
					 * @return string
					 */
					return $this->strCertificateCode;

				case 'CertificateName':
					/**
					 * Gets the value for intCertificateName 
					 * @return integer
					 */
					return $this->intCertificateName;

				case 'Deposited':
					/**
					 * Gets the value for blnDeposited 
					 * @return boolean
					 */
					return $this->blnDeposited;

				case 'DepositedDate':
					/**
					 * Gets the value for dttDepositedDate 
					 * @return QDateTime
					 */
					return $this->dttDepositedDate;

				case 'Verify':
					/**
					 * Gets the value for blnVerify 
					 * @return boolean
					 */
					return $this->blnVerify;

				case 'VerifyBy':
					/**
					 * Gets the value for intVerifyBy 
					 * @return integer
					 */
					return $this->intVerifyBy;

				case 'VerifyDate':
					/**
					 * Gets the value for strVerifyDate 
					 * @return string
					 */
					return $this->strVerifyDate;

				case 'ReturnDate':
					/**
					 * Gets the value for dttReturnDate 
					 * @return QDateTime
					 */
					return $this->dttReturnDate;

				case 'ReturnBy':
					/**
					 * Gets the value for intReturnBy 
					 * @return integer
					 */
					return $this->intReturnBy;


				///////////////////
				// Member Objects
				///////////////////
				case 'StudentObject':
					/**
					 * Gets the value for the Ledger object referenced by intStudent (Not Null)
					 * @return Ledger
					 */
					try {
						if ((!$this->objStudentObject) && (!is_null($this->intStudent)))
							$this->objStudentObject = Ledger::Load($this->intStudent);
						return $this->objStudentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CertificateNameObject':
					/**
					 * Gets the value for the Ledger object referenced by intCertificateName 
					 * @return Ledger
					 */
					try {
						if ((!$this->objCertificateNameObject) && (!is_null($this->intCertificateName)))
							$this->objCertificateNameObject = Ledger::Load($this->intCertificateName);
						return $this->objCertificateNameObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'VerifyByObject':
					/**
					 * Gets the value for the Login object referenced by intVerifyBy 
					 * @return Login
					 */
					try {
						if ((!$this->objVerifyByObject) && (!is_null($this->intVerifyBy)))
							$this->objVerifyByObject = Login::Load($this->intVerifyBy);
						return $this->objVerifyByObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ReturnByObject':
					/**
					 * Gets the value for the Login object referenced by intReturnBy 
					 * @return Login
					 */
					try {
						if ((!$this->objReturnByObject) && (!is_null($this->intReturnBy)))
							$this->objReturnByObject = Login::Load($this->intReturnBy);
						return $this->objReturnByObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Student':
					/**
					 * Sets the value for intStudent (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objStudentObject = null;
						return ($this->intStudent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'PrnNo':
					/**
					 * Sets the value for strPrnNo 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strPrnNo = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CertificateCode':
					/**
					 * Sets the value for strCertificateCode 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCertificateCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CertificateName':
					/**
					 * Sets the value for intCertificateName 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCertificateNameObject = null;
						return ($this->intCertificateName = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Deposited':
					/**
					 * Sets the value for blnDeposited 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnDeposited = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DepositedDate':
					/**
					 * Sets the value for dttDepositedDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDepositedDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Verify':
					/**
					 * Sets the value for blnVerify 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnVerify = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'VerifyBy':
					/**
					 * Sets the value for intVerifyBy 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objVerifyByObject = null;
						return ($this->intVerifyBy = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'VerifyDate':
					/**
					 * Sets the value for strVerifyDate 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strVerifyDate = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ReturnDate':
					/**
					 * Sets the value for dttReturnDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttReturnDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ReturnBy':
					/**
					 * Sets the value for intReturnBy 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objReturnByObject = null;
						return ($this->intReturnBy = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'StudentObject':
					/**
					 * Sets the value for the Ledger object referenced by intStudent (Not Null)
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intStudent = null;
						$this->objStudentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved StudentObject for this CertificateDeposite');

						// Update Local Member Variables
						$this->objStudentObject = $mixValue;
						$this->intStudent = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CertificateNameObject':
					/**
					 * Sets the value for the Ledger object referenced by intCertificateName 
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intCertificateName = null;
						$this->objCertificateNameObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved CertificateNameObject for this CertificateDeposite');

						// Update Local Member Variables
						$this->objCertificateNameObject = $mixValue;
						$this->intCertificateName = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'VerifyByObject':
					/**
					 * Sets the value for the Login object referenced by intVerifyBy 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intVerifyBy = null;
						$this->objVerifyByObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved VerifyByObject for this CertificateDeposite');

						// Update Local Member Variables
						$this->objVerifyByObject = $mixValue;
						$this->intVerifyBy = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ReturnByObject':
					/**
					 * Sets the value for the Login object referenced by intReturnBy 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intReturnBy = null;
						$this->objReturnByObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved ReturnByObject for this CertificateDeposite');

						// Update Local Member Variables
						$this->objReturnByObject = $mixValue;
						$this->intReturnBy = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "certificate_deposite";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[CertificateDeposite::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="CertificateDeposite"><sequence>';
			$strToReturn .= '<element name="IdcertificateDeposite" type="xsd:int"/>';
			$strToReturn .= '<element name="StudentObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="PrnNo" type="xsd:string"/>';
			$strToReturn .= '<element name="CertificateCode" type="xsd:string"/>';
			$strToReturn .= '<element name="CertificateNameObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="Deposited" type="xsd:boolean"/>';
			$strToReturn .= '<element name="DepositedDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Verify" type="xsd:boolean"/>';
			$strToReturn .= '<element name="VerifyByObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="VerifyDate" type="xsd:string"/>';
			$strToReturn .= '<element name="ReturnDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="ReturnByObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('CertificateDeposite', $strComplexTypeArray)) {
				$strComplexTypeArray['CertificateDeposite'] = CertificateDeposite::GetSoapComplexTypeXml();
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, CertificateDeposite::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new CertificateDeposite();
			if (property_exists($objSoapObject, 'IdcertificateDeposite'))
				$objToReturn->intIdcertificateDeposite = $objSoapObject->IdcertificateDeposite;
			if ((property_exists($objSoapObject, 'StudentObject')) &&
				($objSoapObject->StudentObject))
				$objToReturn->StudentObject = Ledger::GetObjectFromSoapObject($objSoapObject->StudentObject);
			if (property_exists($objSoapObject, 'PrnNo'))
				$objToReturn->strPrnNo = $objSoapObject->PrnNo;
			if (property_exists($objSoapObject, 'CertificateCode'))
				$objToReturn->strCertificateCode = $objSoapObject->CertificateCode;
			if ((property_exists($objSoapObject, 'CertificateNameObject')) &&
				($objSoapObject->CertificateNameObject))
				$objToReturn->CertificateNameObject = Ledger::GetObjectFromSoapObject($objSoapObject->CertificateNameObject);
			if (property_exists($objSoapObject, 'Deposited'))
				$objToReturn->blnDeposited = $objSoapObject->Deposited;
			if (property_exists($objSoapObject, 'DepositedDate'))
				$objToReturn->dttDepositedDate = new QDateTime($objSoapObject->DepositedDate);
			if (property_exists($objSoapObject, 'Verify'))
				$objToReturn->blnVerify = $objSoapObject->Verify;
			if ((property_exists($objSoapObject, 'VerifyByObject')) &&
				($objSoapObject->VerifyByObject))
				$objToReturn->VerifyByObject = Login::GetObjectFromSoapObject($objSoapObject->VerifyByObject);
			if (property_exists($objSoapObject, 'VerifyDate'))
				$objToReturn->strVerifyDate = $objSoapObject->VerifyDate;
			if (property_exists($objSoapObject, 'ReturnDate'))
				$objToReturn->dttReturnDate = new QDateTime($objSoapObject->ReturnDate);
			if ((property_exists($objSoapObject, 'ReturnByObject')) &&
				($objSoapObject->ReturnByObject))
				$objToReturn->ReturnByObject = Login::GetObjectFromSoapObject($objSoapObject->ReturnByObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, CertificateDeposite::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objStudentObject)
				$objObject->objStudentObject = Ledger::GetSoapObjectFromObject($objObject->objStudentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intStudent = null;
			if ($objObject->objCertificateNameObject)
				$objObject->objCertificateNameObject = Ledger::GetSoapObjectFromObject($objObject->objCertificateNameObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCertificateName = null;
			if ($objObject->dttDepositedDate)
				$objObject->dttDepositedDate = $objObject->dttDepositedDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objVerifyByObject)
				$objObject->objVerifyByObject = Login::GetSoapObjectFromObject($objObject->objVerifyByObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intVerifyBy = null;
			if ($objObject->dttReturnDate)
				$objObject->dttReturnDate = $objObject->dttReturnDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objReturnByObject)
				$objObject->objReturnByObject = Login::GetSoapObjectFromObject($objObject->objReturnByObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intReturnBy = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdcertificateDeposite'] = $this->intIdcertificateDeposite;
			$iArray['Student'] = $this->intStudent;
			$iArray['PrnNo'] = $this->strPrnNo;
			$iArray['CertificateCode'] = $this->strCertificateCode;
			$iArray['CertificateName'] = $this->intCertificateName;
			$iArray['Deposited'] = $this->blnDeposited;
			$iArray['DepositedDate'] = $this->dttDepositedDate;
			$iArray['Verify'] = $this->blnVerify;
			$iArray['VerifyBy'] = $this->intVerifyBy;
			$iArray['VerifyDate'] = $this->strVerifyDate;
			$iArray['ReturnDate'] = $this->dttReturnDate;
			$iArray['ReturnBy'] = $this->intReturnBy;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdcertificateDeposite ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdcertificateDeposite
     * @property-read QQNode $Student
     * @property-read QQNodeLedger $StudentObject
     * @property-read QQNode $PrnNo
     * @property-read QQNode $CertificateCode
     * @property-read QQNode $CertificateName
     * @property-read QQNodeLedger $CertificateNameObject
     * @property-read QQNode $Deposited
     * @property-read QQNode $DepositedDate
     * @property-read QQNode $Verify
     * @property-read QQNode $VerifyBy
     * @property-read QQNodeLogin $VerifyByObject
     * @property-read QQNode $VerifyDate
     * @property-read QQNode $ReturnDate
     * @property-read QQNode $ReturnBy
     * @property-read QQNodeLogin $ReturnByObject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeCertificateDeposite extends QQNode {
		protected $strTableName = 'certificate_deposite';
		protected $strPrimaryKey = 'idcertificate_deposite';
		protected $strClassName = 'CertificateDeposite';
		public function __get($strName) {
			switch ($strName) {
				case 'IdcertificateDeposite':
					return new QQNode('idcertificate_deposite', 'IdcertificateDeposite', 'Integer', $this);
				case 'Student':
					return new QQNode('student', 'Student', 'Integer', $this);
				case 'StudentObject':
					return new QQNodeLedger('student', 'StudentObject', 'Integer', $this);
				case 'PrnNo':
					return new QQNode('prn_no', 'PrnNo', 'VarChar', $this);
				case 'CertificateCode':
					return new QQNode('certificate_code', 'CertificateCode', 'VarChar', $this);
				case 'CertificateName':
					return new QQNode('certificate_name', 'CertificateName', 'Integer', $this);
				case 'CertificateNameObject':
					return new QQNodeLedger('certificate_name', 'CertificateNameObject', 'Integer', $this);
				case 'Deposited':
					return new QQNode('deposited', 'Deposited', 'Bit', $this);
				case 'DepositedDate':
					return new QQNode('deposited_date', 'DepositedDate', 'DateTime', $this);
				case 'Verify':
					return new QQNode('verify', 'Verify', 'Bit', $this);
				case 'VerifyBy':
					return new QQNode('verify_by', 'VerifyBy', 'Integer', $this);
				case 'VerifyByObject':
					return new QQNodeLogin('verify_by', 'VerifyByObject', 'Integer', $this);
				case 'VerifyDate':
					return new QQNode('verify_date', 'VerifyDate', 'VarChar', $this);
				case 'ReturnDate':
					return new QQNode('return_date', 'ReturnDate', 'DateTime', $this);
				case 'ReturnBy':
					return new QQNode('return_by', 'ReturnBy', 'Integer', $this);
				case 'ReturnByObject':
					return new QQNodeLogin('return_by', 'ReturnByObject', 'Integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idcertificate_deposite', 'IdcertificateDeposite', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdcertificateDeposite
     * @property-read QQNode $Student
     * @property-read QQNodeLedger $StudentObject
     * @property-read QQNode $PrnNo
     * @property-read QQNode $CertificateCode
     * @property-read QQNode $CertificateName
     * @property-read QQNodeLedger $CertificateNameObject
     * @property-read QQNode $Deposited
     * @property-read QQNode $DepositedDate
     * @property-read QQNode $Verify
     * @property-read QQNode $VerifyBy
     * @property-read QQNodeLogin $VerifyByObject
     * @property-read QQNode $VerifyDate
     * @property-read QQNode $ReturnDate
     * @property-read QQNode $ReturnBy
     * @property-read QQNodeLogin $ReturnByObject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeCertificateDeposite extends QQReverseReferenceNode {
		protected $strTableName = 'certificate_deposite';
		protected $strPrimaryKey = 'idcertificate_deposite';
		protected $strClassName = 'CertificateDeposite';
		public function __get($strName) {
			switch ($strName) {
				case 'IdcertificateDeposite':
					return new QQNode('idcertificate_deposite', 'IdcertificateDeposite', 'integer', $this);
				case 'Student':
					return new QQNode('student', 'Student', 'integer', $this);
				case 'StudentObject':
					return new QQNodeLedger('student', 'StudentObject', 'integer', $this);
				case 'PrnNo':
					return new QQNode('prn_no', 'PrnNo', 'string', $this);
				case 'CertificateCode':
					return new QQNode('certificate_code', 'CertificateCode', 'string', $this);
				case 'CertificateName':
					return new QQNode('certificate_name', 'CertificateName', 'integer', $this);
				case 'CertificateNameObject':
					return new QQNodeLedger('certificate_name', 'CertificateNameObject', 'integer', $this);
				case 'Deposited':
					return new QQNode('deposited', 'Deposited', 'boolean', $this);
				case 'DepositedDate':
					return new QQNode('deposited_date', 'DepositedDate', 'QDateTime', $this);
				case 'Verify':
					return new QQNode('verify', 'Verify', 'boolean', $this);
				case 'VerifyBy':
					return new QQNode('verify_by', 'VerifyBy', 'integer', $this);
				case 'VerifyByObject':
					return new QQNodeLogin('verify_by', 'VerifyByObject', 'integer', $this);
				case 'VerifyDate':
					return new QQNode('verify_date', 'VerifyDate', 'string', $this);
				case 'ReturnDate':
					return new QQNode('return_date', 'ReturnDate', 'QDateTime', $this);
				case 'ReturnBy':
					return new QQNode('return_by', 'ReturnBy', 'integer', $this);
				case 'ReturnByObject':
					return new QQNodeLogin('return_by', 'ReturnByObject', 'integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idcertificate_deposite', 'IdcertificateDeposite', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
