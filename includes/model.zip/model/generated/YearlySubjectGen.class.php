<?php
	/**
	 * The abstract YearlySubjectGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the YearlySubject subclass which
	 * extends this YearlySubjectGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the YearlySubject class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdyearlySubject the value for intIdyearlySubject (Read-Only PK)
	 * @property string $Code the value for strCode (Unique)
	 * @property integer $Subject the value for intSubject (Not Null)
	 * @property integer $DeptYear the value for intDeptYear (Not Null)
	 * @property integer $Lab the value for intLab 
	 * @property integer $Tusion the value for intTusion 
	 * @property integer $Practical the value for intPractical 
	 * @property integer $Credit the value for intCredit 
	 * @property integer $CourseGrp the value for intCourseGrp 
	 * @property integer $MinPassing the value for intMinPassing 
	 * @property integer $Parrent the value for intParrent 
	 * @property integer $Seq the value for intSeq 
	 * @property boolean $Visible the value for blnVisible 
	 * @property boolean $GadeModifyLock the value for blnGadeModifyLock 
	 * @property string $Mean the value for strMean 
	 * @property string $Sd the value for strSd 
	 * @property Subject $SubjectObject the value for the Subject object referenced by intSubject (Not Null)
	 * @property DeptYear $DeptYearObject the value for the DeptYear object referenced by intDeptYear (Not Null)
	 * @property CourseGrp $CourseGrpObject the value for the CourseGrp object referenced by intCourseGrp 
	 * @property YearlySubject $ParrentObject the value for the YearlySubject object referenced by intParrent 
	 * @property-read AppliedExam $_AppliedExam the value for the private _objAppliedExam (Read-Only) if set due to an expansion on the applied_exam.yearly_subject reverse relationship
	 * @property-read AppliedExam[] $_AppliedExamArray the value for the private _objAppliedExamArray (Read-Only) if set due to an ExpandAsArray on the applied_exam.yearly_subject reverse relationship
	 * @property-read ApplyGradeImproment $_ApplyGradeImpromentAsSubject the value for the private _objApplyGradeImpromentAsSubject (Read-Only) if set due to an expansion on the apply_grade_improment.subject reverse relationship
	 * @property-read ApplyGradeImproment[] $_ApplyGradeImpromentAsSubjectArray the value for the private _objApplyGradeImpromentAsSubjectArray (Read-Only) if set due to an ExpandAsArray on the apply_grade_improment.subject reverse relationship
	 * @property-read DeptYearEvents $_DeptYearEvents the value for the private _objDeptYearEvents (Read-Only) if set due to an expansion on the dept_year_events.yearly_subject reverse relationship
	 * @property-read DeptYearEvents[] $_DeptYearEventsArray the value for the private _objDeptYearEventsArray (Read-Only) if set due to an ExpandAsArray on the dept_year_events.yearly_subject reverse relationship
	 * @property-read DeptYearExam $_DeptYearExam the value for the private _objDeptYearExam (Read-Only) if set due to an expansion on the dept_year_exam.yearly_subject reverse relationship
	 * @property-read DeptYearExam[] $_DeptYearExamArray the value for the private _objDeptYearExamArray (Read-Only) if set due to an ExpandAsArray on the dept_year_exam.yearly_subject reverse relationship
	 * @property-read EventHasGrade $_EventHasGrade the value for the private _objEventHasGrade (Read-Only) if set due to an expansion on the event_has_grade.yearly_subject reverse relationship
	 * @property-read EventHasGrade[] $_EventHasGradeArray the value for the private _objEventHasGradeArray (Read-Only) if set due to an ExpandAsArray on the event_has_grade.yearly_subject reverse relationship
	 * @property-read GradeCard $_GradeCardAsSubject the value for the private _objGradeCardAsSubject (Read-Only) if set due to an expansion on the grade_card.subject reverse relationship
	 * @property-read GradeCard[] $_GradeCardAsSubjectArray the value for the private _objGradeCardAsSubjectArray (Read-Only) if set due to an ExpandAsArray on the grade_card.subject reverse relationship
	 * @property-read ReEvaluation $_ReEvaluation the value for the private _objReEvaluation (Read-Only) if set due to an expansion on the re_evaluation.yearly_subject reverse relationship
	 * @property-read ReEvaluation[] $_ReEvaluationArray the value for the private _objReEvaluationArray (Read-Only) if set due to an ExpandAsArray on the re_evaluation.yearly_subject reverse relationship
	 * @property-read StudAttendence $_StudAttendence the value for the private _objStudAttendence (Read-Only) if set due to an expansion on the stud_attendence.yearly_subject reverse relationship
	 * @property-read StudAttendence[] $_StudAttendenceArray the value for the private _objStudAttendenceArray (Read-Only) if set due to an ExpandAsArray on the stud_attendence.yearly_subject reverse relationship
	 * @property-read SubjectTought $_SubjectToughtAsSubject the value for the private _objSubjectToughtAsSubject (Read-Only) if set due to an expansion on the subject_tought.subject reverse relationship
	 * @property-read SubjectTought[] $_SubjectToughtAsSubjectArray the value for the private _objSubjectToughtAsSubjectArray (Read-Only) if set due to an ExpandAsArray on the subject_tought.subject reverse relationship
	 * @property-read Timetable $_Timetable the value for the private _objTimetable (Read-Only) if set due to an expansion on the timetable.yearly_subject reverse relationship
	 * @property-read Timetable[] $_TimetableArray the value for the private _objTimetableArray (Read-Only) if set due to an ExpandAsArray on the timetable.yearly_subject reverse relationship
	 * @property-read YearlySubject $_YearlySubjectAsParrent the value for the private _objYearlySubjectAsParrent (Read-Only) if set due to an expansion on the yearly_subject.parrent reverse relationship
	 * @property-read YearlySubject[] $_YearlySubjectAsParrentArray the value for the private _objYearlySubjectAsParrentArray (Read-Only) if set due to an ExpandAsArray on the yearly_subject.parrent reverse relationship
	 * @property-read YearsubjectHasTopic $_YearsubjectHasTopic the value for the private _objYearsubjectHasTopic (Read-Only) if set due to an expansion on the yearsubject_has_topic.yearly_subject reverse relationship
	 * @property-read YearsubjectHasTopic[] $_YearsubjectHasTopicArray the value for the private _objYearsubjectHasTopicArray (Read-Only) if set due to an ExpandAsArray on the yearsubject_has_topic.yearly_subject reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class YearlySubjectGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column yearly_subject.idyearly_subject
		 * @var integer intIdyearlySubject
		 */
		protected $intIdyearlySubject;
		const IdyearlySubjectDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.code
		 * @var string strCode
		 */
		protected $strCode;
		const CodeMaxLength = 45;
		const CodeDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.subject
		 * @var integer intSubject
		 */
		protected $intSubject;
		const SubjectDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.dept_year
		 * @var integer intDeptYear
		 */
		protected $intDeptYear;
		const DeptYearDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.lab
		 * @var integer intLab
		 */
		protected $intLab;
		const LabDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.tusion
		 * @var integer intTusion
		 */
		protected $intTusion;
		const TusionDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.practical
		 * @var integer intPractical
		 */
		protected $intPractical;
		const PracticalDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.credit
		 * @var integer intCredit
		 */
		protected $intCredit;
		const CreditDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.course_grp
		 * @var integer intCourseGrp
		 */
		protected $intCourseGrp;
		const CourseGrpDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.min_passing
		 * @var integer intMinPassing
		 */
		protected $intMinPassing;
		const MinPassingDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.parrent
		 * @var integer intParrent
		 */
		protected $intParrent;
		const ParrentDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.seq
		 * @var integer intSeq
		 */
		protected $intSeq;
		const SeqDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.visible
		 * @var boolean blnVisible
		 */
		protected $blnVisible;
		const VisibleDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.gade_modify_lock
		 * @var boolean blnGadeModifyLock
		 */
		protected $blnGadeModifyLock;
		const GadeModifyLockDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.mean
		 * @var string strMean
		 */
		protected $strMean;
		const MeanDefault = null;


		/**
		 * Protected member variable that maps to the database column yearly_subject.sd
		 * @var string strSd
		 */
		protected $strSd;
		const SdDefault = null;


		/**
		 * Private member variable that stores a reference to a single AppliedExam object
		 * (of type AppliedExam), if this YearlySubject object was restored with
		 * an expansion on the applied_exam association table.
		 * @var AppliedExam _objAppliedExam;
		 */
		private $_objAppliedExam;

		/**
		 * Private member variable that stores a reference to an array of AppliedExam objects
		 * (of type AppliedExam[]), if this YearlySubject object was restored with
		 * an ExpandAsArray on the applied_exam association table.
		 * @var AppliedExam[] _objAppliedExamArray;
		 */
		private $_objAppliedExamArray = null;

		/**
		 * Private member variable that stores a reference to a single ApplyGradeImpromentAsSubject object
		 * (of type ApplyGradeImproment), if this YearlySubject object was restored with
		 * an expansion on the apply_grade_improment association table.
		 * @var ApplyGradeImproment _objApplyGradeImpromentAsSubject;
		 */
		private $_objApplyGradeImpromentAsSubject;

		/**
		 * Private member variable that stores a reference to an array of ApplyGradeImpromentAsSubject objects
		 * (of type ApplyGradeImproment[]), if this YearlySubject object was restored with
		 * an ExpandAsArray on the apply_grade_improment association table.
		 * @var ApplyGradeImproment[] _objApplyGradeImpromentAsSubjectArray;
		 */
		private $_objApplyGradeImpromentAsSubjectArray = null;

		/**
		 * Private member variable that stores a reference to a single DeptYearEvents object
		 * (of type DeptYearEvents), if this YearlySubject object was restored with
		 * an expansion on the dept_year_events association table.
		 * @var DeptYearEvents _objDeptYearEvents;
		 */
		private $_objDeptYearEvents;

		/**
		 * Private member variable that stores a reference to an array of DeptYearEvents objects
		 * (of type DeptYearEvents[]), if this YearlySubject object was restored with
		 * an ExpandAsArray on the dept_year_events association table.
		 * @var DeptYearEvents[] _objDeptYearEventsArray;
		 */
		private $_objDeptYearEventsArray = null;

		/**
		 * Private member variable that stores a reference to a single DeptYearExam object
		 * (of type DeptYearExam), if this YearlySubject object was restored with
		 * an expansion on the dept_year_exam association table.
		 * @var DeptYearExam _objDeptYearExam;
		 */
		private $_objDeptYearExam;

		/**
		 * Private member variable that stores a reference to an array of DeptYearExam objects
		 * (of type DeptYearExam[]), if this YearlySubject object was restored with
		 * an ExpandAsArray on the dept_year_exam association table.
		 * @var DeptYearExam[] _objDeptYearExamArray;
		 */
		private $_objDeptYearExamArray = null;

		/**
		 * Private member variable that stores a reference to a single EventHasGrade object
		 * (of type EventHasGrade), if this YearlySubject object was restored with
		 * an expansion on the event_has_grade association table.
		 * @var EventHasGrade _objEventHasGrade;
		 */
		private $_objEventHasGrade;

		/**
		 * Private member variable that stores a reference to an array of EventHasGrade objects
		 * (of type EventHasGrade[]), if this YearlySubject object was restored with
		 * an ExpandAsArray on the event_has_grade association table.
		 * @var EventHasGrade[] _objEventHasGradeArray;
		 */
		private $_objEventHasGradeArray = null;

		/**
		 * Private member variable that stores a reference to a single GradeCardAsSubject object
		 * (of type GradeCard), if this YearlySubject object was restored with
		 * an expansion on the grade_card association table.
		 * @var GradeCard _objGradeCardAsSubject;
		 */
		private $_objGradeCardAsSubject;

		/**
		 * Private member variable that stores a reference to an array of GradeCardAsSubject objects
		 * (of type GradeCard[]), if this YearlySubject object was restored with
		 * an ExpandAsArray on the grade_card association table.
		 * @var GradeCard[] _objGradeCardAsSubjectArray;
		 */
		private $_objGradeCardAsSubjectArray = null;

		/**
		 * Private member variable that stores a reference to a single ReEvaluation object
		 * (of type ReEvaluation), if this YearlySubject object was restored with
		 * an expansion on the re_evaluation association table.
		 * @var ReEvaluation _objReEvaluation;
		 */
		private $_objReEvaluation;

		/**
		 * Private member variable that stores a reference to an array of ReEvaluation objects
		 * (of type ReEvaluation[]), if this YearlySubject object was restored with
		 * an ExpandAsArray on the re_evaluation association table.
		 * @var ReEvaluation[] _objReEvaluationArray;
		 */
		private $_objReEvaluationArray = null;

		/**
		 * Private member variable that stores a reference to a single StudAttendence object
		 * (of type StudAttendence), if this YearlySubject object was restored with
		 * an expansion on the stud_attendence association table.
		 * @var StudAttendence _objStudAttendence;
		 */
		private $_objStudAttendence;

		/**
		 * Private member variable that stores a reference to an array of StudAttendence objects
		 * (of type StudAttendence[]), if this YearlySubject object was restored with
		 * an ExpandAsArray on the stud_attendence association table.
		 * @var StudAttendence[] _objStudAttendenceArray;
		 */
		private $_objStudAttendenceArray = null;

		/**
		 * Private member variable that stores a reference to a single SubjectToughtAsSubject object
		 * (of type SubjectTought), if this YearlySubject object was restored with
		 * an expansion on the subject_tought association table.
		 * @var SubjectTought _objSubjectToughtAsSubject;
		 */
		private $_objSubjectToughtAsSubject;

		/**
		 * Private member variable that stores a reference to an array of SubjectToughtAsSubject objects
		 * (of type SubjectTought[]), if this YearlySubject object was restored with
		 * an ExpandAsArray on the subject_tought association table.
		 * @var SubjectTought[] _objSubjectToughtAsSubjectArray;
		 */
		private $_objSubjectToughtAsSubjectArray = null;

		/**
		 * Private member variable that stores a reference to a single Timetable object
		 * (of type Timetable), if this YearlySubject object was restored with
		 * an expansion on the timetable association table.
		 * @var Timetable _objTimetable;
		 */
		private $_objTimetable;

		/**
		 * Private member variable that stores a reference to an array of Timetable objects
		 * (of type Timetable[]), if this YearlySubject object was restored with
		 * an ExpandAsArray on the timetable association table.
		 * @var Timetable[] _objTimetableArray;
		 */
		private $_objTimetableArray = null;

		/**
		 * Private member variable that stores a reference to a single YearlySubjectAsParrent object
		 * (of type YearlySubject), if this YearlySubject object was restored with
		 * an expansion on the yearly_subject association table.
		 * @var YearlySubject _objYearlySubjectAsParrent;
		 */
		private $_objYearlySubjectAsParrent;

		/**
		 * Private member variable that stores a reference to an array of YearlySubjectAsParrent objects
		 * (of type YearlySubject[]), if this YearlySubject object was restored with
		 * an ExpandAsArray on the yearly_subject association table.
		 * @var YearlySubject[] _objYearlySubjectAsParrentArray;
		 */
		private $_objYearlySubjectAsParrentArray = null;

		/**
		 * Private member variable that stores a reference to a single YearsubjectHasTopic object
		 * (of type YearsubjectHasTopic), if this YearlySubject object was restored with
		 * an expansion on the yearsubject_has_topic association table.
		 * @var YearsubjectHasTopic _objYearsubjectHasTopic;
		 */
		private $_objYearsubjectHasTopic;

		/**
		 * Private member variable that stores a reference to an array of YearsubjectHasTopic objects
		 * (of type YearsubjectHasTopic[]), if this YearlySubject object was restored with
		 * an ExpandAsArray on the yearsubject_has_topic association table.
		 * @var YearsubjectHasTopic[] _objYearsubjectHasTopicArray;
		 */
		private $_objYearsubjectHasTopicArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column yearly_subject.subject.
		 *
		 * NOTE: Always use the SubjectObject property getter to correctly retrieve this Subject object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Subject objSubjectObject
		 */
		protected $objSubjectObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column yearly_subject.dept_year.
		 *
		 * NOTE: Always use the DeptYearObject property getter to correctly retrieve this DeptYear object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var DeptYear objDeptYearObject
		 */
		protected $objDeptYearObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column yearly_subject.course_grp.
		 *
		 * NOTE: Always use the CourseGrpObject property getter to correctly retrieve this CourseGrp object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var CourseGrp objCourseGrpObject
		 */
		protected $objCourseGrpObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column yearly_subject.parrent.
		 *
		 * NOTE: Always use the ParrentObject property getter to correctly retrieve this YearlySubject object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var YearlySubject objParrentObject
		 */
		protected $objParrentObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdyearlySubject = YearlySubject::IdyearlySubjectDefault;
			$this->strCode = YearlySubject::CodeDefault;
			$this->intSubject = YearlySubject::SubjectDefault;
			$this->intDeptYear = YearlySubject::DeptYearDefault;
			$this->intLab = YearlySubject::LabDefault;
			$this->intTusion = YearlySubject::TusionDefault;
			$this->intPractical = YearlySubject::PracticalDefault;
			$this->intCredit = YearlySubject::CreditDefault;
			$this->intCourseGrp = YearlySubject::CourseGrpDefault;
			$this->intMinPassing = YearlySubject::MinPassingDefault;
			$this->intParrent = YearlySubject::ParrentDefault;
			$this->intSeq = YearlySubject::SeqDefault;
			$this->blnVisible = YearlySubject::VisibleDefault;
			$this->blnGadeModifyLock = YearlySubject::GadeModifyLockDefault;
			$this->strMean = YearlySubject::MeanDefault;
			$this->strSd = YearlySubject::SdDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a YearlySubject from PK Info
		 * @param integer $intIdyearlySubject
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject
		 */
		public static function Load($intIdyearlySubject, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'YearlySubject', $intIdyearlySubject);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = YearlySubject::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::YearlySubject()->IdyearlySubject, $intIdyearlySubject)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all YearlySubjects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call YearlySubject::QueryArray to perform the LoadAll query
			try {
				return YearlySubject::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all YearlySubjects
		 * @return int
		 */
		public static function CountAll() {
			// Call YearlySubject::QueryCount to perform the CountAll query
			return YearlySubject::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Create/Build out the QueryBuilder object with YearlySubject-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'yearly_subject');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				YearlySubject::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('yearly_subject');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single YearlySubject object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return YearlySubject the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = YearlySubject::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new YearlySubject object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = YearlySubject::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return YearlySubject::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of YearlySubject objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return YearlySubject[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = YearlySubject::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return YearlySubject::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = YearlySubject::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of YearlySubject objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = YearlySubject::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			$strQuery = YearlySubject::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/yearlysubject', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = YearlySubject::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this YearlySubject
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'yearly_subject';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idyearly_subject', $strAliasPrefix . 'idyearly_subject');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idyearly_subject', $strAliasPrefix . 'idyearly_subject');
			    $objBuilder->AddSelectItem($strTableName, 'code', $strAliasPrefix . 'code');
			    $objBuilder->AddSelectItem($strTableName, 'subject', $strAliasPrefix . 'subject');
			    $objBuilder->AddSelectItem($strTableName, 'dept_year', $strAliasPrefix . 'dept_year');
			    $objBuilder->AddSelectItem($strTableName, 'lab', $strAliasPrefix . 'lab');
			    $objBuilder->AddSelectItem($strTableName, 'tusion', $strAliasPrefix . 'tusion');
			    $objBuilder->AddSelectItem($strTableName, 'practical', $strAliasPrefix . 'practical');
			    $objBuilder->AddSelectItem($strTableName, 'credit', $strAliasPrefix . 'credit');
			    $objBuilder->AddSelectItem($strTableName, 'course_grp', $strAliasPrefix . 'course_grp');
			    $objBuilder->AddSelectItem($strTableName, 'min_passing', $strAliasPrefix . 'min_passing');
			    $objBuilder->AddSelectItem($strTableName, 'parrent', $strAliasPrefix . 'parrent');
			    $objBuilder->AddSelectItem($strTableName, 'seq', $strAliasPrefix . 'seq');
			    $objBuilder->AddSelectItem($strTableName, 'visible', $strAliasPrefix . 'visible');
			    $objBuilder->AddSelectItem($strTableName, 'gade_modify_lock', $strAliasPrefix . 'gade_modify_lock');
			    $objBuilder->AddSelectItem($strTableName, 'mean', $strAliasPrefix . 'mean');
			    $objBuilder->AddSelectItem($strTableName, 'sd', $strAliasPrefix . 'sd');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a YearlySubject from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this YearlySubject::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return YearlySubject
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idyearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdyearlySubject == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'yearly_subject__';


						// Expanding reverse references: AppliedExam
						$strAlias = $strAliasPrefix . 'appliedexam__idapplied_exam';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objAppliedExamArray)
								$objPreviousItem->_objAppliedExamArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objAppliedExamArray)) {
								$objPreviousChildItems = $objPreviousItem->_objAppliedExamArray;
								$objChildItem = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexam__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objAppliedExamArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objAppliedExamArray[] = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ApplyGradeImpromentAsSubject
						$strAlias = $strAliasPrefix . 'applygradeimpromentassubject__idapply_grade_improment';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objApplyGradeImpromentAsSubjectArray)
								$objPreviousItem->_objApplyGradeImpromentAsSubjectArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objApplyGradeImpromentAsSubjectArray)) {
								$objPreviousChildItems = $objPreviousItem->_objApplyGradeImpromentAsSubjectArray;
								$objChildItem = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentassubject__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objApplyGradeImpromentAsSubjectArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objApplyGradeImpromentAsSubjectArray[] = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentassubject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: DeptYearEvents
						$strAlias = $strAliasPrefix . 'deptyearevents__iddept_year_events';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objDeptYearEventsArray)
								$objPreviousItem->_objDeptYearEventsArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objDeptYearEventsArray)) {
								$objPreviousChildItems = $objPreviousItem->_objDeptYearEventsArray;
								$objChildItem = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearevents__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objDeptYearEventsArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objDeptYearEventsArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearevents__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: DeptYearExam
						$strAlias = $strAliasPrefix . 'deptyearexam__yearly_subject';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objDeptYearExamArray)
								$objPreviousItem->_objDeptYearExamArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objDeptYearExamArray)) {
								$objPreviousChildItems = $objPreviousItem->_objDeptYearExamArray;
								$objChildItem = DeptYearExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearexam__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objDeptYearExamArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objDeptYearExamArray[] = DeptYearExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearexam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: EventHasGrade
						$strAlias = $strAliasPrefix . 'eventhasgrade__idevent_has_grade';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objEventHasGradeArray)
								$objPreviousItem->_objEventHasGradeArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objEventHasGradeArray)) {
								$objPreviousChildItems = $objPreviousItem->_objEventHasGradeArray;
								$objChildItem = EventHasGrade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasgrade__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objEventHasGradeArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objEventHasGradeArray[] = EventHasGrade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasgrade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: GradeCardAsSubject
						$strAlias = $strAliasPrefix . 'gradecardassubject__idgrade_card';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objGradeCardAsSubjectArray)
								$objPreviousItem->_objGradeCardAsSubjectArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objGradeCardAsSubjectArray)) {
								$objPreviousChildItems = $objPreviousItem->_objGradeCardAsSubjectArray;
								$objChildItem = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardassubject__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objGradeCardAsSubjectArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objGradeCardAsSubjectArray[] = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardassubject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ReEvaluation
						$strAlias = $strAliasPrefix . 'reevaluation__idre_evaluation';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objReEvaluationArray)
								$objPreviousItem->_objReEvaluationArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objReEvaluationArray)) {
								$objPreviousChildItems = $objPreviousItem->_objReEvaluationArray;
								$objChildItem = ReEvaluation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'reevaluation__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objReEvaluationArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objReEvaluationArray[] = ReEvaluation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'reevaluation__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: StudAttendence
						$strAlias = $strAliasPrefix . 'studattendence__idstud_attendence';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objStudAttendenceArray)
								$objPreviousItem->_objStudAttendenceArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objStudAttendenceArray)) {
								$objPreviousChildItems = $objPreviousItem->_objStudAttendenceArray;
								$objChildItem = StudAttendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'studattendence__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objStudAttendenceArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objStudAttendenceArray[] = StudAttendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'studattendence__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: SubjectToughtAsSubject
						$strAlias = $strAliasPrefix . 'subjecttoughtassubject__idsubject_tought';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objSubjectToughtAsSubjectArray)
								$objPreviousItem->_objSubjectToughtAsSubjectArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objSubjectToughtAsSubjectArray)) {
								$objPreviousChildItems = $objPreviousItem->_objSubjectToughtAsSubjectArray;
								$objChildItem = SubjectTought::InstantiateDbRow($objDbRow, $strAliasPrefix . 'subjecttoughtassubject__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objSubjectToughtAsSubjectArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objSubjectToughtAsSubjectArray[] = SubjectTought::InstantiateDbRow($objDbRow, $strAliasPrefix . 'subjecttoughtassubject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: Timetable
						$strAlias = $strAliasPrefix . 'timetable__idtimetable';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objTimetableArray)
								$objPreviousItem->_objTimetableArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objTimetableArray)) {
								$objPreviousChildItems = $objPreviousItem->_objTimetableArray;
								$objChildItem = Timetable::InstantiateDbRow($objDbRow, $strAliasPrefix . 'timetable__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objTimetableArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objTimetableArray[] = Timetable::InstantiateDbRow($objDbRow, $strAliasPrefix . 'timetable__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: YearlySubjectAsParrent
						$strAlias = $strAliasPrefix . 'yearlysubjectasparrent__idyearly_subject';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objYearlySubjectAsParrentArray)
								$objPreviousItem->_objYearlySubjectAsParrentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objYearlySubjectAsParrentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objYearlySubjectAsParrentArray;
								$objChildItem = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearlysubjectasparrent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objYearlySubjectAsParrentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objYearlySubjectAsParrentArray[] = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearlysubjectasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: YearsubjectHasTopic
						$strAlias = $strAliasPrefix . 'yearsubjecthastopic__idyearsubject_has_topic';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objYearsubjectHasTopicArray)
								$objPreviousItem->_objYearsubjectHasTopicArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objYearsubjectHasTopicArray)) {
								$objPreviousChildItems = $objPreviousItem->_objYearsubjectHasTopicArray;
								$objChildItem = YearsubjectHasTopic::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearsubjecthastopic__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objYearsubjectHasTopicArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objYearsubjectHasTopicArray[] = YearsubjectHasTopic::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearsubjecthastopic__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'yearly_subject__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the YearlySubject object
			$objToReturn = new YearlySubject();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idyearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdyearlySubject = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSubject = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'dept_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDeptYear = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'lab';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intLab = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'tusion';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intTusion = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'practical';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intPractical = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'credit';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCredit = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'course_grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCourseGrp = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'min_passing';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMinPassing = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'parrent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intParrent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'seq';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSeq = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'visible';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnVisible = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'gade_modify_lock';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnGadeModifyLock = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'mean';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strMean = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'sd';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strSd = $objDbRow->GetColumn($strAliasName, 'VarChar');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdyearlySubject != $objPreviousItem->IdyearlySubject) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objAppliedExamArray);
					$cnt = count($objToReturn->_objAppliedExamArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objAppliedExamArray, $objToReturn->_objAppliedExamArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objApplyGradeImpromentAsSubjectArray);
					$cnt = count($objToReturn->_objApplyGradeImpromentAsSubjectArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objApplyGradeImpromentAsSubjectArray, $objToReturn->_objApplyGradeImpromentAsSubjectArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objDeptYearEventsArray);
					$cnt = count($objToReturn->_objDeptYearEventsArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objDeptYearEventsArray, $objToReturn->_objDeptYearEventsArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objDeptYearExamArray);
					$cnt = count($objToReturn->_objDeptYearExamArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objDeptYearExamArray, $objToReturn->_objDeptYearExamArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objEventHasGradeArray);
					$cnt = count($objToReturn->_objEventHasGradeArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objEventHasGradeArray, $objToReturn->_objEventHasGradeArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objGradeCardAsSubjectArray);
					$cnt = count($objToReturn->_objGradeCardAsSubjectArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objGradeCardAsSubjectArray, $objToReturn->_objGradeCardAsSubjectArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objReEvaluationArray);
					$cnt = count($objToReturn->_objReEvaluationArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objReEvaluationArray, $objToReturn->_objReEvaluationArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objStudAttendenceArray);
					$cnt = count($objToReturn->_objStudAttendenceArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objStudAttendenceArray, $objToReturn->_objStudAttendenceArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objSubjectToughtAsSubjectArray);
					$cnt = count($objToReturn->_objSubjectToughtAsSubjectArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objSubjectToughtAsSubjectArray, $objToReturn->_objSubjectToughtAsSubjectArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objTimetableArray);
					$cnt = count($objToReturn->_objTimetableArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objTimetableArray, $objToReturn->_objTimetableArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objYearlySubjectAsParrentArray);
					$cnt = count($objToReturn->_objYearlySubjectAsParrentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objYearlySubjectAsParrentArray, $objToReturn->_objYearlySubjectAsParrentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objYearsubjectHasTopicArray);
					$cnt = count($objToReturn->_objYearsubjectHasTopicArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objYearsubjectHasTopicArray, $objToReturn->_objYearsubjectHasTopicArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'yearly_subject__';

			// Check for SubjectObject Early Binding
			$strAlias = $strAliasPrefix . 'subject__idsubject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSubjectObject = Subject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'subject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DeptYearObject Early Binding
			$strAlias = $strAliasPrefix . 'dept_year__iddept_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDeptYearObject = DeptYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'dept_year__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CourseGrpObject Early Binding
			$strAlias = $strAliasPrefix . 'course_grp__idcourse_grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCourseGrpObject = CourseGrp::InstantiateDbRow($objDbRow, $strAliasPrefix . 'course_grp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ParrentObject Early Binding
			$strAlias = $strAliasPrefix . 'parrent__idyearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objParrentObject = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'parrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for AppliedExam Virtual Binding
			$strAlias = $strAliasPrefix . 'appliedexam__idapplied_exam';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objAppliedExamArray)
				$objToReturn->_objAppliedExamArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objAppliedExamArray[] = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objAppliedExam = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ApplyGradeImpromentAsSubject Virtual Binding
			$strAlias = $strAliasPrefix . 'applygradeimpromentassubject__idapply_grade_improment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objApplyGradeImpromentAsSubjectArray)
				$objToReturn->_objApplyGradeImpromentAsSubjectArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objApplyGradeImpromentAsSubjectArray[] = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentassubject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objApplyGradeImpromentAsSubject = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentassubject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for DeptYearEvents Virtual Binding
			$strAlias = $strAliasPrefix . 'deptyearevents__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objDeptYearEventsArray)
				$objToReturn->_objDeptYearEventsArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objDeptYearEventsArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearevents__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objDeptYearEvents = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearevents__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for DeptYearExam Virtual Binding
			$strAlias = $strAliasPrefix . 'deptyearexam__yearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objDeptYearExamArray)
				$objToReturn->_objDeptYearExamArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objDeptYearExamArray[] = DeptYearExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearexam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objDeptYearExam = DeptYearExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyearexam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for EventHasGrade Virtual Binding
			$strAlias = $strAliasPrefix . 'eventhasgrade__idevent_has_grade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objEventHasGradeArray)
				$objToReturn->_objEventHasGradeArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objEventHasGradeArray[] = EventHasGrade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasgrade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objEventHasGrade = EventHasGrade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasgrade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for GradeCardAsSubject Virtual Binding
			$strAlias = $strAliasPrefix . 'gradecardassubject__idgrade_card';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objGradeCardAsSubjectArray)
				$objToReturn->_objGradeCardAsSubjectArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objGradeCardAsSubjectArray[] = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardassubject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objGradeCardAsSubject = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardassubject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ReEvaluation Virtual Binding
			$strAlias = $strAliasPrefix . 'reevaluation__idre_evaluation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objReEvaluationArray)
				$objToReturn->_objReEvaluationArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objReEvaluationArray[] = ReEvaluation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'reevaluation__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objReEvaluation = ReEvaluation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'reevaluation__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for StudAttendence Virtual Binding
			$strAlias = $strAliasPrefix . 'studattendence__idstud_attendence';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objStudAttendenceArray)
				$objToReturn->_objStudAttendenceArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objStudAttendenceArray[] = StudAttendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'studattendence__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objStudAttendence = StudAttendence::InstantiateDbRow($objDbRow, $strAliasPrefix . 'studattendence__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for SubjectToughtAsSubject Virtual Binding
			$strAlias = $strAliasPrefix . 'subjecttoughtassubject__idsubject_tought';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objSubjectToughtAsSubjectArray)
				$objToReturn->_objSubjectToughtAsSubjectArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objSubjectToughtAsSubjectArray[] = SubjectTought::InstantiateDbRow($objDbRow, $strAliasPrefix . 'subjecttoughtassubject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objSubjectToughtAsSubject = SubjectTought::InstantiateDbRow($objDbRow, $strAliasPrefix . 'subjecttoughtassubject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for Timetable Virtual Binding
			$strAlias = $strAliasPrefix . 'timetable__idtimetable';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objTimetableArray)
				$objToReturn->_objTimetableArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objTimetableArray[] = Timetable::InstantiateDbRow($objDbRow, $strAliasPrefix . 'timetable__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objTimetable = Timetable::InstantiateDbRow($objDbRow, $strAliasPrefix . 'timetable__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for YearlySubjectAsParrent Virtual Binding
			$strAlias = $strAliasPrefix . 'yearlysubjectasparrent__idyearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objYearlySubjectAsParrentArray)
				$objToReturn->_objYearlySubjectAsParrentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objYearlySubjectAsParrentArray[] = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearlysubjectasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objYearlySubjectAsParrent = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearlysubjectasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for YearsubjectHasTopic Virtual Binding
			$strAlias = $strAliasPrefix . 'yearsubjecthastopic__idyearsubject_has_topic';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objYearsubjectHasTopicArray)
				$objToReturn->_objYearsubjectHasTopicArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objYearsubjectHasTopicArray[] = YearsubjectHasTopic::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearsubjecthastopic__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objYearsubjectHasTopic = YearsubjectHasTopic::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearsubjecthastopic__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of YearlySubjects from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return YearlySubject[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = YearlySubject::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = YearlySubject::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single YearlySubject object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return YearlySubject next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return YearlySubject::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single YearlySubject object,
		 * by IdyearlySubject Index(es)
		 * @param integer $intIdyearlySubject
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject
		*/
		public static function LoadByIdyearlySubject($intIdyearlySubject, $objOptionalClauses = null) {
			return YearlySubject::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::YearlySubject()->IdyearlySubject, $intIdyearlySubject)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single YearlySubject object,
		 * by Code Index(es)
		 * @param string $strCode
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject
		*/
		public static function LoadByCode($strCode, $objOptionalClauses = null) {
			return YearlySubject::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::YearlySubject()->Code, $strCode)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of YearlySubject objects,
		 * by DeptYear Index(es)
		 * @param integer $intDeptYear
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject[]
		*/
		public static function LoadArrayByDeptYear($intDeptYear, $objOptionalClauses = null) {
			// Call YearlySubject::QueryArray to perform the LoadArrayByDeptYear query
			try {
				return YearlySubject::QueryArray(
					QQ::Equal(QQN::YearlySubject()->DeptYear, $intDeptYear),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count YearlySubjects
		 * by DeptYear Index(es)
		 * @param integer $intDeptYear
		 * @return int
		*/
		public static function CountByDeptYear($intDeptYear) {
			// Call YearlySubject::QueryCount to perform the CountByDeptYear query
			return YearlySubject::QueryCount(
				QQ::Equal(QQN::YearlySubject()->DeptYear, $intDeptYear)
			);
		}

		/**
		 * Load an array of YearlySubject objects,
		 * by Subject Index(es)
		 * @param integer $intSubject
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject[]
		*/
		public static function LoadArrayBySubject($intSubject, $objOptionalClauses = null) {
			// Call YearlySubject::QueryArray to perform the LoadArrayBySubject query
			try {
				return YearlySubject::QueryArray(
					QQ::Equal(QQN::YearlySubject()->Subject, $intSubject),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count YearlySubjects
		 * by Subject Index(es)
		 * @param integer $intSubject
		 * @return int
		*/
		public static function CountBySubject($intSubject) {
			// Call YearlySubject::QueryCount to perform the CountBySubject query
			return YearlySubject::QueryCount(
				QQ::Equal(QQN::YearlySubject()->Subject, $intSubject)
			);
		}

		/**
		 * Load an array of YearlySubject objects,
		 * by CourseGrp Index(es)
		 * @param integer $intCourseGrp
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject[]
		*/
		public static function LoadArrayByCourseGrp($intCourseGrp, $objOptionalClauses = null) {
			// Call YearlySubject::QueryArray to perform the LoadArrayByCourseGrp query
			try {
				return YearlySubject::QueryArray(
					QQ::Equal(QQN::YearlySubject()->CourseGrp, $intCourseGrp),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count YearlySubjects
		 * by CourseGrp Index(es)
		 * @param integer $intCourseGrp
		 * @return int
		*/
		public static function CountByCourseGrp($intCourseGrp) {
			// Call YearlySubject::QueryCount to perform the CountByCourseGrp query
			return YearlySubject::QueryCount(
				QQ::Equal(QQN::YearlySubject()->CourseGrp, $intCourseGrp)
			);
		}

		/**
		 * Load an array of YearlySubject objects,
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject[]
		*/
		public static function LoadArrayByParrent($intParrent, $objOptionalClauses = null) {
			// Call YearlySubject::QueryArray to perform the LoadArrayByParrent query
			try {
				return YearlySubject::QueryArray(
					QQ::Equal(QQN::YearlySubject()->Parrent, $intParrent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count YearlySubjects
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @return int
		*/
		public static function CountByParrent($intParrent) {
			// Call YearlySubject::QueryCount to perform the CountByParrent query
			return YearlySubject::QueryCount(
				QQ::Equal(QQN::YearlySubject()->Parrent, $intParrent)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this YearlySubject
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `yearly_subject` (
							`code`,
							`subject`,
							`dept_year`,
							`lab`,
							`tusion`,
							`practical`,
							`credit`,
							`course_grp`,
							`min_passing`,
							`parrent`,
							`seq`,
							`visible`,
							`gade_modify_lock`,
							`mean`,
							`sd`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strCode) . ',
							' . $objDatabase->SqlVariable($this->intSubject) . ',
							' . $objDatabase->SqlVariable($this->intDeptYear) . ',
							' . $objDatabase->SqlVariable($this->intLab) . ',
							' . $objDatabase->SqlVariable($this->intTusion) . ',
							' . $objDatabase->SqlVariable($this->intPractical) . ',
							' . $objDatabase->SqlVariable($this->intCredit) . ',
							' . $objDatabase->SqlVariable($this->intCourseGrp) . ',
							' . $objDatabase->SqlVariable($this->intMinPassing) . ',
							' . $objDatabase->SqlVariable($this->intParrent) . ',
							' . $objDatabase->SqlVariable($this->intSeq) . ',
							' . $objDatabase->SqlVariable($this->blnVisible) . ',
							' . $objDatabase->SqlVariable($this->blnGadeModifyLock) . ',
							' . $objDatabase->SqlVariable($this->strMean) . ',
							' . $objDatabase->SqlVariable($this->strSd) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdyearlySubject = $objDatabase->InsertId('yearly_subject', 'idyearly_subject');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`yearly_subject`
						SET
							`code` = ' . $objDatabase->SqlVariable($this->strCode) . ',
							`subject` = ' . $objDatabase->SqlVariable($this->intSubject) . ',
							`dept_year` = ' . $objDatabase->SqlVariable($this->intDeptYear) . ',
							`lab` = ' . $objDatabase->SqlVariable($this->intLab) . ',
							`tusion` = ' . $objDatabase->SqlVariable($this->intTusion) . ',
							`practical` = ' . $objDatabase->SqlVariable($this->intPractical) . ',
							`credit` = ' . $objDatabase->SqlVariable($this->intCredit) . ',
							`course_grp` = ' . $objDatabase->SqlVariable($this->intCourseGrp) . ',
							`min_passing` = ' . $objDatabase->SqlVariable($this->intMinPassing) . ',
							`parrent` = ' . $objDatabase->SqlVariable($this->intParrent) . ',
							`seq` = ' . $objDatabase->SqlVariable($this->intSeq) . ',
							`visible` = ' . $objDatabase->SqlVariable($this->blnVisible) . ',
							`gade_modify_lock` = ' . $objDatabase->SqlVariable($this->blnGadeModifyLock) . ',
							`mean` = ' . $objDatabase->SqlVariable($this->strMean) . ',
							`sd` = ' . $objDatabase->SqlVariable($this->strSd) . '
						WHERE
							`idyearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this YearlySubject
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this YearlySubject with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`yearly_subject`
				WHERE
					`idyearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this YearlySubject ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'YearlySubject', $this->intIdyearlySubject);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all YearlySubjects
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`yearly_subject`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate yearly_subject table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `yearly_subject`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this YearlySubject from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved YearlySubject object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = YearlySubject::Load($this->intIdyearlySubject);

			// Update $this's local variables to match
			$this->strCode = $objReloaded->strCode;
			$this->Subject = $objReloaded->Subject;
			$this->DeptYear = $objReloaded->DeptYear;
			$this->intLab = $objReloaded->intLab;
			$this->intTusion = $objReloaded->intTusion;
			$this->intPractical = $objReloaded->intPractical;
			$this->intCredit = $objReloaded->intCredit;
			$this->CourseGrp = $objReloaded->CourseGrp;
			$this->intMinPassing = $objReloaded->intMinPassing;
			$this->Parrent = $objReloaded->Parrent;
			$this->intSeq = $objReloaded->intSeq;
			$this->blnVisible = $objReloaded->blnVisible;
			$this->blnGadeModifyLock = $objReloaded->blnGadeModifyLock;
			$this->strMean = $objReloaded->strMean;
			$this->strSd = $objReloaded->strSd;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdyearlySubject':
					/**
					 * Gets the value for intIdyearlySubject (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdyearlySubject;

				case 'Code':
					/**
					 * Gets the value for strCode (Unique)
					 * @return string
					 */
					return $this->strCode;

				case 'Subject':
					/**
					 * Gets the value for intSubject (Not Null)
					 * @return integer
					 */
					return $this->intSubject;

				case 'DeptYear':
					/**
					 * Gets the value for intDeptYear (Not Null)
					 * @return integer
					 */
					return $this->intDeptYear;

				case 'Lab':
					/**
					 * Gets the value for intLab 
					 * @return integer
					 */
					return $this->intLab;

				case 'Tusion':
					/**
					 * Gets the value for intTusion 
					 * @return integer
					 */
					return $this->intTusion;

				case 'Practical':
					/**
					 * Gets the value for intPractical 
					 * @return integer
					 */
					return $this->intPractical;

				case 'Credit':
					/**
					 * Gets the value for intCredit 
					 * @return integer
					 */
					return $this->intCredit;

				case 'CourseGrp':
					/**
					 * Gets the value for intCourseGrp 
					 * @return integer
					 */
					return $this->intCourseGrp;

				case 'MinPassing':
					/**
					 * Gets the value for intMinPassing 
					 * @return integer
					 */
					return $this->intMinPassing;

				case 'Parrent':
					/**
					 * Gets the value for intParrent 
					 * @return integer
					 */
					return $this->intParrent;

				case 'Seq':
					/**
					 * Gets the value for intSeq 
					 * @return integer
					 */
					return $this->intSeq;

				case 'Visible':
					/**
					 * Gets the value for blnVisible 
					 * @return boolean
					 */
					return $this->blnVisible;

				case 'GadeModifyLock':
					/**
					 * Gets the value for blnGadeModifyLock 
					 * @return boolean
					 */
					return $this->blnGadeModifyLock;

				case 'Mean':
					/**
					 * Gets the value for strMean 
					 * @return string
					 */
					return $this->strMean;

				case 'Sd':
					/**
					 * Gets the value for strSd 
					 * @return string
					 */
					return $this->strSd;


				///////////////////
				// Member Objects
				///////////////////
				case 'SubjectObject':
					/**
					 * Gets the value for the Subject object referenced by intSubject (Not Null)
					 * @return Subject
					 */
					try {
						if ((!$this->objSubjectObject) && (!is_null($this->intSubject)))
							$this->objSubjectObject = Subject::Load($this->intSubject);
						return $this->objSubjectObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DeptYearObject':
					/**
					 * Gets the value for the DeptYear object referenced by intDeptYear (Not Null)
					 * @return DeptYear
					 */
					try {
						if ((!$this->objDeptYearObject) && (!is_null($this->intDeptYear)))
							$this->objDeptYearObject = DeptYear::Load($this->intDeptYear);
						return $this->objDeptYearObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CourseGrpObject':
					/**
					 * Gets the value for the CourseGrp object referenced by intCourseGrp 
					 * @return CourseGrp
					 */
					try {
						if ((!$this->objCourseGrpObject) && (!is_null($this->intCourseGrp)))
							$this->objCourseGrpObject = CourseGrp::Load($this->intCourseGrp);
						return $this->objCourseGrpObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ParrentObject':
					/**
					 * Gets the value for the YearlySubject object referenced by intParrent 
					 * @return YearlySubject
					 */
					try {
						if ((!$this->objParrentObject) && (!is_null($this->intParrent)))
							$this->objParrentObject = YearlySubject::Load($this->intParrent);
						return $this->objParrentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_AppliedExam':
					/**
					 * Gets the value for the private _objAppliedExam (Read-Only)
					 * if set due to an expansion on the applied_exam.yearly_subject reverse relationship
					 * @return AppliedExam
					 */
					return $this->_objAppliedExam;

				case '_AppliedExamArray':
					/**
					 * Gets the value for the private _objAppliedExamArray (Read-Only)
					 * if set due to an ExpandAsArray on the applied_exam.yearly_subject reverse relationship
					 * @return AppliedExam[]
					 */
					return $this->_objAppliedExamArray;

				case '_ApplyGradeImpromentAsSubject':
					/**
					 * Gets the value for the private _objApplyGradeImpromentAsSubject (Read-Only)
					 * if set due to an expansion on the apply_grade_improment.subject reverse relationship
					 * @return ApplyGradeImproment
					 */
					return $this->_objApplyGradeImpromentAsSubject;

				case '_ApplyGradeImpromentAsSubjectArray':
					/**
					 * Gets the value for the private _objApplyGradeImpromentAsSubjectArray (Read-Only)
					 * if set due to an ExpandAsArray on the apply_grade_improment.subject reverse relationship
					 * @return ApplyGradeImproment[]
					 */
					return $this->_objApplyGradeImpromentAsSubjectArray;

				case '_DeptYearEvents':
					/**
					 * Gets the value for the private _objDeptYearEvents (Read-Only)
					 * if set due to an expansion on the dept_year_events.yearly_subject reverse relationship
					 * @return DeptYearEvents
					 */
					return $this->_objDeptYearEvents;

				case '_DeptYearEventsArray':
					/**
					 * Gets the value for the private _objDeptYearEventsArray (Read-Only)
					 * if set due to an ExpandAsArray on the dept_year_events.yearly_subject reverse relationship
					 * @return DeptYearEvents[]
					 */
					return $this->_objDeptYearEventsArray;

				case '_DeptYearExam':
					/**
					 * Gets the value for the private _objDeptYearExam (Read-Only)
					 * if set due to an expansion on the dept_year_exam.yearly_subject reverse relationship
					 * @return DeptYearExam
					 */
					return $this->_objDeptYearExam;

				case '_DeptYearExamArray':
					/**
					 * Gets the value for the private _objDeptYearExamArray (Read-Only)
					 * if set due to an ExpandAsArray on the dept_year_exam.yearly_subject reverse relationship
					 * @return DeptYearExam[]
					 */
					return $this->_objDeptYearExamArray;

				case '_EventHasGrade':
					/**
					 * Gets the value for the private _objEventHasGrade (Read-Only)
					 * if set due to an expansion on the event_has_grade.yearly_subject reverse relationship
					 * @return EventHasGrade
					 */
					return $this->_objEventHasGrade;

				case '_EventHasGradeArray':
					/**
					 * Gets the value for the private _objEventHasGradeArray (Read-Only)
					 * if set due to an ExpandAsArray on the event_has_grade.yearly_subject reverse relationship
					 * @return EventHasGrade[]
					 */
					return $this->_objEventHasGradeArray;

				case '_GradeCardAsSubject':
					/**
					 * Gets the value for the private _objGradeCardAsSubject (Read-Only)
					 * if set due to an expansion on the grade_card.subject reverse relationship
					 * @return GradeCard
					 */
					return $this->_objGradeCardAsSubject;

				case '_GradeCardAsSubjectArray':
					/**
					 * Gets the value for the private _objGradeCardAsSubjectArray (Read-Only)
					 * if set due to an ExpandAsArray on the grade_card.subject reverse relationship
					 * @return GradeCard[]
					 */
					return $this->_objGradeCardAsSubjectArray;

				case '_ReEvaluation':
					/**
					 * Gets the value for the private _objReEvaluation (Read-Only)
					 * if set due to an expansion on the re_evaluation.yearly_subject reverse relationship
					 * @return ReEvaluation
					 */
					return $this->_objReEvaluation;

				case '_ReEvaluationArray':
					/**
					 * Gets the value for the private _objReEvaluationArray (Read-Only)
					 * if set due to an ExpandAsArray on the re_evaluation.yearly_subject reverse relationship
					 * @return ReEvaluation[]
					 */
					return $this->_objReEvaluationArray;

				case '_StudAttendence':
					/**
					 * Gets the value for the private _objStudAttendence (Read-Only)
					 * if set due to an expansion on the stud_attendence.yearly_subject reverse relationship
					 * @return StudAttendence
					 */
					return $this->_objStudAttendence;

				case '_StudAttendenceArray':
					/**
					 * Gets the value for the private _objStudAttendenceArray (Read-Only)
					 * if set due to an ExpandAsArray on the stud_attendence.yearly_subject reverse relationship
					 * @return StudAttendence[]
					 */
					return $this->_objStudAttendenceArray;

				case '_SubjectToughtAsSubject':
					/**
					 * Gets the value for the private _objSubjectToughtAsSubject (Read-Only)
					 * if set due to an expansion on the subject_tought.subject reverse relationship
					 * @return SubjectTought
					 */
					return $this->_objSubjectToughtAsSubject;

				case '_SubjectToughtAsSubjectArray':
					/**
					 * Gets the value for the private _objSubjectToughtAsSubjectArray (Read-Only)
					 * if set due to an ExpandAsArray on the subject_tought.subject reverse relationship
					 * @return SubjectTought[]
					 */
					return $this->_objSubjectToughtAsSubjectArray;

				case '_Timetable':
					/**
					 * Gets the value for the private _objTimetable (Read-Only)
					 * if set due to an expansion on the timetable.yearly_subject reverse relationship
					 * @return Timetable
					 */
					return $this->_objTimetable;

				case '_TimetableArray':
					/**
					 * Gets the value for the private _objTimetableArray (Read-Only)
					 * if set due to an ExpandAsArray on the timetable.yearly_subject reverse relationship
					 * @return Timetable[]
					 */
					return $this->_objTimetableArray;

				case '_YearlySubjectAsParrent':
					/**
					 * Gets the value for the private _objYearlySubjectAsParrent (Read-Only)
					 * if set due to an expansion on the yearly_subject.parrent reverse relationship
					 * @return YearlySubject
					 */
					return $this->_objYearlySubjectAsParrent;

				case '_YearlySubjectAsParrentArray':
					/**
					 * Gets the value for the private _objYearlySubjectAsParrentArray (Read-Only)
					 * if set due to an ExpandAsArray on the yearly_subject.parrent reverse relationship
					 * @return YearlySubject[]
					 */
					return $this->_objYearlySubjectAsParrentArray;

				case '_YearsubjectHasTopic':
					/**
					 * Gets the value for the private _objYearsubjectHasTopic (Read-Only)
					 * if set due to an expansion on the yearsubject_has_topic.yearly_subject reverse relationship
					 * @return YearsubjectHasTopic
					 */
					return $this->_objYearsubjectHasTopic;

				case '_YearsubjectHasTopicArray':
					/**
					 * Gets the value for the private _objYearsubjectHasTopicArray (Read-Only)
					 * if set due to an ExpandAsArray on the yearsubject_has_topic.yearly_subject reverse relationship
					 * @return YearsubjectHasTopic[]
					 */
					return $this->_objYearsubjectHasTopicArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Code':
					/**
					 * Sets the value for strCode (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Subject':
					/**
					 * Sets the value for intSubject (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSubjectObject = null;
						return ($this->intSubject = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DeptYear':
					/**
					 * Sets the value for intDeptYear (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDeptYearObject = null;
						return ($this->intDeptYear = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Lab':
					/**
					 * Sets the value for intLab 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intLab = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Tusion':
					/**
					 * Sets the value for intTusion 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intTusion = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Practical':
					/**
					 * Sets the value for intPractical 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intPractical = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Credit':
					/**
					 * Sets the value for intCredit 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intCredit = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CourseGrp':
					/**
					 * Sets the value for intCourseGrp 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCourseGrpObject = null;
						return ($this->intCourseGrp = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'MinPassing':
					/**
					 * Sets the value for intMinPassing 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intMinPassing = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Parrent':
					/**
					 * Sets the value for intParrent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objParrentObject = null;
						return ($this->intParrent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Seq':
					/**
					 * Sets the value for intSeq 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intSeq = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Visible':
					/**
					 * Sets the value for blnVisible 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnVisible = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GadeModifyLock':
					/**
					 * Sets the value for blnGadeModifyLock 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnGadeModifyLock = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Mean':
					/**
					 * Sets the value for strMean 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strMean = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Sd':
					/**
					 * Sets the value for strSd 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strSd = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'SubjectObject':
					/**
					 * Sets the value for the Subject object referenced by intSubject (Not Null)
					 * @param Subject $mixValue
					 * @return Subject
					 */
					if (is_null($mixValue)) {
						$this->intSubject = null;
						$this->objSubjectObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Subject object
						try {
							$mixValue = QType::Cast($mixValue, 'Subject');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Subject object
						if (is_null($mixValue->Idsubject))
							throw new QCallerException('Unable to set an unsaved SubjectObject for this YearlySubject');

						// Update Local Member Variables
						$this->objSubjectObject = $mixValue;
						$this->intSubject = $mixValue->Idsubject;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DeptYearObject':
					/**
					 * Sets the value for the DeptYear object referenced by intDeptYear (Not Null)
					 * @param DeptYear $mixValue
					 * @return DeptYear
					 */
					if (is_null($mixValue)) {
						$this->intDeptYear = null;
						$this->objDeptYearObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a DeptYear object
						try {
							$mixValue = QType::Cast($mixValue, 'DeptYear');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED DeptYear object
						if (is_null($mixValue->IddeptYear))
							throw new QCallerException('Unable to set an unsaved DeptYearObject for this YearlySubject');

						// Update Local Member Variables
						$this->objDeptYearObject = $mixValue;
						$this->intDeptYear = $mixValue->IddeptYear;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CourseGrpObject':
					/**
					 * Sets the value for the CourseGrp object referenced by intCourseGrp 
					 * @param CourseGrp $mixValue
					 * @return CourseGrp
					 */
					if (is_null($mixValue)) {
						$this->intCourseGrp = null;
						$this->objCourseGrpObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a CourseGrp object
						try {
							$mixValue = QType::Cast($mixValue, 'CourseGrp');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED CourseGrp object
						if (is_null($mixValue->IdcourseGrp))
							throw new QCallerException('Unable to set an unsaved CourseGrpObject for this YearlySubject');

						// Update Local Member Variables
						$this->objCourseGrpObject = $mixValue;
						$this->intCourseGrp = $mixValue->IdcourseGrp;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ParrentObject':
					/**
					 * Sets the value for the YearlySubject object referenced by intParrent 
					 * @param YearlySubject $mixValue
					 * @return YearlySubject
					 */
					if (is_null($mixValue)) {
						$this->intParrent = null;
						$this->objParrentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a YearlySubject object
						try {
							$mixValue = QType::Cast($mixValue, 'YearlySubject');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED YearlySubject object
						if (is_null($mixValue->IdyearlySubject))
							throw new QCallerException('Unable to set an unsaved ParrentObject for this YearlySubject');

						// Update Local Member Variables
						$this->objParrentObject = $mixValue;
						$this->intParrent = $mixValue->IdyearlySubject;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for AppliedExam
		//-------------------------------------------------------------------

		/**
		 * Gets all associated AppliedExams as an array of AppliedExam objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppliedExam[]
		*/
		public function GetAppliedExamArray($objOptionalClauses = null) {
			if ((is_null($this->intIdyearlySubject)))
				return array();

			try {
				return AppliedExam::LoadArrayByYearlySubject($this->intIdyearlySubject, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated AppliedExams
		 * @return int
		*/
		public function CountAppliedExams() {
			if ((is_null($this->intIdyearlySubject)))
				return 0;

			return AppliedExam::CountByYearlySubject($this->intIdyearlySubject);
		}

		/**
		 * Associates a AppliedExam
		 * @param AppliedExam $objAppliedExam
		 * @return void
		*/
		public function AssociateAppliedExam(AppliedExam $objAppliedExam) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppliedExam on this unsaved YearlySubject.');
			if ((is_null($objAppliedExam->IdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppliedExam on this YearlySubject with an unsaved AppliedExam.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`applied_exam`
				SET
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($objAppliedExam->IdappliedExam) . '
			');
		}

		/**
		 * Unassociates a AppliedExam
		 * @param AppliedExam $objAppliedExam
		 * @return void
		*/
		public function UnassociateAppliedExam(AppliedExam $objAppliedExam) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExam on this unsaved YearlySubject.');
			if ((is_null($objAppliedExam->IdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExam on this YearlySubject with an unsaved AppliedExam.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`applied_exam`
				SET
					`yearly_subject` = null
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($objAppliedExam->IdappliedExam) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Unassociates all AppliedExams
		 * @return void
		*/
		public function UnassociateAllAppliedExams() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExam on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`applied_exam`
				SET
					`yearly_subject` = null
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes an associated AppliedExam
		 * @param AppliedExam $objAppliedExam
		 * @return void
		*/
		public function DeleteAssociatedAppliedExam(AppliedExam $objAppliedExam) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExam on this unsaved YearlySubject.');
			if ((is_null($objAppliedExam->IdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExam on this YearlySubject with an unsaved AppliedExam.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`applied_exam`
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($objAppliedExam->IdappliedExam) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes all associated AppliedExams
		 * @return void
		*/
		public function DeleteAllAppliedExams() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExam on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`applied_exam`
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}


		// Related Objects' Methods for ApplyGradeImpromentAsSubject
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ApplyGradeImpromentsAsSubject as an array of ApplyGradeImproment objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ApplyGradeImproment[]
		*/
		public function GetApplyGradeImpromentAsSubjectArray($objOptionalClauses = null) {
			if ((is_null($this->intIdyearlySubject)))
				return array();

			try {
				return ApplyGradeImproment::LoadArrayBySubject($this->intIdyearlySubject, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ApplyGradeImpromentsAsSubject
		 * @return int
		*/
		public function CountApplyGradeImpromentsAsSubject() {
			if ((is_null($this->intIdyearlySubject)))
				return 0;

			return ApplyGradeImproment::CountBySubject($this->intIdyearlySubject);
		}

		/**
		 * Associates a ApplyGradeImpromentAsSubject
		 * @param ApplyGradeImproment $objApplyGradeImproment
		 * @return void
		*/
		public function AssociateApplyGradeImpromentAsSubject(ApplyGradeImproment $objApplyGradeImproment) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplyGradeImpromentAsSubject on this unsaved YearlySubject.');
			if ((is_null($objApplyGradeImproment->IdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplyGradeImpromentAsSubject on this YearlySubject with an unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`apply_grade_improment`
				SET
					`subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
				WHERE
					`idapply_grade_improment` = ' . $objDatabase->SqlVariable($objApplyGradeImproment->IdapplyGradeImproment) . '
			');
		}

		/**
		 * Unassociates a ApplyGradeImpromentAsSubject
		 * @param ApplyGradeImproment $objApplyGradeImproment
		 * @return void
		*/
		public function UnassociateApplyGradeImpromentAsSubject(ApplyGradeImproment $objApplyGradeImproment) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsSubject on this unsaved YearlySubject.');
			if ((is_null($objApplyGradeImproment->IdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsSubject on this YearlySubject with an unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`apply_grade_improment`
				SET
					`subject` = null
				WHERE
					`idapply_grade_improment` = ' . $objDatabase->SqlVariable($objApplyGradeImproment->IdapplyGradeImproment) . ' AND
					`subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Unassociates all ApplyGradeImpromentsAsSubject
		 * @return void
		*/
		public function UnassociateAllApplyGradeImpromentsAsSubject() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsSubject on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`apply_grade_improment`
				SET
					`subject` = null
				WHERE
					`subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes an associated ApplyGradeImpromentAsSubject
		 * @param ApplyGradeImproment $objApplyGradeImproment
		 * @return void
		*/
		public function DeleteAssociatedApplyGradeImpromentAsSubject(ApplyGradeImproment $objApplyGradeImproment) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsSubject on this unsaved YearlySubject.');
			if ((is_null($objApplyGradeImproment->IdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsSubject on this YearlySubject with an unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`apply_grade_improment`
				WHERE
					`idapply_grade_improment` = ' . $objDatabase->SqlVariable($objApplyGradeImproment->IdapplyGradeImproment) . ' AND
					`subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes all associated ApplyGradeImpromentsAsSubject
		 * @return void
		*/
		public function DeleteAllApplyGradeImpromentsAsSubject() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsSubject on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`apply_grade_improment`
				WHERE
					`subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}


		// Related Objects' Methods for DeptYearEvents
		//-------------------------------------------------------------------

		/**
		 * Gets all associated DeptYearEventses as an array of DeptYearEvents objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public function GetDeptYearEventsArray($objOptionalClauses = null) {
			if ((is_null($this->intIdyearlySubject)))
				return array();

			try {
				return DeptYearEvents::LoadArrayByYearlySubject($this->intIdyearlySubject, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated DeptYearEventses
		 * @return int
		*/
		public function CountDeptYearEventses() {
			if ((is_null($this->intIdyearlySubject)))
				return 0;

			return DeptYearEvents::CountByYearlySubject($this->intIdyearlySubject);
		}

		/**
		 * Associates a DeptYearEvents
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function AssociateDeptYearEvents(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEvents on this unsaved YearlySubject.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEvents on this YearlySubject with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates a DeptYearEvents
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function UnassociateDeptYearEvents(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this unsaved YearlySubject.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this YearlySubject with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`yearly_subject` = null
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Unassociates all DeptYearEventses
		 * @return void
		*/
		public function UnassociateAllDeptYearEventses() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`yearly_subject` = null
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes an associated DeptYearEvents
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function DeleteAssociatedDeptYearEvents(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this unsaved YearlySubject.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this YearlySubject with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes all associated DeptYearEventses
		 * @return void
		*/
		public function DeleteAllDeptYearEventses() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEvents on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}


		// Related Objects' Methods for DeptYearExam
		//-------------------------------------------------------------------

		/**
		 * Gets all associated DeptYearExams as an array of DeptYearExam objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearExam[]
		*/
		public function GetDeptYearExamArray($objOptionalClauses = null) {
			if ((is_null($this->intIdyearlySubject)))
				return array();

			try {
				return DeptYearExam::LoadArrayByYearlySubject($this->intIdyearlySubject, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated DeptYearExams
		 * @return int
		*/
		public function CountDeptYearExams() {
			if ((is_null($this->intIdyearlySubject)))
				return 0;

			return DeptYearExam::CountByYearlySubject($this->intIdyearlySubject);
		}

		/**
		 * Associates a DeptYearExam
		 * @param DeptYearExam $objDeptYearExam
		 * @return void
		*/
		public function AssociateDeptYearExam(DeptYearExam $objDeptYearExam) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearExam on this unsaved YearlySubject.');
			if ((is_null($objDeptYearExam->YearlySubject)) || (is_null($objDeptYearExam->Exam)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearExam on this YearlySubject with an unsaved DeptYearExam.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_exam`
				SET
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($objDeptYearExam->YearlySubject) . ' AND
					`exam` = ' . $objDatabase->SqlVariable($objDeptYearExam->Exam) . '
			');
		}

		/**
		 * Unassociates a DeptYearExam
		 * @param DeptYearExam $objDeptYearExam
		 * @return void
		*/
		public function UnassociateDeptYearExam(DeptYearExam $objDeptYearExam) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearExam on this unsaved YearlySubject.');
			if ((is_null($objDeptYearExam->YearlySubject)) || (is_null($objDeptYearExam->Exam)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearExam on this YearlySubject with an unsaved DeptYearExam.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_exam`
				SET
					`yearly_subject` = null
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($objDeptYearExam->YearlySubject) . ' AND
					`exam` = ' . $objDatabase->SqlVariable($objDeptYearExam->Exam) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Unassociates all DeptYearExams
		 * @return void
		*/
		public function UnassociateAllDeptYearExams() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearExam on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_exam`
				SET
					`yearly_subject` = null
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes an associated DeptYearExam
		 * @param DeptYearExam $objDeptYearExam
		 * @return void
		*/
		public function DeleteAssociatedDeptYearExam(DeptYearExam $objDeptYearExam) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearExam on this unsaved YearlySubject.');
			if ((is_null($objDeptYearExam->YearlySubject)) || (is_null($objDeptYearExam->Exam)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearExam on this YearlySubject with an unsaved DeptYearExam.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_exam`
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($objDeptYearExam->YearlySubject) . ' AND
					`exam` = ' . $objDatabase->SqlVariable($objDeptYearExam->Exam) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes all associated DeptYearExams
		 * @return void
		*/
		public function DeleteAllDeptYearExams() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearExam on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_exam`
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}


		// Related Objects' Methods for EventHasGrade
		//-------------------------------------------------------------------

		/**
		 * Gets all associated EventHasGrades as an array of EventHasGrade objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EventHasGrade[]
		*/
		public function GetEventHasGradeArray($objOptionalClauses = null) {
			if ((is_null($this->intIdyearlySubject)))
				return array();

			try {
				return EventHasGrade::LoadArrayByYearlySubject($this->intIdyearlySubject, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated EventHasGrades
		 * @return int
		*/
		public function CountEventHasGrades() {
			if ((is_null($this->intIdyearlySubject)))
				return 0;

			return EventHasGrade::CountByYearlySubject($this->intIdyearlySubject);
		}

		/**
		 * Associates a EventHasGrade
		 * @param EventHasGrade $objEventHasGrade
		 * @return void
		*/
		public function AssociateEventHasGrade(EventHasGrade $objEventHasGrade) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEventHasGrade on this unsaved YearlySubject.');
			if ((is_null($objEventHasGrade->IdeventHasGrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEventHasGrade on this YearlySubject with an unsaved EventHasGrade.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event_has_grade`
				SET
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
				WHERE
					`idevent_has_grade` = ' . $objDatabase->SqlVariable($objEventHasGrade->IdeventHasGrade) . '
			');
		}

		/**
		 * Unassociates a EventHasGrade
		 * @param EventHasGrade $objEventHasGrade
		 * @return void
		*/
		public function UnassociateEventHasGrade(EventHasGrade $objEventHasGrade) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this unsaved YearlySubject.');
			if ((is_null($objEventHasGrade->IdeventHasGrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this YearlySubject with an unsaved EventHasGrade.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event_has_grade`
				SET
					`yearly_subject` = null
				WHERE
					`idevent_has_grade` = ' . $objDatabase->SqlVariable($objEventHasGrade->IdeventHasGrade) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Unassociates all EventHasGrades
		 * @return void
		*/
		public function UnassociateAllEventHasGrades() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event_has_grade`
				SET
					`yearly_subject` = null
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes an associated EventHasGrade
		 * @param EventHasGrade $objEventHasGrade
		 * @return void
		*/
		public function DeleteAssociatedEventHasGrade(EventHasGrade $objEventHasGrade) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this unsaved YearlySubject.');
			if ((is_null($objEventHasGrade->IdeventHasGrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this YearlySubject with an unsaved EventHasGrade.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event_has_grade`
				WHERE
					`idevent_has_grade` = ' . $objDatabase->SqlVariable($objEventHasGrade->IdeventHasGrade) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes all associated EventHasGrades
		 * @return void
		*/
		public function DeleteAllEventHasGrades() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event_has_grade`
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}


		// Related Objects' Methods for GradeCardAsSubject
		//-------------------------------------------------------------------

		/**
		 * Gets all associated GradeCardsAsSubject as an array of GradeCard objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		*/
		public function GetGradeCardAsSubjectArray($objOptionalClauses = null) {
			if ((is_null($this->intIdyearlySubject)))
				return array();

			try {
				return GradeCard::LoadArrayBySubject($this->intIdyearlySubject, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated GradeCardsAsSubject
		 * @return int
		*/
		public function CountGradeCardsAsSubject() {
			if ((is_null($this->intIdyearlySubject)))
				return 0;

			return GradeCard::CountBySubject($this->intIdyearlySubject);
		}

		/**
		 * Associates a GradeCardAsSubject
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function AssociateGradeCardAsSubject(GradeCard $objGradeCard) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGradeCardAsSubject on this unsaved YearlySubject.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGradeCardAsSubject on this YearlySubject with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . '
			');
		}

		/**
		 * Unassociates a GradeCardAsSubject
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function UnassociateGradeCardAsSubject(GradeCard $objGradeCard) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsSubject on this unsaved YearlySubject.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsSubject on this YearlySubject with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`subject` = null
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . ' AND
					`subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Unassociates all GradeCardsAsSubject
		 * @return void
		*/
		public function UnassociateAllGradeCardsAsSubject() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsSubject on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`subject` = null
				WHERE
					`subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes an associated GradeCardAsSubject
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function DeleteAssociatedGradeCardAsSubject(GradeCard $objGradeCard) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsSubject on this unsaved YearlySubject.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsSubject on this YearlySubject with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . ' AND
					`subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes all associated GradeCardsAsSubject
		 * @return void
		*/
		public function DeleteAllGradeCardsAsSubject() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsSubject on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`
				WHERE
					`subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}


		// Related Objects' Methods for ReEvaluation
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ReEvaluations as an array of ReEvaluation objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ReEvaluation[]
		*/
		public function GetReEvaluationArray($objOptionalClauses = null) {
			if ((is_null($this->intIdyearlySubject)))
				return array();

			try {
				return ReEvaluation::LoadArrayByYearlySubject($this->intIdyearlySubject, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ReEvaluations
		 * @return int
		*/
		public function CountReEvaluations() {
			if ((is_null($this->intIdyearlySubject)))
				return 0;

			return ReEvaluation::CountByYearlySubject($this->intIdyearlySubject);
		}

		/**
		 * Associates a ReEvaluation
		 * @param ReEvaluation $objReEvaluation
		 * @return void
		*/
		public function AssociateReEvaluation(ReEvaluation $objReEvaluation) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateReEvaluation on this unsaved YearlySubject.');
			if ((is_null($objReEvaluation->IdreEvaluation)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateReEvaluation on this YearlySubject with an unsaved ReEvaluation.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`re_evaluation`
				SET
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
				WHERE
					`idre_evaluation` = ' . $objDatabase->SqlVariable($objReEvaluation->IdreEvaluation) . '
			');
		}

		/**
		 * Unassociates a ReEvaluation
		 * @param ReEvaluation $objReEvaluation
		 * @return void
		*/
		public function UnassociateReEvaluation(ReEvaluation $objReEvaluation) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluation on this unsaved YearlySubject.');
			if ((is_null($objReEvaluation->IdreEvaluation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluation on this YearlySubject with an unsaved ReEvaluation.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`re_evaluation`
				SET
					`yearly_subject` = null
				WHERE
					`idre_evaluation` = ' . $objDatabase->SqlVariable($objReEvaluation->IdreEvaluation) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Unassociates all ReEvaluations
		 * @return void
		*/
		public function UnassociateAllReEvaluations() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluation on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`re_evaluation`
				SET
					`yearly_subject` = null
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes an associated ReEvaluation
		 * @param ReEvaluation $objReEvaluation
		 * @return void
		*/
		public function DeleteAssociatedReEvaluation(ReEvaluation $objReEvaluation) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluation on this unsaved YearlySubject.');
			if ((is_null($objReEvaluation->IdreEvaluation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluation on this YearlySubject with an unsaved ReEvaluation.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`re_evaluation`
				WHERE
					`idre_evaluation` = ' . $objDatabase->SqlVariable($objReEvaluation->IdreEvaluation) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes all associated ReEvaluations
		 * @return void
		*/
		public function DeleteAllReEvaluations() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluation on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`re_evaluation`
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}


		// Related Objects' Methods for StudAttendence
		//-------------------------------------------------------------------

		/**
		 * Gets all associated StudAttendences as an array of StudAttendence objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return StudAttendence[]
		*/
		public function GetStudAttendenceArray($objOptionalClauses = null) {
			if ((is_null($this->intIdyearlySubject)))
				return array();

			try {
				return StudAttendence::LoadArrayByYearlySubject($this->intIdyearlySubject, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated StudAttendences
		 * @return int
		*/
		public function CountStudAttendences() {
			if ((is_null($this->intIdyearlySubject)))
				return 0;

			return StudAttendence::CountByYearlySubject($this->intIdyearlySubject);
		}

		/**
		 * Associates a StudAttendence
		 * @param StudAttendence $objStudAttendence
		 * @return void
		*/
		public function AssociateStudAttendence(StudAttendence $objStudAttendence) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateStudAttendence on this unsaved YearlySubject.');
			if ((is_null($objStudAttendence->IdstudAttendence)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateStudAttendence on this YearlySubject with an unsaved StudAttendence.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`stud_attendence`
				SET
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
				WHERE
					`idstud_attendence` = ' . $objDatabase->SqlVariable($objStudAttendence->IdstudAttendence) . '
			');
		}

		/**
		 * Unassociates a StudAttendence
		 * @param StudAttendence $objStudAttendence
		 * @return void
		*/
		public function UnassociateStudAttendence(StudAttendence $objStudAttendence) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendence on this unsaved YearlySubject.');
			if ((is_null($objStudAttendence->IdstudAttendence)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendence on this YearlySubject with an unsaved StudAttendence.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`stud_attendence`
				SET
					`yearly_subject` = null
				WHERE
					`idstud_attendence` = ' . $objDatabase->SqlVariable($objStudAttendence->IdstudAttendence) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Unassociates all StudAttendences
		 * @return void
		*/
		public function UnassociateAllStudAttendences() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendence on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`stud_attendence`
				SET
					`yearly_subject` = null
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes an associated StudAttendence
		 * @param StudAttendence $objStudAttendence
		 * @return void
		*/
		public function DeleteAssociatedStudAttendence(StudAttendence $objStudAttendence) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendence on this unsaved YearlySubject.');
			if ((is_null($objStudAttendence->IdstudAttendence)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendence on this YearlySubject with an unsaved StudAttendence.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`stud_attendence`
				WHERE
					`idstud_attendence` = ' . $objDatabase->SqlVariable($objStudAttendence->IdstudAttendence) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes all associated StudAttendences
		 * @return void
		*/
		public function DeleteAllStudAttendences() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateStudAttendence on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`stud_attendence`
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}


		// Related Objects' Methods for SubjectToughtAsSubject
		//-------------------------------------------------------------------

		/**
		 * Gets all associated SubjectToughtsAsSubject as an array of SubjectTought objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SubjectTought[]
		*/
		public function GetSubjectToughtAsSubjectArray($objOptionalClauses = null) {
			if ((is_null($this->intIdyearlySubject)))
				return array();

			try {
				return SubjectTought::LoadArrayBySubject($this->intIdyearlySubject, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated SubjectToughtsAsSubject
		 * @return int
		*/
		public function CountSubjectToughtsAsSubject() {
			if ((is_null($this->intIdyearlySubject)))
				return 0;

			return SubjectTought::CountBySubject($this->intIdyearlySubject);
		}

		/**
		 * Associates a SubjectToughtAsSubject
		 * @param SubjectTought $objSubjectTought
		 * @return void
		*/
		public function AssociateSubjectToughtAsSubject(SubjectTought $objSubjectTought) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSubjectToughtAsSubject on this unsaved YearlySubject.');
			if ((is_null($objSubjectTought->IdsubjectTought)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSubjectToughtAsSubject on this YearlySubject with an unsaved SubjectTought.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`subject_tought`
				SET
					`subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
				WHERE
					`idsubject_tought` = ' . $objDatabase->SqlVariable($objSubjectTought->IdsubjectTought) . '
			');
		}

		/**
		 * Unassociates a SubjectToughtAsSubject
		 * @param SubjectTought $objSubjectTought
		 * @return void
		*/
		public function UnassociateSubjectToughtAsSubject(SubjectTought $objSubjectTought) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSubjectToughtAsSubject on this unsaved YearlySubject.');
			if ((is_null($objSubjectTought->IdsubjectTought)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSubjectToughtAsSubject on this YearlySubject with an unsaved SubjectTought.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`subject_tought`
				SET
					`subject` = null
				WHERE
					`idsubject_tought` = ' . $objDatabase->SqlVariable($objSubjectTought->IdsubjectTought) . ' AND
					`subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Unassociates all SubjectToughtsAsSubject
		 * @return void
		*/
		public function UnassociateAllSubjectToughtsAsSubject() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSubjectToughtAsSubject on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`subject_tought`
				SET
					`subject` = null
				WHERE
					`subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes an associated SubjectToughtAsSubject
		 * @param SubjectTought $objSubjectTought
		 * @return void
		*/
		public function DeleteAssociatedSubjectToughtAsSubject(SubjectTought $objSubjectTought) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSubjectToughtAsSubject on this unsaved YearlySubject.');
			if ((is_null($objSubjectTought->IdsubjectTought)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSubjectToughtAsSubject on this YearlySubject with an unsaved SubjectTought.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`subject_tought`
				WHERE
					`idsubject_tought` = ' . $objDatabase->SqlVariable($objSubjectTought->IdsubjectTought) . ' AND
					`subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes all associated SubjectToughtsAsSubject
		 * @return void
		*/
		public function DeleteAllSubjectToughtsAsSubject() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSubjectToughtAsSubject on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`subject_tought`
				WHERE
					`subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}


		// Related Objects' Methods for Timetable
		//-------------------------------------------------------------------

		/**
		 * Gets all associated Timetables as an array of Timetable objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Timetable[]
		*/
		public function GetTimetableArray($objOptionalClauses = null) {
			if ((is_null($this->intIdyearlySubject)))
				return array();

			try {
				return Timetable::LoadArrayByYearlySubject($this->intIdyearlySubject, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated Timetables
		 * @return int
		*/
		public function CountTimetables() {
			if ((is_null($this->intIdyearlySubject)))
				return 0;

			return Timetable::CountByYearlySubject($this->intIdyearlySubject);
		}

		/**
		 * Associates a Timetable
		 * @param Timetable $objTimetable
		 * @return void
		*/
		public function AssociateTimetable(Timetable $objTimetable) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateTimetable on this unsaved YearlySubject.');
			if ((is_null($objTimetable->Idtimetable)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateTimetable on this YearlySubject with an unsaved Timetable.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`timetable`
				SET
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
				WHERE
					`idtimetable` = ' . $objDatabase->SqlVariable($objTimetable->Idtimetable) . '
			');
		}

		/**
		 * Unassociates a Timetable
		 * @param Timetable $objTimetable
		 * @return void
		*/
		public function UnassociateTimetable(Timetable $objTimetable) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTimetable on this unsaved YearlySubject.');
			if ((is_null($objTimetable->Idtimetable)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTimetable on this YearlySubject with an unsaved Timetable.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`timetable`
				SET
					`yearly_subject` = null
				WHERE
					`idtimetable` = ' . $objDatabase->SqlVariable($objTimetable->Idtimetable) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Unassociates all Timetables
		 * @return void
		*/
		public function UnassociateAllTimetables() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTimetable on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`timetable`
				SET
					`yearly_subject` = null
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes an associated Timetable
		 * @param Timetable $objTimetable
		 * @return void
		*/
		public function DeleteAssociatedTimetable(Timetable $objTimetable) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTimetable on this unsaved YearlySubject.');
			if ((is_null($objTimetable->Idtimetable)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTimetable on this YearlySubject with an unsaved Timetable.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`timetable`
				WHERE
					`idtimetable` = ' . $objDatabase->SqlVariable($objTimetable->Idtimetable) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes all associated Timetables
		 * @return void
		*/
		public function DeleteAllTimetables() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateTimetable on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`timetable`
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}


		// Related Objects' Methods for YearlySubjectAsParrent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated YearlySubjectsAsParrent as an array of YearlySubject objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearlySubject[]
		*/
		public function GetYearlySubjectAsParrentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdyearlySubject)))
				return array();

			try {
				return YearlySubject::LoadArrayByParrent($this->intIdyearlySubject, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated YearlySubjectsAsParrent
		 * @return int
		*/
		public function CountYearlySubjectsAsParrent() {
			if ((is_null($this->intIdyearlySubject)))
				return 0;

			return YearlySubject::CountByParrent($this->intIdyearlySubject);
		}

		/**
		 * Associates a YearlySubjectAsParrent
		 * @param YearlySubject $objYearlySubject
		 * @return void
		*/
		public function AssociateYearlySubjectAsParrent(YearlySubject $objYearlySubject) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateYearlySubjectAsParrent on this unsaved YearlySubject.');
			if ((is_null($objYearlySubject->IdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateYearlySubjectAsParrent on this YearlySubject with an unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`yearly_subject`
				SET
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
				WHERE
					`idyearly_subject` = ' . $objDatabase->SqlVariable($objYearlySubject->IdyearlySubject) . '
			');
		}

		/**
		 * Unassociates a YearlySubjectAsParrent
		 * @param YearlySubject $objYearlySubject
		 * @return void
		*/
		public function UnassociateYearlySubjectAsParrent(YearlySubject $objYearlySubject) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubjectAsParrent on this unsaved YearlySubject.');
			if ((is_null($objYearlySubject->IdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubjectAsParrent on this YearlySubject with an unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`yearly_subject`
				SET
					`parrent` = null
				WHERE
					`idyearly_subject` = ' . $objDatabase->SqlVariable($objYearlySubject->IdyearlySubject) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Unassociates all YearlySubjectsAsParrent
		 * @return void
		*/
		public function UnassociateAllYearlySubjectsAsParrent() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubjectAsParrent on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`yearly_subject`
				SET
					`parrent` = null
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes an associated YearlySubjectAsParrent
		 * @param YearlySubject $objYearlySubject
		 * @return void
		*/
		public function DeleteAssociatedYearlySubjectAsParrent(YearlySubject $objYearlySubject) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubjectAsParrent on this unsaved YearlySubject.');
			if ((is_null($objYearlySubject->IdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubjectAsParrent on this YearlySubject with an unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`yearly_subject`
				WHERE
					`idyearly_subject` = ' . $objDatabase->SqlVariable($objYearlySubject->IdyearlySubject) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes all associated YearlySubjectsAsParrent
		 * @return void
		*/
		public function DeleteAllYearlySubjectsAsParrent() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearlySubjectAsParrent on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`yearly_subject`
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}


		// Related Objects' Methods for YearsubjectHasTopic
		//-------------------------------------------------------------------

		/**
		 * Gets all associated YearsubjectHasTopics as an array of YearsubjectHasTopic objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return YearsubjectHasTopic[]
		*/
		public function GetYearsubjectHasTopicArray($objOptionalClauses = null) {
			if ((is_null($this->intIdyearlySubject)))
				return array();

			try {
				return YearsubjectHasTopic::LoadArrayByYearlySubject($this->intIdyearlySubject, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated YearsubjectHasTopics
		 * @return int
		*/
		public function CountYearsubjectHasTopics() {
			if ((is_null($this->intIdyearlySubject)))
				return 0;

			return YearsubjectHasTopic::CountByYearlySubject($this->intIdyearlySubject);
		}

		/**
		 * Associates a YearsubjectHasTopic
		 * @param YearsubjectHasTopic $objYearsubjectHasTopic
		 * @return void
		*/
		public function AssociateYearsubjectHasTopic(YearsubjectHasTopic $objYearsubjectHasTopic) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateYearsubjectHasTopic on this unsaved YearlySubject.');
			if ((is_null($objYearsubjectHasTopic->IdyearsubjectHasTopic)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateYearsubjectHasTopic on this YearlySubject with an unsaved YearsubjectHasTopic.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`yearsubject_has_topic`
				SET
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
				WHERE
					`idyearsubject_has_topic` = ' . $objDatabase->SqlVariable($objYearsubjectHasTopic->IdyearsubjectHasTopic) . '
			');
		}

		/**
		 * Unassociates a YearsubjectHasTopic
		 * @param YearsubjectHasTopic $objYearsubjectHasTopic
		 * @return void
		*/
		public function UnassociateYearsubjectHasTopic(YearsubjectHasTopic $objYearsubjectHasTopic) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearsubjectHasTopic on this unsaved YearlySubject.');
			if ((is_null($objYearsubjectHasTopic->IdyearsubjectHasTopic)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearsubjectHasTopic on this YearlySubject with an unsaved YearsubjectHasTopic.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`yearsubject_has_topic`
				SET
					`yearly_subject` = null
				WHERE
					`idyearsubject_has_topic` = ' . $objDatabase->SqlVariable($objYearsubjectHasTopic->IdyearsubjectHasTopic) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Unassociates all YearsubjectHasTopics
		 * @return void
		*/
		public function UnassociateAllYearsubjectHasTopics() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearsubjectHasTopic on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`yearsubject_has_topic`
				SET
					`yearly_subject` = null
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes an associated YearsubjectHasTopic
		 * @param YearsubjectHasTopic $objYearsubjectHasTopic
		 * @return void
		*/
		public function DeleteAssociatedYearsubjectHasTopic(YearsubjectHasTopic $objYearsubjectHasTopic) {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearsubjectHasTopic on this unsaved YearlySubject.');
			if ((is_null($objYearsubjectHasTopic->IdyearsubjectHasTopic)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearsubjectHasTopic on this YearlySubject with an unsaved YearsubjectHasTopic.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`yearsubject_has_topic`
				WHERE
					`idyearsubject_has_topic` = ' . $objDatabase->SqlVariable($objYearsubjectHasTopic->IdyearsubjectHasTopic) . ' AND
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}

		/**
		 * Deletes all associated YearsubjectHasTopics
		 * @return void
		*/
		public function DeleteAllYearsubjectHasTopics() {
			if ((is_null($this->intIdyearlySubject)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateYearsubjectHasTopic on this unsaved YearlySubject.');

			// Get the Database Object for this Class
			$objDatabase = YearlySubject::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`yearsubject_has_topic`
				WHERE
					`yearly_subject` = ' . $objDatabase->SqlVariable($this->intIdyearlySubject) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "yearly_subject";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[YearlySubject::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="YearlySubject"><sequence>';
			$strToReturn .= '<element name="IdyearlySubject" type="xsd:int"/>';
			$strToReturn .= '<element name="Code" type="xsd:string"/>';
			$strToReturn .= '<element name="SubjectObject" type="xsd1:Subject"/>';
			$strToReturn .= '<element name="DeptYearObject" type="xsd1:DeptYear"/>';
			$strToReturn .= '<element name="Lab" type="xsd:int"/>';
			$strToReturn .= '<element name="Tusion" type="xsd:int"/>';
			$strToReturn .= '<element name="Practical" type="xsd:int"/>';
			$strToReturn .= '<element name="Credit" type="xsd:int"/>';
			$strToReturn .= '<element name="CourseGrpObject" type="xsd1:CourseGrp"/>';
			$strToReturn .= '<element name="MinPassing" type="xsd:int"/>';
			$strToReturn .= '<element name="ParrentObject" type="xsd1:YearlySubject"/>';
			$strToReturn .= '<element name="Seq" type="xsd:int"/>';
			$strToReturn .= '<element name="Visible" type="xsd:boolean"/>';
			$strToReturn .= '<element name="GadeModifyLock" type="xsd:boolean"/>';
			$strToReturn .= '<element name="Mean" type="xsd:string"/>';
			$strToReturn .= '<element name="Sd" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('YearlySubject', $strComplexTypeArray)) {
				$strComplexTypeArray['YearlySubject'] = YearlySubject::GetSoapComplexTypeXml();
				Subject::AlterSoapComplexTypeArray($strComplexTypeArray);
				DeptYear::AlterSoapComplexTypeArray($strComplexTypeArray);
				CourseGrp::AlterSoapComplexTypeArray($strComplexTypeArray);
				YearlySubject::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, YearlySubject::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new YearlySubject();
			if (property_exists($objSoapObject, 'IdyearlySubject'))
				$objToReturn->intIdyearlySubject = $objSoapObject->IdyearlySubject;
			if (property_exists($objSoapObject, 'Code'))
				$objToReturn->strCode = $objSoapObject->Code;
			if ((property_exists($objSoapObject, 'SubjectObject')) &&
				($objSoapObject->SubjectObject))
				$objToReturn->SubjectObject = Subject::GetObjectFromSoapObject($objSoapObject->SubjectObject);
			if ((property_exists($objSoapObject, 'DeptYearObject')) &&
				($objSoapObject->DeptYearObject))
				$objToReturn->DeptYearObject = DeptYear::GetObjectFromSoapObject($objSoapObject->DeptYearObject);
			if (property_exists($objSoapObject, 'Lab'))
				$objToReturn->intLab = $objSoapObject->Lab;
			if (property_exists($objSoapObject, 'Tusion'))
				$objToReturn->intTusion = $objSoapObject->Tusion;
			if (property_exists($objSoapObject, 'Practical'))
				$objToReturn->intPractical = $objSoapObject->Practical;
			if (property_exists($objSoapObject, 'Credit'))
				$objToReturn->intCredit = $objSoapObject->Credit;
			if ((property_exists($objSoapObject, 'CourseGrpObject')) &&
				($objSoapObject->CourseGrpObject))
				$objToReturn->CourseGrpObject = CourseGrp::GetObjectFromSoapObject($objSoapObject->CourseGrpObject);
			if (property_exists($objSoapObject, 'MinPassing'))
				$objToReturn->intMinPassing = $objSoapObject->MinPassing;
			if ((property_exists($objSoapObject, 'ParrentObject')) &&
				($objSoapObject->ParrentObject))
				$objToReturn->ParrentObject = YearlySubject::GetObjectFromSoapObject($objSoapObject->ParrentObject);
			if (property_exists($objSoapObject, 'Seq'))
				$objToReturn->intSeq = $objSoapObject->Seq;
			if (property_exists($objSoapObject, 'Visible'))
				$objToReturn->blnVisible = $objSoapObject->Visible;
			if (property_exists($objSoapObject, 'GadeModifyLock'))
				$objToReturn->blnGadeModifyLock = $objSoapObject->GadeModifyLock;
			if (property_exists($objSoapObject, 'Mean'))
				$objToReturn->strMean = $objSoapObject->Mean;
			if (property_exists($objSoapObject, 'Sd'))
				$objToReturn->strSd = $objSoapObject->Sd;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, YearlySubject::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objSubjectObject)
				$objObject->objSubjectObject = Subject::GetSoapObjectFromObject($objObject->objSubjectObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSubject = null;
			if ($objObject->objDeptYearObject)
				$objObject->objDeptYearObject = DeptYear::GetSoapObjectFromObject($objObject->objDeptYearObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDeptYear = null;
			if ($objObject->objCourseGrpObject)
				$objObject->objCourseGrpObject = CourseGrp::GetSoapObjectFromObject($objObject->objCourseGrpObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCourseGrp = null;
			if ($objObject->objParrentObject)
				$objObject->objParrentObject = YearlySubject::GetSoapObjectFromObject($objObject->objParrentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intParrent = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdyearlySubject'] = $this->intIdyearlySubject;
			$iArray['Code'] = $this->strCode;
			$iArray['Subject'] = $this->intSubject;
			$iArray['DeptYear'] = $this->intDeptYear;
			$iArray['Lab'] = $this->intLab;
			$iArray['Tusion'] = $this->intTusion;
			$iArray['Practical'] = $this->intPractical;
			$iArray['Credit'] = $this->intCredit;
			$iArray['CourseGrp'] = $this->intCourseGrp;
			$iArray['MinPassing'] = $this->intMinPassing;
			$iArray['Parrent'] = $this->intParrent;
			$iArray['Seq'] = $this->intSeq;
			$iArray['Visible'] = $this->blnVisible;
			$iArray['GadeModifyLock'] = $this->blnGadeModifyLock;
			$iArray['Mean'] = $this->strMean;
			$iArray['Sd'] = $this->strSd;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdyearlySubject ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdyearlySubject
     * @property-read QQNode $Code
     * @property-read QQNode $Subject
     * @property-read QQNodeSubject $SubjectObject
     * @property-read QQNode $DeptYear
     * @property-read QQNodeDeptYear $DeptYearObject
     * @property-read QQNode $Lab
     * @property-read QQNode $Tusion
     * @property-read QQNode $Practical
     * @property-read QQNode $Credit
     * @property-read QQNode $CourseGrp
     * @property-read QQNodeCourseGrp $CourseGrpObject
     * @property-read QQNode $MinPassing
     * @property-read QQNode $Parrent
     * @property-read QQNodeYearlySubject $ParrentObject
     * @property-read QQNode $Seq
     * @property-read QQNode $Visible
     * @property-read QQNode $GadeModifyLock
     * @property-read QQNode $Mean
     * @property-read QQNode $Sd
     *
     *
     * @property-read QQReverseReferenceNodeAppliedExam $AppliedExam
     * @property-read QQReverseReferenceNodeApplyGradeImproment $ApplyGradeImpromentAsSubject
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEvents
     * @property-read QQReverseReferenceNodeDeptYearExam $DeptYearExam
     * @property-read QQReverseReferenceNodeEventHasGrade $EventHasGrade
     * @property-read QQReverseReferenceNodeGradeCard $GradeCardAsSubject
     * @property-read QQReverseReferenceNodeReEvaluation $ReEvaluation
     * @property-read QQReverseReferenceNodeStudAttendence $StudAttendence
     * @property-read QQReverseReferenceNodeSubjectTought $SubjectToughtAsSubject
     * @property-read QQReverseReferenceNodeTimetable $Timetable
     * @property-read QQReverseReferenceNodeYearlySubject $YearlySubjectAsParrent
     * @property-read QQReverseReferenceNodeYearsubjectHasTopic $YearsubjectHasTopic

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeYearlySubject extends QQNode {
		protected $strTableName = 'yearly_subject';
		protected $strPrimaryKey = 'idyearly_subject';
		protected $strClassName = 'YearlySubject';
		public function __get($strName) {
			switch ($strName) {
				case 'IdyearlySubject':
					return new QQNode('idyearly_subject', 'IdyearlySubject', 'Integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'VarChar', $this);
				case 'Subject':
					return new QQNode('subject', 'Subject', 'Integer', $this);
				case 'SubjectObject':
					return new QQNodeSubject('subject', 'SubjectObject', 'Integer', $this);
				case 'DeptYear':
					return new QQNode('dept_year', 'DeptYear', 'Integer', $this);
				case 'DeptYearObject':
					return new QQNodeDeptYear('dept_year', 'DeptYearObject', 'Integer', $this);
				case 'Lab':
					return new QQNode('lab', 'Lab', 'Integer', $this);
				case 'Tusion':
					return new QQNode('tusion', 'Tusion', 'Integer', $this);
				case 'Practical':
					return new QQNode('practical', 'Practical', 'Integer', $this);
				case 'Credit':
					return new QQNode('credit', 'Credit', 'Integer', $this);
				case 'CourseGrp':
					return new QQNode('course_grp', 'CourseGrp', 'Integer', $this);
				case 'CourseGrpObject':
					return new QQNodeCourseGrp('course_grp', 'CourseGrpObject', 'Integer', $this);
				case 'MinPassing':
					return new QQNode('min_passing', 'MinPassing', 'Integer', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'Integer', $this);
				case 'ParrentObject':
					return new QQNodeYearlySubject('parrent', 'ParrentObject', 'Integer', $this);
				case 'Seq':
					return new QQNode('seq', 'Seq', 'Integer', $this);
				case 'Visible':
					return new QQNode('visible', 'Visible', 'Bit', $this);
				case 'GadeModifyLock':
					return new QQNode('gade_modify_lock', 'GadeModifyLock', 'Bit', $this);
				case 'Mean':
					return new QQNode('mean', 'Mean', 'VarChar', $this);
				case 'Sd':
					return new QQNode('sd', 'Sd', 'VarChar', $this);
				case 'AppliedExam':
					return new QQReverseReferenceNodeAppliedExam($this, 'appliedexam', 'reverse_reference', 'yearly_subject');
				case 'ApplyGradeImpromentAsSubject':
					return new QQReverseReferenceNodeApplyGradeImproment($this, 'applygradeimpromentassubject', 'reverse_reference', 'subject');
				case 'DeptYearEvents':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyearevents', 'reverse_reference', 'yearly_subject');
				case 'DeptYearExam':
					return new QQReverseReferenceNodeDeptYearExam($this, 'deptyearexam', 'reverse_reference', 'yearly_subject');
				case 'EventHasGrade':
					return new QQReverseReferenceNodeEventHasGrade($this, 'eventhasgrade', 'reverse_reference', 'yearly_subject');
				case 'GradeCardAsSubject':
					return new QQReverseReferenceNodeGradeCard($this, 'gradecardassubject', 'reverse_reference', 'subject');
				case 'ReEvaluation':
					return new QQReverseReferenceNodeReEvaluation($this, 'reevaluation', 'reverse_reference', 'yearly_subject');
				case 'StudAttendence':
					return new QQReverseReferenceNodeStudAttendence($this, 'studattendence', 'reverse_reference', 'yearly_subject');
				case 'SubjectToughtAsSubject':
					return new QQReverseReferenceNodeSubjectTought($this, 'subjecttoughtassubject', 'reverse_reference', 'subject');
				case 'Timetable':
					return new QQReverseReferenceNodeTimetable($this, 'timetable', 'reverse_reference', 'yearly_subject');
				case 'YearlySubjectAsParrent':
					return new QQReverseReferenceNodeYearlySubject($this, 'yearlysubjectasparrent', 'reverse_reference', 'parrent');
				case 'YearsubjectHasTopic':
					return new QQReverseReferenceNodeYearsubjectHasTopic($this, 'yearsubjecthastopic', 'reverse_reference', 'yearly_subject');

				case '_PrimaryKeyNode':
					return new QQNode('idyearly_subject', 'IdyearlySubject', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdyearlySubject
     * @property-read QQNode $Code
     * @property-read QQNode $Subject
     * @property-read QQNodeSubject $SubjectObject
     * @property-read QQNode $DeptYear
     * @property-read QQNodeDeptYear $DeptYearObject
     * @property-read QQNode $Lab
     * @property-read QQNode $Tusion
     * @property-read QQNode $Practical
     * @property-read QQNode $Credit
     * @property-read QQNode $CourseGrp
     * @property-read QQNodeCourseGrp $CourseGrpObject
     * @property-read QQNode $MinPassing
     * @property-read QQNode $Parrent
     * @property-read QQNodeYearlySubject $ParrentObject
     * @property-read QQNode $Seq
     * @property-read QQNode $Visible
     * @property-read QQNode $GadeModifyLock
     * @property-read QQNode $Mean
     * @property-read QQNode $Sd
     *
     *
     * @property-read QQReverseReferenceNodeAppliedExam $AppliedExam
     * @property-read QQReverseReferenceNodeApplyGradeImproment $ApplyGradeImpromentAsSubject
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEvents
     * @property-read QQReverseReferenceNodeDeptYearExam $DeptYearExam
     * @property-read QQReverseReferenceNodeEventHasGrade $EventHasGrade
     * @property-read QQReverseReferenceNodeGradeCard $GradeCardAsSubject
     * @property-read QQReverseReferenceNodeReEvaluation $ReEvaluation
     * @property-read QQReverseReferenceNodeStudAttendence $StudAttendence
     * @property-read QQReverseReferenceNodeSubjectTought $SubjectToughtAsSubject
     * @property-read QQReverseReferenceNodeTimetable $Timetable
     * @property-read QQReverseReferenceNodeYearlySubject $YearlySubjectAsParrent
     * @property-read QQReverseReferenceNodeYearsubjectHasTopic $YearsubjectHasTopic

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeYearlySubject extends QQReverseReferenceNode {
		protected $strTableName = 'yearly_subject';
		protected $strPrimaryKey = 'idyearly_subject';
		protected $strClassName = 'YearlySubject';
		public function __get($strName) {
			switch ($strName) {
				case 'IdyearlySubject':
					return new QQNode('idyearly_subject', 'IdyearlySubject', 'integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'string', $this);
				case 'Subject':
					return new QQNode('subject', 'Subject', 'integer', $this);
				case 'SubjectObject':
					return new QQNodeSubject('subject', 'SubjectObject', 'integer', $this);
				case 'DeptYear':
					return new QQNode('dept_year', 'DeptYear', 'integer', $this);
				case 'DeptYearObject':
					return new QQNodeDeptYear('dept_year', 'DeptYearObject', 'integer', $this);
				case 'Lab':
					return new QQNode('lab', 'Lab', 'integer', $this);
				case 'Tusion':
					return new QQNode('tusion', 'Tusion', 'integer', $this);
				case 'Practical':
					return new QQNode('practical', 'Practical', 'integer', $this);
				case 'Credit':
					return new QQNode('credit', 'Credit', 'integer', $this);
				case 'CourseGrp':
					return new QQNode('course_grp', 'CourseGrp', 'integer', $this);
				case 'CourseGrpObject':
					return new QQNodeCourseGrp('course_grp', 'CourseGrpObject', 'integer', $this);
				case 'MinPassing':
					return new QQNode('min_passing', 'MinPassing', 'integer', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'integer', $this);
				case 'ParrentObject':
					return new QQNodeYearlySubject('parrent', 'ParrentObject', 'integer', $this);
				case 'Seq':
					return new QQNode('seq', 'Seq', 'integer', $this);
				case 'Visible':
					return new QQNode('visible', 'Visible', 'boolean', $this);
				case 'GadeModifyLock':
					return new QQNode('gade_modify_lock', 'GadeModifyLock', 'boolean', $this);
				case 'Mean':
					return new QQNode('mean', 'Mean', 'string', $this);
				case 'Sd':
					return new QQNode('sd', 'Sd', 'string', $this);
				case 'AppliedExam':
					return new QQReverseReferenceNodeAppliedExam($this, 'appliedexam', 'reverse_reference', 'yearly_subject');
				case 'ApplyGradeImpromentAsSubject':
					return new QQReverseReferenceNodeApplyGradeImproment($this, 'applygradeimpromentassubject', 'reverse_reference', 'subject');
				case 'DeptYearEvents':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyearevents', 'reverse_reference', 'yearly_subject');
				case 'DeptYearExam':
					return new QQReverseReferenceNodeDeptYearExam($this, 'deptyearexam', 'reverse_reference', 'yearly_subject');
				case 'EventHasGrade':
					return new QQReverseReferenceNodeEventHasGrade($this, 'eventhasgrade', 'reverse_reference', 'yearly_subject');
				case 'GradeCardAsSubject':
					return new QQReverseReferenceNodeGradeCard($this, 'gradecardassubject', 'reverse_reference', 'subject');
				case 'ReEvaluation':
					return new QQReverseReferenceNodeReEvaluation($this, 'reevaluation', 'reverse_reference', 'yearly_subject');
				case 'StudAttendence':
					return new QQReverseReferenceNodeStudAttendence($this, 'studattendence', 'reverse_reference', 'yearly_subject');
				case 'SubjectToughtAsSubject':
					return new QQReverseReferenceNodeSubjectTought($this, 'subjecttoughtassubject', 'reverse_reference', 'subject');
				case 'Timetable':
					return new QQReverseReferenceNodeTimetable($this, 'timetable', 'reverse_reference', 'yearly_subject');
				case 'YearlySubjectAsParrent':
					return new QQReverseReferenceNodeYearlySubject($this, 'yearlysubjectasparrent', 'reverse_reference', 'parrent');
				case 'YearsubjectHasTopic':
					return new QQReverseReferenceNodeYearsubjectHasTopic($this, 'yearsubjecthastopic', 'reverse_reference', 'yearly_subject');

				case '_PrimaryKeyNode':
					return new QQNode('idyearly_subject', 'IdyearlySubject', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
