<?php
	/**
	 * The abstract SalarysheetGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Salarysheet subclass which
	 * extends this SalarysheetGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Salarysheet class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idsalarysheet the value for intIdsalarysheet (Read-Only PK)
	 * @property string $Code the value for strCode (Unique)
	 * @property QDateTime $Date the value for dttDate (Not Null)
	 * @property QDateTime $ForMonth the value for dttForMonth (Not Null)
	 * @property integer $Department the value for intDepartment (Not Null)
	 * @property integer $Designation the value for intDesignation 
	 * @property QDateTime $PaymentDate the value for dttPaymentDate 
	 * @property QDateTime $DeductionDate the value for dttDeductionDate 
	 * @property QDateTime $DepositeDate the value for dttDepositeDate 
	 * @property Role $DepartmentObject the value for the Role object referenced by intDepartment (Not Null)
	 * @property Role $DesignationObject the value for the Role object referenced by intDesignation 
	 * @property IncomeTaxDetails $IncomeTaxDetails the value for the IncomeTaxDetails object that uniquely references this Salarysheet
	 * @property-read SalarysheetApproval $_SalarysheetApproval the value for the private _objSalarysheetApproval (Read-Only) if set due to an expansion on the salarysheet_approval.salarysheet reverse relationship
	 * @property-read SalarysheetApproval[] $_SalarysheetApprovalArray the value for the private _objSalarysheetApprovalArray (Read-Only) if set due to an ExpandAsArray on the salarysheet_approval.salarysheet reverse relationship
	 * @property-read SalarysheetHasEmployee $_SalarysheetHasEmployee the value for the private _objSalarysheetHasEmployee (Read-Only) if set due to an expansion on the salarysheet_has_employee.salarysheet reverse relationship
	 * @property-read SalarysheetHasEmployee[] $_SalarysheetHasEmployeeArray the value for the private _objSalarysheetHasEmployeeArray (Read-Only) if set due to an ExpandAsArray on the salarysheet_has_employee.salarysheet reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class SalarysheetGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column salarysheet.idsalarysheet
		 * @var integer intIdsalarysheet
		 */
		protected $intIdsalarysheet;
		const IdsalarysheetDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet.code
		 * @var string strCode
		 */
		protected $strCode;
		const CodeMaxLength = 45;
		const CodeDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet.date
		 * @var QDateTime dttDate
		 */
		protected $dttDate;
		const DateDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet.for_month
		 * @var QDateTime dttForMonth
		 */
		protected $dttForMonth;
		const ForMonthDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet.department
		 * @var integer intDepartment
		 */
		protected $intDepartment;
		const DepartmentDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet.designation
		 * @var integer intDesignation
		 */
		protected $intDesignation;
		const DesignationDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet.payment_date
		 * @var QDateTime dttPaymentDate
		 */
		protected $dttPaymentDate;
		const PaymentDateDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet.deduction_date
		 * @var QDateTime dttDeductionDate
		 */
		protected $dttDeductionDate;
		const DeductionDateDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet.deposite_date
		 * @var QDateTime dttDepositeDate
		 */
		protected $dttDepositeDate;
		const DepositeDateDefault = null;


		/**
		 * Private member variable that stores a reference to a single SalarysheetApproval object
		 * (of type SalarysheetApproval), if this Salarysheet object was restored with
		 * an expansion on the salarysheet_approval association table.
		 * @var SalarysheetApproval _objSalarysheetApproval;
		 */
		private $_objSalarysheetApproval;

		/**
		 * Private member variable that stores a reference to an array of SalarysheetApproval objects
		 * (of type SalarysheetApproval[]), if this Salarysheet object was restored with
		 * an ExpandAsArray on the salarysheet_approval association table.
		 * @var SalarysheetApproval[] _objSalarysheetApprovalArray;
		 */
		private $_objSalarysheetApprovalArray = null;

		/**
		 * Private member variable that stores a reference to a single SalarysheetHasEmployee object
		 * (of type SalarysheetHasEmployee), if this Salarysheet object was restored with
		 * an expansion on the salarysheet_has_employee association table.
		 * @var SalarysheetHasEmployee _objSalarysheetHasEmployee;
		 */
		private $_objSalarysheetHasEmployee;

		/**
		 * Private member variable that stores a reference to an array of SalarysheetHasEmployee objects
		 * (of type SalarysheetHasEmployee[]), if this Salarysheet object was restored with
		 * an ExpandAsArray on the salarysheet_has_employee association table.
		 * @var SalarysheetHasEmployee[] _objSalarysheetHasEmployeeArray;
		 */
		private $_objSalarysheetHasEmployeeArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salarysheet.department.
		 *
		 * NOTE: Always use the DepartmentObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objDepartmentObject
		 */
		protected $objDepartmentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salarysheet.designation.
		 *
		 * NOTE: Always use the DesignationObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objDesignationObject
		 */
		protected $objDesignationObject;

		/**
		 * Protected member variable that contains the object which points to
		 * this object by the reference in the unique database column income_tax_details.idincome_tax_details.
		 *
		 * NOTE: Always use the IncomeTaxDetails property getter to correctly retrieve this IncomeTaxDetails object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var IncomeTaxDetails objIncomeTaxDetails
		 */
		protected $objIncomeTaxDetails;

		/**
		 * Used internally to manage whether the adjoined IncomeTaxDetails object
		 * needs to be updated on save.
		 *
		 * NOTE: Do not manually update this value
		 */
		protected $blnDirtyIncomeTaxDetails;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdsalarysheet = Salarysheet::IdsalarysheetDefault;
			$this->strCode = Salarysheet::CodeDefault;
			$this->dttDate = (Salarysheet::DateDefault === null)?null:new QDateTime(Salarysheet::DateDefault);
			$this->dttForMonth = (Salarysheet::ForMonthDefault === null)?null:new QDateTime(Salarysheet::ForMonthDefault);
			$this->intDepartment = Salarysheet::DepartmentDefault;
			$this->intDesignation = Salarysheet::DesignationDefault;
			$this->dttPaymentDate = (Salarysheet::PaymentDateDefault === null)?null:new QDateTime(Salarysheet::PaymentDateDefault);
			$this->dttDeductionDate = (Salarysheet::DeductionDateDefault === null)?null:new QDateTime(Salarysheet::DeductionDateDefault);
			$this->dttDepositeDate = (Salarysheet::DepositeDateDefault === null)?null:new QDateTime(Salarysheet::DepositeDateDefault);
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Salarysheet from PK Info
		 * @param integer $intIdsalarysheet
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Salarysheet
		 */
		public static function Load($intIdsalarysheet, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Salarysheet', $intIdsalarysheet);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Salarysheet::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Salarysheet()->Idsalarysheet, $intIdsalarysheet)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Salarysheets
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Salarysheet[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Salarysheet::QueryArray to perform the LoadAll query
			try {
				return Salarysheet::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Salarysheets
		 * @return int
		 */
		public static function CountAll() {
			// Call Salarysheet::QueryCount to perform the CountAll query
			return Salarysheet::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();

			// Create/Build out the QueryBuilder object with Salarysheet-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'salarysheet');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Salarysheet::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('salarysheet');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Salarysheet object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Salarysheet the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Salarysheet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Salarysheet object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Salarysheet::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Salarysheet::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Salarysheet objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Salarysheet[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Salarysheet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Salarysheet::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Salarysheet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Salarysheet objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Salarysheet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();

			$strQuery = Salarysheet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/salarysheet', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Salarysheet::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Salarysheet
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'salarysheet';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idsalarysheet', $strAliasPrefix . 'idsalarysheet');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idsalarysheet', $strAliasPrefix . 'idsalarysheet');
			    $objBuilder->AddSelectItem($strTableName, 'code', $strAliasPrefix . 'code');
			    $objBuilder->AddSelectItem($strTableName, 'date', $strAliasPrefix . 'date');
			    $objBuilder->AddSelectItem($strTableName, 'for_month', $strAliasPrefix . 'for_month');
			    $objBuilder->AddSelectItem($strTableName, 'department', $strAliasPrefix . 'department');
			    $objBuilder->AddSelectItem($strTableName, 'designation', $strAliasPrefix . 'designation');
			    $objBuilder->AddSelectItem($strTableName, 'payment_date', $strAliasPrefix . 'payment_date');
			    $objBuilder->AddSelectItem($strTableName, 'deduction_date', $strAliasPrefix . 'deduction_date');
			    $objBuilder->AddSelectItem($strTableName, 'deposite_date', $strAliasPrefix . 'deposite_date');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Salarysheet from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Salarysheet::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Salarysheet
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idsalarysheet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdsalarysheet == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'salarysheet__';


						// Expanding reverse references: SalarysheetApproval
						$strAlias = $strAliasPrefix . 'salarysheetapproval__idsalarysheet_approval';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objSalarysheetApprovalArray)
								$objPreviousItem->_objSalarysheetApprovalArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objSalarysheetApprovalArray)) {
								$objPreviousChildItems = $objPreviousItem->_objSalarysheetApprovalArray;
								$objChildItem = SalarysheetApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarysheetapproval__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objSalarysheetApprovalArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objSalarysheetApprovalArray[] = SalarysheetApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarysheetapproval__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: SalarysheetHasEmployee
						$strAlias = $strAliasPrefix . 'salarysheethasemployee__idsalarysheet_has_employee';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objSalarysheetHasEmployeeArray)
								$objPreviousItem->_objSalarysheetHasEmployeeArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objSalarysheetHasEmployeeArray)) {
								$objPreviousChildItems = $objPreviousItem->_objSalarysheetHasEmployeeArray;
								$objChildItem = SalarysheetHasEmployee::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarysheethasemployee__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objSalarysheetHasEmployeeArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objSalarysheetHasEmployeeArray[] = SalarysheetHasEmployee::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarysheethasemployee__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'salarysheet__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Salarysheet object
			$objToReturn = new Salarysheet();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idsalarysheet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdsalarysheet = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'for_month';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttForMonth = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'department';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDepartment = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'designation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDesignation = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'payment_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttPaymentDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'deduction_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDeductionDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'deposite_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDepositeDate = $objDbRow->GetColumn($strAliasName, 'Date');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idsalarysheet != $objPreviousItem->Idsalarysheet) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objSalarysheetApprovalArray);
					$cnt = count($objToReturn->_objSalarysheetApprovalArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objSalarysheetApprovalArray, $objToReturn->_objSalarysheetApprovalArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objSalarysheetHasEmployeeArray);
					$cnt = count($objToReturn->_objSalarysheetHasEmployeeArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objSalarysheetHasEmployeeArray, $objToReturn->_objSalarysheetHasEmployeeArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'salarysheet__';

			// Check for DepartmentObject Early Binding
			$strAlias = $strAliasPrefix . 'department__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDepartmentObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'department__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DesignationObject Early Binding
			$strAlias = $strAliasPrefix . 'designation__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDesignationObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'designation__', $strExpandAsArrayNodes, null, $strColumnAliasArray);


			// Check for IncomeTaxDetails Unique ReverseReference Binding
			$strAlias = $strAliasPrefix . 'incometaxdetails__idincome_tax_details';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if ($objDbRow->ColumnExists($strAliasName)) {
				if (!is_null($objDbRow->GetColumn($strAliasName)))
					$objToReturn->objIncomeTaxDetails = IncomeTaxDetails::InstantiateDbRow($objDbRow, $strAliasPrefix . 'incometaxdetails__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					// We ATTEMPTED to do an Early Bind but the Object Doesn't Exist
					// Let's set to FALSE so that the object knows not to try and re-query again
					$objToReturn->objIncomeTaxDetails = false;
			}



			// Check for SalarysheetApproval Virtual Binding
			$strAlias = $strAliasPrefix . 'salarysheetapproval__idsalarysheet_approval';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objSalarysheetApprovalArray)
				$objToReturn->_objSalarysheetApprovalArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objSalarysheetApprovalArray[] = SalarysheetApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarysheetapproval__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objSalarysheetApproval = SalarysheetApproval::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarysheetapproval__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for SalarysheetHasEmployee Virtual Binding
			$strAlias = $strAliasPrefix . 'salarysheethasemployee__idsalarysheet_has_employee';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objSalarysheetHasEmployeeArray)
				$objToReturn->_objSalarysheetHasEmployeeArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objSalarysheetHasEmployeeArray[] = SalarysheetHasEmployee::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarysheethasemployee__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objSalarysheetHasEmployee = SalarysheetHasEmployee::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarysheethasemployee__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Salarysheets from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Salarysheet[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Salarysheet::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Salarysheet::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Salarysheet object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Salarysheet next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Salarysheet::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Salarysheet object,
		 * by Idsalarysheet Index(es)
		 * @param integer $intIdsalarysheet
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Salarysheet
		*/
		public static function LoadByIdsalarysheet($intIdsalarysheet, $objOptionalClauses = null) {
			return Salarysheet::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Salarysheet()->Idsalarysheet, $intIdsalarysheet)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single Salarysheet object,
		 * by Code Index(es)
		 * @param string $strCode
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Salarysheet
		*/
		public static function LoadByCode($strCode, $objOptionalClauses = null) {
			return Salarysheet::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Salarysheet()->Code, $strCode)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Salarysheet objects,
		 * by Designation Index(es)
		 * @param integer $intDesignation
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Salarysheet[]
		*/
		public static function LoadArrayByDesignation($intDesignation, $objOptionalClauses = null) {
			// Call Salarysheet::QueryArray to perform the LoadArrayByDesignation query
			try {
				return Salarysheet::QueryArray(
					QQ::Equal(QQN::Salarysheet()->Designation, $intDesignation),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Salarysheets
		 * by Designation Index(es)
		 * @param integer $intDesignation
		 * @return int
		*/
		public static function CountByDesignation($intDesignation) {
			// Call Salarysheet::QueryCount to perform the CountByDesignation query
			return Salarysheet::QueryCount(
				QQ::Equal(QQN::Salarysheet()->Designation, $intDesignation)
			);
		}

		/**
		 * Load an array of Salarysheet objects,
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Salarysheet[]
		*/
		public static function LoadArrayByDepartment($intDepartment, $objOptionalClauses = null) {
			// Call Salarysheet::QueryArray to perform the LoadArrayByDepartment query
			try {
				return Salarysheet::QueryArray(
					QQ::Equal(QQN::Salarysheet()->Department, $intDepartment),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Salarysheets
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @return int
		*/
		public static function CountByDepartment($intDepartment) {
			// Call Salarysheet::QueryCount to perform the CountByDepartment query
			return Salarysheet::QueryCount(
				QQ::Equal(QQN::Salarysheet()->Department, $intDepartment)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Salarysheet
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `salarysheet` (
							`code`,
							`date`,
							`for_month`,
							`department`,
							`designation`,
							`payment_date`,
							`deduction_date`,
							`deposite_date`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strCode) . ',
							' . $objDatabase->SqlVariable($this->dttDate) . ',
							' . $objDatabase->SqlVariable($this->dttForMonth) . ',
							' . $objDatabase->SqlVariable($this->intDepartment) . ',
							' . $objDatabase->SqlVariable($this->intDesignation) . ',
							' . $objDatabase->SqlVariable($this->dttPaymentDate) . ',
							' . $objDatabase->SqlVariable($this->dttDeductionDate) . ',
							' . $objDatabase->SqlVariable($this->dttDepositeDate) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdsalarysheet = $objDatabase->InsertId('salarysheet', 'idsalarysheet');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`salarysheet`
						SET
							`code` = ' . $objDatabase->SqlVariable($this->strCode) . ',
							`date` = ' . $objDatabase->SqlVariable($this->dttDate) . ',
							`for_month` = ' . $objDatabase->SqlVariable($this->dttForMonth) . ',
							`department` = ' . $objDatabase->SqlVariable($this->intDepartment) . ',
							`designation` = ' . $objDatabase->SqlVariable($this->intDesignation) . ',
							`payment_date` = ' . $objDatabase->SqlVariable($this->dttPaymentDate) . ',
							`deduction_date` = ' . $objDatabase->SqlVariable($this->dttDeductionDate) . ',
							`deposite_date` = ' . $objDatabase->SqlVariable($this->dttDepositeDate) . '
						WHERE
							`idsalarysheet` = ' . $objDatabase->SqlVariable($this->intIdsalarysheet) . '
					');
				}



				// Update the adjoined IncomeTaxDetails object (if applicable)
				// TODO: Make this into hard-coded SQL queries
				if ($this->blnDirtyIncomeTaxDetails) {
					// Unassociate the old one (if applicable)
					if ($objAssociated = IncomeTaxDetails::LoadByIdincomeTaxDetails($this->intIdsalarysheet)) {
						$objAssociated->IdincomeTaxDetails = null;
						$objAssociated->Save();
					}

					// Associate the new one (if applicable)
					if ($this->objIncomeTaxDetails) {
						$this->objIncomeTaxDetails->IdincomeTaxDetails = $this->intIdsalarysheet;
						$this->objIncomeTaxDetails->Save();
					}

					// Reset the "Dirty" flag
					$this->blnDirtyIncomeTaxDetails = false;
				}
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Salarysheet
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdsalarysheet)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Salarysheet with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();


		
			// Update the adjoined IncomeTaxDetails object (if applicable) and perform a delete

			// Optional -- if you **KNOW** that you do not want to EVER run any level of business logic on the disassocation,
			// you *could* override Delete() so that this step can be a single hard coded query to optimize performance.
			if ($objAssociated = IncomeTaxDetails::LoadByIdincomeTaxDetails($this->intIdsalarysheet)) {
				$objAssociated->Delete();
			}

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salarysheet`
				WHERE
					`idsalarysheet` = ' . $objDatabase->SqlVariable($this->intIdsalarysheet) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Salarysheet ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Salarysheet', $this->intIdsalarysheet);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Salarysheets
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salarysheet`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate salarysheet table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `salarysheet`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Salarysheet from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Salarysheet object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Salarysheet::Load($this->intIdsalarysheet);

			// Update $this's local variables to match
			$this->strCode = $objReloaded->strCode;
			$this->dttDate = $objReloaded->dttDate;
			$this->dttForMonth = $objReloaded->dttForMonth;
			$this->Department = $objReloaded->Department;
			$this->Designation = $objReloaded->Designation;
			$this->dttPaymentDate = $objReloaded->dttPaymentDate;
			$this->dttDeductionDate = $objReloaded->dttDeductionDate;
			$this->dttDepositeDate = $objReloaded->dttDepositeDate;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idsalarysheet':
					/**
					 * Gets the value for intIdsalarysheet (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdsalarysheet;

				case 'Code':
					/**
					 * Gets the value for strCode (Unique)
					 * @return string
					 */
					return $this->strCode;

				case 'Date':
					/**
					 * Gets the value for dttDate (Not Null)
					 * @return QDateTime
					 */
					return $this->dttDate;

				case 'ForMonth':
					/**
					 * Gets the value for dttForMonth (Not Null)
					 * @return QDateTime
					 */
					return $this->dttForMonth;

				case 'Department':
					/**
					 * Gets the value for intDepartment (Not Null)
					 * @return integer
					 */
					return $this->intDepartment;

				case 'Designation':
					/**
					 * Gets the value for intDesignation 
					 * @return integer
					 */
					return $this->intDesignation;

				case 'PaymentDate':
					/**
					 * Gets the value for dttPaymentDate 
					 * @return QDateTime
					 */
					return $this->dttPaymentDate;

				case 'DeductionDate':
					/**
					 * Gets the value for dttDeductionDate 
					 * @return QDateTime
					 */
					return $this->dttDeductionDate;

				case 'DepositeDate':
					/**
					 * Gets the value for dttDepositeDate 
					 * @return QDateTime
					 */
					return $this->dttDepositeDate;


				///////////////////
				// Member Objects
				///////////////////
				case 'DepartmentObject':
					/**
					 * Gets the value for the Role object referenced by intDepartment (Not Null)
					 * @return Role
					 */
					try {
						if ((!$this->objDepartmentObject) && (!is_null($this->intDepartment)))
							$this->objDepartmentObject = Role::Load($this->intDepartment);
						return $this->objDepartmentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DesignationObject':
					/**
					 * Gets the value for the Role object referenced by intDesignation 
					 * @return Role
					 */
					try {
						if ((!$this->objDesignationObject) && (!is_null($this->intDesignation)))
							$this->objDesignationObject = Role::Load($this->intDesignation);
						return $this->objDesignationObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'IncomeTaxDetails':
					/**
					 * Gets the value for the IncomeTaxDetails object that uniquely references this Salarysheet
					 * by objIncomeTaxDetails (Unique)
					 * @return IncomeTaxDetails
					 */
					try {
						if ($this->objIncomeTaxDetails === false)
							// We've attempted early binding -- and the reverse reference object does not exist
							return null;
						if (!$this->objIncomeTaxDetails)
							$this->objIncomeTaxDetails = IncomeTaxDetails::LoadByIdincomeTaxDetails($this->intIdsalarysheet);
						return $this->objIncomeTaxDetails;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_SalarysheetApproval':
					/**
					 * Gets the value for the private _objSalarysheetApproval (Read-Only)
					 * if set due to an expansion on the salarysheet_approval.salarysheet reverse relationship
					 * @return SalarysheetApproval
					 */
					return $this->_objSalarysheetApproval;

				case '_SalarysheetApprovalArray':
					/**
					 * Gets the value for the private _objSalarysheetApprovalArray (Read-Only)
					 * if set due to an ExpandAsArray on the salarysheet_approval.salarysheet reverse relationship
					 * @return SalarysheetApproval[]
					 */
					return $this->_objSalarysheetApprovalArray;

				case '_SalarysheetHasEmployee':
					/**
					 * Gets the value for the private _objSalarysheetHasEmployee (Read-Only)
					 * if set due to an expansion on the salarysheet_has_employee.salarysheet reverse relationship
					 * @return SalarysheetHasEmployee
					 */
					return $this->_objSalarysheetHasEmployee;

				case '_SalarysheetHasEmployeeArray':
					/**
					 * Gets the value for the private _objSalarysheetHasEmployeeArray (Read-Only)
					 * if set due to an ExpandAsArray on the salarysheet_has_employee.salarysheet reverse relationship
					 * @return SalarysheetHasEmployee[]
					 */
					return $this->_objSalarysheetHasEmployeeArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Code':
					/**
					 * Sets the value for strCode (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Date':
					/**
					 * Sets the value for dttDate (Not Null)
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ForMonth':
					/**
					 * Sets the value for dttForMonth (Not Null)
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttForMonth = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Department':
					/**
					 * Sets the value for intDepartment (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDepartmentObject = null;
						return ($this->intDepartment = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Designation':
					/**
					 * Sets the value for intDesignation 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDesignationObject = null;
						return ($this->intDesignation = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'PaymentDate':
					/**
					 * Sets the value for dttPaymentDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttPaymentDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DeductionDate':
					/**
					 * Sets the value for dttDeductionDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDeductionDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DepositeDate':
					/**
					 * Sets the value for dttDepositeDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDepositeDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'DepartmentObject':
					/**
					 * Sets the value for the Role object referenced by intDepartment (Not Null)
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intDepartment = null;
						$this->objDepartmentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved DepartmentObject for this Salarysheet');

						// Update Local Member Variables
						$this->objDepartmentObject = $mixValue;
						$this->intDepartment = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DesignationObject':
					/**
					 * Sets the value for the Role object referenced by intDesignation 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intDesignation = null;
						$this->objDesignationObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved DesignationObject for this Salarysheet');

						// Update Local Member Variables
						$this->objDesignationObject = $mixValue;
						$this->intDesignation = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'IncomeTaxDetails':
					/**
					 * Sets the value for the IncomeTaxDetails object referenced by objIncomeTaxDetails (Unique)
					 * @param IncomeTaxDetails $mixValue
					 * @return IncomeTaxDetails
					 */
					if (is_null($mixValue)) {
						$this->objIncomeTaxDetails = null;

						// Make sure we update the adjoined IncomeTaxDetails object the next time we call Save()
						$this->blnDirtyIncomeTaxDetails = true;

						return null;
					} else {
						// Make sure $mixValue actually is a IncomeTaxDetails object
						try {
							$mixValue = QType::Cast($mixValue, 'IncomeTaxDetails');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Are we setting objIncomeTaxDetails to a DIFFERENT $mixValue?
						if ((!$this->IncomeTaxDetails) || ($this->IncomeTaxDetails->IdincomeTaxDetails != $mixValue->IdincomeTaxDetails)) {
							// Yes -- therefore, set the "Dirty" flag to true
							// to make sure we update the adjoined IncomeTaxDetails object the next time we call Save()
							$this->blnDirtyIncomeTaxDetails = true;

							// Update Local Member Variable
							$this->objIncomeTaxDetails = $mixValue;
						} else {
							// Nope -- therefore, make no changes
						}

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for SalarysheetApproval
		//-------------------------------------------------------------------

		/**
		 * Gets all associated SalarysheetApprovals as an array of SalarysheetApproval objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalarysheetApproval[]
		*/
		public function GetSalarysheetApprovalArray($objOptionalClauses = null) {
			if ((is_null($this->intIdsalarysheet)))
				return array();

			try {
				return SalarysheetApproval::LoadArrayBySalarysheet($this->intIdsalarysheet, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated SalarysheetApprovals
		 * @return int
		*/
		public function CountSalarysheetApprovals() {
			if ((is_null($this->intIdsalarysheet)))
				return 0;

			return SalarysheetApproval::CountBySalarysheet($this->intIdsalarysheet);
		}

		/**
		 * Associates a SalarysheetApproval
		 * @param SalarysheetApproval $objSalarysheetApproval
		 * @return void
		*/
		public function AssociateSalarysheetApproval(SalarysheetApproval $objSalarysheetApproval) {
			if ((is_null($this->intIdsalarysheet)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSalarysheetApproval on this unsaved Salarysheet.');
			if ((is_null($objSalarysheetApproval->IdsalarysheetApproval)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSalarysheetApproval on this Salarysheet with an unsaved SalarysheetApproval.');

			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salarysheet_approval`
				SET
					`salarysheet` = ' . $objDatabase->SqlVariable($this->intIdsalarysheet) . '
				WHERE
					`idsalarysheet_approval` = ' . $objDatabase->SqlVariable($objSalarysheetApproval->IdsalarysheetApproval) . '
			');
		}

		/**
		 * Unassociates a SalarysheetApproval
		 * @param SalarysheetApproval $objSalarysheetApproval
		 * @return void
		*/
		public function UnassociateSalarysheetApproval(SalarysheetApproval $objSalarysheetApproval) {
			if ((is_null($this->intIdsalarysheet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetApproval on this unsaved Salarysheet.');
			if ((is_null($objSalarysheetApproval->IdsalarysheetApproval)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetApproval on this Salarysheet with an unsaved SalarysheetApproval.');

			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salarysheet_approval`
				SET
					`salarysheet` = null
				WHERE
					`idsalarysheet_approval` = ' . $objDatabase->SqlVariable($objSalarysheetApproval->IdsalarysheetApproval) . ' AND
					`salarysheet` = ' . $objDatabase->SqlVariable($this->intIdsalarysheet) . '
			');
		}

		/**
		 * Unassociates all SalarysheetApprovals
		 * @return void
		*/
		public function UnassociateAllSalarysheetApprovals() {
			if ((is_null($this->intIdsalarysheet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetApproval on this unsaved Salarysheet.');

			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salarysheet_approval`
				SET
					`salarysheet` = null
				WHERE
					`salarysheet` = ' . $objDatabase->SqlVariable($this->intIdsalarysheet) . '
			');
		}

		/**
		 * Deletes an associated SalarysheetApproval
		 * @param SalarysheetApproval $objSalarysheetApproval
		 * @return void
		*/
		public function DeleteAssociatedSalarysheetApproval(SalarysheetApproval $objSalarysheetApproval) {
			if ((is_null($this->intIdsalarysheet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetApproval on this unsaved Salarysheet.');
			if ((is_null($objSalarysheetApproval->IdsalarysheetApproval)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetApproval on this Salarysheet with an unsaved SalarysheetApproval.');

			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salarysheet_approval`
				WHERE
					`idsalarysheet_approval` = ' . $objDatabase->SqlVariable($objSalarysheetApproval->IdsalarysheetApproval) . ' AND
					`salarysheet` = ' . $objDatabase->SqlVariable($this->intIdsalarysheet) . '
			');
		}

		/**
		 * Deletes all associated SalarysheetApprovals
		 * @return void
		*/
		public function DeleteAllSalarysheetApprovals() {
			if ((is_null($this->intIdsalarysheet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetApproval on this unsaved Salarysheet.');

			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salarysheet_approval`
				WHERE
					`salarysheet` = ' . $objDatabase->SqlVariable($this->intIdsalarysheet) . '
			');
		}


		// Related Objects' Methods for SalarysheetHasEmployee
		//-------------------------------------------------------------------

		/**
		 * Gets all associated SalarysheetHasEmployees as an array of SalarysheetHasEmployee objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalarysheetHasEmployee[]
		*/
		public function GetSalarysheetHasEmployeeArray($objOptionalClauses = null) {
			if ((is_null($this->intIdsalarysheet)))
				return array();

			try {
				return SalarysheetHasEmployee::LoadArrayBySalarysheet($this->intIdsalarysheet, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated SalarysheetHasEmployees
		 * @return int
		*/
		public function CountSalarysheetHasEmployees() {
			if ((is_null($this->intIdsalarysheet)))
				return 0;

			return SalarysheetHasEmployee::CountBySalarysheet($this->intIdsalarysheet);
		}

		/**
		 * Associates a SalarysheetHasEmployee
		 * @param SalarysheetHasEmployee $objSalarysheetHasEmployee
		 * @return void
		*/
		public function AssociateSalarysheetHasEmployee(SalarysheetHasEmployee $objSalarysheetHasEmployee) {
			if ((is_null($this->intIdsalarysheet)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSalarysheetHasEmployee on this unsaved Salarysheet.');
			if ((is_null($objSalarysheetHasEmployee->IdsalarysheetHasEmployee)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSalarysheetHasEmployee on this Salarysheet with an unsaved SalarysheetHasEmployee.');

			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salarysheet_has_employee`
				SET
					`salarysheet` = ' . $objDatabase->SqlVariable($this->intIdsalarysheet) . '
				WHERE
					`idsalarysheet_has_employee` = ' . $objDatabase->SqlVariable($objSalarysheetHasEmployee->IdsalarysheetHasEmployee) . '
			');
		}

		/**
		 * Unassociates a SalarysheetHasEmployee
		 * @param SalarysheetHasEmployee $objSalarysheetHasEmployee
		 * @return void
		*/
		public function UnassociateSalarysheetHasEmployee(SalarysheetHasEmployee $objSalarysheetHasEmployee) {
			if ((is_null($this->intIdsalarysheet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetHasEmployee on this unsaved Salarysheet.');
			if ((is_null($objSalarysheetHasEmployee->IdsalarysheetHasEmployee)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetHasEmployee on this Salarysheet with an unsaved SalarysheetHasEmployee.');

			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salarysheet_has_employee`
				SET
					`salarysheet` = null
				WHERE
					`idsalarysheet_has_employee` = ' . $objDatabase->SqlVariable($objSalarysheetHasEmployee->IdsalarysheetHasEmployee) . ' AND
					`salarysheet` = ' . $objDatabase->SqlVariable($this->intIdsalarysheet) . '
			');
		}

		/**
		 * Unassociates all SalarysheetHasEmployees
		 * @return void
		*/
		public function UnassociateAllSalarysheetHasEmployees() {
			if ((is_null($this->intIdsalarysheet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetHasEmployee on this unsaved Salarysheet.');

			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salarysheet_has_employee`
				SET
					`salarysheet` = null
				WHERE
					`salarysheet` = ' . $objDatabase->SqlVariable($this->intIdsalarysheet) . '
			');
		}

		/**
		 * Deletes an associated SalarysheetHasEmployee
		 * @param SalarysheetHasEmployee $objSalarysheetHasEmployee
		 * @return void
		*/
		public function DeleteAssociatedSalarysheetHasEmployee(SalarysheetHasEmployee $objSalarysheetHasEmployee) {
			if ((is_null($this->intIdsalarysheet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetHasEmployee on this unsaved Salarysheet.');
			if ((is_null($objSalarysheetHasEmployee->IdsalarysheetHasEmployee)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetHasEmployee on this Salarysheet with an unsaved SalarysheetHasEmployee.');

			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salarysheet_has_employee`
				WHERE
					`idsalarysheet_has_employee` = ' . $objDatabase->SqlVariable($objSalarysheetHasEmployee->IdsalarysheetHasEmployee) . ' AND
					`salarysheet` = ' . $objDatabase->SqlVariable($this->intIdsalarysheet) . '
			');
		}

		/**
		 * Deletes all associated SalarysheetHasEmployees
		 * @return void
		*/
		public function DeleteAllSalarysheetHasEmployees() {
			if ((is_null($this->intIdsalarysheet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalarysheetHasEmployee on this unsaved Salarysheet.');

			// Get the Database Object for this Class
			$objDatabase = Salarysheet::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salarysheet_has_employee`
				WHERE
					`salarysheet` = ' . $objDatabase->SqlVariable($this->intIdsalarysheet) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "salarysheet";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Salarysheet::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Salarysheet"><sequence>';
			$strToReturn .= '<element name="Idsalarysheet" type="xsd:int"/>';
			$strToReturn .= '<element name="Code" type="xsd:string"/>';
			$strToReturn .= '<element name="Date" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="ForMonth" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="DepartmentObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="DesignationObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="PaymentDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="DeductionDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="DepositeDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Salarysheet', $strComplexTypeArray)) {
				$strComplexTypeArray['Salarysheet'] = Salarysheet::GetSoapComplexTypeXml();
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Salarysheet::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Salarysheet();
			if (property_exists($objSoapObject, 'Idsalarysheet'))
				$objToReturn->intIdsalarysheet = $objSoapObject->Idsalarysheet;
			if (property_exists($objSoapObject, 'Code'))
				$objToReturn->strCode = $objSoapObject->Code;
			if (property_exists($objSoapObject, 'Date'))
				$objToReturn->dttDate = new QDateTime($objSoapObject->Date);
			if (property_exists($objSoapObject, 'ForMonth'))
				$objToReturn->dttForMonth = new QDateTime($objSoapObject->ForMonth);
			if ((property_exists($objSoapObject, 'DepartmentObject')) &&
				($objSoapObject->DepartmentObject))
				$objToReturn->DepartmentObject = Role::GetObjectFromSoapObject($objSoapObject->DepartmentObject);
			if ((property_exists($objSoapObject, 'DesignationObject')) &&
				($objSoapObject->DesignationObject))
				$objToReturn->DesignationObject = Role::GetObjectFromSoapObject($objSoapObject->DesignationObject);
			if (property_exists($objSoapObject, 'PaymentDate'))
				$objToReturn->dttPaymentDate = new QDateTime($objSoapObject->PaymentDate);
			if (property_exists($objSoapObject, 'DeductionDate'))
				$objToReturn->dttDeductionDate = new QDateTime($objSoapObject->DeductionDate);
			if (property_exists($objSoapObject, 'DepositeDate'))
				$objToReturn->dttDepositeDate = new QDateTime($objSoapObject->DepositeDate);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Salarysheet::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->dttDate)
				$objObject->dttDate = $objObject->dttDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttForMonth)
				$objObject->dttForMonth = $objObject->dttForMonth->qFormat(QDateTime::FormatSoap);
			if ($objObject->objDepartmentObject)
				$objObject->objDepartmentObject = Role::GetSoapObjectFromObject($objObject->objDepartmentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDepartment = null;
			if ($objObject->objDesignationObject)
				$objObject->objDesignationObject = Role::GetSoapObjectFromObject($objObject->objDesignationObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDesignation = null;
			if ($objObject->dttPaymentDate)
				$objObject->dttPaymentDate = $objObject->dttPaymentDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttDeductionDate)
				$objObject->dttDeductionDate = $objObject->dttDeductionDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttDepositeDate)
				$objObject->dttDepositeDate = $objObject->dttDepositeDate->qFormat(QDateTime::FormatSoap);
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idsalarysheet'] = $this->intIdsalarysheet;
			$iArray['Code'] = $this->strCode;
			$iArray['Date'] = $this->dttDate;
			$iArray['ForMonth'] = $this->dttForMonth;
			$iArray['Department'] = $this->intDepartment;
			$iArray['Designation'] = $this->intDesignation;
			$iArray['PaymentDate'] = $this->dttPaymentDate;
			$iArray['DeductionDate'] = $this->dttDeductionDate;
			$iArray['DepositeDate'] = $this->dttDepositeDate;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdsalarysheet ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idsalarysheet
     * @property-read QQNode $Code
     * @property-read QQNode $Date
     * @property-read QQNode $ForMonth
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $Designation
     * @property-read QQNodeRole $DesignationObject
     * @property-read QQNode $PaymentDate
     * @property-read QQNode $DeductionDate
     * @property-read QQNode $DepositeDate
     *
     *
     * @property-read QQReverseReferenceNodeIncomeTaxDetails $IncomeTaxDetails
     * @property-read QQReverseReferenceNodeSalarysheetApproval $SalarysheetApproval
     * @property-read QQReverseReferenceNodeSalarysheetHasEmployee $SalarysheetHasEmployee

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeSalarysheet extends QQNode {
		protected $strTableName = 'salarysheet';
		protected $strPrimaryKey = 'idsalarysheet';
		protected $strClassName = 'Salarysheet';
		public function __get($strName) {
			switch ($strName) {
				case 'Idsalarysheet':
					return new QQNode('idsalarysheet', 'Idsalarysheet', 'Integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'VarChar', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'Date', $this);
				case 'ForMonth':
					return new QQNode('for_month', 'ForMonth', 'Date', $this);
				case 'Department':
					return new QQNode('department', 'Department', 'Integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'Integer', $this);
				case 'Designation':
					return new QQNode('designation', 'Designation', 'Integer', $this);
				case 'DesignationObject':
					return new QQNodeRole('designation', 'DesignationObject', 'Integer', $this);
				case 'PaymentDate':
					return new QQNode('payment_date', 'PaymentDate', 'Date', $this);
				case 'DeductionDate':
					return new QQNode('deduction_date', 'DeductionDate', 'Date', $this);
				case 'DepositeDate':
					return new QQNode('deposite_date', 'DepositeDate', 'Date', $this);
				case 'IncomeTaxDetails':
					return new QQReverseReferenceNodeIncomeTaxDetails($this, 'incometaxdetails', 'reverse_reference', 'idincome_tax_details', 'IncomeTaxDetails');
				case 'SalarysheetApproval':
					return new QQReverseReferenceNodeSalarysheetApproval($this, 'salarysheetapproval', 'reverse_reference', 'salarysheet');
				case 'SalarysheetHasEmployee':
					return new QQReverseReferenceNodeSalarysheetHasEmployee($this, 'salarysheethasemployee', 'reverse_reference', 'salarysheet');

				case '_PrimaryKeyNode':
					return new QQNode('idsalarysheet', 'Idsalarysheet', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idsalarysheet
     * @property-read QQNode $Code
     * @property-read QQNode $Date
     * @property-read QQNode $ForMonth
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $Designation
     * @property-read QQNodeRole $DesignationObject
     * @property-read QQNode $PaymentDate
     * @property-read QQNode $DeductionDate
     * @property-read QQNode $DepositeDate
     *
     *
     * @property-read QQReverseReferenceNodeIncomeTaxDetails $IncomeTaxDetails
     * @property-read QQReverseReferenceNodeSalarysheetApproval $SalarysheetApproval
     * @property-read QQReverseReferenceNodeSalarysheetHasEmployee $SalarysheetHasEmployee

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeSalarysheet extends QQReverseReferenceNode {
		protected $strTableName = 'salarysheet';
		protected $strPrimaryKey = 'idsalarysheet';
		protected $strClassName = 'Salarysheet';
		public function __get($strName) {
			switch ($strName) {
				case 'Idsalarysheet':
					return new QQNode('idsalarysheet', 'Idsalarysheet', 'integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'string', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'QDateTime', $this);
				case 'ForMonth':
					return new QQNode('for_month', 'ForMonth', 'QDateTime', $this);
				case 'Department':
					return new QQNode('department', 'Department', 'integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'integer', $this);
				case 'Designation':
					return new QQNode('designation', 'Designation', 'integer', $this);
				case 'DesignationObject':
					return new QQNodeRole('designation', 'DesignationObject', 'integer', $this);
				case 'PaymentDate':
					return new QQNode('payment_date', 'PaymentDate', 'QDateTime', $this);
				case 'DeductionDate':
					return new QQNode('deduction_date', 'DeductionDate', 'QDateTime', $this);
				case 'DepositeDate':
					return new QQNode('deposite_date', 'DepositeDate', 'QDateTime', $this);
				case 'IncomeTaxDetails':
					return new QQReverseReferenceNodeIncomeTaxDetails($this, 'incometaxdetails', 'reverse_reference', 'idincome_tax_details', 'IncomeTaxDetails');
				case 'SalarysheetApproval':
					return new QQReverseReferenceNodeSalarysheetApproval($this, 'salarysheetapproval', 'reverse_reference', 'salarysheet');
				case 'SalarysheetHasEmployee':
					return new QQReverseReferenceNodeSalarysheetHasEmployee($this, 'salarysheethasemployee', 'reverse_reference', 'salarysheet');

				case '_PrimaryKeyNode':
					return new QQNode('idsalarysheet', 'Idsalarysheet', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
