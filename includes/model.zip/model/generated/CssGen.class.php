<?php
	/**
	 * The abstract CssGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Css subclass which
	 * extends this CssGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Css class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idcss the value for intIdcss (Read-Only PK)
	 * @property string $Name the value for strName (Unique)
	 * @property string $Description the value for strDescription 
	 * @property integer $Parrent the value for intParrent 
	 * @property Css $ParrentObject the value for the Css object referenced by intParrent 
	 * @property-read Article $_Article the value for the private _objArticle (Read-Only) if set due to an expansion on the article.css reverse relationship
	 * @property-read Article[] $_ArticleArray the value for the private _objArticleArray (Read-Only) if set due to an ExpandAsArray on the article.css reverse relationship
	 * @property-read Article $_ArticleAsClass the value for the private _objArticleAsClass (Read-Only) if set due to an expansion on the article.class reverse relationship
	 * @property-read Article[] $_ArticleAsClassArray the value for the private _objArticleAsClassArray (Read-Only) if set due to an ExpandAsArray on the article.class reverse relationship
	 * @property-read Css $_CssAsParrent the value for the private _objCssAsParrent (Read-Only) if set due to an expansion on the css.parrent reverse relationship
	 * @property-read Css[] $_CssAsParrentArray the value for the private _objCssAsParrentArray (Read-Only) if set due to an ExpandAsArray on the css.parrent reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class CssGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column css.idcss
		 * @var integer intIdcss
		 */
		protected $intIdcss;
		const IdcssDefault = null;


		/**
		 * Protected member variable that maps to the database column css.name
		 * @var string strName
		 */
		protected $strName;
		const NameMaxLength = 45;
		const NameDefault = null;


		/**
		 * Protected member variable that maps to the database column css.description
		 * @var string strDescription
		 */
		protected $strDescription;
		const DescriptionDefault = null;


		/**
		 * Protected member variable that maps to the database column css.parrent
		 * @var integer intParrent
		 */
		protected $intParrent;
		const ParrentDefault = null;


		/**
		 * Private member variable that stores a reference to a single Article object
		 * (of type Article), if this Css object was restored with
		 * an expansion on the article association table.
		 * @var Article _objArticle;
		 */
		private $_objArticle;

		/**
		 * Private member variable that stores a reference to an array of Article objects
		 * (of type Article[]), if this Css object was restored with
		 * an ExpandAsArray on the article association table.
		 * @var Article[] _objArticleArray;
		 */
		private $_objArticleArray = null;

		/**
		 * Private member variable that stores a reference to a single ArticleAsClass object
		 * (of type Article), if this Css object was restored with
		 * an expansion on the article association table.
		 * @var Article _objArticleAsClass;
		 */
		private $_objArticleAsClass;

		/**
		 * Private member variable that stores a reference to an array of ArticleAsClass objects
		 * (of type Article[]), if this Css object was restored with
		 * an ExpandAsArray on the article association table.
		 * @var Article[] _objArticleAsClassArray;
		 */
		private $_objArticleAsClassArray = null;

		/**
		 * Private member variable that stores a reference to a single CssAsParrent object
		 * (of type Css), if this Css object was restored with
		 * an expansion on the css association table.
		 * @var Css _objCssAsParrent;
		 */
		private $_objCssAsParrent;

		/**
		 * Private member variable that stores a reference to an array of CssAsParrent objects
		 * (of type Css[]), if this Css object was restored with
		 * an ExpandAsArray on the css association table.
		 * @var Css[] _objCssAsParrentArray;
		 */
		private $_objCssAsParrentArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column css.parrent.
		 *
		 * NOTE: Always use the ParrentObject property getter to correctly retrieve this Css object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Css objParrentObject
		 */
		protected $objParrentObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdcss = Css::IdcssDefault;
			$this->strName = Css::NameDefault;
			$this->strDescription = Css::DescriptionDefault;
			$this->intParrent = Css::ParrentDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Css from PK Info
		 * @param integer $intIdcss
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Css
		 */
		public static function Load($intIdcss, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Css', $intIdcss);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Css::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Css()->Idcss, $intIdcss)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Csses
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Css[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Css::QueryArray to perform the LoadAll query
			try {
				return Css::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Csses
		 * @return int
		 */
		public static function CountAll() {
			// Call Css::QueryCount to perform the CountAll query
			return Css::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Create/Build out the QueryBuilder object with Css-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'css');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Css::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('css');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Css object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Css the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Css::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Css object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Css::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Css::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Css objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Css[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Css::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Css::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Css::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Css objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Css::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			$strQuery = Css::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/css', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Css::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Css
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'css';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idcss', $strAliasPrefix . 'idcss');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idcss', $strAliasPrefix . 'idcss');
			    $objBuilder->AddSelectItem($strTableName, 'name', $strAliasPrefix . 'name');
			    $objBuilder->AddSelectItem($strTableName, 'description', $strAliasPrefix . 'description');
			    $objBuilder->AddSelectItem($strTableName, 'parrent', $strAliasPrefix . 'parrent');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Css from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Css::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Css
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idcss';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdcss == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'css__';


						// Expanding reverse references: Article
						$strAlias = $strAliasPrefix . 'article__idarticle';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objArticleArray)
								$objPreviousItem->_objArticleArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objArticleArray)) {
								$objPreviousChildItems = $objPreviousItem->_objArticleArray;
								$objChildItem = Article::InstantiateDbRow($objDbRow, $strAliasPrefix . 'article__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objArticleArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objArticleArray[] = Article::InstantiateDbRow($objDbRow, $strAliasPrefix . 'article__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ArticleAsClass
						$strAlias = $strAliasPrefix . 'articleasclass__idarticle';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objArticleAsClassArray)
								$objPreviousItem->_objArticleAsClassArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objArticleAsClassArray)) {
								$objPreviousChildItems = $objPreviousItem->_objArticleAsClassArray;
								$objChildItem = Article::InstantiateDbRow($objDbRow, $strAliasPrefix . 'articleasclass__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objArticleAsClassArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objArticleAsClassArray[] = Article::InstantiateDbRow($objDbRow, $strAliasPrefix . 'articleasclass__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: CssAsParrent
						$strAlias = $strAliasPrefix . 'cssasparrent__idcss';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objCssAsParrentArray)
								$objPreviousItem->_objCssAsParrentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objCssAsParrentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objCssAsParrentArray;
								$objChildItem = Css::InstantiateDbRow($objDbRow, $strAliasPrefix . 'cssasparrent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objCssAsParrentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objCssAsParrentArray[] = Css::InstantiateDbRow($objDbRow, $strAliasPrefix . 'cssasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'css__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Css object
			$objToReturn = new Css();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idcss';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdcss = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'name';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strName = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'description';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strDescription = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'parrent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intParrent = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idcss != $objPreviousItem->Idcss) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objArticleArray);
					$cnt = count($objToReturn->_objArticleArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objArticleArray, $objToReturn->_objArticleArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objArticleAsClassArray);
					$cnt = count($objToReturn->_objArticleAsClassArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objArticleAsClassArray, $objToReturn->_objArticleAsClassArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objCssAsParrentArray);
					$cnt = count($objToReturn->_objCssAsParrentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objCssAsParrentArray, $objToReturn->_objCssAsParrentArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'css__';

			// Check for ParrentObject Early Binding
			$strAlias = $strAliasPrefix . 'parrent__idcss';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objParrentObject = Css::InstantiateDbRow($objDbRow, $strAliasPrefix . 'parrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for Article Virtual Binding
			$strAlias = $strAliasPrefix . 'article__idarticle';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objArticleArray)
				$objToReturn->_objArticleArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objArticleArray[] = Article::InstantiateDbRow($objDbRow, $strAliasPrefix . 'article__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objArticle = Article::InstantiateDbRow($objDbRow, $strAliasPrefix . 'article__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ArticleAsClass Virtual Binding
			$strAlias = $strAliasPrefix . 'articleasclass__idarticle';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objArticleAsClassArray)
				$objToReturn->_objArticleAsClassArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objArticleAsClassArray[] = Article::InstantiateDbRow($objDbRow, $strAliasPrefix . 'articleasclass__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objArticleAsClass = Article::InstantiateDbRow($objDbRow, $strAliasPrefix . 'articleasclass__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for CssAsParrent Virtual Binding
			$strAlias = $strAliasPrefix . 'cssasparrent__idcss';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objCssAsParrentArray)
				$objToReturn->_objCssAsParrentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objCssAsParrentArray[] = Css::InstantiateDbRow($objDbRow, $strAliasPrefix . 'cssasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objCssAsParrent = Css::InstantiateDbRow($objDbRow, $strAliasPrefix . 'cssasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Csses from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Css[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Css::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Css::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Css object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Css next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Css::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Css object,
		 * by Idcss Index(es)
		 * @param integer $intIdcss
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Css
		*/
		public static function LoadByIdcss($intIdcss, $objOptionalClauses = null) {
			return Css::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Css()->Idcss, $intIdcss)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single Css object,
		 * by Name Index(es)
		 * @param string $strName
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Css
		*/
		public static function LoadByName($strName, $objOptionalClauses = null) {
			return Css::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Css()->Name, $strName)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Css objects,
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Css[]
		*/
		public static function LoadArrayByParrent($intParrent, $objOptionalClauses = null) {
			// Call Css::QueryArray to perform the LoadArrayByParrent query
			try {
				return Css::QueryArray(
					QQ::Equal(QQN::Css()->Parrent, $intParrent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Csses
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @return int
		*/
		public static function CountByParrent($intParrent) {
			// Call Css::QueryCount to perform the CountByParrent query
			return Css::QueryCount(
				QQ::Equal(QQN::Css()->Parrent, $intParrent)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Css
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `css` (
							`name`,
							`description`,
							`parrent`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strName) . ',
							' . $objDatabase->SqlVariable($this->strDescription) . ',
							' . $objDatabase->SqlVariable($this->intParrent) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdcss = $objDatabase->InsertId('css', 'idcss');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`css`
						SET
							`name` = ' . $objDatabase->SqlVariable($this->strName) . ',
							`description` = ' . $objDatabase->SqlVariable($this->strDescription) . ',
							`parrent` = ' . $objDatabase->SqlVariable($this->intParrent) . '
						WHERE
							`idcss` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Css
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Css with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`css`
				WHERE
					`idcss` = ' . $objDatabase->SqlVariable($this->intIdcss) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Css ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Css', $this->intIdcss);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Csses
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`css`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate css table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `css`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Css from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Css object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Css::Load($this->intIdcss);

			// Update $this's local variables to match
			$this->strName = $objReloaded->strName;
			$this->strDescription = $objReloaded->strDescription;
			$this->Parrent = $objReloaded->Parrent;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idcss':
					/**
					 * Gets the value for intIdcss (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdcss;

				case 'Name':
					/**
					 * Gets the value for strName (Unique)
					 * @return string
					 */
					return $this->strName;

				case 'Description':
					/**
					 * Gets the value for strDescription 
					 * @return string
					 */
					return $this->strDescription;

				case 'Parrent':
					/**
					 * Gets the value for intParrent 
					 * @return integer
					 */
					return $this->intParrent;


				///////////////////
				// Member Objects
				///////////////////
				case 'ParrentObject':
					/**
					 * Gets the value for the Css object referenced by intParrent 
					 * @return Css
					 */
					try {
						if ((!$this->objParrentObject) && (!is_null($this->intParrent)))
							$this->objParrentObject = Css::Load($this->intParrent);
						return $this->objParrentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_Article':
					/**
					 * Gets the value for the private _objArticle (Read-Only)
					 * if set due to an expansion on the article.css reverse relationship
					 * @return Article
					 */
					return $this->_objArticle;

				case '_ArticleArray':
					/**
					 * Gets the value for the private _objArticleArray (Read-Only)
					 * if set due to an ExpandAsArray on the article.css reverse relationship
					 * @return Article[]
					 */
					return $this->_objArticleArray;

				case '_ArticleAsClass':
					/**
					 * Gets the value for the private _objArticleAsClass (Read-Only)
					 * if set due to an expansion on the article.class reverse relationship
					 * @return Article
					 */
					return $this->_objArticleAsClass;

				case '_ArticleAsClassArray':
					/**
					 * Gets the value for the private _objArticleAsClassArray (Read-Only)
					 * if set due to an ExpandAsArray on the article.class reverse relationship
					 * @return Article[]
					 */
					return $this->_objArticleAsClassArray;

				case '_CssAsParrent':
					/**
					 * Gets the value for the private _objCssAsParrent (Read-Only)
					 * if set due to an expansion on the css.parrent reverse relationship
					 * @return Css
					 */
					return $this->_objCssAsParrent;

				case '_CssAsParrentArray':
					/**
					 * Gets the value for the private _objCssAsParrentArray (Read-Only)
					 * if set due to an ExpandAsArray on the css.parrent reverse relationship
					 * @return Css[]
					 */
					return $this->_objCssAsParrentArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Name':
					/**
					 * Sets the value for strName (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strName = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Description':
					/**
					 * Sets the value for strDescription 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strDescription = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Parrent':
					/**
					 * Sets the value for intParrent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objParrentObject = null;
						return ($this->intParrent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'ParrentObject':
					/**
					 * Sets the value for the Css object referenced by intParrent 
					 * @param Css $mixValue
					 * @return Css
					 */
					if (is_null($mixValue)) {
						$this->intParrent = null;
						$this->objParrentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Css object
						try {
							$mixValue = QType::Cast($mixValue, 'Css');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Css object
						if (is_null($mixValue->Idcss))
							throw new QCallerException('Unable to set an unsaved ParrentObject for this Css');

						// Update Local Member Variables
						$this->objParrentObject = $mixValue;
						$this->intParrent = $mixValue->Idcss;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for Article
		//-------------------------------------------------------------------

		/**
		 * Gets all associated Articles as an array of Article objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Article[]
		*/
		public function GetArticleArray($objOptionalClauses = null) {
			if ((is_null($this->intIdcss)))
				return array();

			try {
				return Article::LoadArrayByCss($this->intIdcss, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated Articles
		 * @return int
		*/
		public function CountArticles() {
			if ((is_null($this->intIdcss)))
				return 0;

			return Article::CountByCss($this->intIdcss);
		}

		/**
		 * Associates a Article
		 * @param Article $objArticle
		 * @return void
		*/
		public function AssociateArticle(Article $objArticle) {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateArticle on this unsaved Css.');
			if ((is_null($objArticle->Idarticle)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateArticle on this Css with an unsaved Article.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`article`
				SET
					`css` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
				WHERE
					`idarticle` = ' . $objDatabase->SqlVariable($objArticle->Idarticle) . '
			');
		}

		/**
		 * Unassociates a Article
		 * @param Article $objArticle
		 * @return void
		*/
		public function UnassociateArticle(Article $objArticle) {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateArticle on this unsaved Css.');
			if ((is_null($objArticle->Idarticle)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateArticle on this Css with an unsaved Article.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`article`
				SET
					`css` = null
				WHERE
					`idarticle` = ' . $objDatabase->SqlVariable($objArticle->Idarticle) . ' AND
					`css` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
			');
		}

		/**
		 * Unassociates all Articles
		 * @return void
		*/
		public function UnassociateAllArticles() {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateArticle on this unsaved Css.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`article`
				SET
					`css` = null
				WHERE
					`css` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
			');
		}

		/**
		 * Deletes an associated Article
		 * @param Article $objArticle
		 * @return void
		*/
		public function DeleteAssociatedArticle(Article $objArticle) {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateArticle on this unsaved Css.');
			if ((is_null($objArticle->Idarticle)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateArticle on this Css with an unsaved Article.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`article`
				WHERE
					`idarticle` = ' . $objDatabase->SqlVariable($objArticle->Idarticle) . ' AND
					`css` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
			');
		}

		/**
		 * Deletes all associated Articles
		 * @return void
		*/
		public function DeleteAllArticles() {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateArticle on this unsaved Css.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`article`
				WHERE
					`css` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
			');
		}


		// Related Objects' Methods for ArticleAsClass
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ArticlesAsClass as an array of Article objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Article[]
		*/
		public function GetArticleAsClassArray($objOptionalClauses = null) {
			if ((is_null($this->intIdcss)))
				return array();

			try {
				return Article::LoadArrayByClass($this->intIdcss, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ArticlesAsClass
		 * @return int
		*/
		public function CountArticlesAsClass() {
			if ((is_null($this->intIdcss)))
				return 0;

			return Article::CountByClass($this->intIdcss);
		}

		/**
		 * Associates a ArticleAsClass
		 * @param Article $objArticle
		 * @return void
		*/
		public function AssociateArticleAsClass(Article $objArticle) {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateArticleAsClass on this unsaved Css.');
			if ((is_null($objArticle->Idarticle)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateArticleAsClass on this Css with an unsaved Article.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`article`
				SET
					`class` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
				WHERE
					`idarticle` = ' . $objDatabase->SqlVariable($objArticle->Idarticle) . '
			');
		}

		/**
		 * Unassociates a ArticleAsClass
		 * @param Article $objArticle
		 * @return void
		*/
		public function UnassociateArticleAsClass(Article $objArticle) {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateArticleAsClass on this unsaved Css.');
			if ((is_null($objArticle->Idarticle)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateArticleAsClass on this Css with an unsaved Article.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`article`
				SET
					`class` = null
				WHERE
					`idarticle` = ' . $objDatabase->SqlVariable($objArticle->Idarticle) . ' AND
					`class` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
			');
		}

		/**
		 * Unassociates all ArticlesAsClass
		 * @return void
		*/
		public function UnassociateAllArticlesAsClass() {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateArticleAsClass on this unsaved Css.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`article`
				SET
					`class` = null
				WHERE
					`class` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
			');
		}

		/**
		 * Deletes an associated ArticleAsClass
		 * @param Article $objArticle
		 * @return void
		*/
		public function DeleteAssociatedArticleAsClass(Article $objArticle) {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateArticleAsClass on this unsaved Css.');
			if ((is_null($objArticle->Idarticle)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateArticleAsClass on this Css with an unsaved Article.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`article`
				WHERE
					`idarticle` = ' . $objDatabase->SqlVariable($objArticle->Idarticle) . ' AND
					`class` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
			');
		}

		/**
		 * Deletes all associated ArticlesAsClass
		 * @return void
		*/
		public function DeleteAllArticlesAsClass() {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateArticleAsClass on this unsaved Css.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`article`
				WHERE
					`class` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
			');
		}


		// Related Objects' Methods for CssAsParrent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated CssesAsParrent as an array of Css objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Css[]
		*/
		public function GetCssAsParrentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdcss)))
				return array();

			try {
				return Css::LoadArrayByParrent($this->intIdcss, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated CssesAsParrent
		 * @return int
		*/
		public function CountCssesAsParrent() {
			if ((is_null($this->intIdcss)))
				return 0;

			return Css::CountByParrent($this->intIdcss);
		}

		/**
		 * Associates a CssAsParrent
		 * @param Css $objCss
		 * @return void
		*/
		public function AssociateCssAsParrent(Css $objCss) {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCssAsParrent on this unsaved Css.');
			if ((is_null($objCss->Idcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCssAsParrent on this Css with an unsaved Css.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`css`
				SET
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
				WHERE
					`idcss` = ' . $objDatabase->SqlVariable($objCss->Idcss) . '
			');
		}

		/**
		 * Unassociates a CssAsParrent
		 * @param Css $objCss
		 * @return void
		*/
		public function UnassociateCssAsParrent(Css $objCss) {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCssAsParrent on this unsaved Css.');
			if ((is_null($objCss->Idcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCssAsParrent on this Css with an unsaved Css.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`css`
				SET
					`parrent` = null
				WHERE
					`idcss` = ' . $objDatabase->SqlVariable($objCss->Idcss) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
			');
		}

		/**
		 * Unassociates all CssesAsParrent
		 * @return void
		*/
		public function UnassociateAllCssesAsParrent() {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCssAsParrent on this unsaved Css.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`css`
				SET
					`parrent` = null
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
			');
		}

		/**
		 * Deletes an associated CssAsParrent
		 * @param Css $objCss
		 * @return void
		*/
		public function DeleteAssociatedCssAsParrent(Css $objCss) {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCssAsParrent on this unsaved Css.');
			if ((is_null($objCss->Idcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCssAsParrent on this Css with an unsaved Css.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`css`
				WHERE
					`idcss` = ' . $objDatabase->SqlVariable($objCss->Idcss) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
			');
		}

		/**
		 * Deletes all associated CssesAsParrent
		 * @return void
		*/
		public function DeleteAllCssesAsParrent() {
			if ((is_null($this->intIdcss)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCssAsParrent on this unsaved Css.');

			// Get the Database Object for this Class
			$objDatabase = Css::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`css`
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdcss) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "css";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Css::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Css"><sequence>';
			$strToReturn .= '<element name="Idcss" type="xsd:int"/>';
			$strToReturn .= '<element name="Name" type="xsd:string"/>';
			$strToReturn .= '<element name="Description" type="xsd:string"/>';
			$strToReturn .= '<element name="ParrentObject" type="xsd1:Css"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Css', $strComplexTypeArray)) {
				$strComplexTypeArray['Css'] = Css::GetSoapComplexTypeXml();
				Css::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Css::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Css();
			if (property_exists($objSoapObject, 'Idcss'))
				$objToReturn->intIdcss = $objSoapObject->Idcss;
			if (property_exists($objSoapObject, 'Name'))
				$objToReturn->strName = $objSoapObject->Name;
			if (property_exists($objSoapObject, 'Description'))
				$objToReturn->strDescription = $objSoapObject->Description;
			if ((property_exists($objSoapObject, 'ParrentObject')) &&
				($objSoapObject->ParrentObject))
				$objToReturn->ParrentObject = Css::GetObjectFromSoapObject($objSoapObject->ParrentObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Css::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objParrentObject)
				$objObject->objParrentObject = Css::GetSoapObjectFromObject($objObject->objParrentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intParrent = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idcss'] = $this->intIdcss;
			$iArray['Name'] = $this->strName;
			$iArray['Description'] = $this->strDescription;
			$iArray['Parrent'] = $this->intParrent;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdcss ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idcss
     * @property-read QQNode $Name
     * @property-read QQNode $Description
     * @property-read QQNode $Parrent
     * @property-read QQNodeCss $ParrentObject
     *
     *
     * @property-read QQReverseReferenceNodeArticle $Article
     * @property-read QQReverseReferenceNodeArticle $ArticleAsClass
     * @property-read QQReverseReferenceNodeCss $CssAsParrent

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeCss extends QQNode {
		protected $strTableName = 'css';
		protected $strPrimaryKey = 'idcss';
		protected $strClassName = 'Css';
		public function __get($strName) {
			switch ($strName) {
				case 'Idcss':
					return new QQNode('idcss', 'Idcss', 'Integer', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'VarChar', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'Blob', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'Integer', $this);
				case 'ParrentObject':
					return new QQNodeCss('parrent', 'ParrentObject', 'Integer', $this);
				case 'Article':
					return new QQReverseReferenceNodeArticle($this, 'article', 'reverse_reference', 'css');
				case 'ArticleAsClass':
					return new QQReverseReferenceNodeArticle($this, 'articleasclass', 'reverse_reference', 'class');
				case 'CssAsParrent':
					return new QQReverseReferenceNodeCss($this, 'cssasparrent', 'reverse_reference', 'parrent');

				case '_PrimaryKeyNode':
					return new QQNode('idcss', 'Idcss', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idcss
     * @property-read QQNode $Name
     * @property-read QQNode $Description
     * @property-read QQNode $Parrent
     * @property-read QQNodeCss $ParrentObject
     *
     *
     * @property-read QQReverseReferenceNodeArticle $Article
     * @property-read QQReverseReferenceNodeArticle $ArticleAsClass
     * @property-read QQReverseReferenceNodeCss $CssAsParrent

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeCss extends QQReverseReferenceNode {
		protected $strTableName = 'css';
		protected $strPrimaryKey = 'idcss';
		protected $strClassName = 'Css';
		public function __get($strName) {
			switch ($strName) {
				case 'Idcss':
					return new QQNode('idcss', 'Idcss', 'integer', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'string', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'string', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'integer', $this);
				case 'ParrentObject':
					return new QQNodeCss('parrent', 'ParrentObject', 'integer', $this);
				case 'Article':
					return new QQReverseReferenceNodeArticle($this, 'article', 'reverse_reference', 'css');
				case 'ArticleAsClass':
					return new QQReverseReferenceNodeArticle($this, 'articleasclass', 'reverse_reference', 'class');
				case 'CssAsParrent':
					return new QQReverseReferenceNodeCss($this, 'cssasparrent', 'reverse_reference', 'parrent');

				case '_PrimaryKeyNode':
					return new QQNode('idcss', 'Idcss', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
