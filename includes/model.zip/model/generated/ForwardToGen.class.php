<?php
	/**
	 * The abstract ForwardToGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the ForwardTo subclass which
	 * extends this ForwardToGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the ForwardTo class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdforwardTo the value for intIdforwardTo (Read-Only PK)
	 * @property integer $Ticket the value for intTicket (Not Null)
	 * @property integer $Dept the value for intDept (Not Null)
	 * @property integer $Post the value for intPost 
	 * @property integer $ForWhome the value for intForWhome 
	 * @property QDateTime $AssignedDate the value for dttAssignedDate 
	 * @property integer $ForwardedTo the value for intForwardedTo 
	 * @property QDateTime $ClosedDate the value for dttClosedDate 
	 * @property integer $Status the value for intStatus 
	 * @property ETicket $TicketObject the value for the ETicket object referenced by intTicket (Not Null)
	 * @property Role $DeptObject the value for the Role object referenced by intDept (Not Null)
	 * @property Role $PostObject the value for the Role object referenced by intPost 
	 * @property Login $ForWhomeObject the value for the Login object referenced by intForWhome 
	 * @property Login $ForwardedToObject the value for the Login object referenced by intForwardedTo 
	 * @property HelpdeskStatus $StatusObject the value for the HelpdeskStatus object referenced by intStatus 
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class ForwardToGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column forward_to.idforward_to
		 * @var integer intIdforwardTo
		 */
		protected $intIdforwardTo;
		const IdforwardToDefault = null;


		/**
		 * Protected member variable that maps to the database column forward_to.ticket
		 * @var integer intTicket
		 */
		protected $intTicket;
		const TicketDefault = null;


		/**
		 * Protected member variable that maps to the database column forward_to.dept
		 * @var integer intDept
		 */
		protected $intDept;
		const DeptDefault = null;


		/**
		 * Protected member variable that maps to the database column forward_to.post
		 * @var integer intPost
		 */
		protected $intPost;
		const PostDefault = null;


		/**
		 * Protected member variable that maps to the database column forward_to.for_whome
		 * @var integer intForWhome
		 */
		protected $intForWhome;
		const ForWhomeDefault = null;


		/**
		 * Protected member variable that maps to the database column forward_to.assigned_date
		 * @var QDateTime dttAssignedDate
		 */
		protected $dttAssignedDate;
		const AssignedDateDefault = null;


		/**
		 * Protected member variable that maps to the database column forward_to.forwarded_to
		 * @var integer intForwardedTo
		 */
		protected $intForwardedTo;
		const ForwardedToDefault = null;


		/**
		 * Protected member variable that maps to the database column forward_to.closed_date
		 * @var QDateTime dttClosedDate
		 */
		protected $dttClosedDate;
		const ClosedDateDefault = null;


		/**
		 * Protected member variable that maps to the database column forward_to.status
		 * @var integer intStatus
		 */
		protected $intStatus;
		const StatusDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column forward_to.ticket.
		 *
		 * NOTE: Always use the TicketObject property getter to correctly retrieve this ETicket object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var ETicket objTicketObject
		 */
		protected $objTicketObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column forward_to.dept.
		 *
		 * NOTE: Always use the DeptObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objDeptObject
		 */
		protected $objDeptObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column forward_to.post.
		 *
		 * NOTE: Always use the PostObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objPostObject
		 */
		protected $objPostObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column forward_to.for_whome.
		 *
		 * NOTE: Always use the ForWhomeObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objForWhomeObject
		 */
		protected $objForWhomeObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column forward_to.forwarded_to.
		 *
		 * NOTE: Always use the ForwardedToObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objForwardedToObject
		 */
		protected $objForwardedToObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column forward_to.status.
		 *
		 * NOTE: Always use the StatusObject property getter to correctly retrieve this HelpdeskStatus object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var HelpdeskStatus objStatusObject
		 */
		protected $objStatusObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdforwardTo = ForwardTo::IdforwardToDefault;
			$this->intTicket = ForwardTo::TicketDefault;
			$this->intDept = ForwardTo::DeptDefault;
			$this->intPost = ForwardTo::PostDefault;
			$this->intForWhome = ForwardTo::ForWhomeDefault;
			$this->dttAssignedDate = (ForwardTo::AssignedDateDefault === null)?null:new QDateTime(ForwardTo::AssignedDateDefault);
			$this->intForwardedTo = ForwardTo::ForwardedToDefault;
			$this->dttClosedDate = (ForwardTo::ClosedDateDefault === null)?null:new QDateTime(ForwardTo::ClosedDateDefault);
			$this->intStatus = ForwardTo::StatusDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a ForwardTo from PK Info
		 * @param integer $intIdforwardTo
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ForwardTo
		 */
		public static function Load($intIdforwardTo, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'ForwardTo', $intIdforwardTo);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = ForwardTo::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::ForwardTo()->IdforwardTo, $intIdforwardTo)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all ForwardTos
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ForwardTo[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call ForwardTo::QueryArray to perform the LoadAll query
			try {
				return ForwardTo::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all ForwardTos
		 * @return int
		 */
		public static function CountAll() {
			// Call ForwardTo::QueryCount to perform the CountAll query
			return ForwardTo::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = ForwardTo::GetDatabase();

			// Create/Build out the QueryBuilder object with ForwardTo-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'forward_to');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				ForwardTo::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('forward_to');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single ForwardTo object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return ForwardTo the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = ForwardTo::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new ForwardTo object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = ForwardTo::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return ForwardTo::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of ForwardTo objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return ForwardTo[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = ForwardTo::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return ForwardTo::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = ForwardTo::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of ForwardTo objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = ForwardTo::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = ForwardTo::GetDatabase();

			$strQuery = ForwardTo::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/forwardto', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = ForwardTo::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this ForwardTo
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'forward_to';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idforward_to', $strAliasPrefix . 'idforward_to');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idforward_to', $strAliasPrefix . 'idforward_to');
			    $objBuilder->AddSelectItem($strTableName, 'ticket', $strAliasPrefix . 'ticket');
			    $objBuilder->AddSelectItem($strTableName, 'dept', $strAliasPrefix . 'dept');
			    $objBuilder->AddSelectItem($strTableName, 'post', $strAliasPrefix . 'post');
			    $objBuilder->AddSelectItem($strTableName, 'for_whome', $strAliasPrefix . 'for_whome');
			    $objBuilder->AddSelectItem($strTableName, 'assigned_date', $strAliasPrefix . 'assigned_date');
			    $objBuilder->AddSelectItem($strTableName, 'forwarded_to', $strAliasPrefix . 'forwarded_to');
			    $objBuilder->AddSelectItem($strTableName, 'closed_date', $strAliasPrefix . 'closed_date');
			    $objBuilder->AddSelectItem($strTableName, 'status', $strAliasPrefix . 'status');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a ForwardTo from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this ForwardTo::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return ForwardTo
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the ForwardTo object
			$objToReturn = new ForwardTo();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idforward_to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdforwardTo = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'ticket';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intTicket = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'dept';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDept = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'post';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intPost = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'for_whome';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intForWhome = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'assigned_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttAssignedDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'forwarded_to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intForwardedTo = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'closed_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttClosedDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'status';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intStatus = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdforwardTo != $objPreviousItem->IdforwardTo) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'forward_to__';

			// Check for TicketObject Early Binding
			$strAlias = $strAliasPrefix . 'ticket__ide_ticket';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objTicketObject = ETicket::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ticket__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DeptObject Early Binding
			$strAlias = $strAliasPrefix . 'dept__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDeptObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'dept__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for PostObject Early Binding
			$strAlias = $strAliasPrefix . 'post__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objPostObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'post__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ForWhomeObject Early Binding
			$strAlias = $strAliasPrefix . 'for_whome__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objForWhomeObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'for_whome__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ForwardedToObject Early Binding
			$strAlias = $strAliasPrefix . 'forwarded_to__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objForwardedToObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'forwarded_to__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for StatusObject Early Binding
			$strAlias = $strAliasPrefix . 'status__idhelpdesk_status';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objStatusObject = HelpdeskStatus::InstantiateDbRow($objDbRow, $strAliasPrefix . 'status__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of ForwardTos from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return ForwardTo[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = ForwardTo::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = ForwardTo::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single ForwardTo object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return ForwardTo next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return ForwardTo::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single ForwardTo object,
		 * by IdforwardTo Index(es)
		 * @param integer $intIdforwardTo
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ForwardTo
		*/
		public static function LoadByIdforwardTo($intIdforwardTo, $objOptionalClauses = null) {
			return ForwardTo::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::ForwardTo()->IdforwardTo, $intIdforwardTo)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of ForwardTo objects,
		 * by Ticket Index(es)
		 * @param integer $intTicket
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ForwardTo[]
		*/
		public static function LoadArrayByTicket($intTicket, $objOptionalClauses = null) {
			// Call ForwardTo::QueryArray to perform the LoadArrayByTicket query
			try {
				return ForwardTo::QueryArray(
					QQ::Equal(QQN::ForwardTo()->Ticket, $intTicket),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ForwardTos
		 * by Ticket Index(es)
		 * @param integer $intTicket
		 * @return int
		*/
		public static function CountByTicket($intTicket) {
			// Call ForwardTo::QueryCount to perform the CountByTicket query
			return ForwardTo::QueryCount(
				QQ::Equal(QQN::ForwardTo()->Ticket, $intTicket)
			);
		}

		/**
		 * Load an array of ForwardTo objects,
		 * by Dept Index(es)
		 * @param integer $intDept
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ForwardTo[]
		*/
		public static function LoadArrayByDept($intDept, $objOptionalClauses = null) {
			// Call ForwardTo::QueryArray to perform the LoadArrayByDept query
			try {
				return ForwardTo::QueryArray(
					QQ::Equal(QQN::ForwardTo()->Dept, $intDept),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ForwardTos
		 * by Dept Index(es)
		 * @param integer $intDept
		 * @return int
		*/
		public static function CountByDept($intDept) {
			// Call ForwardTo::QueryCount to perform the CountByDept query
			return ForwardTo::QueryCount(
				QQ::Equal(QQN::ForwardTo()->Dept, $intDept)
			);
		}

		/**
		 * Load an array of ForwardTo objects,
		 * by Post Index(es)
		 * @param integer $intPost
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ForwardTo[]
		*/
		public static function LoadArrayByPost($intPost, $objOptionalClauses = null) {
			// Call ForwardTo::QueryArray to perform the LoadArrayByPost query
			try {
				return ForwardTo::QueryArray(
					QQ::Equal(QQN::ForwardTo()->Post, $intPost),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ForwardTos
		 * by Post Index(es)
		 * @param integer $intPost
		 * @return int
		*/
		public static function CountByPost($intPost) {
			// Call ForwardTo::QueryCount to perform the CountByPost query
			return ForwardTo::QueryCount(
				QQ::Equal(QQN::ForwardTo()->Post, $intPost)
			);
		}

		/**
		 * Load an array of ForwardTo objects,
		 * by ForWhome Index(es)
		 * @param integer $intForWhome
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ForwardTo[]
		*/
		public static function LoadArrayByForWhome($intForWhome, $objOptionalClauses = null) {
			// Call ForwardTo::QueryArray to perform the LoadArrayByForWhome query
			try {
				return ForwardTo::QueryArray(
					QQ::Equal(QQN::ForwardTo()->ForWhome, $intForWhome),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ForwardTos
		 * by ForWhome Index(es)
		 * @param integer $intForWhome
		 * @return int
		*/
		public static function CountByForWhome($intForWhome) {
			// Call ForwardTo::QueryCount to perform the CountByForWhome query
			return ForwardTo::QueryCount(
				QQ::Equal(QQN::ForwardTo()->ForWhome, $intForWhome)
			);
		}

		/**
		 * Load an array of ForwardTo objects,
		 * by ForwardedTo Index(es)
		 * @param integer $intForwardedTo
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ForwardTo[]
		*/
		public static function LoadArrayByForwardedTo($intForwardedTo, $objOptionalClauses = null) {
			// Call ForwardTo::QueryArray to perform the LoadArrayByForwardedTo query
			try {
				return ForwardTo::QueryArray(
					QQ::Equal(QQN::ForwardTo()->ForwardedTo, $intForwardedTo),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ForwardTos
		 * by ForwardedTo Index(es)
		 * @param integer $intForwardedTo
		 * @return int
		*/
		public static function CountByForwardedTo($intForwardedTo) {
			// Call ForwardTo::QueryCount to perform the CountByForwardedTo query
			return ForwardTo::QueryCount(
				QQ::Equal(QQN::ForwardTo()->ForwardedTo, $intForwardedTo)
			);
		}

		/**
		 * Load an array of ForwardTo objects,
		 * by Status Index(es)
		 * @param integer $intStatus
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ForwardTo[]
		*/
		public static function LoadArrayByStatus($intStatus, $objOptionalClauses = null) {
			// Call ForwardTo::QueryArray to perform the LoadArrayByStatus query
			try {
				return ForwardTo::QueryArray(
					QQ::Equal(QQN::ForwardTo()->Status, $intStatus),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ForwardTos
		 * by Status Index(es)
		 * @param integer $intStatus
		 * @return int
		*/
		public static function CountByStatus($intStatus) {
			// Call ForwardTo::QueryCount to perform the CountByStatus query
			return ForwardTo::QueryCount(
				QQ::Equal(QQN::ForwardTo()->Status, $intStatus)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this ForwardTo
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = ForwardTo::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `forward_to` (
							`ticket`,
							`dept`,
							`post`,
							`for_whome`,
							`assigned_date`,
							`forwarded_to`,
							`closed_date`,
							`status`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intTicket) . ',
							' . $objDatabase->SqlVariable($this->intDept) . ',
							' . $objDatabase->SqlVariable($this->intPost) . ',
							' . $objDatabase->SqlVariable($this->intForWhome) . ',
							' . $objDatabase->SqlVariable($this->dttAssignedDate) . ',
							' . $objDatabase->SqlVariable($this->intForwardedTo) . ',
							' . $objDatabase->SqlVariable($this->dttClosedDate) . ',
							' . $objDatabase->SqlVariable($this->intStatus) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdforwardTo = $objDatabase->InsertId('forward_to', 'idforward_to');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`forward_to`
						SET
							`ticket` = ' . $objDatabase->SqlVariable($this->intTicket) . ',
							`dept` = ' . $objDatabase->SqlVariable($this->intDept) . ',
							`post` = ' . $objDatabase->SqlVariable($this->intPost) . ',
							`for_whome` = ' . $objDatabase->SqlVariable($this->intForWhome) . ',
							`assigned_date` = ' . $objDatabase->SqlVariable($this->dttAssignedDate) . ',
							`forwarded_to` = ' . $objDatabase->SqlVariable($this->intForwardedTo) . ',
							`closed_date` = ' . $objDatabase->SqlVariable($this->dttClosedDate) . ',
							`status` = ' . $objDatabase->SqlVariable($this->intStatus) . '
						WHERE
							`idforward_to` = ' . $objDatabase->SqlVariable($this->intIdforwardTo) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this ForwardTo
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdforwardTo)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this ForwardTo with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = ForwardTo::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`forward_to`
				WHERE
					`idforward_to` = ' . $objDatabase->SqlVariable($this->intIdforwardTo) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this ForwardTo ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'ForwardTo', $this->intIdforwardTo);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all ForwardTos
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = ForwardTo::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`forward_to`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate forward_to table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = ForwardTo::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `forward_to`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this ForwardTo from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved ForwardTo object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = ForwardTo::Load($this->intIdforwardTo);

			// Update $this's local variables to match
			$this->Ticket = $objReloaded->Ticket;
			$this->Dept = $objReloaded->Dept;
			$this->Post = $objReloaded->Post;
			$this->ForWhome = $objReloaded->ForWhome;
			$this->dttAssignedDate = $objReloaded->dttAssignedDate;
			$this->ForwardedTo = $objReloaded->ForwardedTo;
			$this->dttClosedDate = $objReloaded->dttClosedDate;
			$this->Status = $objReloaded->Status;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdforwardTo':
					/**
					 * Gets the value for intIdforwardTo (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdforwardTo;

				case 'Ticket':
					/**
					 * Gets the value for intTicket (Not Null)
					 * @return integer
					 */
					return $this->intTicket;

				case 'Dept':
					/**
					 * Gets the value for intDept (Not Null)
					 * @return integer
					 */
					return $this->intDept;

				case 'Post':
					/**
					 * Gets the value for intPost 
					 * @return integer
					 */
					return $this->intPost;

				case 'ForWhome':
					/**
					 * Gets the value for intForWhome 
					 * @return integer
					 */
					return $this->intForWhome;

				case 'AssignedDate':
					/**
					 * Gets the value for dttAssignedDate 
					 * @return QDateTime
					 */
					return $this->dttAssignedDate;

				case 'ForwardedTo':
					/**
					 * Gets the value for intForwardedTo 
					 * @return integer
					 */
					return $this->intForwardedTo;

				case 'ClosedDate':
					/**
					 * Gets the value for dttClosedDate 
					 * @return QDateTime
					 */
					return $this->dttClosedDate;

				case 'Status':
					/**
					 * Gets the value for intStatus 
					 * @return integer
					 */
					return $this->intStatus;


				///////////////////
				// Member Objects
				///////////////////
				case 'TicketObject':
					/**
					 * Gets the value for the ETicket object referenced by intTicket (Not Null)
					 * @return ETicket
					 */
					try {
						if ((!$this->objTicketObject) && (!is_null($this->intTicket)))
							$this->objTicketObject = ETicket::Load($this->intTicket);
						return $this->objTicketObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DeptObject':
					/**
					 * Gets the value for the Role object referenced by intDept (Not Null)
					 * @return Role
					 */
					try {
						if ((!$this->objDeptObject) && (!is_null($this->intDept)))
							$this->objDeptObject = Role::Load($this->intDept);
						return $this->objDeptObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'PostObject':
					/**
					 * Gets the value for the Role object referenced by intPost 
					 * @return Role
					 */
					try {
						if ((!$this->objPostObject) && (!is_null($this->intPost)))
							$this->objPostObject = Role::Load($this->intPost);
						return $this->objPostObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ForWhomeObject':
					/**
					 * Gets the value for the Login object referenced by intForWhome 
					 * @return Login
					 */
					try {
						if ((!$this->objForWhomeObject) && (!is_null($this->intForWhome)))
							$this->objForWhomeObject = Login::Load($this->intForWhome);
						return $this->objForWhomeObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ForwardedToObject':
					/**
					 * Gets the value for the Login object referenced by intForwardedTo 
					 * @return Login
					 */
					try {
						if ((!$this->objForwardedToObject) && (!is_null($this->intForwardedTo)))
							$this->objForwardedToObject = Login::Load($this->intForwardedTo);
						return $this->objForwardedToObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'StatusObject':
					/**
					 * Gets the value for the HelpdeskStatus object referenced by intStatus 
					 * @return HelpdeskStatus
					 */
					try {
						if ((!$this->objStatusObject) && (!is_null($this->intStatus)))
							$this->objStatusObject = HelpdeskStatus::Load($this->intStatus);
						return $this->objStatusObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Ticket':
					/**
					 * Sets the value for intTicket (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objTicketObject = null;
						return ($this->intTicket = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Dept':
					/**
					 * Sets the value for intDept (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDeptObject = null;
						return ($this->intDept = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Post':
					/**
					 * Sets the value for intPost 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objPostObject = null;
						return ($this->intPost = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ForWhome':
					/**
					 * Sets the value for intForWhome 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objForWhomeObject = null;
						return ($this->intForWhome = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AssignedDate':
					/**
					 * Sets the value for dttAssignedDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttAssignedDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ForwardedTo':
					/**
					 * Sets the value for intForwardedTo 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objForwardedToObject = null;
						return ($this->intForwardedTo = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ClosedDate':
					/**
					 * Sets the value for dttClosedDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttClosedDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Status':
					/**
					 * Sets the value for intStatus 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objStatusObject = null;
						return ($this->intStatus = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'TicketObject':
					/**
					 * Sets the value for the ETicket object referenced by intTicket (Not Null)
					 * @param ETicket $mixValue
					 * @return ETicket
					 */
					if (is_null($mixValue)) {
						$this->intTicket = null;
						$this->objTicketObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a ETicket object
						try {
							$mixValue = QType::Cast($mixValue, 'ETicket');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED ETicket object
						if (is_null($mixValue->IdeTicket))
							throw new QCallerException('Unable to set an unsaved TicketObject for this ForwardTo');

						// Update Local Member Variables
						$this->objTicketObject = $mixValue;
						$this->intTicket = $mixValue->IdeTicket;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DeptObject':
					/**
					 * Sets the value for the Role object referenced by intDept (Not Null)
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intDept = null;
						$this->objDeptObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved DeptObject for this ForwardTo');

						// Update Local Member Variables
						$this->objDeptObject = $mixValue;
						$this->intDept = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'PostObject':
					/**
					 * Sets the value for the Role object referenced by intPost 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intPost = null;
						$this->objPostObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved PostObject for this ForwardTo');

						// Update Local Member Variables
						$this->objPostObject = $mixValue;
						$this->intPost = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ForWhomeObject':
					/**
					 * Sets the value for the Login object referenced by intForWhome 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intForWhome = null;
						$this->objForWhomeObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved ForWhomeObject for this ForwardTo');

						// Update Local Member Variables
						$this->objForWhomeObject = $mixValue;
						$this->intForWhome = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ForwardedToObject':
					/**
					 * Sets the value for the Login object referenced by intForwardedTo 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intForwardedTo = null;
						$this->objForwardedToObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved ForwardedToObject for this ForwardTo');

						// Update Local Member Variables
						$this->objForwardedToObject = $mixValue;
						$this->intForwardedTo = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'StatusObject':
					/**
					 * Sets the value for the HelpdeskStatus object referenced by intStatus 
					 * @param HelpdeskStatus $mixValue
					 * @return HelpdeskStatus
					 */
					if (is_null($mixValue)) {
						$this->intStatus = null;
						$this->objStatusObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a HelpdeskStatus object
						try {
							$mixValue = QType::Cast($mixValue, 'HelpdeskStatus');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED HelpdeskStatus object
						if (is_null($mixValue->IdhelpdeskStatus))
							throw new QCallerException('Unable to set an unsaved StatusObject for this ForwardTo');

						// Update Local Member Variables
						$this->objStatusObject = $mixValue;
						$this->intStatus = $mixValue->IdhelpdeskStatus;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "forward_to";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[ForwardTo::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="ForwardTo"><sequence>';
			$strToReturn .= '<element name="IdforwardTo" type="xsd:int"/>';
			$strToReturn .= '<element name="TicketObject" type="xsd1:ETicket"/>';
			$strToReturn .= '<element name="DeptObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="PostObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="ForWhomeObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="AssignedDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="ForwardedToObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="ClosedDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="StatusObject" type="xsd1:HelpdeskStatus"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('ForwardTo', $strComplexTypeArray)) {
				$strComplexTypeArray['ForwardTo'] = ForwardTo::GetSoapComplexTypeXml();
				ETicket::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				HelpdeskStatus::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, ForwardTo::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new ForwardTo();
			if (property_exists($objSoapObject, 'IdforwardTo'))
				$objToReturn->intIdforwardTo = $objSoapObject->IdforwardTo;
			if ((property_exists($objSoapObject, 'TicketObject')) &&
				($objSoapObject->TicketObject))
				$objToReturn->TicketObject = ETicket::GetObjectFromSoapObject($objSoapObject->TicketObject);
			if ((property_exists($objSoapObject, 'DeptObject')) &&
				($objSoapObject->DeptObject))
				$objToReturn->DeptObject = Role::GetObjectFromSoapObject($objSoapObject->DeptObject);
			if ((property_exists($objSoapObject, 'PostObject')) &&
				($objSoapObject->PostObject))
				$objToReturn->PostObject = Role::GetObjectFromSoapObject($objSoapObject->PostObject);
			if ((property_exists($objSoapObject, 'ForWhomeObject')) &&
				($objSoapObject->ForWhomeObject))
				$objToReturn->ForWhomeObject = Login::GetObjectFromSoapObject($objSoapObject->ForWhomeObject);
			if (property_exists($objSoapObject, 'AssignedDate'))
				$objToReturn->dttAssignedDate = new QDateTime($objSoapObject->AssignedDate);
			if ((property_exists($objSoapObject, 'ForwardedToObject')) &&
				($objSoapObject->ForwardedToObject))
				$objToReturn->ForwardedToObject = Login::GetObjectFromSoapObject($objSoapObject->ForwardedToObject);
			if (property_exists($objSoapObject, 'ClosedDate'))
				$objToReturn->dttClosedDate = new QDateTime($objSoapObject->ClosedDate);
			if ((property_exists($objSoapObject, 'StatusObject')) &&
				($objSoapObject->StatusObject))
				$objToReturn->StatusObject = HelpdeskStatus::GetObjectFromSoapObject($objSoapObject->StatusObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, ForwardTo::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objTicketObject)
				$objObject->objTicketObject = ETicket::GetSoapObjectFromObject($objObject->objTicketObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intTicket = null;
			if ($objObject->objDeptObject)
				$objObject->objDeptObject = Role::GetSoapObjectFromObject($objObject->objDeptObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDept = null;
			if ($objObject->objPostObject)
				$objObject->objPostObject = Role::GetSoapObjectFromObject($objObject->objPostObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intPost = null;
			if ($objObject->objForWhomeObject)
				$objObject->objForWhomeObject = Login::GetSoapObjectFromObject($objObject->objForWhomeObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intForWhome = null;
			if ($objObject->dttAssignedDate)
				$objObject->dttAssignedDate = $objObject->dttAssignedDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objForwardedToObject)
				$objObject->objForwardedToObject = Login::GetSoapObjectFromObject($objObject->objForwardedToObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intForwardedTo = null;
			if ($objObject->dttClosedDate)
				$objObject->dttClosedDate = $objObject->dttClosedDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objStatusObject)
				$objObject->objStatusObject = HelpdeskStatus::GetSoapObjectFromObject($objObject->objStatusObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intStatus = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdforwardTo'] = $this->intIdforwardTo;
			$iArray['Ticket'] = $this->intTicket;
			$iArray['Dept'] = $this->intDept;
			$iArray['Post'] = $this->intPost;
			$iArray['ForWhome'] = $this->intForWhome;
			$iArray['AssignedDate'] = $this->dttAssignedDate;
			$iArray['ForwardedTo'] = $this->intForwardedTo;
			$iArray['ClosedDate'] = $this->dttClosedDate;
			$iArray['Status'] = $this->intStatus;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdforwardTo ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdforwardTo
     * @property-read QQNode $Ticket
     * @property-read QQNodeETicket $TicketObject
     * @property-read QQNode $Dept
     * @property-read QQNodeRole $DeptObject
     * @property-read QQNode $Post
     * @property-read QQNodeRole $PostObject
     * @property-read QQNode $ForWhome
     * @property-read QQNodeLogin $ForWhomeObject
     * @property-read QQNode $AssignedDate
     * @property-read QQNode $ForwardedTo
     * @property-read QQNodeLogin $ForwardedToObject
     * @property-read QQNode $ClosedDate
     * @property-read QQNode $Status
     * @property-read QQNodeHelpdeskStatus $StatusObject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeForwardTo extends QQNode {
		protected $strTableName = 'forward_to';
		protected $strPrimaryKey = 'idforward_to';
		protected $strClassName = 'ForwardTo';
		public function __get($strName) {
			switch ($strName) {
				case 'IdforwardTo':
					return new QQNode('idforward_to', 'IdforwardTo', 'Integer', $this);
				case 'Ticket':
					return new QQNode('ticket', 'Ticket', 'Integer', $this);
				case 'TicketObject':
					return new QQNodeETicket('ticket', 'TicketObject', 'Integer', $this);
				case 'Dept':
					return new QQNode('dept', 'Dept', 'Integer', $this);
				case 'DeptObject':
					return new QQNodeRole('dept', 'DeptObject', 'Integer', $this);
				case 'Post':
					return new QQNode('post', 'Post', 'Integer', $this);
				case 'PostObject':
					return new QQNodeRole('post', 'PostObject', 'Integer', $this);
				case 'ForWhome':
					return new QQNode('for_whome', 'ForWhome', 'Integer', $this);
				case 'ForWhomeObject':
					return new QQNodeLogin('for_whome', 'ForWhomeObject', 'Integer', $this);
				case 'AssignedDate':
					return new QQNode('assigned_date', 'AssignedDate', 'DateTime', $this);
				case 'ForwardedTo':
					return new QQNode('forwarded_to', 'ForwardedTo', 'Integer', $this);
				case 'ForwardedToObject':
					return new QQNodeLogin('forwarded_to', 'ForwardedToObject', 'Integer', $this);
				case 'ClosedDate':
					return new QQNode('closed_date', 'ClosedDate', 'DateTime', $this);
				case 'Status':
					return new QQNode('status', 'Status', 'Integer', $this);
				case 'StatusObject':
					return new QQNodeHelpdeskStatus('status', 'StatusObject', 'Integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idforward_to', 'IdforwardTo', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdforwardTo
     * @property-read QQNode $Ticket
     * @property-read QQNodeETicket $TicketObject
     * @property-read QQNode $Dept
     * @property-read QQNodeRole $DeptObject
     * @property-read QQNode $Post
     * @property-read QQNodeRole $PostObject
     * @property-read QQNode $ForWhome
     * @property-read QQNodeLogin $ForWhomeObject
     * @property-read QQNode $AssignedDate
     * @property-read QQNode $ForwardedTo
     * @property-read QQNodeLogin $ForwardedToObject
     * @property-read QQNode $ClosedDate
     * @property-read QQNode $Status
     * @property-read QQNodeHelpdeskStatus $StatusObject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeForwardTo extends QQReverseReferenceNode {
		protected $strTableName = 'forward_to';
		protected $strPrimaryKey = 'idforward_to';
		protected $strClassName = 'ForwardTo';
		public function __get($strName) {
			switch ($strName) {
				case 'IdforwardTo':
					return new QQNode('idforward_to', 'IdforwardTo', 'integer', $this);
				case 'Ticket':
					return new QQNode('ticket', 'Ticket', 'integer', $this);
				case 'TicketObject':
					return new QQNodeETicket('ticket', 'TicketObject', 'integer', $this);
				case 'Dept':
					return new QQNode('dept', 'Dept', 'integer', $this);
				case 'DeptObject':
					return new QQNodeRole('dept', 'DeptObject', 'integer', $this);
				case 'Post':
					return new QQNode('post', 'Post', 'integer', $this);
				case 'PostObject':
					return new QQNodeRole('post', 'PostObject', 'integer', $this);
				case 'ForWhome':
					return new QQNode('for_whome', 'ForWhome', 'integer', $this);
				case 'ForWhomeObject':
					return new QQNodeLogin('for_whome', 'ForWhomeObject', 'integer', $this);
				case 'AssignedDate':
					return new QQNode('assigned_date', 'AssignedDate', 'QDateTime', $this);
				case 'ForwardedTo':
					return new QQNode('forwarded_to', 'ForwardedTo', 'integer', $this);
				case 'ForwardedToObject':
					return new QQNodeLogin('forwarded_to', 'ForwardedToObject', 'integer', $this);
				case 'ClosedDate':
					return new QQNode('closed_date', 'ClosedDate', 'QDateTime', $this);
				case 'Status':
					return new QQNode('status', 'Status', 'integer', $this);
				case 'StatusObject':
					return new QQNodeHelpdeskStatus('status', 'StatusObject', 'integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idforward_to', 'IdforwardTo', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
