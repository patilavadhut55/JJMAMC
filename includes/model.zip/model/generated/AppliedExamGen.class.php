<?php
	/**
	 * The abstract AppliedExamGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the AppliedExam subclass which
	 * extends this AppliedExamGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the AppliedExam class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdappliedExam the value for intIdappliedExam (Read-Only PK)
	 * @property integer $Student the value for intStudent 
	 * @property integer $StudRole the value for intStudRole 
	 * @property integer $EventExam the value for intEventExam 
	 * @property string $MarksObtained the value for strMarksObtained 
	 * @property integer $EventSubject the value for intEventSubject 
	 * @property integer $ExamType the value for intExamType 
	 * @property integer $YearlySubject the value for intYearlySubject 
	 * @property boolean $LockExam the value for blnLockExam 
	 * @property boolean $PrintDraft the value for blnPrintDraft 
	 * @property string $Remark the value for strRemark 
	 * @property string $CheckCode the value for strCheckCode 
	 * @property boolean $GradeImprovement the value for blnGradeImprovement 
	 * @property string $GraceCode the value for strGraceCode 
	 * @property string $ChInEse the value for strChInEse 
	 * @property string $AbsCode the value for strAbsCode 
	 * @property string $RelCode the value for strRelCode 
	 * @property integer $RefGradeImprovement the value for intRefGradeImprovement 
	 * @property Login $StudentObject the value for the Login object referenced by intStudent 
	 * @property Role $StudRoleObject the value for the Role object referenced by intStudRole 
	 * @property DeptYearEvents $EventExamObject the value for the DeptYearEvents object referenced by intEventExam 
	 * @property DeptYearEvents $EventSubjectObject the value for the DeptYearEvents object referenced by intEventSubject 
	 * @property Exam $ExamTypeObject the value for the Exam object referenced by intExamType 
	 * @property YearlySubject $YearlySubjectObject the value for the YearlySubject object referenced by intYearlySubject 
	 * @property ApplyGradeImproment $RefGradeImprovementObject the value for the ApplyGradeImproment object referenced by intRefGradeImprovement 
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class AppliedExamGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column applied_exam.idapplied_exam
		 * @var integer intIdappliedExam
		 */
		protected $intIdappliedExam;
		const IdappliedExamDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.student
		 * @var integer intStudent
		 */
		protected $intStudent;
		const StudentDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.stud_role
		 * @var integer intStudRole
		 */
		protected $intStudRole;
		const StudRoleDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.event_exam
		 * @var integer intEventExam
		 */
		protected $intEventExam;
		const EventExamDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.marks_obtained
		 * @var string strMarksObtained
		 */
		protected $strMarksObtained;
		const MarksObtainedMaxLength = 45;
		const MarksObtainedDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.event_subject
		 * @var integer intEventSubject
		 */
		protected $intEventSubject;
		const EventSubjectDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.exam_type
		 * @var integer intExamType
		 */
		protected $intExamType;
		const ExamTypeDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.yearly_subject
		 * @var integer intYearlySubject
		 */
		protected $intYearlySubject;
		const YearlySubjectDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.lock_exam
		 * @var boolean blnLockExam
		 */
		protected $blnLockExam;
		const LockExamDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.print_draft
		 * @var boolean blnPrintDraft
		 */
		protected $blnPrintDraft;
		const PrintDraftDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.remark
		 * @var string strRemark
		 */
		protected $strRemark;
		const RemarkDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.check_code
		 * @var string strCheckCode
		 */
		protected $strCheckCode;
		const CheckCodeMaxLength = 255;
		const CheckCodeDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.grade_improvement
		 * @var boolean blnGradeImprovement
		 */
		protected $blnGradeImprovement;
		const GradeImprovementDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.grace_code
		 * @var string strGraceCode
		 */
		protected $strGraceCode;
		const GraceCodeMaxLength = 255;
		const GraceCodeDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.ch_in_ese
		 * @var string strChInEse
		 */
		protected $strChInEse;
		const ChInEseMaxLength = 255;
		const ChInEseDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.abs_code
		 * @var string strAbsCode
		 */
		protected $strAbsCode;
		const AbsCodeMaxLength = 255;
		const AbsCodeDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.rel_code
		 * @var string strRelCode
		 */
		protected $strRelCode;
		const RelCodeMaxLength = 255;
		const RelCodeDefault = null;


		/**
		 * Protected member variable that maps to the database column applied_exam.ref_grade_improvement
		 * @var integer intRefGradeImprovement
		 */
		protected $intRefGradeImprovement;
		const RefGradeImprovementDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column applied_exam.student.
		 *
		 * NOTE: Always use the StudentObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objStudentObject
		 */
		protected $objStudentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column applied_exam.stud_role.
		 *
		 * NOTE: Always use the StudRoleObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objStudRoleObject
		 */
		protected $objStudRoleObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column applied_exam.event_exam.
		 *
		 * NOTE: Always use the EventExamObject property getter to correctly retrieve this DeptYearEvents object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var DeptYearEvents objEventExamObject
		 */
		protected $objEventExamObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column applied_exam.event_subject.
		 *
		 * NOTE: Always use the EventSubjectObject property getter to correctly retrieve this DeptYearEvents object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var DeptYearEvents objEventSubjectObject
		 */
		protected $objEventSubjectObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column applied_exam.exam_type.
		 *
		 * NOTE: Always use the ExamTypeObject property getter to correctly retrieve this Exam object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Exam objExamTypeObject
		 */
		protected $objExamTypeObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column applied_exam.yearly_subject.
		 *
		 * NOTE: Always use the YearlySubjectObject property getter to correctly retrieve this YearlySubject object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var YearlySubject objYearlySubjectObject
		 */
		protected $objYearlySubjectObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column applied_exam.ref_grade_improvement.
		 *
		 * NOTE: Always use the RefGradeImprovementObject property getter to correctly retrieve this ApplyGradeImproment object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var ApplyGradeImproment objRefGradeImprovementObject
		 */
		protected $objRefGradeImprovementObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdappliedExam = AppliedExam::IdappliedExamDefault;
			$this->intStudent = AppliedExam::StudentDefault;
			$this->intStudRole = AppliedExam::StudRoleDefault;
			$this->intEventExam = AppliedExam::EventExamDefault;
			$this->strMarksObtained = AppliedExam::MarksObtainedDefault;
			$this->intEventSubject = AppliedExam::EventSubjectDefault;
			$this->intExamType = AppliedExam::ExamTypeDefault;
			$this->intYearlySubject = AppliedExam::YearlySubjectDefault;
			$this->blnLockExam = AppliedExam::LockExamDefault;
			$this->blnPrintDraft = AppliedExam::PrintDraftDefault;
			$this->strRemark = AppliedExam::RemarkDefault;
			$this->strCheckCode = AppliedExam::CheckCodeDefault;
			$this->blnGradeImprovement = AppliedExam::GradeImprovementDefault;
			$this->strGraceCode = AppliedExam::GraceCodeDefault;
			$this->strChInEse = AppliedExam::ChInEseDefault;
			$this->strAbsCode = AppliedExam::AbsCodeDefault;
			$this->strRelCode = AppliedExam::RelCodeDefault;
			$this->intRefGradeImprovement = AppliedExam::RefGradeImprovementDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a AppliedExam from PK Info
		 * @param integer $intIdappliedExam
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppliedExam
		 */
		public static function Load($intIdappliedExam, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'AppliedExam', $intIdappliedExam);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = AppliedExam::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::AppliedExam()->IdappliedExam, $intIdappliedExam)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all AppliedExams
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppliedExam[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call AppliedExam::QueryArray to perform the LoadAll query
			try {
				return AppliedExam::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all AppliedExams
		 * @return int
		 */
		public static function CountAll() {
			// Call AppliedExam::QueryCount to perform the CountAll query
			return AppliedExam::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = AppliedExam::GetDatabase();

			// Create/Build out the QueryBuilder object with AppliedExam-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'applied_exam');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				AppliedExam::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('applied_exam');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single AppliedExam object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return AppliedExam the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = AppliedExam::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new AppliedExam object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = AppliedExam::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return AppliedExam::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of AppliedExam objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return AppliedExam[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = AppliedExam::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return AppliedExam::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = AppliedExam::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of AppliedExam objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = AppliedExam::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = AppliedExam::GetDatabase();

			$strQuery = AppliedExam::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/appliedexam', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = AppliedExam::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this AppliedExam
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'applied_exam';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idapplied_exam', $strAliasPrefix . 'idapplied_exam');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idapplied_exam', $strAliasPrefix . 'idapplied_exam');
			    $objBuilder->AddSelectItem($strTableName, 'student', $strAliasPrefix . 'student');
			    $objBuilder->AddSelectItem($strTableName, 'stud_role', $strAliasPrefix . 'stud_role');
			    $objBuilder->AddSelectItem($strTableName, 'event_exam', $strAliasPrefix . 'event_exam');
			    $objBuilder->AddSelectItem($strTableName, 'marks_obtained', $strAliasPrefix . 'marks_obtained');
			    $objBuilder->AddSelectItem($strTableName, 'event_subject', $strAliasPrefix . 'event_subject');
			    $objBuilder->AddSelectItem($strTableName, 'exam_type', $strAliasPrefix . 'exam_type');
			    $objBuilder->AddSelectItem($strTableName, 'yearly_subject', $strAliasPrefix . 'yearly_subject');
			    $objBuilder->AddSelectItem($strTableName, 'lock_exam', $strAliasPrefix . 'lock_exam');
			    $objBuilder->AddSelectItem($strTableName, 'print_draft', $strAliasPrefix . 'print_draft');
			    $objBuilder->AddSelectItem($strTableName, 'remark', $strAliasPrefix . 'remark');
			    $objBuilder->AddSelectItem($strTableName, 'check_code', $strAliasPrefix . 'check_code');
			    $objBuilder->AddSelectItem($strTableName, 'grade_improvement', $strAliasPrefix . 'grade_improvement');
			    $objBuilder->AddSelectItem($strTableName, 'grace_code', $strAliasPrefix . 'grace_code');
			    $objBuilder->AddSelectItem($strTableName, 'ch_in_ese', $strAliasPrefix . 'ch_in_ese');
			    $objBuilder->AddSelectItem($strTableName, 'abs_code', $strAliasPrefix . 'abs_code');
			    $objBuilder->AddSelectItem($strTableName, 'rel_code', $strAliasPrefix . 'rel_code');
			    $objBuilder->AddSelectItem($strTableName, 'ref_grade_improvement', $strAliasPrefix . 'ref_grade_improvement');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a AppliedExam from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this AppliedExam::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return AppliedExam
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the AppliedExam object
			$objToReturn = new AppliedExam();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idapplied_exam';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdappliedExam = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'student';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intStudent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'stud_role';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intStudRole = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'event_exam';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intEventExam = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'marks_obtained';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strMarksObtained = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'event_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intEventSubject = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'exam_type';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intExamType = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'yearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intYearlySubject = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'lock_exam';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnLockExam = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'print_draft';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnPrintDraft = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'remark';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strRemark = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'check_code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCheckCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'grade_improvement';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnGradeImprovement = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'grace_code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strGraceCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'ch_in_ese';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strChInEse = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'abs_code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strAbsCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'rel_code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strRelCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'ref_grade_improvement';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intRefGradeImprovement = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdappliedExam != $objPreviousItem->IdappliedExam) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'applied_exam__';

			// Check for StudentObject Early Binding
			$strAlias = $strAliasPrefix . 'student__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objStudentObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'student__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for StudRoleObject Early Binding
			$strAlias = $strAliasPrefix . 'stud_role__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objStudRoleObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'stud_role__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for EventExamObject Early Binding
			$strAlias = $strAliasPrefix . 'event_exam__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objEventExamObject = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'event_exam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for EventSubjectObject Early Binding
			$strAlias = $strAliasPrefix . 'event_subject__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objEventSubjectObject = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'event_subject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ExamTypeObject Early Binding
			$strAlias = $strAliasPrefix . 'exam_type__idexam';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objExamTypeObject = Exam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'exam_type__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for YearlySubjectObject Early Binding
			$strAlias = $strAliasPrefix . 'yearly_subject__idyearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objYearlySubjectObject = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearly_subject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for RefGradeImprovementObject Early Binding
			$strAlias = $strAliasPrefix . 'ref_grade_improvement__idapply_grade_improment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objRefGradeImprovementObject = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ref_grade_improvement__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of AppliedExams from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return AppliedExam[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = AppliedExam::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = AppliedExam::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single AppliedExam object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return AppliedExam next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return AppliedExam::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single AppliedExam object,
		 * by IdappliedExam Index(es)
		 * @param integer $intIdappliedExam
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppliedExam
		*/
		public static function LoadByIdappliedExam($intIdappliedExam, $objOptionalClauses = null) {
			return AppliedExam::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::AppliedExam()->IdappliedExam, $intIdappliedExam)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of AppliedExam objects,
		 * by Student Index(es)
		 * @param integer $intStudent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppliedExam[]
		*/
		public static function LoadArrayByStudent($intStudent, $objOptionalClauses = null) {
			// Call AppliedExam::QueryArray to perform the LoadArrayByStudent query
			try {
				return AppliedExam::QueryArray(
					QQ::Equal(QQN::AppliedExam()->Student, $intStudent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count AppliedExams
		 * by Student Index(es)
		 * @param integer $intStudent
		 * @return int
		*/
		public static function CountByStudent($intStudent) {
			// Call AppliedExam::QueryCount to perform the CountByStudent query
			return AppliedExam::QueryCount(
				QQ::Equal(QQN::AppliedExam()->Student, $intStudent)
			);
		}

		/**
		 * Load an array of AppliedExam objects,
		 * by StudRole Index(es)
		 * @param integer $intStudRole
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppliedExam[]
		*/
		public static function LoadArrayByStudRole($intStudRole, $objOptionalClauses = null) {
			// Call AppliedExam::QueryArray to perform the LoadArrayByStudRole query
			try {
				return AppliedExam::QueryArray(
					QQ::Equal(QQN::AppliedExam()->StudRole, $intStudRole),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count AppliedExams
		 * by StudRole Index(es)
		 * @param integer $intStudRole
		 * @return int
		*/
		public static function CountByStudRole($intStudRole) {
			// Call AppliedExam::QueryCount to perform the CountByStudRole query
			return AppliedExam::QueryCount(
				QQ::Equal(QQN::AppliedExam()->StudRole, $intStudRole)
			);
		}

		/**
		 * Load an array of AppliedExam objects,
		 * by EventSubject Index(es)
		 * @param integer $intEventSubject
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppliedExam[]
		*/
		public static function LoadArrayByEventSubject($intEventSubject, $objOptionalClauses = null) {
			// Call AppliedExam::QueryArray to perform the LoadArrayByEventSubject query
			try {
				return AppliedExam::QueryArray(
					QQ::Equal(QQN::AppliedExam()->EventSubject, $intEventSubject),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count AppliedExams
		 * by EventSubject Index(es)
		 * @param integer $intEventSubject
		 * @return int
		*/
		public static function CountByEventSubject($intEventSubject) {
			// Call AppliedExam::QueryCount to perform the CountByEventSubject query
			return AppliedExam::QueryCount(
				QQ::Equal(QQN::AppliedExam()->EventSubject, $intEventSubject)
			);
		}

		/**
		 * Load an array of AppliedExam objects,
		 * by EventExam Index(es)
		 * @param integer $intEventExam
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppliedExam[]
		*/
		public static function LoadArrayByEventExam($intEventExam, $objOptionalClauses = null) {
			// Call AppliedExam::QueryArray to perform the LoadArrayByEventExam query
			try {
				return AppliedExam::QueryArray(
					QQ::Equal(QQN::AppliedExam()->EventExam, $intEventExam),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count AppliedExams
		 * by EventExam Index(es)
		 * @param integer $intEventExam
		 * @return int
		*/
		public static function CountByEventExam($intEventExam) {
			// Call AppliedExam::QueryCount to perform the CountByEventExam query
			return AppliedExam::QueryCount(
				QQ::Equal(QQN::AppliedExam()->EventExam, $intEventExam)
			);
		}

		/**
		 * Load an array of AppliedExam objects,
		 * by YearlySubject Index(es)
		 * @param integer $intYearlySubject
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppliedExam[]
		*/
		public static function LoadArrayByYearlySubject($intYearlySubject, $objOptionalClauses = null) {
			// Call AppliedExam::QueryArray to perform the LoadArrayByYearlySubject query
			try {
				return AppliedExam::QueryArray(
					QQ::Equal(QQN::AppliedExam()->YearlySubject, $intYearlySubject),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count AppliedExams
		 * by YearlySubject Index(es)
		 * @param integer $intYearlySubject
		 * @return int
		*/
		public static function CountByYearlySubject($intYearlySubject) {
			// Call AppliedExam::QueryCount to perform the CountByYearlySubject query
			return AppliedExam::QueryCount(
				QQ::Equal(QQN::AppliedExam()->YearlySubject, $intYearlySubject)
			);
		}

		/**
		 * Load an array of AppliedExam objects,
		 * by ExamType Index(es)
		 * @param integer $intExamType
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppliedExam[]
		*/
		public static function LoadArrayByExamType($intExamType, $objOptionalClauses = null) {
			// Call AppliedExam::QueryArray to perform the LoadArrayByExamType query
			try {
				return AppliedExam::QueryArray(
					QQ::Equal(QQN::AppliedExam()->ExamType, $intExamType),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count AppliedExams
		 * by ExamType Index(es)
		 * @param integer $intExamType
		 * @return int
		*/
		public static function CountByExamType($intExamType) {
			// Call AppliedExam::QueryCount to perform the CountByExamType query
			return AppliedExam::QueryCount(
				QQ::Equal(QQN::AppliedExam()->ExamType, $intExamType)
			);
		}

		/**
		 * Load an array of AppliedExam objects,
		 * by RefGradeImprovement Index(es)
		 * @param integer $intRefGradeImprovement
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppliedExam[]
		*/
		public static function LoadArrayByRefGradeImprovement($intRefGradeImprovement, $objOptionalClauses = null) {
			// Call AppliedExam::QueryArray to perform the LoadArrayByRefGradeImprovement query
			try {
				return AppliedExam::QueryArray(
					QQ::Equal(QQN::AppliedExam()->RefGradeImprovement, $intRefGradeImprovement),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count AppliedExams
		 * by RefGradeImprovement Index(es)
		 * @param integer $intRefGradeImprovement
		 * @return int
		*/
		public static function CountByRefGradeImprovement($intRefGradeImprovement) {
			// Call AppliedExam::QueryCount to perform the CountByRefGradeImprovement query
			return AppliedExam::QueryCount(
				QQ::Equal(QQN::AppliedExam()->RefGradeImprovement, $intRefGradeImprovement)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this AppliedExam
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = AppliedExam::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `applied_exam` (
							`student`,
							`stud_role`,
							`event_exam`,
							`marks_obtained`,
							`event_subject`,
							`exam_type`,
							`yearly_subject`,
							`lock_exam`,
							`print_draft`,
							`remark`,
							`check_code`,
							`grade_improvement`,
							`grace_code`,
							`ch_in_ese`,
							`abs_code`,
							`rel_code`,
							`ref_grade_improvement`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intStudent) . ',
							' . $objDatabase->SqlVariable($this->intStudRole) . ',
							' . $objDatabase->SqlVariable($this->intEventExam) . ',
							' . $objDatabase->SqlVariable($this->strMarksObtained) . ',
							' . $objDatabase->SqlVariable($this->intEventSubject) . ',
							' . $objDatabase->SqlVariable($this->intExamType) . ',
							' . $objDatabase->SqlVariable($this->intYearlySubject) . ',
							' . $objDatabase->SqlVariable($this->blnLockExam) . ',
							' . $objDatabase->SqlVariable($this->blnPrintDraft) . ',
							' . $objDatabase->SqlVariable($this->strRemark) . ',
							' . $objDatabase->SqlVariable($this->strCheckCode) . ',
							' . $objDatabase->SqlVariable($this->blnGradeImprovement) . ',
							' . $objDatabase->SqlVariable($this->strGraceCode) . ',
							' . $objDatabase->SqlVariable($this->strChInEse) . ',
							' . $objDatabase->SqlVariable($this->strAbsCode) . ',
							' . $objDatabase->SqlVariable($this->strRelCode) . ',
							' . $objDatabase->SqlVariable($this->intRefGradeImprovement) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdappliedExam = $objDatabase->InsertId('applied_exam', 'idapplied_exam');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`applied_exam`
						SET
							`student` = ' . $objDatabase->SqlVariable($this->intStudent) . ',
							`stud_role` = ' . $objDatabase->SqlVariable($this->intStudRole) . ',
							`event_exam` = ' . $objDatabase->SqlVariable($this->intEventExam) . ',
							`marks_obtained` = ' . $objDatabase->SqlVariable($this->strMarksObtained) . ',
							`event_subject` = ' . $objDatabase->SqlVariable($this->intEventSubject) . ',
							`exam_type` = ' . $objDatabase->SqlVariable($this->intExamType) . ',
							`yearly_subject` = ' . $objDatabase->SqlVariable($this->intYearlySubject) . ',
							`lock_exam` = ' . $objDatabase->SqlVariable($this->blnLockExam) . ',
							`print_draft` = ' . $objDatabase->SqlVariable($this->blnPrintDraft) . ',
							`remark` = ' . $objDatabase->SqlVariable($this->strRemark) . ',
							`check_code` = ' . $objDatabase->SqlVariable($this->strCheckCode) . ',
							`grade_improvement` = ' . $objDatabase->SqlVariable($this->blnGradeImprovement) . ',
							`grace_code` = ' . $objDatabase->SqlVariable($this->strGraceCode) . ',
							`ch_in_ese` = ' . $objDatabase->SqlVariable($this->strChInEse) . ',
							`abs_code` = ' . $objDatabase->SqlVariable($this->strAbsCode) . ',
							`rel_code` = ' . $objDatabase->SqlVariable($this->strRelCode) . ',
							`ref_grade_improvement` = ' . $objDatabase->SqlVariable($this->intRefGradeImprovement) . '
						WHERE
							`idapplied_exam` = ' . $objDatabase->SqlVariable($this->intIdappliedExam) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this AppliedExam
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this AppliedExam with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = AppliedExam::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`applied_exam`
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($this->intIdappliedExam) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this AppliedExam ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'AppliedExam', $this->intIdappliedExam);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all AppliedExams
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = AppliedExam::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`applied_exam`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate applied_exam table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = AppliedExam::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `applied_exam`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this AppliedExam from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved AppliedExam object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = AppliedExam::Load($this->intIdappliedExam);

			// Update $this's local variables to match
			$this->Student = $objReloaded->Student;
			$this->StudRole = $objReloaded->StudRole;
			$this->EventExam = $objReloaded->EventExam;
			$this->strMarksObtained = $objReloaded->strMarksObtained;
			$this->EventSubject = $objReloaded->EventSubject;
			$this->ExamType = $objReloaded->ExamType;
			$this->YearlySubject = $objReloaded->YearlySubject;
			$this->blnLockExam = $objReloaded->blnLockExam;
			$this->blnPrintDraft = $objReloaded->blnPrintDraft;
			$this->strRemark = $objReloaded->strRemark;
			$this->strCheckCode = $objReloaded->strCheckCode;
			$this->blnGradeImprovement = $objReloaded->blnGradeImprovement;
			$this->strGraceCode = $objReloaded->strGraceCode;
			$this->strChInEse = $objReloaded->strChInEse;
			$this->strAbsCode = $objReloaded->strAbsCode;
			$this->strRelCode = $objReloaded->strRelCode;
			$this->RefGradeImprovement = $objReloaded->RefGradeImprovement;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdappliedExam':
					/**
					 * Gets the value for intIdappliedExam (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdappliedExam;

				case 'Student':
					/**
					 * Gets the value for intStudent 
					 * @return integer
					 */
					return $this->intStudent;

				case 'StudRole':
					/**
					 * Gets the value for intStudRole 
					 * @return integer
					 */
					return $this->intStudRole;

				case 'EventExam':
					/**
					 * Gets the value for intEventExam 
					 * @return integer
					 */
					return $this->intEventExam;

				case 'MarksObtained':
					/**
					 * Gets the value for strMarksObtained 
					 * @return string
					 */
					return $this->strMarksObtained;

				case 'EventSubject':
					/**
					 * Gets the value for intEventSubject 
					 * @return integer
					 */
					return $this->intEventSubject;

				case 'ExamType':
					/**
					 * Gets the value for intExamType 
					 * @return integer
					 */
					return $this->intExamType;

				case 'YearlySubject':
					/**
					 * Gets the value for intYearlySubject 
					 * @return integer
					 */
					return $this->intYearlySubject;

				case 'LockExam':
					/**
					 * Gets the value for blnLockExam 
					 * @return boolean
					 */
					return $this->blnLockExam;

				case 'PrintDraft':
					/**
					 * Gets the value for blnPrintDraft 
					 * @return boolean
					 */
					return $this->blnPrintDraft;

				case 'Remark':
					/**
					 * Gets the value for strRemark 
					 * @return string
					 */
					return $this->strRemark;

				case 'CheckCode':
					/**
					 * Gets the value for strCheckCode 
					 * @return string
					 */
					return $this->strCheckCode;

				case 'GradeImprovement':
					/**
					 * Gets the value for blnGradeImprovement 
					 * @return boolean
					 */
					return $this->blnGradeImprovement;

				case 'GraceCode':
					/**
					 * Gets the value for strGraceCode 
					 * @return string
					 */
					return $this->strGraceCode;

				case 'ChInEse':
					/**
					 * Gets the value for strChInEse 
					 * @return string
					 */
					return $this->strChInEse;

				case 'AbsCode':
					/**
					 * Gets the value for strAbsCode 
					 * @return string
					 */
					return $this->strAbsCode;

				case 'RelCode':
					/**
					 * Gets the value for strRelCode 
					 * @return string
					 */
					return $this->strRelCode;

				case 'RefGradeImprovement':
					/**
					 * Gets the value for intRefGradeImprovement 
					 * @return integer
					 */
					return $this->intRefGradeImprovement;


				///////////////////
				// Member Objects
				///////////////////
				case 'StudentObject':
					/**
					 * Gets the value for the Login object referenced by intStudent 
					 * @return Login
					 */
					try {
						if ((!$this->objStudentObject) && (!is_null($this->intStudent)))
							$this->objStudentObject = Login::Load($this->intStudent);
						return $this->objStudentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'StudRoleObject':
					/**
					 * Gets the value for the Role object referenced by intStudRole 
					 * @return Role
					 */
					try {
						if ((!$this->objStudRoleObject) && (!is_null($this->intStudRole)))
							$this->objStudRoleObject = Role::Load($this->intStudRole);
						return $this->objStudRoleObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'EventExamObject':
					/**
					 * Gets the value for the DeptYearEvents object referenced by intEventExam 
					 * @return DeptYearEvents
					 */
					try {
						if ((!$this->objEventExamObject) && (!is_null($this->intEventExam)))
							$this->objEventExamObject = DeptYearEvents::Load($this->intEventExam);
						return $this->objEventExamObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'EventSubjectObject':
					/**
					 * Gets the value for the DeptYearEvents object referenced by intEventSubject 
					 * @return DeptYearEvents
					 */
					try {
						if ((!$this->objEventSubjectObject) && (!is_null($this->intEventSubject)))
							$this->objEventSubjectObject = DeptYearEvents::Load($this->intEventSubject);
						return $this->objEventSubjectObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ExamTypeObject':
					/**
					 * Gets the value for the Exam object referenced by intExamType 
					 * @return Exam
					 */
					try {
						if ((!$this->objExamTypeObject) && (!is_null($this->intExamType)))
							$this->objExamTypeObject = Exam::Load($this->intExamType);
						return $this->objExamTypeObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'YearlySubjectObject':
					/**
					 * Gets the value for the YearlySubject object referenced by intYearlySubject 
					 * @return YearlySubject
					 */
					try {
						if ((!$this->objYearlySubjectObject) && (!is_null($this->intYearlySubject)))
							$this->objYearlySubjectObject = YearlySubject::Load($this->intYearlySubject);
						return $this->objYearlySubjectObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RefGradeImprovementObject':
					/**
					 * Gets the value for the ApplyGradeImproment object referenced by intRefGradeImprovement 
					 * @return ApplyGradeImproment
					 */
					try {
						if ((!$this->objRefGradeImprovementObject) && (!is_null($this->intRefGradeImprovement)))
							$this->objRefGradeImprovementObject = ApplyGradeImproment::Load($this->intRefGradeImprovement);
						return $this->objRefGradeImprovementObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Student':
					/**
					 * Sets the value for intStudent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objStudentObject = null;
						return ($this->intStudent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'StudRole':
					/**
					 * Sets the value for intStudRole 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objStudRoleObject = null;
						return ($this->intStudRole = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'EventExam':
					/**
					 * Sets the value for intEventExam 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objEventExamObject = null;
						return ($this->intEventExam = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'MarksObtained':
					/**
					 * Sets the value for strMarksObtained 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strMarksObtained = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'EventSubject':
					/**
					 * Sets the value for intEventSubject 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objEventSubjectObject = null;
						return ($this->intEventSubject = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ExamType':
					/**
					 * Sets the value for intExamType 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objExamTypeObject = null;
						return ($this->intExamType = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'YearlySubject':
					/**
					 * Sets the value for intYearlySubject 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objYearlySubjectObject = null;
						return ($this->intYearlySubject = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LockExam':
					/**
					 * Sets the value for blnLockExam 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnLockExam = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'PrintDraft':
					/**
					 * Sets the value for blnPrintDraft 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnPrintDraft = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Remark':
					/**
					 * Sets the value for strRemark 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strRemark = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CheckCode':
					/**
					 * Sets the value for strCheckCode 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCheckCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GradeImprovement':
					/**
					 * Sets the value for blnGradeImprovement 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnGradeImprovement = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GraceCode':
					/**
					 * Sets the value for strGraceCode 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strGraceCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ChInEse':
					/**
					 * Sets the value for strChInEse 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strChInEse = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AbsCode':
					/**
					 * Sets the value for strAbsCode 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strAbsCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RelCode':
					/**
					 * Sets the value for strRelCode 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strRelCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RefGradeImprovement':
					/**
					 * Sets the value for intRefGradeImprovement 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objRefGradeImprovementObject = null;
						return ($this->intRefGradeImprovement = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'StudentObject':
					/**
					 * Sets the value for the Login object referenced by intStudent 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intStudent = null;
						$this->objStudentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved StudentObject for this AppliedExam');

						// Update Local Member Variables
						$this->objStudentObject = $mixValue;
						$this->intStudent = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'StudRoleObject':
					/**
					 * Sets the value for the Role object referenced by intStudRole 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intStudRole = null;
						$this->objStudRoleObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved StudRoleObject for this AppliedExam');

						// Update Local Member Variables
						$this->objStudRoleObject = $mixValue;
						$this->intStudRole = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'EventExamObject':
					/**
					 * Sets the value for the DeptYearEvents object referenced by intEventExam 
					 * @param DeptYearEvents $mixValue
					 * @return DeptYearEvents
					 */
					if (is_null($mixValue)) {
						$this->intEventExam = null;
						$this->objEventExamObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a DeptYearEvents object
						try {
							$mixValue = QType::Cast($mixValue, 'DeptYearEvents');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED DeptYearEvents object
						if (is_null($mixValue->IddeptYearEvents))
							throw new QCallerException('Unable to set an unsaved EventExamObject for this AppliedExam');

						// Update Local Member Variables
						$this->objEventExamObject = $mixValue;
						$this->intEventExam = $mixValue->IddeptYearEvents;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'EventSubjectObject':
					/**
					 * Sets the value for the DeptYearEvents object referenced by intEventSubject 
					 * @param DeptYearEvents $mixValue
					 * @return DeptYearEvents
					 */
					if (is_null($mixValue)) {
						$this->intEventSubject = null;
						$this->objEventSubjectObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a DeptYearEvents object
						try {
							$mixValue = QType::Cast($mixValue, 'DeptYearEvents');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED DeptYearEvents object
						if (is_null($mixValue->IddeptYearEvents))
							throw new QCallerException('Unable to set an unsaved EventSubjectObject for this AppliedExam');

						// Update Local Member Variables
						$this->objEventSubjectObject = $mixValue;
						$this->intEventSubject = $mixValue->IddeptYearEvents;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ExamTypeObject':
					/**
					 * Sets the value for the Exam object referenced by intExamType 
					 * @param Exam $mixValue
					 * @return Exam
					 */
					if (is_null($mixValue)) {
						$this->intExamType = null;
						$this->objExamTypeObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Exam object
						try {
							$mixValue = QType::Cast($mixValue, 'Exam');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Exam object
						if (is_null($mixValue->Idexam))
							throw new QCallerException('Unable to set an unsaved ExamTypeObject for this AppliedExam');

						// Update Local Member Variables
						$this->objExamTypeObject = $mixValue;
						$this->intExamType = $mixValue->Idexam;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'YearlySubjectObject':
					/**
					 * Sets the value for the YearlySubject object referenced by intYearlySubject 
					 * @param YearlySubject $mixValue
					 * @return YearlySubject
					 */
					if (is_null($mixValue)) {
						$this->intYearlySubject = null;
						$this->objYearlySubjectObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a YearlySubject object
						try {
							$mixValue = QType::Cast($mixValue, 'YearlySubject');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED YearlySubject object
						if (is_null($mixValue->IdyearlySubject))
							throw new QCallerException('Unable to set an unsaved YearlySubjectObject for this AppliedExam');

						// Update Local Member Variables
						$this->objYearlySubjectObject = $mixValue;
						$this->intYearlySubject = $mixValue->IdyearlySubject;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'RefGradeImprovementObject':
					/**
					 * Sets the value for the ApplyGradeImproment object referenced by intRefGradeImprovement 
					 * @param ApplyGradeImproment $mixValue
					 * @return ApplyGradeImproment
					 */
					if (is_null($mixValue)) {
						$this->intRefGradeImprovement = null;
						$this->objRefGradeImprovementObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a ApplyGradeImproment object
						try {
							$mixValue = QType::Cast($mixValue, 'ApplyGradeImproment');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED ApplyGradeImproment object
						if (is_null($mixValue->IdapplyGradeImproment))
							throw new QCallerException('Unable to set an unsaved RefGradeImprovementObject for this AppliedExam');

						// Update Local Member Variables
						$this->objRefGradeImprovementObject = $mixValue;
						$this->intRefGradeImprovement = $mixValue->IdapplyGradeImproment;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "applied_exam";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[AppliedExam::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="AppliedExam"><sequence>';
			$strToReturn .= '<element name="IdappliedExam" type="xsd:int"/>';
			$strToReturn .= '<element name="StudentObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="StudRoleObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="EventExamObject" type="xsd1:DeptYearEvents"/>';
			$strToReturn .= '<element name="MarksObtained" type="xsd:string"/>';
			$strToReturn .= '<element name="EventSubjectObject" type="xsd1:DeptYearEvents"/>';
			$strToReturn .= '<element name="ExamTypeObject" type="xsd1:Exam"/>';
			$strToReturn .= '<element name="YearlySubjectObject" type="xsd1:YearlySubject"/>';
			$strToReturn .= '<element name="LockExam" type="xsd:boolean"/>';
			$strToReturn .= '<element name="PrintDraft" type="xsd:boolean"/>';
			$strToReturn .= '<element name="Remark" type="xsd:string"/>';
			$strToReturn .= '<element name="CheckCode" type="xsd:string"/>';
			$strToReturn .= '<element name="GradeImprovement" type="xsd:boolean"/>';
			$strToReturn .= '<element name="GraceCode" type="xsd:string"/>';
			$strToReturn .= '<element name="ChInEse" type="xsd:string"/>';
			$strToReturn .= '<element name="AbsCode" type="xsd:string"/>';
			$strToReturn .= '<element name="RelCode" type="xsd:string"/>';
			$strToReturn .= '<element name="RefGradeImprovementObject" type="xsd1:ApplyGradeImproment"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('AppliedExam', $strComplexTypeArray)) {
				$strComplexTypeArray['AppliedExam'] = AppliedExam::GetSoapComplexTypeXml();
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				DeptYearEvents::AlterSoapComplexTypeArray($strComplexTypeArray);
				DeptYearEvents::AlterSoapComplexTypeArray($strComplexTypeArray);
				Exam::AlterSoapComplexTypeArray($strComplexTypeArray);
				YearlySubject::AlterSoapComplexTypeArray($strComplexTypeArray);
				ApplyGradeImproment::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, AppliedExam::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new AppliedExam();
			if (property_exists($objSoapObject, 'IdappliedExam'))
				$objToReturn->intIdappliedExam = $objSoapObject->IdappliedExam;
			if ((property_exists($objSoapObject, 'StudentObject')) &&
				($objSoapObject->StudentObject))
				$objToReturn->StudentObject = Login::GetObjectFromSoapObject($objSoapObject->StudentObject);
			if ((property_exists($objSoapObject, 'StudRoleObject')) &&
				($objSoapObject->StudRoleObject))
				$objToReturn->StudRoleObject = Role::GetObjectFromSoapObject($objSoapObject->StudRoleObject);
			if ((property_exists($objSoapObject, 'EventExamObject')) &&
				($objSoapObject->EventExamObject))
				$objToReturn->EventExamObject = DeptYearEvents::GetObjectFromSoapObject($objSoapObject->EventExamObject);
			if (property_exists($objSoapObject, 'MarksObtained'))
				$objToReturn->strMarksObtained = $objSoapObject->MarksObtained;
			if ((property_exists($objSoapObject, 'EventSubjectObject')) &&
				($objSoapObject->EventSubjectObject))
				$objToReturn->EventSubjectObject = DeptYearEvents::GetObjectFromSoapObject($objSoapObject->EventSubjectObject);
			if ((property_exists($objSoapObject, 'ExamTypeObject')) &&
				($objSoapObject->ExamTypeObject))
				$objToReturn->ExamTypeObject = Exam::GetObjectFromSoapObject($objSoapObject->ExamTypeObject);
			if ((property_exists($objSoapObject, 'YearlySubjectObject')) &&
				($objSoapObject->YearlySubjectObject))
				$objToReturn->YearlySubjectObject = YearlySubject::GetObjectFromSoapObject($objSoapObject->YearlySubjectObject);
			if (property_exists($objSoapObject, 'LockExam'))
				$objToReturn->blnLockExam = $objSoapObject->LockExam;
			if (property_exists($objSoapObject, 'PrintDraft'))
				$objToReturn->blnPrintDraft = $objSoapObject->PrintDraft;
			if (property_exists($objSoapObject, 'Remark'))
				$objToReturn->strRemark = $objSoapObject->Remark;
			if (property_exists($objSoapObject, 'CheckCode'))
				$objToReturn->strCheckCode = $objSoapObject->CheckCode;
			if (property_exists($objSoapObject, 'GradeImprovement'))
				$objToReturn->blnGradeImprovement = $objSoapObject->GradeImprovement;
			if (property_exists($objSoapObject, 'GraceCode'))
				$objToReturn->strGraceCode = $objSoapObject->GraceCode;
			if (property_exists($objSoapObject, 'ChInEse'))
				$objToReturn->strChInEse = $objSoapObject->ChInEse;
			if (property_exists($objSoapObject, 'AbsCode'))
				$objToReturn->strAbsCode = $objSoapObject->AbsCode;
			if (property_exists($objSoapObject, 'RelCode'))
				$objToReturn->strRelCode = $objSoapObject->RelCode;
			if ((property_exists($objSoapObject, 'RefGradeImprovementObject')) &&
				($objSoapObject->RefGradeImprovementObject))
				$objToReturn->RefGradeImprovementObject = ApplyGradeImproment::GetObjectFromSoapObject($objSoapObject->RefGradeImprovementObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, AppliedExam::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objStudentObject)
				$objObject->objStudentObject = Login::GetSoapObjectFromObject($objObject->objStudentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intStudent = null;
			if ($objObject->objStudRoleObject)
				$objObject->objStudRoleObject = Role::GetSoapObjectFromObject($objObject->objStudRoleObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intStudRole = null;
			if ($objObject->objEventExamObject)
				$objObject->objEventExamObject = DeptYearEvents::GetSoapObjectFromObject($objObject->objEventExamObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intEventExam = null;
			if ($objObject->objEventSubjectObject)
				$objObject->objEventSubjectObject = DeptYearEvents::GetSoapObjectFromObject($objObject->objEventSubjectObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intEventSubject = null;
			if ($objObject->objExamTypeObject)
				$objObject->objExamTypeObject = Exam::GetSoapObjectFromObject($objObject->objExamTypeObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intExamType = null;
			if ($objObject->objYearlySubjectObject)
				$objObject->objYearlySubjectObject = YearlySubject::GetSoapObjectFromObject($objObject->objYearlySubjectObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intYearlySubject = null;
			if ($objObject->objRefGradeImprovementObject)
				$objObject->objRefGradeImprovementObject = ApplyGradeImproment::GetSoapObjectFromObject($objObject->objRefGradeImprovementObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intRefGradeImprovement = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdappliedExam'] = $this->intIdappliedExam;
			$iArray['Student'] = $this->intStudent;
			$iArray['StudRole'] = $this->intStudRole;
			$iArray['EventExam'] = $this->intEventExam;
			$iArray['MarksObtained'] = $this->strMarksObtained;
			$iArray['EventSubject'] = $this->intEventSubject;
			$iArray['ExamType'] = $this->intExamType;
			$iArray['YearlySubject'] = $this->intYearlySubject;
			$iArray['LockExam'] = $this->blnLockExam;
			$iArray['PrintDraft'] = $this->blnPrintDraft;
			$iArray['Remark'] = $this->strRemark;
			$iArray['CheckCode'] = $this->strCheckCode;
			$iArray['GradeImprovement'] = $this->blnGradeImprovement;
			$iArray['GraceCode'] = $this->strGraceCode;
			$iArray['ChInEse'] = $this->strChInEse;
			$iArray['AbsCode'] = $this->strAbsCode;
			$iArray['RelCode'] = $this->strRelCode;
			$iArray['RefGradeImprovement'] = $this->intRefGradeImprovement;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdappliedExam ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdappliedExam
     * @property-read QQNode $Student
     * @property-read QQNodeLogin $StudentObject
     * @property-read QQNode $StudRole
     * @property-read QQNodeRole $StudRoleObject
     * @property-read QQNode $EventExam
     * @property-read QQNodeDeptYearEvents $EventExamObject
     * @property-read QQNode $MarksObtained
     * @property-read QQNode $EventSubject
     * @property-read QQNodeDeptYearEvents $EventSubjectObject
     * @property-read QQNode $ExamType
     * @property-read QQNodeExam $ExamTypeObject
     * @property-read QQNode $YearlySubject
     * @property-read QQNodeYearlySubject $YearlySubjectObject
     * @property-read QQNode $LockExam
     * @property-read QQNode $PrintDraft
     * @property-read QQNode $Remark
     * @property-read QQNode $CheckCode
     * @property-read QQNode $GradeImprovement
     * @property-read QQNode $GraceCode
     * @property-read QQNode $ChInEse
     * @property-read QQNode $AbsCode
     * @property-read QQNode $RelCode
     * @property-read QQNode $RefGradeImprovement
     * @property-read QQNodeApplyGradeImproment $RefGradeImprovementObject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeAppliedExam extends QQNode {
		protected $strTableName = 'applied_exam';
		protected $strPrimaryKey = 'idapplied_exam';
		protected $strClassName = 'AppliedExam';
		public function __get($strName) {
			switch ($strName) {
				case 'IdappliedExam':
					return new QQNode('idapplied_exam', 'IdappliedExam', 'Integer', $this);
				case 'Student':
					return new QQNode('student', 'Student', 'Integer', $this);
				case 'StudentObject':
					return new QQNodeLogin('student', 'StudentObject', 'Integer', $this);
				case 'StudRole':
					return new QQNode('stud_role', 'StudRole', 'Integer', $this);
				case 'StudRoleObject':
					return new QQNodeRole('stud_role', 'StudRoleObject', 'Integer', $this);
				case 'EventExam':
					return new QQNode('event_exam', 'EventExam', 'Integer', $this);
				case 'EventExamObject':
					return new QQNodeDeptYearEvents('event_exam', 'EventExamObject', 'Integer', $this);
				case 'MarksObtained':
					return new QQNode('marks_obtained', 'MarksObtained', 'VarChar', $this);
				case 'EventSubject':
					return new QQNode('event_subject', 'EventSubject', 'Integer', $this);
				case 'EventSubjectObject':
					return new QQNodeDeptYearEvents('event_subject', 'EventSubjectObject', 'Integer', $this);
				case 'ExamType':
					return new QQNode('exam_type', 'ExamType', 'Integer', $this);
				case 'ExamTypeObject':
					return new QQNodeExam('exam_type', 'ExamTypeObject', 'Integer', $this);
				case 'YearlySubject':
					return new QQNode('yearly_subject', 'YearlySubject', 'Integer', $this);
				case 'YearlySubjectObject':
					return new QQNodeYearlySubject('yearly_subject', 'YearlySubjectObject', 'Integer', $this);
				case 'LockExam':
					return new QQNode('lock_exam', 'LockExam', 'Bit', $this);
				case 'PrintDraft':
					return new QQNode('print_draft', 'PrintDraft', 'Bit', $this);
				case 'Remark':
					return new QQNode('remark', 'Remark', 'Blob', $this);
				case 'CheckCode':
					return new QQNode('check_code', 'CheckCode', 'VarChar', $this);
				case 'GradeImprovement':
					return new QQNode('grade_improvement', 'GradeImprovement', 'Bit', $this);
				case 'GraceCode':
					return new QQNode('grace_code', 'GraceCode', 'VarChar', $this);
				case 'ChInEse':
					return new QQNode('ch_in_ese', 'ChInEse', 'VarChar', $this);
				case 'AbsCode':
					return new QQNode('abs_code', 'AbsCode', 'VarChar', $this);
				case 'RelCode':
					return new QQNode('rel_code', 'RelCode', 'VarChar', $this);
				case 'RefGradeImprovement':
					return new QQNode('ref_grade_improvement', 'RefGradeImprovement', 'Integer', $this);
				case 'RefGradeImprovementObject':
					return new QQNodeApplyGradeImproment('ref_grade_improvement', 'RefGradeImprovementObject', 'Integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idapplied_exam', 'IdappliedExam', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdappliedExam
     * @property-read QQNode $Student
     * @property-read QQNodeLogin $StudentObject
     * @property-read QQNode $StudRole
     * @property-read QQNodeRole $StudRoleObject
     * @property-read QQNode $EventExam
     * @property-read QQNodeDeptYearEvents $EventExamObject
     * @property-read QQNode $MarksObtained
     * @property-read QQNode $EventSubject
     * @property-read QQNodeDeptYearEvents $EventSubjectObject
     * @property-read QQNode $ExamType
     * @property-read QQNodeExam $ExamTypeObject
     * @property-read QQNode $YearlySubject
     * @property-read QQNodeYearlySubject $YearlySubjectObject
     * @property-read QQNode $LockExam
     * @property-read QQNode $PrintDraft
     * @property-read QQNode $Remark
     * @property-read QQNode $CheckCode
     * @property-read QQNode $GradeImprovement
     * @property-read QQNode $GraceCode
     * @property-read QQNode $ChInEse
     * @property-read QQNode $AbsCode
     * @property-read QQNode $RelCode
     * @property-read QQNode $RefGradeImprovement
     * @property-read QQNodeApplyGradeImproment $RefGradeImprovementObject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeAppliedExam extends QQReverseReferenceNode {
		protected $strTableName = 'applied_exam';
		protected $strPrimaryKey = 'idapplied_exam';
		protected $strClassName = 'AppliedExam';
		public function __get($strName) {
			switch ($strName) {
				case 'IdappliedExam':
					return new QQNode('idapplied_exam', 'IdappliedExam', 'integer', $this);
				case 'Student':
					return new QQNode('student', 'Student', 'integer', $this);
				case 'StudentObject':
					return new QQNodeLogin('student', 'StudentObject', 'integer', $this);
				case 'StudRole':
					return new QQNode('stud_role', 'StudRole', 'integer', $this);
				case 'StudRoleObject':
					return new QQNodeRole('stud_role', 'StudRoleObject', 'integer', $this);
				case 'EventExam':
					return new QQNode('event_exam', 'EventExam', 'integer', $this);
				case 'EventExamObject':
					return new QQNodeDeptYearEvents('event_exam', 'EventExamObject', 'integer', $this);
				case 'MarksObtained':
					return new QQNode('marks_obtained', 'MarksObtained', 'string', $this);
				case 'EventSubject':
					return new QQNode('event_subject', 'EventSubject', 'integer', $this);
				case 'EventSubjectObject':
					return new QQNodeDeptYearEvents('event_subject', 'EventSubjectObject', 'integer', $this);
				case 'ExamType':
					return new QQNode('exam_type', 'ExamType', 'integer', $this);
				case 'ExamTypeObject':
					return new QQNodeExam('exam_type', 'ExamTypeObject', 'integer', $this);
				case 'YearlySubject':
					return new QQNode('yearly_subject', 'YearlySubject', 'integer', $this);
				case 'YearlySubjectObject':
					return new QQNodeYearlySubject('yearly_subject', 'YearlySubjectObject', 'integer', $this);
				case 'LockExam':
					return new QQNode('lock_exam', 'LockExam', 'boolean', $this);
				case 'PrintDraft':
					return new QQNode('print_draft', 'PrintDraft', 'boolean', $this);
				case 'Remark':
					return new QQNode('remark', 'Remark', 'string', $this);
				case 'CheckCode':
					return new QQNode('check_code', 'CheckCode', 'string', $this);
				case 'GradeImprovement':
					return new QQNode('grade_improvement', 'GradeImprovement', 'boolean', $this);
				case 'GraceCode':
					return new QQNode('grace_code', 'GraceCode', 'string', $this);
				case 'ChInEse':
					return new QQNode('ch_in_ese', 'ChInEse', 'string', $this);
				case 'AbsCode':
					return new QQNode('abs_code', 'AbsCode', 'string', $this);
				case 'RelCode':
					return new QQNode('rel_code', 'RelCode', 'string', $this);
				case 'RefGradeImprovement':
					return new QQNode('ref_grade_improvement', 'RefGradeImprovement', 'integer', $this);
				case 'RefGradeImprovementObject':
					return new QQNodeApplyGradeImproment('ref_grade_improvement', 'RefGradeImprovementObject', 'integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idapplied_exam', 'IdappliedExam', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
