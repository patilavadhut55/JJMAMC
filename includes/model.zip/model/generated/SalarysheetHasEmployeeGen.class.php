<?php
	/**
	 * The abstract SalarysheetHasEmployeeGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the SalarysheetHasEmployee subclass which
	 * extends this SalarysheetHasEmployeeGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the SalarysheetHasEmployee class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdsalarysheetHasEmployee the value for intIdsalarysheetHasEmployee (Read-Only PK)
	 * @property integer $Salarysheet the value for intSalarysheet (Not Null)
	 * @property integer $Employee the value for intEmployee (Not Null)
	 * @property string $WorkingDays the value for strWorkingDays 
	 * @property string $PresentDays the value for strPresentDays 
	 * @property string $TotaDeduction the value for strTotaDeduction 
	 * @property string $TotalEarning the value for strTotalEarning 
	 * @property string $NetPay the value for strNetPay 
	 * @property string $Paid the value for strPaid 
	 * @property Salarysheet $SalarysheetObject the value for the Salarysheet object referenced by intSalarysheet (Not Null)
	 * @property Address $EmployeeObject the value for the Address object referenced by intEmployee (Not Null)
	 * @property-read GeneratedSalary $_GeneratedSalaryAsReference the value for the private _objGeneratedSalaryAsReference (Read-Only) if set due to an expansion on the generated_salary.reference reverse relationship
	 * @property-read GeneratedSalary[] $_GeneratedSalaryAsReferenceArray the value for the private _objGeneratedSalaryAsReferenceArray (Read-Only) if set due to an ExpandAsArray on the generated_salary.reference reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class SalarysheetHasEmployeeGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column salarysheet_has_employee.idsalarysheet_has_employee
		 * @var integer intIdsalarysheetHasEmployee
		 */
		protected $intIdsalarysheetHasEmployee;
		const IdsalarysheetHasEmployeeDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_has_employee.salarysheet
		 * @var integer intSalarysheet
		 */
		protected $intSalarysheet;
		const SalarysheetDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_has_employee.employee
		 * @var integer intEmployee
		 */
		protected $intEmployee;
		const EmployeeDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_has_employee.working_days
		 * @var string strWorkingDays
		 */
		protected $strWorkingDays;
		const WorkingDaysDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_has_employee.present_days
		 * @var string strPresentDays
		 */
		protected $strPresentDays;
		const PresentDaysDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_has_employee.tota_deduction
		 * @var string strTotaDeduction
		 */
		protected $strTotaDeduction;
		const TotaDeductionDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_has_employee.total_earning
		 * @var string strTotalEarning
		 */
		protected $strTotalEarning;
		const TotalEarningDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_has_employee.net_pay
		 * @var string strNetPay
		 */
		protected $strNetPay;
		const NetPayDefault = null;


		/**
		 * Protected member variable that maps to the database column salarysheet_has_employee.paid
		 * @var string strPaid
		 */
		protected $strPaid;
		const PaidDefault = null;


		/**
		 * Private member variable that stores a reference to a single GeneratedSalaryAsReference object
		 * (of type GeneratedSalary), if this SalarysheetHasEmployee object was restored with
		 * an expansion on the generated_salary association table.
		 * @var GeneratedSalary _objGeneratedSalaryAsReference;
		 */
		private $_objGeneratedSalaryAsReference;

		/**
		 * Private member variable that stores a reference to an array of GeneratedSalaryAsReference objects
		 * (of type GeneratedSalary[]), if this SalarysheetHasEmployee object was restored with
		 * an ExpandAsArray on the generated_salary association table.
		 * @var GeneratedSalary[] _objGeneratedSalaryAsReferenceArray;
		 */
		private $_objGeneratedSalaryAsReferenceArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salarysheet_has_employee.salarysheet.
		 *
		 * NOTE: Always use the SalarysheetObject property getter to correctly retrieve this Salarysheet object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Salarysheet objSalarysheetObject
		 */
		protected $objSalarysheetObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salarysheet_has_employee.employee.
		 *
		 * NOTE: Always use the EmployeeObject property getter to correctly retrieve this Address object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Address objEmployeeObject
		 */
		protected $objEmployeeObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdsalarysheetHasEmployee = SalarysheetHasEmployee::IdsalarysheetHasEmployeeDefault;
			$this->intSalarysheet = SalarysheetHasEmployee::SalarysheetDefault;
			$this->intEmployee = SalarysheetHasEmployee::EmployeeDefault;
			$this->strWorkingDays = SalarysheetHasEmployee::WorkingDaysDefault;
			$this->strPresentDays = SalarysheetHasEmployee::PresentDaysDefault;
			$this->strTotaDeduction = SalarysheetHasEmployee::TotaDeductionDefault;
			$this->strTotalEarning = SalarysheetHasEmployee::TotalEarningDefault;
			$this->strNetPay = SalarysheetHasEmployee::NetPayDefault;
			$this->strPaid = SalarysheetHasEmployee::PaidDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a SalarysheetHasEmployee from PK Info
		 * @param integer $intIdsalarysheetHasEmployee
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalarysheetHasEmployee
		 */
		public static function Load($intIdsalarysheetHasEmployee, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'SalarysheetHasEmployee', $intIdsalarysheetHasEmployee);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = SalarysheetHasEmployee::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::SalarysheetHasEmployee()->IdsalarysheetHasEmployee, $intIdsalarysheetHasEmployee)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all SalarysheetHasEmployees
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalarysheetHasEmployee[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call SalarysheetHasEmployee::QueryArray to perform the LoadAll query
			try {
				return SalarysheetHasEmployee::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all SalarysheetHasEmployees
		 * @return int
		 */
		public static function CountAll() {
			// Call SalarysheetHasEmployee::QueryCount to perform the CountAll query
			return SalarysheetHasEmployee::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = SalarysheetHasEmployee::GetDatabase();

			// Create/Build out the QueryBuilder object with SalarysheetHasEmployee-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'salarysheet_has_employee');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				SalarysheetHasEmployee::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('salarysheet_has_employee');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single SalarysheetHasEmployee object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return SalarysheetHasEmployee the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = SalarysheetHasEmployee::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new SalarysheetHasEmployee object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = SalarysheetHasEmployee::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return SalarysheetHasEmployee::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of SalarysheetHasEmployee objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return SalarysheetHasEmployee[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = SalarysheetHasEmployee::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return SalarysheetHasEmployee::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = SalarysheetHasEmployee::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of SalarysheetHasEmployee objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = SalarysheetHasEmployee::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = SalarysheetHasEmployee::GetDatabase();

			$strQuery = SalarysheetHasEmployee::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/salarysheethasemployee', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = SalarysheetHasEmployee::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this SalarysheetHasEmployee
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'salarysheet_has_employee';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idsalarysheet_has_employee', $strAliasPrefix . 'idsalarysheet_has_employee');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idsalarysheet_has_employee', $strAliasPrefix . 'idsalarysheet_has_employee');
			    $objBuilder->AddSelectItem($strTableName, 'salarysheet', $strAliasPrefix . 'salarysheet');
			    $objBuilder->AddSelectItem($strTableName, 'employee', $strAliasPrefix . 'employee');
			    $objBuilder->AddSelectItem($strTableName, 'working_days', $strAliasPrefix . 'working_days');
			    $objBuilder->AddSelectItem($strTableName, 'present_days', $strAliasPrefix . 'present_days');
			    $objBuilder->AddSelectItem($strTableName, 'tota_deduction', $strAliasPrefix . 'tota_deduction');
			    $objBuilder->AddSelectItem($strTableName, 'total_earning', $strAliasPrefix . 'total_earning');
			    $objBuilder->AddSelectItem($strTableName, 'net_pay', $strAliasPrefix . 'net_pay');
			    $objBuilder->AddSelectItem($strTableName, 'paid', $strAliasPrefix . 'paid');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a SalarysheetHasEmployee from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this SalarysheetHasEmployee::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return SalarysheetHasEmployee
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idsalarysheet_has_employee';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdsalarysheetHasEmployee == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'salarysheet_has_employee__';


						// Expanding reverse references: GeneratedSalaryAsReference
						$strAlias = $strAliasPrefix . 'generatedsalaryasreference__idgenerated_salary';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objGeneratedSalaryAsReferenceArray)
								$objPreviousItem->_objGeneratedSalaryAsReferenceArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objGeneratedSalaryAsReferenceArray)) {
								$objPreviousChildItems = $objPreviousItem->_objGeneratedSalaryAsReferenceArray;
								$objChildItem = GeneratedSalary::InstantiateDbRow($objDbRow, $strAliasPrefix . 'generatedsalaryasreference__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objGeneratedSalaryAsReferenceArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objGeneratedSalaryAsReferenceArray[] = GeneratedSalary::InstantiateDbRow($objDbRow, $strAliasPrefix . 'generatedsalaryasreference__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'salarysheet_has_employee__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the SalarysheetHasEmployee object
			$objToReturn = new SalarysheetHasEmployee();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idsalarysheet_has_employee';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdsalarysheetHasEmployee = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'salarysheet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSalarysheet = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'employee';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intEmployee = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'working_days';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strWorkingDays = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'present_days';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strPresentDays = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'tota_deduction';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTotaDeduction = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'total_earning';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTotalEarning = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'net_pay';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strNetPay = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'paid';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strPaid = $objDbRow->GetColumn($strAliasName, 'VarChar');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdsalarysheetHasEmployee != $objPreviousItem->IdsalarysheetHasEmployee) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objGeneratedSalaryAsReferenceArray);
					$cnt = count($objToReturn->_objGeneratedSalaryAsReferenceArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objGeneratedSalaryAsReferenceArray, $objToReturn->_objGeneratedSalaryAsReferenceArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'salarysheet_has_employee__';

			// Check for SalarysheetObject Early Binding
			$strAlias = $strAliasPrefix . 'salarysheet__idsalarysheet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSalarysheetObject = Salarysheet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salarysheet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for EmployeeObject Early Binding
			$strAlias = $strAliasPrefix . 'employee__idaddress';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objEmployeeObject = Address::InstantiateDbRow($objDbRow, $strAliasPrefix . 'employee__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for GeneratedSalaryAsReference Virtual Binding
			$strAlias = $strAliasPrefix . 'generatedsalaryasreference__idgenerated_salary';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objGeneratedSalaryAsReferenceArray)
				$objToReturn->_objGeneratedSalaryAsReferenceArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objGeneratedSalaryAsReferenceArray[] = GeneratedSalary::InstantiateDbRow($objDbRow, $strAliasPrefix . 'generatedsalaryasreference__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objGeneratedSalaryAsReference = GeneratedSalary::InstantiateDbRow($objDbRow, $strAliasPrefix . 'generatedsalaryasreference__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of SalarysheetHasEmployees from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return SalarysheetHasEmployee[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = SalarysheetHasEmployee::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = SalarysheetHasEmployee::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single SalarysheetHasEmployee object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return SalarysheetHasEmployee next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return SalarysheetHasEmployee::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single SalarysheetHasEmployee object,
		 * by IdsalarysheetHasEmployee Index(es)
		 * @param integer $intIdsalarysheetHasEmployee
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalarysheetHasEmployee
		*/
		public static function LoadByIdsalarysheetHasEmployee($intIdsalarysheetHasEmployee, $objOptionalClauses = null) {
			return SalarysheetHasEmployee::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::SalarysheetHasEmployee()->IdsalarysheetHasEmployee, $intIdsalarysheetHasEmployee)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of SalarysheetHasEmployee objects,
		 * by Salarysheet Index(es)
		 * @param integer $intSalarysheet
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalarysheetHasEmployee[]
		*/
		public static function LoadArrayBySalarysheet($intSalarysheet, $objOptionalClauses = null) {
			// Call SalarysheetHasEmployee::QueryArray to perform the LoadArrayBySalarysheet query
			try {
				return SalarysheetHasEmployee::QueryArray(
					QQ::Equal(QQN::SalarysheetHasEmployee()->Salarysheet, $intSalarysheet),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count SalarysheetHasEmployees
		 * by Salarysheet Index(es)
		 * @param integer $intSalarysheet
		 * @return int
		*/
		public static function CountBySalarysheet($intSalarysheet) {
			// Call SalarysheetHasEmployee::QueryCount to perform the CountBySalarysheet query
			return SalarysheetHasEmployee::QueryCount(
				QQ::Equal(QQN::SalarysheetHasEmployee()->Salarysheet, $intSalarysheet)
			);
		}

		/**
		 * Load an array of SalarysheetHasEmployee objects,
		 * by Employee Index(es)
		 * @param integer $intEmployee
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalarysheetHasEmployee[]
		*/
		public static function LoadArrayByEmployee($intEmployee, $objOptionalClauses = null) {
			// Call SalarysheetHasEmployee::QueryArray to perform the LoadArrayByEmployee query
			try {
				return SalarysheetHasEmployee::QueryArray(
					QQ::Equal(QQN::SalarysheetHasEmployee()->Employee, $intEmployee),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count SalarysheetHasEmployees
		 * by Employee Index(es)
		 * @param integer $intEmployee
		 * @return int
		*/
		public static function CountByEmployee($intEmployee) {
			// Call SalarysheetHasEmployee::QueryCount to perform the CountByEmployee query
			return SalarysheetHasEmployee::QueryCount(
				QQ::Equal(QQN::SalarysheetHasEmployee()->Employee, $intEmployee)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this SalarysheetHasEmployee
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = SalarysheetHasEmployee::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `salarysheet_has_employee` (
							`salarysheet`,
							`employee`,
							`working_days`,
							`present_days`,
							`tota_deduction`,
							`total_earning`,
							`net_pay`,
							`paid`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intSalarysheet) . ',
							' . $objDatabase->SqlVariable($this->intEmployee) . ',
							' . $objDatabase->SqlVariable($this->strWorkingDays) . ',
							' . $objDatabase->SqlVariable($this->strPresentDays) . ',
							' . $objDatabase->SqlVariable($this->strTotaDeduction) . ',
							' . $objDatabase->SqlVariable($this->strTotalEarning) . ',
							' . $objDatabase->SqlVariable($this->strNetPay) . ',
							' . $objDatabase->SqlVariable($this->strPaid) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdsalarysheetHasEmployee = $objDatabase->InsertId('salarysheet_has_employee', 'idsalarysheet_has_employee');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`salarysheet_has_employee`
						SET
							`salarysheet` = ' . $objDatabase->SqlVariable($this->intSalarysheet) . ',
							`employee` = ' . $objDatabase->SqlVariable($this->intEmployee) . ',
							`working_days` = ' . $objDatabase->SqlVariable($this->strWorkingDays) . ',
							`present_days` = ' . $objDatabase->SqlVariable($this->strPresentDays) . ',
							`tota_deduction` = ' . $objDatabase->SqlVariable($this->strTotaDeduction) . ',
							`total_earning` = ' . $objDatabase->SqlVariable($this->strTotalEarning) . ',
							`net_pay` = ' . $objDatabase->SqlVariable($this->strNetPay) . ',
							`paid` = ' . $objDatabase->SqlVariable($this->strPaid) . '
						WHERE
							`idsalarysheet_has_employee` = ' . $objDatabase->SqlVariable($this->intIdsalarysheetHasEmployee) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this SalarysheetHasEmployee
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdsalarysheetHasEmployee)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this SalarysheetHasEmployee with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = SalarysheetHasEmployee::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salarysheet_has_employee`
				WHERE
					`idsalarysheet_has_employee` = ' . $objDatabase->SqlVariable($this->intIdsalarysheetHasEmployee) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this SalarysheetHasEmployee ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'SalarysheetHasEmployee', $this->intIdsalarysheetHasEmployee);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all SalarysheetHasEmployees
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = SalarysheetHasEmployee::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salarysheet_has_employee`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate salarysheet_has_employee table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = SalarysheetHasEmployee::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `salarysheet_has_employee`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this SalarysheetHasEmployee from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved SalarysheetHasEmployee object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = SalarysheetHasEmployee::Load($this->intIdsalarysheetHasEmployee);

			// Update $this's local variables to match
			$this->Salarysheet = $objReloaded->Salarysheet;
			$this->Employee = $objReloaded->Employee;
			$this->strWorkingDays = $objReloaded->strWorkingDays;
			$this->strPresentDays = $objReloaded->strPresentDays;
			$this->strTotaDeduction = $objReloaded->strTotaDeduction;
			$this->strTotalEarning = $objReloaded->strTotalEarning;
			$this->strNetPay = $objReloaded->strNetPay;
			$this->strPaid = $objReloaded->strPaid;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdsalarysheetHasEmployee':
					/**
					 * Gets the value for intIdsalarysheetHasEmployee (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdsalarysheetHasEmployee;

				case 'Salarysheet':
					/**
					 * Gets the value for intSalarysheet (Not Null)
					 * @return integer
					 */
					return $this->intSalarysheet;

				case 'Employee':
					/**
					 * Gets the value for intEmployee (Not Null)
					 * @return integer
					 */
					return $this->intEmployee;

				case 'WorkingDays':
					/**
					 * Gets the value for strWorkingDays 
					 * @return string
					 */
					return $this->strWorkingDays;

				case 'PresentDays':
					/**
					 * Gets the value for strPresentDays 
					 * @return string
					 */
					return $this->strPresentDays;

				case 'TotaDeduction':
					/**
					 * Gets the value for strTotaDeduction 
					 * @return string
					 */
					return $this->strTotaDeduction;

				case 'TotalEarning':
					/**
					 * Gets the value for strTotalEarning 
					 * @return string
					 */
					return $this->strTotalEarning;

				case 'NetPay':
					/**
					 * Gets the value for strNetPay 
					 * @return string
					 */
					return $this->strNetPay;

				case 'Paid':
					/**
					 * Gets the value for strPaid 
					 * @return string
					 */
					return $this->strPaid;


				///////////////////
				// Member Objects
				///////////////////
				case 'SalarysheetObject':
					/**
					 * Gets the value for the Salarysheet object referenced by intSalarysheet (Not Null)
					 * @return Salarysheet
					 */
					try {
						if ((!$this->objSalarysheetObject) && (!is_null($this->intSalarysheet)))
							$this->objSalarysheetObject = Salarysheet::Load($this->intSalarysheet);
						return $this->objSalarysheetObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'EmployeeObject':
					/**
					 * Gets the value for the Address object referenced by intEmployee (Not Null)
					 * @return Address
					 */
					try {
						if ((!$this->objEmployeeObject) && (!is_null($this->intEmployee)))
							$this->objEmployeeObject = Address::Load($this->intEmployee);
						return $this->objEmployeeObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_GeneratedSalaryAsReference':
					/**
					 * Gets the value for the private _objGeneratedSalaryAsReference (Read-Only)
					 * if set due to an expansion on the generated_salary.reference reverse relationship
					 * @return GeneratedSalary
					 */
					return $this->_objGeneratedSalaryAsReference;

				case '_GeneratedSalaryAsReferenceArray':
					/**
					 * Gets the value for the private _objGeneratedSalaryAsReferenceArray (Read-Only)
					 * if set due to an ExpandAsArray on the generated_salary.reference reverse relationship
					 * @return GeneratedSalary[]
					 */
					return $this->_objGeneratedSalaryAsReferenceArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Salarysheet':
					/**
					 * Sets the value for intSalarysheet (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSalarysheetObject = null;
						return ($this->intSalarysheet = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Employee':
					/**
					 * Sets the value for intEmployee (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objEmployeeObject = null;
						return ($this->intEmployee = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'WorkingDays':
					/**
					 * Sets the value for strWorkingDays 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strWorkingDays = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'PresentDays':
					/**
					 * Sets the value for strPresentDays 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strPresentDays = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TotaDeduction':
					/**
					 * Sets the value for strTotaDeduction 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTotaDeduction = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TotalEarning':
					/**
					 * Sets the value for strTotalEarning 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTotalEarning = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'NetPay':
					/**
					 * Sets the value for strNetPay 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strNetPay = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Paid':
					/**
					 * Sets the value for strPaid 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strPaid = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'SalarysheetObject':
					/**
					 * Sets the value for the Salarysheet object referenced by intSalarysheet (Not Null)
					 * @param Salarysheet $mixValue
					 * @return Salarysheet
					 */
					if (is_null($mixValue)) {
						$this->intSalarysheet = null;
						$this->objSalarysheetObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Salarysheet object
						try {
							$mixValue = QType::Cast($mixValue, 'Salarysheet');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Salarysheet object
						if (is_null($mixValue->Idsalarysheet))
							throw new QCallerException('Unable to set an unsaved SalarysheetObject for this SalarysheetHasEmployee');

						// Update Local Member Variables
						$this->objSalarysheetObject = $mixValue;
						$this->intSalarysheet = $mixValue->Idsalarysheet;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'EmployeeObject':
					/**
					 * Sets the value for the Address object referenced by intEmployee (Not Null)
					 * @param Address $mixValue
					 * @return Address
					 */
					if (is_null($mixValue)) {
						$this->intEmployee = null;
						$this->objEmployeeObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Address object
						try {
							$mixValue = QType::Cast($mixValue, 'Address');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Address object
						if (is_null($mixValue->Idaddress))
							throw new QCallerException('Unable to set an unsaved EmployeeObject for this SalarysheetHasEmployee');

						// Update Local Member Variables
						$this->objEmployeeObject = $mixValue;
						$this->intEmployee = $mixValue->Idaddress;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for GeneratedSalaryAsReference
		//-------------------------------------------------------------------

		/**
		 * Gets all associated GeneratedSalariesAsReference as an array of GeneratedSalary objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GeneratedSalary[]
		*/
		public function GetGeneratedSalaryAsReferenceArray($objOptionalClauses = null) {
			if ((is_null($this->intIdsalarysheetHasEmployee)))
				return array();

			try {
				return GeneratedSalary::LoadArrayByReference($this->intIdsalarysheetHasEmployee, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated GeneratedSalariesAsReference
		 * @return int
		*/
		public function CountGeneratedSalariesAsReference() {
			if ((is_null($this->intIdsalarysheetHasEmployee)))
				return 0;

			return GeneratedSalary::CountByReference($this->intIdsalarysheetHasEmployee);
		}

		/**
		 * Associates a GeneratedSalaryAsReference
		 * @param GeneratedSalary $objGeneratedSalary
		 * @return void
		*/
		public function AssociateGeneratedSalaryAsReference(GeneratedSalary $objGeneratedSalary) {
			if ((is_null($this->intIdsalarysheetHasEmployee)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGeneratedSalaryAsReference on this unsaved SalarysheetHasEmployee.');
			if ((is_null($objGeneratedSalary->IdgeneratedSalary)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGeneratedSalaryAsReference on this SalarysheetHasEmployee with an unsaved GeneratedSalary.');

			// Get the Database Object for this Class
			$objDatabase = SalarysheetHasEmployee::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`generated_salary`
				SET
					`reference` = ' . $objDatabase->SqlVariable($this->intIdsalarysheetHasEmployee) . '
				WHERE
					`idgenerated_salary` = ' . $objDatabase->SqlVariable($objGeneratedSalary->IdgeneratedSalary) . '
			');
		}

		/**
		 * Unassociates a GeneratedSalaryAsReference
		 * @param GeneratedSalary $objGeneratedSalary
		 * @return void
		*/
		public function UnassociateGeneratedSalaryAsReference(GeneratedSalary $objGeneratedSalary) {
			if ((is_null($this->intIdsalarysheetHasEmployee)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGeneratedSalaryAsReference on this unsaved SalarysheetHasEmployee.');
			if ((is_null($objGeneratedSalary->IdgeneratedSalary)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGeneratedSalaryAsReference on this SalarysheetHasEmployee with an unsaved GeneratedSalary.');

			// Get the Database Object for this Class
			$objDatabase = SalarysheetHasEmployee::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`generated_salary`
				SET
					`reference` = null
				WHERE
					`idgenerated_salary` = ' . $objDatabase->SqlVariable($objGeneratedSalary->IdgeneratedSalary) . ' AND
					`reference` = ' . $objDatabase->SqlVariable($this->intIdsalarysheetHasEmployee) . '
			');
		}

		/**
		 * Unassociates all GeneratedSalariesAsReference
		 * @return void
		*/
		public function UnassociateAllGeneratedSalariesAsReference() {
			if ((is_null($this->intIdsalarysheetHasEmployee)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGeneratedSalaryAsReference on this unsaved SalarysheetHasEmployee.');

			// Get the Database Object for this Class
			$objDatabase = SalarysheetHasEmployee::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`generated_salary`
				SET
					`reference` = null
				WHERE
					`reference` = ' . $objDatabase->SqlVariable($this->intIdsalarysheetHasEmployee) . '
			');
		}

		/**
		 * Deletes an associated GeneratedSalaryAsReference
		 * @param GeneratedSalary $objGeneratedSalary
		 * @return void
		*/
		public function DeleteAssociatedGeneratedSalaryAsReference(GeneratedSalary $objGeneratedSalary) {
			if ((is_null($this->intIdsalarysheetHasEmployee)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGeneratedSalaryAsReference on this unsaved SalarysheetHasEmployee.');
			if ((is_null($objGeneratedSalary->IdgeneratedSalary)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGeneratedSalaryAsReference on this SalarysheetHasEmployee with an unsaved GeneratedSalary.');

			// Get the Database Object for this Class
			$objDatabase = SalarysheetHasEmployee::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`generated_salary`
				WHERE
					`idgenerated_salary` = ' . $objDatabase->SqlVariable($objGeneratedSalary->IdgeneratedSalary) . ' AND
					`reference` = ' . $objDatabase->SqlVariable($this->intIdsalarysheetHasEmployee) . '
			');
		}

		/**
		 * Deletes all associated GeneratedSalariesAsReference
		 * @return void
		*/
		public function DeleteAllGeneratedSalariesAsReference() {
			if ((is_null($this->intIdsalarysheetHasEmployee)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGeneratedSalaryAsReference on this unsaved SalarysheetHasEmployee.');

			// Get the Database Object for this Class
			$objDatabase = SalarysheetHasEmployee::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`generated_salary`
				WHERE
					`reference` = ' . $objDatabase->SqlVariable($this->intIdsalarysheetHasEmployee) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "salarysheet_has_employee";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[SalarysheetHasEmployee::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="SalarysheetHasEmployee"><sequence>';
			$strToReturn .= '<element name="IdsalarysheetHasEmployee" type="xsd:int"/>';
			$strToReturn .= '<element name="SalarysheetObject" type="xsd1:Salarysheet"/>';
			$strToReturn .= '<element name="EmployeeObject" type="xsd1:Address"/>';
			$strToReturn .= '<element name="WorkingDays" type="xsd:string"/>';
			$strToReturn .= '<element name="PresentDays" type="xsd:string"/>';
			$strToReturn .= '<element name="TotaDeduction" type="xsd:string"/>';
			$strToReturn .= '<element name="TotalEarning" type="xsd:string"/>';
			$strToReturn .= '<element name="NetPay" type="xsd:string"/>';
			$strToReturn .= '<element name="Paid" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('SalarysheetHasEmployee', $strComplexTypeArray)) {
				$strComplexTypeArray['SalarysheetHasEmployee'] = SalarysheetHasEmployee::GetSoapComplexTypeXml();
				Salarysheet::AlterSoapComplexTypeArray($strComplexTypeArray);
				Address::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, SalarysheetHasEmployee::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new SalarysheetHasEmployee();
			if (property_exists($objSoapObject, 'IdsalarysheetHasEmployee'))
				$objToReturn->intIdsalarysheetHasEmployee = $objSoapObject->IdsalarysheetHasEmployee;
			if ((property_exists($objSoapObject, 'SalarysheetObject')) &&
				($objSoapObject->SalarysheetObject))
				$objToReturn->SalarysheetObject = Salarysheet::GetObjectFromSoapObject($objSoapObject->SalarysheetObject);
			if ((property_exists($objSoapObject, 'EmployeeObject')) &&
				($objSoapObject->EmployeeObject))
				$objToReturn->EmployeeObject = Address::GetObjectFromSoapObject($objSoapObject->EmployeeObject);
			if (property_exists($objSoapObject, 'WorkingDays'))
				$objToReturn->strWorkingDays = $objSoapObject->WorkingDays;
			if (property_exists($objSoapObject, 'PresentDays'))
				$objToReturn->strPresentDays = $objSoapObject->PresentDays;
			if (property_exists($objSoapObject, 'TotaDeduction'))
				$objToReturn->strTotaDeduction = $objSoapObject->TotaDeduction;
			if (property_exists($objSoapObject, 'TotalEarning'))
				$objToReturn->strTotalEarning = $objSoapObject->TotalEarning;
			if (property_exists($objSoapObject, 'NetPay'))
				$objToReturn->strNetPay = $objSoapObject->NetPay;
			if (property_exists($objSoapObject, 'Paid'))
				$objToReturn->strPaid = $objSoapObject->Paid;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, SalarysheetHasEmployee::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objSalarysheetObject)
				$objObject->objSalarysheetObject = Salarysheet::GetSoapObjectFromObject($objObject->objSalarysheetObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSalarysheet = null;
			if ($objObject->objEmployeeObject)
				$objObject->objEmployeeObject = Address::GetSoapObjectFromObject($objObject->objEmployeeObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intEmployee = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdsalarysheetHasEmployee'] = $this->intIdsalarysheetHasEmployee;
			$iArray['Salarysheet'] = $this->intSalarysheet;
			$iArray['Employee'] = $this->intEmployee;
			$iArray['WorkingDays'] = $this->strWorkingDays;
			$iArray['PresentDays'] = $this->strPresentDays;
			$iArray['TotaDeduction'] = $this->strTotaDeduction;
			$iArray['TotalEarning'] = $this->strTotalEarning;
			$iArray['NetPay'] = $this->strNetPay;
			$iArray['Paid'] = $this->strPaid;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdsalarysheetHasEmployee ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdsalarysheetHasEmployee
     * @property-read QQNode $Salarysheet
     * @property-read QQNodeSalarysheet $SalarysheetObject
     * @property-read QQNode $Employee
     * @property-read QQNodeAddress $EmployeeObject
     * @property-read QQNode $WorkingDays
     * @property-read QQNode $PresentDays
     * @property-read QQNode $TotaDeduction
     * @property-read QQNode $TotalEarning
     * @property-read QQNode $NetPay
     * @property-read QQNode $Paid
     *
     *
     * @property-read QQReverseReferenceNodeGeneratedSalary $GeneratedSalaryAsReference

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeSalarysheetHasEmployee extends QQNode {
		protected $strTableName = 'salarysheet_has_employee';
		protected $strPrimaryKey = 'idsalarysheet_has_employee';
		protected $strClassName = 'SalarysheetHasEmployee';
		public function __get($strName) {
			switch ($strName) {
				case 'IdsalarysheetHasEmployee':
					return new QQNode('idsalarysheet_has_employee', 'IdsalarysheetHasEmployee', 'Integer', $this);
				case 'Salarysheet':
					return new QQNode('salarysheet', 'Salarysheet', 'Integer', $this);
				case 'SalarysheetObject':
					return new QQNodeSalarysheet('salarysheet', 'SalarysheetObject', 'Integer', $this);
				case 'Employee':
					return new QQNode('employee', 'Employee', 'Integer', $this);
				case 'EmployeeObject':
					return new QQNodeAddress('employee', 'EmployeeObject', 'Integer', $this);
				case 'WorkingDays':
					return new QQNode('working_days', 'WorkingDays', 'VarChar', $this);
				case 'PresentDays':
					return new QQNode('present_days', 'PresentDays', 'VarChar', $this);
				case 'TotaDeduction':
					return new QQNode('tota_deduction', 'TotaDeduction', 'VarChar', $this);
				case 'TotalEarning':
					return new QQNode('total_earning', 'TotalEarning', 'VarChar', $this);
				case 'NetPay':
					return new QQNode('net_pay', 'NetPay', 'VarChar', $this);
				case 'Paid':
					return new QQNode('paid', 'Paid', 'VarChar', $this);
				case 'GeneratedSalaryAsReference':
					return new QQReverseReferenceNodeGeneratedSalary($this, 'generatedsalaryasreference', 'reverse_reference', 'reference');

				case '_PrimaryKeyNode':
					return new QQNode('idsalarysheet_has_employee', 'IdsalarysheetHasEmployee', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdsalarysheetHasEmployee
     * @property-read QQNode $Salarysheet
     * @property-read QQNodeSalarysheet $SalarysheetObject
     * @property-read QQNode $Employee
     * @property-read QQNodeAddress $EmployeeObject
     * @property-read QQNode $WorkingDays
     * @property-read QQNode $PresentDays
     * @property-read QQNode $TotaDeduction
     * @property-read QQNode $TotalEarning
     * @property-read QQNode $NetPay
     * @property-read QQNode $Paid
     *
     *
     * @property-read QQReverseReferenceNodeGeneratedSalary $GeneratedSalaryAsReference

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeSalarysheetHasEmployee extends QQReverseReferenceNode {
		protected $strTableName = 'salarysheet_has_employee';
		protected $strPrimaryKey = 'idsalarysheet_has_employee';
		protected $strClassName = 'SalarysheetHasEmployee';
		public function __get($strName) {
			switch ($strName) {
				case 'IdsalarysheetHasEmployee':
					return new QQNode('idsalarysheet_has_employee', 'IdsalarysheetHasEmployee', 'integer', $this);
				case 'Salarysheet':
					return new QQNode('salarysheet', 'Salarysheet', 'integer', $this);
				case 'SalarysheetObject':
					return new QQNodeSalarysheet('salarysheet', 'SalarysheetObject', 'integer', $this);
				case 'Employee':
					return new QQNode('employee', 'Employee', 'integer', $this);
				case 'EmployeeObject':
					return new QQNodeAddress('employee', 'EmployeeObject', 'integer', $this);
				case 'WorkingDays':
					return new QQNode('working_days', 'WorkingDays', 'string', $this);
				case 'PresentDays':
					return new QQNode('present_days', 'PresentDays', 'string', $this);
				case 'TotaDeduction':
					return new QQNode('tota_deduction', 'TotaDeduction', 'string', $this);
				case 'TotalEarning':
					return new QQNode('total_earning', 'TotalEarning', 'string', $this);
				case 'NetPay':
					return new QQNode('net_pay', 'NetPay', 'string', $this);
				case 'Paid':
					return new QQNode('paid', 'Paid', 'string', $this);
				case 'GeneratedSalaryAsReference':
					return new QQReverseReferenceNodeGeneratedSalary($this, 'generatedsalaryasreference', 'reverse_reference', 'reference');

				case '_PrimaryKeyNode':
					return new QQNode('idsalarysheet_has_employee', 'IdsalarysheetHasEmployee', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
