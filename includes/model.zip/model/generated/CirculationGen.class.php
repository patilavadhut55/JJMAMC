<?php
	/**
	 * The abstract CirculationGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Circulation subclass which
	 * extends this CirculationGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Circulation class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idcirculation the value for intIdcirculation (Read-Only PK)
	 * @property integer $Accession the value for intAccession (Not Null)
	 * @property integer $StaffStud the value for intStaffStud (Not Null)
	 * @property QDateTime $IssueDate the value for dttIssueDate (Not Null)
	 * @property integer $DataBy the value for intDataBy 
	 * @property string $Fine the value for strFine 
	 * @property boolean $Returened the value for blnReturened 
	 * @property QDateTime $ReturnededOn the value for dttReturnededOn 
	 * @property QDateTime $ReturnDate the value for dttReturnDate 
	 * @property Serials $AccessionObject the value for the Serials object referenced by intAccession (Not Null)
	 * @property Login $StaffStudObject the value for the Login object referenced by intStaffStud (Not Null)
	 * @property Login $DataByObject the value for the Login object referenced by intDataBy 
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class CirculationGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column circulation.idcirculation
		 * @var integer intIdcirculation
		 */
		protected $intIdcirculation;
		const IdcirculationDefault = null;


		/**
		 * Protected member variable that maps to the database column circulation.accession
		 * @var integer intAccession
		 */
		protected $intAccession;
		const AccessionDefault = null;


		/**
		 * Protected member variable that maps to the database column circulation.staff_stud
		 * @var integer intStaffStud
		 */
		protected $intStaffStud;
		const StaffStudDefault = null;


		/**
		 * Protected member variable that maps to the database column circulation.issue_date
		 * @var QDateTime dttIssueDate
		 */
		protected $dttIssueDate;
		const IssueDateDefault = null;


		/**
		 * Protected member variable that maps to the database column circulation.data_by
		 * @var integer intDataBy
		 */
		protected $intDataBy;
		const DataByDefault = null;


		/**
		 * Protected member variable that maps to the database column circulation.fine
		 * @var string strFine
		 */
		protected $strFine;
		const FineDefault = null;


		/**
		 * Protected member variable that maps to the database column circulation.returened
		 * @var boolean blnReturened
		 */
		protected $blnReturened;
		const ReturenedDefault = null;


		/**
		 * Protected member variable that maps to the database column circulation.returneded_on
		 * @var QDateTime dttReturnededOn
		 */
		protected $dttReturnededOn;
		const ReturnededOnDefault = null;


		/**
		 * Protected member variable that maps to the database column circulation.return_date
		 * @var QDateTime dttReturnDate
		 */
		protected $dttReturnDate;
		const ReturnDateDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column circulation.accession.
		 *
		 * NOTE: Always use the AccessionObject property getter to correctly retrieve this Serials object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Serials objAccessionObject
		 */
		protected $objAccessionObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column circulation.staff_stud.
		 *
		 * NOTE: Always use the StaffStudObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objStaffStudObject
		 */
		protected $objStaffStudObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column circulation.data_by.
		 *
		 * NOTE: Always use the DataByObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objDataByObject
		 */
		protected $objDataByObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdcirculation = Circulation::IdcirculationDefault;
			$this->intAccession = Circulation::AccessionDefault;
			$this->intStaffStud = Circulation::StaffStudDefault;
			$this->dttIssueDate = (Circulation::IssueDateDefault === null)?null:new QDateTime(Circulation::IssueDateDefault);
			$this->intDataBy = Circulation::DataByDefault;
			$this->strFine = Circulation::FineDefault;
			$this->blnReturened = Circulation::ReturenedDefault;
			$this->dttReturnededOn = (Circulation::ReturnededOnDefault === null)?null:new QDateTime(Circulation::ReturnededOnDefault);
			$this->dttReturnDate = (Circulation::ReturnDateDefault === null)?null:new QDateTime(Circulation::ReturnDateDefault);
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Circulation from PK Info
		 * @param integer $intIdcirculation
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Circulation
		 */
		public static function Load($intIdcirculation, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Circulation', $intIdcirculation);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Circulation::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Circulation()->Idcirculation, $intIdcirculation)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Circulations
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Circulation[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Circulation::QueryArray to perform the LoadAll query
			try {
				return Circulation::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Circulations
		 * @return int
		 */
		public static function CountAll() {
			// Call Circulation::QueryCount to perform the CountAll query
			return Circulation::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Circulation::GetDatabase();

			// Create/Build out the QueryBuilder object with Circulation-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'circulation');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Circulation::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('circulation');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Circulation object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Circulation the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Circulation::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Circulation object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Circulation::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Circulation::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Circulation objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Circulation[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Circulation::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Circulation::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Circulation::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Circulation objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Circulation::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Circulation::GetDatabase();

			$strQuery = Circulation::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/circulation', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Circulation::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Circulation
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'circulation';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idcirculation', $strAliasPrefix . 'idcirculation');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idcirculation', $strAliasPrefix . 'idcirculation');
			    $objBuilder->AddSelectItem($strTableName, 'accession', $strAliasPrefix . 'accession');
			    $objBuilder->AddSelectItem($strTableName, 'staff_stud', $strAliasPrefix . 'staff_stud');
			    $objBuilder->AddSelectItem($strTableName, 'issue_date', $strAliasPrefix . 'issue_date');
			    $objBuilder->AddSelectItem($strTableName, 'data_by', $strAliasPrefix . 'data_by');
			    $objBuilder->AddSelectItem($strTableName, 'fine', $strAliasPrefix . 'fine');
			    $objBuilder->AddSelectItem($strTableName, 'returened', $strAliasPrefix . 'returened');
			    $objBuilder->AddSelectItem($strTableName, 'returneded_on', $strAliasPrefix . 'returneded_on');
			    $objBuilder->AddSelectItem($strTableName, 'return_date', $strAliasPrefix . 'return_date');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Circulation from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Circulation::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Circulation
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the Circulation object
			$objToReturn = new Circulation();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idcirculation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdcirculation = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'accession';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intAccession = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'staff_stud';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intStaffStud = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'issue_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttIssueDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'data_by';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDataBy = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'fine';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strFine = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'returened';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnReturened = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'returneded_on';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttReturnededOn = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'return_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttReturnDate = $objDbRow->GetColumn($strAliasName, 'DateTime');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idcirculation != $objPreviousItem->Idcirculation) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'circulation__';

			// Check for AccessionObject Early Binding
			$strAlias = $strAliasPrefix . 'accession__idserials';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objAccessionObject = Serials::InstantiateDbRow($objDbRow, $strAliasPrefix . 'accession__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for StaffStudObject Early Binding
			$strAlias = $strAliasPrefix . 'staff_stud__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objStaffStudObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'staff_stud__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DataByObject Early Binding
			$strAlias = $strAliasPrefix . 'data_by__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDataByObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'data_by__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of Circulations from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Circulation[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Circulation::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Circulation::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Circulation object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Circulation next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Circulation::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Circulation object,
		 * by Idcirculation Index(es)
		 * @param integer $intIdcirculation
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Circulation
		*/
		public static function LoadByIdcirculation($intIdcirculation, $objOptionalClauses = null) {
			return Circulation::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Circulation()->Idcirculation, $intIdcirculation)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Circulation objects,
		 * by DataBy Index(es)
		 * @param integer $intDataBy
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Circulation[]
		*/
		public static function LoadArrayByDataBy($intDataBy, $objOptionalClauses = null) {
			// Call Circulation::QueryArray to perform the LoadArrayByDataBy query
			try {
				return Circulation::QueryArray(
					QQ::Equal(QQN::Circulation()->DataBy, $intDataBy),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Circulations
		 * by DataBy Index(es)
		 * @param integer $intDataBy
		 * @return int
		*/
		public static function CountByDataBy($intDataBy) {
			// Call Circulation::QueryCount to perform the CountByDataBy query
			return Circulation::QueryCount(
				QQ::Equal(QQN::Circulation()->DataBy, $intDataBy)
			);
		}

		/**
		 * Load an array of Circulation objects,
		 * by StaffStud Index(es)
		 * @param integer $intStaffStud
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Circulation[]
		*/
		public static function LoadArrayByStaffStud($intStaffStud, $objOptionalClauses = null) {
			// Call Circulation::QueryArray to perform the LoadArrayByStaffStud query
			try {
				return Circulation::QueryArray(
					QQ::Equal(QQN::Circulation()->StaffStud, $intStaffStud),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Circulations
		 * by StaffStud Index(es)
		 * @param integer $intStaffStud
		 * @return int
		*/
		public static function CountByStaffStud($intStaffStud) {
			// Call Circulation::QueryCount to perform the CountByStaffStud query
			return Circulation::QueryCount(
				QQ::Equal(QQN::Circulation()->StaffStud, $intStaffStud)
			);
		}

		/**
		 * Load an array of Circulation objects,
		 * by Accession Index(es)
		 * @param integer $intAccession
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Circulation[]
		*/
		public static function LoadArrayByAccession($intAccession, $objOptionalClauses = null) {
			// Call Circulation::QueryArray to perform the LoadArrayByAccession query
			try {
				return Circulation::QueryArray(
					QQ::Equal(QQN::Circulation()->Accession, $intAccession),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Circulations
		 * by Accession Index(es)
		 * @param integer $intAccession
		 * @return int
		*/
		public static function CountByAccession($intAccession) {
			// Call Circulation::QueryCount to perform the CountByAccession query
			return Circulation::QueryCount(
				QQ::Equal(QQN::Circulation()->Accession, $intAccession)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Circulation
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Circulation::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `circulation` (
							`accession`,
							`staff_stud`,
							`issue_date`,
							`data_by`,
							`fine`,
							`returened`,
							`returneded_on`,
							`return_date`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intAccession) . ',
							' . $objDatabase->SqlVariable($this->intStaffStud) . ',
							' . $objDatabase->SqlVariable($this->dttIssueDate) . ',
							' . $objDatabase->SqlVariable($this->intDataBy) . ',
							' . $objDatabase->SqlVariable($this->strFine) . ',
							' . $objDatabase->SqlVariable($this->blnReturened) . ',
							' . $objDatabase->SqlVariable($this->dttReturnededOn) . ',
							' . $objDatabase->SqlVariable($this->dttReturnDate) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdcirculation = $objDatabase->InsertId('circulation', 'idcirculation');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`circulation`
						SET
							`accession` = ' . $objDatabase->SqlVariable($this->intAccession) . ',
							`staff_stud` = ' . $objDatabase->SqlVariable($this->intStaffStud) . ',
							`issue_date` = ' . $objDatabase->SqlVariable($this->dttIssueDate) . ',
							`data_by` = ' . $objDatabase->SqlVariable($this->intDataBy) . ',
							`fine` = ' . $objDatabase->SqlVariable($this->strFine) . ',
							`returened` = ' . $objDatabase->SqlVariable($this->blnReturened) . ',
							`returneded_on` = ' . $objDatabase->SqlVariable($this->dttReturnededOn) . ',
							`return_date` = ' . $objDatabase->SqlVariable($this->dttReturnDate) . '
						WHERE
							`idcirculation` = ' . $objDatabase->SqlVariable($this->intIdcirculation) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Circulation
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdcirculation)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Circulation with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Circulation::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`circulation`
				WHERE
					`idcirculation` = ' . $objDatabase->SqlVariable($this->intIdcirculation) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Circulation ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Circulation', $this->intIdcirculation);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Circulations
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Circulation::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`circulation`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate circulation table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Circulation::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `circulation`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Circulation from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Circulation object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Circulation::Load($this->intIdcirculation);

			// Update $this's local variables to match
			$this->Accession = $objReloaded->Accession;
			$this->StaffStud = $objReloaded->StaffStud;
			$this->dttIssueDate = $objReloaded->dttIssueDate;
			$this->DataBy = $objReloaded->DataBy;
			$this->strFine = $objReloaded->strFine;
			$this->blnReturened = $objReloaded->blnReturened;
			$this->dttReturnededOn = $objReloaded->dttReturnededOn;
			$this->dttReturnDate = $objReloaded->dttReturnDate;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idcirculation':
					/**
					 * Gets the value for intIdcirculation (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdcirculation;

				case 'Accession':
					/**
					 * Gets the value for intAccession (Not Null)
					 * @return integer
					 */
					return $this->intAccession;

				case 'StaffStud':
					/**
					 * Gets the value for intStaffStud (Not Null)
					 * @return integer
					 */
					return $this->intStaffStud;

				case 'IssueDate':
					/**
					 * Gets the value for dttIssueDate (Not Null)
					 * @return QDateTime
					 */
					return $this->dttIssueDate;

				case 'DataBy':
					/**
					 * Gets the value for intDataBy 
					 * @return integer
					 */
					return $this->intDataBy;

				case 'Fine':
					/**
					 * Gets the value for strFine 
					 * @return string
					 */
					return $this->strFine;

				case 'Returened':
					/**
					 * Gets the value for blnReturened 
					 * @return boolean
					 */
					return $this->blnReturened;

				case 'ReturnededOn':
					/**
					 * Gets the value for dttReturnededOn 
					 * @return QDateTime
					 */
					return $this->dttReturnededOn;

				case 'ReturnDate':
					/**
					 * Gets the value for dttReturnDate 
					 * @return QDateTime
					 */
					return $this->dttReturnDate;


				///////////////////
				// Member Objects
				///////////////////
				case 'AccessionObject':
					/**
					 * Gets the value for the Serials object referenced by intAccession (Not Null)
					 * @return Serials
					 */
					try {
						if ((!$this->objAccessionObject) && (!is_null($this->intAccession)))
							$this->objAccessionObject = Serials::Load($this->intAccession);
						return $this->objAccessionObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'StaffStudObject':
					/**
					 * Gets the value for the Login object referenced by intStaffStud (Not Null)
					 * @return Login
					 */
					try {
						if ((!$this->objStaffStudObject) && (!is_null($this->intStaffStud)))
							$this->objStaffStudObject = Login::Load($this->intStaffStud);
						return $this->objStaffStudObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DataByObject':
					/**
					 * Gets the value for the Login object referenced by intDataBy 
					 * @return Login
					 */
					try {
						if ((!$this->objDataByObject) && (!is_null($this->intDataBy)))
							$this->objDataByObject = Login::Load($this->intDataBy);
						return $this->objDataByObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Accession':
					/**
					 * Sets the value for intAccession (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objAccessionObject = null;
						return ($this->intAccession = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'StaffStud':
					/**
					 * Sets the value for intStaffStud (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objStaffStudObject = null;
						return ($this->intStaffStud = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'IssueDate':
					/**
					 * Sets the value for dttIssueDate (Not Null)
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttIssueDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DataBy':
					/**
					 * Sets the value for intDataBy 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDataByObject = null;
						return ($this->intDataBy = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Fine':
					/**
					 * Sets the value for strFine 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strFine = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Returened':
					/**
					 * Sets the value for blnReturened 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnReturened = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ReturnededOn':
					/**
					 * Sets the value for dttReturnededOn 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttReturnededOn = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ReturnDate':
					/**
					 * Sets the value for dttReturnDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttReturnDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'AccessionObject':
					/**
					 * Sets the value for the Serials object referenced by intAccession (Not Null)
					 * @param Serials $mixValue
					 * @return Serials
					 */
					if (is_null($mixValue)) {
						$this->intAccession = null;
						$this->objAccessionObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Serials object
						try {
							$mixValue = QType::Cast($mixValue, 'Serials');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Serials object
						if (is_null($mixValue->Idserials))
							throw new QCallerException('Unable to set an unsaved AccessionObject for this Circulation');

						// Update Local Member Variables
						$this->objAccessionObject = $mixValue;
						$this->intAccession = $mixValue->Idserials;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'StaffStudObject':
					/**
					 * Sets the value for the Login object referenced by intStaffStud (Not Null)
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intStaffStud = null;
						$this->objStaffStudObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved StaffStudObject for this Circulation');

						// Update Local Member Variables
						$this->objStaffStudObject = $mixValue;
						$this->intStaffStud = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DataByObject':
					/**
					 * Sets the value for the Login object referenced by intDataBy 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intDataBy = null;
						$this->objDataByObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved DataByObject for this Circulation');

						// Update Local Member Variables
						$this->objDataByObject = $mixValue;
						$this->intDataBy = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "circulation";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Circulation::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Circulation"><sequence>';
			$strToReturn .= '<element name="Idcirculation" type="xsd:int"/>';
			$strToReturn .= '<element name="AccessionObject" type="xsd1:Serials"/>';
			$strToReturn .= '<element name="StaffStudObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="IssueDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="DataByObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="Fine" type="xsd:string"/>';
			$strToReturn .= '<element name="Returened" type="xsd:boolean"/>';
			$strToReturn .= '<element name="ReturnededOn" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="ReturnDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Circulation', $strComplexTypeArray)) {
				$strComplexTypeArray['Circulation'] = Circulation::GetSoapComplexTypeXml();
				Serials::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Circulation::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Circulation();
			if (property_exists($objSoapObject, 'Idcirculation'))
				$objToReturn->intIdcirculation = $objSoapObject->Idcirculation;
			if ((property_exists($objSoapObject, 'AccessionObject')) &&
				($objSoapObject->AccessionObject))
				$objToReturn->AccessionObject = Serials::GetObjectFromSoapObject($objSoapObject->AccessionObject);
			if ((property_exists($objSoapObject, 'StaffStudObject')) &&
				($objSoapObject->StaffStudObject))
				$objToReturn->StaffStudObject = Login::GetObjectFromSoapObject($objSoapObject->StaffStudObject);
			if (property_exists($objSoapObject, 'IssueDate'))
				$objToReturn->dttIssueDate = new QDateTime($objSoapObject->IssueDate);
			if ((property_exists($objSoapObject, 'DataByObject')) &&
				($objSoapObject->DataByObject))
				$objToReturn->DataByObject = Login::GetObjectFromSoapObject($objSoapObject->DataByObject);
			if (property_exists($objSoapObject, 'Fine'))
				$objToReturn->strFine = $objSoapObject->Fine;
			if (property_exists($objSoapObject, 'Returened'))
				$objToReturn->blnReturened = $objSoapObject->Returened;
			if (property_exists($objSoapObject, 'ReturnededOn'))
				$objToReturn->dttReturnededOn = new QDateTime($objSoapObject->ReturnededOn);
			if (property_exists($objSoapObject, 'ReturnDate'))
				$objToReturn->dttReturnDate = new QDateTime($objSoapObject->ReturnDate);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Circulation::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objAccessionObject)
				$objObject->objAccessionObject = Serials::GetSoapObjectFromObject($objObject->objAccessionObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intAccession = null;
			if ($objObject->objStaffStudObject)
				$objObject->objStaffStudObject = Login::GetSoapObjectFromObject($objObject->objStaffStudObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intStaffStud = null;
			if ($objObject->dttIssueDate)
				$objObject->dttIssueDate = $objObject->dttIssueDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objDataByObject)
				$objObject->objDataByObject = Login::GetSoapObjectFromObject($objObject->objDataByObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDataBy = null;
			if ($objObject->dttReturnededOn)
				$objObject->dttReturnededOn = $objObject->dttReturnededOn->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttReturnDate)
				$objObject->dttReturnDate = $objObject->dttReturnDate->qFormat(QDateTime::FormatSoap);
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idcirculation'] = $this->intIdcirculation;
			$iArray['Accession'] = $this->intAccession;
			$iArray['StaffStud'] = $this->intStaffStud;
			$iArray['IssueDate'] = $this->dttIssueDate;
			$iArray['DataBy'] = $this->intDataBy;
			$iArray['Fine'] = $this->strFine;
			$iArray['Returened'] = $this->blnReturened;
			$iArray['ReturnededOn'] = $this->dttReturnededOn;
			$iArray['ReturnDate'] = $this->dttReturnDate;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdcirculation ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idcirculation
     * @property-read QQNode $Accession
     * @property-read QQNodeSerials $AccessionObject
     * @property-read QQNode $StaffStud
     * @property-read QQNodeLogin $StaffStudObject
     * @property-read QQNode $IssueDate
     * @property-read QQNode $DataBy
     * @property-read QQNodeLogin $DataByObject
     * @property-read QQNode $Fine
     * @property-read QQNode $Returened
     * @property-read QQNode $ReturnededOn
     * @property-read QQNode $ReturnDate
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeCirculation extends QQNode {
		protected $strTableName = 'circulation';
		protected $strPrimaryKey = 'idcirculation';
		protected $strClassName = 'Circulation';
		public function __get($strName) {
			switch ($strName) {
				case 'Idcirculation':
					return new QQNode('idcirculation', 'Idcirculation', 'Integer', $this);
				case 'Accession':
					return new QQNode('accession', 'Accession', 'Integer', $this);
				case 'AccessionObject':
					return new QQNodeSerials('accession', 'AccessionObject', 'Integer', $this);
				case 'StaffStud':
					return new QQNode('staff_stud', 'StaffStud', 'Integer', $this);
				case 'StaffStudObject':
					return new QQNodeLogin('staff_stud', 'StaffStudObject', 'Integer', $this);
				case 'IssueDate':
					return new QQNode('issue_date', 'IssueDate', 'DateTime', $this);
				case 'DataBy':
					return new QQNode('data_by', 'DataBy', 'Integer', $this);
				case 'DataByObject':
					return new QQNodeLogin('data_by', 'DataByObject', 'Integer', $this);
				case 'Fine':
					return new QQNode('fine', 'Fine', 'VarChar', $this);
				case 'Returened':
					return new QQNode('returened', 'Returened', 'Bit', $this);
				case 'ReturnededOn':
					return new QQNode('returneded_on', 'ReturnededOn', 'DateTime', $this);
				case 'ReturnDate':
					return new QQNode('return_date', 'ReturnDate', 'DateTime', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idcirculation', 'Idcirculation', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idcirculation
     * @property-read QQNode $Accession
     * @property-read QQNodeSerials $AccessionObject
     * @property-read QQNode $StaffStud
     * @property-read QQNodeLogin $StaffStudObject
     * @property-read QQNode $IssueDate
     * @property-read QQNode $DataBy
     * @property-read QQNodeLogin $DataByObject
     * @property-read QQNode $Fine
     * @property-read QQNode $Returened
     * @property-read QQNode $ReturnededOn
     * @property-read QQNode $ReturnDate
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeCirculation extends QQReverseReferenceNode {
		protected $strTableName = 'circulation';
		protected $strPrimaryKey = 'idcirculation';
		protected $strClassName = 'Circulation';
		public function __get($strName) {
			switch ($strName) {
				case 'Idcirculation':
					return new QQNode('idcirculation', 'Idcirculation', 'integer', $this);
				case 'Accession':
					return new QQNode('accession', 'Accession', 'integer', $this);
				case 'AccessionObject':
					return new QQNodeSerials('accession', 'AccessionObject', 'integer', $this);
				case 'StaffStud':
					return new QQNode('staff_stud', 'StaffStud', 'integer', $this);
				case 'StaffStudObject':
					return new QQNodeLogin('staff_stud', 'StaffStudObject', 'integer', $this);
				case 'IssueDate':
					return new QQNode('issue_date', 'IssueDate', 'QDateTime', $this);
				case 'DataBy':
					return new QQNode('data_by', 'DataBy', 'integer', $this);
				case 'DataByObject':
					return new QQNodeLogin('data_by', 'DataByObject', 'integer', $this);
				case 'Fine':
					return new QQNode('fine', 'Fine', 'string', $this);
				case 'Returened':
					return new QQNode('returened', 'Returened', 'boolean', $this);
				case 'ReturnededOn':
					return new QQNode('returneded_on', 'ReturnededOn', 'QDateTime', $this);
				case 'ReturnDate':
					return new QQNode('return_date', 'ReturnDate', 'QDateTime', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idcirculation', 'Idcirculation', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
