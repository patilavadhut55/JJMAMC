<?php
	/**
	 * The abstract BankLoanGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the BankLoan subclass which
	 * extends this BankLoanGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the BankLoan class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdbankLoan the value for intIdbankLoan (Read-Only PK)
	 * @property integer $Employee the value for intEmployee (Not Null)
	 * @property integer $Bank the value for intBank (Not Null)
	 * @property string $Amount the value for strAmount (Not Null)
	 * @property QDateTime $FromDate the value for dttFromDate 
	 * @property QDateTime $ToDate the value for dttToDate 
	 * @property boolean $Show the value for blnShow 
	 * @property Ledger $EmployeeObject the value for the Ledger object referenced by intEmployee (Not Null)
	 * @property Ledger $BankObject the value for the Ledger object referenced by intBank (Not Null)
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class BankLoanGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column bank_loan.idbank_loan
		 * @var integer intIdbankLoan
		 */
		protected $intIdbankLoan;
		const IdbankLoanDefault = null;


		/**
		 * Protected member variable that maps to the database column bank_loan.employee
		 * @var integer intEmployee
		 */
		protected $intEmployee;
		const EmployeeDefault = null;


		/**
		 * Protected member variable that maps to the database column bank_loan.bank
		 * @var integer intBank
		 */
		protected $intBank;
		const BankDefault = null;


		/**
		 * Protected member variable that maps to the database column bank_loan.amount
		 * @var string strAmount
		 */
		protected $strAmount;
		const AmountDefault = null;


		/**
		 * Protected member variable that maps to the database column bank_loan.from_date
		 * @var QDateTime dttFromDate
		 */
		protected $dttFromDate;
		const FromDateDefault = null;


		/**
		 * Protected member variable that maps to the database column bank_loan.to_date
		 * @var QDateTime dttToDate
		 */
		protected $dttToDate;
		const ToDateDefault = null;


		/**
		 * Protected member variable that maps to the database column bank_loan.show
		 * @var boolean blnShow
		 */
		protected $blnShow;
		const ShowDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column bank_loan.employee.
		 *
		 * NOTE: Always use the EmployeeObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objEmployeeObject
		 */
		protected $objEmployeeObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column bank_loan.bank.
		 *
		 * NOTE: Always use the BankObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objBankObject
		 */
		protected $objBankObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdbankLoan = BankLoan::IdbankLoanDefault;
			$this->intEmployee = BankLoan::EmployeeDefault;
			$this->intBank = BankLoan::BankDefault;
			$this->strAmount = BankLoan::AmountDefault;
			$this->dttFromDate = (BankLoan::FromDateDefault === null)?null:new QDateTime(BankLoan::FromDateDefault);
			$this->dttToDate = (BankLoan::ToDateDefault === null)?null:new QDateTime(BankLoan::ToDateDefault);
			$this->blnShow = BankLoan::ShowDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a BankLoan from PK Info
		 * @param integer $intIdbankLoan
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return BankLoan
		 */
		public static function Load($intIdbankLoan, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'BankLoan', $intIdbankLoan);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = BankLoan::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::BankLoan()->IdbankLoan, $intIdbankLoan)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all BankLoans
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return BankLoan[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call BankLoan::QueryArray to perform the LoadAll query
			try {
				return BankLoan::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all BankLoans
		 * @return int
		 */
		public static function CountAll() {
			// Call BankLoan::QueryCount to perform the CountAll query
			return BankLoan::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = BankLoan::GetDatabase();

			// Create/Build out the QueryBuilder object with BankLoan-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'bank_loan');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				BankLoan::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('bank_loan');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single BankLoan object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return BankLoan the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = BankLoan::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new BankLoan object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = BankLoan::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return BankLoan::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of BankLoan objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return BankLoan[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = BankLoan::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return BankLoan::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = BankLoan::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of BankLoan objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = BankLoan::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = BankLoan::GetDatabase();

			$strQuery = BankLoan::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/bankloan', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = BankLoan::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this BankLoan
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'bank_loan';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idbank_loan', $strAliasPrefix . 'idbank_loan');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idbank_loan', $strAliasPrefix . 'idbank_loan');
			    $objBuilder->AddSelectItem($strTableName, 'employee', $strAliasPrefix . 'employee');
			    $objBuilder->AddSelectItem($strTableName, 'bank', $strAliasPrefix . 'bank');
			    $objBuilder->AddSelectItem($strTableName, 'amount', $strAliasPrefix . 'amount');
			    $objBuilder->AddSelectItem($strTableName, 'from_date', $strAliasPrefix . 'from_date');
			    $objBuilder->AddSelectItem($strTableName, 'to_date', $strAliasPrefix . 'to_date');
			    $objBuilder->AddSelectItem($strTableName, 'show', $strAliasPrefix . 'show');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a BankLoan from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this BankLoan::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return BankLoan
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the BankLoan object
			$objToReturn = new BankLoan();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idbank_loan';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdbankLoan = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'employee';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intEmployee = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'bank';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intBank = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'amount';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strAmount = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'from_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttFromDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'to_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttToDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'show';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnShow = $objDbRow->GetColumn($strAliasName, 'Bit');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdbankLoan != $objPreviousItem->IdbankLoan) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'bank_loan__';

			// Check for EmployeeObject Early Binding
			$strAlias = $strAliasPrefix . 'employee__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objEmployeeObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'employee__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for BankObject Early Binding
			$strAlias = $strAliasPrefix . 'bank__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objBankObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'bank__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of BankLoans from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return BankLoan[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = BankLoan::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = BankLoan::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single BankLoan object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return BankLoan next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return BankLoan::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single BankLoan object,
		 * by IdbankLoan Index(es)
		 * @param integer $intIdbankLoan
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return BankLoan
		*/
		public static function LoadByIdbankLoan($intIdbankLoan, $objOptionalClauses = null) {
			return BankLoan::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::BankLoan()->IdbankLoan, $intIdbankLoan)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of BankLoan objects,
		 * by Employee Index(es)
		 * @param integer $intEmployee
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return BankLoan[]
		*/
		public static function LoadArrayByEmployee($intEmployee, $objOptionalClauses = null) {
			// Call BankLoan::QueryArray to perform the LoadArrayByEmployee query
			try {
				return BankLoan::QueryArray(
					QQ::Equal(QQN::BankLoan()->Employee, $intEmployee),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count BankLoans
		 * by Employee Index(es)
		 * @param integer $intEmployee
		 * @return int
		*/
		public static function CountByEmployee($intEmployee) {
			// Call BankLoan::QueryCount to perform the CountByEmployee query
			return BankLoan::QueryCount(
				QQ::Equal(QQN::BankLoan()->Employee, $intEmployee)
			);
		}

		/**
		 * Load an array of BankLoan objects,
		 * by Bank Index(es)
		 * @param integer $intBank
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return BankLoan[]
		*/
		public static function LoadArrayByBank($intBank, $objOptionalClauses = null) {
			// Call BankLoan::QueryArray to perform the LoadArrayByBank query
			try {
				return BankLoan::QueryArray(
					QQ::Equal(QQN::BankLoan()->Bank, $intBank),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count BankLoans
		 * by Bank Index(es)
		 * @param integer $intBank
		 * @return int
		*/
		public static function CountByBank($intBank) {
			// Call BankLoan::QueryCount to perform the CountByBank query
			return BankLoan::QueryCount(
				QQ::Equal(QQN::BankLoan()->Bank, $intBank)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this BankLoan
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = BankLoan::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `bank_loan` (
							`employee`,
							`bank`,
							`amount`,
							`from_date`,
							`to_date`,
							`show`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intEmployee) . ',
							' . $objDatabase->SqlVariable($this->intBank) . ',
							' . $objDatabase->SqlVariable($this->strAmount) . ',
							' . $objDatabase->SqlVariable($this->dttFromDate) . ',
							' . $objDatabase->SqlVariable($this->dttToDate) . ',
							' . $objDatabase->SqlVariable($this->blnShow) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdbankLoan = $objDatabase->InsertId('bank_loan', 'idbank_loan');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`bank_loan`
						SET
							`employee` = ' . $objDatabase->SqlVariable($this->intEmployee) . ',
							`bank` = ' . $objDatabase->SqlVariable($this->intBank) . ',
							`amount` = ' . $objDatabase->SqlVariable($this->strAmount) . ',
							`from_date` = ' . $objDatabase->SqlVariable($this->dttFromDate) . ',
							`to_date` = ' . $objDatabase->SqlVariable($this->dttToDate) . ',
							`show` = ' . $objDatabase->SqlVariable($this->blnShow) . '
						WHERE
							`idbank_loan` = ' . $objDatabase->SqlVariable($this->intIdbankLoan) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this BankLoan
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdbankLoan)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this BankLoan with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = BankLoan::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`bank_loan`
				WHERE
					`idbank_loan` = ' . $objDatabase->SqlVariable($this->intIdbankLoan) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this BankLoan ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'BankLoan', $this->intIdbankLoan);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all BankLoans
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = BankLoan::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`bank_loan`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate bank_loan table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = BankLoan::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `bank_loan`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this BankLoan from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved BankLoan object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = BankLoan::Load($this->intIdbankLoan);

			// Update $this's local variables to match
			$this->Employee = $objReloaded->Employee;
			$this->Bank = $objReloaded->Bank;
			$this->strAmount = $objReloaded->strAmount;
			$this->dttFromDate = $objReloaded->dttFromDate;
			$this->dttToDate = $objReloaded->dttToDate;
			$this->blnShow = $objReloaded->blnShow;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdbankLoan':
					/**
					 * Gets the value for intIdbankLoan (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdbankLoan;

				case 'Employee':
					/**
					 * Gets the value for intEmployee (Not Null)
					 * @return integer
					 */
					return $this->intEmployee;

				case 'Bank':
					/**
					 * Gets the value for intBank (Not Null)
					 * @return integer
					 */
					return $this->intBank;

				case 'Amount':
					/**
					 * Gets the value for strAmount (Not Null)
					 * @return string
					 */
					return $this->strAmount;

				case 'FromDate':
					/**
					 * Gets the value for dttFromDate 
					 * @return QDateTime
					 */
					return $this->dttFromDate;

				case 'ToDate':
					/**
					 * Gets the value for dttToDate 
					 * @return QDateTime
					 */
					return $this->dttToDate;

				case 'Show':
					/**
					 * Gets the value for blnShow 
					 * @return boolean
					 */
					return $this->blnShow;


				///////////////////
				// Member Objects
				///////////////////
				case 'EmployeeObject':
					/**
					 * Gets the value for the Ledger object referenced by intEmployee (Not Null)
					 * @return Ledger
					 */
					try {
						if ((!$this->objEmployeeObject) && (!is_null($this->intEmployee)))
							$this->objEmployeeObject = Ledger::Load($this->intEmployee);
						return $this->objEmployeeObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'BankObject':
					/**
					 * Gets the value for the Ledger object referenced by intBank (Not Null)
					 * @return Ledger
					 */
					try {
						if ((!$this->objBankObject) && (!is_null($this->intBank)))
							$this->objBankObject = Ledger::Load($this->intBank);
						return $this->objBankObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Employee':
					/**
					 * Sets the value for intEmployee (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objEmployeeObject = null;
						return ($this->intEmployee = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Bank':
					/**
					 * Sets the value for intBank (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objBankObject = null;
						return ($this->intBank = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Amount':
					/**
					 * Sets the value for strAmount (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strAmount = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'FromDate':
					/**
					 * Sets the value for dttFromDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttFromDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ToDate':
					/**
					 * Sets the value for dttToDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttToDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Show':
					/**
					 * Sets the value for blnShow 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnShow = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'EmployeeObject':
					/**
					 * Sets the value for the Ledger object referenced by intEmployee (Not Null)
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intEmployee = null;
						$this->objEmployeeObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved EmployeeObject for this BankLoan');

						// Update Local Member Variables
						$this->objEmployeeObject = $mixValue;
						$this->intEmployee = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'BankObject':
					/**
					 * Sets the value for the Ledger object referenced by intBank (Not Null)
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intBank = null;
						$this->objBankObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved BankObject for this BankLoan');

						// Update Local Member Variables
						$this->objBankObject = $mixValue;
						$this->intBank = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "bank_loan";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[BankLoan::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="BankLoan"><sequence>';
			$strToReturn .= '<element name="IdbankLoan" type="xsd:int"/>';
			$strToReturn .= '<element name="EmployeeObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="BankObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="Amount" type="xsd:string"/>';
			$strToReturn .= '<element name="FromDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="ToDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Show" type="xsd:boolean"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('BankLoan', $strComplexTypeArray)) {
				$strComplexTypeArray['BankLoan'] = BankLoan::GetSoapComplexTypeXml();
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, BankLoan::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new BankLoan();
			if (property_exists($objSoapObject, 'IdbankLoan'))
				$objToReturn->intIdbankLoan = $objSoapObject->IdbankLoan;
			if ((property_exists($objSoapObject, 'EmployeeObject')) &&
				($objSoapObject->EmployeeObject))
				$objToReturn->EmployeeObject = Ledger::GetObjectFromSoapObject($objSoapObject->EmployeeObject);
			if ((property_exists($objSoapObject, 'BankObject')) &&
				($objSoapObject->BankObject))
				$objToReturn->BankObject = Ledger::GetObjectFromSoapObject($objSoapObject->BankObject);
			if (property_exists($objSoapObject, 'Amount'))
				$objToReturn->strAmount = $objSoapObject->Amount;
			if (property_exists($objSoapObject, 'FromDate'))
				$objToReturn->dttFromDate = new QDateTime($objSoapObject->FromDate);
			if (property_exists($objSoapObject, 'ToDate'))
				$objToReturn->dttToDate = new QDateTime($objSoapObject->ToDate);
			if (property_exists($objSoapObject, 'Show'))
				$objToReturn->blnShow = $objSoapObject->Show;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, BankLoan::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objEmployeeObject)
				$objObject->objEmployeeObject = Ledger::GetSoapObjectFromObject($objObject->objEmployeeObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intEmployee = null;
			if ($objObject->objBankObject)
				$objObject->objBankObject = Ledger::GetSoapObjectFromObject($objObject->objBankObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intBank = null;
			if ($objObject->dttFromDate)
				$objObject->dttFromDate = $objObject->dttFromDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttToDate)
				$objObject->dttToDate = $objObject->dttToDate->qFormat(QDateTime::FormatSoap);
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdbankLoan'] = $this->intIdbankLoan;
			$iArray['Employee'] = $this->intEmployee;
			$iArray['Bank'] = $this->intBank;
			$iArray['Amount'] = $this->strAmount;
			$iArray['FromDate'] = $this->dttFromDate;
			$iArray['ToDate'] = $this->dttToDate;
			$iArray['Show'] = $this->blnShow;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdbankLoan ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdbankLoan
     * @property-read QQNode $Employee
     * @property-read QQNodeLedger $EmployeeObject
     * @property-read QQNode $Bank
     * @property-read QQNodeLedger $BankObject
     * @property-read QQNode $Amount
     * @property-read QQNode $FromDate
     * @property-read QQNode $ToDate
     * @property-read QQNode $Show
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeBankLoan extends QQNode {
		protected $strTableName = 'bank_loan';
		protected $strPrimaryKey = 'idbank_loan';
		protected $strClassName = 'BankLoan';
		public function __get($strName) {
			switch ($strName) {
				case 'IdbankLoan':
					return new QQNode('idbank_loan', 'IdbankLoan', 'Integer', $this);
				case 'Employee':
					return new QQNode('employee', 'Employee', 'Integer', $this);
				case 'EmployeeObject':
					return new QQNodeLedger('employee', 'EmployeeObject', 'Integer', $this);
				case 'Bank':
					return new QQNode('bank', 'Bank', 'Integer', $this);
				case 'BankObject':
					return new QQNodeLedger('bank', 'BankObject', 'Integer', $this);
				case 'Amount':
					return new QQNode('amount', 'Amount', 'VarChar', $this);
				case 'FromDate':
					return new QQNode('from_date', 'FromDate', 'Date', $this);
				case 'ToDate':
					return new QQNode('to_date', 'ToDate', 'Date', $this);
				case 'Show':
					return new QQNode('show', 'Show', 'Bit', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idbank_loan', 'IdbankLoan', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdbankLoan
     * @property-read QQNode $Employee
     * @property-read QQNodeLedger $EmployeeObject
     * @property-read QQNode $Bank
     * @property-read QQNodeLedger $BankObject
     * @property-read QQNode $Amount
     * @property-read QQNode $FromDate
     * @property-read QQNode $ToDate
     * @property-read QQNode $Show
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeBankLoan extends QQReverseReferenceNode {
		protected $strTableName = 'bank_loan';
		protected $strPrimaryKey = 'idbank_loan';
		protected $strClassName = 'BankLoan';
		public function __get($strName) {
			switch ($strName) {
				case 'IdbankLoan':
					return new QQNode('idbank_loan', 'IdbankLoan', 'integer', $this);
				case 'Employee':
					return new QQNode('employee', 'Employee', 'integer', $this);
				case 'EmployeeObject':
					return new QQNodeLedger('employee', 'EmployeeObject', 'integer', $this);
				case 'Bank':
					return new QQNode('bank', 'Bank', 'integer', $this);
				case 'BankObject':
					return new QQNodeLedger('bank', 'BankObject', 'integer', $this);
				case 'Amount':
					return new QQNode('amount', 'Amount', 'string', $this);
				case 'FromDate':
					return new QQNode('from_date', 'FromDate', 'QDateTime', $this);
				case 'ToDate':
					return new QQNode('to_date', 'ToDate', 'QDateTime', $this);
				case 'Show':
					return new QQNode('show', 'Show', 'boolean', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idbank_loan', 'IdbankLoan', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
