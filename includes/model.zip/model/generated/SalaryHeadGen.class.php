<?php
	/**
	 * The abstract SalaryHeadGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the SalaryHead subclass which
	 * extends this SalaryHeadGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the SalaryHead class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdsalaryHead the value for intIdsalaryHead (Read-Only PK)
	 * @property integer $SalaryTemplet the value for intSalaryTemplet (Not Null)
	 * @property integer $SalaryHead the value for intSalaryHead (Not Null)
	 * @property integer $CalculationGrp the value for intCalculationGrp (Not Null)
	 * @property string $AppliedMonth the value for strAppliedMonth 
	 * @property integer $BasedSalaryHead the value for intBasedSalaryHead 
	 * @property string $Percentage the value for strPercentage 
	 * @property string $Amount the value for strAmount 
	 * @property string $GeneratedAmount the value for strGeneratedAmount 
	 * @property boolean $ShowInSalary the value for blnShowInSalary 
	 * @property SalaryTemplet $SalaryTempletObject the value for the SalaryTemplet object referenced by intSalaryTemplet (Not Null)
	 * @property Ledger $SalaryHeadObject the value for the Ledger object referenced by intSalaryHead (Not Null)
	 * @property CalculationGrp $CalculationGrpObject the value for the CalculationGrp object referenced by intCalculationGrp (Not Null)
	 * @property SalaryHead $BasedSalaryHeadObject the value for the SalaryHead object referenced by intBasedSalaryHead 
	 * @property-read Calculation $_Calculation the value for the private _objCalculation (Read-Only) if set due to an expansion on the calculation.salary_head reverse relationship
	 * @property-read Calculation[] $_CalculationArray the value for the private _objCalculationArray (Read-Only) if set due to an ExpandAsArray on the calculation.salary_head reverse relationship
	 * @property-read Calculation $_CalculationAs2 the value for the private _objCalculationAs2 (Read-Only) if set due to an expansion on the calculation.salary_head_2 reverse relationship
	 * @property-read Calculation[] $_CalculationAs2Array the value for the private _objCalculationAs2Array (Read-Only) if set due to an ExpandAsArray on the calculation.salary_head_2 reverse relationship
	 * @property-read Calculation $_CalculationAs1 the value for the private _objCalculationAs1 (Read-Only) if set due to an expansion on the calculation.salary_head_1 reverse relationship
	 * @property-read Calculation[] $_CalculationAs1Array the value for the private _objCalculationAs1Array (Read-Only) if set due to an ExpandAsArray on the calculation.salary_head_1 reverse relationship
	 * @property-read PaySlabs $_PaySlabsAsSalaryhead the value for the private _objPaySlabsAsSalaryhead (Read-Only) if set due to an expansion on the pay_slabs.salaryhead reverse relationship
	 * @property-read PaySlabs[] $_PaySlabsAsSalaryheadArray the value for the private _objPaySlabsAsSalaryheadArray (Read-Only) if set due to an ExpandAsArray on the pay_slabs.salaryhead reverse relationship
	 * @property-read SalaryHead $_SalaryHeadAsBased the value for the private _objSalaryHeadAsBased (Read-Only) if set due to an expansion on the salary_head.based_salary_head reverse relationship
	 * @property-read SalaryHead[] $_SalaryHeadAsBasedArray the value for the private _objSalaryHeadAsBasedArray (Read-Only) if set due to an ExpandAsArray on the salary_head.based_salary_head reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class SalaryHeadGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column salary_head.idsalary_head
		 * @var integer intIdsalaryHead
		 */
		protected $intIdsalaryHead;
		const IdsalaryHeadDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_head.salary_templet
		 * @var integer intSalaryTemplet
		 */
		protected $intSalaryTemplet;
		const SalaryTempletDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_head.salary_head
		 * @var integer intSalaryHead
		 */
		protected $intSalaryHead;
		const SalaryHeadDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_head.calculation_grp
		 * @var integer intCalculationGrp
		 */
		protected $intCalculationGrp;
		const CalculationGrpDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_head.applied_month
		 * @var string strAppliedMonth
		 */
		protected $strAppliedMonth;
		const AppliedMonthMaxLength = 255;
		const AppliedMonthDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_head.based_salary_head
		 * @var integer intBasedSalaryHead
		 */
		protected $intBasedSalaryHead;
		const BasedSalaryHeadDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_head.percentage
		 * @var string strPercentage
		 */
		protected $strPercentage;
		const PercentageDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_head.amount
		 * @var string strAmount
		 */
		protected $strAmount;
		const AmountDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_head.generated_amount
		 * @var string strGeneratedAmount
		 */
		protected $strGeneratedAmount;
		const GeneratedAmountDefault = null;


		/**
		 * Protected member variable that maps to the database column salary_head.show_in_salary
		 * @var boolean blnShowInSalary
		 */
		protected $blnShowInSalary;
		const ShowInSalaryDefault = null;


		/**
		 * Private member variable that stores a reference to a single Calculation object
		 * (of type Calculation), if this SalaryHead object was restored with
		 * an expansion on the calculation association table.
		 * @var Calculation _objCalculation;
		 */
		private $_objCalculation;

		/**
		 * Private member variable that stores a reference to an array of Calculation objects
		 * (of type Calculation[]), if this SalaryHead object was restored with
		 * an ExpandAsArray on the calculation association table.
		 * @var Calculation[] _objCalculationArray;
		 */
		private $_objCalculationArray = null;

		/**
		 * Private member variable that stores a reference to a single CalculationAs2 object
		 * (of type Calculation), if this SalaryHead object was restored with
		 * an expansion on the calculation association table.
		 * @var Calculation _objCalculationAs2;
		 */
		private $_objCalculationAs2;

		/**
		 * Private member variable that stores a reference to an array of CalculationAs2 objects
		 * (of type Calculation[]), if this SalaryHead object was restored with
		 * an ExpandAsArray on the calculation association table.
		 * @var Calculation[] _objCalculationAs2Array;
		 */
		private $_objCalculationAs2Array = null;

		/**
		 * Private member variable that stores a reference to a single CalculationAs1 object
		 * (of type Calculation), if this SalaryHead object was restored with
		 * an expansion on the calculation association table.
		 * @var Calculation _objCalculationAs1;
		 */
		private $_objCalculationAs1;

		/**
		 * Private member variable that stores a reference to an array of CalculationAs1 objects
		 * (of type Calculation[]), if this SalaryHead object was restored with
		 * an ExpandAsArray on the calculation association table.
		 * @var Calculation[] _objCalculationAs1Array;
		 */
		private $_objCalculationAs1Array = null;

		/**
		 * Private member variable that stores a reference to a single PaySlabsAsSalaryhead object
		 * (of type PaySlabs), if this SalaryHead object was restored with
		 * an expansion on the pay_slabs association table.
		 * @var PaySlabs _objPaySlabsAsSalaryhead;
		 */
		private $_objPaySlabsAsSalaryhead;

		/**
		 * Private member variable that stores a reference to an array of PaySlabsAsSalaryhead objects
		 * (of type PaySlabs[]), if this SalaryHead object was restored with
		 * an ExpandAsArray on the pay_slabs association table.
		 * @var PaySlabs[] _objPaySlabsAsSalaryheadArray;
		 */
		private $_objPaySlabsAsSalaryheadArray = null;

		/**
		 * Private member variable that stores a reference to a single SalaryHeadAsBased object
		 * (of type SalaryHead), if this SalaryHead object was restored with
		 * an expansion on the salary_head association table.
		 * @var SalaryHead _objSalaryHeadAsBased;
		 */
		private $_objSalaryHeadAsBased;

		/**
		 * Private member variable that stores a reference to an array of SalaryHeadAsBased objects
		 * (of type SalaryHead[]), if this SalaryHead object was restored with
		 * an ExpandAsArray on the salary_head association table.
		 * @var SalaryHead[] _objSalaryHeadAsBasedArray;
		 */
		private $_objSalaryHeadAsBasedArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salary_head.salary_templet.
		 *
		 * NOTE: Always use the SalaryTempletObject property getter to correctly retrieve this SalaryTemplet object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var SalaryTemplet objSalaryTempletObject
		 */
		protected $objSalaryTempletObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salary_head.salary_head.
		 *
		 * NOTE: Always use the SalaryHeadObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objSalaryHeadObject
		 */
		protected $objSalaryHeadObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salary_head.calculation_grp.
		 *
		 * NOTE: Always use the CalculationGrpObject property getter to correctly retrieve this CalculationGrp object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var CalculationGrp objCalculationGrpObject
		 */
		protected $objCalculationGrpObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salary_head.based_salary_head.
		 *
		 * NOTE: Always use the BasedSalaryHeadObject property getter to correctly retrieve this SalaryHead object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var SalaryHead objBasedSalaryHeadObject
		 */
		protected $objBasedSalaryHeadObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdsalaryHead = SalaryHead::IdsalaryHeadDefault;
			$this->intSalaryTemplet = SalaryHead::SalaryTempletDefault;
			$this->intSalaryHead = SalaryHead::SalaryHeadDefault;
			$this->intCalculationGrp = SalaryHead::CalculationGrpDefault;
			$this->strAppliedMonth = SalaryHead::AppliedMonthDefault;
			$this->intBasedSalaryHead = SalaryHead::BasedSalaryHeadDefault;
			$this->strPercentage = SalaryHead::PercentageDefault;
			$this->strAmount = SalaryHead::AmountDefault;
			$this->strGeneratedAmount = SalaryHead::GeneratedAmountDefault;
			$this->blnShowInSalary = SalaryHead::ShowInSalaryDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a SalaryHead from PK Info
		 * @param integer $intIdsalaryHead
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryHead
		 */
		public static function Load($intIdsalaryHead, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'SalaryHead', $intIdsalaryHead);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = SalaryHead::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::SalaryHead()->IdsalaryHead, $intIdsalaryHead)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all SalaryHeads
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryHead[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call SalaryHead::QueryArray to perform the LoadAll query
			try {
				return SalaryHead::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all SalaryHeads
		 * @return int
		 */
		public static function CountAll() {
			// Call SalaryHead::QueryCount to perform the CountAll query
			return SalaryHead::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Create/Build out the QueryBuilder object with SalaryHead-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'salary_head');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				SalaryHead::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('salary_head');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single SalaryHead object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return SalaryHead the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = SalaryHead::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new SalaryHead object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = SalaryHead::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return SalaryHead::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of SalaryHead objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return SalaryHead[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = SalaryHead::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return SalaryHead::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = SalaryHead::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of SalaryHead objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = SalaryHead::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			$strQuery = SalaryHead::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/salaryhead', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = SalaryHead::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this SalaryHead
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'salary_head';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idsalary_head', $strAliasPrefix . 'idsalary_head');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idsalary_head', $strAliasPrefix . 'idsalary_head');
			    $objBuilder->AddSelectItem($strTableName, 'salary_templet', $strAliasPrefix . 'salary_templet');
			    $objBuilder->AddSelectItem($strTableName, 'salary_head', $strAliasPrefix . 'salary_head');
			    $objBuilder->AddSelectItem($strTableName, 'calculation_grp', $strAliasPrefix . 'calculation_grp');
			    $objBuilder->AddSelectItem($strTableName, 'applied_month', $strAliasPrefix . 'applied_month');
			    $objBuilder->AddSelectItem($strTableName, 'based_salary_head', $strAliasPrefix . 'based_salary_head');
			    $objBuilder->AddSelectItem($strTableName, 'percentage', $strAliasPrefix . 'percentage');
			    $objBuilder->AddSelectItem($strTableName, 'amount', $strAliasPrefix . 'amount');
			    $objBuilder->AddSelectItem($strTableName, 'generated_amount', $strAliasPrefix . 'generated_amount');
			    $objBuilder->AddSelectItem($strTableName, 'show_in_salary', $strAliasPrefix . 'show_in_salary');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a SalaryHead from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this SalaryHead::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return SalaryHead
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idsalary_head';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdsalaryHead == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'salary_head__';


						// Expanding reverse references: Calculation
						$strAlias = $strAliasPrefix . 'calculation__idcalculation';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objCalculationArray)
								$objPreviousItem->_objCalculationArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objCalculationArray)) {
								$objPreviousChildItems = $objPreviousItem->_objCalculationArray;
								$objChildItem = Calculation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calculation__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objCalculationArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objCalculationArray[] = Calculation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calculation__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: CalculationAs2
						$strAlias = $strAliasPrefix . 'calculationas2__idcalculation';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objCalculationAs2Array)
								$objPreviousItem->_objCalculationAs2Array = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objCalculationAs2Array)) {
								$objPreviousChildItems = $objPreviousItem->_objCalculationAs2Array;
								$objChildItem = Calculation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calculationas2__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objCalculationAs2Array[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objCalculationAs2Array[] = Calculation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calculationas2__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: CalculationAs1
						$strAlias = $strAliasPrefix . 'calculationas1__idcalculation';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objCalculationAs1Array)
								$objPreviousItem->_objCalculationAs1Array = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objCalculationAs1Array)) {
								$objPreviousChildItems = $objPreviousItem->_objCalculationAs1Array;
								$objChildItem = Calculation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calculationas1__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objCalculationAs1Array[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objCalculationAs1Array[] = Calculation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calculationas1__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: PaySlabsAsSalaryhead
						$strAlias = $strAliasPrefix . 'payslabsassalaryhead__idpay_slabs';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objPaySlabsAsSalaryheadArray)
								$objPreviousItem->_objPaySlabsAsSalaryheadArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objPaySlabsAsSalaryheadArray)) {
								$objPreviousChildItems = $objPreviousItem->_objPaySlabsAsSalaryheadArray;
								$objChildItem = PaySlabs::InstantiateDbRow($objDbRow, $strAliasPrefix . 'payslabsassalaryhead__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objPaySlabsAsSalaryheadArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objPaySlabsAsSalaryheadArray[] = PaySlabs::InstantiateDbRow($objDbRow, $strAliasPrefix . 'payslabsassalaryhead__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: SalaryHeadAsBased
						$strAlias = $strAliasPrefix . 'salaryheadasbased__idsalary_head';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objSalaryHeadAsBasedArray)
								$objPreviousItem->_objSalaryHeadAsBasedArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objSalaryHeadAsBasedArray)) {
								$objPreviousChildItems = $objPreviousItem->_objSalaryHeadAsBasedArray;
								$objChildItem = SalaryHead::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salaryheadasbased__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objSalaryHeadAsBasedArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objSalaryHeadAsBasedArray[] = SalaryHead::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salaryheadasbased__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'salary_head__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the SalaryHead object
			$objToReturn = new SalaryHead();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idsalary_head';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdsalaryHead = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'salary_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSalaryTemplet = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'salary_head';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSalaryHead = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'calculation_grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCalculationGrp = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'applied_month';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strAppliedMonth = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'based_salary_head';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intBasedSalaryHead = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'percentage';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strPercentage = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'amount';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strAmount = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'generated_amount';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strGeneratedAmount = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'show_in_salary';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnShowInSalary = $objDbRow->GetColumn($strAliasName, 'Bit');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdsalaryHead != $objPreviousItem->IdsalaryHead) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objCalculationArray);
					$cnt = count($objToReturn->_objCalculationArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objCalculationArray, $objToReturn->_objCalculationArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objCalculationAs2Array);
					$cnt = count($objToReturn->_objCalculationAs2Array);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objCalculationAs2Array, $objToReturn->_objCalculationAs2Array)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objCalculationAs1Array);
					$cnt = count($objToReturn->_objCalculationAs1Array);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objCalculationAs1Array, $objToReturn->_objCalculationAs1Array)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objPaySlabsAsSalaryheadArray);
					$cnt = count($objToReturn->_objPaySlabsAsSalaryheadArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objPaySlabsAsSalaryheadArray, $objToReturn->_objPaySlabsAsSalaryheadArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objSalaryHeadAsBasedArray);
					$cnt = count($objToReturn->_objSalaryHeadAsBasedArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objSalaryHeadAsBasedArray, $objToReturn->_objSalaryHeadAsBasedArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'salary_head__';

			// Check for SalaryTempletObject Early Binding
			$strAlias = $strAliasPrefix . 'salary_templet__idsalary_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSalaryTempletObject = SalaryTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salary_templet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for SalaryHeadObject Early Binding
			$strAlias = $strAliasPrefix . 'salary_head__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSalaryHeadObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salary_head__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CalculationGrpObject Early Binding
			$strAlias = $strAliasPrefix . 'calculation_grp__idcalculation_grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCalculationGrpObject = CalculationGrp::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calculation_grp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for BasedSalaryHeadObject Early Binding
			$strAlias = $strAliasPrefix . 'based_salary_head__idsalary_head';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objBasedSalaryHeadObject = SalaryHead::InstantiateDbRow($objDbRow, $strAliasPrefix . 'based_salary_head__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for Calculation Virtual Binding
			$strAlias = $strAliasPrefix . 'calculation__idcalculation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objCalculationArray)
				$objToReturn->_objCalculationArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objCalculationArray[] = Calculation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calculation__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objCalculation = Calculation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calculation__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for CalculationAs2 Virtual Binding
			$strAlias = $strAliasPrefix . 'calculationas2__idcalculation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objCalculationAs2Array)
				$objToReturn->_objCalculationAs2Array = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objCalculationAs2Array[] = Calculation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calculationas2__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objCalculationAs2 = Calculation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calculationas2__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for CalculationAs1 Virtual Binding
			$strAlias = $strAliasPrefix . 'calculationas1__idcalculation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objCalculationAs1Array)
				$objToReturn->_objCalculationAs1Array = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objCalculationAs1Array[] = Calculation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calculationas1__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objCalculationAs1 = Calculation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calculationas1__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for PaySlabsAsSalaryhead Virtual Binding
			$strAlias = $strAliasPrefix . 'payslabsassalaryhead__idpay_slabs';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objPaySlabsAsSalaryheadArray)
				$objToReturn->_objPaySlabsAsSalaryheadArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objPaySlabsAsSalaryheadArray[] = PaySlabs::InstantiateDbRow($objDbRow, $strAliasPrefix . 'payslabsassalaryhead__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objPaySlabsAsSalaryhead = PaySlabs::InstantiateDbRow($objDbRow, $strAliasPrefix . 'payslabsassalaryhead__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for SalaryHeadAsBased Virtual Binding
			$strAlias = $strAliasPrefix . 'salaryheadasbased__idsalary_head';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objSalaryHeadAsBasedArray)
				$objToReturn->_objSalaryHeadAsBasedArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objSalaryHeadAsBasedArray[] = SalaryHead::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salaryheadasbased__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objSalaryHeadAsBased = SalaryHead::InstantiateDbRow($objDbRow, $strAliasPrefix . 'salaryheadasbased__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of SalaryHeads from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return SalaryHead[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = SalaryHead::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = SalaryHead::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single SalaryHead object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return SalaryHead next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return SalaryHead::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single SalaryHead object,
		 * by IdsalaryHead Index(es)
		 * @param integer $intIdsalaryHead
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryHead
		*/
		public static function LoadByIdsalaryHead($intIdsalaryHead, $objOptionalClauses = null) {
			return SalaryHead::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::SalaryHead()->IdsalaryHead, $intIdsalaryHead)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of SalaryHead objects,
		 * by SalaryTemplet Index(es)
		 * @param integer $intSalaryTemplet
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryHead[]
		*/
		public static function LoadArrayBySalaryTemplet($intSalaryTemplet, $objOptionalClauses = null) {
			// Call SalaryHead::QueryArray to perform the LoadArrayBySalaryTemplet query
			try {
				return SalaryHead::QueryArray(
					QQ::Equal(QQN::SalaryHead()->SalaryTemplet, $intSalaryTemplet),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count SalaryHeads
		 * by SalaryTemplet Index(es)
		 * @param integer $intSalaryTemplet
		 * @return int
		*/
		public static function CountBySalaryTemplet($intSalaryTemplet) {
			// Call SalaryHead::QueryCount to perform the CountBySalaryTemplet query
			return SalaryHead::QueryCount(
				QQ::Equal(QQN::SalaryHead()->SalaryTemplet, $intSalaryTemplet)
			);
		}

		/**
		 * Load an array of SalaryHead objects,
		 * by SalaryHead Index(es)
		 * @param integer $intSalaryHead
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryHead[]
		*/
		public static function LoadArrayBySalaryHead($intSalaryHead, $objOptionalClauses = null) {
			// Call SalaryHead::QueryArray to perform the LoadArrayBySalaryHead query
			try {
				return SalaryHead::QueryArray(
					QQ::Equal(QQN::SalaryHead()->SalaryHead, $intSalaryHead),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count SalaryHeads
		 * by SalaryHead Index(es)
		 * @param integer $intSalaryHead
		 * @return int
		*/
		public static function CountBySalaryHead($intSalaryHead) {
			// Call SalaryHead::QueryCount to perform the CountBySalaryHead query
			return SalaryHead::QueryCount(
				QQ::Equal(QQN::SalaryHead()->SalaryHead, $intSalaryHead)
			);
		}

		/**
		 * Load an array of SalaryHead objects,
		 * by CalculationGrp Index(es)
		 * @param integer $intCalculationGrp
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryHead[]
		*/
		public static function LoadArrayByCalculationGrp($intCalculationGrp, $objOptionalClauses = null) {
			// Call SalaryHead::QueryArray to perform the LoadArrayByCalculationGrp query
			try {
				return SalaryHead::QueryArray(
					QQ::Equal(QQN::SalaryHead()->CalculationGrp, $intCalculationGrp),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count SalaryHeads
		 * by CalculationGrp Index(es)
		 * @param integer $intCalculationGrp
		 * @return int
		*/
		public static function CountByCalculationGrp($intCalculationGrp) {
			// Call SalaryHead::QueryCount to perform the CountByCalculationGrp query
			return SalaryHead::QueryCount(
				QQ::Equal(QQN::SalaryHead()->CalculationGrp, $intCalculationGrp)
			);
		}

		/**
		 * Load an array of SalaryHead objects,
		 * by BasedSalaryHead Index(es)
		 * @param integer $intBasedSalaryHead
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryHead[]
		*/
		public static function LoadArrayByBasedSalaryHead($intBasedSalaryHead, $objOptionalClauses = null) {
			// Call SalaryHead::QueryArray to perform the LoadArrayByBasedSalaryHead query
			try {
				return SalaryHead::QueryArray(
					QQ::Equal(QQN::SalaryHead()->BasedSalaryHead, $intBasedSalaryHead),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count SalaryHeads
		 * by BasedSalaryHead Index(es)
		 * @param integer $intBasedSalaryHead
		 * @return int
		*/
		public static function CountByBasedSalaryHead($intBasedSalaryHead) {
			// Call SalaryHead::QueryCount to perform the CountByBasedSalaryHead query
			return SalaryHead::QueryCount(
				QQ::Equal(QQN::SalaryHead()->BasedSalaryHead, $intBasedSalaryHead)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this SalaryHead
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `salary_head` (
							`salary_templet`,
							`salary_head`,
							`calculation_grp`,
							`applied_month`,
							`based_salary_head`,
							`percentage`,
							`amount`,
							`generated_amount`,
							`show_in_salary`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intSalaryTemplet) . ',
							' . $objDatabase->SqlVariable($this->intSalaryHead) . ',
							' . $objDatabase->SqlVariable($this->intCalculationGrp) . ',
							' . $objDatabase->SqlVariable($this->strAppliedMonth) . ',
							' . $objDatabase->SqlVariable($this->intBasedSalaryHead) . ',
							' . $objDatabase->SqlVariable($this->strPercentage) . ',
							' . $objDatabase->SqlVariable($this->strAmount) . ',
							' . $objDatabase->SqlVariable($this->strGeneratedAmount) . ',
							' . $objDatabase->SqlVariable($this->blnShowInSalary) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdsalaryHead = $objDatabase->InsertId('salary_head', 'idsalary_head');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`salary_head`
						SET
							`salary_templet` = ' . $objDatabase->SqlVariable($this->intSalaryTemplet) . ',
							`salary_head` = ' . $objDatabase->SqlVariable($this->intSalaryHead) . ',
							`calculation_grp` = ' . $objDatabase->SqlVariable($this->intCalculationGrp) . ',
							`applied_month` = ' . $objDatabase->SqlVariable($this->strAppliedMonth) . ',
							`based_salary_head` = ' . $objDatabase->SqlVariable($this->intBasedSalaryHead) . ',
							`percentage` = ' . $objDatabase->SqlVariable($this->strPercentage) . ',
							`amount` = ' . $objDatabase->SqlVariable($this->strAmount) . ',
							`generated_amount` = ' . $objDatabase->SqlVariable($this->strGeneratedAmount) . ',
							`show_in_salary` = ' . $objDatabase->SqlVariable($this->blnShowInSalary) . '
						WHERE
							`idsalary_head` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this SalaryHead
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this SalaryHead with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salary_head`
				WHERE
					`idsalary_head` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this SalaryHead ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'SalaryHead', $this->intIdsalaryHead);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all SalaryHeads
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salary_head`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate salary_head table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `salary_head`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this SalaryHead from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved SalaryHead object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = SalaryHead::Load($this->intIdsalaryHead);

			// Update $this's local variables to match
			$this->SalaryTemplet = $objReloaded->SalaryTemplet;
			$this->SalaryHead = $objReloaded->SalaryHead;
			$this->CalculationGrp = $objReloaded->CalculationGrp;
			$this->strAppliedMonth = $objReloaded->strAppliedMonth;
			$this->BasedSalaryHead = $objReloaded->BasedSalaryHead;
			$this->strPercentage = $objReloaded->strPercentage;
			$this->strAmount = $objReloaded->strAmount;
			$this->strGeneratedAmount = $objReloaded->strGeneratedAmount;
			$this->blnShowInSalary = $objReloaded->blnShowInSalary;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdsalaryHead':
					/**
					 * Gets the value for intIdsalaryHead (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdsalaryHead;

				case 'SalaryTemplet':
					/**
					 * Gets the value for intSalaryTemplet (Not Null)
					 * @return integer
					 */
					return $this->intSalaryTemplet;

				case 'SalaryHead':
					/**
					 * Gets the value for intSalaryHead (Not Null)
					 * @return integer
					 */
					return $this->intSalaryHead;

				case 'CalculationGrp':
					/**
					 * Gets the value for intCalculationGrp (Not Null)
					 * @return integer
					 */
					return $this->intCalculationGrp;

				case 'AppliedMonth':
					/**
					 * Gets the value for strAppliedMonth 
					 * @return string
					 */
					return $this->strAppliedMonth;

				case 'BasedSalaryHead':
					/**
					 * Gets the value for intBasedSalaryHead 
					 * @return integer
					 */
					return $this->intBasedSalaryHead;

				case 'Percentage':
					/**
					 * Gets the value for strPercentage 
					 * @return string
					 */
					return $this->strPercentage;

				case 'Amount':
					/**
					 * Gets the value for strAmount 
					 * @return string
					 */
					return $this->strAmount;

				case 'GeneratedAmount':
					/**
					 * Gets the value for strGeneratedAmount 
					 * @return string
					 */
					return $this->strGeneratedAmount;

				case 'ShowInSalary':
					/**
					 * Gets the value for blnShowInSalary 
					 * @return boolean
					 */
					return $this->blnShowInSalary;


				///////////////////
				// Member Objects
				///////////////////
				case 'SalaryTempletObject':
					/**
					 * Gets the value for the SalaryTemplet object referenced by intSalaryTemplet (Not Null)
					 * @return SalaryTemplet
					 */
					try {
						if ((!$this->objSalaryTempletObject) && (!is_null($this->intSalaryTemplet)))
							$this->objSalaryTempletObject = SalaryTemplet::Load($this->intSalaryTemplet);
						return $this->objSalaryTempletObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SalaryHeadObject':
					/**
					 * Gets the value for the Ledger object referenced by intSalaryHead (Not Null)
					 * @return Ledger
					 */
					try {
						if ((!$this->objSalaryHeadObject) && (!is_null($this->intSalaryHead)))
							$this->objSalaryHeadObject = Ledger::Load($this->intSalaryHead);
						return $this->objSalaryHeadObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CalculationGrpObject':
					/**
					 * Gets the value for the CalculationGrp object referenced by intCalculationGrp (Not Null)
					 * @return CalculationGrp
					 */
					try {
						if ((!$this->objCalculationGrpObject) && (!is_null($this->intCalculationGrp)))
							$this->objCalculationGrpObject = CalculationGrp::Load($this->intCalculationGrp);
						return $this->objCalculationGrpObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'BasedSalaryHeadObject':
					/**
					 * Gets the value for the SalaryHead object referenced by intBasedSalaryHead 
					 * @return SalaryHead
					 */
					try {
						if ((!$this->objBasedSalaryHeadObject) && (!is_null($this->intBasedSalaryHead)))
							$this->objBasedSalaryHeadObject = SalaryHead::Load($this->intBasedSalaryHead);
						return $this->objBasedSalaryHeadObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_Calculation':
					/**
					 * Gets the value for the private _objCalculation (Read-Only)
					 * if set due to an expansion on the calculation.salary_head reverse relationship
					 * @return Calculation
					 */
					return $this->_objCalculation;

				case '_CalculationArray':
					/**
					 * Gets the value for the private _objCalculationArray (Read-Only)
					 * if set due to an ExpandAsArray on the calculation.salary_head reverse relationship
					 * @return Calculation[]
					 */
					return $this->_objCalculationArray;

				case '_CalculationAs2':
					/**
					 * Gets the value for the private _objCalculationAs2 (Read-Only)
					 * if set due to an expansion on the calculation.salary_head_2 reverse relationship
					 * @return Calculation
					 */
					return $this->_objCalculationAs2;

				case '_CalculationAs2Array':
					/**
					 * Gets the value for the private _objCalculationAs2Array (Read-Only)
					 * if set due to an ExpandAsArray on the calculation.salary_head_2 reverse relationship
					 * @return Calculation[]
					 */
					return $this->_objCalculationAs2Array;

				case '_CalculationAs1':
					/**
					 * Gets the value for the private _objCalculationAs1 (Read-Only)
					 * if set due to an expansion on the calculation.salary_head_1 reverse relationship
					 * @return Calculation
					 */
					return $this->_objCalculationAs1;

				case '_CalculationAs1Array':
					/**
					 * Gets the value for the private _objCalculationAs1Array (Read-Only)
					 * if set due to an ExpandAsArray on the calculation.salary_head_1 reverse relationship
					 * @return Calculation[]
					 */
					return $this->_objCalculationAs1Array;

				case '_PaySlabsAsSalaryhead':
					/**
					 * Gets the value for the private _objPaySlabsAsSalaryhead (Read-Only)
					 * if set due to an expansion on the pay_slabs.salaryhead reverse relationship
					 * @return PaySlabs
					 */
					return $this->_objPaySlabsAsSalaryhead;

				case '_PaySlabsAsSalaryheadArray':
					/**
					 * Gets the value for the private _objPaySlabsAsSalaryheadArray (Read-Only)
					 * if set due to an ExpandAsArray on the pay_slabs.salaryhead reverse relationship
					 * @return PaySlabs[]
					 */
					return $this->_objPaySlabsAsSalaryheadArray;

				case '_SalaryHeadAsBased':
					/**
					 * Gets the value for the private _objSalaryHeadAsBased (Read-Only)
					 * if set due to an expansion on the salary_head.based_salary_head reverse relationship
					 * @return SalaryHead
					 */
					return $this->_objSalaryHeadAsBased;

				case '_SalaryHeadAsBasedArray':
					/**
					 * Gets the value for the private _objSalaryHeadAsBasedArray (Read-Only)
					 * if set due to an ExpandAsArray on the salary_head.based_salary_head reverse relationship
					 * @return SalaryHead[]
					 */
					return $this->_objSalaryHeadAsBasedArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'SalaryTemplet':
					/**
					 * Sets the value for intSalaryTemplet (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSalaryTempletObject = null;
						return ($this->intSalaryTemplet = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SalaryHead':
					/**
					 * Sets the value for intSalaryHead (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSalaryHeadObject = null;
						return ($this->intSalaryHead = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CalculationGrp':
					/**
					 * Sets the value for intCalculationGrp (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCalculationGrpObject = null;
						return ($this->intCalculationGrp = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AppliedMonth':
					/**
					 * Sets the value for strAppliedMonth 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strAppliedMonth = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'BasedSalaryHead':
					/**
					 * Sets the value for intBasedSalaryHead 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objBasedSalaryHeadObject = null;
						return ($this->intBasedSalaryHead = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Percentage':
					/**
					 * Sets the value for strPercentage 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strPercentage = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Amount':
					/**
					 * Sets the value for strAmount 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strAmount = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GeneratedAmount':
					/**
					 * Sets the value for strGeneratedAmount 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strGeneratedAmount = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ShowInSalary':
					/**
					 * Sets the value for blnShowInSalary 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnShowInSalary = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'SalaryTempletObject':
					/**
					 * Sets the value for the SalaryTemplet object referenced by intSalaryTemplet (Not Null)
					 * @param SalaryTemplet $mixValue
					 * @return SalaryTemplet
					 */
					if (is_null($mixValue)) {
						$this->intSalaryTemplet = null;
						$this->objSalaryTempletObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a SalaryTemplet object
						try {
							$mixValue = QType::Cast($mixValue, 'SalaryTemplet');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED SalaryTemplet object
						if (is_null($mixValue->IdsalaryTemplet))
							throw new QCallerException('Unable to set an unsaved SalaryTempletObject for this SalaryHead');

						// Update Local Member Variables
						$this->objSalaryTempletObject = $mixValue;
						$this->intSalaryTemplet = $mixValue->IdsalaryTemplet;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'SalaryHeadObject':
					/**
					 * Sets the value for the Ledger object referenced by intSalaryHead (Not Null)
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intSalaryHead = null;
						$this->objSalaryHeadObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved SalaryHeadObject for this SalaryHead');

						// Update Local Member Variables
						$this->objSalaryHeadObject = $mixValue;
						$this->intSalaryHead = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CalculationGrpObject':
					/**
					 * Sets the value for the CalculationGrp object referenced by intCalculationGrp (Not Null)
					 * @param CalculationGrp $mixValue
					 * @return CalculationGrp
					 */
					if (is_null($mixValue)) {
						$this->intCalculationGrp = null;
						$this->objCalculationGrpObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a CalculationGrp object
						try {
							$mixValue = QType::Cast($mixValue, 'CalculationGrp');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED CalculationGrp object
						if (is_null($mixValue->IdcalculationGrp))
							throw new QCallerException('Unable to set an unsaved CalculationGrpObject for this SalaryHead');

						// Update Local Member Variables
						$this->objCalculationGrpObject = $mixValue;
						$this->intCalculationGrp = $mixValue->IdcalculationGrp;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'BasedSalaryHeadObject':
					/**
					 * Sets the value for the SalaryHead object referenced by intBasedSalaryHead 
					 * @param SalaryHead $mixValue
					 * @return SalaryHead
					 */
					if (is_null($mixValue)) {
						$this->intBasedSalaryHead = null;
						$this->objBasedSalaryHeadObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a SalaryHead object
						try {
							$mixValue = QType::Cast($mixValue, 'SalaryHead');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED SalaryHead object
						if (is_null($mixValue->IdsalaryHead))
							throw new QCallerException('Unable to set an unsaved BasedSalaryHeadObject for this SalaryHead');

						// Update Local Member Variables
						$this->objBasedSalaryHeadObject = $mixValue;
						$this->intBasedSalaryHead = $mixValue->IdsalaryHead;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for Calculation
		//-------------------------------------------------------------------

		/**
		 * Gets all associated Calculations as an array of Calculation objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Calculation[]
		*/
		public function GetCalculationArray($objOptionalClauses = null) {
			if ((is_null($this->intIdsalaryHead)))
				return array();

			try {
				return Calculation::LoadArrayBySalaryHead($this->intIdsalaryHead, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated Calculations
		 * @return int
		*/
		public function CountCalculations() {
			if ((is_null($this->intIdsalaryHead)))
				return 0;

			return Calculation::CountBySalaryHead($this->intIdsalaryHead);
		}

		/**
		 * Associates a Calculation
		 * @param Calculation $objCalculation
		 * @return void
		*/
		public function AssociateCalculation(Calculation $objCalculation) {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCalculation on this unsaved SalaryHead.');
			if ((is_null($objCalculation->Idcalculation)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCalculation on this SalaryHead with an unsaved Calculation.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`calculation`
				SET
					`salary_head` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
				WHERE
					`idcalculation` = ' . $objDatabase->SqlVariable($objCalculation->Idcalculation) . '
			');
		}

		/**
		 * Unassociates a Calculation
		 * @param Calculation $objCalculation
		 * @return void
		*/
		public function UnassociateCalculation(Calculation $objCalculation) {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculation on this unsaved SalaryHead.');
			if ((is_null($objCalculation->Idcalculation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculation on this SalaryHead with an unsaved Calculation.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`calculation`
				SET
					`salary_head` = null
				WHERE
					`idcalculation` = ' . $objDatabase->SqlVariable($objCalculation->Idcalculation) . ' AND
					`salary_head` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}

		/**
		 * Unassociates all Calculations
		 * @return void
		*/
		public function UnassociateAllCalculations() {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculation on this unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`calculation`
				SET
					`salary_head` = null
				WHERE
					`salary_head` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}

		/**
		 * Deletes an associated Calculation
		 * @param Calculation $objCalculation
		 * @return void
		*/
		public function DeleteAssociatedCalculation(Calculation $objCalculation) {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculation on this unsaved SalaryHead.');
			if ((is_null($objCalculation->Idcalculation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculation on this SalaryHead with an unsaved Calculation.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`calculation`
				WHERE
					`idcalculation` = ' . $objDatabase->SqlVariable($objCalculation->Idcalculation) . ' AND
					`salary_head` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}

		/**
		 * Deletes all associated Calculations
		 * @return void
		*/
		public function DeleteAllCalculations() {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculation on this unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`calculation`
				WHERE
					`salary_head` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}


		// Related Objects' Methods for CalculationAs2
		//-------------------------------------------------------------------

		/**
		 * Gets all associated CalculationsAs2 as an array of Calculation objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Calculation[]
		*/
		public function GetCalculationAs2Array($objOptionalClauses = null) {
			if ((is_null($this->intIdsalaryHead)))
				return array();

			try {
				return Calculation::LoadArrayBySalaryHead2($this->intIdsalaryHead, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated CalculationsAs2
		 * @return int
		*/
		public function CountCalculationsAs2() {
			if ((is_null($this->intIdsalaryHead)))
				return 0;

			return Calculation::CountBySalaryHead2($this->intIdsalaryHead);
		}

		/**
		 * Associates a CalculationAs2
		 * @param Calculation $objCalculation
		 * @return void
		*/
		public function AssociateCalculationAs2(Calculation $objCalculation) {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCalculationAs2 on this unsaved SalaryHead.');
			if ((is_null($objCalculation->Idcalculation)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCalculationAs2 on this SalaryHead with an unsaved Calculation.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`calculation`
				SET
					`salary_head_2` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
				WHERE
					`idcalculation` = ' . $objDatabase->SqlVariable($objCalculation->Idcalculation) . '
			');
		}

		/**
		 * Unassociates a CalculationAs2
		 * @param Calculation $objCalculation
		 * @return void
		*/
		public function UnassociateCalculationAs2(Calculation $objCalculation) {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculationAs2 on this unsaved SalaryHead.');
			if ((is_null($objCalculation->Idcalculation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculationAs2 on this SalaryHead with an unsaved Calculation.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`calculation`
				SET
					`salary_head_2` = null
				WHERE
					`idcalculation` = ' . $objDatabase->SqlVariable($objCalculation->Idcalculation) . ' AND
					`salary_head_2` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}

		/**
		 * Unassociates all CalculationsAs2
		 * @return void
		*/
		public function UnassociateAllCalculationsAs2() {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculationAs2 on this unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`calculation`
				SET
					`salary_head_2` = null
				WHERE
					`salary_head_2` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}

		/**
		 * Deletes an associated CalculationAs2
		 * @param Calculation $objCalculation
		 * @return void
		*/
		public function DeleteAssociatedCalculationAs2(Calculation $objCalculation) {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculationAs2 on this unsaved SalaryHead.');
			if ((is_null($objCalculation->Idcalculation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculationAs2 on this SalaryHead with an unsaved Calculation.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`calculation`
				WHERE
					`idcalculation` = ' . $objDatabase->SqlVariable($objCalculation->Idcalculation) . ' AND
					`salary_head_2` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}

		/**
		 * Deletes all associated CalculationsAs2
		 * @return void
		*/
		public function DeleteAllCalculationsAs2() {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculationAs2 on this unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`calculation`
				WHERE
					`salary_head_2` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}


		// Related Objects' Methods for CalculationAs1
		//-------------------------------------------------------------------

		/**
		 * Gets all associated CalculationsAs1 as an array of Calculation objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Calculation[]
		*/
		public function GetCalculationAs1Array($objOptionalClauses = null) {
			if ((is_null($this->intIdsalaryHead)))
				return array();

			try {
				return Calculation::LoadArrayBySalaryHead1($this->intIdsalaryHead, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated CalculationsAs1
		 * @return int
		*/
		public function CountCalculationsAs1() {
			if ((is_null($this->intIdsalaryHead)))
				return 0;

			return Calculation::CountBySalaryHead1($this->intIdsalaryHead);
		}

		/**
		 * Associates a CalculationAs1
		 * @param Calculation $objCalculation
		 * @return void
		*/
		public function AssociateCalculationAs1(Calculation $objCalculation) {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCalculationAs1 on this unsaved SalaryHead.');
			if ((is_null($objCalculation->Idcalculation)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCalculationAs1 on this SalaryHead with an unsaved Calculation.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`calculation`
				SET
					`salary_head_1` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
				WHERE
					`idcalculation` = ' . $objDatabase->SqlVariable($objCalculation->Idcalculation) . '
			');
		}

		/**
		 * Unassociates a CalculationAs1
		 * @param Calculation $objCalculation
		 * @return void
		*/
		public function UnassociateCalculationAs1(Calculation $objCalculation) {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculationAs1 on this unsaved SalaryHead.');
			if ((is_null($objCalculation->Idcalculation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculationAs1 on this SalaryHead with an unsaved Calculation.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`calculation`
				SET
					`salary_head_1` = null
				WHERE
					`idcalculation` = ' . $objDatabase->SqlVariable($objCalculation->Idcalculation) . ' AND
					`salary_head_1` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}

		/**
		 * Unassociates all CalculationsAs1
		 * @return void
		*/
		public function UnassociateAllCalculationsAs1() {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculationAs1 on this unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`calculation`
				SET
					`salary_head_1` = null
				WHERE
					`salary_head_1` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}

		/**
		 * Deletes an associated CalculationAs1
		 * @param Calculation $objCalculation
		 * @return void
		*/
		public function DeleteAssociatedCalculationAs1(Calculation $objCalculation) {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculationAs1 on this unsaved SalaryHead.');
			if ((is_null($objCalculation->Idcalculation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculationAs1 on this SalaryHead with an unsaved Calculation.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`calculation`
				WHERE
					`idcalculation` = ' . $objDatabase->SqlVariable($objCalculation->Idcalculation) . ' AND
					`salary_head_1` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}

		/**
		 * Deletes all associated CalculationsAs1
		 * @return void
		*/
		public function DeleteAllCalculationsAs1() {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCalculationAs1 on this unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`calculation`
				WHERE
					`salary_head_1` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}


		// Related Objects' Methods for PaySlabsAsSalaryhead
		//-------------------------------------------------------------------

		/**
		 * Gets all associated PaySlabsesAsSalaryhead as an array of PaySlabs objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return PaySlabs[]
		*/
		public function GetPaySlabsAsSalaryheadArray($objOptionalClauses = null) {
			if ((is_null($this->intIdsalaryHead)))
				return array();

			try {
				return PaySlabs::LoadArrayBySalaryhead($this->intIdsalaryHead, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated PaySlabsesAsSalaryhead
		 * @return int
		*/
		public function CountPaySlabsesAsSalaryhead() {
			if ((is_null($this->intIdsalaryHead)))
				return 0;

			return PaySlabs::CountBySalaryhead($this->intIdsalaryHead);
		}

		/**
		 * Associates a PaySlabsAsSalaryhead
		 * @param PaySlabs $objPaySlabs
		 * @return void
		*/
		public function AssociatePaySlabsAsSalaryhead(PaySlabs $objPaySlabs) {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociatePaySlabsAsSalaryhead on this unsaved SalaryHead.');
			if ((is_null($objPaySlabs->IdpaySlabs)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociatePaySlabsAsSalaryhead on this SalaryHead with an unsaved PaySlabs.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`pay_slabs`
				SET
					`salaryhead` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
				WHERE
					`idpay_slabs` = ' . $objDatabase->SqlVariable($objPaySlabs->IdpaySlabs) . '
			');
		}

		/**
		 * Unassociates a PaySlabsAsSalaryhead
		 * @param PaySlabs $objPaySlabs
		 * @return void
		*/
		public function UnassociatePaySlabsAsSalaryhead(PaySlabs $objPaySlabs) {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociatePaySlabsAsSalaryhead on this unsaved SalaryHead.');
			if ((is_null($objPaySlabs->IdpaySlabs)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociatePaySlabsAsSalaryhead on this SalaryHead with an unsaved PaySlabs.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`pay_slabs`
				SET
					`salaryhead` = null
				WHERE
					`idpay_slabs` = ' . $objDatabase->SqlVariable($objPaySlabs->IdpaySlabs) . ' AND
					`salaryhead` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}

		/**
		 * Unassociates all PaySlabsesAsSalaryhead
		 * @return void
		*/
		public function UnassociateAllPaySlabsesAsSalaryhead() {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociatePaySlabsAsSalaryhead on this unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`pay_slabs`
				SET
					`salaryhead` = null
				WHERE
					`salaryhead` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}

		/**
		 * Deletes an associated PaySlabsAsSalaryhead
		 * @param PaySlabs $objPaySlabs
		 * @return void
		*/
		public function DeleteAssociatedPaySlabsAsSalaryhead(PaySlabs $objPaySlabs) {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociatePaySlabsAsSalaryhead on this unsaved SalaryHead.');
			if ((is_null($objPaySlabs->IdpaySlabs)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociatePaySlabsAsSalaryhead on this SalaryHead with an unsaved PaySlabs.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`pay_slabs`
				WHERE
					`idpay_slabs` = ' . $objDatabase->SqlVariable($objPaySlabs->IdpaySlabs) . ' AND
					`salaryhead` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}

		/**
		 * Deletes all associated PaySlabsesAsSalaryhead
		 * @return void
		*/
		public function DeleteAllPaySlabsesAsSalaryhead() {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociatePaySlabsAsSalaryhead on this unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`pay_slabs`
				WHERE
					`salaryhead` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}


		// Related Objects' Methods for SalaryHeadAsBased
		//-------------------------------------------------------------------

		/**
		 * Gets all associated SalaryHeadsAsBased as an array of SalaryHead objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return SalaryHead[]
		*/
		public function GetSalaryHeadAsBasedArray($objOptionalClauses = null) {
			if ((is_null($this->intIdsalaryHead)))
				return array();

			try {
				return SalaryHead::LoadArrayByBasedSalaryHead($this->intIdsalaryHead, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated SalaryHeadsAsBased
		 * @return int
		*/
		public function CountSalaryHeadsAsBased() {
			if ((is_null($this->intIdsalaryHead)))
				return 0;

			return SalaryHead::CountByBasedSalaryHead($this->intIdsalaryHead);
		}

		/**
		 * Associates a SalaryHeadAsBased
		 * @param SalaryHead $objSalaryHead
		 * @return void
		*/
		public function AssociateSalaryHeadAsBased(SalaryHead $objSalaryHead) {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSalaryHeadAsBased on this unsaved SalaryHead.');
			if ((is_null($objSalaryHead->IdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateSalaryHeadAsBased on this SalaryHead with an unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salary_head`
				SET
					`based_salary_head` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
				WHERE
					`idsalary_head` = ' . $objDatabase->SqlVariable($objSalaryHead->IdsalaryHead) . '
			');
		}

		/**
		 * Unassociates a SalaryHeadAsBased
		 * @param SalaryHead $objSalaryHead
		 * @return void
		*/
		public function UnassociateSalaryHeadAsBased(SalaryHead $objSalaryHead) {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryHeadAsBased on this unsaved SalaryHead.');
			if ((is_null($objSalaryHead->IdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryHeadAsBased on this SalaryHead with an unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salary_head`
				SET
					`based_salary_head` = null
				WHERE
					`idsalary_head` = ' . $objDatabase->SqlVariable($objSalaryHead->IdsalaryHead) . ' AND
					`based_salary_head` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}

		/**
		 * Unassociates all SalaryHeadsAsBased
		 * @return void
		*/
		public function UnassociateAllSalaryHeadsAsBased() {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryHeadAsBased on this unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`salary_head`
				SET
					`based_salary_head` = null
				WHERE
					`based_salary_head` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}

		/**
		 * Deletes an associated SalaryHeadAsBased
		 * @param SalaryHead $objSalaryHead
		 * @return void
		*/
		public function DeleteAssociatedSalaryHeadAsBased(SalaryHead $objSalaryHead) {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryHeadAsBased on this unsaved SalaryHead.');
			if ((is_null($objSalaryHead->IdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryHeadAsBased on this SalaryHead with an unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salary_head`
				WHERE
					`idsalary_head` = ' . $objDatabase->SqlVariable($objSalaryHead->IdsalaryHead) . ' AND
					`based_salary_head` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}

		/**
		 * Deletes all associated SalaryHeadsAsBased
		 * @return void
		*/
		public function DeleteAllSalaryHeadsAsBased() {
			if ((is_null($this->intIdsalaryHead)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateSalaryHeadAsBased on this unsaved SalaryHead.');

			// Get the Database Object for this Class
			$objDatabase = SalaryHead::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salary_head`
				WHERE
					`based_salary_head` = ' . $objDatabase->SqlVariable($this->intIdsalaryHead) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "salary_head";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[SalaryHead::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="SalaryHead"><sequence>';
			$strToReturn .= '<element name="IdsalaryHead" type="xsd:int"/>';
			$strToReturn .= '<element name="SalaryTempletObject" type="xsd1:SalaryTemplet"/>';
			$strToReturn .= '<element name="SalaryHeadObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="CalculationGrpObject" type="xsd1:CalculationGrp"/>';
			$strToReturn .= '<element name="AppliedMonth" type="xsd:string"/>';
			$strToReturn .= '<element name="BasedSalaryHeadObject" type="xsd1:SalaryHead"/>';
			$strToReturn .= '<element name="Percentage" type="xsd:string"/>';
			$strToReturn .= '<element name="Amount" type="xsd:string"/>';
			$strToReturn .= '<element name="GeneratedAmount" type="xsd:string"/>';
			$strToReturn .= '<element name="ShowInSalary" type="xsd:boolean"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('SalaryHead', $strComplexTypeArray)) {
				$strComplexTypeArray['SalaryHead'] = SalaryHead::GetSoapComplexTypeXml();
				SalaryTemplet::AlterSoapComplexTypeArray($strComplexTypeArray);
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
				CalculationGrp::AlterSoapComplexTypeArray($strComplexTypeArray);
				SalaryHead::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, SalaryHead::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new SalaryHead();
			if (property_exists($objSoapObject, 'IdsalaryHead'))
				$objToReturn->intIdsalaryHead = $objSoapObject->IdsalaryHead;
			if ((property_exists($objSoapObject, 'SalaryTempletObject')) &&
				($objSoapObject->SalaryTempletObject))
				$objToReturn->SalaryTempletObject = SalaryTemplet::GetObjectFromSoapObject($objSoapObject->SalaryTempletObject);
			if ((property_exists($objSoapObject, 'SalaryHeadObject')) &&
				($objSoapObject->SalaryHeadObject))
				$objToReturn->SalaryHeadObject = Ledger::GetObjectFromSoapObject($objSoapObject->SalaryHeadObject);
			if ((property_exists($objSoapObject, 'CalculationGrpObject')) &&
				($objSoapObject->CalculationGrpObject))
				$objToReturn->CalculationGrpObject = CalculationGrp::GetObjectFromSoapObject($objSoapObject->CalculationGrpObject);
			if (property_exists($objSoapObject, 'AppliedMonth'))
				$objToReturn->strAppliedMonth = $objSoapObject->AppliedMonth;
			if ((property_exists($objSoapObject, 'BasedSalaryHeadObject')) &&
				($objSoapObject->BasedSalaryHeadObject))
				$objToReturn->BasedSalaryHeadObject = SalaryHead::GetObjectFromSoapObject($objSoapObject->BasedSalaryHeadObject);
			if (property_exists($objSoapObject, 'Percentage'))
				$objToReturn->strPercentage = $objSoapObject->Percentage;
			if (property_exists($objSoapObject, 'Amount'))
				$objToReturn->strAmount = $objSoapObject->Amount;
			if (property_exists($objSoapObject, 'GeneratedAmount'))
				$objToReturn->strGeneratedAmount = $objSoapObject->GeneratedAmount;
			if (property_exists($objSoapObject, 'ShowInSalary'))
				$objToReturn->blnShowInSalary = $objSoapObject->ShowInSalary;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, SalaryHead::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objSalaryTempletObject)
				$objObject->objSalaryTempletObject = SalaryTemplet::GetSoapObjectFromObject($objObject->objSalaryTempletObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSalaryTemplet = null;
			if ($objObject->objSalaryHeadObject)
				$objObject->objSalaryHeadObject = Ledger::GetSoapObjectFromObject($objObject->objSalaryHeadObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSalaryHead = null;
			if ($objObject->objCalculationGrpObject)
				$objObject->objCalculationGrpObject = CalculationGrp::GetSoapObjectFromObject($objObject->objCalculationGrpObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCalculationGrp = null;
			if ($objObject->objBasedSalaryHeadObject)
				$objObject->objBasedSalaryHeadObject = SalaryHead::GetSoapObjectFromObject($objObject->objBasedSalaryHeadObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intBasedSalaryHead = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdsalaryHead'] = $this->intIdsalaryHead;
			$iArray['SalaryTemplet'] = $this->intSalaryTemplet;
			$iArray['SalaryHead'] = $this->intSalaryHead;
			$iArray['CalculationGrp'] = $this->intCalculationGrp;
			$iArray['AppliedMonth'] = $this->strAppliedMonth;
			$iArray['BasedSalaryHead'] = $this->intBasedSalaryHead;
			$iArray['Percentage'] = $this->strPercentage;
			$iArray['Amount'] = $this->strAmount;
			$iArray['GeneratedAmount'] = $this->strGeneratedAmount;
			$iArray['ShowInSalary'] = $this->blnShowInSalary;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdsalaryHead ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdsalaryHead
     * @property-read QQNode $SalaryTemplet
     * @property-read QQNodeSalaryTemplet $SalaryTempletObject
     * @property-read QQNode $SalaryHead
     * @property-read QQNodeLedger $SalaryHeadObject
     * @property-read QQNode $CalculationGrp
     * @property-read QQNodeCalculationGrp $CalculationGrpObject
     * @property-read QQNode $AppliedMonth
     * @property-read QQNode $BasedSalaryHead
     * @property-read QQNodeSalaryHead $BasedSalaryHeadObject
     * @property-read QQNode $Percentage
     * @property-read QQNode $Amount
     * @property-read QQNode $GeneratedAmount
     * @property-read QQNode $ShowInSalary
     *
     *
     * @property-read QQReverseReferenceNodeCalculation $Calculation
     * @property-read QQReverseReferenceNodeCalculation $CalculationAs2
     * @property-read QQReverseReferenceNodeCalculation $CalculationAs1
     * @property-read QQReverseReferenceNodePaySlabs $PaySlabsAsSalaryhead
     * @property-read QQReverseReferenceNodeSalaryHead $SalaryHeadAsBased

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeSalaryHead extends QQNode {
		protected $strTableName = 'salary_head';
		protected $strPrimaryKey = 'idsalary_head';
		protected $strClassName = 'SalaryHead';
		public function __get($strName) {
			switch ($strName) {
				case 'IdsalaryHead':
					return new QQNode('idsalary_head', 'IdsalaryHead', 'Integer', $this);
				case 'SalaryTemplet':
					return new QQNode('salary_templet', 'SalaryTemplet', 'Integer', $this);
				case 'SalaryTempletObject':
					return new QQNodeSalaryTemplet('salary_templet', 'SalaryTempletObject', 'Integer', $this);
				case 'SalaryHead':
					return new QQNode('salary_head', 'SalaryHead', 'Integer', $this);
				case 'SalaryHeadObject':
					return new QQNodeLedger('salary_head', 'SalaryHeadObject', 'Integer', $this);
				case 'CalculationGrp':
					return new QQNode('calculation_grp', 'CalculationGrp', 'Integer', $this);
				case 'CalculationGrpObject':
					return new QQNodeCalculationGrp('calculation_grp', 'CalculationGrpObject', 'Integer', $this);
				case 'AppliedMonth':
					return new QQNode('applied_month', 'AppliedMonth', 'VarChar', $this);
				case 'BasedSalaryHead':
					return new QQNode('based_salary_head', 'BasedSalaryHead', 'Integer', $this);
				case 'BasedSalaryHeadObject':
					return new QQNodeSalaryHead('based_salary_head', 'BasedSalaryHeadObject', 'Integer', $this);
				case 'Percentage':
					return new QQNode('percentage', 'Percentage', 'VarChar', $this);
				case 'Amount':
					return new QQNode('amount', 'Amount', 'VarChar', $this);
				case 'GeneratedAmount':
					return new QQNode('generated_amount', 'GeneratedAmount', 'VarChar', $this);
				case 'ShowInSalary':
					return new QQNode('show_in_salary', 'ShowInSalary', 'Bit', $this);
				case 'Calculation':
					return new QQReverseReferenceNodeCalculation($this, 'calculation', 'reverse_reference', 'salary_head');
				case 'CalculationAs2':
					return new QQReverseReferenceNodeCalculation($this, 'calculationas2', 'reverse_reference', 'salary_head_2');
				case 'CalculationAs1':
					return new QQReverseReferenceNodeCalculation($this, 'calculationas1', 'reverse_reference', 'salary_head_1');
				case 'PaySlabsAsSalaryhead':
					return new QQReverseReferenceNodePaySlabs($this, 'payslabsassalaryhead', 'reverse_reference', 'salaryhead');
				case 'SalaryHeadAsBased':
					return new QQReverseReferenceNodeSalaryHead($this, 'salaryheadasbased', 'reverse_reference', 'based_salary_head');

				case '_PrimaryKeyNode':
					return new QQNode('idsalary_head', 'IdsalaryHead', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdsalaryHead
     * @property-read QQNode $SalaryTemplet
     * @property-read QQNodeSalaryTemplet $SalaryTempletObject
     * @property-read QQNode $SalaryHead
     * @property-read QQNodeLedger $SalaryHeadObject
     * @property-read QQNode $CalculationGrp
     * @property-read QQNodeCalculationGrp $CalculationGrpObject
     * @property-read QQNode $AppliedMonth
     * @property-read QQNode $BasedSalaryHead
     * @property-read QQNodeSalaryHead $BasedSalaryHeadObject
     * @property-read QQNode $Percentage
     * @property-read QQNode $Amount
     * @property-read QQNode $GeneratedAmount
     * @property-read QQNode $ShowInSalary
     *
     *
     * @property-read QQReverseReferenceNodeCalculation $Calculation
     * @property-read QQReverseReferenceNodeCalculation $CalculationAs2
     * @property-read QQReverseReferenceNodeCalculation $CalculationAs1
     * @property-read QQReverseReferenceNodePaySlabs $PaySlabsAsSalaryhead
     * @property-read QQReverseReferenceNodeSalaryHead $SalaryHeadAsBased

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeSalaryHead extends QQReverseReferenceNode {
		protected $strTableName = 'salary_head';
		protected $strPrimaryKey = 'idsalary_head';
		protected $strClassName = 'SalaryHead';
		public function __get($strName) {
			switch ($strName) {
				case 'IdsalaryHead':
					return new QQNode('idsalary_head', 'IdsalaryHead', 'integer', $this);
				case 'SalaryTemplet':
					return new QQNode('salary_templet', 'SalaryTemplet', 'integer', $this);
				case 'SalaryTempletObject':
					return new QQNodeSalaryTemplet('salary_templet', 'SalaryTempletObject', 'integer', $this);
				case 'SalaryHead':
					return new QQNode('salary_head', 'SalaryHead', 'integer', $this);
				case 'SalaryHeadObject':
					return new QQNodeLedger('salary_head', 'SalaryHeadObject', 'integer', $this);
				case 'CalculationGrp':
					return new QQNode('calculation_grp', 'CalculationGrp', 'integer', $this);
				case 'CalculationGrpObject':
					return new QQNodeCalculationGrp('calculation_grp', 'CalculationGrpObject', 'integer', $this);
				case 'AppliedMonth':
					return new QQNode('applied_month', 'AppliedMonth', 'string', $this);
				case 'BasedSalaryHead':
					return new QQNode('based_salary_head', 'BasedSalaryHead', 'integer', $this);
				case 'BasedSalaryHeadObject':
					return new QQNodeSalaryHead('based_salary_head', 'BasedSalaryHeadObject', 'integer', $this);
				case 'Percentage':
					return new QQNode('percentage', 'Percentage', 'string', $this);
				case 'Amount':
					return new QQNode('amount', 'Amount', 'string', $this);
				case 'GeneratedAmount':
					return new QQNode('generated_amount', 'GeneratedAmount', 'string', $this);
				case 'ShowInSalary':
					return new QQNode('show_in_salary', 'ShowInSalary', 'boolean', $this);
				case 'Calculation':
					return new QQReverseReferenceNodeCalculation($this, 'calculation', 'reverse_reference', 'salary_head');
				case 'CalculationAs2':
					return new QQReverseReferenceNodeCalculation($this, 'calculationas2', 'reverse_reference', 'salary_head_2');
				case 'CalculationAs1':
					return new QQReverseReferenceNodeCalculation($this, 'calculationas1', 'reverse_reference', 'salary_head_1');
				case 'PaySlabsAsSalaryhead':
					return new QQReverseReferenceNodePaySlabs($this, 'payslabsassalaryhead', 'reverse_reference', 'salaryhead');
				case 'SalaryHeadAsBased':
					return new QQReverseReferenceNodeSalaryHead($this, 'salaryheadasbased', 'reverse_reference', 'based_salary_head');

				case '_PrimaryKeyNode':
					return new QQNode('idsalary_head', 'IdsalaryHead', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
