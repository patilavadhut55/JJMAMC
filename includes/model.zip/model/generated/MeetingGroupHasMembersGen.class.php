<?php
	/**
	 * The abstract MeetingGroupHasMembersGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the MeetingGroupHasMembers subclass which
	 * extends this MeetingGroupHasMembersGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the MeetingGroupHasMembers class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdmeetingGroupHasMembers the value for intIdmeetingGroupHasMembers (Read-Only PK)
	 * @property integer $MeetingGroup the value for intMeetingGroup 
	 * @property integer $Member the value for intMember 
	 * @property MeetingMemberGroup $MeetingGroupObject the value for the MeetingMemberGroup object referenced by intMeetingGroup 
	 * @property Login $MemberObject the value for the Login object referenced by intMember 
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class MeetingGroupHasMembersGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column meeting_group_has_members.idmeeting_group_has_members
		 * @var integer intIdmeetingGroupHasMembers
		 */
		protected $intIdmeetingGroupHasMembers;
		const IdmeetingGroupHasMembersDefault = null;


		/**
		 * Protected member variable that maps to the database column meeting_group_has_members.meeting_group
		 * @var integer intMeetingGroup
		 */
		protected $intMeetingGroup;
		const MeetingGroupDefault = null;


		/**
		 * Protected member variable that maps to the database column meeting_group_has_members.member
		 * @var integer intMember
		 */
		protected $intMember;
		const MemberDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column meeting_group_has_members.meeting_group.
		 *
		 * NOTE: Always use the MeetingGroupObject property getter to correctly retrieve this MeetingMemberGroup object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var MeetingMemberGroup objMeetingGroupObject
		 */
		protected $objMeetingGroupObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column meeting_group_has_members.member.
		 *
		 * NOTE: Always use the MemberObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objMemberObject
		 */
		protected $objMemberObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdmeetingGroupHasMembers = MeetingGroupHasMembers::IdmeetingGroupHasMembersDefault;
			$this->intMeetingGroup = MeetingGroupHasMembers::MeetingGroupDefault;
			$this->intMember = MeetingGroupHasMembers::MemberDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a MeetingGroupHasMembers from PK Info
		 * @param integer $intIdmeetingGroupHasMembers
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingGroupHasMembers
		 */
		public static function Load($intIdmeetingGroupHasMembers, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'MeetingGroupHasMembers', $intIdmeetingGroupHasMembers);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = MeetingGroupHasMembers::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::MeetingGroupHasMembers()->IdmeetingGroupHasMembers, $intIdmeetingGroupHasMembers)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all MeetingGroupHasMemberses
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingGroupHasMembers[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call MeetingGroupHasMembers::QueryArray to perform the LoadAll query
			try {
				return MeetingGroupHasMembers::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all MeetingGroupHasMemberses
		 * @return int
		 */
		public static function CountAll() {
			// Call MeetingGroupHasMembers::QueryCount to perform the CountAll query
			return MeetingGroupHasMembers::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = MeetingGroupHasMembers::GetDatabase();

			// Create/Build out the QueryBuilder object with MeetingGroupHasMembers-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'meeting_group_has_members');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				MeetingGroupHasMembers::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('meeting_group_has_members');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single MeetingGroupHasMembers object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return MeetingGroupHasMembers the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = MeetingGroupHasMembers::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new MeetingGroupHasMembers object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = MeetingGroupHasMembers::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return MeetingGroupHasMembers::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of MeetingGroupHasMembers objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return MeetingGroupHasMembers[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = MeetingGroupHasMembers::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return MeetingGroupHasMembers::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = MeetingGroupHasMembers::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of MeetingGroupHasMembers objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = MeetingGroupHasMembers::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = MeetingGroupHasMembers::GetDatabase();

			$strQuery = MeetingGroupHasMembers::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/meetinggrouphasmembers', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = MeetingGroupHasMembers::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this MeetingGroupHasMembers
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'meeting_group_has_members';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idmeeting_group_has_members', $strAliasPrefix . 'idmeeting_group_has_members');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idmeeting_group_has_members', $strAliasPrefix . 'idmeeting_group_has_members');
			    $objBuilder->AddSelectItem($strTableName, 'meeting_group', $strAliasPrefix . 'meeting_group');
			    $objBuilder->AddSelectItem($strTableName, 'member', $strAliasPrefix . 'member');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a MeetingGroupHasMembers from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this MeetingGroupHasMembers::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return MeetingGroupHasMembers
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the MeetingGroupHasMembers object
			$objToReturn = new MeetingGroupHasMembers();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idmeeting_group_has_members';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdmeetingGroupHasMembers = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'meeting_group';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMeetingGroup = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'member';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMember = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdmeetingGroupHasMembers != $objPreviousItem->IdmeetingGroupHasMembers) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'meeting_group_has_members__';

			// Check for MeetingGroupObject Early Binding
			$strAlias = $strAliasPrefix . 'meeting_group__idmeeting_member_group';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objMeetingGroupObject = MeetingMemberGroup::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meeting_group__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for MemberObject Early Binding
			$strAlias = $strAliasPrefix . 'member__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objMemberObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'member__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of MeetingGroupHasMemberses from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return MeetingGroupHasMembers[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = MeetingGroupHasMembers::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = MeetingGroupHasMembers::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single MeetingGroupHasMembers object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return MeetingGroupHasMembers next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return MeetingGroupHasMembers::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single MeetingGroupHasMembers object,
		 * by IdmeetingGroupHasMembers Index(es)
		 * @param integer $intIdmeetingGroupHasMembers
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingGroupHasMembers
		*/
		public static function LoadByIdmeetingGroupHasMembers($intIdmeetingGroupHasMembers, $objOptionalClauses = null) {
			return MeetingGroupHasMembers::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::MeetingGroupHasMembers()->IdmeetingGroupHasMembers, $intIdmeetingGroupHasMembers)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of MeetingGroupHasMembers objects,
		 * by MeetingGroup Index(es)
		 * @param integer $intMeetingGroup
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingGroupHasMembers[]
		*/
		public static function LoadArrayByMeetingGroup($intMeetingGroup, $objOptionalClauses = null) {
			// Call MeetingGroupHasMembers::QueryArray to perform the LoadArrayByMeetingGroup query
			try {
				return MeetingGroupHasMembers::QueryArray(
					QQ::Equal(QQN::MeetingGroupHasMembers()->MeetingGroup, $intMeetingGroup),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count MeetingGroupHasMemberses
		 * by MeetingGroup Index(es)
		 * @param integer $intMeetingGroup
		 * @return int
		*/
		public static function CountByMeetingGroup($intMeetingGroup) {
			// Call MeetingGroupHasMembers::QueryCount to perform the CountByMeetingGroup query
			return MeetingGroupHasMembers::QueryCount(
				QQ::Equal(QQN::MeetingGroupHasMembers()->MeetingGroup, $intMeetingGroup)
			);
		}

		/**
		 * Load an array of MeetingGroupHasMembers objects,
		 * by Member Index(es)
		 * @param integer $intMember
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingGroupHasMembers[]
		*/
		public static function LoadArrayByMember($intMember, $objOptionalClauses = null) {
			// Call MeetingGroupHasMembers::QueryArray to perform the LoadArrayByMember query
			try {
				return MeetingGroupHasMembers::QueryArray(
					QQ::Equal(QQN::MeetingGroupHasMembers()->Member, $intMember),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count MeetingGroupHasMemberses
		 * by Member Index(es)
		 * @param integer $intMember
		 * @return int
		*/
		public static function CountByMember($intMember) {
			// Call MeetingGroupHasMembers::QueryCount to perform the CountByMember query
			return MeetingGroupHasMembers::QueryCount(
				QQ::Equal(QQN::MeetingGroupHasMembers()->Member, $intMember)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this MeetingGroupHasMembers
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = MeetingGroupHasMembers::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `meeting_group_has_members` (
							`meeting_group`,
							`member`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intMeetingGroup) . ',
							' . $objDatabase->SqlVariable($this->intMember) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdmeetingGroupHasMembers = $objDatabase->InsertId('meeting_group_has_members', 'idmeeting_group_has_members');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`meeting_group_has_members`
						SET
							`meeting_group` = ' . $objDatabase->SqlVariable($this->intMeetingGroup) . ',
							`member` = ' . $objDatabase->SqlVariable($this->intMember) . '
						WHERE
							`idmeeting_group_has_members` = ' . $objDatabase->SqlVariable($this->intIdmeetingGroupHasMembers) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this MeetingGroupHasMembers
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdmeetingGroupHasMembers)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this MeetingGroupHasMembers with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = MeetingGroupHasMembers::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_group_has_members`
				WHERE
					`idmeeting_group_has_members` = ' . $objDatabase->SqlVariable($this->intIdmeetingGroupHasMembers) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this MeetingGroupHasMembers ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'MeetingGroupHasMembers', $this->intIdmeetingGroupHasMembers);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all MeetingGroupHasMemberses
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = MeetingGroupHasMembers::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_group_has_members`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate meeting_group_has_members table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = MeetingGroupHasMembers::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `meeting_group_has_members`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this MeetingGroupHasMembers from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved MeetingGroupHasMembers object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = MeetingGroupHasMembers::Load($this->intIdmeetingGroupHasMembers);

			// Update $this's local variables to match
			$this->MeetingGroup = $objReloaded->MeetingGroup;
			$this->Member = $objReloaded->Member;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdmeetingGroupHasMembers':
					/**
					 * Gets the value for intIdmeetingGroupHasMembers (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdmeetingGroupHasMembers;

				case 'MeetingGroup':
					/**
					 * Gets the value for intMeetingGroup 
					 * @return integer
					 */
					return $this->intMeetingGroup;

				case 'Member':
					/**
					 * Gets the value for intMember 
					 * @return integer
					 */
					return $this->intMember;


				///////////////////
				// Member Objects
				///////////////////
				case 'MeetingGroupObject':
					/**
					 * Gets the value for the MeetingMemberGroup object referenced by intMeetingGroup 
					 * @return MeetingMemberGroup
					 */
					try {
						if ((!$this->objMeetingGroupObject) && (!is_null($this->intMeetingGroup)))
							$this->objMeetingGroupObject = MeetingMemberGroup::Load($this->intMeetingGroup);
						return $this->objMeetingGroupObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'MemberObject':
					/**
					 * Gets the value for the Login object referenced by intMember 
					 * @return Login
					 */
					try {
						if ((!$this->objMemberObject) && (!is_null($this->intMember)))
							$this->objMemberObject = Login::Load($this->intMember);
						return $this->objMemberObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'MeetingGroup':
					/**
					 * Sets the value for intMeetingGroup 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objMeetingGroupObject = null;
						return ($this->intMeetingGroup = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Member':
					/**
					 * Sets the value for intMember 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objMemberObject = null;
						return ($this->intMember = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'MeetingGroupObject':
					/**
					 * Sets the value for the MeetingMemberGroup object referenced by intMeetingGroup 
					 * @param MeetingMemberGroup $mixValue
					 * @return MeetingMemberGroup
					 */
					if (is_null($mixValue)) {
						$this->intMeetingGroup = null;
						$this->objMeetingGroupObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a MeetingMemberGroup object
						try {
							$mixValue = QType::Cast($mixValue, 'MeetingMemberGroup');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED MeetingMemberGroup object
						if (is_null($mixValue->IdmeetingMemberGroup))
							throw new QCallerException('Unable to set an unsaved MeetingGroupObject for this MeetingGroupHasMembers');

						// Update Local Member Variables
						$this->objMeetingGroupObject = $mixValue;
						$this->intMeetingGroup = $mixValue->IdmeetingMemberGroup;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'MemberObject':
					/**
					 * Sets the value for the Login object referenced by intMember 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intMember = null;
						$this->objMemberObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved MemberObject for this MeetingGroupHasMembers');

						// Update Local Member Variables
						$this->objMemberObject = $mixValue;
						$this->intMember = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "meeting_group_has_members";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[MeetingGroupHasMembers::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="MeetingGroupHasMembers"><sequence>';
			$strToReturn .= '<element name="IdmeetingGroupHasMembers" type="xsd:int"/>';
			$strToReturn .= '<element name="MeetingGroupObject" type="xsd1:MeetingMemberGroup"/>';
			$strToReturn .= '<element name="MemberObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('MeetingGroupHasMembers', $strComplexTypeArray)) {
				$strComplexTypeArray['MeetingGroupHasMembers'] = MeetingGroupHasMembers::GetSoapComplexTypeXml();
				MeetingMemberGroup::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, MeetingGroupHasMembers::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new MeetingGroupHasMembers();
			if (property_exists($objSoapObject, 'IdmeetingGroupHasMembers'))
				$objToReturn->intIdmeetingGroupHasMembers = $objSoapObject->IdmeetingGroupHasMembers;
			if ((property_exists($objSoapObject, 'MeetingGroupObject')) &&
				($objSoapObject->MeetingGroupObject))
				$objToReturn->MeetingGroupObject = MeetingMemberGroup::GetObjectFromSoapObject($objSoapObject->MeetingGroupObject);
			if ((property_exists($objSoapObject, 'MemberObject')) &&
				($objSoapObject->MemberObject))
				$objToReturn->MemberObject = Login::GetObjectFromSoapObject($objSoapObject->MemberObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, MeetingGroupHasMembers::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objMeetingGroupObject)
				$objObject->objMeetingGroupObject = MeetingMemberGroup::GetSoapObjectFromObject($objObject->objMeetingGroupObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intMeetingGroup = null;
			if ($objObject->objMemberObject)
				$objObject->objMemberObject = Login::GetSoapObjectFromObject($objObject->objMemberObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intMember = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdmeetingGroupHasMembers'] = $this->intIdmeetingGroupHasMembers;
			$iArray['MeetingGroup'] = $this->intMeetingGroup;
			$iArray['Member'] = $this->intMember;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdmeetingGroupHasMembers ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdmeetingGroupHasMembers
     * @property-read QQNode $MeetingGroup
     * @property-read QQNodeMeetingMemberGroup $MeetingGroupObject
     * @property-read QQNode $Member
     * @property-read QQNodeLogin $MemberObject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeMeetingGroupHasMembers extends QQNode {
		protected $strTableName = 'meeting_group_has_members';
		protected $strPrimaryKey = 'idmeeting_group_has_members';
		protected $strClassName = 'MeetingGroupHasMembers';
		public function __get($strName) {
			switch ($strName) {
				case 'IdmeetingGroupHasMembers':
					return new QQNode('idmeeting_group_has_members', 'IdmeetingGroupHasMembers', 'Integer', $this);
				case 'MeetingGroup':
					return new QQNode('meeting_group', 'MeetingGroup', 'Integer', $this);
				case 'MeetingGroupObject':
					return new QQNodeMeetingMemberGroup('meeting_group', 'MeetingGroupObject', 'Integer', $this);
				case 'Member':
					return new QQNode('member', 'Member', 'Integer', $this);
				case 'MemberObject':
					return new QQNodeLogin('member', 'MemberObject', 'Integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idmeeting_group_has_members', 'IdmeetingGroupHasMembers', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdmeetingGroupHasMembers
     * @property-read QQNode $MeetingGroup
     * @property-read QQNodeMeetingMemberGroup $MeetingGroupObject
     * @property-read QQNode $Member
     * @property-read QQNodeLogin $MemberObject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeMeetingGroupHasMembers extends QQReverseReferenceNode {
		protected $strTableName = 'meeting_group_has_members';
		protected $strPrimaryKey = 'idmeeting_group_has_members';
		protected $strClassName = 'MeetingGroupHasMembers';
		public function __get($strName) {
			switch ($strName) {
				case 'IdmeetingGroupHasMembers':
					return new QQNode('idmeeting_group_has_members', 'IdmeetingGroupHasMembers', 'integer', $this);
				case 'MeetingGroup':
					return new QQNode('meeting_group', 'MeetingGroup', 'integer', $this);
				case 'MeetingGroupObject':
					return new QQNodeMeetingMemberGroup('meeting_group', 'MeetingGroupObject', 'integer', $this);
				case 'Member':
					return new QQNode('member', 'Member', 'integer', $this);
				case 'MemberObject':
					return new QQNodeLogin('member', 'MemberObject', 'integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idmeeting_group_has_members', 'IdmeetingGroupHasMembers', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
