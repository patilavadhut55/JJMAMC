<?php
	/**
	 * The abstract ArticleGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Article subclass which
	 * extends this ArticleGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Article class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idarticle the value for intIdarticle (Read-Only PK)
	 * @property string $Code the value for strCode (Unique)
	 * @property integer $Grp the value for intGrp (Not Null)
	 * @property string $Title the value for strTitle (Not Null)
	 * @property string $Intro the value for strIntro (Not Null)
	 * @property string $Data the value for strData (Not Null)
	 * @property integer $Css the value for intCss 
	 * @property integer $Class the value for intClass 
	 * @property string $VideoUrl the value for strVideoUrl 
	 * @property ArticleGrp $GrpObject the value for the ArticleGrp object referenced by intGrp (Not Null)
	 * @property Css $CssObject the value for the Css object referenced by intCss 
	 * @property Css $ClassObject the value for the Css object referenced by intClass 
	 * @property-read MenuHasArticle $_MenuHasArticleAsId the value for the private _objMenuHasArticleAsId (Read-Only) if set due to an expansion on the menu_has_article.article_idarticle reverse relationship
	 * @property-read MenuHasArticle[] $_MenuHasArticleAsIdArray the value for the private _objMenuHasArticleAsIdArray (Read-Only) if set due to an ExpandAsArray on the menu_has_article.article_idarticle reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class ArticleGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column article.idarticle
		 * @var integer intIdarticle
		 */
		protected $intIdarticle;
		const IdarticleDefault = null;


		/**
		 * Protected member variable that maps to the database column article.code
		 * @var string strCode
		 */
		protected $strCode;
		const CodeMaxLength = 45;
		const CodeDefault = null;


		/**
		 * Protected member variable that maps to the database column article.grp
		 * @var integer intGrp
		 */
		protected $intGrp;
		const GrpDefault = null;


		/**
		 * Protected member variable that maps to the database column article.title
		 * @var string strTitle
		 */
		protected $strTitle;
		const TitleMaxLength = 200;
		const TitleDefault = null;


		/**
		 * Protected member variable that maps to the database column article.intro
		 * @var string strIntro
		 */
		protected $strIntro;
		const IntroDefault = null;


		/**
		 * Protected member variable that maps to the database column article.data
		 * @var string strData
		 */
		protected $strData;
		const DataDefault = null;


		/**
		 * Protected member variable that maps to the database column article.css
		 * @var integer intCss
		 */
		protected $intCss;
		const CssDefault = null;


		/**
		 * Protected member variable that maps to the database column article.class
		 * @var integer intClass
		 */
		protected $intClass;
		const ClassDefault = null;


		/**
		 * Protected member variable that maps to the database column article.video_url
		 * @var string strVideoUrl
		 */
		protected $strVideoUrl;
		const VideoUrlDefault = null;


		/**
		 * Private member variable that stores a reference to a single MenuHasArticleAsId object
		 * (of type MenuHasArticle), if this Article object was restored with
		 * an expansion on the menu_has_article association table.
		 * @var MenuHasArticle _objMenuHasArticleAsId;
		 */
		private $_objMenuHasArticleAsId;

		/**
		 * Private member variable that stores a reference to an array of MenuHasArticleAsId objects
		 * (of type MenuHasArticle[]), if this Article object was restored with
		 * an ExpandAsArray on the menu_has_article association table.
		 * @var MenuHasArticle[] _objMenuHasArticleAsIdArray;
		 */
		private $_objMenuHasArticleAsIdArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column article.grp.
		 *
		 * NOTE: Always use the GrpObject property getter to correctly retrieve this ArticleGrp object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var ArticleGrp objGrpObject
		 */
		protected $objGrpObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column article.css.
		 *
		 * NOTE: Always use the CssObject property getter to correctly retrieve this Css object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Css objCssObject
		 */
		protected $objCssObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column article.class.
		 *
		 * NOTE: Always use the ClassObject property getter to correctly retrieve this Css object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Css objClassObject
		 */
		protected $objClassObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdarticle = Article::IdarticleDefault;
			$this->strCode = Article::CodeDefault;
			$this->intGrp = Article::GrpDefault;
			$this->strTitle = Article::TitleDefault;
			$this->strIntro = Article::IntroDefault;
			$this->strData = Article::DataDefault;
			$this->intCss = Article::CssDefault;
			$this->intClass = Article::ClassDefault;
			$this->strVideoUrl = Article::VideoUrlDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Article from PK Info
		 * @param integer $intIdarticle
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Article
		 */
		public static function Load($intIdarticle, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Article', $intIdarticle);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Article::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Article()->Idarticle, $intIdarticle)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Articles
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Article[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Article::QueryArray to perform the LoadAll query
			try {
				return Article::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Articles
		 * @return int
		 */
		public static function CountAll() {
			// Call Article::QueryCount to perform the CountAll query
			return Article::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Article::GetDatabase();

			// Create/Build out the QueryBuilder object with Article-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'article');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Article::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('article');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Article object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Article the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Article::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Article object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Article::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Article::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Article objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Article[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Article::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Article::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Article::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Article objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Article::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Article::GetDatabase();

			$strQuery = Article::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/article', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Article::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Article
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'article';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idarticle', $strAliasPrefix . 'idarticle');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idarticle', $strAliasPrefix . 'idarticle');
			    $objBuilder->AddSelectItem($strTableName, 'code', $strAliasPrefix . 'code');
			    $objBuilder->AddSelectItem($strTableName, 'grp', $strAliasPrefix . 'grp');
			    $objBuilder->AddSelectItem($strTableName, 'title', $strAliasPrefix . 'title');
			    $objBuilder->AddSelectItem($strTableName, 'intro', $strAliasPrefix . 'intro');
			    $objBuilder->AddSelectItem($strTableName, 'data', $strAliasPrefix . 'data');
			    $objBuilder->AddSelectItem($strTableName, 'css', $strAliasPrefix . 'css');
			    $objBuilder->AddSelectItem($strTableName, 'class', $strAliasPrefix . 'class');
			    $objBuilder->AddSelectItem($strTableName, 'video_url', $strAliasPrefix . 'video_url');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Article from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Article::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Article
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idarticle';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdarticle == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'article__';


						// Expanding reverse references: MenuHasArticleAsId
						$strAlias = $strAliasPrefix . 'menuhasarticleasid__menu_idmenu';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objMenuHasArticleAsIdArray)
								$objPreviousItem->_objMenuHasArticleAsIdArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objMenuHasArticleAsIdArray)) {
								$objPreviousChildItems = $objPreviousItem->_objMenuHasArticleAsIdArray;
								$objChildItem = MenuHasArticle::InstantiateDbRow($objDbRow, $strAliasPrefix . 'menuhasarticleasid__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objMenuHasArticleAsIdArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objMenuHasArticleAsIdArray[] = MenuHasArticle::InstantiateDbRow($objDbRow, $strAliasPrefix . 'menuhasarticleasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'article__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Article object
			$objToReturn = new Article();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idarticle';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdarticle = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intGrp = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'title';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTitle = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'intro';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strIntro = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'data';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strData = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'css';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCss = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'class';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intClass = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'video_url';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strVideoUrl = $objDbRow->GetColumn($strAliasName, 'Blob');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idarticle != $objPreviousItem->Idarticle) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objMenuHasArticleAsIdArray);
					$cnt = count($objToReturn->_objMenuHasArticleAsIdArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objMenuHasArticleAsIdArray, $objToReturn->_objMenuHasArticleAsIdArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'article__';

			// Check for GrpObject Early Binding
			$strAlias = $strAliasPrefix . 'grp__idarticle_grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objGrpObject = ArticleGrp::InstantiateDbRow($objDbRow, $strAliasPrefix . 'grp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CssObject Early Binding
			$strAlias = $strAliasPrefix . 'css__idcss';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCssObject = Css::InstantiateDbRow($objDbRow, $strAliasPrefix . 'css__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ClassObject Early Binding
			$strAlias = $strAliasPrefix . 'class__idcss';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objClassObject = Css::InstantiateDbRow($objDbRow, $strAliasPrefix . 'class__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for MenuHasArticleAsId Virtual Binding
			$strAlias = $strAliasPrefix . 'menuhasarticleasid__menu_idmenu';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objMenuHasArticleAsIdArray)
				$objToReturn->_objMenuHasArticleAsIdArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objMenuHasArticleAsIdArray[] = MenuHasArticle::InstantiateDbRow($objDbRow, $strAliasPrefix . 'menuhasarticleasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objMenuHasArticleAsId = MenuHasArticle::InstantiateDbRow($objDbRow, $strAliasPrefix . 'menuhasarticleasid__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Articles from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Article[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Article::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Article::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Article object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Article next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Article::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Article object,
		 * by Idarticle Index(es)
		 * @param integer $intIdarticle
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Article
		*/
		public static function LoadByIdarticle($intIdarticle, $objOptionalClauses = null) {
			return Article::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Article()->Idarticle, $intIdarticle)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single Article object,
		 * by Code Index(es)
		 * @param string $strCode
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Article
		*/
		public static function LoadByCode($strCode, $objOptionalClauses = null) {
			return Article::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Article()->Code, $strCode)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Article objects,
		 * by Grp Index(es)
		 * @param integer $intGrp
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Article[]
		*/
		public static function LoadArrayByGrp($intGrp, $objOptionalClauses = null) {
			// Call Article::QueryArray to perform the LoadArrayByGrp query
			try {
				return Article::QueryArray(
					QQ::Equal(QQN::Article()->Grp, $intGrp),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Articles
		 * by Grp Index(es)
		 * @param integer $intGrp
		 * @return int
		*/
		public static function CountByGrp($intGrp) {
			// Call Article::QueryCount to perform the CountByGrp query
			return Article::QueryCount(
				QQ::Equal(QQN::Article()->Grp, $intGrp)
			);
		}

		/**
		 * Load an array of Article objects,
		 * by Css Index(es)
		 * @param integer $intCss
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Article[]
		*/
		public static function LoadArrayByCss($intCss, $objOptionalClauses = null) {
			// Call Article::QueryArray to perform the LoadArrayByCss query
			try {
				return Article::QueryArray(
					QQ::Equal(QQN::Article()->Css, $intCss),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Articles
		 * by Css Index(es)
		 * @param integer $intCss
		 * @return int
		*/
		public static function CountByCss($intCss) {
			// Call Article::QueryCount to perform the CountByCss query
			return Article::QueryCount(
				QQ::Equal(QQN::Article()->Css, $intCss)
			);
		}

		/**
		 * Load an array of Article objects,
		 * by Class Index(es)
		 * @param integer $intClass
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Article[]
		*/
		public static function LoadArrayByClass($intClass, $objOptionalClauses = null) {
			// Call Article::QueryArray to perform the LoadArrayByClass query
			try {
				return Article::QueryArray(
					QQ::Equal(QQN::Article()->Class, $intClass),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Articles
		 * by Class Index(es)
		 * @param integer $intClass
		 * @return int
		*/
		public static function CountByClass($intClass) {
			// Call Article::QueryCount to perform the CountByClass query
			return Article::QueryCount(
				QQ::Equal(QQN::Article()->Class, $intClass)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Article
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Article::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `article` (
							`code`,
							`grp`,
							`title`,
							`intro`,
							`data`,
							`css`,
							`class`,
							`video_url`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strCode) . ',
							' . $objDatabase->SqlVariable($this->intGrp) . ',
							' . $objDatabase->SqlVariable($this->strTitle) . ',
							' . $objDatabase->SqlVariable($this->strIntro) . ',
							' . $objDatabase->SqlVariable($this->strData) . ',
							' . $objDatabase->SqlVariable($this->intCss) . ',
							' . $objDatabase->SqlVariable($this->intClass) . ',
							' . $objDatabase->SqlVariable($this->strVideoUrl) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdarticle = $objDatabase->InsertId('article', 'idarticle');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`article`
						SET
							`code` = ' . $objDatabase->SqlVariable($this->strCode) . ',
							`grp` = ' . $objDatabase->SqlVariable($this->intGrp) . ',
							`title` = ' . $objDatabase->SqlVariable($this->strTitle) . ',
							`intro` = ' . $objDatabase->SqlVariable($this->strIntro) . ',
							`data` = ' . $objDatabase->SqlVariable($this->strData) . ',
							`css` = ' . $objDatabase->SqlVariable($this->intCss) . ',
							`class` = ' . $objDatabase->SqlVariable($this->intClass) . ',
							`video_url` = ' . $objDatabase->SqlVariable($this->strVideoUrl) . '
						WHERE
							`idarticle` = ' . $objDatabase->SqlVariable($this->intIdarticle) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Article
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdarticle)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Article with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Article::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`article`
				WHERE
					`idarticle` = ' . $objDatabase->SqlVariable($this->intIdarticle) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Article ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Article', $this->intIdarticle);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Articles
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Article::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`article`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate article table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Article::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `article`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Article from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Article object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Article::Load($this->intIdarticle);

			// Update $this's local variables to match
			$this->strCode = $objReloaded->strCode;
			$this->Grp = $objReloaded->Grp;
			$this->strTitle = $objReloaded->strTitle;
			$this->strIntro = $objReloaded->strIntro;
			$this->strData = $objReloaded->strData;
			$this->Css = $objReloaded->Css;
			$this->Class = $objReloaded->Class;
			$this->strVideoUrl = $objReloaded->strVideoUrl;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idarticle':
					/**
					 * Gets the value for intIdarticle (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdarticle;

				case 'Code':
					/**
					 * Gets the value for strCode (Unique)
					 * @return string
					 */
					return $this->strCode;

				case 'Grp':
					/**
					 * Gets the value for intGrp (Not Null)
					 * @return integer
					 */
					return $this->intGrp;

				case 'Title':
					/**
					 * Gets the value for strTitle (Not Null)
					 * @return string
					 */
					return $this->strTitle;

				case 'Intro':
					/**
					 * Gets the value for strIntro (Not Null)
					 * @return string
					 */
					return $this->strIntro;

				case 'Data':
					/**
					 * Gets the value for strData (Not Null)
					 * @return string
					 */
					return $this->strData;

				case 'Css':
					/**
					 * Gets the value for intCss 
					 * @return integer
					 */
					return $this->intCss;

				case 'Class':
					/**
					 * Gets the value for intClass 
					 * @return integer
					 */
					return $this->intClass;

				case 'VideoUrl':
					/**
					 * Gets the value for strVideoUrl 
					 * @return string
					 */
					return $this->strVideoUrl;


				///////////////////
				// Member Objects
				///////////////////
				case 'GrpObject':
					/**
					 * Gets the value for the ArticleGrp object referenced by intGrp (Not Null)
					 * @return ArticleGrp
					 */
					try {
						if ((!$this->objGrpObject) && (!is_null($this->intGrp)))
							$this->objGrpObject = ArticleGrp::Load($this->intGrp);
						return $this->objGrpObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CssObject':
					/**
					 * Gets the value for the Css object referenced by intCss 
					 * @return Css
					 */
					try {
						if ((!$this->objCssObject) && (!is_null($this->intCss)))
							$this->objCssObject = Css::Load($this->intCss);
						return $this->objCssObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ClassObject':
					/**
					 * Gets the value for the Css object referenced by intClass 
					 * @return Css
					 */
					try {
						if ((!$this->objClassObject) && (!is_null($this->intClass)))
							$this->objClassObject = Css::Load($this->intClass);
						return $this->objClassObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_MenuHasArticleAsId':
					/**
					 * Gets the value for the private _objMenuHasArticleAsId (Read-Only)
					 * if set due to an expansion on the menu_has_article.article_idarticle reverse relationship
					 * @return MenuHasArticle
					 */
					return $this->_objMenuHasArticleAsId;

				case '_MenuHasArticleAsIdArray':
					/**
					 * Gets the value for the private _objMenuHasArticleAsIdArray (Read-Only)
					 * if set due to an ExpandAsArray on the menu_has_article.article_idarticle reverse relationship
					 * @return MenuHasArticle[]
					 */
					return $this->_objMenuHasArticleAsIdArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Code':
					/**
					 * Sets the value for strCode (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Grp':
					/**
					 * Sets the value for intGrp (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objGrpObject = null;
						return ($this->intGrp = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Title':
					/**
					 * Sets the value for strTitle (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTitle = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Intro':
					/**
					 * Sets the value for strIntro (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strIntro = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Data':
					/**
					 * Sets the value for strData (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strData = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Css':
					/**
					 * Sets the value for intCss 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCssObject = null;
						return ($this->intCss = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Class':
					/**
					 * Sets the value for intClass 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objClassObject = null;
						return ($this->intClass = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'VideoUrl':
					/**
					 * Sets the value for strVideoUrl 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strVideoUrl = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'GrpObject':
					/**
					 * Sets the value for the ArticleGrp object referenced by intGrp (Not Null)
					 * @param ArticleGrp $mixValue
					 * @return ArticleGrp
					 */
					if (is_null($mixValue)) {
						$this->intGrp = null;
						$this->objGrpObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a ArticleGrp object
						try {
							$mixValue = QType::Cast($mixValue, 'ArticleGrp');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED ArticleGrp object
						if (is_null($mixValue->IdarticleGrp))
							throw new QCallerException('Unable to set an unsaved GrpObject for this Article');

						// Update Local Member Variables
						$this->objGrpObject = $mixValue;
						$this->intGrp = $mixValue->IdarticleGrp;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CssObject':
					/**
					 * Sets the value for the Css object referenced by intCss 
					 * @param Css $mixValue
					 * @return Css
					 */
					if (is_null($mixValue)) {
						$this->intCss = null;
						$this->objCssObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Css object
						try {
							$mixValue = QType::Cast($mixValue, 'Css');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Css object
						if (is_null($mixValue->Idcss))
							throw new QCallerException('Unable to set an unsaved CssObject for this Article');

						// Update Local Member Variables
						$this->objCssObject = $mixValue;
						$this->intCss = $mixValue->Idcss;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ClassObject':
					/**
					 * Sets the value for the Css object referenced by intClass 
					 * @param Css $mixValue
					 * @return Css
					 */
					if (is_null($mixValue)) {
						$this->intClass = null;
						$this->objClassObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Css object
						try {
							$mixValue = QType::Cast($mixValue, 'Css');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Css object
						if (is_null($mixValue->Idcss))
							throw new QCallerException('Unable to set an unsaved ClassObject for this Article');

						// Update Local Member Variables
						$this->objClassObject = $mixValue;
						$this->intClass = $mixValue->Idcss;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for MenuHasArticleAsId
		//-------------------------------------------------------------------

		/**
		 * Gets all associated MenuHasArticlesAsId as an array of MenuHasArticle objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MenuHasArticle[]
		*/
		public function GetMenuHasArticleAsIdArray($objOptionalClauses = null) {
			if ((is_null($this->intIdarticle)))
				return array();

			try {
				return MenuHasArticle::LoadArrayByArticleIdarticle($this->intIdarticle, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated MenuHasArticlesAsId
		 * @return int
		*/
		public function CountMenuHasArticlesAsId() {
			if ((is_null($this->intIdarticle)))
				return 0;

			return MenuHasArticle::CountByArticleIdarticle($this->intIdarticle);
		}

		/**
		 * Associates a MenuHasArticleAsId
		 * @param MenuHasArticle $objMenuHasArticle
		 * @return void
		*/
		public function AssociateMenuHasArticleAsId(MenuHasArticle $objMenuHasArticle) {
			if ((is_null($this->intIdarticle)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMenuHasArticleAsId on this unsaved Article.');
			if ((is_null($objMenuHasArticle->MenuIdmenu)) || (is_null($objMenuHasArticle->ArticleIdarticle)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMenuHasArticleAsId on this Article with an unsaved MenuHasArticle.');

			// Get the Database Object for this Class
			$objDatabase = Article::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`menu_has_article`
				SET
					`article_idarticle` = ' . $objDatabase->SqlVariable($this->intIdarticle) . '
				WHERE
					`menu_idmenu` = ' . $objDatabase->SqlVariable($objMenuHasArticle->MenuIdmenu) . ' AND
					`article_idarticle` = ' . $objDatabase->SqlVariable($objMenuHasArticle->ArticleIdarticle) . '
			');
		}

		/**
		 * Unassociates a MenuHasArticleAsId
		 * @param MenuHasArticle $objMenuHasArticle
		 * @return void
		*/
		public function UnassociateMenuHasArticleAsId(MenuHasArticle $objMenuHasArticle) {
			if ((is_null($this->intIdarticle)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMenuHasArticleAsId on this unsaved Article.');
			if ((is_null($objMenuHasArticle->MenuIdmenu)) || (is_null($objMenuHasArticle->ArticleIdarticle)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMenuHasArticleAsId on this Article with an unsaved MenuHasArticle.');

			// Get the Database Object for this Class
			$objDatabase = Article::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`menu_has_article`
				SET
					`article_idarticle` = null
				WHERE
					`menu_idmenu` = ' . $objDatabase->SqlVariable($objMenuHasArticle->MenuIdmenu) . ' AND
					`article_idarticle` = ' . $objDatabase->SqlVariable($objMenuHasArticle->ArticleIdarticle) . ' AND
					`article_idarticle` = ' . $objDatabase->SqlVariable($this->intIdarticle) . '
			');
		}

		/**
		 * Unassociates all MenuHasArticlesAsId
		 * @return void
		*/
		public function UnassociateAllMenuHasArticlesAsId() {
			if ((is_null($this->intIdarticle)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMenuHasArticleAsId on this unsaved Article.');

			// Get the Database Object for this Class
			$objDatabase = Article::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`menu_has_article`
				SET
					`article_idarticle` = null
				WHERE
					`article_idarticle` = ' . $objDatabase->SqlVariable($this->intIdarticle) . '
			');
		}

		/**
		 * Deletes an associated MenuHasArticleAsId
		 * @param MenuHasArticle $objMenuHasArticle
		 * @return void
		*/
		public function DeleteAssociatedMenuHasArticleAsId(MenuHasArticle $objMenuHasArticle) {
			if ((is_null($this->intIdarticle)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMenuHasArticleAsId on this unsaved Article.');
			if ((is_null($objMenuHasArticle->MenuIdmenu)) || (is_null($objMenuHasArticle->ArticleIdarticle)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMenuHasArticleAsId on this Article with an unsaved MenuHasArticle.');

			// Get the Database Object for this Class
			$objDatabase = Article::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`menu_has_article`
				WHERE
					`menu_idmenu` = ' . $objDatabase->SqlVariable($objMenuHasArticle->MenuIdmenu) . ' AND
					`article_idarticle` = ' . $objDatabase->SqlVariable($objMenuHasArticle->ArticleIdarticle) . ' AND
					`article_idarticle` = ' . $objDatabase->SqlVariable($this->intIdarticle) . '
			');
		}

		/**
		 * Deletes all associated MenuHasArticlesAsId
		 * @return void
		*/
		public function DeleteAllMenuHasArticlesAsId() {
			if ((is_null($this->intIdarticle)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMenuHasArticleAsId on this unsaved Article.');

			// Get the Database Object for this Class
			$objDatabase = Article::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`menu_has_article`
				WHERE
					`article_idarticle` = ' . $objDatabase->SqlVariable($this->intIdarticle) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "article";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Article::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Article"><sequence>';
			$strToReturn .= '<element name="Idarticle" type="xsd:int"/>';
			$strToReturn .= '<element name="Code" type="xsd:string"/>';
			$strToReturn .= '<element name="GrpObject" type="xsd1:ArticleGrp"/>';
			$strToReturn .= '<element name="Title" type="xsd:string"/>';
			$strToReturn .= '<element name="Intro" type="xsd:string"/>';
			$strToReturn .= '<element name="Data" type="xsd:string"/>';
			$strToReturn .= '<element name="CssObject" type="xsd1:Css"/>';
			$strToReturn .= '<element name="ClassObject" type="xsd1:Css"/>';
			$strToReturn .= '<element name="VideoUrl" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Article', $strComplexTypeArray)) {
				$strComplexTypeArray['Article'] = Article::GetSoapComplexTypeXml();
				ArticleGrp::AlterSoapComplexTypeArray($strComplexTypeArray);
				Css::AlterSoapComplexTypeArray($strComplexTypeArray);
				Css::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Article::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Article();
			if (property_exists($objSoapObject, 'Idarticle'))
				$objToReturn->intIdarticle = $objSoapObject->Idarticle;
			if (property_exists($objSoapObject, 'Code'))
				$objToReturn->strCode = $objSoapObject->Code;
			if ((property_exists($objSoapObject, 'GrpObject')) &&
				($objSoapObject->GrpObject))
				$objToReturn->GrpObject = ArticleGrp::GetObjectFromSoapObject($objSoapObject->GrpObject);
			if (property_exists($objSoapObject, 'Title'))
				$objToReturn->strTitle = $objSoapObject->Title;
			if (property_exists($objSoapObject, 'Intro'))
				$objToReturn->strIntro = $objSoapObject->Intro;
			if (property_exists($objSoapObject, 'Data'))
				$objToReturn->strData = $objSoapObject->Data;
			if ((property_exists($objSoapObject, 'CssObject')) &&
				($objSoapObject->CssObject))
				$objToReturn->CssObject = Css::GetObjectFromSoapObject($objSoapObject->CssObject);
			if ((property_exists($objSoapObject, 'ClassObject')) &&
				($objSoapObject->ClassObject))
				$objToReturn->ClassObject = Css::GetObjectFromSoapObject($objSoapObject->ClassObject);
			if (property_exists($objSoapObject, 'VideoUrl'))
				$objToReturn->strVideoUrl = $objSoapObject->VideoUrl;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Article::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objGrpObject)
				$objObject->objGrpObject = ArticleGrp::GetSoapObjectFromObject($objObject->objGrpObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intGrp = null;
			if ($objObject->objCssObject)
				$objObject->objCssObject = Css::GetSoapObjectFromObject($objObject->objCssObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCss = null;
			if ($objObject->objClassObject)
				$objObject->objClassObject = Css::GetSoapObjectFromObject($objObject->objClassObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intClass = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idarticle'] = $this->intIdarticle;
			$iArray['Code'] = $this->strCode;
			$iArray['Grp'] = $this->intGrp;
			$iArray['Title'] = $this->strTitle;
			$iArray['Intro'] = $this->strIntro;
			$iArray['Data'] = $this->strData;
			$iArray['Css'] = $this->intCss;
			$iArray['Class'] = $this->intClass;
			$iArray['VideoUrl'] = $this->strVideoUrl;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdarticle ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idarticle
     * @property-read QQNode $Code
     * @property-read QQNode $Grp
     * @property-read QQNodeArticleGrp $GrpObject
     * @property-read QQNode $Title
     * @property-read QQNode $Intro
     * @property-read QQNode $Data
     * @property-read QQNode $Css
     * @property-read QQNodeCss $CssObject
     * @property-read QQNode $Class
     * @property-read QQNodeCss $ClassObject
     * @property-read QQNode $VideoUrl
     *
     *
     * @property-read QQReverseReferenceNodeMenuHasArticle $MenuHasArticleAsId

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeArticle extends QQNode {
		protected $strTableName = 'article';
		protected $strPrimaryKey = 'idarticle';
		protected $strClassName = 'Article';
		public function __get($strName) {
			switch ($strName) {
				case 'Idarticle':
					return new QQNode('idarticle', 'Idarticle', 'Integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'VarChar', $this);
				case 'Grp':
					return new QQNode('grp', 'Grp', 'Integer', $this);
				case 'GrpObject':
					return new QQNodeArticleGrp('grp', 'GrpObject', 'Integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'VarChar', $this);
				case 'Intro':
					return new QQNode('intro', 'Intro', 'Blob', $this);
				case 'Data':
					return new QQNode('data', 'Data', 'Blob', $this);
				case 'Css':
					return new QQNode('css', 'Css', 'Integer', $this);
				case 'CssObject':
					return new QQNodeCss('css', 'CssObject', 'Integer', $this);
				case 'Class':
					return new QQNode('class', 'Class', 'Integer', $this);
				case 'ClassObject':
					return new QQNodeCss('class', 'ClassObject', 'Integer', $this);
				case 'VideoUrl':
					return new QQNode('video_url', 'VideoUrl', 'Blob', $this);
				case 'MenuHasArticleAsId':
					return new QQReverseReferenceNodeMenuHasArticle($this, 'menuhasarticleasid', 'reverse_reference', 'article_idarticle');

				case '_PrimaryKeyNode':
					return new QQNode('idarticle', 'Idarticle', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idarticle
     * @property-read QQNode $Code
     * @property-read QQNode $Grp
     * @property-read QQNodeArticleGrp $GrpObject
     * @property-read QQNode $Title
     * @property-read QQNode $Intro
     * @property-read QQNode $Data
     * @property-read QQNode $Css
     * @property-read QQNodeCss $CssObject
     * @property-read QQNode $Class
     * @property-read QQNodeCss $ClassObject
     * @property-read QQNode $VideoUrl
     *
     *
     * @property-read QQReverseReferenceNodeMenuHasArticle $MenuHasArticleAsId

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeArticle extends QQReverseReferenceNode {
		protected $strTableName = 'article';
		protected $strPrimaryKey = 'idarticle';
		protected $strClassName = 'Article';
		public function __get($strName) {
			switch ($strName) {
				case 'Idarticle':
					return new QQNode('idarticle', 'Idarticle', 'integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'string', $this);
				case 'Grp':
					return new QQNode('grp', 'Grp', 'integer', $this);
				case 'GrpObject':
					return new QQNodeArticleGrp('grp', 'GrpObject', 'integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'string', $this);
				case 'Intro':
					return new QQNode('intro', 'Intro', 'string', $this);
				case 'Data':
					return new QQNode('data', 'Data', 'string', $this);
				case 'Css':
					return new QQNode('css', 'Css', 'integer', $this);
				case 'CssObject':
					return new QQNodeCss('css', 'CssObject', 'integer', $this);
				case 'Class':
					return new QQNode('class', 'Class', 'integer', $this);
				case 'ClassObject':
					return new QQNodeCss('class', 'ClassObject', 'integer', $this);
				case 'VideoUrl':
					return new QQNode('video_url', 'VideoUrl', 'string', $this);
				case 'MenuHasArticleAsId':
					return new QQReverseReferenceNodeMenuHasArticle($this, 'menuhasarticleasid', 'reverse_reference', 'article_idarticle');

				case '_PrimaryKeyNode':
					return new QQNode('idarticle', 'Idarticle', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
