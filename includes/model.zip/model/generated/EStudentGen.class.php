<?php
	/**
	 * The abstract EStudentGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the EStudent subclass which
	 * extends this EStudentGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the EStudent class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdeStudent the value for intIdeStudent (Read-Only PK)
	 * @property integer $Student the value for intStudent (Not Null)
	 * @property integer $IdeCourse the value for intIdeCourse (Not Null)
	 * @property string $SessionProgress the value for strSessionProgress 
	 * @property QDateTime $StartDate the value for dttStartDate 
	 * @property QDateTime $LastAccessDate the value for dttLastAccessDate 
	 * @property QDateTime $EndDate the value for dttEndDate 
	 * @property string $Feedback the value for strFeedback 
	 * @property string $Rating the value for strRating 
	 * @property integer $Marks the value for intMarks 
	 * @property integer $MarksOutof the value for intMarksOutof 
	 * @property string $ECertificate the value for strECertificate 
	 * @property Login $StudentObject the value for the Login object referenced by intStudent (Not Null)
	 * @property ECourse $IdeCourseObject the value for the ECourse object referenced by intIdeCourse (Not Null)
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class EStudentGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column e_student.ide_student
		 * @var integer intIdeStudent
		 */
		protected $intIdeStudent;
		const IdeStudentDefault = null;


		/**
		 * Protected member variable that maps to the database column e_student.student
		 * @var integer intStudent
		 */
		protected $intStudent;
		const StudentDefault = null;


		/**
		 * Protected member variable that maps to the database column e_student.ide_course
		 * @var integer intIdeCourse
		 */
		protected $intIdeCourse;
		const IdeCourseDefault = null;


		/**
		 * Protected member variable that maps to the database column e_student.session_progress
		 * @var string strSessionProgress
		 */
		protected $strSessionProgress;
		const SessionProgressMaxLength = 255;
		const SessionProgressDefault = null;


		/**
		 * Protected member variable that maps to the database column e_student.start_date
		 * @var QDateTime dttStartDate
		 */
		protected $dttStartDate;
		const StartDateDefault = null;


		/**
		 * Protected member variable that maps to the database column e_student.last_access_date
		 * @var QDateTime dttLastAccessDate
		 */
		protected $dttLastAccessDate;
		const LastAccessDateDefault = null;


		/**
		 * Protected member variable that maps to the database column e_student.end_date
		 * @var QDateTime dttEndDate
		 */
		protected $dttEndDate;
		const EndDateDefault = null;


		/**
		 * Protected member variable that maps to the database column e_student.feedback
		 * @var string strFeedback
		 */
		protected $strFeedback;
		const FeedbackDefault = null;


		/**
		 * Protected member variable that maps to the database column e_student.rating
		 * @var string strRating
		 */
		protected $strRating;
		const RatingDefault = null;


		/**
		 * Protected member variable that maps to the database column e_student.marks
		 * @var integer intMarks
		 */
		protected $intMarks;
		const MarksDefault = null;


		/**
		 * Protected member variable that maps to the database column e_student.marks_outof
		 * @var integer intMarksOutof
		 */
		protected $intMarksOutof;
		const MarksOutofDefault = null;


		/**
		 * Protected member variable that maps to the database column e_student.e_certificate
		 * @var string strECertificate
		 */
		protected $strECertificate;
		const ECertificateDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column e_student.student.
		 *
		 * NOTE: Always use the StudentObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objStudentObject
		 */
		protected $objStudentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column e_student.ide_course.
		 *
		 * NOTE: Always use the IdeCourseObject property getter to correctly retrieve this ECourse object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var ECourse objIdeCourseObject
		 */
		protected $objIdeCourseObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdeStudent = EStudent::IdeStudentDefault;
			$this->intStudent = EStudent::StudentDefault;
			$this->intIdeCourse = EStudent::IdeCourseDefault;
			$this->strSessionProgress = EStudent::SessionProgressDefault;
			$this->dttStartDate = (EStudent::StartDateDefault === null)?null:new QDateTime(EStudent::StartDateDefault);
			$this->dttLastAccessDate = (EStudent::LastAccessDateDefault === null)?null:new QDateTime(EStudent::LastAccessDateDefault);
			$this->dttEndDate = (EStudent::EndDateDefault === null)?null:new QDateTime(EStudent::EndDateDefault);
			$this->strFeedback = EStudent::FeedbackDefault;
			$this->strRating = EStudent::RatingDefault;
			$this->intMarks = EStudent::MarksDefault;
			$this->intMarksOutof = EStudent::MarksOutofDefault;
			$this->strECertificate = EStudent::ECertificateDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a EStudent from PK Info
		 * @param integer $intIdeStudent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EStudent
		 */
		public static function Load($intIdeStudent, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'EStudent', $intIdeStudent);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = EStudent::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::EStudent()->IdeStudent, $intIdeStudent)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all EStudents
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EStudent[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call EStudent::QueryArray to perform the LoadAll query
			try {
				return EStudent::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all EStudents
		 * @return int
		 */
		public static function CountAll() {
			// Call EStudent::QueryCount to perform the CountAll query
			return EStudent::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = EStudent::GetDatabase();

			// Create/Build out the QueryBuilder object with EStudent-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'e_student');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				EStudent::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('e_student');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single EStudent object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return EStudent the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = EStudent::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new EStudent object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = EStudent::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return EStudent::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of EStudent objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return EStudent[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = EStudent::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return EStudent::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = EStudent::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of EStudent objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = EStudent::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = EStudent::GetDatabase();

			$strQuery = EStudent::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/estudent', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = EStudent::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this EStudent
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'e_student';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'ide_student', $strAliasPrefix . 'ide_student');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'ide_student', $strAliasPrefix . 'ide_student');
			    $objBuilder->AddSelectItem($strTableName, 'student', $strAliasPrefix . 'student');
			    $objBuilder->AddSelectItem($strTableName, 'ide_course', $strAliasPrefix . 'ide_course');
			    $objBuilder->AddSelectItem($strTableName, 'session_progress', $strAliasPrefix . 'session_progress');
			    $objBuilder->AddSelectItem($strTableName, 'start_date', $strAliasPrefix . 'start_date');
			    $objBuilder->AddSelectItem($strTableName, 'last_access_date', $strAliasPrefix . 'last_access_date');
			    $objBuilder->AddSelectItem($strTableName, 'end_date', $strAliasPrefix . 'end_date');
			    $objBuilder->AddSelectItem($strTableName, 'feedback', $strAliasPrefix . 'feedback');
			    $objBuilder->AddSelectItem($strTableName, 'rating', $strAliasPrefix . 'rating');
			    $objBuilder->AddSelectItem($strTableName, 'marks', $strAliasPrefix . 'marks');
			    $objBuilder->AddSelectItem($strTableName, 'marks_outof', $strAliasPrefix . 'marks_outof');
			    $objBuilder->AddSelectItem($strTableName, 'e_certificate', $strAliasPrefix . 'e_certificate');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a EStudent from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this EStudent::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return EStudent
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the EStudent object
			$objToReturn = new EStudent();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'ide_student';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdeStudent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'student';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intStudent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'ide_course';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdeCourse = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'session_progress';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strSessionProgress = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'start_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttStartDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'last_access_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttLastAccessDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'end_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttEndDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'feedback';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strFeedback = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'rating';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strRating = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'marks';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMarks = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'marks_outof';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMarksOutof = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'e_certificate';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strECertificate = $objDbRow->GetColumn($strAliasName, 'Blob');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdeStudent != $objPreviousItem->IdeStudent) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'e_student__';

			// Check for StudentObject Early Binding
			$strAlias = $strAliasPrefix . 'student__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objStudentObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'student__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for IdeCourseObject Early Binding
			$strAlias = $strAliasPrefix . 'ide_course__ide_course';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objIdeCourseObject = ECourse::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ide_course__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of EStudents from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return EStudent[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = EStudent::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = EStudent::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single EStudent object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return EStudent next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return EStudent::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single EStudent object,
		 * by IdeStudent Index(es)
		 * @param integer $intIdeStudent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EStudent
		*/
		public static function LoadByIdeStudent($intIdeStudent, $objOptionalClauses = null) {
			return EStudent::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::EStudent()->IdeStudent, $intIdeStudent)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of EStudent objects,
		 * by IdeCourse Index(es)
		 * @param integer $intIdeCourse
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EStudent[]
		*/
		public static function LoadArrayByIdeCourse($intIdeCourse, $objOptionalClauses = null) {
			// Call EStudent::QueryArray to perform the LoadArrayByIdeCourse query
			try {
				return EStudent::QueryArray(
					QQ::Equal(QQN::EStudent()->IdeCourse, $intIdeCourse),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count EStudents
		 * by IdeCourse Index(es)
		 * @param integer $intIdeCourse
		 * @return int
		*/
		public static function CountByIdeCourse($intIdeCourse) {
			// Call EStudent::QueryCount to perform the CountByIdeCourse query
			return EStudent::QueryCount(
				QQ::Equal(QQN::EStudent()->IdeCourse, $intIdeCourse)
			);
		}

		/**
		 * Load an array of EStudent objects,
		 * by Student Index(es)
		 * @param integer $intStudent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EStudent[]
		*/
		public static function LoadArrayByStudent($intStudent, $objOptionalClauses = null) {
			// Call EStudent::QueryArray to perform the LoadArrayByStudent query
			try {
				return EStudent::QueryArray(
					QQ::Equal(QQN::EStudent()->Student, $intStudent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count EStudents
		 * by Student Index(es)
		 * @param integer $intStudent
		 * @return int
		*/
		public static function CountByStudent($intStudent) {
			// Call EStudent::QueryCount to perform the CountByStudent query
			return EStudent::QueryCount(
				QQ::Equal(QQN::EStudent()->Student, $intStudent)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this EStudent
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = EStudent::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `e_student` (
							`student`,
							`ide_course`,
							`session_progress`,
							`start_date`,
							`last_access_date`,
							`end_date`,
							`feedback`,
							`rating`,
							`marks`,
							`marks_outof`,
							`e_certificate`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intStudent) . ',
							' . $objDatabase->SqlVariable($this->intIdeCourse) . ',
							' . $objDatabase->SqlVariable($this->strSessionProgress) . ',
							' . $objDatabase->SqlVariable($this->dttStartDate) . ',
							' . $objDatabase->SqlVariable($this->dttLastAccessDate) . ',
							' . $objDatabase->SqlVariable($this->dttEndDate) . ',
							' . $objDatabase->SqlVariable($this->strFeedback) . ',
							' . $objDatabase->SqlVariable($this->strRating) . ',
							' . $objDatabase->SqlVariable($this->intMarks) . ',
							' . $objDatabase->SqlVariable($this->intMarksOutof) . ',
							' . $objDatabase->SqlVariable($this->strECertificate) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdeStudent = $objDatabase->InsertId('e_student', 'ide_student');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`e_student`
						SET
							`student` = ' . $objDatabase->SqlVariable($this->intStudent) . ',
							`ide_course` = ' . $objDatabase->SqlVariable($this->intIdeCourse) . ',
							`session_progress` = ' . $objDatabase->SqlVariable($this->strSessionProgress) . ',
							`start_date` = ' . $objDatabase->SqlVariable($this->dttStartDate) . ',
							`last_access_date` = ' . $objDatabase->SqlVariable($this->dttLastAccessDate) . ',
							`end_date` = ' . $objDatabase->SqlVariable($this->dttEndDate) . ',
							`feedback` = ' . $objDatabase->SqlVariable($this->strFeedback) . ',
							`rating` = ' . $objDatabase->SqlVariable($this->strRating) . ',
							`marks` = ' . $objDatabase->SqlVariable($this->intMarks) . ',
							`marks_outof` = ' . $objDatabase->SqlVariable($this->intMarksOutof) . ',
							`e_certificate` = ' . $objDatabase->SqlVariable($this->strECertificate) . '
						WHERE
							`ide_student` = ' . $objDatabase->SqlVariable($this->intIdeStudent) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this EStudent
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdeStudent)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this EStudent with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = EStudent::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`e_student`
				WHERE
					`ide_student` = ' . $objDatabase->SqlVariable($this->intIdeStudent) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this EStudent ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'EStudent', $this->intIdeStudent);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all EStudents
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = EStudent::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`e_student`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate e_student table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = EStudent::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `e_student`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this EStudent from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved EStudent object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = EStudent::Load($this->intIdeStudent);

			// Update $this's local variables to match
			$this->Student = $objReloaded->Student;
			$this->IdeCourse = $objReloaded->IdeCourse;
			$this->strSessionProgress = $objReloaded->strSessionProgress;
			$this->dttStartDate = $objReloaded->dttStartDate;
			$this->dttLastAccessDate = $objReloaded->dttLastAccessDate;
			$this->dttEndDate = $objReloaded->dttEndDate;
			$this->strFeedback = $objReloaded->strFeedback;
			$this->strRating = $objReloaded->strRating;
			$this->intMarks = $objReloaded->intMarks;
			$this->intMarksOutof = $objReloaded->intMarksOutof;
			$this->strECertificate = $objReloaded->strECertificate;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdeStudent':
					/**
					 * Gets the value for intIdeStudent (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdeStudent;

				case 'Student':
					/**
					 * Gets the value for intStudent (Not Null)
					 * @return integer
					 */
					return $this->intStudent;

				case 'IdeCourse':
					/**
					 * Gets the value for intIdeCourse (Not Null)
					 * @return integer
					 */
					return $this->intIdeCourse;

				case 'SessionProgress':
					/**
					 * Gets the value for strSessionProgress 
					 * @return string
					 */
					return $this->strSessionProgress;

				case 'StartDate':
					/**
					 * Gets the value for dttStartDate 
					 * @return QDateTime
					 */
					return $this->dttStartDate;

				case 'LastAccessDate':
					/**
					 * Gets the value for dttLastAccessDate 
					 * @return QDateTime
					 */
					return $this->dttLastAccessDate;

				case 'EndDate':
					/**
					 * Gets the value for dttEndDate 
					 * @return QDateTime
					 */
					return $this->dttEndDate;

				case 'Feedback':
					/**
					 * Gets the value for strFeedback 
					 * @return string
					 */
					return $this->strFeedback;

				case 'Rating':
					/**
					 * Gets the value for strRating 
					 * @return string
					 */
					return $this->strRating;

				case 'Marks':
					/**
					 * Gets the value for intMarks 
					 * @return integer
					 */
					return $this->intMarks;

				case 'MarksOutof':
					/**
					 * Gets the value for intMarksOutof 
					 * @return integer
					 */
					return $this->intMarksOutof;

				case 'ECertificate':
					/**
					 * Gets the value for strECertificate 
					 * @return string
					 */
					return $this->strECertificate;


				///////////////////
				// Member Objects
				///////////////////
				case 'StudentObject':
					/**
					 * Gets the value for the Login object referenced by intStudent (Not Null)
					 * @return Login
					 */
					try {
						if ((!$this->objStudentObject) && (!is_null($this->intStudent)))
							$this->objStudentObject = Login::Load($this->intStudent);
						return $this->objStudentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'IdeCourseObject':
					/**
					 * Gets the value for the ECourse object referenced by intIdeCourse (Not Null)
					 * @return ECourse
					 */
					try {
						if ((!$this->objIdeCourseObject) && (!is_null($this->intIdeCourse)))
							$this->objIdeCourseObject = ECourse::Load($this->intIdeCourse);
						return $this->objIdeCourseObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Student':
					/**
					 * Sets the value for intStudent (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objStudentObject = null;
						return ($this->intStudent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'IdeCourse':
					/**
					 * Sets the value for intIdeCourse (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objIdeCourseObject = null;
						return ($this->intIdeCourse = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SessionProgress':
					/**
					 * Sets the value for strSessionProgress 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strSessionProgress = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'StartDate':
					/**
					 * Sets the value for dttStartDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttStartDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LastAccessDate':
					/**
					 * Sets the value for dttLastAccessDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttLastAccessDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'EndDate':
					/**
					 * Sets the value for dttEndDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttEndDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Feedback':
					/**
					 * Sets the value for strFeedback 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strFeedback = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Rating':
					/**
					 * Sets the value for strRating 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strRating = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Marks':
					/**
					 * Sets the value for intMarks 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intMarks = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'MarksOutof':
					/**
					 * Sets the value for intMarksOutof 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intMarksOutof = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ECertificate':
					/**
					 * Sets the value for strECertificate 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strECertificate = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'StudentObject':
					/**
					 * Sets the value for the Login object referenced by intStudent (Not Null)
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intStudent = null;
						$this->objStudentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved StudentObject for this EStudent');

						// Update Local Member Variables
						$this->objStudentObject = $mixValue;
						$this->intStudent = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'IdeCourseObject':
					/**
					 * Sets the value for the ECourse object referenced by intIdeCourse (Not Null)
					 * @param ECourse $mixValue
					 * @return ECourse
					 */
					if (is_null($mixValue)) {
						$this->intIdeCourse = null;
						$this->objIdeCourseObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a ECourse object
						try {
							$mixValue = QType::Cast($mixValue, 'ECourse');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED ECourse object
						if (is_null($mixValue->IdeCourse))
							throw new QCallerException('Unable to set an unsaved IdeCourseObject for this EStudent');

						// Update Local Member Variables
						$this->objIdeCourseObject = $mixValue;
						$this->intIdeCourse = $mixValue->IdeCourse;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "e_student";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[EStudent::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="EStudent"><sequence>';
			$strToReturn .= '<element name="IdeStudent" type="xsd:int"/>';
			$strToReturn .= '<element name="StudentObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="IdeCourseObject" type="xsd1:ECourse"/>';
			$strToReturn .= '<element name="SessionProgress" type="xsd:string"/>';
			$strToReturn .= '<element name="StartDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="LastAccessDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="EndDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Feedback" type="xsd:string"/>';
			$strToReturn .= '<element name="Rating" type="xsd:string"/>';
			$strToReturn .= '<element name="Marks" type="xsd:int"/>';
			$strToReturn .= '<element name="MarksOutof" type="xsd:int"/>';
			$strToReturn .= '<element name="ECertificate" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('EStudent', $strComplexTypeArray)) {
				$strComplexTypeArray['EStudent'] = EStudent::GetSoapComplexTypeXml();
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				ECourse::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, EStudent::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new EStudent();
			if (property_exists($objSoapObject, 'IdeStudent'))
				$objToReturn->intIdeStudent = $objSoapObject->IdeStudent;
			if ((property_exists($objSoapObject, 'StudentObject')) &&
				($objSoapObject->StudentObject))
				$objToReturn->StudentObject = Login::GetObjectFromSoapObject($objSoapObject->StudentObject);
			if ((property_exists($objSoapObject, 'IdeCourseObject')) &&
				($objSoapObject->IdeCourseObject))
				$objToReturn->IdeCourseObject = ECourse::GetObjectFromSoapObject($objSoapObject->IdeCourseObject);
			if (property_exists($objSoapObject, 'SessionProgress'))
				$objToReturn->strSessionProgress = $objSoapObject->SessionProgress;
			if (property_exists($objSoapObject, 'StartDate'))
				$objToReturn->dttStartDate = new QDateTime($objSoapObject->StartDate);
			if (property_exists($objSoapObject, 'LastAccessDate'))
				$objToReturn->dttLastAccessDate = new QDateTime($objSoapObject->LastAccessDate);
			if (property_exists($objSoapObject, 'EndDate'))
				$objToReturn->dttEndDate = new QDateTime($objSoapObject->EndDate);
			if (property_exists($objSoapObject, 'Feedback'))
				$objToReturn->strFeedback = $objSoapObject->Feedback;
			if (property_exists($objSoapObject, 'Rating'))
				$objToReturn->strRating = $objSoapObject->Rating;
			if (property_exists($objSoapObject, 'Marks'))
				$objToReturn->intMarks = $objSoapObject->Marks;
			if (property_exists($objSoapObject, 'MarksOutof'))
				$objToReturn->intMarksOutof = $objSoapObject->MarksOutof;
			if (property_exists($objSoapObject, 'ECertificate'))
				$objToReturn->strECertificate = $objSoapObject->ECertificate;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, EStudent::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objStudentObject)
				$objObject->objStudentObject = Login::GetSoapObjectFromObject($objObject->objStudentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intStudent = null;
			if ($objObject->objIdeCourseObject)
				$objObject->objIdeCourseObject = ECourse::GetSoapObjectFromObject($objObject->objIdeCourseObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intIdeCourse = null;
			if ($objObject->dttStartDate)
				$objObject->dttStartDate = $objObject->dttStartDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttLastAccessDate)
				$objObject->dttLastAccessDate = $objObject->dttLastAccessDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttEndDate)
				$objObject->dttEndDate = $objObject->dttEndDate->qFormat(QDateTime::FormatSoap);
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdeStudent'] = $this->intIdeStudent;
			$iArray['Student'] = $this->intStudent;
			$iArray['IdeCourse'] = $this->intIdeCourse;
			$iArray['SessionProgress'] = $this->strSessionProgress;
			$iArray['StartDate'] = $this->dttStartDate;
			$iArray['LastAccessDate'] = $this->dttLastAccessDate;
			$iArray['EndDate'] = $this->dttEndDate;
			$iArray['Feedback'] = $this->strFeedback;
			$iArray['Rating'] = $this->strRating;
			$iArray['Marks'] = $this->intMarks;
			$iArray['MarksOutof'] = $this->intMarksOutof;
			$iArray['ECertificate'] = $this->strECertificate;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdeStudent ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdeStudent
     * @property-read QQNode $Student
     * @property-read QQNodeLogin $StudentObject
     * @property-read QQNode $IdeCourse
     * @property-read QQNodeECourse $IdeCourseObject
     * @property-read QQNode $SessionProgress
     * @property-read QQNode $StartDate
     * @property-read QQNode $LastAccessDate
     * @property-read QQNode $EndDate
     * @property-read QQNode $Feedback
     * @property-read QQNode $Rating
     * @property-read QQNode $Marks
     * @property-read QQNode $MarksOutof
     * @property-read QQNode $ECertificate
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeEStudent extends QQNode {
		protected $strTableName = 'e_student';
		protected $strPrimaryKey = 'ide_student';
		protected $strClassName = 'EStudent';
		public function __get($strName) {
			switch ($strName) {
				case 'IdeStudent':
					return new QQNode('ide_student', 'IdeStudent', 'Integer', $this);
				case 'Student':
					return new QQNode('student', 'Student', 'Integer', $this);
				case 'StudentObject':
					return new QQNodeLogin('student', 'StudentObject', 'Integer', $this);
				case 'IdeCourse':
					return new QQNode('ide_course', 'IdeCourse', 'Integer', $this);
				case 'IdeCourseObject':
					return new QQNodeECourse('ide_course', 'IdeCourseObject', 'Integer', $this);
				case 'SessionProgress':
					return new QQNode('session_progress', 'SessionProgress', 'VarChar', $this);
				case 'StartDate':
					return new QQNode('start_date', 'StartDate', 'Date', $this);
				case 'LastAccessDate':
					return new QQNode('last_access_date', 'LastAccessDate', 'Date', $this);
				case 'EndDate':
					return new QQNode('end_date', 'EndDate', 'Date', $this);
				case 'Feedback':
					return new QQNode('feedback', 'Feedback', 'Blob', $this);
				case 'Rating':
					return new QQNode('rating', 'Rating', 'VarChar', $this);
				case 'Marks':
					return new QQNode('marks', 'Marks', 'Integer', $this);
				case 'MarksOutof':
					return new QQNode('marks_outof', 'MarksOutof', 'Integer', $this);
				case 'ECertificate':
					return new QQNode('e_certificate', 'ECertificate', 'Blob', $this);

				case '_PrimaryKeyNode':
					return new QQNode('ide_student', 'IdeStudent', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdeStudent
     * @property-read QQNode $Student
     * @property-read QQNodeLogin $StudentObject
     * @property-read QQNode $IdeCourse
     * @property-read QQNodeECourse $IdeCourseObject
     * @property-read QQNode $SessionProgress
     * @property-read QQNode $StartDate
     * @property-read QQNode $LastAccessDate
     * @property-read QQNode $EndDate
     * @property-read QQNode $Feedback
     * @property-read QQNode $Rating
     * @property-read QQNode $Marks
     * @property-read QQNode $MarksOutof
     * @property-read QQNode $ECertificate
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeEStudent extends QQReverseReferenceNode {
		protected $strTableName = 'e_student';
		protected $strPrimaryKey = 'ide_student';
		protected $strClassName = 'EStudent';
		public function __get($strName) {
			switch ($strName) {
				case 'IdeStudent':
					return new QQNode('ide_student', 'IdeStudent', 'integer', $this);
				case 'Student':
					return new QQNode('student', 'Student', 'integer', $this);
				case 'StudentObject':
					return new QQNodeLogin('student', 'StudentObject', 'integer', $this);
				case 'IdeCourse':
					return new QQNode('ide_course', 'IdeCourse', 'integer', $this);
				case 'IdeCourseObject':
					return new QQNodeECourse('ide_course', 'IdeCourseObject', 'integer', $this);
				case 'SessionProgress':
					return new QQNode('session_progress', 'SessionProgress', 'string', $this);
				case 'StartDate':
					return new QQNode('start_date', 'StartDate', 'QDateTime', $this);
				case 'LastAccessDate':
					return new QQNode('last_access_date', 'LastAccessDate', 'QDateTime', $this);
				case 'EndDate':
					return new QQNode('end_date', 'EndDate', 'QDateTime', $this);
				case 'Feedback':
					return new QQNode('feedback', 'Feedback', 'string', $this);
				case 'Rating':
					return new QQNode('rating', 'Rating', 'string', $this);
				case 'Marks':
					return new QQNode('marks', 'Marks', 'integer', $this);
				case 'MarksOutof':
					return new QQNode('marks_outof', 'MarksOutof', 'integer', $this);
				case 'ECertificate':
					return new QQNode('e_certificate', 'ECertificate', 'string', $this);

				case '_PrimaryKeyNode':
					return new QQNode('ide_student', 'IdeStudent', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
