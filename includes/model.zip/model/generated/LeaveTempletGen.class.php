<?php
	/**
	 * The abstract LeaveTempletGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the LeaveTemplet subclass which
	 * extends this LeaveTempletGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the LeaveTemplet class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdleaveTemplet the value for intIdleaveTemplet (Read-Only PK)
	 * @property integer $AppointmentCat the value for intAppointmentCat (Not Null)
	 * @property integer $LeaveCat the value for intLeaveCat (Not Null)
	 * @property integer $LeaveCount the value for intLeaveCount 
	 * @property AppointmentCategory $AppointmentCatObject the value for the AppointmentCategory object referenced by intAppointmentCat (Not Null)
	 * @property LeaveCat $LeaveCatObject the value for the LeaveCat object referenced by intLeaveCat (Not Null)
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class LeaveTempletGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column leave_templet.idleave_templet
		 * @var integer intIdleaveTemplet
		 */
		protected $intIdleaveTemplet;
		const IdleaveTempletDefault = null;


		/**
		 * Protected member variable that maps to the database column leave_templet.appointment_cat
		 * @var integer intAppointmentCat
		 */
		protected $intAppointmentCat;
		const AppointmentCatDefault = null;


		/**
		 * Protected member variable that maps to the database column leave_templet.leave_cat
		 * @var integer intLeaveCat
		 */
		protected $intLeaveCat;
		const LeaveCatDefault = null;


		/**
		 * Protected member variable that maps to the database column leave_templet.leave_count
		 * @var integer intLeaveCount
		 */
		protected $intLeaveCount;
		const LeaveCountDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column leave_templet.appointment_cat.
		 *
		 * NOTE: Always use the AppointmentCatObject property getter to correctly retrieve this AppointmentCategory object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var AppointmentCategory objAppointmentCatObject
		 */
		protected $objAppointmentCatObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column leave_templet.leave_cat.
		 *
		 * NOTE: Always use the LeaveCatObject property getter to correctly retrieve this LeaveCat object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var LeaveCat objLeaveCatObject
		 */
		protected $objLeaveCatObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdleaveTemplet = LeaveTemplet::IdleaveTempletDefault;
			$this->intAppointmentCat = LeaveTemplet::AppointmentCatDefault;
			$this->intLeaveCat = LeaveTemplet::LeaveCatDefault;
			$this->intLeaveCount = LeaveTemplet::LeaveCountDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a LeaveTemplet from PK Info
		 * @param integer $intIdleaveTemplet
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveTemplet
		 */
		public static function Load($intIdleaveTemplet, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'LeaveTemplet', $intIdleaveTemplet);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = LeaveTemplet::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::LeaveTemplet()->IdleaveTemplet, $intIdleaveTemplet)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all LeaveTemplets
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveTemplet[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call LeaveTemplet::QueryArray to perform the LoadAll query
			try {
				return LeaveTemplet::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all LeaveTemplets
		 * @return int
		 */
		public static function CountAll() {
			// Call LeaveTemplet::QueryCount to perform the CountAll query
			return LeaveTemplet::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = LeaveTemplet::GetDatabase();

			// Create/Build out the QueryBuilder object with LeaveTemplet-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'leave_templet');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				LeaveTemplet::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('leave_templet');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single LeaveTemplet object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return LeaveTemplet the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = LeaveTemplet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new LeaveTemplet object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = LeaveTemplet::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return LeaveTemplet::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of LeaveTemplet objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return LeaveTemplet[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = LeaveTemplet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return LeaveTemplet::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = LeaveTemplet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of LeaveTemplet objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = LeaveTemplet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = LeaveTemplet::GetDatabase();

			$strQuery = LeaveTemplet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/leavetemplet', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = LeaveTemplet::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this LeaveTemplet
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'leave_templet';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idleave_templet', $strAliasPrefix . 'idleave_templet');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idleave_templet', $strAliasPrefix . 'idleave_templet');
			    $objBuilder->AddSelectItem($strTableName, 'appointment_cat', $strAliasPrefix . 'appointment_cat');
			    $objBuilder->AddSelectItem($strTableName, 'leave_cat', $strAliasPrefix . 'leave_cat');
			    $objBuilder->AddSelectItem($strTableName, 'leave_count', $strAliasPrefix . 'leave_count');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a LeaveTemplet from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this LeaveTemplet::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return LeaveTemplet
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the LeaveTemplet object
			$objToReturn = new LeaveTemplet();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idleave_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdleaveTemplet = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'appointment_cat';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intAppointmentCat = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'leave_cat';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intLeaveCat = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'leave_count';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intLeaveCount = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdleaveTemplet != $objPreviousItem->IdleaveTemplet) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'leave_templet__';

			// Check for AppointmentCatObject Early Binding
			$strAlias = $strAliasPrefix . 'appointment_cat__idappointment_category';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objAppointmentCatObject = AppointmentCategory::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appointment_cat__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for LeaveCatObject Early Binding
			$strAlias = $strAliasPrefix . 'leave_cat__idleave_cat';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objLeaveCatObject = LeaveCat::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leave_cat__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of LeaveTemplets from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return LeaveTemplet[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = LeaveTemplet::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = LeaveTemplet::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single LeaveTemplet object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return LeaveTemplet next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return LeaveTemplet::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single LeaveTemplet object,
		 * by IdleaveTemplet Index(es)
		 * @param integer $intIdleaveTemplet
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveTemplet
		*/
		public static function LoadByIdleaveTemplet($intIdleaveTemplet, $objOptionalClauses = null) {
			return LeaveTemplet::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::LeaveTemplet()->IdleaveTemplet, $intIdleaveTemplet)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of LeaveTemplet objects,
		 * by AppointmentCat Index(es)
		 * @param integer $intAppointmentCat
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveTemplet[]
		*/
		public static function LoadArrayByAppointmentCat($intAppointmentCat, $objOptionalClauses = null) {
			// Call LeaveTemplet::QueryArray to perform the LoadArrayByAppointmentCat query
			try {
				return LeaveTemplet::QueryArray(
					QQ::Equal(QQN::LeaveTemplet()->AppointmentCat, $intAppointmentCat),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count LeaveTemplets
		 * by AppointmentCat Index(es)
		 * @param integer $intAppointmentCat
		 * @return int
		*/
		public static function CountByAppointmentCat($intAppointmentCat) {
			// Call LeaveTemplet::QueryCount to perform the CountByAppointmentCat query
			return LeaveTemplet::QueryCount(
				QQ::Equal(QQN::LeaveTemplet()->AppointmentCat, $intAppointmentCat)
			);
		}

		/**
		 * Load an array of LeaveTemplet objects,
		 * by LeaveCat Index(es)
		 * @param integer $intLeaveCat
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveTemplet[]
		*/
		public static function LoadArrayByLeaveCat($intLeaveCat, $objOptionalClauses = null) {
			// Call LeaveTemplet::QueryArray to perform the LoadArrayByLeaveCat query
			try {
				return LeaveTemplet::QueryArray(
					QQ::Equal(QQN::LeaveTemplet()->LeaveCat, $intLeaveCat),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count LeaveTemplets
		 * by LeaveCat Index(es)
		 * @param integer $intLeaveCat
		 * @return int
		*/
		public static function CountByLeaveCat($intLeaveCat) {
			// Call LeaveTemplet::QueryCount to perform the CountByLeaveCat query
			return LeaveTemplet::QueryCount(
				QQ::Equal(QQN::LeaveTemplet()->LeaveCat, $intLeaveCat)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this LeaveTemplet
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = LeaveTemplet::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `leave_templet` (
							`appointment_cat`,
							`leave_cat`,
							`leave_count`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intAppointmentCat) . ',
							' . $objDatabase->SqlVariable($this->intLeaveCat) . ',
							' . $objDatabase->SqlVariable($this->intLeaveCount) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdleaveTemplet = $objDatabase->InsertId('leave_templet', 'idleave_templet');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`leave_templet`
						SET
							`appointment_cat` = ' . $objDatabase->SqlVariable($this->intAppointmentCat) . ',
							`leave_cat` = ' . $objDatabase->SqlVariable($this->intLeaveCat) . ',
							`leave_count` = ' . $objDatabase->SqlVariable($this->intLeaveCount) . '
						WHERE
							`idleave_templet` = ' . $objDatabase->SqlVariable($this->intIdleaveTemplet) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this LeaveTemplet
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdleaveTemplet)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this LeaveTemplet with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = LeaveTemplet::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leave_templet`
				WHERE
					`idleave_templet` = ' . $objDatabase->SqlVariable($this->intIdleaveTemplet) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this LeaveTemplet ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'LeaveTemplet', $this->intIdleaveTemplet);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all LeaveTemplets
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = LeaveTemplet::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leave_templet`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate leave_templet table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = LeaveTemplet::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `leave_templet`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this LeaveTemplet from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved LeaveTemplet object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = LeaveTemplet::Load($this->intIdleaveTemplet);

			// Update $this's local variables to match
			$this->AppointmentCat = $objReloaded->AppointmentCat;
			$this->LeaveCat = $objReloaded->LeaveCat;
			$this->intLeaveCount = $objReloaded->intLeaveCount;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdleaveTemplet':
					/**
					 * Gets the value for intIdleaveTemplet (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdleaveTemplet;

				case 'AppointmentCat':
					/**
					 * Gets the value for intAppointmentCat (Not Null)
					 * @return integer
					 */
					return $this->intAppointmentCat;

				case 'LeaveCat':
					/**
					 * Gets the value for intLeaveCat (Not Null)
					 * @return integer
					 */
					return $this->intLeaveCat;

				case 'LeaveCount':
					/**
					 * Gets the value for intLeaveCount 
					 * @return integer
					 */
					return $this->intLeaveCount;


				///////////////////
				// Member Objects
				///////////////////
				case 'AppointmentCatObject':
					/**
					 * Gets the value for the AppointmentCategory object referenced by intAppointmentCat (Not Null)
					 * @return AppointmentCategory
					 */
					try {
						if ((!$this->objAppointmentCatObject) && (!is_null($this->intAppointmentCat)))
							$this->objAppointmentCatObject = AppointmentCategory::Load($this->intAppointmentCat);
						return $this->objAppointmentCatObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeaveCatObject':
					/**
					 * Gets the value for the LeaveCat object referenced by intLeaveCat (Not Null)
					 * @return LeaveCat
					 */
					try {
						if ((!$this->objLeaveCatObject) && (!is_null($this->intLeaveCat)))
							$this->objLeaveCatObject = LeaveCat::Load($this->intLeaveCat);
						return $this->objLeaveCatObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'AppointmentCat':
					/**
					 * Sets the value for intAppointmentCat (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objAppointmentCatObject = null;
						return ($this->intAppointmentCat = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeaveCat':
					/**
					 * Sets the value for intLeaveCat (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objLeaveCatObject = null;
						return ($this->intLeaveCat = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LeaveCount':
					/**
					 * Sets the value for intLeaveCount 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intLeaveCount = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'AppointmentCatObject':
					/**
					 * Sets the value for the AppointmentCategory object referenced by intAppointmentCat (Not Null)
					 * @param AppointmentCategory $mixValue
					 * @return AppointmentCategory
					 */
					if (is_null($mixValue)) {
						$this->intAppointmentCat = null;
						$this->objAppointmentCatObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a AppointmentCategory object
						try {
							$mixValue = QType::Cast($mixValue, 'AppointmentCategory');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED AppointmentCategory object
						if (is_null($mixValue->IdappointmentCategory))
							throw new QCallerException('Unable to set an unsaved AppointmentCatObject for this LeaveTemplet');

						// Update Local Member Variables
						$this->objAppointmentCatObject = $mixValue;
						$this->intAppointmentCat = $mixValue->IdappointmentCategory;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'LeaveCatObject':
					/**
					 * Sets the value for the LeaveCat object referenced by intLeaveCat (Not Null)
					 * @param LeaveCat $mixValue
					 * @return LeaveCat
					 */
					if (is_null($mixValue)) {
						$this->intLeaveCat = null;
						$this->objLeaveCatObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a LeaveCat object
						try {
							$mixValue = QType::Cast($mixValue, 'LeaveCat');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED LeaveCat object
						if (is_null($mixValue->IdleaveCat))
							throw new QCallerException('Unable to set an unsaved LeaveCatObject for this LeaveTemplet');

						// Update Local Member Variables
						$this->objLeaveCatObject = $mixValue;
						$this->intLeaveCat = $mixValue->IdleaveCat;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "leave_templet";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[LeaveTemplet::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="LeaveTemplet"><sequence>';
			$strToReturn .= '<element name="IdleaveTemplet" type="xsd:int"/>';
			$strToReturn .= '<element name="AppointmentCatObject" type="xsd1:AppointmentCategory"/>';
			$strToReturn .= '<element name="LeaveCatObject" type="xsd1:LeaveCat"/>';
			$strToReturn .= '<element name="LeaveCount" type="xsd:int"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('LeaveTemplet', $strComplexTypeArray)) {
				$strComplexTypeArray['LeaveTemplet'] = LeaveTemplet::GetSoapComplexTypeXml();
				AppointmentCategory::AlterSoapComplexTypeArray($strComplexTypeArray);
				LeaveCat::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, LeaveTemplet::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new LeaveTemplet();
			if (property_exists($objSoapObject, 'IdleaveTemplet'))
				$objToReturn->intIdleaveTemplet = $objSoapObject->IdleaveTemplet;
			if ((property_exists($objSoapObject, 'AppointmentCatObject')) &&
				($objSoapObject->AppointmentCatObject))
				$objToReturn->AppointmentCatObject = AppointmentCategory::GetObjectFromSoapObject($objSoapObject->AppointmentCatObject);
			if ((property_exists($objSoapObject, 'LeaveCatObject')) &&
				($objSoapObject->LeaveCatObject))
				$objToReturn->LeaveCatObject = LeaveCat::GetObjectFromSoapObject($objSoapObject->LeaveCatObject);
			if (property_exists($objSoapObject, 'LeaveCount'))
				$objToReturn->intLeaveCount = $objSoapObject->LeaveCount;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, LeaveTemplet::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objAppointmentCatObject)
				$objObject->objAppointmentCatObject = AppointmentCategory::GetSoapObjectFromObject($objObject->objAppointmentCatObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intAppointmentCat = null;
			if ($objObject->objLeaveCatObject)
				$objObject->objLeaveCatObject = LeaveCat::GetSoapObjectFromObject($objObject->objLeaveCatObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intLeaveCat = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdleaveTemplet'] = $this->intIdleaveTemplet;
			$iArray['AppointmentCat'] = $this->intAppointmentCat;
			$iArray['LeaveCat'] = $this->intLeaveCat;
			$iArray['LeaveCount'] = $this->intLeaveCount;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdleaveTemplet ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdleaveTemplet
     * @property-read QQNode $AppointmentCat
     * @property-read QQNodeAppointmentCategory $AppointmentCatObject
     * @property-read QQNode $LeaveCat
     * @property-read QQNodeLeaveCat $LeaveCatObject
     * @property-read QQNode $LeaveCount
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeLeaveTemplet extends QQNode {
		protected $strTableName = 'leave_templet';
		protected $strPrimaryKey = 'idleave_templet';
		protected $strClassName = 'LeaveTemplet';
		public function __get($strName) {
			switch ($strName) {
				case 'IdleaveTemplet':
					return new QQNode('idleave_templet', 'IdleaveTemplet', 'Integer', $this);
				case 'AppointmentCat':
					return new QQNode('appointment_cat', 'AppointmentCat', 'Integer', $this);
				case 'AppointmentCatObject':
					return new QQNodeAppointmentCategory('appointment_cat', 'AppointmentCatObject', 'Integer', $this);
				case 'LeaveCat':
					return new QQNode('leave_cat', 'LeaveCat', 'Integer', $this);
				case 'LeaveCatObject':
					return new QQNodeLeaveCat('leave_cat', 'LeaveCatObject', 'Integer', $this);
				case 'LeaveCount':
					return new QQNode('leave_count', 'LeaveCount', 'Integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idleave_templet', 'IdleaveTemplet', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdleaveTemplet
     * @property-read QQNode $AppointmentCat
     * @property-read QQNodeAppointmentCategory $AppointmentCatObject
     * @property-read QQNode $LeaveCat
     * @property-read QQNodeLeaveCat $LeaveCatObject
     * @property-read QQNode $LeaveCount
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeLeaveTemplet extends QQReverseReferenceNode {
		protected $strTableName = 'leave_templet';
		protected $strPrimaryKey = 'idleave_templet';
		protected $strClassName = 'LeaveTemplet';
		public function __get($strName) {
			switch ($strName) {
				case 'IdleaveTemplet':
					return new QQNode('idleave_templet', 'IdleaveTemplet', 'integer', $this);
				case 'AppointmentCat':
					return new QQNode('appointment_cat', 'AppointmentCat', 'integer', $this);
				case 'AppointmentCatObject':
					return new QQNodeAppointmentCategory('appointment_cat', 'AppointmentCatObject', 'integer', $this);
				case 'LeaveCat':
					return new QQNode('leave_cat', 'LeaveCat', 'integer', $this);
				case 'LeaveCatObject':
					return new QQNodeLeaveCat('leave_cat', 'LeaveCatObject', 'integer', $this);
				case 'LeaveCount':
					return new QQNode('leave_count', 'LeaveCount', 'integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idleave_templet', 'IdleaveTemplet', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
