<?php
	/**
	 * The abstract AcademicTempletGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the AcademicTemplet subclass which
	 * extends this AcademicTempletGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the AcademicTemplet class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property integer $Department the value for intDepartment (Not Null)
	 * @property integer $Academics the value for intAcademics (Not Null)
	 * @property integer $Seq the value for intSeq (Not Null)
	 * @property integer $Semister the value for intSemister (Not Null)
	 * @property-read integer $Id the value for intId (Read-Only PK)
	 * @property QDateTime $SemStartDate the value for dttSemStartDate 
	 * @property QDateTime $SemendDate the value for dttSemendDate 
	 * @property QDateTime $ExamStartDate the value for dttExamStartDate 
	 * @property QDateTime $ExamEndDate the value for dttExamEndDate 
	 * @property Role $DepartmentObject the value for the Role object referenced by intDepartment (Not Null)
	 * @property AcademicYear $AcademicsObject the value for the AcademicYear object referenced by intAcademics (Not Null)
	 * @property AcademicYear $SemisterObject the value for the AcademicYear object referenced by intSemister (Not Null)
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class AcademicTempletGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database column academic_templet.department
		 * @var integer intDepartment
		 */
		protected $intDepartment;
		const DepartmentDefault = null;


		/**
		 * Protected member variable that maps to the database column academic_templet.academics
		 * @var integer intAcademics
		 */
		protected $intAcademics;
		const AcademicsDefault = null;


		/**
		 * Protected member variable that maps to the database column academic_templet.seq
		 * @var integer intSeq
		 */
		protected $intSeq;
		const SeqDefault = null;


		/**
		 * Protected member variable that maps to the database column academic_templet.semister
		 * @var integer intSemister
		 */
		protected $intSemister;
		const SemisterDefault = null;


		/**
		 * Protected member variable that maps to the database PK Identity column academic_templet.id
		 * @var integer intId
		 */
		protected $intId;
		const IdDefault = null;


		/**
		 * Protected member variable that maps to the database column academic_templet.sem_start_date
		 * @var QDateTime dttSemStartDate
		 */
		protected $dttSemStartDate;
		const SemStartDateDefault = null;


		/**
		 * Protected member variable that maps to the database column academic_templet.semend_date
		 * @var QDateTime dttSemendDate
		 */
		protected $dttSemendDate;
		const SemendDateDefault = null;


		/**
		 * Protected member variable that maps to the database column academic_templet.exam_start_date
		 * @var QDateTime dttExamStartDate
		 */
		protected $dttExamStartDate;
		const ExamStartDateDefault = null;


		/**
		 * Protected member variable that maps to the database column academic_templet.exam_end_date
		 * @var QDateTime dttExamEndDate
		 */
		protected $dttExamEndDate;
		const ExamEndDateDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column academic_templet.department.
		 *
		 * NOTE: Always use the DepartmentObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objDepartmentObject
		 */
		protected $objDepartmentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column academic_templet.academics.
		 *
		 * NOTE: Always use the AcademicsObject property getter to correctly retrieve this AcademicYear object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var AcademicYear objAcademicsObject
		 */
		protected $objAcademicsObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column academic_templet.semister.
		 *
		 * NOTE: Always use the SemisterObject property getter to correctly retrieve this AcademicYear object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var AcademicYear objSemisterObject
		 */
		protected $objSemisterObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intDepartment = AcademicTemplet::DepartmentDefault;
			$this->intAcademics = AcademicTemplet::AcademicsDefault;
			$this->intSeq = AcademicTemplet::SeqDefault;
			$this->intSemister = AcademicTemplet::SemisterDefault;
			$this->intId = AcademicTemplet::IdDefault;
			$this->dttSemStartDate = (AcademicTemplet::SemStartDateDefault === null)?null:new QDateTime(AcademicTemplet::SemStartDateDefault);
			$this->dttSemendDate = (AcademicTemplet::SemendDateDefault === null)?null:new QDateTime(AcademicTemplet::SemendDateDefault);
			$this->dttExamStartDate = (AcademicTemplet::ExamStartDateDefault === null)?null:new QDateTime(AcademicTemplet::ExamStartDateDefault);
			$this->dttExamEndDate = (AcademicTemplet::ExamEndDateDefault === null)?null:new QDateTime(AcademicTemplet::ExamEndDateDefault);
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a AcademicTemplet from PK Info
		 * @param integer $intId
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AcademicTemplet
		 */
		public static function Load($intId, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'AcademicTemplet', $intId);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = AcademicTemplet::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::AcademicTemplet()->Id, $intId)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all AcademicTemplets
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AcademicTemplet[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call AcademicTemplet::QueryArray to perform the LoadAll query
			try {
				return AcademicTemplet::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all AcademicTemplets
		 * @return int
		 */
		public static function CountAll() {
			// Call AcademicTemplet::QueryCount to perform the CountAll query
			return AcademicTemplet::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = AcademicTemplet::GetDatabase();

			// Create/Build out the QueryBuilder object with AcademicTemplet-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'academic_templet');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				AcademicTemplet::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('academic_templet');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single AcademicTemplet object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return AcademicTemplet the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = AcademicTemplet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new AcademicTemplet object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = AcademicTemplet::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return AcademicTemplet::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of AcademicTemplet objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return AcademicTemplet[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = AcademicTemplet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return AcademicTemplet::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = AcademicTemplet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of AcademicTemplet objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = AcademicTemplet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = AcademicTemplet::GetDatabase();

			$strQuery = AcademicTemplet::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/academictemplet', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = AcademicTemplet::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this AcademicTemplet
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'academic_templet';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'id', $strAliasPrefix . 'id');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'department', $strAliasPrefix . 'department');
			    $objBuilder->AddSelectItem($strTableName, 'academics', $strAliasPrefix . 'academics');
			    $objBuilder->AddSelectItem($strTableName, 'seq', $strAliasPrefix . 'seq');
			    $objBuilder->AddSelectItem($strTableName, 'semister', $strAliasPrefix . 'semister');
			    $objBuilder->AddSelectItem($strTableName, 'id', $strAliasPrefix . 'id');
			    $objBuilder->AddSelectItem($strTableName, 'sem_start_date', $strAliasPrefix . 'sem_start_date');
			    $objBuilder->AddSelectItem($strTableName, 'semend_date', $strAliasPrefix . 'semend_date');
			    $objBuilder->AddSelectItem($strTableName, 'exam_start_date', $strAliasPrefix . 'exam_start_date');
			    $objBuilder->AddSelectItem($strTableName, 'exam_end_date', $strAliasPrefix . 'exam_end_date');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a AcademicTemplet from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this AcademicTemplet::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return AcademicTemplet
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the AcademicTemplet object
			$objToReturn = new AcademicTemplet();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'department';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDepartment = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'academics';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intAcademics = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'seq';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSeq = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'semister';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSemister = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'id';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intId = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'sem_start_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttSemStartDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'semend_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttSemendDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'exam_start_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttExamStartDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'exam_end_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttExamEndDate = $objDbRow->GetColumn($strAliasName, 'DateTime');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Id != $objPreviousItem->Id) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'academic_templet__';

			// Check for DepartmentObject Early Binding
			$strAlias = $strAliasPrefix . 'department__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDepartmentObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'department__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for AcademicsObject Early Binding
			$strAlias = $strAliasPrefix . 'academics__idacademic_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objAcademicsObject = AcademicYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'academics__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for SemisterObject Early Binding
			$strAlias = $strAliasPrefix . 'semister__idacademic_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSemisterObject = AcademicYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'semister__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of AcademicTemplets from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return AcademicTemplet[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = AcademicTemplet::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = AcademicTemplet::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single AcademicTemplet object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return AcademicTemplet next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return AcademicTemplet::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single AcademicTemplet object,
		 * by Id Index(es)
		 * @param integer $intId
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AcademicTemplet
		*/
		public static function LoadById($intId, $objOptionalClauses = null) {
			return AcademicTemplet::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::AcademicTemplet()->Id, $intId)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of AcademicTemplet objects,
		 * by Academics Index(es)
		 * @param integer $intAcademics
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AcademicTemplet[]
		*/
		public static function LoadArrayByAcademics($intAcademics, $objOptionalClauses = null) {
			// Call AcademicTemplet::QueryArray to perform the LoadArrayByAcademics query
			try {
				return AcademicTemplet::QueryArray(
					QQ::Equal(QQN::AcademicTemplet()->Academics, $intAcademics),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count AcademicTemplets
		 * by Academics Index(es)
		 * @param integer $intAcademics
		 * @return int
		*/
		public static function CountByAcademics($intAcademics) {
			// Call AcademicTemplet::QueryCount to perform the CountByAcademics query
			return AcademicTemplet::QueryCount(
				QQ::Equal(QQN::AcademicTemplet()->Academics, $intAcademics)
			);
		}

		/**
		 * Load an array of AcademicTemplet objects,
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AcademicTemplet[]
		*/
		public static function LoadArrayByDepartment($intDepartment, $objOptionalClauses = null) {
			// Call AcademicTemplet::QueryArray to perform the LoadArrayByDepartment query
			try {
				return AcademicTemplet::QueryArray(
					QQ::Equal(QQN::AcademicTemplet()->Department, $intDepartment),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count AcademicTemplets
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @return int
		*/
		public static function CountByDepartment($intDepartment) {
			// Call AcademicTemplet::QueryCount to perform the CountByDepartment query
			return AcademicTemplet::QueryCount(
				QQ::Equal(QQN::AcademicTemplet()->Department, $intDepartment)
			);
		}

		/**
		 * Load an array of AcademicTemplet objects,
		 * by Semister Index(es)
		 * @param integer $intSemister
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AcademicTemplet[]
		*/
		public static function LoadArrayBySemister($intSemister, $objOptionalClauses = null) {
			// Call AcademicTemplet::QueryArray to perform the LoadArrayBySemister query
			try {
				return AcademicTemplet::QueryArray(
					QQ::Equal(QQN::AcademicTemplet()->Semister, $intSemister),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count AcademicTemplets
		 * by Semister Index(es)
		 * @param integer $intSemister
		 * @return int
		*/
		public static function CountBySemister($intSemister) {
			// Call AcademicTemplet::QueryCount to perform the CountBySemister query
			return AcademicTemplet::QueryCount(
				QQ::Equal(QQN::AcademicTemplet()->Semister, $intSemister)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this AcademicTemplet
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = AcademicTemplet::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `academic_templet` (
							`department`,
							`academics`,
							`seq`,
							`semister`,
							`sem_start_date`,
							`semend_date`,
							`exam_start_date`,
							`exam_end_date`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intDepartment) . ',
							' . $objDatabase->SqlVariable($this->intAcademics) . ',
							' . $objDatabase->SqlVariable($this->intSeq) . ',
							' . $objDatabase->SqlVariable($this->intSemister) . ',
							' . $objDatabase->SqlVariable($this->dttSemStartDate) . ',
							' . $objDatabase->SqlVariable($this->dttSemendDate) . ',
							' . $objDatabase->SqlVariable($this->dttExamStartDate) . ',
							' . $objDatabase->SqlVariable($this->dttExamEndDate) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intId = $objDatabase->InsertId('academic_templet', 'id');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`academic_templet`
						SET
							`department` = ' . $objDatabase->SqlVariable($this->intDepartment) . ',
							`academics` = ' . $objDatabase->SqlVariable($this->intAcademics) . ',
							`seq` = ' . $objDatabase->SqlVariable($this->intSeq) . ',
							`semister` = ' . $objDatabase->SqlVariable($this->intSemister) . ',
							`sem_start_date` = ' . $objDatabase->SqlVariable($this->dttSemStartDate) . ',
							`semend_date` = ' . $objDatabase->SqlVariable($this->dttSemendDate) . ',
							`exam_start_date` = ' . $objDatabase->SqlVariable($this->dttExamStartDate) . ',
							`exam_end_date` = ' . $objDatabase->SqlVariable($this->dttExamEndDate) . '
						WHERE
							`id` = ' . $objDatabase->SqlVariable($this->intId) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this AcademicTemplet
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intId)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this AcademicTemplet with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = AcademicTemplet::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`academic_templet`
				WHERE
					`id` = ' . $objDatabase->SqlVariable($this->intId) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this AcademicTemplet ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'AcademicTemplet', $this->intId);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all AcademicTemplets
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = AcademicTemplet::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`academic_templet`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate academic_templet table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = AcademicTemplet::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `academic_templet`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this AcademicTemplet from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved AcademicTemplet object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = AcademicTemplet::Load($this->intId);

			// Update $this's local variables to match
			$this->Department = $objReloaded->Department;
			$this->Academics = $objReloaded->Academics;
			$this->intSeq = $objReloaded->intSeq;
			$this->Semister = $objReloaded->Semister;
			$this->dttSemStartDate = $objReloaded->dttSemStartDate;
			$this->dttSemendDate = $objReloaded->dttSemendDate;
			$this->dttExamStartDate = $objReloaded->dttExamStartDate;
			$this->dttExamEndDate = $objReloaded->dttExamEndDate;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Department':
					/**
					 * Gets the value for intDepartment (Not Null)
					 * @return integer
					 */
					return $this->intDepartment;

				case 'Academics':
					/**
					 * Gets the value for intAcademics (Not Null)
					 * @return integer
					 */
					return $this->intAcademics;

				case 'Seq':
					/**
					 * Gets the value for intSeq (Not Null)
					 * @return integer
					 */
					return $this->intSeq;

				case 'Semister':
					/**
					 * Gets the value for intSemister (Not Null)
					 * @return integer
					 */
					return $this->intSemister;

				case 'Id':
					/**
					 * Gets the value for intId (Read-Only PK)
					 * @return integer
					 */
					return $this->intId;

				case 'SemStartDate':
					/**
					 * Gets the value for dttSemStartDate 
					 * @return QDateTime
					 */
					return $this->dttSemStartDate;

				case 'SemendDate':
					/**
					 * Gets the value for dttSemendDate 
					 * @return QDateTime
					 */
					return $this->dttSemendDate;

				case 'ExamStartDate':
					/**
					 * Gets the value for dttExamStartDate 
					 * @return QDateTime
					 */
					return $this->dttExamStartDate;

				case 'ExamEndDate':
					/**
					 * Gets the value for dttExamEndDate 
					 * @return QDateTime
					 */
					return $this->dttExamEndDate;


				///////////////////
				// Member Objects
				///////////////////
				case 'DepartmentObject':
					/**
					 * Gets the value for the Role object referenced by intDepartment (Not Null)
					 * @return Role
					 */
					try {
						if ((!$this->objDepartmentObject) && (!is_null($this->intDepartment)))
							$this->objDepartmentObject = Role::Load($this->intDepartment);
						return $this->objDepartmentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AcademicsObject':
					/**
					 * Gets the value for the AcademicYear object referenced by intAcademics (Not Null)
					 * @return AcademicYear
					 */
					try {
						if ((!$this->objAcademicsObject) && (!is_null($this->intAcademics)))
							$this->objAcademicsObject = AcademicYear::Load($this->intAcademics);
						return $this->objAcademicsObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SemisterObject':
					/**
					 * Gets the value for the AcademicYear object referenced by intSemister (Not Null)
					 * @return AcademicYear
					 */
					try {
						if ((!$this->objSemisterObject) && (!is_null($this->intSemister)))
							$this->objSemisterObject = AcademicYear::Load($this->intSemister);
						return $this->objSemisterObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Department':
					/**
					 * Sets the value for intDepartment (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDepartmentObject = null;
						return ($this->intDepartment = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Academics':
					/**
					 * Sets the value for intAcademics (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objAcademicsObject = null;
						return ($this->intAcademics = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Seq':
					/**
					 * Sets the value for intSeq (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intSeq = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Semister':
					/**
					 * Sets the value for intSemister (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSemisterObject = null;
						return ($this->intSemister = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SemStartDate':
					/**
					 * Sets the value for dttSemStartDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttSemStartDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SemendDate':
					/**
					 * Sets the value for dttSemendDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttSemendDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ExamStartDate':
					/**
					 * Sets the value for dttExamStartDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttExamStartDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ExamEndDate':
					/**
					 * Sets the value for dttExamEndDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttExamEndDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'DepartmentObject':
					/**
					 * Sets the value for the Role object referenced by intDepartment (Not Null)
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intDepartment = null;
						$this->objDepartmentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved DepartmentObject for this AcademicTemplet');

						// Update Local Member Variables
						$this->objDepartmentObject = $mixValue;
						$this->intDepartment = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'AcademicsObject':
					/**
					 * Sets the value for the AcademicYear object referenced by intAcademics (Not Null)
					 * @param AcademicYear $mixValue
					 * @return AcademicYear
					 */
					if (is_null($mixValue)) {
						$this->intAcademics = null;
						$this->objAcademicsObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a AcademicYear object
						try {
							$mixValue = QType::Cast($mixValue, 'AcademicYear');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED AcademicYear object
						if (is_null($mixValue->IdacademicYear))
							throw new QCallerException('Unable to set an unsaved AcademicsObject for this AcademicTemplet');

						// Update Local Member Variables
						$this->objAcademicsObject = $mixValue;
						$this->intAcademics = $mixValue->IdacademicYear;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'SemisterObject':
					/**
					 * Sets the value for the AcademicYear object referenced by intSemister (Not Null)
					 * @param AcademicYear $mixValue
					 * @return AcademicYear
					 */
					if (is_null($mixValue)) {
						$this->intSemister = null;
						$this->objSemisterObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a AcademicYear object
						try {
							$mixValue = QType::Cast($mixValue, 'AcademicYear');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED AcademicYear object
						if (is_null($mixValue->IdacademicYear))
							throw new QCallerException('Unable to set an unsaved SemisterObject for this AcademicTemplet');

						// Update Local Member Variables
						$this->objSemisterObject = $mixValue;
						$this->intSemister = $mixValue->IdacademicYear;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "academic_templet";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[AcademicTemplet::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="AcademicTemplet"><sequence>';
			$strToReturn .= '<element name="DepartmentObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="AcademicsObject" type="xsd1:AcademicYear"/>';
			$strToReturn .= '<element name="Seq" type="xsd:int"/>';
			$strToReturn .= '<element name="SemisterObject" type="xsd1:AcademicYear"/>';
			$strToReturn .= '<element name="Id" type="xsd:int"/>';
			$strToReturn .= '<element name="SemStartDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="SemendDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="ExamStartDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="ExamEndDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('AcademicTemplet', $strComplexTypeArray)) {
				$strComplexTypeArray['AcademicTemplet'] = AcademicTemplet::GetSoapComplexTypeXml();
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				AcademicYear::AlterSoapComplexTypeArray($strComplexTypeArray);
				AcademicYear::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, AcademicTemplet::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new AcademicTemplet();
			if ((property_exists($objSoapObject, 'DepartmentObject')) &&
				($objSoapObject->DepartmentObject))
				$objToReturn->DepartmentObject = Role::GetObjectFromSoapObject($objSoapObject->DepartmentObject);
			if ((property_exists($objSoapObject, 'AcademicsObject')) &&
				($objSoapObject->AcademicsObject))
				$objToReturn->AcademicsObject = AcademicYear::GetObjectFromSoapObject($objSoapObject->AcademicsObject);
			if (property_exists($objSoapObject, 'Seq'))
				$objToReturn->intSeq = $objSoapObject->Seq;
			if ((property_exists($objSoapObject, 'SemisterObject')) &&
				($objSoapObject->SemisterObject))
				$objToReturn->SemisterObject = AcademicYear::GetObjectFromSoapObject($objSoapObject->SemisterObject);
			if (property_exists($objSoapObject, 'Id'))
				$objToReturn->intId = $objSoapObject->Id;
			if (property_exists($objSoapObject, 'SemStartDate'))
				$objToReturn->dttSemStartDate = new QDateTime($objSoapObject->SemStartDate);
			if (property_exists($objSoapObject, 'SemendDate'))
				$objToReturn->dttSemendDate = new QDateTime($objSoapObject->SemendDate);
			if (property_exists($objSoapObject, 'ExamStartDate'))
				$objToReturn->dttExamStartDate = new QDateTime($objSoapObject->ExamStartDate);
			if (property_exists($objSoapObject, 'ExamEndDate'))
				$objToReturn->dttExamEndDate = new QDateTime($objSoapObject->ExamEndDate);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, AcademicTemplet::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objDepartmentObject)
				$objObject->objDepartmentObject = Role::GetSoapObjectFromObject($objObject->objDepartmentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDepartment = null;
			if ($objObject->objAcademicsObject)
				$objObject->objAcademicsObject = AcademicYear::GetSoapObjectFromObject($objObject->objAcademicsObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intAcademics = null;
			if ($objObject->objSemisterObject)
				$objObject->objSemisterObject = AcademicYear::GetSoapObjectFromObject($objObject->objSemisterObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSemister = null;
			if ($objObject->dttSemStartDate)
				$objObject->dttSemStartDate = $objObject->dttSemStartDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttSemendDate)
				$objObject->dttSemendDate = $objObject->dttSemendDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttExamStartDate)
				$objObject->dttExamStartDate = $objObject->dttExamStartDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttExamEndDate)
				$objObject->dttExamEndDate = $objObject->dttExamEndDate->qFormat(QDateTime::FormatSoap);
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Department'] = $this->intDepartment;
			$iArray['Academics'] = $this->intAcademics;
			$iArray['Seq'] = $this->intSeq;
			$iArray['Semister'] = $this->intSemister;
			$iArray['Id'] = $this->intId;
			$iArray['SemStartDate'] = $this->dttSemStartDate;
			$iArray['SemendDate'] = $this->dttSemendDate;
			$iArray['ExamStartDate'] = $this->dttExamStartDate;
			$iArray['ExamEndDate'] = $this->dttExamEndDate;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intId ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $Academics
     * @property-read QQNodeAcademicYear $AcademicsObject
     * @property-read QQNode $Seq
     * @property-read QQNode $Semister
     * @property-read QQNodeAcademicYear $SemisterObject
     * @property-read QQNode $Id
     * @property-read QQNode $SemStartDate
     * @property-read QQNode $SemendDate
     * @property-read QQNode $ExamStartDate
     * @property-read QQNode $ExamEndDate
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeAcademicTemplet extends QQNode {
		protected $strTableName = 'academic_templet';
		protected $strPrimaryKey = 'id';
		protected $strClassName = 'AcademicTemplet';
		public function __get($strName) {
			switch ($strName) {
				case 'Department':
					return new QQNode('department', 'Department', 'Integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'Integer', $this);
				case 'Academics':
					return new QQNode('academics', 'Academics', 'Integer', $this);
				case 'AcademicsObject':
					return new QQNodeAcademicYear('academics', 'AcademicsObject', 'Integer', $this);
				case 'Seq':
					return new QQNode('seq', 'Seq', 'Integer', $this);
				case 'Semister':
					return new QQNode('semister', 'Semister', 'Integer', $this);
				case 'SemisterObject':
					return new QQNodeAcademicYear('semister', 'SemisterObject', 'Integer', $this);
				case 'Id':
					return new QQNode('id', 'Id', 'Integer', $this);
				case 'SemStartDate':
					return new QQNode('sem_start_date', 'SemStartDate', 'DateTime', $this);
				case 'SemendDate':
					return new QQNode('semend_date', 'SemendDate', 'DateTime', $this);
				case 'ExamStartDate':
					return new QQNode('exam_start_date', 'ExamStartDate', 'DateTime', $this);
				case 'ExamEndDate':
					return new QQNode('exam_end_date', 'ExamEndDate', 'DateTime', $this);

				case '_PrimaryKeyNode':
					return new QQNode('id', 'Id', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $Academics
     * @property-read QQNodeAcademicYear $AcademicsObject
     * @property-read QQNode $Seq
     * @property-read QQNode $Semister
     * @property-read QQNodeAcademicYear $SemisterObject
     * @property-read QQNode $Id
     * @property-read QQNode $SemStartDate
     * @property-read QQNode $SemendDate
     * @property-read QQNode $ExamStartDate
     * @property-read QQNode $ExamEndDate
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeAcademicTemplet extends QQReverseReferenceNode {
		protected $strTableName = 'academic_templet';
		protected $strPrimaryKey = 'id';
		protected $strClassName = 'AcademicTemplet';
		public function __get($strName) {
			switch ($strName) {
				case 'Department':
					return new QQNode('department', 'Department', 'integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'integer', $this);
				case 'Academics':
					return new QQNode('academics', 'Academics', 'integer', $this);
				case 'AcademicsObject':
					return new QQNodeAcademicYear('academics', 'AcademicsObject', 'integer', $this);
				case 'Seq':
					return new QQNode('seq', 'Seq', 'integer', $this);
				case 'Semister':
					return new QQNode('semister', 'Semister', 'integer', $this);
				case 'SemisterObject':
					return new QQNodeAcademicYear('semister', 'SemisterObject', 'integer', $this);
				case 'Id':
					return new QQNode('id', 'Id', 'integer', $this);
				case 'SemStartDate':
					return new QQNode('sem_start_date', 'SemStartDate', 'QDateTime', $this);
				case 'SemendDate':
					return new QQNode('semend_date', 'SemendDate', 'QDateTime', $this);
				case 'ExamStartDate':
					return new QQNode('exam_start_date', 'ExamStartDate', 'QDateTime', $this);
				case 'ExamEndDate':
					return new QQNode('exam_end_date', 'ExamEndDate', 'QDateTime', $this);

				case '_PrimaryKeyNode':
					return new QQNode('id', 'Id', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
