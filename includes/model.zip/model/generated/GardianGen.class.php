<?php
	/**
	 * The abstract GardianGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Gardian subclass which
	 * extends this GardianGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Gardian class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idgardian the value for intIdgardian (Read-Only PK)
	 * @property integer $Of the value for intOf 
	 * @property string $GardianName the value for strGardianName 
	 * @property string $GardianOccupation the value for strGardianOccupation 
	 * @property string $RelationOfGardian the value for strRelationOfGardian 
	 * @property string $GardianAddress the value for strGardianAddress 
	 * @property integer $GardianState the value for intGardianState 
	 * @property string $GardianContact the value for strGardianContact 
	 * @property string $GardianEmail the value for strGardianEmail 
	 * @property integer $GardianCat the value for intGardianCat 
	 * @property integer $GardianDistrict the value for intGardianDistrict 
	 * @property integer $GardianTaluka the value for intGardianTaluka 
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class GardianGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column gardian.idgardian
		 * @var integer intIdgardian
		 */
		protected $intIdgardian;
		const IdgardianDefault = null;


		/**
		 * Protected member variable that maps to the database column gardian.of
		 * @var integer intOf
		 */
		protected $intOf;
		const OfDefault = null;


		/**
		 * Protected member variable that maps to the database column gardian.gardian_name
		 * @var string strGardianName
		 */
		protected $strGardianName;
		const GardianNameMaxLength = 255;
		const GardianNameDefault = null;


		/**
		 * Protected member variable that maps to the database column gardian.gardian_occupation
		 * @var string strGardianOccupation
		 */
		protected $strGardianOccupation;
		const GardianOccupationMaxLength = 45;
		const GardianOccupationDefault = null;


		/**
		 * Protected member variable that maps to the database column gardian.relation_of_gardian
		 * @var string strRelationOfGardian
		 */
		protected $strRelationOfGardian;
		const RelationOfGardianMaxLength = 45;
		const RelationOfGardianDefault = null;


		/**
		 * Protected member variable that maps to the database column gardian.gardian_address
		 * @var string strGardianAddress
		 */
		protected $strGardianAddress;
		const GardianAddressDefault = null;


		/**
		 * Protected member variable that maps to the database column gardian.gardian_state
		 * @var integer intGardianState
		 */
		protected $intGardianState;
		const GardianStateDefault = null;


		/**
		 * Protected member variable that maps to the database column gardian.gardian_contact
		 * @var string strGardianContact
		 */
		protected $strGardianContact;
		const GardianContactMaxLength = 45;
		const GardianContactDefault = null;


		/**
		 * Protected member variable that maps to the database column gardian.gardian_email
		 * @var string strGardianEmail
		 */
		protected $strGardianEmail;
		const GardianEmailMaxLength = 255;
		const GardianEmailDefault = null;


		/**
		 * Protected member variable that maps to the database column gardian.gardian_cat
		 * @var integer intGardianCat
		 */
		protected $intGardianCat;
		const GardianCatDefault = null;


		/**
		 * Protected member variable that maps to the database column gardian.gardian_district
		 * @var integer intGardianDistrict
		 */
		protected $intGardianDistrict;
		const GardianDistrictDefault = null;


		/**
		 * Protected member variable that maps to the database column gardian.gardian_taluka
		 * @var integer intGardianTaluka
		 */
		protected $intGardianTaluka;
		const GardianTalukaDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdgardian = Gardian::IdgardianDefault;
			$this->intOf = Gardian::OfDefault;
			$this->strGardianName = Gardian::GardianNameDefault;
			$this->strGardianOccupation = Gardian::GardianOccupationDefault;
			$this->strRelationOfGardian = Gardian::RelationOfGardianDefault;
			$this->strGardianAddress = Gardian::GardianAddressDefault;
			$this->intGardianState = Gardian::GardianStateDefault;
			$this->strGardianContact = Gardian::GardianContactDefault;
			$this->strGardianEmail = Gardian::GardianEmailDefault;
			$this->intGardianCat = Gardian::GardianCatDefault;
			$this->intGardianDistrict = Gardian::GardianDistrictDefault;
			$this->intGardianTaluka = Gardian::GardianTalukaDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Gardian from PK Info
		 * @param integer $intIdgardian
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Gardian
		 */
		public static function Load($intIdgardian, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Gardian', $intIdgardian);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Gardian::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Gardian()->Idgardian, $intIdgardian)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Gardians
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Gardian[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Gardian::QueryArray to perform the LoadAll query
			try {
				return Gardian::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Gardians
		 * @return int
		 */
		public static function CountAll() {
			// Call Gardian::QueryCount to perform the CountAll query
			return Gardian::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Gardian::GetDatabase();

			// Create/Build out the QueryBuilder object with Gardian-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'gardian');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Gardian::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('gardian');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Gardian object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Gardian the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Gardian::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Gardian object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Gardian::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Gardian::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Gardian objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Gardian[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Gardian::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Gardian::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Gardian::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Gardian objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Gardian::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Gardian::GetDatabase();

			$strQuery = Gardian::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/gardian', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Gardian::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Gardian
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'gardian';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idgardian', $strAliasPrefix . 'idgardian');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idgardian', $strAliasPrefix . 'idgardian');
			    $objBuilder->AddSelectItem($strTableName, 'of', $strAliasPrefix . 'of');
			    $objBuilder->AddSelectItem($strTableName, 'gardian_name', $strAliasPrefix . 'gardian_name');
			    $objBuilder->AddSelectItem($strTableName, 'gardian_occupation', $strAliasPrefix . 'gardian_occupation');
			    $objBuilder->AddSelectItem($strTableName, 'relation_of_gardian', $strAliasPrefix . 'relation_of_gardian');
			    $objBuilder->AddSelectItem($strTableName, 'gardian_address', $strAliasPrefix . 'gardian_address');
			    $objBuilder->AddSelectItem($strTableName, 'gardian_state', $strAliasPrefix . 'gardian_state');
			    $objBuilder->AddSelectItem($strTableName, 'gardian_contact', $strAliasPrefix . 'gardian_contact');
			    $objBuilder->AddSelectItem($strTableName, 'gardian_email', $strAliasPrefix . 'gardian_email');
			    $objBuilder->AddSelectItem($strTableName, 'gardian_cat', $strAliasPrefix . 'gardian_cat');
			    $objBuilder->AddSelectItem($strTableName, 'gardian_district', $strAliasPrefix . 'gardian_district');
			    $objBuilder->AddSelectItem($strTableName, 'gardian_taluka', $strAliasPrefix . 'gardian_taluka');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Gardian from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Gardian::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Gardian
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the Gardian object
			$objToReturn = new Gardian();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idgardian';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdgardian = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'of';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intOf = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'gardian_name';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strGardianName = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'gardian_occupation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strGardianOccupation = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'relation_of_gardian';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strRelationOfGardian = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'gardian_address';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strGardianAddress = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'gardian_state';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intGardianState = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'gardian_contact';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strGardianContact = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'gardian_email';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strGardianEmail = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'gardian_cat';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intGardianCat = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'gardian_district';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intGardianDistrict = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'gardian_taluka';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intGardianTaluka = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idgardian != $objPreviousItem->Idgardian) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'gardian__';




			return $objToReturn;
		}

		/**
		 * Instantiate an array of Gardians from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Gardian[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Gardian::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Gardian::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Gardian object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Gardian next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Gardian::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Gardian object,
		 * by Idgardian Index(es)
		 * @param integer $intIdgardian
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Gardian
		*/
		public static function LoadByIdgardian($intIdgardian, $objOptionalClauses = null) {
			return Gardian::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Gardian()->Idgardian, $intIdgardian)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Gardian objects,
		 * by GardianState Index(es)
		 * @param integer $intGardianState
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Gardian[]
		*/
		public static function LoadArrayByGardianState($intGardianState, $objOptionalClauses = null) {
			// Call Gardian::QueryArray to perform the LoadArrayByGardianState query
			try {
				return Gardian::QueryArray(
					QQ::Equal(QQN::Gardian()->GardianState, $intGardianState),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Gardians
		 * by GardianState Index(es)
		 * @param integer $intGardianState
		 * @return int
		*/
		public static function CountByGardianState($intGardianState) {
			// Call Gardian::QueryCount to perform the CountByGardianState query
			return Gardian::QueryCount(
				QQ::Equal(QQN::Gardian()->GardianState, $intGardianState)
			);
		}

		/**
		 * Load an array of Gardian objects,
		 * by GardianCat Index(es)
		 * @param integer $intGardianCat
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Gardian[]
		*/
		public static function LoadArrayByGardianCat($intGardianCat, $objOptionalClauses = null) {
			// Call Gardian::QueryArray to perform the LoadArrayByGardianCat query
			try {
				return Gardian::QueryArray(
					QQ::Equal(QQN::Gardian()->GardianCat, $intGardianCat),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Gardians
		 * by GardianCat Index(es)
		 * @param integer $intGardianCat
		 * @return int
		*/
		public static function CountByGardianCat($intGardianCat) {
			// Call Gardian::QueryCount to perform the CountByGardianCat query
			return Gardian::QueryCount(
				QQ::Equal(QQN::Gardian()->GardianCat, $intGardianCat)
			);
		}

		/**
		 * Load an array of Gardian objects,
		 * by Of Index(es)
		 * @param integer $intOf
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Gardian[]
		*/
		public static function LoadArrayByOf($intOf, $objOptionalClauses = null) {
			// Call Gardian::QueryArray to perform the LoadArrayByOf query
			try {
				return Gardian::QueryArray(
					QQ::Equal(QQN::Gardian()->Of, $intOf),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Gardians
		 * by Of Index(es)
		 * @param integer $intOf
		 * @return int
		*/
		public static function CountByOf($intOf) {
			// Call Gardian::QueryCount to perform the CountByOf query
			return Gardian::QueryCount(
				QQ::Equal(QQN::Gardian()->Of, $intOf)
			);
		}

		/**
		 * Load an array of Gardian objects,
		 * by GardianTaluka Index(es)
		 * @param integer $intGardianTaluka
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Gardian[]
		*/
		public static function LoadArrayByGardianTaluka($intGardianTaluka, $objOptionalClauses = null) {
			// Call Gardian::QueryArray to perform the LoadArrayByGardianTaluka query
			try {
				return Gardian::QueryArray(
					QQ::Equal(QQN::Gardian()->GardianTaluka, $intGardianTaluka),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Gardians
		 * by GardianTaluka Index(es)
		 * @param integer $intGardianTaluka
		 * @return int
		*/
		public static function CountByGardianTaluka($intGardianTaluka) {
			// Call Gardian::QueryCount to perform the CountByGardianTaluka query
			return Gardian::QueryCount(
				QQ::Equal(QQN::Gardian()->GardianTaluka, $intGardianTaluka)
			);
		}

		/**
		 * Load an array of Gardian objects,
		 * by GardianDistrict Index(es)
		 * @param integer $intGardianDistrict
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Gardian[]
		*/
		public static function LoadArrayByGardianDistrict($intGardianDistrict, $objOptionalClauses = null) {
			// Call Gardian::QueryArray to perform the LoadArrayByGardianDistrict query
			try {
				return Gardian::QueryArray(
					QQ::Equal(QQN::Gardian()->GardianDistrict, $intGardianDistrict),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Gardians
		 * by GardianDistrict Index(es)
		 * @param integer $intGardianDistrict
		 * @return int
		*/
		public static function CountByGardianDistrict($intGardianDistrict) {
			// Call Gardian::QueryCount to perform the CountByGardianDistrict query
			return Gardian::QueryCount(
				QQ::Equal(QQN::Gardian()->GardianDistrict, $intGardianDistrict)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Gardian
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Gardian::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `gardian` (
							`of`,
							`gardian_name`,
							`gardian_occupation`,
							`relation_of_gardian`,
							`gardian_address`,
							`gardian_state`,
							`gardian_contact`,
							`gardian_email`,
							`gardian_cat`,
							`gardian_district`,
							`gardian_taluka`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intOf) . ',
							' . $objDatabase->SqlVariable($this->strGardianName) . ',
							' . $objDatabase->SqlVariable($this->strGardianOccupation) . ',
							' . $objDatabase->SqlVariable($this->strRelationOfGardian) . ',
							' . $objDatabase->SqlVariable($this->strGardianAddress) . ',
							' . $objDatabase->SqlVariable($this->intGardianState) . ',
							' . $objDatabase->SqlVariable($this->strGardianContact) . ',
							' . $objDatabase->SqlVariable($this->strGardianEmail) . ',
							' . $objDatabase->SqlVariable($this->intGardianCat) . ',
							' . $objDatabase->SqlVariable($this->intGardianDistrict) . ',
							' . $objDatabase->SqlVariable($this->intGardianTaluka) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdgardian = $objDatabase->InsertId('gardian', 'idgardian');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`gardian`
						SET
							`of` = ' . $objDatabase->SqlVariable($this->intOf) . ',
							`gardian_name` = ' . $objDatabase->SqlVariable($this->strGardianName) . ',
							`gardian_occupation` = ' . $objDatabase->SqlVariable($this->strGardianOccupation) . ',
							`relation_of_gardian` = ' . $objDatabase->SqlVariable($this->strRelationOfGardian) . ',
							`gardian_address` = ' . $objDatabase->SqlVariable($this->strGardianAddress) . ',
							`gardian_state` = ' . $objDatabase->SqlVariable($this->intGardianState) . ',
							`gardian_contact` = ' . $objDatabase->SqlVariable($this->strGardianContact) . ',
							`gardian_email` = ' . $objDatabase->SqlVariable($this->strGardianEmail) . ',
							`gardian_cat` = ' . $objDatabase->SqlVariable($this->intGardianCat) . ',
							`gardian_district` = ' . $objDatabase->SqlVariable($this->intGardianDistrict) . ',
							`gardian_taluka` = ' . $objDatabase->SqlVariable($this->intGardianTaluka) . '
						WHERE
							`idgardian` = ' . $objDatabase->SqlVariable($this->intIdgardian) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Gardian
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdgardian)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Gardian with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Gardian::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`gardian`
				WHERE
					`idgardian` = ' . $objDatabase->SqlVariable($this->intIdgardian) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Gardian ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Gardian', $this->intIdgardian);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Gardians
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Gardian::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`gardian`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate gardian table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Gardian::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `gardian`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Gardian from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Gardian object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Gardian::Load($this->intIdgardian);

			// Update $this's local variables to match
			$this->intOf = $objReloaded->intOf;
			$this->strGardianName = $objReloaded->strGardianName;
			$this->strGardianOccupation = $objReloaded->strGardianOccupation;
			$this->strRelationOfGardian = $objReloaded->strRelationOfGardian;
			$this->strGardianAddress = $objReloaded->strGardianAddress;
			$this->intGardianState = $objReloaded->intGardianState;
			$this->strGardianContact = $objReloaded->strGardianContact;
			$this->strGardianEmail = $objReloaded->strGardianEmail;
			$this->intGardianCat = $objReloaded->intGardianCat;
			$this->intGardianDistrict = $objReloaded->intGardianDistrict;
			$this->intGardianTaluka = $objReloaded->intGardianTaluka;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idgardian':
					/**
					 * Gets the value for intIdgardian (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdgardian;

				case 'Of':
					/**
					 * Gets the value for intOf 
					 * @return integer
					 */
					return $this->intOf;

				case 'GardianName':
					/**
					 * Gets the value for strGardianName 
					 * @return string
					 */
					return $this->strGardianName;

				case 'GardianOccupation':
					/**
					 * Gets the value for strGardianOccupation 
					 * @return string
					 */
					return $this->strGardianOccupation;

				case 'RelationOfGardian':
					/**
					 * Gets the value for strRelationOfGardian 
					 * @return string
					 */
					return $this->strRelationOfGardian;

				case 'GardianAddress':
					/**
					 * Gets the value for strGardianAddress 
					 * @return string
					 */
					return $this->strGardianAddress;

				case 'GardianState':
					/**
					 * Gets the value for intGardianState 
					 * @return integer
					 */
					return $this->intGardianState;

				case 'GardianContact':
					/**
					 * Gets the value for strGardianContact 
					 * @return string
					 */
					return $this->strGardianContact;

				case 'GardianEmail':
					/**
					 * Gets the value for strGardianEmail 
					 * @return string
					 */
					return $this->strGardianEmail;

				case 'GardianCat':
					/**
					 * Gets the value for intGardianCat 
					 * @return integer
					 */
					return $this->intGardianCat;

				case 'GardianDistrict':
					/**
					 * Gets the value for intGardianDistrict 
					 * @return integer
					 */
					return $this->intGardianDistrict;

				case 'GardianTaluka':
					/**
					 * Gets the value for intGardianTaluka 
					 * @return integer
					 */
					return $this->intGardianTaluka;


				///////////////////
				// Member Objects
				///////////////////

				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Of':
					/**
					 * Sets the value for intOf 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intOf = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GardianName':
					/**
					 * Sets the value for strGardianName 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strGardianName = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GardianOccupation':
					/**
					 * Sets the value for strGardianOccupation 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strGardianOccupation = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RelationOfGardian':
					/**
					 * Sets the value for strRelationOfGardian 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strRelationOfGardian = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GardianAddress':
					/**
					 * Sets the value for strGardianAddress 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strGardianAddress = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GardianState':
					/**
					 * Sets the value for intGardianState 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intGardianState = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GardianContact':
					/**
					 * Sets the value for strGardianContact 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strGardianContact = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GardianEmail':
					/**
					 * Sets the value for strGardianEmail 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strGardianEmail = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GardianCat':
					/**
					 * Sets the value for intGardianCat 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intGardianCat = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GardianDistrict':
					/**
					 * Sets the value for intGardianDistrict 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intGardianDistrict = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GardianTaluka':
					/**
					 * Sets the value for intGardianTaluka 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intGardianTaluka = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "gardian";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Gardian::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Gardian"><sequence>';
			$strToReturn .= '<element name="Idgardian" type="xsd:int"/>';
			$strToReturn .= '<element name="Of" type="xsd:int"/>';
			$strToReturn .= '<element name="GardianName" type="xsd:string"/>';
			$strToReturn .= '<element name="GardianOccupation" type="xsd:string"/>';
			$strToReturn .= '<element name="RelationOfGardian" type="xsd:string"/>';
			$strToReturn .= '<element name="GardianAddress" type="xsd:string"/>';
			$strToReturn .= '<element name="GardianState" type="xsd:int"/>';
			$strToReturn .= '<element name="GardianContact" type="xsd:string"/>';
			$strToReturn .= '<element name="GardianEmail" type="xsd:string"/>';
			$strToReturn .= '<element name="GardianCat" type="xsd:int"/>';
			$strToReturn .= '<element name="GardianDistrict" type="xsd:int"/>';
			$strToReturn .= '<element name="GardianTaluka" type="xsd:int"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Gardian', $strComplexTypeArray)) {
				$strComplexTypeArray['Gardian'] = Gardian::GetSoapComplexTypeXml();
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Gardian::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Gardian();
			if (property_exists($objSoapObject, 'Idgardian'))
				$objToReturn->intIdgardian = $objSoapObject->Idgardian;
			if (property_exists($objSoapObject, 'Of'))
				$objToReturn->intOf = $objSoapObject->Of;
			if (property_exists($objSoapObject, 'GardianName'))
				$objToReturn->strGardianName = $objSoapObject->GardianName;
			if (property_exists($objSoapObject, 'GardianOccupation'))
				$objToReturn->strGardianOccupation = $objSoapObject->GardianOccupation;
			if (property_exists($objSoapObject, 'RelationOfGardian'))
				$objToReturn->strRelationOfGardian = $objSoapObject->RelationOfGardian;
			if (property_exists($objSoapObject, 'GardianAddress'))
				$objToReturn->strGardianAddress = $objSoapObject->GardianAddress;
			if (property_exists($objSoapObject, 'GardianState'))
				$objToReturn->intGardianState = $objSoapObject->GardianState;
			if (property_exists($objSoapObject, 'GardianContact'))
				$objToReturn->strGardianContact = $objSoapObject->GardianContact;
			if (property_exists($objSoapObject, 'GardianEmail'))
				$objToReturn->strGardianEmail = $objSoapObject->GardianEmail;
			if (property_exists($objSoapObject, 'GardianCat'))
				$objToReturn->intGardianCat = $objSoapObject->GardianCat;
			if (property_exists($objSoapObject, 'GardianDistrict'))
				$objToReturn->intGardianDistrict = $objSoapObject->GardianDistrict;
			if (property_exists($objSoapObject, 'GardianTaluka'))
				$objToReturn->intGardianTaluka = $objSoapObject->GardianTaluka;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Gardian::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idgardian'] = $this->intIdgardian;
			$iArray['Of'] = $this->intOf;
			$iArray['GardianName'] = $this->strGardianName;
			$iArray['GardianOccupation'] = $this->strGardianOccupation;
			$iArray['RelationOfGardian'] = $this->strRelationOfGardian;
			$iArray['GardianAddress'] = $this->strGardianAddress;
			$iArray['GardianState'] = $this->intGardianState;
			$iArray['GardianContact'] = $this->strGardianContact;
			$iArray['GardianEmail'] = $this->strGardianEmail;
			$iArray['GardianCat'] = $this->intGardianCat;
			$iArray['GardianDistrict'] = $this->intGardianDistrict;
			$iArray['GardianTaluka'] = $this->intGardianTaluka;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdgardian ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idgardian
     * @property-read QQNode $Of
     * @property-read QQNode $GardianName
     * @property-read QQNode $GardianOccupation
     * @property-read QQNode $RelationOfGardian
     * @property-read QQNode $GardianAddress
     * @property-read QQNode $GardianState
     * @property-read QQNode $GardianContact
     * @property-read QQNode $GardianEmail
     * @property-read QQNode $GardianCat
     * @property-read QQNode $GardianDistrict
     * @property-read QQNode $GardianTaluka
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeGardian extends QQNode {
		protected $strTableName = 'gardian';
		protected $strPrimaryKey = 'idgardian';
		protected $strClassName = 'Gardian';
		public function __get($strName) {
			switch ($strName) {
				case 'Idgardian':
					return new QQNode('idgardian', 'Idgardian', 'Integer', $this);
				case 'Of':
					return new QQNode('of', 'Of', 'Integer', $this);
				case 'GardianName':
					return new QQNode('gardian_name', 'GardianName', 'VarChar', $this);
				case 'GardianOccupation':
					return new QQNode('gardian_occupation', 'GardianOccupation', 'VarChar', $this);
				case 'RelationOfGardian':
					return new QQNode('relation_of_gardian', 'RelationOfGardian', 'VarChar', $this);
				case 'GardianAddress':
					return new QQNode('gardian_address', 'GardianAddress', 'Blob', $this);
				case 'GardianState':
					return new QQNode('gardian_state', 'GardianState', 'Integer', $this);
				case 'GardianContact':
					return new QQNode('gardian_contact', 'GardianContact', 'VarChar', $this);
				case 'GardianEmail':
					return new QQNode('gardian_email', 'GardianEmail', 'VarChar', $this);
				case 'GardianCat':
					return new QQNode('gardian_cat', 'GardianCat', 'Integer', $this);
				case 'GardianDistrict':
					return new QQNode('gardian_district', 'GardianDistrict', 'Integer', $this);
				case 'GardianTaluka':
					return new QQNode('gardian_taluka', 'GardianTaluka', 'Integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idgardian', 'Idgardian', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idgardian
     * @property-read QQNode $Of
     * @property-read QQNode $GardianName
     * @property-read QQNode $GardianOccupation
     * @property-read QQNode $RelationOfGardian
     * @property-read QQNode $GardianAddress
     * @property-read QQNode $GardianState
     * @property-read QQNode $GardianContact
     * @property-read QQNode $GardianEmail
     * @property-read QQNode $GardianCat
     * @property-read QQNode $GardianDistrict
     * @property-read QQNode $GardianTaluka
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeGardian extends QQReverseReferenceNode {
		protected $strTableName = 'gardian';
		protected $strPrimaryKey = 'idgardian';
		protected $strClassName = 'Gardian';
		public function __get($strName) {
			switch ($strName) {
				case 'Idgardian':
					return new QQNode('idgardian', 'Idgardian', 'integer', $this);
				case 'Of':
					return new QQNode('of', 'Of', 'integer', $this);
				case 'GardianName':
					return new QQNode('gardian_name', 'GardianName', 'string', $this);
				case 'GardianOccupation':
					return new QQNode('gardian_occupation', 'GardianOccupation', 'string', $this);
				case 'RelationOfGardian':
					return new QQNode('relation_of_gardian', 'RelationOfGardian', 'string', $this);
				case 'GardianAddress':
					return new QQNode('gardian_address', 'GardianAddress', 'string', $this);
				case 'GardianState':
					return new QQNode('gardian_state', 'GardianState', 'integer', $this);
				case 'GardianContact':
					return new QQNode('gardian_contact', 'GardianContact', 'string', $this);
				case 'GardianEmail':
					return new QQNode('gardian_email', 'GardianEmail', 'string', $this);
				case 'GardianCat':
					return new QQNode('gardian_cat', 'GardianCat', 'integer', $this);
				case 'GardianDistrict':
					return new QQNode('gardian_district', 'GardianDistrict', 'integer', $this);
				case 'GardianTaluka':
					return new QQNode('gardian_taluka', 'GardianTaluka', 'integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idgardian', 'Idgardian', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
