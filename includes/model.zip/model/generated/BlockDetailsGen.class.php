<?php
	/**
	 * The abstract BlockDetailsGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the BlockDetails subclass which
	 * extends this BlockDetailsGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the BlockDetails class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdblockDetails the value for intIdblockDetails (Read-Only PK)
	 * @property QDateTime $Date the value for dttDate 
	 * @property integer $Block the value for intBlock 
	 * @property integer $Department the value for intDepartment 
	 * @property string $Title the value for strTitle 
	 * @property integer $Capacity the value for intCapacity 
	 * @property Block $BlockObject the value for the Block object referenced by intBlock 
	 * @property Role $DepartmentObject the value for the Role object referenced by intDepartment 
	 * @property-read OccupyBy $_OccupyBy the value for the private _objOccupyBy (Read-Only) if set due to an expansion on the occupy_by.block_details reverse relationship
	 * @property-read OccupyBy[] $_OccupyByArray the value for the private _objOccupyByArray (Read-Only) if set due to an ExpandAsArray on the occupy_by.block_details reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class BlockDetailsGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column block_details.idblock_details
		 * @var integer intIdblockDetails
		 */
		protected $intIdblockDetails;
		const IdblockDetailsDefault = null;


		/**
		 * Protected member variable that maps to the database column block_details.date
		 * @var QDateTime dttDate
		 */
		protected $dttDate;
		const DateDefault = null;


		/**
		 * Protected member variable that maps to the database column block_details.block
		 * @var integer intBlock
		 */
		protected $intBlock;
		const BlockDefault = null;


		/**
		 * Protected member variable that maps to the database column block_details.department
		 * @var integer intDepartment
		 */
		protected $intDepartment;
		const DepartmentDefault = null;


		/**
		 * Protected member variable that maps to the database column block_details.title
		 * @var string strTitle
		 */
		protected $strTitle;
		const TitleMaxLength = 255;
		const TitleDefault = null;


		/**
		 * Protected member variable that maps to the database column block_details.capacity
		 * @var integer intCapacity
		 */
		protected $intCapacity;
		const CapacityDefault = null;


		/**
		 * Private member variable that stores a reference to a single OccupyBy object
		 * (of type OccupyBy), if this BlockDetails object was restored with
		 * an expansion on the occupy_by association table.
		 * @var OccupyBy _objOccupyBy;
		 */
		private $_objOccupyBy;

		/**
		 * Private member variable that stores a reference to an array of OccupyBy objects
		 * (of type OccupyBy[]), if this BlockDetails object was restored with
		 * an ExpandAsArray on the occupy_by association table.
		 * @var OccupyBy[] _objOccupyByArray;
		 */
		private $_objOccupyByArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column block_details.block.
		 *
		 * NOTE: Always use the BlockObject property getter to correctly retrieve this Block object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Block objBlockObject
		 */
		protected $objBlockObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column block_details.department.
		 *
		 * NOTE: Always use the DepartmentObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objDepartmentObject
		 */
		protected $objDepartmentObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdblockDetails = BlockDetails::IdblockDetailsDefault;
			$this->dttDate = (BlockDetails::DateDefault === null)?null:new QDateTime(BlockDetails::DateDefault);
			$this->intBlock = BlockDetails::BlockDefault;
			$this->intDepartment = BlockDetails::DepartmentDefault;
			$this->strTitle = BlockDetails::TitleDefault;
			$this->intCapacity = BlockDetails::CapacityDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a BlockDetails from PK Info
		 * @param integer $intIdblockDetails
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return BlockDetails
		 */
		public static function Load($intIdblockDetails, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'BlockDetails', $intIdblockDetails);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = BlockDetails::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::BlockDetails()->IdblockDetails, $intIdblockDetails)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all BlockDetailses
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return BlockDetails[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call BlockDetails::QueryArray to perform the LoadAll query
			try {
				return BlockDetails::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all BlockDetailses
		 * @return int
		 */
		public static function CountAll() {
			// Call BlockDetails::QueryCount to perform the CountAll query
			return BlockDetails::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = BlockDetails::GetDatabase();

			// Create/Build out the QueryBuilder object with BlockDetails-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'block_details');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				BlockDetails::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('block_details');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single BlockDetails object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return BlockDetails the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = BlockDetails::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new BlockDetails object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = BlockDetails::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return BlockDetails::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of BlockDetails objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return BlockDetails[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = BlockDetails::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return BlockDetails::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = BlockDetails::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of BlockDetails objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = BlockDetails::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = BlockDetails::GetDatabase();

			$strQuery = BlockDetails::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/blockdetails', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = BlockDetails::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this BlockDetails
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'block_details';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idblock_details', $strAliasPrefix . 'idblock_details');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idblock_details', $strAliasPrefix . 'idblock_details');
			    $objBuilder->AddSelectItem($strTableName, 'date', $strAliasPrefix . 'date');
			    $objBuilder->AddSelectItem($strTableName, 'block', $strAliasPrefix . 'block');
			    $objBuilder->AddSelectItem($strTableName, 'department', $strAliasPrefix . 'department');
			    $objBuilder->AddSelectItem($strTableName, 'title', $strAliasPrefix . 'title');
			    $objBuilder->AddSelectItem($strTableName, 'capacity', $strAliasPrefix . 'capacity');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a BlockDetails from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this BlockDetails::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return BlockDetails
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idblock_details';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdblockDetails == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'block_details__';


						// Expanding reverse references: OccupyBy
						$strAlias = $strAliasPrefix . 'occupyby__idoccupy_by';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objOccupyByArray)
								$objPreviousItem->_objOccupyByArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objOccupyByArray)) {
								$objPreviousChildItems = $objPreviousItem->_objOccupyByArray;
								$objChildItem = OccupyBy::InstantiateDbRow($objDbRow, $strAliasPrefix . 'occupyby__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objOccupyByArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objOccupyByArray[] = OccupyBy::InstantiateDbRow($objDbRow, $strAliasPrefix . 'occupyby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'block_details__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the BlockDetails object
			$objToReturn = new BlockDetails();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idblock_details';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdblockDetails = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'block';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intBlock = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'department';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDepartment = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'title';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTitle = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'capacity';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCapacity = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdblockDetails != $objPreviousItem->IdblockDetails) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objOccupyByArray);
					$cnt = count($objToReturn->_objOccupyByArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objOccupyByArray, $objToReturn->_objOccupyByArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'block_details__';

			// Check for BlockObject Early Binding
			$strAlias = $strAliasPrefix . 'block__idblock';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objBlockObject = Block::InstantiateDbRow($objDbRow, $strAliasPrefix . 'block__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DepartmentObject Early Binding
			$strAlias = $strAliasPrefix . 'department__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDepartmentObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'department__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for OccupyBy Virtual Binding
			$strAlias = $strAliasPrefix . 'occupyby__idoccupy_by';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objOccupyByArray)
				$objToReturn->_objOccupyByArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objOccupyByArray[] = OccupyBy::InstantiateDbRow($objDbRow, $strAliasPrefix . 'occupyby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objOccupyBy = OccupyBy::InstantiateDbRow($objDbRow, $strAliasPrefix . 'occupyby__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of BlockDetailses from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return BlockDetails[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = BlockDetails::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = BlockDetails::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single BlockDetails object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return BlockDetails next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return BlockDetails::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single BlockDetails object,
		 * by IdblockDetails Index(es)
		 * @param integer $intIdblockDetails
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return BlockDetails
		*/
		public static function LoadByIdblockDetails($intIdblockDetails, $objOptionalClauses = null) {
			return BlockDetails::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::BlockDetails()->IdblockDetails, $intIdblockDetails)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of BlockDetails objects,
		 * by Block Index(es)
		 * @param integer $intBlock
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return BlockDetails[]
		*/
		public static function LoadArrayByBlock($intBlock, $objOptionalClauses = null) {
			// Call BlockDetails::QueryArray to perform the LoadArrayByBlock query
			try {
				return BlockDetails::QueryArray(
					QQ::Equal(QQN::BlockDetails()->Block, $intBlock),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count BlockDetailses
		 * by Block Index(es)
		 * @param integer $intBlock
		 * @return int
		*/
		public static function CountByBlock($intBlock) {
			// Call BlockDetails::QueryCount to perform the CountByBlock query
			return BlockDetails::QueryCount(
				QQ::Equal(QQN::BlockDetails()->Block, $intBlock)
			);
		}

		/**
		 * Load an array of BlockDetails objects,
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return BlockDetails[]
		*/
		public static function LoadArrayByDepartment($intDepartment, $objOptionalClauses = null) {
			// Call BlockDetails::QueryArray to perform the LoadArrayByDepartment query
			try {
				return BlockDetails::QueryArray(
					QQ::Equal(QQN::BlockDetails()->Department, $intDepartment),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count BlockDetailses
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @return int
		*/
		public static function CountByDepartment($intDepartment) {
			// Call BlockDetails::QueryCount to perform the CountByDepartment query
			return BlockDetails::QueryCount(
				QQ::Equal(QQN::BlockDetails()->Department, $intDepartment)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this BlockDetails
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = BlockDetails::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `block_details` (
							`date`,
							`block`,
							`department`,
							`title`,
							`capacity`
						) VALUES (
							' . $objDatabase->SqlVariable($this->dttDate) . ',
							' . $objDatabase->SqlVariable($this->intBlock) . ',
							' . $objDatabase->SqlVariable($this->intDepartment) . ',
							' . $objDatabase->SqlVariable($this->strTitle) . ',
							' . $objDatabase->SqlVariable($this->intCapacity) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdblockDetails = $objDatabase->InsertId('block_details', 'idblock_details');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`block_details`
						SET
							`date` = ' . $objDatabase->SqlVariable($this->dttDate) . ',
							`block` = ' . $objDatabase->SqlVariable($this->intBlock) . ',
							`department` = ' . $objDatabase->SqlVariable($this->intDepartment) . ',
							`title` = ' . $objDatabase->SqlVariable($this->strTitle) . ',
							`capacity` = ' . $objDatabase->SqlVariable($this->intCapacity) . '
						WHERE
							`idblock_details` = ' . $objDatabase->SqlVariable($this->intIdblockDetails) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this BlockDetails
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdblockDetails)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this BlockDetails with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = BlockDetails::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`block_details`
				WHERE
					`idblock_details` = ' . $objDatabase->SqlVariable($this->intIdblockDetails) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this BlockDetails ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'BlockDetails', $this->intIdblockDetails);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all BlockDetailses
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = BlockDetails::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`block_details`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate block_details table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = BlockDetails::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `block_details`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this BlockDetails from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved BlockDetails object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = BlockDetails::Load($this->intIdblockDetails);

			// Update $this's local variables to match
			$this->dttDate = $objReloaded->dttDate;
			$this->Block = $objReloaded->Block;
			$this->Department = $objReloaded->Department;
			$this->strTitle = $objReloaded->strTitle;
			$this->intCapacity = $objReloaded->intCapacity;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdblockDetails':
					/**
					 * Gets the value for intIdblockDetails (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdblockDetails;

				case 'Date':
					/**
					 * Gets the value for dttDate 
					 * @return QDateTime
					 */
					return $this->dttDate;

				case 'Block':
					/**
					 * Gets the value for intBlock 
					 * @return integer
					 */
					return $this->intBlock;

				case 'Department':
					/**
					 * Gets the value for intDepartment 
					 * @return integer
					 */
					return $this->intDepartment;

				case 'Title':
					/**
					 * Gets the value for strTitle 
					 * @return string
					 */
					return $this->strTitle;

				case 'Capacity':
					/**
					 * Gets the value for intCapacity 
					 * @return integer
					 */
					return $this->intCapacity;


				///////////////////
				// Member Objects
				///////////////////
				case 'BlockObject':
					/**
					 * Gets the value for the Block object referenced by intBlock 
					 * @return Block
					 */
					try {
						if ((!$this->objBlockObject) && (!is_null($this->intBlock)))
							$this->objBlockObject = Block::Load($this->intBlock);
						return $this->objBlockObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DepartmentObject':
					/**
					 * Gets the value for the Role object referenced by intDepartment 
					 * @return Role
					 */
					try {
						if ((!$this->objDepartmentObject) && (!is_null($this->intDepartment)))
							$this->objDepartmentObject = Role::Load($this->intDepartment);
						return $this->objDepartmentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_OccupyBy':
					/**
					 * Gets the value for the private _objOccupyBy (Read-Only)
					 * if set due to an expansion on the occupy_by.block_details reverse relationship
					 * @return OccupyBy
					 */
					return $this->_objOccupyBy;

				case '_OccupyByArray':
					/**
					 * Gets the value for the private _objOccupyByArray (Read-Only)
					 * if set due to an ExpandAsArray on the occupy_by.block_details reverse relationship
					 * @return OccupyBy[]
					 */
					return $this->_objOccupyByArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Date':
					/**
					 * Sets the value for dttDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Block':
					/**
					 * Sets the value for intBlock 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objBlockObject = null;
						return ($this->intBlock = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Department':
					/**
					 * Sets the value for intDepartment 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDepartmentObject = null;
						return ($this->intDepartment = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Title':
					/**
					 * Sets the value for strTitle 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTitle = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Capacity':
					/**
					 * Sets the value for intCapacity 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intCapacity = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'BlockObject':
					/**
					 * Sets the value for the Block object referenced by intBlock 
					 * @param Block $mixValue
					 * @return Block
					 */
					if (is_null($mixValue)) {
						$this->intBlock = null;
						$this->objBlockObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Block object
						try {
							$mixValue = QType::Cast($mixValue, 'Block');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Block object
						if (is_null($mixValue->Idblock))
							throw new QCallerException('Unable to set an unsaved BlockObject for this BlockDetails');

						// Update Local Member Variables
						$this->objBlockObject = $mixValue;
						$this->intBlock = $mixValue->Idblock;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DepartmentObject':
					/**
					 * Sets the value for the Role object referenced by intDepartment 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intDepartment = null;
						$this->objDepartmentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved DepartmentObject for this BlockDetails');

						// Update Local Member Variables
						$this->objDepartmentObject = $mixValue;
						$this->intDepartment = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for OccupyBy
		//-------------------------------------------------------------------

		/**
		 * Gets all associated OccupyBies as an array of OccupyBy objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return OccupyBy[]
		*/
		public function GetOccupyByArray($objOptionalClauses = null) {
			if ((is_null($this->intIdblockDetails)))
				return array();

			try {
				return OccupyBy::LoadArrayByBlockDetails($this->intIdblockDetails, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated OccupyBies
		 * @return int
		*/
		public function CountOccupyBies() {
			if ((is_null($this->intIdblockDetails)))
				return 0;

			return OccupyBy::CountByBlockDetails($this->intIdblockDetails);
		}

		/**
		 * Associates a OccupyBy
		 * @param OccupyBy $objOccupyBy
		 * @return void
		*/
		public function AssociateOccupyBy(OccupyBy $objOccupyBy) {
			if ((is_null($this->intIdblockDetails)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateOccupyBy on this unsaved BlockDetails.');
			if ((is_null($objOccupyBy->IdoccupyBy)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateOccupyBy on this BlockDetails with an unsaved OccupyBy.');

			// Get the Database Object for this Class
			$objDatabase = BlockDetails::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`occupy_by`
				SET
					`block_details` = ' . $objDatabase->SqlVariable($this->intIdblockDetails) . '
				WHERE
					`idoccupy_by` = ' . $objDatabase->SqlVariable($objOccupyBy->IdoccupyBy) . '
			');
		}

		/**
		 * Unassociates a OccupyBy
		 * @param OccupyBy $objOccupyBy
		 * @return void
		*/
		public function UnassociateOccupyBy(OccupyBy $objOccupyBy) {
			if ((is_null($this->intIdblockDetails)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateOccupyBy on this unsaved BlockDetails.');
			if ((is_null($objOccupyBy->IdoccupyBy)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateOccupyBy on this BlockDetails with an unsaved OccupyBy.');

			// Get the Database Object for this Class
			$objDatabase = BlockDetails::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`occupy_by`
				SET
					`block_details` = null
				WHERE
					`idoccupy_by` = ' . $objDatabase->SqlVariable($objOccupyBy->IdoccupyBy) . ' AND
					`block_details` = ' . $objDatabase->SqlVariable($this->intIdblockDetails) . '
			');
		}

		/**
		 * Unassociates all OccupyBies
		 * @return void
		*/
		public function UnassociateAllOccupyBies() {
			if ((is_null($this->intIdblockDetails)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateOccupyBy on this unsaved BlockDetails.');

			// Get the Database Object for this Class
			$objDatabase = BlockDetails::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`occupy_by`
				SET
					`block_details` = null
				WHERE
					`block_details` = ' . $objDatabase->SqlVariable($this->intIdblockDetails) . '
			');
		}

		/**
		 * Deletes an associated OccupyBy
		 * @param OccupyBy $objOccupyBy
		 * @return void
		*/
		public function DeleteAssociatedOccupyBy(OccupyBy $objOccupyBy) {
			if ((is_null($this->intIdblockDetails)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateOccupyBy on this unsaved BlockDetails.');
			if ((is_null($objOccupyBy->IdoccupyBy)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateOccupyBy on this BlockDetails with an unsaved OccupyBy.');

			// Get the Database Object for this Class
			$objDatabase = BlockDetails::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`occupy_by`
				WHERE
					`idoccupy_by` = ' . $objDatabase->SqlVariable($objOccupyBy->IdoccupyBy) . ' AND
					`block_details` = ' . $objDatabase->SqlVariable($this->intIdblockDetails) . '
			');
		}

		/**
		 * Deletes all associated OccupyBies
		 * @return void
		*/
		public function DeleteAllOccupyBies() {
			if ((is_null($this->intIdblockDetails)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateOccupyBy on this unsaved BlockDetails.');

			// Get the Database Object for this Class
			$objDatabase = BlockDetails::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`occupy_by`
				WHERE
					`block_details` = ' . $objDatabase->SqlVariable($this->intIdblockDetails) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "block_details";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[BlockDetails::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="BlockDetails"><sequence>';
			$strToReturn .= '<element name="IdblockDetails" type="xsd:int"/>';
			$strToReturn .= '<element name="Date" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="BlockObject" type="xsd1:Block"/>';
			$strToReturn .= '<element name="DepartmentObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="Title" type="xsd:string"/>';
			$strToReturn .= '<element name="Capacity" type="xsd:int"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('BlockDetails', $strComplexTypeArray)) {
				$strComplexTypeArray['BlockDetails'] = BlockDetails::GetSoapComplexTypeXml();
				Block::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, BlockDetails::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new BlockDetails();
			if (property_exists($objSoapObject, 'IdblockDetails'))
				$objToReturn->intIdblockDetails = $objSoapObject->IdblockDetails;
			if (property_exists($objSoapObject, 'Date'))
				$objToReturn->dttDate = new QDateTime($objSoapObject->Date);
			if ((property_exists($objSoapObject, 'BlockObject')) &&
				($objSoapObject->BlockObject))
				$objToReturn->BlockObject = Block::GetObjectFromSoapObject($objSoapObject->BlockObject);
			if ((property_exists($objSoapObject, 'DepartmentObject')) &&
				($objSoapObject->DepartmentObject))
				$objToReturn->DepartmentObject = Role::GetObjectFromSoapObject($objSoapObject->DepartmentObject);
			if (property_exists($objSoapObject, 'Title'))
				$objToReturn->strTitle = $objSoapObject->Title;
			if (property_exists($objSoapObject, 'Capacity'))
				$objToReturn->intCapacity = $objSoapObject->Capacity;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, BlockDetails::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->dttDate)
				$objObject->dttDate = $objObject->dttDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objBlockObject)
				$objObject->objBlockObject = Block::GetSoapObjectFromObject($objObject->objBlockObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intBlock = null;
			if ($objObject->objDepartmentObject)
				$objObject->objDepartmentObject = Role::GetSoapObjectFromObject($objObject->objDepartmentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDepartment = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdblockDetails'] = $this->intIdblockDetails;
			$iArray['Date'] = $this->dttDate;
			$iArray['Block'] = $this->intBlock;
			$iArray['Department'] = $this->intDepartment;
			$iArray['Title'] = $this->strTitle;
			$iArray['Capacity'] = $this->intCapacity;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdblockDetails ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdblockDetails
     * @property-read QQNode $Date
     * @property-read QQNode $Block
     * @property-read QQNodeBlock $BlockObject
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $Title
     * @property-read QQNode $Capacity
     *
     *
     * @property-read QQReverseReferenceNodeOccupyBy $OccupyBy

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeBlockDetails extends QQNode {
		protected $strTableName = 'block_details';
		protected $strPrimaryKey = 'idblock_details';
		protected $strClassName = 'BlockDetails';
		public function __get($strName) {
			switch ($strName) {
				case 'IdblockDetails':
					return new QQNode('idblock_details', 'IdblockDetails', 'Integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'Date', $this);
				case 'Block':
					return new QQNode('block', 'Block', 'Integer', $this);
				case 'BlockObject':
					return new QQNodeBlock('block', 'BlockObject', 'Integer', $this);
				case 'Department':
					return new QQNode('department', 'Department', 'Integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'Integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'VarChar', $this);
				case 'Capacity':
					return new QQNode('capacity', 'Capacity', 'Integer', $this);
				case 'OccupyBy':
					return new QQReverseReferenceNodeOccupyBy($this, 'occupyby', 'reverse_reference', 'block_details');

				case '_PrimaryKeyNode':
					return new QQNode('idblock_details', 'IdblockDetails', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdblockDetails
     * @property-read QQNode $Date
     * @property-read QQNode $Block
     * @property-read QQNodeBlock $BlockObject
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $Title
     * @property-read QQNode $Capacity
     *
     *
     * @property-read QQReverseReferenceNodeOccupyBy $OccupyBy

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeBlockDetails extends QQReverseReferenceNode {
		protected $strTableName = 'block_details';
		protected $strPrimaryKey = 'idblock_details';
		protected $strClassName = 'BlockDetails';
		public function __get($strName) {
			switch ($strName) {
				case 'IdblockDetails':
					return new QQNode('idblock_details', 'IdblockDetails', 'integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'QDateTime', $this);
				case 'Block':
					return new QQNode('block', 'Block', 'integer', $this);
				case 'BlockObject':
					return new QQNodeBlock('block', 'BlockObject', 'integer', $this);
				case 'Department':
					return new QQNode('department', 'Department', 'integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'string', $this);
				case 'Capacity':
					return new QQNode('capacity', 'Capacity', 'integer', $this);
				case 'OccupyBy':
					return new QQReverseReferenceNodeOccupyBy($this, 'occupyby', 'reverse_reference', 'block_details');

				case '_PrimaryKeyNode':
					return new QQNode('idblock_details', 'IdblockDetails', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
