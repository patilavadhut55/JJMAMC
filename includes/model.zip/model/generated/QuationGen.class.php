<?php
	/**
	 * The abstract QuationGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Quation subclass which
	 * extends this QuationGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Quation class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idquation the value for intIdquation (Read-Only PK)
	 * @property string $Code the value for strCode 
	 * @property integer $Seq the value for intSeq 
	 * @property integer $Parrent the value for intParrent 
	 * @property string $Quation the value for strQuation 
	 * @property integer $Topic the value for intTopic 
	 * @property string $Credit the value for strCredit 
	 * @property string $ModelAnswer the value for strModelAnswer 
	 * @property integer $Exampaper the value for intExampaper 
	 * @property integer $Marks the value for intMarks 
	 * @property Quation $ParrentObject the value for the Quation object referenced by intParrent 
	 * @property YearsubjectHasTopic $TopicObject the value for the YearsubjectHasTopic object referenced by intTopic 
	 * @property Exampaper $ExampaperObject the value for the Exampaper object referenced by intExampaper 
	 * @property-read Quation $_QuationAsParrent the value for the private _objQuationAsParrent (Read-Only) if set due to an expansion on the quation.parrent reverse relationship
	 * @property-read Quation[] $_QuationAsParrentArray the value for the private _objQuationAsParrentArray (Read-Only) if set due to an ExpandAsArray on the quation.parrent reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class QuationGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column quation.idquation
		 * @var integer intIdquation
		 */
		protected $intIdquation;
		const IdquationDefault = null;


		/**
		 * Protected member variable that maps to the database column quation.code
		 * @var string strCode
		 */
		protected $strCode;
		const CodeMaxLength = 45;
		const CodeDefault = null;


		/**
		 * Protected member variable that maps to the database column quation.seq
		 * @var integer intSeq
		 */
		protected $intSeq;
		const SeqDefault = null;


		/**
		 * Protected member variable that maps to the database column quation.parrent
		 * @var integer intParrent
		 */
		protected $intParrent;
		const ParrentDefault = null;


		/**
		 * Protected member variable that maps to the database column quation.quation
		 * @var string strQuation
		 */
		protected $strQuation;
		const QuationDefault = null;


		/**
		 * Protected member variable that maps to the database column quation.topic
		 * @var integer intTopic
		 */
		protected $intTopic;
		const TopicDefault = null;


		/**
		 * Protected member variable that maps to the database column quation.credit
		 * @var string strCredit
		 */
		protected $strCredit;
		const CreditMaxLength = 45;
		const CreditDefault = null;


		/**
		 * Protected member variable that maps to the database column quation.model_answer
		 * @var string strModelAnswer
		 */
		protected $strModelAnswer;
		const ModelAnswerDefault = null;


		/**
		 * Protected member variable that maps to the database column quation.exampaper
		 * @var integer intExampaper
		 */
		protected $intExampaper;
		const ExampaperDefault = null;


		/**
		 * Protected member variable that maps to the database column quation.marks
		 * @var integer intMarks
		 */
		protected $intMarks;
		const MarksDefault = null;


		/**
		 * Private member variable that stores a reference to a single QuationAsParrent object
		 * (of type Quation), if this Quation object was restored with
		 * an expansion on the quation association table.
		 * @var Quation _objQuationAsParrent;
		 */
		private $_objQuationAsParrent;

		/**
		 * Private member variable that stores a reference to an array of QuationAsParrent objects
		 * (of type Quation[]), if this Quation object was restored with
		 * an ExpandAsArray on the quation association table.
		 * @var Quation[] _objQuationAsParrentArray;
		 */
		private $_objQuationAsParrentArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column quation.parrent.
		 *
		 * NOTE: Always use the ParrentObject property getter to correctly retrieve this Quation object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Quation objParrentObject
		 */
		protected $objParrentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column quation.topic.
		 *
		 * NOTE: Always use the TopicObject property getter to correctly retrieve this YearsubjectHasTopic object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var YearsubjectHasTopic objTopicObject
		 */
		protected $objTopicObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column quation.exampaper.
		 *
		 * NOTE: Always use the ExampaperObject property getter to correctly retrieve this Exampaper object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Exampaper objExampaperObject
		 */
		protected $objExampaperObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdquation = Quation::IdquationDefault;
			$this->strCode = Quation::CodeDefault;
			$this->intSeq = Quation::SeqDefault;
			$this->intParrent = Quation::ParrentDefault;
			$this->strQuation = Quation::QuationDefault;
			$this->intTopic = Quation::TopicDefault;
			$this->strCredit = Quation::CreditDefault;
			$this->strModelAnswer = Quation::ModelAnswerDefault;
			$this->intExampaper = Quation::ExampaperDefault;
			$this->intMarks = Quation::MarksDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Quation from PK Info
		 * @param integer $intIdquation
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Quation
		 */
		public static function Load($intIdquation, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Quation', $intIdquation);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Quation::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Quation()->Idquation, $intIdquation)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Quations
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Quation[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Quation::QueryArray to perform the LoadAll query
			try {
				return Quation::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Quations
		 * @return int
		 */
		public static function CountAll() {
			// Call Quation::QueryCount to perform the CountAll query
			return Quation::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Quation::GetDatabase();

			// Create/Build out the QueryBuilder object with Quation-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'quation');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Quation::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('quation');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Quation object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Quation the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Quation::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Quation object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Quation::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Quation::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Quation objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Quation[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Quation::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Quation::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Quation::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Quation objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Quation::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Quation::GetDatabase();

			$strQuery = Quation::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/quation', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Quation::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Quation
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'quation';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idquation', $strAliasPrefix . 'idquation');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idquation', $strAliasPrefix . 'idquation');
			    $objBuilder->AddSelectItem($strTableName, 'code', $strAliasPrefix . 'code');
			    $objBuilder->AddSelectItem($strTableName, 'seq', $strAliasPrefix . 'seq');
			    $objBuilder->AddSelectItem($strTableName, 'parrent', $strAliasPrefix . 'parrent');
			    $objBuilder->AddSelectItem($strTableName, 'quation', $strAliasPrefix . 'quation');
			    $objBuilder->AddSelectItem($strTableName, 'topic', $strAliasPrefix . 'topic');
			    $objBuilder->AddSelectItem($strTableName, 'credit', $strAliasPrefix . 'credit');
			    $objBuilder->AddSelectItem($strTableName, 'model_answer', $strAliasPrefix . 'model_answer');
			    $objBuilder->AddSelectItem($strTableName, 'exampaper', $strAliasPrefix . 'exampaper');
			    $objBuilder->AddSelectItem($strTableName, 'marks', $strAliasPrefix . 'marks');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Quation from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Quation::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Quation
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idquation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdquation == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'quation__';


						// Expanding reverse references: QuationAsParrent
						$strAlias = $strAliasPrefix . 'quationasparrent__idquation';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objQuationAsParrentArray)
								$objPreviousItem->_objQuationAsParrentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objQuationAsParrentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objQuationAsParrentArray;
								$objChildItem = Quation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'quationasparrent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objQuationAsParrentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objQuationAsParrentArray[] = Quation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'quationasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'quation__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Quation object
			$objToReturn = new Quation();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idquation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdquation = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'seq';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSeq = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'parrent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intParrent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'quation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strQuation = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'topic';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intTopic = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'credit';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCredit = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'model_answer';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strModelAnswer = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'exampaper';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intExampaper = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'marks';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMarks = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idquation != $objPreviousItem->Idquation) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objQuationAsParrentArray);
					$cnt = count($objToReturn->_objQuationAsParrentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objQuationAsParrentArray, $objToReturn->_objQuationAsParrentArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'quation__';

			// Check for ParrentObject Early Binding
			$strAlias = $strAliasPrefix . 'parrent__idquation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objParrentObject = Quation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'parrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for TopicObject Early Binding
			$strAlias = $strAliasPrefix . 'topic__idyearsubject_has_topic';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objTopicObject = YearsubjectHasTopic::InstantiateDbRow($objDbRow, $strAliasPrefix . 'topic__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ExampaperObject Early Binding
			$strAlias = $strAliasPrefix . 'exampaper__idexampaper';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objExampaperObject = Exampaper::InstantiateDbRow($objDbRow, $strAliasPrefix . 'exampaper__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for QuationAsParrent Virtual Binding
			$strAlias = $strAliasPrefix . 'quationasparrent__idquation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objQuationAsParrentArray)
				$objToReturn->_objQuationAsParrentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objQuationAsParrentArray[] = Quation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'quationasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objQuationAsParrent = Quation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'quationasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Quations from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Quation[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Quation::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Quation::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Quation object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Quation next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Quation::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Quation object,
		 * by Idquation Index(es)
		 * @param integer $intIdquation
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Quation
		*/
		public static function LoadByIdquation($intIdquation, $objOptionalClauses = null) {
			return Quation::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Quation()->Idquation, $intIdquation)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Quation objects,
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Quation[]
		*/
		public static function LoadArrayByParrent($intParrent, $objOptionalClauses = null) {
			// Call Quation::QueryArray to perform the LoadArrayByParrent query
			try {
				return Quation::QueryArray(
					QQ::Equal(QQN::Quation()->Parrent, $intParrent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Quations
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @return int
		*/
		public static function CountByParrent($intParrent) {
			// Call Quation::QueryCount to perform the CountByParrent query
			return Quation::QueryCount(
				QQ::Equal(QQN::Quation()->Parrent, $intParrent)
			);
		}

		/**
		 * Load an array of Quation objects,
		 * by Exampaper Index(es)
		 * @param integer $intExampaper
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Quation[]
		*/
		public static function LoadArrayByExampaper($intExampaper, $objOptionalClauses = null) {
			// Call Quation::QueryArray to perform the LoadArrayByExampaper query
			try {
				return Quation::QueryArray(
					QQ::Equal(QQN::Quation()->Exampaper, $intExampaper),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Quations
		 * by Exampaper Index(es)
		 * @param integer $intExampaper
		 * @return int
		*/
		public static function CountByExampaper($intExampaper) {
			// Call Quation::QueryCount to perform the CountByExampaper query
			return Quation::QueryCount(
				QQ::Equal(QQN::Quation()->Exampaper, $intExampaper)
			);
		}

		/**
		 * Load an array of Quation objects,
		 * by Topic Index(es)
		 * @param integer $intTopic
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Quation[]
		*/
		public static function LoadArrayByTopic($intTopic, $objOptionalClauses = null) {
			// Call Quation::QueryArray to perform the LoadArrayByTopic query
			try {
				return Quation::QueryArray(
					QQ::Equal(QQN::Quation()->Topic, $intTopic),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Quations
		 * by Topic Index(es)
		 * @param integer $intTopic
		 * @return int
		*/
		public static function CountByTopic($intTopic) {
			// Call Quation::QueryCount to perform the CountByTopic query
			return Quation::QueryCount(
				QQ::Equal(QQN::Quation()->Topic, $intTopic)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Quation
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Quation::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `quation` (
							`code`,
							`seq`,
							`parrent`,
							`quation`,
							`topic`,
							`credit`,
							`model_answer`,
							`exampaper`,
							`marks`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strCode) . ',
							' . $objDatabase->SqlVariable($this->intSeq) . ',
							' . $objDatabase->SqlVariable($this->intParrent) . ',
							' . $objDatabase->SqlVariable($this->strQuation) . ',
							' . $objDatabase->SqlVariable($this->intTopic) . ',
							' . $objDatabase->SqlVariable($this->strCredit) . ',
							' . $objDatabase->SqlVariable($this->strModelAnswer) . ',
							' . $objDatabase->SqlVariable($this->intExampaper) . ',
							' . $objDatabase->SqlVariable($this->intMarks) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdquation = $objDatabase->InsertId('quation', 'idquation');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`quation`
						SET
							`code` = ' . $objDatabase->SqlVariable($this->strCode) . ',
							`seq` = ' . $objDatabase->SqlVariable($this->intSeq) . ',
							`parrent` = ' . $objDatabase->SqlVariable($this->intParrent) . ',
							`quation` = ' . $objDatabase->SqlVariable($this->strQuation) . ',
							`topic` = ' . $objDatabase->SqlVariable($this->intTopic) . ',
							`credit` = ' . $objDatabase->SqlVariable($this->strCredit) . ',
							`model_answer` = ' . $objDatabase->SqlVariable($this->strModelAnswer) . ',
							`exampaper` = ' . $objDatabase->SqlVariable($this->intExampaper) . ',
							`marks` = ' . $objDatabase->SqlVariable($this->intMarks) . '
						WHERE
							`idquation` = ' . $objDatabase->SqlVariable($this->intIdquation) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Quation
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdquation)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Quation with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Quation::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`quation`
				WHERE
					`idquation` = ' . $objDatabase->SqlVariable($this->intIdquation) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Quation ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Quation', $this->intIdquation);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Quations
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Quation::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`quation`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate quation table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Quation::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `quation`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Quation from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Quation object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Quation::Load($this->intIdquation);

			// Update $this's local variables to match
			$this->strCode = $objReloaded->strCode;
			$this->intSeq = $objReloaded->intSeq;
			$this->Parrent = $objReloaded->Parrent;
			$this->strQuation = $objReloaded->strQuation;
			$this->Topic = $objReloaded->Topic;
			$this->strCredit = $objReloaded->strCredit;
			$this->strModelAnswer = $objReloaded->strModelAnswer;
			$this->Exampaper = $objReloaded->Exampaper;
			$this->intMarks = $objReloaded->intMarks;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idquation':
					/**
					 * Gets the value for intIdquation (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdquation;

				case 'Code':
					/**
					 * Gets the value for strCode 
					 * @return string
					 */
					return $this->strCode;

				case 'Seq':
					/**
					 * Gets the value for intSeq 
					 * @return integer
					 */
					return $this->intSeq;

				case 'Parrent':
					/**
					 * Gets the value for intParrent 
					 * @return integer
					 */
					return $this->intParrent;

				case 'Quation':
					/**
					 * Gets the value for strQuation 
					 * @return string
					 */
					return $this->strQuation;

				case 'Topic':
					/**
					 * Gets the value for intTopic 
					 * @return integer
					 */
					return $this->intTopic;

				case 'Credit':
					/**
					 * Gets the value for strCredit 
					 * @return string
					 */
					return $this->strCredit;

				case 'ModelAnswer':
					/**
					 * Gets the value for strModelAnswer 
					 * @return string
					 */
					return $this->strModelAnswer;

				case 'Exampaper':
					/**
					 * Gets the value for intExampaper 
					 * @return integer
					 */
					return $this->intExampaper;

				case 'Marks':
					/**
					 * Gets the value for intMarks 
					 * @return integer
					 */
					return $this->intMarks;


				///////////////////
				// Member Objects
				///////////////////
				case 'ParrentObject':
					/**
					 * Gets the value for the Quation object referenced by intParrent 
					 * @return Quation
					 */
					try {
						if ((!$this->objParrentObject) && (!is_null($this->intParrent)))
							$this->objParrentObject = Quation::Load($this->intParrent);
						return $this->objParrentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TopicObject':
					/**
					 * Gets the value for the YearsubjectHasTopic object referenced by intTopic 
					 * @return YearsubjectHasTopic
					 */
					try {
						if ((!$this->objTopicObject) && (!is_null($this->intTopic)))
							$this->objTopicObject = YearsubjectHasTopic::Load($this->intTopic);
						return $this->objTopicObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ExampaperObject':
					/**
					 * Gets the value for the Exampaper object referenced by intExampaper 
					 * @return Exampaper
					 */
					try {
						if ((!$this->objExampaperObject) && (!is_null($this->intExampaper)))
							$this->objExampaperObject = Exampaper::Load($this->intExampaper);
						return $this->objExampaperObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_QuationAsParrent':
					/**
					 * Gets the value for the private _objQuationAsParrent (Read-Only)
					 * if set due to an expansion on the quation.parrent reverse relationship
					 * @return Quation
					 */
					return $this->_objQuationAsParrent;

				case '_QuationAsParrentArray':
					/**
					 * Gets the value for the private _objQuationAsParrentArray (Read-Only)
					 * if set due to an ExpandAsArray on the quation.parrent reverse relationship
					 * @return Quation[]
					 */
					return $this->_objQuationAsParrentArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Code':
					/**
					 * Sets the value for strCode 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Seq':
					/**
					 * Sets the value for intSeq 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intSeq = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Parrent':
					/**
					 * Sets the value for intParrent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objParrentObject = null;
						return ($this->intParrent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Quation':
					/**
					 * Sets the value for strQuation 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strQuation = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Topic':
					/**
					 * Sets the value for intTopic 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objTopicObject = null;
						return ($this->intTopic = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Credit':
					/**
					 * Sets the value for strCredit 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCredit = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ModelAnswer':
					/**
					 * Sets the value for strModelAnswer 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strModelAnswer = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Exampaper':
					/**
					 * Sets the value for intExampaper 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objExampaperObject = null;
						return ($this->intExampaper = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Marks':
					/**
					 * Sets the value for intMarks 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intMarks = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'ParrentObject':
					/**
					 * Sets the value for the Quation object referenced by intParrent 
					 * @param Quation $mixValue
					 * @return Quation
					 */
					if (is_null($mixValue)) {
						$this->intParrent = null;
						$this->objParrentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Quation object
						try {
							$mixValue = QType::Cast($mixValue, 'Quation');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Quation object
						if (is_null($mixValue->Idquation))
							throw new QCallerException('Unable to set an unsaved ParrentObject for this Quation');

						// Update Local Member Variables
						$this->objParrentObject = $mixValue;
						$this->intParrent = $mixValue->Idquation;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'TopicObject':
					/**
					 * Sets the value for the YearsubjectHasTopic object referenced by intTopic 
					 * @param YearsubjectHasTopic $mixValue
					 * @return YearsubjectHasTopic
					 */
					if (is_null($mixValue)) {
						$this->intTopic = null;
						$this->objTopicObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a YearsubjectHasTopic object
						try {
							$mixValue = QType::Cast($mixValue, 'YearsubjectHasTopic');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED YearsubjectHasTopic object
						if (is_null($mixValue->IdyearsubjectHasTopic))
							throw new QCallerException('Unable to set an unsaved TopicObject for this Quation');

						// Update Local Member Variables
						$this->objTopicObject = $mixValue;
						$this->intTopic = $mixValue->IdyearsubjectHasTopic;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ExampaperObject':
					/**
					 * Sets the value for the Exampaper object referenced by intExampaper 
					 * @param Exampaper $mixValue
					 * @return Exampaper
					 */
					if (is_null($mixValue)) {
						$this->intExampaper = null;
						$this->objExampaperObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Exampaper object
						try {
							$mixValue = QType::Cast($mixValue, 'Exampaper');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Exampaper object
						if (is_null($mixValue->Idexampaper))
							throw new QCallerException('Unable to set an unsaved ExampaperObject for this Quation');

						// Update Local Member Variables
						$this->objExampaperObject = $mixValue;
						$this->intExampaper = $mixValue->Idexampaper;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for QuationAsParrent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated QuationsAsParrent as an array of Quation objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Quation[]
		*/
		public function GetQuationAsParrentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdquation)))
				return array();

			try {
				return Quation::LoadArrayByParrent($this->intIdquation, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated QuationsAsParrent
		 * @return int
		*/
		public function CountQuationsAsParrent() {
			if ((is_null($this->intIdquation)))
				return 0;

			return Quation::CountByParrent($this->intIdquation);
		}

		/**
		 * Associates a QuationAsParrent
		 * @param Quation $objQuation
		 * @return void
		*/
		public function AssociateQuationAsParrent(Quation $objQuation) {
			if ((is_null($this->intIdquation)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateQuationAsParrent on this unsaved Quation.');
			if ((is_null($objQuation->Idquation)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateQuationAsParrent on this Quation with an unsaved Quation.');

			// Get the Database Object for this Class
			$objDatabase = Quation::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`quation`
				SET
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdquation) . '
				WHERE
					`idquation` = ' . $objDatabase->SqlVariable($objQuation->Idquation) . '
			');
		}

		/**
		 * Unassociates a QuationAsParrent
		 * @param Quation $objQuation
		 * @return void
		*/
		public function UnassociateQuationAsParrent(Quation $objQuation) {
			if ((is_null($this->intIdquation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateQuationAsParrent on this unsaved Quation.');
			if ((is_null($objQuation->Idquation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateQuationAsParrent on this Quation with an unsaved Quation.');

			// Get the Database Object for this Class
			$objDatabase = Quation::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`quation`
				SET
					`parrent` = null
				WHERE
					`idquation` = ' . $objDatabase->SqlVariable($objQuation->Idquation) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdquation) . '
			');
		}

		/**
		 * Unassociates all QuationsAsParrent
		 * @return void
		*/
		public function UnassociateAllQuationsAsParrent() {
			if ((is_null($this->intIdquation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateQuationAsParrent on this unsaved Quation.');

			// Get the Database Object for this Class
			$objDatabase = Quation::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`quation`
				SET
					`parrent` = null
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdquation) . '
			');
		}

		/**
		 * Deletes an associated QuationAsParrent
		 * @param Quation $objQuation
		 * @return void
		*/
		public function DeleteAssociatedQuationAsParrent(Quation $objQuation) {
			if ((is_null($this->intIdquation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateQuationAsParrent on this unsaved Quation.');
			if ((is_null($objQuation->Idquation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateQuationAsParrent on this Quation with an unsaved Quation.');

			// Get the Database Object for this Class
			$objDatabase = Quation::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`quation`
				WHERE
					`idquation` = ' . $objDatabase->SqlVariable($objQuation->Idquation) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdquation) . '
			');
		}

		/**
		 * Deletes all associated QuationsAsParrent
		 * @return void
		*/
		public function DeleteAllQuationsAsParrent() {
			if ((is_null($this->intIdquation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateQuationAsParrent on this unsaved Quation.');

			// Get the Database Object for this Class
			$objDatabase = Quation::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`quation`
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdquation) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "quation";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Quation::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Quation"><sequence>';
			$strToReturn .= '<element name="Idquation" type="xsd:int"/>';
			$strToReturn .= '<element name="Code" type="xsd:string"/>';
			$strToReturn .= '<element name="Seq" type="xsd:int"/>';
			$strToReturn .= '<element name="ParrentObject" type="xsd1:Quation"/>';
			$strToReturn .= '<element name="Quation" type="xsd:string"/>';
			$strToReturn .= '<element name="TopicObject" type="xsd1:YearsubjectHasTopic"/>';
			$strToReturn .= '<element name="Credit" type="xsd:string"/>';
			$strToReturn .= '<element name="ModelAnswer" type="xsd:string"/>';
			$strToReturn .= '<element name="ExampaperObject" type="xsd1:Exampaper"/>';
			$strToReturn .= '<element name="Marks" type="xsd:int"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Quation', $strComplexTypeArray)) {
				$strComplexTypeArray['Quation'] = Quation::GetSoapComplexTypeXml();
				Quation::AlterSoapComplexTypeArray($strComplexTypeArray);
				YearsubjectHasTopic::AlterSoapComplexTypeArray($strComplexTypeArray);
				Exampaper::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Quation::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Quation();
			if (property_exists($objSoapObject, 'Idquation'))
				$objToReturn->intIdquation = $objSoapObject->Idquation;
			if (property_exists($objSoapObject, 'Code'))
				$objToReturn->strCode = $objSoapObject->Code;
			if (property_exists($objSoapObject, 'Seq'))
				$objToReturn->intSeq = $objSoapObject->Seq;
			if ((property_exists($objSoapObject, 'ParrentObject')) &&
				($objSoapObject->ParrentObject))
				$objToReturn->ParrentObject = Quation::GetObjectFromSoapObject($objSoapObject->ParrentObject);
			if (property_exists($objSoapObject, 'Quation'))
				$objToReturn->strQuation = $objSoapObject->Quation;
			if ((property_exists($objSoapObject, 'TopicObject')) &&
				($objSoapObject->TopicObject))
				$objToReturn->TopicObject = YearsubjectHasTopic::GetObjectFromSoapObject($objSoapObject->TopicObject);
			if (property_exists($objSoapObject, 'Credit'))
				$objToReturn->strCredit = $objSoapObject->Credit;
			if (property_exists($objSoapObject, 'ModelAnswer'))
				$objToReturn->strModelAnswer = $objSoapObject->ModelAnswer;
			if ((property_exists($objSoapObject, 'ExampaperObject')) &&
				($objSoapObject->ExampaperObject))
				$objToReturn->ExampaperObject = Exampaper::GetObjectFromSoapObject($objSoapObject->ExampaperObject);
			if (property_exists($objSoapObject, 'Marks'))
				$objToReturn->intMarks = $objSoapObject->Marks;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Quation::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objParrentObject)
				$objObject->objParrentObject = Quation::GetSoapObjectFromObject($objObject->objParrentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intParrent = null;
			if ($objObject->objTopicObject)
				$objObject->objTopicObject = YearsubjectHasTopic::GetSoapObjectFromObject($objObject->objTopicObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intTopic = null;
			if ($objObject->objExampaperObject)
				$objObject->objExampaperObject = Exampaper::GetSoapObjectFromObject($objObject->objExampaperObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intExampaper = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idquation'] = $this->intIdquation;
			$iArray['Code'] = $this->strCode;
			$iArray['Seq'] = $this->intSeq;
			$iArray['Parrent'] = $this->intParrent;
			$iArray['Quation'] = $this->strQuation;
			$iArray['Topic'] = $this->intTopic;
			$iArray['Credit'] = $this->strCredit;
			$iArray['ModelAnswer'] = $this->strModelAnswer;
			$iArray['Exampaper'] = $this->intExampaper;
			$iArray['Marks'] = $this->intMarks;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdquation ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idquation
     * @property-read QQNode $Code
     * @property-read QQNode $Seq
     * @property-read QQNode $Parrent
     * @property-read QQNodeQuation $ParrentObject
     * @property-read QQNode $Quation
     * @property-read QQNode $Topic
     * @property-read QQNodeYearsubjectHasTopic $TopicObject
     * @property-read QQNode $Credit
     * @property-read QQNode $ModelAnswer
     * @property-read QQNode $Exampaper
     * @property-read QQNodeExampaper $ExampaperObject
     * @property-read QQNode $Marks
     *
     *
     * @property-read QQReverseReferenceNodeQuation $QuationAsParrent

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeQuation extends QQNode {
		protected $strTableName = 'quation';
		protected $strPrimaryKey = 'idquation';
		protected $strClassName = 'Quation';
		public function __get($strName) {
			switch ($strName) {
				case 'Idquation':
					return new QQNode('idquation', 'Idquation', 'Integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'VarChar', $this);
				case 'Seq':
					return new QQNode('seq', 'Seq', 'Integer', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'Integer', $this);
				case 'ParrentObject':
					return new QQNodeQuation('parrent', 'ParrentObject', 'Integer', $this);
				case 'Quation':
					return new QQNode('quation', 'Quation', 'Blob', $this);
				case 'Topic':
					return new QQNode('topic', 'Topic', 'Integer', $this);
				case 'TopicObject':
					return new QQNodeYearsubjectHasTopic('topic', 'TopicObject', 'Integer', $this);
				case 'Credit':
					return new QQNode('credit', 'Credit', 'VarChar', $this);
				case 'ModelAnswer':
					return new QQNode('model_answer', 'ModelAnswer', 'Blob', $this);
				case 'Exampaper':
					return new QQNode('exampaper', 'Exampaper', 'Integer', $this);
				case 'ExampaperObject':
					return new QQNodeExampaper('exampaper', 'ExampaperObject', 'Integer', $this);
				case 'Marks':
					return new QQNode('marks', 'Marks', 'Integer', $this);
				case 'QuationAsParrent':
					return new QQReverseReferenceNodeQuation($this, 'quationasparrent', 'reverse_reference', 'parrent');

				case '_PrimaryKeyNode':
					return new QQNode('idquation', 'Idquation', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idquation
     * @property-read QQNode $Code
     * @property-read QQNode $Seq
     * @property-read QQNode $Parrent
     * @property-read QQNodeQuation $ParrentObject
     * @property-read QQNode $Quation
     * @property-read QQNode $Topic
     * @property-read QQNodeYearsubjectHasTopic $TopicObject
     * @property-read QQNode $Credit
     * @property-read QQNode $ModelAnswer
     * @property-read QQNode $Exampaper
     * @property-read QQNodeExampaper $ExampaperObject
     * @property-read QQNode $Marks
     *
     *
     * @property-read QQReverseReferenceNodeQuation $QuationAsParrent

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeQuation extends QQReverseReferenceNode {
		protected $strTableName = 'quation';
		protected $strPrimaryKey = 'idquation';
		protected $strClassName = 'Quation';
		public function __get($strName) {
			switch ($strName) {
				case 'Idquation':
					return new QQNode('idquation', 'Idquation', 'integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'string', $this);
				case 'Seq':
					return new QQNode('seq', 'Seq', 'integer', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'integer', $this);
				case 'ParrentObject':
					return new QQNodeQuation('parrent', 'ParrentObject', 'integer', $this);
				case 'Quation':
					return new QQNode('quation', 'Quation', 'string', $this);
				case 'Topic':
					return new QQNode('topic', 'Topic', 'integer', $this);
				case 'TopicObject':
					return new QQNodeYearsubjectHasTopic('topic', 'TopicObject', 'integer', $this);
				case 'Credit':
					return new QQNode('credit', 'Credit', 'string', $this);
				case 'ModelAnswer':
					return new QQNode('model_answer', 'ModelAnswer', 'string', $this);
				case 'Exampaper':
					return new QQNode('exampaper', 'Exampaper', 'integer', $this);
				case 'ExampaperObject':
					return new QQNodeExampaper('exampaper', 'ExampaperObject', 'integer', $this);
				case 'Marks':
					return new QQNode('marks', 'Marks', 'integer', $this);
				case 'QuationAsParrent':
					return new QQReverseReferenceNodeQuation($this, 'quationasparrent', 'reverse_reference', 'parrent');

				case '_PrimaryKeyNode':
					return new QQNode('idquation', 'Idquation', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
