<?php
	/**
	 * The abstract BatchGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Batch subclass which
	 * extends this BatchGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Batch class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idbatch the value for intIdbatch (Read-Only PK)
	 * @property string $Batchno the value for strBatchno (Not Null)
	 * @property integer $Item the value for intItem 
	 * @property string $Inword the value for strInword 
	 * @property string $Outword the value for strOutword 
	 * @property string $Return the value for strReturn 
	 * @property string $Remaining the value for strRemaining 
	 * @property QDateTime $Expiry the value for dttExpiry 
	 * @property QDateTime $Date the value for dttDate 
	 * @property string $Cost the value for strCost 
	 * @property string $Dp the value for strDp 
	 * @property string $Mrp the value for strMrp 
	 * @property LedgerDetails $ItemObject the value for the LedgerDetails object referenced by intItem 
	 * @property-read VoucherHasItem $_VoucherHasItem the value for the private _objVoucherHasItem (Read-Only) if set due to an expansion on the voucher_has_item.batch reverse relationship
	 * @property-read VoucherHasItem[] $_VoucherHasItemArray the value for the private _objVoucherHasItemArray (Read-Only) if set due to an ExpandAsArray on the voucher_has_item.batch reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class BatchGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column batch.idbatch
		 * @var integer intIdbatch
		 */
		protected $intIdbatch;
		const IdbatchDefault = null;


		/**
		 * Protected member variable that maps to the database column batch.batchno
		 * @var string strBatchno
		 */
		protected $strBatchno;
		const BatchnoMaxLength = 255;
		const BatchnoDefault = null;


		/**
		 * Protected member variable that maps to the database column batch.item
		 * @var integer intItem
		 */
		protected $intItem;
		const ItemDefault = null;


		/**
		 * Protected member variable that maps to the database column batch.inword
		 * @var string strInword
		 */
		protected $strInword;
		const InwordDefault = null;


		/**
		 * Protected member variable that maps to the database column batch.outword
		 * @var string strOutword
		 */
		protected $strOutword;
		const OutwordDefault = null;


		/**
		 * Protected member variable that maps to the database column batch.return
		 * @var string strReturn
		 */
		protected $strReturn;
		const ReturnDefault = null;


		/**
		 * Protected member variable that maps to the database column batch.remaining
		 * @var string strRemaining
		 */
		protected $strRemaining;
		const RemainingDefault = null;


		/**
		 * Protected member variable that maps to the database column batch.expiry
		 * @var QDateTime dttExpiry
		 */
		protected $dttExpiry;
		const ExpiryDefault = null;


		/**
		 * Protected member variable that maps to the database column batch.date
		 * @var QDateTime dttDate
		 */
		protected $dttDate;
		const DateDefault = null;


		/**
		 * Protected member variable that maps to the database column batch.cost
		 * @var string strCost
		 */
		protected $strCost;
		const CostDefault = null;


		/**
		 * Protected member variable that maps to the database column batch.dp
		 * @var string strDp
		 */
		protected $strDp;
		const DpDefault = null;


		/**
		 * Protected member variable that maps to the database column batch.mrp
		 * @var string strMrp
		 */
		protected $strMrp;
		const MrpDefault = null;


		/**
		 * Private member variable that stores a reference to a single VoucherHasItem object
		 * (of type VoucherHasItem), if this Batch object was restored with
		 * an expansion on the voucher_has_item association table.
		 * @var VoucherHasItem _objVoucherHasItem;
		 */
		private $_objVoucherHasItem;

		/**
		 * Private member variable that stores a reference to an array of VoucherHasItem objects
		 * (of type VoucherHasItem[]), if this Batch object was restored with
		 * an ExpandAsArray on the voucher_has_item association table.
		 * @var VoucherHasItem[] _objVoucherHasItemArray;
		 */
		private $_objVoucherHasItemArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column batch.item.
		 *
		 * NOTE: Always use the ItemObject property getter to correctly retrieve this LedgerDetails object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var LedgerDetails objItemObject
		 */
		protected $objItemObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdbatch = Batch::IdbatchDefault;
			$this->strBatchno = Batch::BatchnoDefault;
			$this->intItem = Batch::ItemDefault;
			$this->strInword = Batch::InwordDefault;
			$this->strOutword = Batch::OutwordDefault;
			$this->strReturn = Batch::ReturnDefault;
			$this->strRemaining = Batch::RemainingDefault;
			$this->dttExpiry = (Batch::ExpiryDefault === null)?null:new QDateTime(Batch::ExpiryDefault);
			$this->dttDate = (Batch::DateDefault === null)?null:new QDateTime(Batch::DateDefault);
			$this->strCost = Batch::CostDefault;
			$this->strDp = Batch::DpDefault;
			$this->strMrp = Batch::MrpDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Batch from PK Info
		 * @param integer $intIdbatch
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Batch
		 */
		public static function Load($intIdbatch, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Batch', $intIdbatch);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Batch::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Batch()->Idbatch, $intIdbatch)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Batches
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Batch[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Batch::QueryArray to perform the LoadAll query
			try {
				return Batch::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Batches
		 * @return int
		 */
		public static function CountAll() {
			// Call Batch::QueryCount to perform the CountAll query
			return Batch::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Batch::GetDatabase();

			// Create/Build out the QueryBuilder object with Batch-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'batch');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Batch::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('batch');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Batch object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Batch the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Batch::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Batch object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Batch::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Batch::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Batch objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Batch[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Batch::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Batch::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Batch::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Batch objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Batch::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Batch::GetDatabase();

			$strQuery = Batch::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/batch', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Batch::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Batch
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'batch';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idbatch', $strAliasPrefix . 'idbatch');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idbatch', $strAliasPrefix . 'idbatch');
			    $objBuilder->AddSelectItem($strTableName, 'batchno', $strAliasPrefix . 'batchno');
			    $objBuilder->AddSelectItem($strTableName, 'item', $strAliasPrefix . 'item');
			    $objBuilder->AddSelectItem($strTableName, 'inword', $strAliasPrefix . 'inword');
			    $objBuilder->AddSelectItem($strTableName, 'outword', $strAliasPrefix . 'outword');
			    $objBuilder->AddSelectItem($strTableName, 'return', $strAliasPrefix . 'return');
			    $objBuilder->AddSelectItem($strTableName, 'remaining', $strAliasPrefix . 'remaining');
			    $objBuilder->AddSelectItem($strTableName, 'expiry', $strAliasPrefix . 'expiry');
			    $objBuilder->AddSelectItem($strTableName, 'date', $strAliasPrefix . 'date');
			    $objBuilder->AddSelectItem($strTableName, 'cost', $strAliasPrefix . 'cost');
			    $objBuilder->AddSelectItem($strTableName, 'dp', $strAliasPrefix . 'dp');
			    $objBuilder->AddSelectItem($strTableName, 'mrp', $strAliasPrefix . 'mrp');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Batch from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Batch::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Batch
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idbatch';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdbatch == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'batch__';


						// Expanding reverse references: VoucherHasItem
						$strAlias = $strAliasPrefix . 'voucherhasitem__idvoucher_has_item';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objVoucherHasItemArray)
								$objPreviousItem->_objVoucherHasItemArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objVoucherHasItemArray)) {
								$objPreviousChildItems = $objPreviousItem->_objVoucherHasItemArray;
								$objChildItem = VoucherHasItem::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherhasitem__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objVoucherHasItemArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objVoucherHasItemArray[] = VoucherHasItem::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherhasitem__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'batch__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Batch object
			$objToReturn = new Batch();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idbatch';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdbatch = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'batchno';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strBatchno = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'item';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intItem = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'inword';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strInword = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'outword';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strOutword = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'return';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strReturn = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'remaining';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strRemaining = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'expiry';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttExpiry = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'cost';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCost = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'dp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strDp = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'mrp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strMrp = $objDbRow->GetColumn($strAliasName, 'VarChar');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idbatch != $objPreviousItem->Idbatch) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objVoucherHasItemArray);
					$cnt = count($objToReturn->_objVoucherHasItemArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objVoucherHasItemArray, $objToReturn->_objVoucherHasItemArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'batch__';

			// Check for ItemObject Early Binding
			$strAlias = $strAliasPrefix . 'item__idledger_details';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objItemObject = LedgerDetails::InstantiateDbRow($objDbRow, $strAliasPrefix . 'item__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for VoucherHasItem Virtual Binding
			$strAlias = $strAliasPrefix . 'voucherhasitem__idvoucher_has_item';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objVoucherHasItemArray)
				$objToReturn->_objVoucherHasItemArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objVoucherHasItemArray[] = VoucherHasItem::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherhasitem__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objVoucherHasItem = VoucherHasItem::InstantiateDbRow($objDbRow, $strAliasPrefix . 'voucherhasitem__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Batches from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Batch[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Batch::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Batch::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Batch object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Batch next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Batch::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Batch object,
		 * by Idbatch Index(es)
		 * @param integer $intIdbatch
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Batch
		*/
		public static function LoadByIdbatch($intIdbatch, $objOptionalClauses = null) {
			return Batch::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Batch()->Idbatch, $intIdbatch)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Batch objects,
		 * by Item Index(es)
		 * @param integer $intItem
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Batch[]
		*/
		public static function LoadArrayByItem($intItem, $objOptionalClauses = null) {
			// Call Batch::QueryArray to perform the LoadArrayByItem query
			try {
				return Batch::QueryArray(
					QQ::Equal(QQN::Batch()->Item, $intItem),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Batches
		 * by Item Index(es)
		 * @param integer $intItem
		 * @return int
		*/
		public static function CountByItem($intItem) {
			// Call Batch::QueryCount to perform the CountByItem query
			return Batch::QueryCount(
				QQ::Equal(QQN::Batch()->Item, $intItem)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Batch
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Batch::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `batch` (
							`batchno`,
							`item`,
							`inword`,
							`outword`,
							`return`,
							`remaining`,
							`expiry`,
							`date`,
							`cost`,
							`dp`,
							`mrp`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strBatchno) . ',
							' . $objDatabase->SqlVariable($this->intItem) . ',
							' . $objDatabase->SqlVariable($this->strInword) . ',
							' . $objDatabase->SqlVariable($this->strOutword) . ',
							' . $objDatabase->SqlVariable($this->strReturn) . ',
							' . $objDatabase->SqlVariable($this->strRemaining) . ',
							' . $objDatabase->SqlVariable($this->dttExpiry) . ',
							' . $objDatabase->SqlVariable($this->dttDate) . ',
							' . $objDatabase->SqlVariable($this->strCost) . ',
							' . $objDatabase->SqlVariable($this->strDp) . ',
							' . $objDatabase->SqlVariable($this->strMrp) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdbatch = $objDatabase->InsertId('batch', 'idbatch');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`batch`
						SET
							`batchno` = ' . $objDatabase->SqlVariable($this->strBatchno) . ',
							`item` = ' . $objDatabase->SqlVariable($this->intItem) . ',
							`inword` = ' . $objDatabase->SqlVariable($this->strInword) . ',
							`outword` = ' . $objDatabase->SqlVariable($this->strOutword) . ',
							`return` = ' . $objDatabase->SqlVariable($this->strReturn) . ',
							`remaining` = ' . $objDatabase->SqlVariable($this->strRemaining) . ',
							`expiry` = ' . $objDatabase->SqlVariable($this->dttExpiry) . ',
							`date` = ' . $objDatabase->SqlVariable($this->dttDate) . ',
							`cost` = ' . $objDatabase->SqlVariable($this->strCost) . ',
							`dp` = ' . $objDatabase->SqlVariable($this->strDp) . ',
							`mrp` = ' . $objDatabase->SqlVariable($this->strMrp) . '
						WHERE
							`idbatch` = ' . $objDatabase->SqlVariable($this->intIdbatch) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Batch
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdbatch)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Batch with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Batch::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`batch`
				WHERE
					`idbatch` = ' . $objDatabase->SqlVariable($this->intIdbatch) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Batch ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Batch', $this->intIdbatch);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Batches
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Batch::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`batch`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate batch table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Batch::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `batch`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Batch from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Batch object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Batch::Load($this->intIdbatch);

			// Update $this's local variables to match
			$this->strBatchno = $objReloaded->strBatchno;
			$this->Item = $objReloaded->Item;
			$this->strInword = $objReloaded->strInword;
			$this->strOutword = $objReloaded->strOutword;
			$this->strReturn = $objReloaded->strReturn;
			$this->strRemaining = $objReloaded->strRemaining;
			$this->dttExpiry = $objReloaded->dttExpiry;
			$this->dttDate = $objReloaded->dttDate;
			$this->strCost = $objReloaded->strCost;
			$this->strDp = $objReloaded->strDp;
			$this->strMrp = $objReloaded->strMrp;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idbatch':
					/**
					 * Gets the value for intIdbatch (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdbatch;

				case 'Batchno':
					/**
					 * Gets the value for strBatchno (Not Null)
					 * @return string
					 */
					return $this->strBatchno;

				case 'Item':
					/**
					 * Gets the value for intItem 
					 * @return integer
					 */
					return $this->intItem;

				case 'Inword':
					/**
					 * Gets the value for strInword 
					 * @return string
					 */
					return $this->strInword;

				case 'Outword':
					/**
					 * Gets the value for strOutword 
					 * @return string
					 */
					return $this->strOutword;

				case 'Return':
					/**
					 * Gets the value for strReturn 
					 * @return string
					 */
					return $this->strReturn;

				case 'Remaining':
					/**
					 * Gets the value for strRemaining 
					 * @return string
					 */
					return $this->strRemaining;

				case 'Expiry':
					/**
					 * Gets the value for dttExpiry 
					 * @return QDateTime
					 */
					return $this->dttExpiry;

				case 'Date':
					/**
					 * Gets the value for dttDate 
					 * @return QDateTime
					 */
					return $this->dttDate;

				case 'Cost':
					/**
					 * Gets the value for strCost 
					 * @return string
					 */
					return $this->strCost;

				case 'Dp':
					/**
					 * Gets the value for strDp 
					 * @return string
					 */
					return $this->strDp;

				case 'Mrp':
					/**
					 * Gets the value for strMrp 
					 * @return string
					 */
					return $this->strMrp;


				///////////////////
				// Member Objects
				///////////////////
				case 'ItemObject':
					/**
					 * Gets the value for the LedgerDetails object referenced by intItem 
					 * @return LedgerDetails
					 */
					try {
						if ((!$this->objItemObject) && (!is_null($this->intItem)))
							$this->objItemObject = LedgerDetails::Load($this->intItem);
						return $this->objItemObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_VoucherHasItem':
					/**
					 * Gets the value for the private _objVoucherHasItem (Read-Only)
					 * if set due to an expansion on the voucher_has_item.batch reverse relationship
					 * @return VoucherHasItem
					 */
					return $this->_objVoucherHasItem;

				case '_VoucherHasItemArray':
					/**
					 * Gets the value for the private _objVoucherHasItemArray (Read-Only)
					 * if set due to an ExpandAsArray on the voucher_has_item.batch reverse relationship
					 * @return VoucherHasItem[]
					 */
					return $this->_objVoucherHasItemArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Batchno':
					/**
					 * Sets the value for strBatchno (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strBatchno = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Item':
					/**
					 * Sets the value for intItem 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objItemObject = null;
						return ($this->intItem = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Inword':
					/**
					 * Sets the value for strInword 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strInword = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Outword':
					/**
					 * Sets the value for strOutword 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strOutword = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Return':
					/**
					 * Sets the value for strReturn 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strReturn = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Remaining':
					/**
					 * Sets the value for strRemaining 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strRemaining = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Expiry':
					/**
					 * Sets the value for dttExpiry 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttExpiry = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Date':
					/**
					 * Sets the value for dttDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Cost':
					/**
					 * Sets the value for strCost 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCost = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Dp':
					/**
					 * Sets the value for strDp 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strDp = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Mrp':
					/**
					 * Sets the value for strMrp 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strMrp = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'ItemObject':
					/**
					 * Sets the value for the LedgerDetails object referenced by intItem 
					 * @param LedgerDetails $mixValue
					 * @return LedgerDetails
					 */
					if (is_null($mixValue)) {
						$this->intItem = null;
						$this->objItemObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a LedgerDetails object
						try {
							$mixValue = QType::Cast($mixValue, 'LedgerDetails');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED LedgerDetails object
						if (is_null($mixValue->IdledgerDetails))
							throw new QCallerException('Unable to set an unsaved ItemObject for this Batch');

						// Update Local Member Variables
						$this->objItemObject = $mixValue;
						$this->intItem = $mixValue->IdledgerDetails;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for VoucherHasItem
		//-------------------------------------------------------------------

		/**
		 * Gets all associated VoucherHasItems as an array of VoucherHasItem objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return VoucherHasItem[]
		*/
		public function GetVoucherHasItemArray($objOptionalClauses = null) {
			if ((is_null($this->intIdbatch)))
				return array();

			try {
				return VoucherHasItem::LoadArrayByBatch($this->intIdbatch, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated VoucherHasItems
		 * @return int
		*/
		public function CountVoucherHasItems() {
			if ((is_null($this->intIdbatch)))
				return 0;

			return VoucherHasItem::CountByBatch($this->intIdbatch);
		}

		/**
		 * Associates a VoucherHasItem
		 * @param VoucherHasItem $objVoucherHasItem
		 * @return void
		*/
		public function AssociateVoucherHasItem(VoucherHasItem $objVoucherHasItem) {
			if ((is_null($this->intIdbatch)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherHasItem on this unsaved Batch.');
			if ((is_null($objVoucherHasItem->IdvoucherHasItem)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateVoucherHasItem on this Batch with an unsaved VoucherHasItem.');

			// Get the Database Object for this Class
			$objDatabase = Batch::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher_has_item`
				SET
					`batch` = ' . $objDatabase->SqlVariable($this->intIdbatch) . '
				WHERE
					`idvoucher_has_item` = ' . $objDatabase->SqlVariable($objVoucherHasItem->IdvoucherHasItem) . '
			');
		}

		/**
		 * Unassociates a VoucherHasItem
		 * @param VoucherHasItem $objVoucherHasItem
		 * @return void
		*/
		public function UnassociateVoucherHasItem(VoucherHasItem $objVoucherHasItem) {
			if ((is_null($this->intIdbatch)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherHasItem on this unsaved Batch.');
			if ((is_null($objVoucherHasItem->IdvoucherHasItem)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherHasItem on this Batch with an unsaved VoucherHasItem.');

			// Get the Database Object for this Class
			$objDatabase = Batch::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher_has_item`
				SET
					`batch` = null
				WHERE
					`idvoucher_has_item` = ' . $objDatabase->SqlVariable($objVoucherHasItem->IdvoucherHasItem) . ' AND
					`batch` = ' . $objDatabase->SqlVariable($this->intIdbatch) . '
			');
		}

		/**
		 * Unassociates all VoucherHasItems
		 * @return void
		*/
		public function UnassociateAllVoucherHasItems() {
			if ((is_null($this->intIdbatch)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherHasItem on this unsaved Batch.');

			// Get the Database Object for this Class
			$objDatabase = Batch::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`voucher_has_item`
				SET
					`batch` = null
				WHERE
					`batch` = ' . $objDatabase->SqlVariable($this->intIdbatch) . '
			');
		}

		/**
		 * Deletes an associated VoucherHasItem
		 * @param VoucherHasItem $objVoucherHasItem
		 * @return void
		*/
		public function DeleteAssociatedVoucherHasItem(VoucherHasItem $objVoucherHasItem) {
			if ((is_null($this->intIdbatch)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherHasItem on this unsaved Batch.');
			if ((is_null($objVoucherHasItem->IdvoucherHasItem)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherHasItem on this Batch with an unsaved VoucherHasItem.');

			// Get the Database Object for this Class
			$objDatabase = Batch::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher_has_item`
				WHERE
					`idvoucher_has_item` = ' . $objDatabase->SqlVariable($objVoucherHasItem->IdvoucherHasItem) . ' AND
					`batch` = ' . $objDatabase->SqlVariable($this->intIdbatch) . '
			');
		}

		/**
		 * Deletes all associated VoucherHasItems
		 * @return void
		*/
		public function DeleteAllVoucherHasItems() {
			if ((is_null($this->intIdbatch)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateVoucherHasItem on this unsaved Batch.');

			// Get the Database Object for this Class
			$objDatabase = Batch::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`voucher_has_item`
				WHERE
					`batch` = ' . $objDatabase->SqlVariable($this->intIdbatch) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "batch";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Batch::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Batch"><sequence>';
			$strToReturn .= '<element name="Idbatch" type="xsd:int"/>';
			$strToReturn .= '<element name="Batchno" type="xsd:string"/>';
			$strToReturn .= '<element name="ItemObject" type="xsd1:LedgerDetails"/>';
			$strToReturn .= '<element name="Inword" type="xsd:string"/>';
			$strToReturn .= '<element name="Outword" type="xsd:string"/>';
			$strToReturn .= '<element name="Return" type="xsd:string"/>';
			$strToReturn .= '<element name="Remaining" type="xsd:string"/>';
			$strToReturn .= '<element name="Expiry" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Date" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Cost" type="xsd:string"/>';
			$strToReturn .= '<element name="Dp" type="xsd:string"/>';
			$strToReturn .= '<element name="Mrp" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Batch', $strComplexTypeArray)) {
				$strComplexTypeArray['Batch'] = Batch::GetSoapComplexTypeXml();
				LedgerDetails::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Batch::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Batch();
			if (property_exists($objSoapObject, 'Idbatch'))
				$objToReturn->intIdbatch = $objSoapObject->Idbatch;
			if (property_exists($objSoapObject, 'Batchno'))
				$objToReturn->strBatchno = $objSoapObject->Batchno;
			if ((property_exists($objSoapObject, 'ItemObject')) &&
				($objSoapObject->ItemObject))
				$objToReturn->ItemObject = LedgerDetails::GetObjectFromSoapObject($objSoapObject->ItemObject);
			if (property_exists($objSoapObject, 'Inword'))
				$objToReturn->strInword = $objSoapObject->Inword;
			if (property_exists($objSoapObject, 'Outword'))
				$objToReturn->strOutword = $objSoapObject->Outword;
			if (property_exists($objSoapObject, 'Return'))
				$objToReturn->strReturn = $objSoapObject->Return;
			if (property_exists($objSoapObject, 'Remaining'))
				$objToReturn->strRemaining = $objSoapObject->Remaining;
			if (property_exists($objSoapObject, 'Expiry'))
				$objToReturn->dttExpiry = new QDateTime($objSoapObject->Expiry);
			if (property_exists($objSoapObject, 'Date'))
				$objToReturn->dttDate = new QDateTime($objSoapObject->Date);
			if (property_exists($objSoapObject, 'Cost'))
				$objToReturn->strCost = $objSoapObject->Cost;
			if (property_exists($objSoapObject, 'Dp'))
				$objToReturn->strDp = $objSoapObject->Dp;
			if (property_exists($objSoapObject, 'Mrp'))
				$objToReturn->strMrp = $objSoapObject->Mrp;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Batch::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objItemObject)
				$objObject->objItemObject = LedgerDetails::GetSoapObjectFromObject($objObject->objItemObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intItem = null;
			if ($objObject->dttExpiry)
				$objObject->dttExpiry = $objObject->dttExpiry->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttDate)
				$objObject->dttDate = $objObject->dttDate->qFormat(QDateTime::FormatSoap);
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idbatch'] = $this->intIdbatch;
			$iArray['Batchno'] = $this->strBatchno;
			$iArray['Item'] = $this->intItem;
			$iArray['Inword'] = $this->strInword;
			$iArray['Outword'] = $this->strOutword;
			$iArray['Return'] = $this->strReturn;
			$iArray['Remaining'] = $this->strRemaining;
			$iArray['Expiry'] = $this->dttExpiry;
			$iArray['Date'] = $this->dttDate;
			$iArray['Cost'] = $this->strCost;
			$iArray['Dp'] = $this->strDp;
			$iArray['Mrp'] = $this->strMrp;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdbatch ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idbatch
     * @property-read QQNode $Batchno
     * @property-read QQNode $Item
     * @property-read QQNodeLedgerDetails $ItemObject
     * @property-read QQNode $Inword
     * @property-read QQNode $Outword
     * @property-read QQNode $Return
     * @property-read QQNode $Remaining
     * @property-read QQNode $Expiry
     * @property-read QQNode $Date
     * @property-read QQNode $Cost
     * @property-read QQNode $Dp
     * @property-read QQNode $Mrp
     *
     *
     * @property-read QQReverseReferenceNodeVoucherHasItem $VoucherHasItem

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeBatch extends QQNode {
		protected $strTableName = 'batch';
		protected $strPrimaryKey = 'idbatch';
		protected $strClassName = 'Batch';
		public function __get($strName) {
			switch ($strName) {
				case 'Idbatch':
					return new QQNode('idbatch', 'Idbatch', 'Integer', $this);
				case 'Batchno':
					return new QQNode('batchno', 'Batchno', 'VarChar', $this);
				case 'Item':
					return new QQNode('item', 'Item', 'Integer', $this);
				case 'ItemObject':
					return new QQNodeLedgerDetails('item', 'ItemObject', 'Integer', $this);
				case 'Inword':
					return new QQNode('inword', 'Inword', 'VarChar', $this);
				case 'Outword':
					return new QQNode('outword', 'Outword', 'VarChar', $this);
				case 'Return':
					return new QQNode('return', 'Return', 'VarChar', $this);
				case 'Remaining':
					return new QQNode('remaining', 'Remaining', 'VarChar', $this);
				case 'Expiry':
					return new QQNode('expiry', 'Expiry', 'Date', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'Date', $this);
				case 'Cost':
					return new QQNode('cost', 'Cost', 'VarChar', $this);
				case 'Dp':
					return new QQNode('dp', 'Dp', 'VarChar', $this);
				case 'Mrp':
					return new QQNode('mrp', 'Mrp', 'VarChar', $this);
				case 'VoucherHasItem':
					return new QQReverseReferenceNodeVoucherHasItem($this, 'voucherhasitem', 'reverse_reference', 'batch');

				case '_PrimaryKeyNode':
					return new QQNode('idbatch', 'Idbatch', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idbatch
     * @property-read QQNode $Batchno
     * @property-read QQNode $Item
     * @property-read QQNodeLedgerDetails $ItemObject
     * @property-read QQNode $Inword
     * @property-read QQNode $Outword
     * @property-read QQNode $Return
     * @property-read QQNode $Remaining
     * @property-read QQNode $Expiry
     * @property-read QQNode $Date
     * @property-read QQNode $Cost
     * @property-read QQNode $Dp
     * @property-read QQNode $Mrp
     *
     *
     * @property-read QQReverseReferenceNodeVoucherHasItem $VoucherHasItem

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeBatch extends QQReverseReferenceNode {
		protected $strTableName = 'batch';
		protected $strPrimaryKey = 'idbatch';
		protected $strClassName = 'Batch';
		public function __get($strName) {
			switch ($strName) {
				case 'Idbatch':
					return new QQNode('idbatch', 'Idbatch', 'integer', $this);
				case 'Batchno':
					return new QQNode('batchno', 'Batchno', 'string', $this);
				case 'Item':
					return new QQNode('item', 'Item', 'integer', $this);
				case 'ItemObject':
					return new QQNodeLedgerDetails('item', 'ItemObject', 'integer', $this);
				case 'Inword':
					return new QQNode('inword', 'Inword', 'string', $this);
				case 'Outword':
					return new QQNode('outword', 'Outword', 'string', $this);
				case 'Return':
					return new QQNode('return', 'Return', 'string', $this);
				case 'Remaining':
					return new QQNode('remaining', 'Remaining', 'string', $this);
				case 'Expiry':
					return new QQNode('expiry', 'Expiry', 'QDateTime', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'QDateTime', $this);
				case 'Cost':
					return new QQNode('cost', 'Cost', 'string', $this);
				case 'Dp':
					return new QQNode('dp', 'Dp', 'string', $this);
				case 'Mrp':
					return new QQNode('mrp', 'Mrp', 'string', $this);
				case 'VoucherHasItem':
					return new QQReverseReferenceNodeVoucherHasItem($this, 'voucherhasitem', 'reverse_reference', 'batch');

				case '_PrimaryKeyNode':
					return new QQNode('idbatch', 'Idbatch', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
