<?php
	/**
	 * The abstract ExampaperGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Exampaper subclass which
	 * extends this ExampaperGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Exampaper class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idexampaper the value for intIdexampaper (Read-Only PK)
	 * @property integer $EventExam the value for intEventExam 
	 * @property string $Code the value for strCode 
	 * @property boolean $Isfinal the value for blnIsfinal 
	 * @property string $Narration the value for strNarration 
	 * @property integer $SetBy the value for intSetBy 
	 * @property integer $Application the value for intApplication 
	 * @property QDateTime $ConfirmDate the value for dttConfirmDate 
	 * @property QDateTime $Date the value for dttDate 
	 * @property integer $TotMarks the value for intTotMarks 
	 * @property QDateTime $From the value for dttFrom 
	 * @property QDateTime $To the value for dttTo 
	 * @property DeptYearEvents $EventExamObject the value for the DeptYearEvents object referenced by intEventExam 
	 * @property Login $SetByObject the value for the Login object referenced by intSetBy 
	 * @property Application $ApplicationObject the value for the Application object referenced by intApplication 
	 * @property-read Quation $_Quation the value for the private _objQuation (Read-Only) if set due to an expansion on the quation.exampaper reverse relationship
	 * @property-read Quation[] $_QuationArray the value for the private _objQuationArray (Read-Only) if set due to an ExpandAsArray on the quation.exampaper reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class ExampaperGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column exampaper.idexampaper
		 * @var integer intIdexampaper
		 */
		protected $intIdexampaper;
		const IdexampaperDefault = null;


		/**
		 * Protected member variable that maps to the database column exampaper.event_exam
		 * @var integer intEventExam
		 */
		protected $intEventExam;
		const EventExamDefault = null;


		/**
		 * Protected member variable that maps to the database column exampaper.code
		 * @var string strCode
		 */
		protected $strCode;
		const CodeMaxLength = 45;
		const CodeDefault = null;


		/**
		 * Protected member variable that maps to the database column exampaper.isfinal
		 * @var boolean blnIsfinal
		 */
		protected $blnIsfinal;
		const IsfinalDefault = null;


		/**
		 * Protected member variable that maps to the database column exampaper.narration
		 * @var string strNarration
		 */
		protected $strNarration;
		const NarrationDefault = null;


		/**
		 * Protected member variable that maps to the database column exampaper.set_by
		 * @var integer intSetBy
		 */
		protected $intSetBy;
		const SetByDefault = null;


		/**
		 * Protected member variable that maps to the database column exampaper.application
		 * @var integer intApplication
		 */
		protected $intApplication;
		const ApplicationDefault = null;


		/**
		 * Protected member variable that maps to the database column exampaper.confirm_date
		 * @var QDateTime dttConfirmDate
		 */
		protected $dttConfirmDate;
		const ConfirmDateDefault = null;


		/**
		 * Protected member variable that maps to the database column exampaper.date
		 * @var QDateTime dttDate
		 */
		protected $dttDate;
		const DateDefault = null;


		/**
		 * Protected member variable that maps to the database column exampaper.tot_marks
		 * @var integer intTotMarks
		 */
		protected $intTotMarks;
		const TotMarksDefault = null;


		/**
		 * Protected member variable that maps to the database column exampaper.from
		 * @var QDateTime dttFrom
		 */
		protected $dttFrom;
		const FromDefault = null;


		/**
		 * Protected member variable that maps to the database column exampaper.to
		 * @var QDateTime dttTo
		 */
		protected $dttTo;
		const ToDefault = null;


		/**
		 * Private member variable that stores a reference to a single Quation object
		 * (of type Quation), if this Exampaper object was restored with
		 * an expansion on the quation association table.
		 * @var Quation _objQuation;
		 */
		private $_objQuation;

		/**
		 * Private member variable that stores a reference to an array of Quation objects
		 * (of type Quation[]), if this Exampaper object was restored with
		 * an ExpandAsArray on the quation association table.
		 * @var Quation[] _objQuationArray;
		 */
		private $_objQuationArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column exampaper.event_exam.
		 *
		 * NOTE: Always use the EventExamObject property getter to correctly retrieve this DeptYearEvents object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var DeptYearEvents objEventExamObject
		 */
		protected $objEventExamObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column exampaper.set_by.
		 *
		 * NOTE: Always use the SetByObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objSetByObject
		 */
		protected $objSetByObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column exampaper.application.
		 *
		 * NOTE: Always use the ApplicationObject property getter to correctly retrieve this Application object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Application objApplicationObject
		 */
		protected $objApplicationObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdexampaper = Exampaper::IdexampaperDefault;
			$this->intEventExam = Exampaper::EventExamDefault;
			$this->strCode = Exampaper::CodeDefault;
			$this->blnIsfinal = Exampaper::IsfinalDefault;
			$this->strNarration = Exampaper::NarrationDefault;
			$this->intSetBy = Exampaper::SetByDefault;
			$this->intApplication = Exampaper::ApplicationDefault;
			$this->dttConfirmDate = (Exampaper::ConfirmDateDefault === null)?null:new QDateTime(Exampaper::ConfirmDateDefault);
			$this->dttDate = (Exampaper::DateDefault === null)?null:new QDateTime(Exampaper::DateDefault);
			$this->intTotMarks = Exampaper::TotMarksDefault;
			$this->dttFrom = (Exampaper::FromDefault === null)?null:new QDateTime(Exampaper::FromDefault);
			$this->dttTo = (Exampaper::ToDefault === null)?null:new QDateTime(Exampaper::ToDefault);
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Exampaper from PK Info
		 * @param integer $intIdexampaper
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Exampaper
		 */
		public static function Load($intIdexampaper, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Exampaper', $intIdexampaper);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Exampaper::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Exampaper()->Idexampaper, $intIdexampaper)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Exampapers
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Exampaper[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Exampaper::QueryArray to perform the LoadAll query
			try {
				return Exampaper::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Exampapers
		 * @return int
		 */
		public static function CountAll() {
			// Call Exampaper::QueryCount to perform the CountAll query
			return Exampaper::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Exampaper::GetDatabase();

			// Create/Build out the QueryBuilder object with Exampaper-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'exampaper');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Exampaper::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('exampaper');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Exampaper object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Exampaper the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Exampaper::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Exampaper object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Exampaper::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Exampaper::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Exampaper objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Exampaper[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Exampaper::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Exampaper::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Exampaper::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Exampaper objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Exampaper::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Exampaper::GetDatabase();

			$strQuery = Exampaper::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/exampaper', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Exampaper::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Exampaper
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'exampaper';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idexampaper', $strAliasPrefix . 'idexampaper');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idexampaper', $strAliasPrefix . 'idexampaper');
			    $objBuilder->AddSelectItem($strTableName, 'event_exam', $strAliasPrefix . 'event_exam');
			    $objBuilder->AddSelectItem($strTableName, 'code', $strAliasPrefix . 'code');
			    $objBuilder->AddSelectItem($strTableName, 'isfinal', $strAliasPrefix . 'isfinal');
			    $objBuilder->AddSelectItem($strTableName, 'narration', $strAliasPrefix . 'narration');
			    $objBuilder->AddSelectItem($strTableName, 'set_by', $strAliasPrefix . 'set_by');
			    $objBuilder->AddSelectItem($strTableName, 'application', $strAliasPrefix . 'application');
			    $objBuilder->AddSelectItem($strTableName, 'confirm_date', $strAliasPrefix . 'confirm_date');
			    $objBuilder->AddSelectItem($strTableName, 'date', $strAliasPrefix . 'date');
			    $objBuilder->AddSelectItem($strTableName, 'tot_marks', $strAliasPrefix . 'tot_marks');
			    $objBuilder->AddSelectItem($strTableName, 'from', $strAliasPrefix . 'from');
			    $objBuilder->AddSelectItem($strTableName, 'to', $strAliasPrefix . 'to');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Exampaper from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Exampaper::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Exampaper
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idexampaper';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdexampaper == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'exampaper__';


						// Expanding reverse references: Quation
						$strAlias = $strAliasPrefix . 'quation__idquation';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objQuationArray)
								$objPreviousItem->_objQuationArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objQuationArray)) {
								$objPreviousChildItems = $objPreviousItem->_objQuationArray;
								$objChildItem = Quation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'quation__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objQuationArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objQuationArray[] = Quation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'quation__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'exampaper__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Exampaper object
			$objToReturn = new Exampaper();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idexampaper';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdexampaper = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'event_exam';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intEventExam = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'isfinal';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnIsfinal = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'narration';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strNarration = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'set_by';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSetBy = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'application';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intApplication = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'confirm_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttConfirmDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'tot_marks';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intTotMarks = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'from';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttFrom = $objDbRow->GetColumn($strAliasName, 'Time');
			$strAlias = $strAliasPrefix . 'to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttTo = $objDbRow->GetColumn($strAliasName, 'Time');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idexampaper != $objPreviousItem->Idexampaper) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objQuationArray);
					$cnt = count($objToReturn->_objQuationArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objQuationArray, $objToReturn->_objQuationArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'exampaper__';

			// Check for EventExamObject Early Binding
			$strAlias = $strAliasPrefix . 'event_exam__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objEventExamObject = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'event_exam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for SetByObject Early Binding
			$strAlias = $strAliasPrefix . 'set_by__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSetByObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'set_by__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ApplicationObject Early Binding
			$strAlias = $strAliasPrefix . 'application__idapplication';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objApplicationObject = Application::InstantiateDbRow($objDbRow, $strAliasPrefix . 'application__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for Quation Virtual Binding
			$strAlias = $strAliasPrefix . 'quation__idquation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objQuationArray)
				$objToReturn->_objQuationArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objQuationArray[] = Quation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'quation__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objQuation = Quation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'quation__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Exampapers from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Exampaper[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Exampaper::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Exampaper::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Exampaper object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Exampaper next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Exampaper::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Exampaper object,
		 * by Idexampaper Index(es)
		 * @param integer $intIdexampaper
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Exampaper
		*/
		public static function LoadByIdexampaper($intIdexampaper, $objOptionalClauses = null) {
			return Exampaper::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Exampaper()->Idexampaper, $intIdexampaper)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Exampaper objects,
		 * by Application Index(es)
		 * @param integer $intApplication
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Exampaper[]
		*/
		public static function LoadArrayByApplication($intApplication, $objOptionalClauses = null) {
			// Call Exampaper::QueryArray to perform the LoadArrayByApplication query
			try {
				return Exampaper::QueryArray(
					QQ::Equal(QQN::Exampaper()->Application, $intApplication),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Exampapers
		 * by Application Index(es)
		 * @param integer $intApplication
		 * @return int
		*/
		public static function CountByApplication($intApplication) {
			// Call Exampaper::QueryCount to perform the CountByApplication query
			return Exampaper::QueryCount(
				QQ::Equal(QQN::Exampaper()->Application, $intApplication)
			);
		}

		/**
		 * Load an array of Exampaper objects,
		 * by SetBy Index(es)
		 * @param integer $intSetBy
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Exampaper[]
		*/
		public static function LoadArrayBySetBy($intSetBy, $objOptionalClauses = null) {
			// Call Exampaper::QueryArray to perform the LoadArrayBySetBy query
			try {
				return Exampaper::QueryArray(
					QQ::Equal(QQN::Exampaper()->SetBy, $intSetBy),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Exampapers
		 * by SetBy Index(es)
		 * @param integer $intSetBy
		 * @return int
		*/
		public static function CountBySetBy($intSetBy) {
			// Call Exampaper::QueryCount to perform the CountBySetBy query
			return Exampaper::QueryCount(
				QQ::Equal(QQN::Exampaper()->SetBy, $intSetBy)
			);
		}

		/**
		 * Load an array of Exampaper objects,
		 * by EventExam Index(es)
		 * @param integer $intEventExam
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Exampaper[]
		*/
		public static function LoadArrayByEventExam($intEventExam, $objOptionalClauses = null) {
			// Call Exampaper::QueryArray to perform the LoadArrayByEventExam query
			try {
				return Exampaper::QueryArray(
					QQ::Equal(QQN::Exampaper()->EventExam, $intEventExam),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Exampapers
		 * by EventExam Index(es)
		 * @param integer $intEventExam
		 * @return int
		*/
		public static function CountByEventExam($intEventExam) {
			// Call Exampaper::QueryCount to perform the CountByEventExam query
			return Exampaper::QueryCount(
				QQ::Equal(QQN::Exampaper()->EventExam, $intEventExam)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Exampaper
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Exampaper::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `exampaper` (
							`event_exam`,
							`code`,
							`isfinal`,
							`narration`,
							`set_by`,
							`application`,
							`confirm_date`,
							`date`,
							`tot_marks`,
							`from`,
							`to`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intEventExam) . ',
							' . $objDatabase->SqlVariable($this->strCode) . ',
							' . $objDatabase->SqlVariable($this->blnIsfinal) . ',
							' . $objDatabase->SqlVariable($this->strNarration) . ',
							' . $objDatabase->SqlVariable($this->intSetBy) . ',
							' . $objDatabase->SqlVariable($this->intApplication) . ',
							' . $objDatabase->SqlVariable($this->dttConfirmDate) . ',
							' . $objDatabase->SqlVariable($this->dttDate) . ',
							' . $objDatabase->SqlVariable($this->intTotMarks) . ',
							' . $objDatabase->SqlVariable($this->dttFrom) . ',
							' . $objDatabase->SqlVariable($this->dttTo) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdexampaper = $objDatabase->InsertId('exampaper', 'idexampaper');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`exampaper`
						SET
							`event_exam` = ' . $objDatabase->SqlVariable($this->intEventExam) . ',
							`code` = ' . $objDatabase->SqlVariable($this->strCode) . ',
							`isfinal` = ' . $objDatabase->SqlVariable($this->blnIsfinal) . ',
							`narration` = ' . $objDatabase->SqlVariable($this->strNarration) . ',
							`set_by` = ' . $objDatabase->SqlVariable($this->intSetBy) . ',
							`application` = ' . $objDatabase->SqlVariable($this->intApplication) . ',
							`confirm_date` = ' . $objDatabase->SqlVariable($this->dttConfirmDate) . ',
							`date` = ' . $objDatabase->SqlVariable($this->dttDate) . ',
							`tot_marks` = ' . $objDatabase->SqlVariable($this->intTotMarks) . ',
							`from` = ' . $objDatabase->SqlVariable($this->dttFrom) . ',
							`to` = ' . $objDatabase->SqlVariable($this->dttTo) . '
						WHERE
							`idexampaper` = ' . $objDatabase->SqlVariable($this->intIdexampaper) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Exampaper
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdexampaper)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Exampaper with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Exampaper::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`exampaper`
				WHERE
					`idexampaper` = ' . $objDatabase->SqlVariable($this->intIdexampaper) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Exampaper ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Exampaper', $this->intIdexampaper);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Exampapers
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Exampaper::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`exampaper`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate exampaper table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Exampaper::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `exampaper`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Exampaper from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Exampaper object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Exampaper::Load($this->intIdexampaper);

			// Update $this's local variables to match
			$this->EventExam = $objReloaded->EventExam;
			$this->strCode = $objReloaded->strCode;
			$this->blnIsfinal = $objReloaded->blnIsfinal;
			$this->strNarration = $objReloaded->strNarration;
			$this->SetBy = $objReloaded->SetBy;
			$this->Application = $objReloaded->Application;
			$this->dttConfirmDate = $objReloaded->dttConfirmDate;
			$this->dttDate = $objReloaded->dttDate;
			$this->intTotMarks = $objReloaded->intTotMarks;
			$this->dttFrom = $objReloaded->dttFrom;
			$this->dttTo = $objReloaded->dttTo;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idexampaper':
					/**
					 * Gets the value for intIdexampaper (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdexampaper;

				case 'EventExam':
					/**
					 * Gets the value for intEventExam 
					 * @return integer
					 */
					return $this->intEventExam;

				case 'Code':
					/**
					 * Gets the value for strCode 
					 * @return string
					 */
					return $this->strCode;

				case 'Isfinal':
					/**
					 * Gets the value for blnIsfinal 
					 * @return boolean
					 */
					return $this->blnIsfinal;

				case 'Narration':
					/**
					 * Gets the value for strNarration 
					 * @return string
					 */
					return $this->strNarration;

				case 'SetBy':
					/**
					 * Gets the value for intSetBy 
					 * @return integer
					 */
					return $this->intSetBy;

				case 'Application':
					/**
					 * Gets the value for intApplication 
					 * @return integer
					 */
					return $this->intApplication;

				case 'ConfirmDate':
					/**
					 * Gets the value for dttConfirmDate 
					 * @return QDateTime
					 */
					return $this->dttConfirmDate;

				case 'Date':
					/**
					 * Gets the value for dttDate 
					 * @return QDateTime
					 */
					return $this->dttDate;

				case 'TotMarks':
					/**
					 * Gets the value for intTotMarks 
					 * @return integer
					 */
					return $this->intTotMarks;

				case 'From':
					/**
					 * Gets the value for dttFrom 
					 * @return QDateTime
					 */
					return $this->dttFrom;

				case 'To':
					/**
					 * Gets the value for dttTo 
					 * @return QDateTime
					 */
					return $this->dttTo;


				///////////////////
				// Member Objects
				///////////////////
				case 'EventExamObject':
					/**
					 * Gets the value for the DeptYearEvents object referenced by intEventExam 
					 * @return DeptYearEvents
					 */
					try {
						if ((!$this->objEventExamObject) && (!is_null($this->intEventExam)))
							$this->objEventExamObject = DeptYearEvents::Load($this->intEventExam);
						return $this->objEventExamObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SetByObject':
					/**
					 * Gets the value for the Login object referenced by intSetBy 
					 * @return Login
					 */
					try {
						if ((!$this->objSetByObject) && (!is_null($this->intSetBy)))
							$this->objSetByObject = Login::Load($this->intSetBy);
						return $this->objSetByObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ApplicationObject':
					/**
					 * Gets the value for the Application object referenced by intApplication 
					 * @return Application
					 */
					try {
						if ((!$this->objApplicationObject) && (!is_null($this->intApplication)))
							$this->objApplicationObject = Application::Load($this->intApplication);
						return $this->objApplicationObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_Quation':
					/**
					 * Gets the value for the private _objQuation (Read-Only)
					 * if set due to an expansion on the quation.exampaper reverse relationship
					 * @return Quation
					 */
					return $this->_objQuation;

				case '_QuationArray':
					/**
					 * Gets the value for the private _objQuationArray (Read-Only)
					 * if set due to an ExpandAsArray on the quation.exampaper reverse relationship
					 * @return Quation[]
					 */
					return $this->_objQuationArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'EventExam':
					/**
					 * Sets the value for intEventExam 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objEventExamObject = null;
						return ($this->intEventExam = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Code':
					/**
					 * Sets the value for strCode 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Isfinal':
					/**
					 * Sets the value for blnIsfinal 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnIsfinal = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Narration':
					/**
					 * Sets the value for strNarration 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strNarration = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SetBy':
					/**
					 * Sets the value for intSetBy 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSetByObject = null;
						return ($this->intSetBy = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Application':
					/**
					 * Sets the value for intApplication 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objApplicationObject = null;
						return ($this->intApplication = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ConfirmDate':
					/**
					 * Sets the value for dttConfirmDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttConfirmDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Date':
					/**
					 * Sets the value for dttDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TotMarks':
					/**
					 * Sets the value for intTotMarks 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intTotMarks = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'From':
					/**
					 * Sets the value for dttFrom 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttFrom = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'To':
					/**
					 * Sets the value for dttTo 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttTo = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'EventExamObject':
					/**
					 * Sets the value for the DeptYearEvents object referenced by intEventExam 
					 * @param DeptYearEvents $mixValue
					 * @return DeptYearEvents
					 */
					if (is_null($mixValue)) {
						$this->intEventExam = null;
						$this->objEventExamObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a DeptYearEvents object
						try {
							$mixValue = QType::Cast($mixValue, 'DeptYearEvents');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED DeptYearEvents object
						if (is_null($mixValue->IddeptYearEvents))
							throw new QCallerException('Unable to set an unsaved EventExamObject for this Exampaper');

						// Update Local Member Variables
						$this->objEventExamObject = $mixValue;
						$this->intEventExam = $mixValue->IddeptYearEvents;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'SetByObject':
					/**
					 * Sets the value for the Login object referenced by intSetBy 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intSetBy = null;
						$this->objSetByObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved SetByObject for this Exampaper');

						// Update Local Member Variables
						$this->objSetByObject = $mixValue;
						$this->intSetBy = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ApplicationObject':
					/**
					 * Sets the value for the Application object referenced by intApplication 
					 * @param Application $mixValue
					 * @return Application
					 */
					if (is_null($mixValue)) {
						$this->intApplication = null;
						$this->objApplicationObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Application object
						try {
							$mixValue = QType::Cast($mixValue, 'Application');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Application object
						if (is_null($mixValue->Idapplication))
							throw new QCallerException('Unable to set an unsaved ApplicationObject for this Exampaper');

						// Update Local Member Variables
						$this->objApplicationObject = $mixValue;
						$this->intApplication = $mixValue->Idapplication;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for Quation
		//-------------------------------------------------------------------

		/**
		 * Gets all associated Quations as an array of Quation objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Quation[]
		*/
		public function GetQuationArray($objOptionalClauses = null) {
			if ((is_null($this->intIdexampaper)))
				return array();

			try {
				return Quation::LoadArrayByExampaper($this->intIdexampaper, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated Quations
		 * @return int
		*/
		public function CountQuations() {
			if ((is_null($this->intIdexampaper)))
				return 0;

			return Quation::CountByExampaper($this->intIdexampaper);
		}

		/**
		 * Associates a Quation
		 * @param Quation $objQuation
		 * @return void
		*/
		public function AssociateQuation(Quation $objQuation) {
			if ((is_null($this->intIdexampaper)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateQuation on this unsaved Exampaper.');
			if ((is_null($objQuation->Idquation)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateQuation on this Exampaper with an unsaved Quation.');

			// Get the Database Object for this Class
			$objDatabase = Exampaper::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`quation`
				SET
					`exampaper` = ' . $objDatabase->SqlVariable($this->intIdexampaper) . '
				WHERE
					`idquation` = ' . $objDatabase->SqlVariable($objQuation->Idquation) . '
			');
		}

		/**
		 * Unassociates a Quation
		 * @param Quation $objQuation
		 * @return void
		*/
		public function UnassociateQuation(Quation $objQuation) {
			if ((is_null($this->intIdexampaper)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateQuation on this unsaved Exampaper.');
			if ((is_null($objQuation->Idquation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateQuation on this Exampaper with an unsaved Quation.');

			// Get the Database Object for this Class
			$objDatabase = Exampaper::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`quation`
				SET
					`exampaper` = null
				WHERE
					`idquation` = ' . $objDatabase->SqlVariable($objQuation->Idquation) . ' AND
					`exampaper` = ' . $objDatabase->SqlVariable($this->intIdexampaper) . '
			');
		}

		/**
		 * Unassociates all Quations
		 * @return void
		*/
		public function UnassociateAllQuations() {
			if ((is_null($this->intIdexampaper)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateQuation on this unsaved Exampaper.');

			// Get the Database Object for this Class
			$objDatabase = Exampaper::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`quation`
				SET
					`exampaper` = null
				WHERE
					`exampaper` = ' . $objDatabase->SqlVariable($this->intIdexampaper) . '
			');
		}

		/**
		 * Deletes an associated Quation
		 * @param Quation $objQuation
		 * @return void
		*/
		public function DeleteAssociatedQuation(Quation $objQuation) {
			if ((is_null($this->intIdexampaper)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateQuation on this unsaved Exampaper.');
			if ((is_null($objQuation->Idquation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateQuation on this Exampaper with an unsaved Quation.');

			// Get the Database Object for this Class
			$objDatabase = Exampaper::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`quation`
				WHERE
					`idquation` = ' . $objDatabase->SqlVariable($objQuation->Idquation) . ' AND
					`exampaper` = ' . $objDatabase->SqlVariable($this->intIdexampaper) . '
			');
		}

		/**
		 * Deletes all associated Quations
		 * @return void
		*/
		public function DeleteAllQuations() {
			if ((is_null($this->intIdexampaper)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateQuation on this unsaved Exampaper.');

			// Get the Database Object for this Class
			$objDatabase = Exampaper::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`quation`
				WHERE
					`exampaper` = ' . $objDatabase->SqlVariable($this->intIdexampaper) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "exampaper";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Exampaper::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Exampaper"><sequence>';
			$strToReturn .= '<element name="Idexampaper" type="xsd:int"/>';
			$strToReturn .= '<element name="EventExamObject" type="xsd1:DeptYearEvents"/>';
			$strToReturn .= '<element name="Code" type="xsd:string"/>';
			$strToReturn .= '<element name="Isfinal" type="xsd:boolean"/>';
			$strToReturn .= '<element name="Narration" type="xsd:string"/>';
			$strToReturn .= '<element name="SetByObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="ApplicationObject" type="xsd1:Application"/>';
			$strToReturn .= '<element name="ConfirmDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Date" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="TotMarks" type="xsd:int"/>';
			$strToReturn .= '<element name="From" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="To" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Exampaper', $strComplexTypeArray)) {
				$strComplexTypeArray['Exampaper'] = Exampaper::GetSoapComplexTypeXml();
				DeptYearEvents::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				Application::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Exampaper::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Exampaper();
			if (property_exists($objSoapObject, 'Idexampaper'))
				$objToReturn->intIdexampaper = $objSoapObject->Idexampaper;
			if ((property_exists($objSoapObject, 'EventExamObject')) &&
				($objSoapObject->EventExamObject))
				$objToReturn->EventExamObject = DeptYearEvents::GetObjectFromSoapObject($objSoapObject->EventExamObject);
			if (property_exists($objSoapObject, 'Code'))
				$objToReturn->strCode = $objSoapObject->Code;
			if (property_exists($objSoapObject, 'Isfinal'))
				$objToReturn->blnIsfinal = $objSoapObject->Isfinal;
			if (property_exists($objSoapObject, 'Narration'))
				$objToReturn->strNarration = $objSoapObject->Narration;
			if ((property_exists($objSoapObject, 'SetByObject')) &&
				($objSoapObject->SetByObject))
				$objToReturn->SetByObject = Login::GetObjectFromSoapObject($objSoapObject->SetByObject);
			if ((property_exists($objSoapObject, 'ApplicationObject')) &&
				($objSoapObject->ApplicationObject))
				$objToReturn->ApplicationObject = Application::GetObjectFromSoapObject($objSoapObject->ApplicationObject);
			if (property_exists($objSoapObject, 'ConfirmDate'))
				$objToReturn->dttConfirmDate = new QDateTime($objSoapObject->ConfirmDate);
			if (property_exists($objSoapObject, 'Date'))
				$objToReturn->dttDate = new QDateTime($objSoapObject->Date);
			if (property_exists($objSoapObject, 'TotMarks'))
				$objToReturn->intTotMarks = $objSoapObject->TotMarks;
			if (property_exists($objSoapObject, 'From'))
				$objToReturn->dttFrom = new QDateTime($objSoapObject->From);
			if (property_exists($objSoapObject, 'To'))
				$objToReturn->dttTo = new QDateTime($objSoapObject->To);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Exampaper::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objEventExamObject)
				$objObject->objEventExamObject = DeptYearEvents::GetSoapObjectFromObject($objObject->objEventExamObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intEventExam = null;
			if ($objObject->objSetByObject)
				$objObject->objSetByObject = Login::GetSoapObjectFromObject($objObject->objSetByObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSetBy = null;
			if ($objObject->objApplicationObject)
				$objObject->objApplicationObject = Application::GetSoapObjectFromObject($objObject->objApplicationObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intApplication = null;
			if ($objObject->dttConfirmDate)
				$objObject->dttConfirmDate = $objObject->dttConfirmDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttDate)
				$objObject->dttDate = $objObject->dttDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttFrom)
				$objObject->dttFrom = $objObject->dttFrom->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttTo)
				$objObject->dttTo = $objObject->dttTo->qFormat(QDateTime::FormatSoap);
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idexampaper'] = $this->intIdexampaper;
			$iArray['EventExam'] = $this->intEventExam;
			$iArray['Code'] = $this->strCode;
			$iArray['Isfinal'] = $this->blnIsfinal;
			$iArray['Narration'] = $this->strNarration;
			$iArray['SetBy'] = $this->intSetBy;
			$iArray['Application'] = $this->intApplication;
			$iArray['ConfirmDate'] = $this->dttConfirmDate;
			$iArray['Date'] = $this->dttDate;
			$iArray['TotMarks'] = $this->intTotMarks;
			$iArray['From'] = $this->dttFrom;
			$iArray['To'] = $this->dttTo;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdexampaper ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idexampaper
     * @property-read QQNode $EventExam
     * @property-read QQNodeDeptYearEvents $EventExamObject
     * @property-read QQNode $Code
     * @property-read QQNode $Isfinal
     * @property-read QQNode $Narration
     * @property-read QQNode $SetBy
     * @property-read QQNodeLogin $SetByObject
     * @property-read QQNode $Application
     * @property-read QQNodeApplication $ApplicationObject
     * @property-read QQNode $ConfirmDate
     * @property-read QQNode $Date
     * @property-read QQNode $TotMarks
     * @property-read QQNode $From
     * @property-read QQNode $To
     *
     *
     * @property-read QQReverseReferenceNodeQuation $Quation

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeExampaper extends QQNode {
		protected $strTableName = 'exampaper';
		protected $strPrimaryKey = 'idexampaper';
		protected $strClassName = 'Exampaper';
		public function __get($strName) {
			switch ($strName) {
				case 'Idexampaper':
					return new QQNode('idexampaper', 'Idexampaper', 'Integer', $this);
				case 'EventExam':
					return new QQNode('event_exam', 'EventExam', 'Integer', $this);
				case 'EventExamObject':
					return new QQNodeDeptYearEvents('event_exam', 'EventExamObject', 'Integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'VarChar', $this);
				case 'Isfinal':
					return new QQNode('isfinal', 'Isfinal', 'Bit', $this);
				case 'Narration':
					return new QQNode('narration', 'Narration', 'Blob', $this);
				case 'SetBy':
					return new QQNode('set_by', 'SetBy', 'Integer', $this);
				case 'SetByObject':
					return new QQNodeLogin('set_by', 'SetByObject', 'Integer', $this);
				case 'Application':
					return new QQNode('application', 'Application', 'Integer', $this);
				case 'ApplicationObject':
					return new QQNodeApplication('application', 'ApplicationObject', 'Integer', $this);
				case 'ConfirmDate':
					return new QQNode('confirm_date', 'ConfirmDate', 'DateTime', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'DateTime', $this);
				case 'TotMarks':
					return new QQNode('tot_marks', 'TotMarks', 'Integer', $this);
				case 'From':
					return new QQNode('from', 'From', 'Time', $this);
				case 'To':
					return new QQNode('to', 'To', 'Time', $this);
				case 'Quation':
					return new QQReverseReferenceNodeQuation($this, 'quation', 'reverse_reference', 'exampaper');

				case '_PrimaryKeyNode':
					return new QQNode('idexampaper', 'Idexampaper', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idexampaper
     * @property-read QQNode $EventExam
     * @property-read QQNodeDeptYearEvents $EventExamObject
     * @property-read QQNode $Code
     * @property-read QQNode $Isfinal
     * @property-read QQNode $Narration
     * @property-read QQNode $SetBy
     * @property-read QQNodeLogin $SetByObject
     * @property-read QQNode $Application
     * @property-read QQNodeApplication $ApplicationObject
     * @property-read QQNode $ConfirmDate
     * @property-read QQNode $Date
     * @property-read QQNode $TotMarks
     * @property-read QQNode $From
     * @property-read QQNode $To
     *
     *
     * @property-read QQReverseReferenceNodeQuation $Quation

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeExampaper extends QQReverseReferenceNode {
		protected $strTableName = 'exampaper';
		protected $strPrimaryKey = 'idexampaper';
		protected $strClassName = 'Exampaper';
		public function __get($strName) {
			switch ($strName) {
				case 'Idexampaper':
					return new QQNode('idexampaper', 'Idexampaper', 'integer', $this);
				case 'EventExam':
					return new QQNode('event_exam', 'EventExam', 'integer', $this);
				case 'EventExamObject':
					return new QQNodeDeptYearEvents('event_exam', 'EventExamObject', 'integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'string', $this);
				case 'Isfinal':
					return new QQNode('isfinal', 'Isfinal', 'boolean', $this);
				case 'Narration':
					return new QQNode('narration', 'Narration', 'string', $this);
				case 'SetBy':
					return new QQNode('set_by', 'SetBy', 'integer', $this);
				case 'SetByObject':
					return new QQNodeLogin('set_by', 'SetByObject', 'integer', $this);
				case 'Application':
					return new QQNode('application', 'Application', 'integer', $this);
				case 'ApplicationObject':
					return new QQNodeApplication('application', 'ApplicationObject', 'integer', $this);
				case 'ConfirmDate':
					return new QQNode('confirm_date', 'ConfirmDate', 'QDateTime', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'QDateTime', $this);
				case 'TotMarks':
					return new QQNode('tot_marks', 'TotMarks', 'integer', $this);
				case 'From':
					return new QQNode('from', 'From', 'QDateTime', $this);
				case 'To':
					return new QQNode('to', 'To', 'QDateTime', $this);
				case 'Quation':
					return new QQReverseReferenceNodeQuation($this, 'quation', 'reverse_reference', 'exampaper');

				case '_PrimaryKeyNode':
					return new QQNode('idexampaper', 'Idexampaper', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
