<?php
	/**
	 * The abstract SalaryGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Salary subclass which
	 * extends this SalaryGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Salary class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idsalary the value for intIdsalary (Read-Only PK)
	 * @property integer $SalaryCat the value for intSalaryCat 
	 * @property boolean $Upgrade the value for blnUpgrade 
	 * @property integer $AppoinmentCat the value for intAppoinmentCat 
	 * @property integer $Staff the value for intStaff (Not Null)
	 * @property Ledger $StaffObject the value for the Ledger object referenced by intStaff (Not Null)
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class SalaryGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column salary.idsalary
		 * @var integer intIdsalary
		 */
		protected $intIdsalary;
		const IdsalaryDefault = null;


		/**
		 * Protected member variable that maps to the database column salary.salary_cat
		 * @var integer intSalaryCat
		 */
		protected $intSalaryCat;
		const SalaryCatDefault = null;


		/**
		 * Protected member variable that maps to the database column salary.upgrade
		 * @var boolean blnUpgrade
		 */
		protected $blnUpgrade;
		const UpgradeDefault = null;


		/**
		 * Protected member variable that maps to the database column salary.appoinment_cat
		 * @var integer intAppoinmentCat
		 */
		protected $intAppoinmentCat;
		const AppoinmentCatDefault = null;


		/**
		 * Protected member variable that maps to the database column salary.staff
		 * @var integer intStaff
		 */
		protected $intStaff;
		const StaffDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column salary.staff.
		 *
		 * NOTE: Always use the StaffObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objStaffObject
		 */
		protected $objStaffObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdsalary = Salary::IdsalaryDefault;
			$this->intSalaryCat = Salary::SalaryCatDefault;
			$this->blnUpgrade = Salary::UpgradeDefault;
			$this->intAppoinmentCat = Salary::AppoinmentCatDefault;
			$this->intStaff = Salary::StaffDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Salary from PK Info
		 * @param integer $intIdsalary
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Salary
		 */
		public static function Load($intIdsalary, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Salary', $intIdsalary);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Salary::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Salary()->Idsalary, $intIdsalary)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Salaries
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Salary[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Salary::QueryArray to perform the LoadAll query
			try {
				return Salary::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Salaries
		 * @return int
		 */
		public static function CountAll() {
			// Call Salary::QueryCount to perform the CountAll query
			return Salary::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Salary::GetDatabase();

			// Create/Build out the QueryBuilder object with Salary-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'salary');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Salary::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('salary');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Salary object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Salary the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Salary::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Salary object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Salary::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Salary::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Salary objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Salary[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Salary::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Salary::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Salary::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Salary objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Salary::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Salary::GetDatabase();

			$strQuery = Salary::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/salary', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Salary::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Salary
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'salary';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idsalary', $strAliasPrefix . 'idsalary');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idsalary', $strAliasPrefix . 'idsalary');
			    $objBuilder->AddSelectItem($strTableName, 'salary_cat', $strAliasPrefix . 'salary_cat');
			    $objBuilder->AddSelectItem($strTableName, 'upgrade', $strAliasPrefix . 'upgrade');
			    $objBuilder->AddSelectItem($strTableName, 'appoinment_cat', $strAliasPrefix . 'appoinment_cat');
			    $objBuilder->AddSelectItem($strTableName, 'staff', $strAliasPrefix . 'staff');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Salary from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Salary::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Salary
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the Salary object
			$objToReturn = new Salary();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idsalary';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdsalary = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'salary_cat';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSalaryCat = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'upgrade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnUpgrade = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'appoinment_cat';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intAppoinmentCat = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'staff';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intStaff = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idsalary != $objPreviousItem->Idsalary) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'salary__';

			// Check for StaffObject Early Binding
			$strAlias = $strAliasPrefix . 'staff__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objStaffObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'staff__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of Salaries from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Salary[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Salary::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Salary::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Salary object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Salary next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Salary::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Salary object,
		 * by Idsalary Index(es)
		 * @param integer $intIdsalary
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Salary
		*/
		public static function LoadByIdsalary($intIdsalary, $objOptionalClauses = null) {
			return Salary::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Salary()->Idsalary, $intIdsalary)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Salary objects,
		 * by Staff Index(es)
		 * @param integer $intStaff
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Salary[]
		*/
		public static function LoadArrayByStaff($intStaff, $objOptionalClauses = null) {
			// Call Salary::QueryArray to perform the LoadArrayByStaff query
			try {
				return Salary::QueryArray(
					QQ::Equal(QQN::Salary()->Staff, $intStaff),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Salaries
		 * by Staff Index(es)
		 * @param integer $intStaff
		 * @return int
		*/
		public static function CountByStaff($intStaff) {
			// Call Salary::QueryCount to perform the CountByStaff query
			return Salary::QueryCount(
				QQ::Equal(QQN::Salary()->Staff, $intStaff)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Salary
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Salary::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `salary` (
							`salary_cat`,
							`upgrade`,
							`appoinment_cat`,
							`staff`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intSalaryCat) . ',
							' . $objDatabase->SqlVariable($this->blnUpgrade) . ',
							' . $objDatabase->SqlVariable($this->intAppoinmentCat) . ',
							' . $objDatabase->SqlVariable($this->intStaff) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdsalary = $objDatabase->InsertId('salary', 'idsalary');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`salary`
						SET
							`salary_cat` = ' . $objDatabase->SqlVariable($this->intSalaryCat) . ',
							`upgrade` = ' . $objDatabase->SqlVariable($this->blnUpgrade) . ',
							`appoinment_cat` = ' . $objDatabase->SqlVariable($this->intAppoinmentCat) . ',
							`staff` = ' . $objDatabase->SqlVariable($this->intStaff) . '
						WHERE
							`idsalary` = ' . $objDatabase->SqlVariable($this->intIdsalary) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Salary
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdsalary)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Salary with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Salary::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salary`
				WHERE
					`idsalary` = ' . $objDatabase->SqlVariable($this->intIdsalary) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Salary ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Salary', $this->intIdsalary);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Salaries
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Salary::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`salary`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate salary table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Salary::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `salary`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Salary from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Salary object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Salary::Load($this->intIdsalary);

			// Update $this's local variables to match
			$this->intSalaryCat = $objReloaded->intSalaryCat;
			$this->blnUpgrade = $objReloaded->blnUpgrade;
			$this->intAppoinmentCat = $objReloaded->intAppoinmentCat;
			$this->Staff = $objReloaded->Staff;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idsalary':
					/**
					 * Gets the value for intIdsalary (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdsalary;

				case 'SalaryCat':
					/**
					 * Gets the value for intSalaryCat 
					 * @return integer
					 */
					return $this->intSalaryCat;

				case 'Upgrade':
					/**
					 * Gets the value for blnUpgrade 
					 * @return boolean
					 */
					return $this->blnUpgrade;

				case 'AppoinmentCat':
					/**
					 * Gets the value for intAppoinmentCat 
					 * @return integer
					 */
					return $this->intAppoinmentCat;

				case 'Staff':
					/**
					 * Gets the value for intStaff (Not Null)
					 * @return integer
					 */
					return $this->intStaff;


				///////////////////
				// Member Objects
				///////////////////
				case 'StaffObject':
					/**
					 * Gets the value for the Ledger object referenced by intStaff (Not Null)
					 * @return Ledger
					 */
					try {
						if ((!$this->objStaffObject) && (!is_null($this->intStaff)))
							$this->objStaffObject = Ledger::Load($this->intStaff);
						return $this->objStaffObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'SalaryCat':
					/**
					 * Sets the value for intSalaryCat 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intSalaryCat = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Upgrade':
					/**
					 * Sets the value for blnUpgrade 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnUpgrade = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AppoinmentCat':
					/**
					 * Sets the value for intAppoinmentCat 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intAppoinmentCat = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Staff':
					/**
					 * Sets the value for intStaff (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objStaffObject = null;
						return ($this->intStaff = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'StaffObject':
					/**
					 * Sets the value for the Ledger object referenced by intStaff (Not Null)
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intStaff = null;
						$this->objStaffObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved StaffObject for this Salary');

						// Update Local Member Variables
						$this->objStaffObject = $mixValue;
						$this->intStaff = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "salary";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Salary::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Salary"><sequence>';
			$strToReturn .= '<element name="Idsalary" type="xsd:int"/>';
			$strToReturn .= '<element name="SalaryCat" type="xsd:int"/>';
			$strToReturn .= '<element name="Upgrade" type="xsd:boolean"/>';
			$strToReturn .= '<element name="AppoinmentCat" type="xsd:int"/>';
			$strToReturn .= '<element name="StaffObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Salary', $strComplexTypeArray)) {
				$strComplexTypeArray['Salary'] = Salary::GetSoapComplexTypeXml();
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Salary::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Salary();
			if (property_exists($objSoapObject, 'Idsalary'))
				$objToReturn->intIdsalary = $objSoapObject->Idsalary;
			if (property_exists($objSoapObject, 'SalaryCat'))
				$objToReturn->intSalaryCat = $objSoapObject->SalaryCat;
			if (property_exists($objSoapObject, 'Upgrade'))
				$objToReturn->blnUpgrade = $objSoapObject->Upgrade;
			if (property_exists($objSoapObject, 'AppoinmentCat'))
				$objToReturn->intAppoinmentCat = $objSoapObject->AppoinmentCat;
			if ((property_exists($objSoapObject, 'StaffObject')) &&
				($objSoapObject->StaffObject))
				$objToReturn->StaffObject = Ledger::GetObjectFromSoapObject($objSoapObject->StaffObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Salary::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objStaffObject)
				$objObject->objStaffObject = Ledger::GetSoapObjectFromObject($objObject->objStaffObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intStaff = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idsalary'] = $this->intIdsalary;
			$iArray['SalaryCat'] = $this->intSalaryCat;
			$iArray['Upgrade'] = $this->blnUpgrade;
			$iArray['AppoinmentCat'] = $this->intAppoinmentCat;
			$iArray['Staff'] = $this->intStaff;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdsalary ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idsalary
     * @property-read QQNode $SalaryCat
     * @property-read QQNode $Upgrade
     * @property-read QQNode $AppoinmentCat
     * @property-read QQNode $Staff
     * @property-read QQNodeLedger $StaffObject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeSalary extends QQNode {
		protected $strTableName = 'salary';
		protected $strPrimaryKey = 'idsalary';
		protected $strClassName = 'Salary';
		public function __get($strName) {
			switch ($strName) {
				case 'Idsalary':
					return new QQNode('idsalary', 'Idsalary', 'Integer', $this);
				case 'SalaryCat':
					return new QQNode('salary_cat', 'SalaryCat', 'Integer', $this);
				case 'Upgrade':
					return new QQNode('upgrade', 'Upgrade', 'Bit', $this);
				case 'AppoinmentCat':
					return new QQNode('appoinment_cat', 'AppoinmentCat', 'Integer', $this);
				case 'Staff':
					return new QQNode('staff', 'Staff', 'Integer', $this);
				case 'StaffObject':
					return new QQNodeLedger('staff', 'StaffObject', 'Integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idsalary', 'Idsalary', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idsalary
     * @property-read QQNode $SalaryCat
     * @property-read QQNode $Upgrade
     * @property-read QQNode $AppoinmentCat
     * @property-read QQNode $Staff
     * @property-read QQNodeLedger $StaffObject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeSalary extends QQReverseReferenceNode {
		protected $strTableName = 'salary';
		protected $strPrimaryKey = 'idsalary';
		protected $strClassName = 'Salary';
		public function __get($strName) {
			switch ($strName) {
				case 'Idsalary':
					return new QQNode('idsalary', 'Idsalary', 'integer', $this);
				case 'SalaryCat':
					return new QQNode('salary_cat', 'SalaryCat', 'integer', $this);
				case 'Upgrade':
					return new QQNode('upgrade', 'Upgrade', 'boolean', $this);
				case 'AppoinmentCat':
					return new QQNode('appoinment_cat', 'AppoinmentCat', 'integer', $this);
				case 'Staff':
					return new QQNode('staff', 'Staff', 'integer', $this);
				case 'StaffObject':
					return new QQNodeLedger('staff', 'StaffObject', 'integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idsalary', 'Idsalary', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
