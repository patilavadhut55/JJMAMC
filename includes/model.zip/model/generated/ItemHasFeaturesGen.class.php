<?php
	/**
	 * The abstract ItemHasFeaturesGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the ItemHasFeatures subclass which
	 * extends this ItemHasFeaturesGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the ItemHasFeatures class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IditemHasFeatures the value for intIditemHasFeatures (Read-Only PK)
	 * @property-read string $Date the value for strDate (Read-Only Timestamp)
	 * @property integer $Item the value for intItem (Not Null)
	 * @property integer $Feature the value for intFeature (Not Null)
	 * @property integer $Seq the value for intSeq (Not Null)
	 * @property integer $Parrent the value for intParrent 
	 * @property integer $Counter the value for intCounter (Not Null)
	 * @property integer $RequirmentBy the value for intRequirmentBy 
	 * @property QDateTime $DueDate the value for dttDueDate 
	 * @property string $Data the value for strData 
	 * @property LedgerDetails $ItemObject the value for the LedgerDetails object referenced by intItem (Not Null)
	 * @property Features $FeatureObject the value for the Features object referenced by intFeature (Not Null)
	 * @property ItemHasFeatures $ParrentObject the value for the ItemHasFeatures object referenced by intParrent 
	 * @property Ledger $RequirmentByObject the value for the Ledger object referenced by intRequirmentBy 
	 * @property-read ItemHasFeatures $_ItemHasFeaturesAsParrent the value for the private _objItemHasFeaturesAsParrent (Read-Only) if set due to an expansion on the item_has_features.parrent reverse relationship
	 * @property-read ItemHasFeatures[] $_ItemHasFeaturesAsParrentArray the value for the private _objItemHasFeaturesAsParrentArray (Read-Only) if set due to an ExpandAsArray on the item_has_features.parrent reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class ItemHasFeaturesGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column item_has_features.iditem_has_features
		 * @var integer intIditemHasFeatures
		 */
		protected $intIditemHasFeatures;
		const IditemHasFeaturesDefault = null;


		/**
		 * Protected member variable that maps to the database column item_has_features.date
		 * @var string strDate
		 */
		protected $strDate;
		const DateDefault = null;


		/**
		 * Protected member variable that maps to the database column item_has_features.item
		 * @var integer intItem
		 */
		protected $intItem;
		const ItemDefault = null;


		/**
		 * Protected member variable that maps to the database column item_has_features.feature
		 * @var integer intFeature
		 */
		protected $intFeature;
		const FeatureDefault = null;


		/**
		 * Protected member variable that maps to the database column item_has_features.seq
		 * @var integer intSeq
		 */
		protected $intSeq;
		const SeqDefault = null;


		/**
		 * Protected member variable that maps to the database column item_has_features.parrent
		 * @var integer intParrent
		 */
		protected $intParrent;
		const ParrentDefault = null;


		/**
		 * Protected member variable that maps to the database column item_has_features.counter
		 * @var integer intCounter
		 */
		protected $intCounter;
		const CounterDefault = null;


		/**
		 * Protected member variable that maps to the database column item_has_features.requirment_by
		 * @var integer intRequirmentBy
		 */
		protected $intRequirmentBy;
		const RequirmentByDefault = null;


		/**
		 * Protected member variable that maps to the database column item_has_features.due_date
		 * @var QDateTime dttDueDate
		 */
		protected $dttDueDate;
		const DueDateDefault = null;


		/**
		 * Protected member variable that maps to the database column item_has_features.data
		 * @var string strData
		 */
		protected $strData;
		const DataDefault = null;


		/**
		 * Private member variable that stores a reference to a single ItemHasFeaturesAsParrent object
		 * (of type ItemHasFeatures), if this ItemHasFeatures object was restored with
		 * an expansion on the item_has_features association table.
		 * @var ItemHasFeatures _objItemHasFeaturesAsParrent;
		 */
		private $_objItemHasFeaturesAsParrent;

		/**
		 * Private member variable that stores a reference to an array of ItemHasFeaturesAsParrent objects
		 * (of type ItemHasFeatures[]), if this ItemHasFeatures object was restored with
		 * an ExpandAsArray on the item_has_features association table.
		 * @var ItemHasFeatures[] _objItemHasFeaturesAsParrentArray;
		 */
		private $_objItemHasFeaturesAsParrentArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column item_has_features.item.
		 *
		 * NOTE: Always use the ItemObject property getter to correctly retrieve this LedgerDetails object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var LedgerDetails objItemObject
		 */
		protected $objItemObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column item_has_features.feature.
		 *
		 * NOTE: Always use the FeatureObject property getter to correctly retrieve this Features object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Features objFeatureObject
		 */
		protected $objFeatureObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column item_has_features.parrent.
		 *
		 * NOTE: Always use the ParrentObject property getter to correctly retrieve this ItemHasFeatures object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var ItemHasFeatures objParrentObject
		 */
		protected $objParrentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column item_has_features.requirment_by.
		 *
		 * NOTE: Always use the RequirmentByObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objRequirmentByObject
		 */
		protected $objRequirmentByObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIditemHasFeatures = ItemHasFeatures::IditemHasFeaturesDefault;
			$this->strDate = ItemHasFeatures::DateDefault;
			$this->intItem = ItemHasFeatures::ItemDefault;
			$this->intFeature = ItemHasFeatures::FeatureDefault;
			$this->intSeq = ItemHasFeatures::SeqDefault;
			$this->intParrent = ItemHasFeatures::ParrentDefault;
			$this->intCounter = ItemHasFeatures::CounterDefault;
			$this->intRequirmentBy = ItemHasFeatures::RequirmentByDefault;
			$this->dttDueDate = (ItemHasFeatures::DueDateDefault === null)?null:new QDateTime(ItemHasFeatures::DueDateDefault);
			$this->strData = ItemHasFeatures::DataDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a ItemHasFeatures from PK Info
		 * @param integer $intIditemHasFeatures
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ItemHasFeatures
		 */
		public static function Load($intIditemHasFeatures, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'ItemHasFeatures', $intIditemHasFeatures);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = ItemHasFeatures::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::ItemHasFeatures()->IditemHasFeatures, $intIditemHasFeatures)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all ItemHasFeatureses
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ItemHasFeatures[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call ItemHasFeatures::QueryArray to perform the LoadAll query
			try {
				return ItemHasFeatures::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all ItemHasFeatureses
		 * @return int
		 */
		public static function CountAll() {
			// Call ItemHasFeatures::QueryCount to perform the CountAll query
			return ItemHasFeatures::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = ItemHasFeatures::GetDatabase();

			// Create/Build out the QueryBuilder object with ItemHasFeatures-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'item_has_features');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				ItemHasFeatures::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('item_has_features');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single ItemHasFeatures object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return ItemHasFeatures the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = ItemHasFeatures::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new ItemHasFeatures object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = ItemHasFeatures::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return ItemHasFeatures::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of ItemHasFeatures objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return ItemHasFeatures[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = ItemHasFeatures::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return ItemHasFeatures::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = ItemHasFeatures::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of ItemHasFeatures objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = ItemHasFeatures::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = ItemHasFeatures::GetDatabase();

			$strQuery = ItemHasFeatures::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/itemhasfeatures', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = ItemHasFeatures::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this ItemHasFeatures
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'item_has_features';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'iditem_has_features', $strAliasPrefix . 'iditem_has_features');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'iditem_has_features', $strAliasPrefix . 'iditem_has_features');
			    $objBuilder->AddSelectItem($strTableName, 'date', $strAliasPrefix . 'date');
			    $objBuilder->AddSelectItem($strTableName, 'item', $strAliasPrefix . 'item');
			    $objBuilder->AddSelectItem($strTableName, 'feature', $strAliasPrefix . 'feature');
			    $objBuilder->AddSelectItem($strTableName, 'seq', $strAliasPrefix . 'seq');
			    $objBuilder->AddSelectItem($strTableName, 'parrent', $strAliasPrefix . 'parrent');
			    $objBuilder->AddSelectItem($strTableName, 'counter', $strAliasPrefix . 'counter');
			    $objBuilder->AddSelectItem($strTableName, 'requirment_by', $strAliasPrefix . 'requirment_by');
			    $objBuilder->AddSelectItem($strTableName, 'due_date', $strAliasPrefix . 'due_date');
			    $objBuilder->AddSelectItem($strTableName, 'data', $strAliasPrefix . 'data');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a ItemHasFeatures from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this ItemHasFeatures::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return ItemHasFeatures
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'iditem_has_features';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIditemHasFeatures == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'item_has_features__';


						// Expanding reverse references: ItemHasFeaturesAsParrent
						$strAlias = $strAliasPrefix . 'itemhasfeaturesasparrent__iditem_has_features';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objItemHasFeaturesAsParrentArray)
								$objPreviousItem->_objItemHasFeaturesAsParrentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objItemHasFeaturesAsParrentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objItemHasFeaturesAsParrentArray;
								$objChildItem = ItemHasFeatures::InstantiateDbRow($objDbRow, $strAliasPrefix . 'itemhasfeaturesasparrent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objItemHasFeaturesAsParrentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objItemHasFeaturesAsParrentArray[] = ItemHasFeatures::InstantiateDbRow($objDbRow, $strAliasPrefix . 'itemhasfeaturesasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'item_has_features__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the ItemHasFeatures object
			$objToReturn = new ItemHasFeatures();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'iditem_has_features';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIditemHasFeatures = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strDate = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'item';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intItem = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'feature';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intFeature = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'seq';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSeq = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'parrent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intParrent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'counter';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCounter = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'requirment_by';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intRequirmentBy = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'due_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDueDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'data';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strData = $objDbRow->GetColumn($strAliasName, 'Blob');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IditemHasFeatures != $objPreviousItem->IditemHasFeatures) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objItemHasFeaturesAsParrentArray);
					$cnt = count($objToReturn->_objItemHasFeaturesAsParrentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objItemHasFeaturesAsParrentArray, $objToReturn->_objItemHasFeaturesAsParrentArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'item_has_features__';

			// Check for ItemObject Early Binding
			$strAlias = $strAliasPrefix . 'item__idledger_details';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objItemObject = LedgerDetails::InstantiateDbRow($objDbRow, $strAliasPrefix . 'item__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for FeatureObject Early Binding
			$strAlias = $strAliasPrefix . 'feature__idfeatures';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objFeatureObject = Features::InstantiateDbRow($objDbRow, $strAliasPrefix . 'feature__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ParrentObject Early Binding
			$strAlias = $strAliasPrefix . 'parrent__iditem_has_features';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objParrentObject = ItemHasFeatures::InstantiateDbRow($objDbRow, $strAliasPrefix . 'parrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for RequirmentByObject Early Binding
			$strAlias = $strAliasPrefix . 'requirment_by__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objRequirmentByObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'requirment_by__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for ItemHasFeaturesAsParrent Virtual Binding
			$strAlias = $strAliasPrefix . 'itemhasfeaturesasparrent__iditem_has_features';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objItemHasFeaturesAsParrentArray)
				$objToReturn->_objItemHasFeaturesAsParrentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objItemHasFeaturesAsParrentArray[] = ItemHasFeatures::InstantiateDbRow($objDbRow, $strAliasPrefix . 'itemhasfeaturesasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objItemHasFeaturesAsParrent = ItemHasFeatures::InstantiateDbRow($objDbRow, $strAliasPrefix . 'itemhasfeaturesasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of ItemHasFeatureses from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return ItemHasFeatures[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = ItemHasFeatures::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = ItemHasFeatures::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single ItemHasFeatures object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return ItemHasFeatures next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return ItemHasFeatures::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single ItemHasFeatures object,
		 * by IditemHasFeatures Index(es)
		 * @param integer $intIditemHasFeatures
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ItemHasFeatures
		*/
		public static function LoadByIditemHasFeatures($intIditemHasFeatures, $objOptionalClauses = null) {
			return ItemHasFeatures::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::ItemHasFeatures()->IditemHasFeatures, $intIditemHasFeatures)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of ItemHasFeatures objects,
		 * by Feature Index(es)
		 * @param integer $intFeature
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ItemHasFeatures[]
		*/
		public static function LoadArrayByFeature($intFeature, $objOptionalClauses = null) {
			// Call ItemHasFeatures::QueryArray to perform the LoadArrayByFeature query
			try {
				return ItemHasFeatures::QueryArray(
					QQ::Equal(QQN::ItemHasFeatures()->Feature, $intFeature),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ItemHasFeatureses
		 * by Feature Index(es)
		 * @param integer $intFeature
		 * @return int
		*/
		public static function CountByFeature($intFeature) {
			// Call ItemHasFeatures::QueryCount to perform the CountByFeature query
			return ItemHasFeatures::QueryCount(
				QQ::Equal(QQN::ItemHasFeatures()->Feature, $intFeature)
			);
		}

		/**
		 * Load an array of ItemHasFeatures objects,
		 * by Item Index(es)
		 * @param integer $intItem
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ItemHasFeatures[]
		*/
		public static function LoadArrayByItem($intItem, $objOptionalClauses = null) {
			// Call ItemHasFeatures::QueryArray to perform the LoadArrayByItem query
			try {
				return ItemHasFeatures::QueryArray(
					QQ::Equal(QQN::ItemHasFeatures()->Item, $intItem),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ItemHasFeatureses
		 * by Item Index(es)
		 * @param integer $intItem
		 * @return int
		*/
		public static function CountByItem($intItem) {
			// Call ItemHasFeatures::QueryCount to perform the CountByItem query
			return ItemHasFeatures::QueryCount(
				QQ::Equal(QQN::ItemHasFeatures()->Item, $intItem)
			);
		}

		/**
		 * Load an array of ItemHasFeatures objects,
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ItemHasFeatures[]
		*/
		public static function LoadArrayByParrent($intParrent, $objOptionalClauses = null) {
			// Call ItemHasFeatures::QueryArray to perform the LoadArrayByParrent query
			try {
				return ItemHasFeatures::QueryArray(
					QQ::Equal(QQN::ItemHasFeatures()->Parrent, $intParrent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ItemHasFeatureses
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @return int
		*/
		public static function CountByParrent($intParrent) {
			// Call ItemHasFeatures::QueryCount to perform the CountByParrent query
			return ItemHasFeatures::QueryCount(
				QQ::Equal(QQN::ItemHasFeatures()->Parrent, $intParrent)
			);
		}

		/**
		 * Load an array of ItemHasFeatures objects,
		 * by RequirmentBy Index(es)
		 * @param integer $intRequirmentBy
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ItemHasFeatures[]
		*/
		public static function LoadArrayByRequirmentBy($intRequirmentBy, $objOptionalClauses = null) {
			// Call ItemHasFeatures::QueryArray to perform the LoadArrayByRequirmentBy query
			try {
				return ItemHasFeatures::QueryArray(
					QQ::Equal(QQN::ItemHasFeatures()->RequirmentBy, $intRequirmentBy),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ItemHasFeatureses
		 * by RequirmentBy Index(es)
		 * @param integer $intRequirmentBy
		 * @return int
		*/
		public static function CountByRequirmentBy($intRequirmentBy) {
			// Call ItemHasFeatures::QueryCount to perform the CountByRequirmentBy query
			return ItemHasFeatures::QueryCount(
				QQ::Equal(QQN::ItemHasFeatures()->RequirmentBy, $intRequirmentBy)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this ItemHasFeatures
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = ItemHasFeatures::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `item_has_features` (
							`item`,
							`feature`,
							`seq`,
							`parrent`,
							`counter`,
							`requirment_by`,
							`due_date`,
							`data`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intItem) . ',
							' . $objDatabase->SqlVariable($this->intFeature) . ',
							' . $objDatabase->SqlVariable($this->intSeq) . ',
							' . $objDatabase->SqlVariable($this->intParrent) . ',
							' . $objDatabase->SqlVariable($this->intCounter) . ',
							' . $objDatabase->SqlVariable($this->intRequirmentBy) . ',
							' . $objDatabase->SqlVariable($this->dttDueDate) . ',
							' . $objDatabase->SqlVariable($this->strData) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIditemHasFeatures = $objDatabase->InsertId('item_has_features', 'iditem_has_features');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)
					if (!$blnForceUpdate) {
						// Perform the Optimistic Locking check
						$objResult = $objDatabase->Query('
							SELECT
								`date`
							FROM
								`item_has_features`
							WHERE
							`iditem_has_features` = ' . $objDatabase->SqlVariable($this->intIditemHasFeatures) . '
						');

						$objRow = $objResult->FetchArray();
						if ($objRow[0] != $this->strDate)
							throw new QOptimisticLockingException('ItemHasFeatures');
					}

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`item_has_features`
						SET
							`item` = ' . $objDatabase->SqlVariable($this->intItem) . ',
							`feature` = ' . $objDatabase->SqlVariable($this->intFeature) . ',
							`seq` = ' . $objDatabase->SqlVariable($this->intSeq) . ',
							`parrent` = ' . $objDatabase->SqlVariable($this->intParrent) . ',
							`counter` = ' . $objDatabase->SqlVariable($this->intCounter) . ',
							`requirment_by` = ' . $objDatabase->SqlVariable($this->intRequirmentBy) . ',
							`due_date` = ' . $objDatabase->SqlVariable($this->dttDueDate) . ',
							`data` = ' . $objDatabase->SqlVariable($this->strData) . '
						WHERE
							`iditem_has_features` = ' . $objDatabase->SqlVariable($this->intIditemHasFeatures) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;

			// Update Local Timestamp
			$objResult = $objDatabase->Query('
				SELECT
					`date`
				FROM
					`item_has_features`
				WHERE
							`iditem_has_features` = ' . $objDatabase->SqlVariable($this->intIditemHasFeatures) . '
			');

			$objRow = $objResult->FetchArray();
			$this->strDate = $objRow[0];

			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this ItemHasFeatures
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIditemHasFeatures)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this ItemHasFeatures with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = ItemHasFeatures::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`item_has_features`
				WHERE
					`iditem_has_features` = ' . $objDatabase->SqlVariable($this->intIditemHasFeatures) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this ItemHasFeatures ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'ItemHasFeatures', $this->intIditemHasFeatures);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all ItemHasFeatureses
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = ItemHasFeatures::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`item_has_features`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate item_has_features table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = ItemHasFeatures::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `item_has_features`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this ItemHasFeatures from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved ItemHasFeatures object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = ItemHasFeatures::Load($this->intIditemHasFeatures);

			// Update $this's local variables to match
			$this->strDate = $objReloaded->strDate;
			$this->Item = $objReloaded->Item;
			$this->Feature = $objReloaded->Feature;
			$this->intSeq = $objReloaded->intSeq;
			$this->Parrent = $objReloaded->Parrent;
			$this->intCounter = $objReloaded->intCounter;
			$this->RequirmentBy = $objReloaded->RequirmentBy;
			$this->dttDueDate = $objReloaded->dttDueDate;
			$this->strData = $objReloaded->strData;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IditemHasFeatures':
					/**
					 * Gets the value for intIditemHasFeatures (Read-Only PK)
					 * @return integer
					 */
					return $this->intIditemHasFeatures;

				case 'Date':
					/**
					 * Gets the value for strDate (Read-Only Timestamp)
					 * @return string
					 */
					return $this->strDate;

				case 'Item':
					/**
					 * Gets the value for intItem (Not Null)
					 * @return integer
					 */
					return $this->intItem;

				case 'Feature':
					/**
					 * Gets the value for intFeature (Not Null)
					 * @return integer
					 */
					return $this->intFeature;

				case 'Seq':
					/**
					 * Gets the value for intSeq (Not Null)
					 * @return integer
					 */
					return $this->intSeq;

				case 'Parrent':
					/**
					 * Gets the value for intParrent 
					 * @return integer
					 */
					return $this->intParrent;

				case 'Counter':
					/**
					 * Gets the value for intCounter (Not Null)
					 * @return integer
					 */
					return $this->intCounter;

				case 'RequirmentBy':
					/**
					 * Gets the value for intRequirmentBy 
					 * @return integer
					 */
					return $this->intRequirmentBy;

				case 'DueDate':
					/**
					 * Gets the value for dttDueDate 
					 * @return QDateTime
					 */
					return $this->dttDueDate;

				case 'Data':
					/**
					 * Gets the value for strData 
					 * @return string
					 */
					return $this->strData;


				///////////////////
				// Member Objects
				///////////////////
				case 'ItemObject':
					/**
					 * Gets the value for the LedgerDetails object referenced by intItem (Not Null)
					 * @return LedgerDetails
					 */
					try {
						if ((!$this->objItemObject) && (!is_null($this->intItem)))
							$this->objItemObject = LedgerDetails::Load($this->intItem);
						return $this->objItemObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'FeatureObject':
					/**
					 * Gets the value for the Features object referenced by intFeature (Not Null)
					 * @return Features
					 */
					try {
						if ((!$this->objFeatureObject) && (!is_null($this->intFeature)))
							$this->objFeatureObject = Features::Load($this->intFeature);
						return $this->objFeatureObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ParrentObject':
					/**
					 * Gets the value for the ItemHasFeatures object referenced by intParrent 
					 * @return ItemHasFeatures
					 */
					try {
						if ((!$this->objParrentObject) && (!is_null($this->intParrent)))
							$this->objParrentObject = ItemHasFeatures::Load($this->intParrent);
						return $this->objParrentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RequirmentByObject':
					/**
					 * Gets the value for the Ledger object referenced by intRequirmentBy 
					 * @return Ledger
					 */
					try {
						if ((!$this->objRequirmentByObject) && (!is_null($this->intRequirmentBy)))
							$this->objRequirmentByObject = Ledger::Load($this->intRequirmentBy);
						return $this->objRequirmentByObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_ItemHasFeaturesAsParrent':
					/**
					 * Gets the value for the private _objItemHasFeaturesAsParrent (Read-Only)
					 * if set due to an expansion on the item_has_features.parrent reverse relationship
					 * @return ItemHasFeatures
					 */
					return $this->_objItemHasFeaturesAsParrent;

				case '_ItemHasFeaturesAsParrentArray':
					/**
					 * Gets the value for the private _objItemHasFeaturesAsParrentArray (Read-Only)
					 * if set due to an ExpandAsArray on the item_has_features.parrent reverse relationship
					 * @return ItemHasFeatures[]
					 */
					return $this->_objItemHasFeaturesAsParrentArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Item':
					/**
					 * Sets the value for intItem (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objItemObject = null;
						return ($this->intItem = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Feature':
					/**
					 * Sets the value for intFeature (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objFeatureObject = null;
						return ($this->intFeature = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Seq':
					/**
					 * Sets the value for intSeq (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intSeq = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Parrent':
					/**
					 * Sets the value for intParrent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objParrentObject = null;
						return ($this->intParrent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Counter':
					/**
					 * Sets the value for intCounter (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intCounter = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RequirmentBy':
					/**
					 * Sets the value for intRequirmentBy 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objRequirmentByObject = null;
						return ($this->intRequirmentBy = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DueDate':
					/**
					 * Sets the value for dttDueDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDueDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Data':
					/**
					 * Sets the value for strData 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strData = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'ItemObject':
					/**
					 * Sets the value for the LedgerDetails object referenced by intItem (Not Null)
					 * @param LedgerDetails $mixValue
					 * @return LedgerDetails
					 */
					if (is_null($mixValue)) {
						$this->intItem = null;
						$this->objItemObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a LedgerDetails object
						try {
							$mixValue = QType::Cast($mixValue, 'LedgerDetails');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED LedgerDetails object
						if (is_null($mixValue->IdledgerDetails))
							throw new QCallerException('Unable to set an unsaved ItemObject for this ItemHasFeatures');

						// Update Local Member Variables
						$this->objItemObject = $mixValue;
						$this->intItem = $mixValue->IdledgerDetails;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'FeatureObject':
					/**
					 * Sets the value for the Features object referenced by intFeature (Not Null)
					 * @param Features $mixValue
					 * @return Features
					 */
					if (is_null($mixValue)) {
						$this->intFeature = null;
						$this->objFeatureObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Features object
						try {
							$mixValue = QType::Cast($mixValue, 'Features');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Features object
						if (is_null($mixValue->Idfeatures))
							throw new QCallerException('Unable to set an unsaved FeatureObject for this ItemHasFeatures');

						// Update Local Member Variables
						$this->objFeatureObject = $mixValue;
						$this->intFeature = $mixValue->Idfeatures;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ParrentObject':
					/**
					 * Sets the value for the ItemHasFeatures object referenced by intParrent 
					 * @param ItemHasFeatures $mixValue
					 * @return ItemHasFeatures
					 */
					if (is_null($mixValue)) {
						$this->intParrent = null;
						$this->objParrentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a ItemHasFeatures object
						try {
							$mixValue = QType::Cast($mixValue, 'ItemHasFeatures');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED ItemHasFeatures object
						if (is_null($mixValue->IditemHasFeatures))
							throw new QCallerException('Unable to set an unsaved ParrentObject for this ItemHasFeatures');

						// Update Local Member Variables
						$this->objParrentObject = $mixValue;
						$this->intParrent = $mixValue->IditemHasFeatures;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'RequirmentByObject':
					/**
					 * Sets the value for the Ledger object referenced by intRequirmentBy 
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intRequirmentBy = null;
						$this->objRequirmentByObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved RequirmentByObject for this ItemHasFeatures');

						// Update Local Member Variables
						$this->objRequirmentByObject = $mixValue;
						$this->intRequirmentBy = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for ItemHasFeaturesAsParrent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ItemHasFeaturesesAsParrent as an array of ItemHasFeatures objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ItemHasFeatures[]
		*/
		public function GetItemHasFeaturesAsParrentArray($objOptionalClauses = null) {
			if ((is_null($this->intIditemHasFeatures)))
				return array();

			try {
				return ItemHasFeatures::LoadArrayByParrent($this->intIditemHasFeatures, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ItemHasFeaturesesAsParrent
		 * @return int
		*/
		public function CountItemHasFeaturesesAsParrent() {
			if ((is_null($this->intIditemHasFeatures)))
				return 0;

			return ItemHasFeatures::CountByParrent($this->intIditemHasFeatures);
		}

		/**
		 * Associates a ItemHasFeaturesAsParrent
		 * @param ItemHasFeatures $objItemHasFeatures
		 * @return void
		*/
		public function AssociateItemHasFeaturesAsParrent(ItemHasFeatures $objItemHasFeatures) {
			if ((is_null($this->intIditemHasFeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateItemHasFeaturesAsParrent on this unsaved ItemHasFeatures.');
			if ((is_null($objItemHasFeatures->IditemHasFeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateItemHasFeaturesAsParrent on this ItemHasFeatures with an unsaved ItemHasFeatures.');

			// Get the Database Object for this Class
			$objDatabase = ItemHasFeatures::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`item_has_features`
				SET
					`parrent` = ' . $objDatabase->SqlVariable($this->intIditemHasFeatures) . '
				WHERE
					`iditem_has_features` = ' . $objDatabase->SqlVariable($objItemHasFeatures->IditemHasFeatures) . '
			');
		}

		/**
		 * Unassociates a ItemHasFeaturesAsParrent
		 * @param ItemHasFeatures $objItemHasFeatures
		 * @return void
		*/
		public function UnassociateItemHasFeaturesAsParrent(ItemHasFeatures $objItemHasFeatures) {
			if ((is_null($this->intIditemHasFeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateItemHasFeaturesAsParrent on this unsaved ItemHasFeatures.');
			if ((is_null($objItemHasFeatures->IditemHasFeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateItemHasFeaturesAsParrent on this ItemHasFeatures with an unsaved ItemHasFeatures.');

			// Get the Database Object for this Class
			$objDatabase = ItemHasFeatures::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`item_has_features`
				SET
					`parrent` = null
				WHERE
					`iditem_has_features` = ' . $objDatabase->SqlVariable($objItemHasFeatures->IditemHasFeatures) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIditemHasFeatures) . '
			');
		}

		/**
		 * Unassociates all ItemHasFeaturesesAsParrent
		 * @return void
		*/
		public function UnassociateAllItemHasFeaturesesAsParrent() {
			if ((is_null($this->intIditemHasFeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateItemHasFeaturesAsParrent on this unsaved ItemHasFeatures.');

			// Get the Database Object for this Class
			$objDatabase = ItemHasFeatures::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`item_has_features`
				SET
					`parrent` = null
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIditemHasFeatures) . '
			');
		}

		/**
		 * Deletes an associated ItemHasFeaturesAsParrent
		 * @param ItemHasFeatures $objItemHasFeatures
		 * @return void
		*/
		public function DeleteAssociatedItemHasFeaturesAsParrent(ItemHasFeatures $objItemHasFeatures) {
			if ((is_null($this->intIditemHasFeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateItemHasFeaturesAsParrent on this unsaved ItemHasFeatures.');
			if ((is_null($objItemHasFeatures->IditemHasFeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateItemHasFeaturesAsParrent on this ItemHasFeatures with an unsaved ItemHasFeatures.');

			// Get the Database Object for this Class
			$objDatabase = ItemHasFeatures::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`item_has_features`
				WHERE
					`iditem_has_features` = ' . $objDatabase->SqlVariable($objItemHasFeatures->IditemHasFeatures) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIditemHasFeatures) . '
			');
		}

		/**
		 * Deletes all associated ItemHasFeaturesesAsParrent
		 * @return void
		*/
		public function DeleteAllItemHasFeaturesesAsParrent() {
			if ((is_null($this->intIditemHasFeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateItemHasFeaturesAsParrent on this unsaved ItemHasFeatures.');

			// Get the Database Object for this Class
			$objDatabase = ItemHasFeatures::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`item_has_features`
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIditemHasFeatures) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "item_has_features";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[ItemHasFeatures::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="ItemHasFeatures"><sequence>';
			$strToReturn .= '<element name="IditemHasFeatures" type="xsd:int"/>';
			$strToReturn .= '<element name="Date" type="xsd:string"/>';
			$strToReturn .= '<element name="ItemObject" type="xsd1:LedgerDetails"/>';
			$strToReturn .= '<element name="FeatureObject" type="xsd1:Features"/>';
			$strToReturn .= '<element name="Seq" type="xsd:int"/>';
			$strToReturn .= '<element name="ParrentObject" type="xsd1:ItemHasFeatures"/>';
			$strToReturn .= '<element name="Counter" type="xsd:int"/>';
			$strToReturn .= '<element name="RequirmentByObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="DueDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Data" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('ItemHasFeatures', $strComplexTypeArray)) {
				$strComplexTypeArray['ItemHasFeatures'] = ItemHasFeatures::GetSoapComplexTypeXml();
				LedgerDetails::AlterSoapComplexTypeArray($strComplexTypeArray);
				Features::AlterSoapComplexTypeArray($strComplexTypeArray);
				ItemHasFeatures::AlterSoapComplexTypeArray($strComplexTypeArray);
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, ItemHasFeatures::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new ItemHasFeatures();
			if (property_exists($objSoapObject, 'IditemHasFeatures'))
				$objToReturn->intIditemHasFeatures = $objSoapObject->IditemHasFeatures;
			if (property_exists($objSoapObject, 'Date'))
				$objToReturn->strDate = $objSoapObject->Date;
			if ((property_exists($objSoapObject, 'ItemObject')) &&
				($objSoapObject->ItemObject))
				$objToReturn->ItemObject = LedgerDetails::GetObjectFromSoapObject($objSoapObject->ItemObject);
			if ((property_exists($objSoapObject, 'FeatureObject')) &&
				($objSoapObject->FeatureObject))
				$objToReturn->FeatureObject = Features::GetObjectFromSoapObject($objSoapObject->FeatureObject);
			if (property_exists($objSoapObject, 'Seq'))
				$objToReturn->intSeq = $objSoapObject->Seq;
			if ((property_exists($objSoapObject, 'ParrentObject')) &&
				($objSoapObject->ParrentObject))
				$objToReturn->ParrentObject = ItemHasFeatures::GetObjectFromSoapObject($objSoapObject->ParrentObject);
			if (property_exists($objSoapObject, 'Counter'))
				$objToReturn->intCounter = $objSoapObject->Counter;
			if ((property_exists($objSoapObject, 'RequirmentByObject')) &&
				($objSoapObject->RequirmentByObject))
				$objToReturn->RequirmentByObject = Ledger::GetObjectFromSoapObject($objSoapObject->RequirmentByObject);
			if (property_exists($objSoapObject, 'DueDate'))
				$objToReturn->dttDueDate = new QDateTime($objSoapObject->DueDate);
			if (property_exists($objSoapObject, 'Data'))
				$objToReturn->strData = $objSoapObject->Data;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, ItemHasFeatures::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objItemObject)
				$objObject->objItemObject = LedgerDetails::GetSoapObjectFromObject($objObject->objItemObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intItem = null;
			if ($objObject->objFeatureObject)
				$objObject->objFeatureObject = Features::GetSoapObjectFromObject($objObject->objFeatureObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intFeature = null;
			if ($objObject->objParrentObject)
				$objObject->objParrentObject = ItemHasFeatures::GetSoapObjectFromObject($objObject->objParrentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intParrent = null;
			if ($objObject->objRequirmentByObject)
				$objObject->objRequirmentByObject = Ledger::GetSoapObjectFromObject($objObject->objRequirmentByObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intRequirmentBy = null;
			if ($objObject->dttDueDate)
				$objObject->dttDueDate = $objObject->dttDueDate->qFormat(QDateTime::FormatSoap);
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IditemHasFeatures'] = $this->intIditemHasFeatures;
			$iArray['Date'] = $this->strDate;
			$iArray['Item'] = $this->intItem;
			$iArray['Feature'] = $this->intFeature;
			$iArray['Seq'] = $this->intSeq;
			$iArray['Parrent'] = $this->intParrent;
			$iArray['Counter'] = $this->intCounter;
			$iArray['RequirmentBy'] = $this->intRequirmentBy;
			$iArray['DueDate'] = $this->dttDueDate;
			$iArray['Data'] = $this->strData;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIditemHasFeatures ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IditemHasFeatures
     * @property-read QQNode $Date
     * @property-read QQNode $Item
     * @property-read QQNodeLedgerDetails $ItemObject
     * @property-read QQNode $Feature
     * @property-read QQNodeFeatures $FeatureObject
     * @property-read QQNode $Seq
     * @property-read QQNode $Parrent
     * @property-read QQNodeItemHasFeatures $ParrentObject
     * @property-read QQNode $Counter
     * @property-read QQNode $RequirmentBy
     * @property-read QQNodeLedger $RequirmentByObject
     * @property-read QQNode $DueDate
     * @property-read QQNode $Data
     *
     *
     * @property-read QQReverseReferenceNodeItemHasFeatures $ItemHasFeaturesAsParrent

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeItemHasFeatures extends QQNode {
		protected $strTableName = 'item_has_features';
		protected $strPrimaryKey = 'iditem_has_features';
		protected $strClassName = 'ItemHasFeatures';
		public function __get($strName) {
			switch ($strName) {
				case 'IditemHasFeatures':
					return new QQNode('iditem_has_features', 'IditemHasFeatures', 'Integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'VarChar', $this);
				case 'Item':
					return new QQNode('item', 'Item', 'Integer', $this);
				case 'ItemObject':
					return new QQNodeLedgerDetails('item', 'ItemObject', 'Integer', $this);
				case 'Feature':
					return new QQNode('feature', 'Feature', 'Integer', $this);
				case 'FeatureObject':
					return new QQNodeFeatures('feature', 'FeatureObject', 'Integer', $this);
				case 'Seq':
					return new QQNode('seq', 'Seq', 'Integer', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'Integer', $this);
				case 'ParrentObject':
					return new QQNodeItemHasFeatures('parrent', 'ParrentObject', 'Integer', $this);
				case 'Counter':
					return new QQNode('counter', 'Counter', 'Integer', $this);
				case 'RequirmentBy':
					return new QQNode('requirment_by', 'RequirmentBy', 'Integer', $this);
				case 'RequirmentByObject':
					return new QQNodeLedger('requirment_by', 'RequirmentByObject', 'Integer', $this);
				case 'DueDate':
					return new QQNode('due_date', 'DueDate', 'DateTime', $this);
				case 'Data':
					return new QQNode('data', 'Data', 'Blob', $this);
				case 'ItemHasFeaturesAsParrent':
					return new QQReverseReferenceNodeItemHasFeatures($this, 'itemhasfeaturesasparrent', 'reverse_reference', 'parrent');

				case '_PrimaryKeyNode':
					return new QQNode('iditem_has_features', 'IditemHasFeatures', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IditemHasFeatures
     * @property-read QQNode $Date
     * @property-read QQNode $Item
     * @property-read QQNodeLedgerDetails $ItemObject
     * @property-read QQNode $Feature
     * @property-read QQNodeFeatures $FeatureObject
     * @property-read QQNode $Seq
     * @property-read QQNode $Parrent
     * @property-read QQNodeItemHasFeatures $ParrentObject
     * @property-read QQNode $Counter
     * @property-read QQNode $RequirmentBy
     * @property-read QQNodeLedger $RequirmentByObject
     * @property-read QQNode $DueDate
     * @property-read QQNode $Data
     *
     *
     * @property-read QQReverseReferenceNodeItemHasFeatures $ItemHasFeaturesAsParrent

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeItemHasFeatures extends QQReverseReferenceNode {
		protected $strTableName = 'item_has_features';
		protected $strPrimaryKey = 'iditem_has_features';
		protected $strClassName = 'ItemHasFeatures';
		public function __get($strName) {
			switch ($strName) {
				case 'IditemHasFeatures':
					return new QQNode('iditem_has_features', 'IditemHasFeatures', 'integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'string', $this);
				case 'Item':
					return new QQNode('item', 'Item', 'integer', $this);
				case 'ItemObject':
					return new QQNodeLedgerDetails('item', 'ItemObject', 'integer', $this);
				case 'Feature':
					return new QQNode('feature', 'Feature', 'integer', $this);
				case 'FeatureObject':
					return new QQNodeFeatures('feature', 'FeatureObject', 'integer', $this);
				case 'Seq':
					return new QQNode('seq', 'Seq', 'integer', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'integer', $this);
				case 'ParrentObject':
					return new QQNodeItemHasFeatures('parrent', 'ParrentObject', 'integer', $this);
				case 'Counter':
					return new QQNode('counter', 'Counter', 'integer', $this);
				case 'RequirmentBy':
					return new QQNode('requirment_by', 'RequirmentBy', 'integer', $this);
				case 'RequirmentByObject':
					return new QQNodeLedger('requirment_by', 'RequirmentByObject', 'integer', $this);
				case 'DueDate':
					return new QQNode('due_date', 'DueDate', 'QDateTime', $this);
				case 'Data':
					return new QQNode('data', 'Data', 'string', $this);
				case 'ItemHasFeaturesAsParrent':
					return new QQReverseReferenceNodeItemHasFeatures($this, 'itemhasfeaturesasparrent', 'reverse_reference', 'parrent');

				case '_PrimaryKeyNode':
					return new QQNode('iditem_has_features', 'IditemHasFeatures', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
