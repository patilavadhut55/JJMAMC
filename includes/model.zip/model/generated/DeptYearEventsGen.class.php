<?php
	/**
	 * The abstract DeptYearEventsGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the DeptYearEvents subclass which
	 * extends this DeptYearEventsGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the DeptYearEvents class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IddeptYearEvents the value for intIddeptYearEvents (Read-Only PK)
	 * @property string $Title the value for strTitle (Unique)
	 * @property integer $Event the value for intEvent (Not Null)
	 * @property integer $Department the value for intDepartment 
	 * @property integer $DeptYear the value for intDeptYear 
	 * @property integer $CalenderYear the value for intCalenderYear 
	 * @property integer $Parrent the value for intParrent 
	 * @property QDateTime $From the value for dttFrom (Not Null)
	 * @property QDateTime $To the value for dttTo (Not Null)
	 * @property string $Description the value for strDescription 
	 * @property integer $ExamType the value for intExamType 
	 * @property integer $YearlySubject the value for intYearlySubject 
	 * @property integer $RefrenceEvent the value for intRefrenceEvent 
	 * @property string $Mean the value for strMean 
	 * @property string $Sd the value for strSd 
	 * @property integer $Intiator the value for intIntiator 
	 * @property integer $Owner the value for intOwner 
	 * @property string $Reason the value for strReason 
	 * @property string $Code the value for strCode 
	 * @property Event $EventObject the value for the Event object referenced by intEvent (Not Null)
	 * @property Role $DepartmentObject the value for the Role object referenced by intDepartment 
	 * @property DeptYear $DeptYearObject the value for the DeptYear object referenced by intDeptYear 
	 * @property CalenderYear $CalenderYearObject the value for the CalenderYear object referenced by intCalenderYear 
	 * @property DeptYearEvents $ParrentObject the value for the DeptYearEvents object referenced by intParrent 
	 * @property Exam $ExamTypeObject the value for the Exam object referenced by intExamType 
	 * @property YearlySubject $YearlySubjectObject the value for the YearlySubject object referenced by intYearlySubject 
	 * @property DeptYearEvents $RefrenceEventObject the value for the DeptYearEvents object referenced by intRefrenceEvent 
	 * @property Login $IntiatorObject the value for the Login object referenced by intIntiator 
	 * @property Login $OwnerObject the value for the Login object referenced by intOwner 
	 * @property-read AppliedExam $_AppliedExamAsEventSubject the value for the private _objAppliedExamAsEventSubject (Read-Only) if set due to an expansion on the applied_exam.event_subject reverse relationship
	 * @property-read AppliedExam[] $_AppliedExamAsEventSubjectArray the value for the private _objAppliedExamAsEventSubjectArray (Read-Only) if set due to an ExpandAsArray on the applied_exam.event_subject reverse relationship
	 * @property-read AppliedExam $_AppliedExamAsEventExam the value for the private _objAppliedExamAsEventExam (Read-Only) if set due to an expansion on the applied_exam.event_exam reverse relationship
	 * @property-read AppliedExam[] $_AppliedExamAsEventExamArray the value for the private _objAppliedExamAsEventExamArray (Read-Only) if set due to an ExpandAsArray on the applied_exam.event_exam reverse relationship
	 * @property-read DeptYearEvents $_DeptYearEventsAsParrent the value for the private _objDeptYearEventsAsParrent (Read-Only) if set due to an expansion on the dept_year_events.parrent reverse relationship
	 * @property-read DeptYearEvents[] $_DeptYearEventsAsParrentArray the value for the private _objDeptYearEventsAsParrentArray (Read-Only) if set due to an ExpandAsArray on the dept_year_events.parrent reverse relationship
	 * @property-read DeptYearEvents $_DeptYearEventsAsRefrenceEvent the value for the private _objDeptYearEventsAsRefrenceEvent (Read-Only) if set due to an expansion on the dept_year_events.refrence_event reverse relationship
	 * @property-read DeptYearEvents[] $_DeptYearEventsAsRefrenceEventArray the value for the private _objDeptYearEventsAsRefrenceEventArray (Read-Only) if set due to an ExpandAsArray on the dept_year_events.refrence_event reverse relationship
	 * @property-read EventHasAttendent $_EventHasAttendentAsEvent the value for the private _objEventHasAttendentAsEvent (Read-Only) if set due to an expansion on the event_has_attendent.event reverse relationship
	 * @property-read EventHasAttendent[] $_EventHasAttendentAsEventArray the value for the private _objEventHasAttendentAsEventArray (Read-Only) if set due to an ExpandAsArray on the event_has_attendent.event reverse relationship
	 * @property-read EventHasGrade $_EventHasGrade the value for the private _objEventHasGrade (Read-Only) if set due to an expansion on the event_has_grade.dept_year_events reverse relationship
	 * @property-read EventHasGrade[] $_EventHasGradeArray the value for the private _objEventHasGradeArray (Read-Only) if set due to an ExpandAsArray on the event_has_grade.dept_year_events reverse relationship
	 * @property-read Exampaper $_ExampaperAsEventExam the value for the private _objExampaperAsEventExam (Read-Only) if set due to an expansion on the exampaper.event_exam reverse relationship
	 * @property-read Exampaper[] $_ExampaperAsEventExamArray the value for the private _objExampaperAsEventExamArray (Read-Only) if set due to an ExpandAsArray on the exampaper.event_exam reverse relationship
	 * @property-read MeetingNotes $_MeetingNotesAsMeeting the value for the private _objMeetingNotesAsMeeting (Read-Only) if set due to an expansion on the meeting_notes.meeting reverse relationship
	 * @property-read MeetingNotes[] $_MeetingNotesAsMeetingArray the value for the private _objMeetingNotesAsMeetingArray (Read-Only) if set due to an ExpandAsArray on the meeting_notes.meeting reverse relationship
	 * @property-read MemberDoc $_MemberDocAsMeeting the value for the private _objMemberDocAsMeeting (Read-Only) if set due to an expansion on the member_doc.meeting reverse relationship
	 * @property-read MemberDoc[] $_MemberDocAsMeetingArray the value for the private _objMemberDocAsMeetingArray (Read-Only) if set due to an ExpandAsArray on the member_doc.meeting reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class DeptYearEventsGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column dept_year_events.iddept_year_events
		 * @var integer intIddeptYearEvents
		 */
		protected $intIddeptYearEvents;
		const IddeptYearEventsDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.title
		 * @var string strTitle
		 */
		protected $strTitle;
		const TitleMaxLength = 255;
		const TitleDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.event
		 * @var integer intEvent
		 */
		protected $intEvent;
		const EventDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.department
		 * @var integer intDepartment
		 */
		protected $intDepartment;
		const DepartmentDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.dept_year
		 * @var integer intDeptYear
		 */
		protected $intDeptYear;
		const DeptYearDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.calender_year
		 * @var integer intCalenderYear
		 */
		protected $intCalenderYear;
		const CalenderYearDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.parrent
		 * @var integer intParrent
		 */
		protected $intParrent;
		const ParrentDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.from
		 * @var QDateTime dttFrom
		 */
		protected $dttFrom;
		const FromDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.to
		 * @var QDateTime dttTo
		 */
		protected $dttTo;
		const ToDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.description
		 * @var string strDescription
		 */
		protected $strDescription;
		const DescriptionDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.exam_type
		 * @var integer intExamType
		 */
		protected $intExamType;
		const ExamTypeDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.yearly_subject
		 * @var integer intYearlySubject
		 */
		protected $intYearlySubject;
		const YearlySubjectDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.refrence_event
		 * @var integer intRefrenceEvent
		 */
		protected $intRefrenceEvent;
		const RefrenceEventDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.mean
		 * @var string strMean
		 */
		protected $strMean;
		const MeanDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.sd
		 * @var string strSd
		 */
		protected $strSd;
		const SdDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.intiator
		 * @var integer intIntiator
		 */
		protected $intIntiator;
		const IntiatorDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.owner
		 * @var integer intOwner
		 */
		protected $intOwner;
		const OwnerDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.reason
		 * @var string strReason
		 */
		protected $strReason;
		const ReasonDefault = null;


		/**
		 * Protected member variable that maps to the database column dept_year_events.code
		 * @var string strCode
		 */
		protected $strCode;
		const CodeMaxLength = 45;
		const CodeDefault = null;


		/**
		 * Private member variable that stores a reference to a single AppliedExamAsEventSubject object
		 * (of type AppliedExam), if this DeptYearEvents object was restored with
		 * an expansion on the applied_exam association table.
		 * @var AppliedExam _objAppliedExamAsEventSubject;
		 */
		private $_objAppliedExamAsEventSubject;

		/**
		 * Private member variable that stores a reference to an array of AppliedExamAsEventSubject objects
		 * (of type AppliedExam[]), if this DeptYearEvents object was restored with
		 * an ExpandAsArray on the applied_exam association table.
		 * @var AppliedExam[] _objAppliedExamAsEventSubjectArray;
		 */
		private $_objAppliedExamAsEventSubjectArray = null;

		/**
		 * Private member variable that stores a reference to a single AppliedExamAsEventExam object
		 * (of type AppliedExam), if this DeptYearEvents object was restored with
		 * an expansion on the applied_exam association table.
		 * @var AppliedExam _objAppliedExamAsEventExam;
		 */
		private $_objAppliedExamAsEventExam;

		/**
		 * Private member variable that stores a reference to an array of AppliedExamAsEventExam objects
		 * (of type AppliedExam[]), if this DeptYearEvents object was restored with
		 * an ExpandAsArray on the applied_exam association table.
		 * @var AppliedExam[] _objAppliedExamAsEventExamArray;
		 */
		private $_objAppliedExamAsEventExamArray = null;

		/**
		 * Private member variable that stores a reference to a single DeptYearEventsAsParrent object
		 * (of type DeptYearEvents), if this DeptYearEvents object was restored with
		 * an expansion on the dept_year_events association table.
		 * @var DeptYearEvents _objDeptYearEventsAsParrent;
		 */
		private $_objDeptYearEventsAsParrent;

		/**
		 * Private member variable that stores a reference to an array of DeptYearEventsAsParrent objects
		 * (of type DeptYearEvents[]), if this DeptYearEvents object was restored with
		 * an ExpandAsArray on the dept_year_events association table.
		 * @var DeptYearEvents[] _objDeptYearEventsAsParrentArray;
		 */
		private $_objDeptYearEventsAsParrentArray = null;

		/**
		 * Private member variable that stores a reference to a single DeptYearEventsAsRefrenceEvent object
		 * (of type DeptYearEvents), if this DeptYearEvents object was restored with
		 * an expansion on the dept_year_events association table.
		 * @var DeptYearEvents _objDeptYearEventsAsRefrenceEvent;
		 */
		private $_objDeptYearEventsAsRefrenceEvent;

		/**
		 * Private member variable that stores a reference to an array of DeptYearEventsAsRefrenceEvent objects
		 * (of type DeptYearEvents[]), if this DeptYearEvents object was restored with
		 * an ExpandAsArray on the dept_year_events association table.
		 * @var DeptYearEvents[] _objDeptYearEventsAsRefrenceEventArray;
		 */
		private $_objDeptYearEventsAsRefrenceEventArray = null;

		/**
		 * Private member variable that stores a reference to a single EventHasAttendentAsEvent object
		 * (of type EventHasAttendent), if this DeptYearEvents object was restored with
		 * an expansion on the event_has_attendent association table.
		 * @var EventHasAttendent _objEventHasAttendentAsEvent;
		 */
		private $_objEventHasAttendentAsEvent;

		/**
		 * Private member variable that stores a reference to an array of EventHasAttendentAsEvent objects
		 * (of type EventHasAttendent[]), if this DeptYearEvents object was restored with
		 * an ExpandAsArray on the event_has_attendent association table.
		 * @var EventHasAttendent[] _objEventHasAttendentAsEventArray;
		 */
		private $_objEventHasAttendentAsEventArray = null;

		/**
		 * Private member variable that stores a reference to a single EventHasGrade object
		 * (of type EventHasGrade), if this DeptYearEvents object was restored with
		 * an expansion on the event_has_grade association table.
		 * @var EventHasGrade _objEventHasGrade;
		 */
		private $_objEventHasGrade;

		/**
		 * Private member variable that stores a reference to an array of EventHasGrade objects
		 * (of type EventHasGrade[]), if this DeptYearEvents object was restored with
		 * an ExpandAsArray on the event_has_grade association table.
		 * @var EventHasGrade[] _objEventHasGradeArray;
		 */
		private $_objEventHasGradeArray = null;

		/**
		 * Private member variable that stores a reference to a single ExampaperAsEventExam object
		 * (of type Exampaper), if this DeptYearEvents object was restored with
		 * an expansion on the exampaper association table.
		 * @var Exampaper _objExampaperAsEventExam;
		 */
		private $_objExampaperAsEventExam;

		/**
		 * Private member variable that stores a reference to an array of ExampaperAsEventExam objects
		 * (of type Exampaper[]), if this DeptYearEvents object was restored with
		 * an ExpandAsArray on the exampaper association table.
		 * @var Exampaper[] _objExampaperAsEventExamArray;
		 */
		private $_objExampaperAsEventExamArray = null;

		/**
		 * Private member variable that stores a reference to a single MeetingNotesAsMeeting object
		 * (of type MeetingNotes), if this DeptYearEvents object was restored with
		 * an expansion on the meeting_notes association table.
		 * @var MeetingNotes _objMeetingNotesAsMeeting;
		 */
		private $_objMeetingNotesAsMeeting;

		/**
		 * Private member variable that stores a reference to an array of MeetingNotesAsMeeting objects
		 * (of type MeetingNotes[]), if this DeptYearEvents object was restored with
		 * an ExpandAsArray on the meeting_notes association table.
		 * @var MeetingNotes[] _objMeetingNotesAsMeetingArray;
		 */
		private $_objMeetingNotesAsMeetingArray = null;

		/**
		 * Private member variable that stores a reference to a single MemberDocAsMeeting object
		 * (of type MemberDoc), if this DeptYearEvents object was restored with
		 * an expansion on the member_doc association table.
		 * @var MemberDoc _objMemberDocAsMeeting;
		 */
		private $_objMemberDocAsMeeting;

		/**
		 * Private member variable that stores a reference to an array of MemberDocAsMeeting objects
		 * (of type MemberDoc[]), if this DeptYearEvents object was restored with
		 * an ExpandAsArray on the member_doc association table.
		 * @var MemberDoc[] _objMemberDocAsMeetingArray;
		 */
		private $_objMemberDocAsMeetingArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_events.event.
		 *
		 * NOTE: Always use the EventObject property getter to correctly retrieve this Event object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Event objEventObject
		 */
		protected $objEventObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_events.department.
		 *
		 * NOTE: Always use the DepartmentObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objDepartmentObject
		 */
		protected $objDepartmentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_events.dept_year.
		 *
		 * NOTE: Always use the DeptYearObject property getter to correctly retrieve this DeptYear object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var DeptYear objDeptYearObject
		 */
		protected $objDeptYearObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_events.calender_year.
		 *
		 * NOTE: Always use the CalenderYearObject property getter to correctly retrieve this CalenderYear object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var CalenderYear objCalenderYearObject
		 */
		protected $objCalenderYearObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_events.parrent.
		 *
		 * NOTE: Always use the ParrentObject property getter to correctly retrieve this DeptYearEvents object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var DeptYearEvents objParrentObject
		 */
		protected $objParrentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_events.exam_type.
		 *
		 * NOTE: Always use the ExamTypeObject property getter to correctly retrieve this Exam object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Exam objExamTypeObject
		 */
		protected $objExamTypeObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_events.yearly_subject.
		 *
		 * NOTE: Always use the YearlySubjectObject property getter to correctly retrieve this YearlySubject object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var YearlySubject objYearlySubjectObject
		 */
		protected $objYearlySubjectObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_events.refrence_event.
		 *
		 * NOTE: Always use the RefrenceEventObject property getter to correctly retrieve this DeptYearEvents object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var DeptYearEvents objRefrenceEventObject
		 */
		protected $objRefrenceEventObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_events.intiator.
		 *
		 * NOTE: Always use the IntiatorObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objIntiatorObject
		 */
		protected $objIntiatorObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column dept_year_events.owner.
		 *
		 * NOTE: Always use the OwnerObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objOwnerObject
		 */
		protected $objOwnerObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIddeptYearEvents = DeptYearEvents::IddeptYearEventsDefault;
			$this->strTitle = DeptYearEvents::TitleDefault;
			$this->intEvent = DeptYearEvents::EventDefault;
			$this->intDepartment = DeptYearEvents::DepartmentDefault;
			$this->intDeptYear = DeptYearEvents::DeptYearDefault;
			$this->intCalenderYear = DeptYearEvents::CalenderYearDefault;
			$this->intParrent = DeptYearEvents::ParrentDefault;
			$this->dttFrom = (DeptYearEvents::FromDefault === null)?null:new QDateTime(DeptYearEvents::FromDefault);
			$this->dttTo = (DeptYearEvents::ToDefault === null)?null:new QDateTime(DeptYearEvents::ToDefault);
			$this->strDescription = DeptYearEvents::DescriptionDefault;
			$this->intExamType = DeptYearEvents::ExamTypeDefault;
			$this->intYearlySubject = DeptYearEvents::YearlySubjectDefault;
			$this->intRefrenceEvent = DeptYearEvents::RefrenceEventDefault;
			$this->strMean = DeptYearEvents::MeanDefault;
			$this->strSd = DeptYearEvents::SdDefault;
			$this->intIntiator = DeptYearEvents::IntiatorDefault;
			$this->intOwner = DeptYearEvents::OwnerDefault;
			$this->strReason = DeptYearEvents::ReasonDefault;
			$this->strCode = DeptYearEvents::CodeDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a DeptYearEvents from PK Info
		 * @param integer $intIddeptYearEvents
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents
		 */
		public static function Load($intIddeptYearEvents, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'DeptYearEvents', $intIddeptYearEvents);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = DeptYearEvents::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::DeptYearEvents()->IddeptYearEvents, $intIddeptYearEvents)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all DeptYearEventses
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call DeptYearEvents::QueryArray to perform the LoadAll query
			try {
				return DeptYearEvents::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all DeptYearEventses
		 * @return int
		 */
		public static function CountAll() {
			// Call DeptYearEvents::QueryCount to perform the CountAll query
			return DeptYearEvents::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Create/Build out the QueryBuilder object with DeptYearEvents-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'dept_year_events');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				DeptYearEvents::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('dept_year_events');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single DeptYearEvents object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return DeptYearEvents the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = DeptYearEvents::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new DeptYearEvents object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = DeptYearEvents::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return DeptYearEvents::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of DeptYearEvents objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return DeptYearEvents[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = DeptYearEvents::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return DeptYearEvents::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = DeptYearEvents::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of DeptYearEvents objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = DeptYearEvents::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			$strQuery = DeptYearEvents::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/deptyearevents', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = DeptYearEvents::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this DeptYearEvents
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'dept_year_events';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'iddept_year_events', $strAliasPrefix . 'iddept_year_events');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'iddept_year_events', $strAliasPrefix . 'iddept_year_events');
			    $objBuilder->AddSelectItem($strTableName, 'title', $strAliasPrefix . 'title');
			    $objBuilder->AddSelectItem($strTableName, 'event', $strAliasPrefix . 'event');
			    $objBuilder->AddSelectItem($strTableName, 'department', $strAliasPrefix . 'department');
			    $objBuilder->AddSelectItem($strTableName, 'dept_year', $strAliasPrefix . 'dept_year');
			    $objBuilder->AddSelectItem($strTableName, 'calender_year', $strAliasPrefix . 'calender_year');
			    $objBuilder->AddSelectItem($strTableName, 'parrent', $strAliasPrefix . 'parrent');
			    $objBuilder->AddSelectItem($strTableName, 'from', $strAliasPrefix . 'from');
			    $objBuilder->AddSelectItem($strTableName, 'to', $strAliasPrefix . 'to');
			    $objBuilder->AddSelectItem($strTableName, 'description', $strAliasPrefix . 'description');
			    $objBuilder->AddSelectItem($strTableName, 'exam_type', $strAliasPrefix . 'exam_type');
			    $objBuilder->AddSelectItem($strTableName, 'yearly_subject', $strAliasPrefix . 'yearly_subject');
			    $objBuilder->AddSelectItem($strTableName, 'refrence_event', $strAliasPrefix . 'refrence_event');
			    $objBuilder->AddSelectItem($strTableName, 'mean', $strAliasPrefix . 'mean');
			    $objBuilder->AddSelectItem($strTableName, 'sd', $strAliasPrefix . 'sd');
			    $objBuilder->AddSelectItem($strTableName, 'intiator', $strAliasPrefix . 'intiator');
			    $objBuilder->AddSelectItem($strTableName, 'owner', $strAliasPrefix . 'owner');
			    $objBuilder->AddSelectItem($strTableName, 'reason', $strAliasPrefix . 'reason');
			    $objBuilder->AddSelectItem($strTableName, 'code', $strAliasPrefix . 'code');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a DeptYearEvents from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this DeptYearEvents::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return DeptYearEvents
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIddeptYearEvents == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'dept_year_events__';


						// Expanding reverse references: AppliedExamAsEventSubject
						$strAlias = $strAliasPrefix . 'appliedexamaseventsubject__idapplied_exam';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objAppliedExamAsEventSubjectArray)
								$objPreviousItem->_objAppliedExamAsEventSubjectArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objAppliedExamAsEventSubjectArray)) {
								$objPreviousChildItems = $objPreviousItem->_objAppliedExamAsEventSubjectArray;
								$objChildItem = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamaseventsubject__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objAppliedExamAsEventSubjectArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objAppliedExamAsEventSubjectArray[] = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamaseventsubject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: AppliedExamAsEventExam
						$strAlias = $strAliasPrefix . 'appliedexamaseventexam__idapplied_exam';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objAppliedExamAsEventExamArray)
								$objPreviousItem->_objAppliedExamAsEventExamArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objAppliedExamAsEventExamArray)) {
								$objPreviousChildItems = $objPreviousItem->_objAppliedExamAsEventExamArray;
								$objChildItem = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamaseventexam__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objAppliedExamAsEventExamArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objAppliedExamAsEventExamArray[] = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamaseventexam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: DeptYearEventsAsParrent
						$strAlias = $strAliasPrefix . 'deptyeareventsasparrent__iddept_year_events';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objDeptYearEventsAsParrentArray)
								$objPreviousItem->_objDeptYearEventsAsParrentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objDeptYearEventsAsParrentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objDeptYearEventsAsParrentArray;
								$objChildItem = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasparrent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objDeptYearEventsAsParrentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objDeptYearEventsAsParrentArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: DeptYearEventsAsRefrenceEvent
						$strAlias = $strAliasPrefix . 'deptyeareventsasrefrenceevent__iddept_year_events';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objDeptYearEventsAsRefrenceEventArray)
								$objPreviousItem->_objDeptYearEventsAsRefrenceEventArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objDeptYearEventsAsRefrenceEventArray)) {
								$objPreviousChildItems = $objPreviousItem->_objDeptYearEventsAsRefrenceEventArray;
								$objChildItem = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasrefrenceevent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objDeptYearEventsAsRefrenceEventArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objDeptYearEventsAsRefrenceEventArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasrefrenceevent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: EventHasAttendentAsEvent
						$strAlias = $strAliasPrefix . 'eventhasattendentasevent__idevent_has_attendent';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objEventHasAttendentAsEventArray)
								$objPreviousItem->_objEventHasAttendentAsEventArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objEventHasAttendentAsEventArray)) {
								$objPreviousChildItems = $objPreviousItem->_objEventHasAttendentAsEventArray;
								$objChildItem = EventHasAttendent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasattendentasevent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objEventHasAttendentAsEventArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objEventHasAttendentAsEventArray[] = EventHasAttendent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasattendentasevent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: EventHasGrade
						$strAlias = $strAliasPrefix . 'eventhasgrade__idevent_has_grade';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objEventHasGradeArray)
								$objPreviousItem->_objEventHasGradeArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objEventHasGradeArray)) {
								$objPreviousChildItems = $objPreviousItem->_objEventHasGradeArray;
								$objChildItem = EventHasGrade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasgrade__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objEventHasGradeArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objEventHasGradeArray[] = EventHasGrade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasgrade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ExampaperAsEventExam
						$strAlias = $strAliasPrefix . 'exampaperaseventexam__idexampaper';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objExampaperAsEventExamArray)
								$objPreviousItem->_objExampaperAsEventExamArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objExampaperAsEventExamArray)) {
								$objPreviousChildItems = $objPreviousItem->_objExampaperAsEventExamArray;
								$objChildItem = Exampaper::InstantiateDbRow($objDbRow, $strAliasPrefix . 'exampaperaseventexam__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objExampaperAsEventExamArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objExampaperAsEventExamArray[] = Exampaper::InstantiateDbRow($objDbRow, $strAliasPrefix . 'exampaperaseventexam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: MeetingNotesAsMeeting
						$strAlias = $strAliasPrefix . 'meetingnotesasmeeting__idmeeting_notes';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objMeetingNotesAsMeetingArray)
								$objPreviousItem->_objMeetingNotesAsMeetingArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objMeetingNotesAsMeetingArray)) {
								$objPreviousChildItems = $objPreviousItem->_objMeetingNotesAsMeetingArray;
								$objChildItem = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasmeeting__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objMeetingNotesAsMeetingArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objMeetingNotesAsMeetingArray[] = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasmeeting__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: MemberDocAsMeeting
						$strAlias = $strAliasPrefix . 'memberdocasmeeting__idmember_doc';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objMemberDocAsMeetingArray)
								$objPreviousItem->_objMemberDocAsMeetingArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objMemberDocAsMeetingArray)) {
								$objPreviousChildItems = $objPreviousItem->_objMemberDocAsMeetingArray;
								$objChildItem = MemberDoc::InstantiateDbRow($objDbRow, $strAliasPrefix . 'memberdocasmeeting__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objMemberDocAsMeetingArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objMemberDocAsMeetingArray[] = MemberDoc::InstantiateDbRow($objDbRow, $strAliasPrefix . 'memberdocasmeeting__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'dept_year_events__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the DeptYearEvents object
			$objToReturn = new DeptYearEvents();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIddeptYearEvents = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'title';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTitle = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'event';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intEvent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'department';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDepartment = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'dept_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDeptYear = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'calender_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCalenderYear = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'parrent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intParrent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'from';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttFrom = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttTo = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'description';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strDescription = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'exam_type';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intExamType = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'yearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intYearlySubject = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'refrence_event';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intRefrenceEvent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'mean';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strMean = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'sd';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strSd = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'intiator';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIntiator = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'owner';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intOwner = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'reason';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strReason = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCode = $objDbRow->GetColumn($strAliasName, 'VarChar');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IddeptYearEvents != $objPreviousItem->IddeptYearEvents) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objAppliedExamAsEventSubjectArray);
					$cnt = count($objToReturn->_objAppliedExamAsEventSubjectArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objAppliedExamAsEventSubjectArray, $objToReturn->_objAppliedExamAsEventSubjectArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objAppliedExamAsEventExamArray);
					$cnt = count($objToReturn->_objAppliedExamAsEventExamArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objAppliedExamAsEventExamArray, $objToReturn->_objAppliedExamAsEventExamArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objDeptYearEventsAsParrentArray);
					$cnt = count($objToReturn->_objDeptYearEventsAsParrentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objDeptYearEventsAsParrentArray, $objToReturn->_objDeptYearEventsAsParrentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objDeptYearEventsAsRefrenceEventArray);
					$cnt = count($objToReturn->_objDeptYearEventsAsRefrenceEventArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objDeptYearEventsAsRefrenceEventArray, $objToReturn->_objDeptYearEventsAsRefrenceEventArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objEventHasAttendentAsEventArray);
					$cnt = count($objToReturn->_objEventHasAttendentAsEventArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objEventHasAttendentAsEventArray, $objToReturn->_objEventHasAttendentAsEventArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objEventHasGradeArray);
					$cnt = count($objToReturn->_objEventHasGradeArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objEventHasGradeArray, $objToReturn->_objEventHasGradeArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objExampaperAsEventExamArray);
					$cnt = count($objToReturn->_objExampaperAsEventExamArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objExampaperAsEventExamArray, $objToReturn->_objExampaperAsEventExamArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objMeetingNotesAsMeetingArray);
					$cnt = count($objToReturn->_objMeetingNotesAsMeetingArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objMeetingNotesAsMeetingArray, $objToReturn->_objMeetingNotesAsMeetingArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objMemberDocAsMeetingArray);
					$cnt = count($objToReturn->_objMemberDocAsMeetingArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objMemberDocAsMeetingArray, $objToReturn->_objMemberDocAsMeetingArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'dept_year_events__';

			// Check for EventObject Early Binding
			$strAlias = $strAliasPrefix . 'event__idevent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objEventObject = Event::InstantiateDbRow($objDbRow, $strAliasPrefix . 'event__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DepartmentObject Early Binding
			$strAlias = $strAliasPrefix . 'department__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDepartmentObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'department__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DeptYearObject Early Binding
			$strAlias = $strAliasPrefix . 'dept_year__iddept_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDeptYearObject = DeptYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'dept_year__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for CalenderYearObject Early Binding
			$strAlias = $strAliasPrefix . 'calender_year__idcalender_year';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objCalenderYearObject = CalenderYear::InstantiateDbRow($objDbRow, $strAliasPrefix . 'calender_year__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ParrentObject Early Binding
			$strAlias = $strAliasPrefix . 'parrent__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objParrentObject = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'parrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ExamTypeObject Early Binding
			$strAlias = $strAliasPrefix . 'exam_type__idexam';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objExamTypeObject = Exam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'exam_type__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for YearlySubjectObject Early Binding
			$strAlias = $strAliasPrefix . 'yearly_subject__idyearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objYearlySubjectObject = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'yearly_subject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for RefrenceEventObject Early Binding
			$strAlias = $strAliasPrefix . 'refrence_event__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objRefrenceEventObject = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'refrence_event__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for IntiatorObject Early Binding
			$strAlias = $strAliasPrefix . 'intiator__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objIntiatorObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'intiator__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for OwnerObject Early Binding
			$strAlias = $strAliasPrefix . 'owner__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objOwnerObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'owner__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for AppliedExamAsEventSubject Virtual Binding
			$strAlias = $strAliasPrefix . 'appliedexamaseventsubject__idapplied_exam';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objAppliedExamAsEventSubjectArray)
				$objToReturn->_objAppliedExamAsEventSubjectArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objAppliedExamAsEventSubjectArray[] = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamaseventsubject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objAppliedExamAsEventSubject = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamaseventsubject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for AppliedExamAsEventExam Virtual Binding
			$strAlias = $strAliasPrefix . 'appliedexamaseventexam__idapplied_exam';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objAppliedExamAsEventExamArray)
				$objToReturn->_objAppliedExamAsEventExamArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objAppliedExamAsEventExamArray[] = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamaseventexam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objAppliedExamAsEventExam = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamaseventexam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for DeptYearEventsAsParrent Virtual Binding
			$strAlias = $strAliasPrefix . 'deptyeareventsasparrent__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objDeptYearEventsAsParrentArray)
				$objToReturn->_objDeptYearEventsAsParrentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objDeptYearEventsAsParrentArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objDeptYearEventsAsParrent = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for DeptYearEventsAsRefrenceEvent Virtual Binding
			$strAlias = $strAliasPrefix . 'deptyeareventsasrefrenceevent__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objDeptYearEventsAsRefrenceEventArray)
				$objToReturn->_objDeptYearEventsAsRefrenceEventArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objDeptYearEventsAsRefrenceEventArray[] = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasrefrenceevent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objDeptYearEventsAsRefrenceEvent = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'deptyeareventsasrefrenceevent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for EventHasAttendentAsEvent Virtual Binding
			$strAlias = $strAliasPrefix . 'eventhasattendentasevent__idevent_has_attendent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objEventHasAttendentAsEventArray)
				$objToReturn->_objEventHasAttendentAsEventArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objEventHasAttendentAsEventArray[] = EventHasAttendent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasattendentasevent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objEventHasAttendentAsEvent = EventHasAttendent::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasattendentasevent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for EventHasGrade Virtual Binding
			$strAlias = $strAliasPrefix . 'eventhasgrade__idevent_has_grade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objEventHasGradeArray)
				$objToReturn->_objEventHasGradeArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objEventHasGradeArray[] = EventHasGrade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasgrade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objEventHasGrade = EventHasGrade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasgrade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ExampaperAsEventExam Virtual Binding
			$strAlias = $strAliasPrefix . 'exampaperaseventexam__idexampaper';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objExampaperAsEventExamArray)
				$objToReturn->_objExampaperAsEventExamArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objExampaperAsEventExamArray[] = Exampaper::InstantiateDbRow($objDbRow, $strAliasPrefix . 'exampaperaseventexam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objExampaperAsEventExam = Exampaper::InstantiateDbRow($objDbRow, $strAliasPrefix . 'exampaperaseventexam__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for MeetingNotesAsMeeting Virtual Binding
			$strAlias = $strAliasPrefix . 'meetingnotesasmeeting__idmeeting_notes';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objMeetingNotesAsMeetingArray)
				$objToReturn->_objMeetingNotesAsMeetingArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objMeetingNotesAsMeetingArray[] = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasmeeting__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objMeetingNotesAsMeeting = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasmeeting__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for MemberDocAsMeeting Virtual Binding
			$strAlias = $strAliasPrefix . 'memberdocasmeeting__idmember_doc';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objMemberDocAsMeetingArray)
				$objToReturn->_objMemberDocAsMeetingArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objMemberDocAsMeetingArray[] = MemberDoc::InstantiateDbRow($objDbRow, $strAliasPrefix . 'memberdocasmeeting__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objMemberDocAsMeeting = MemberDoc::InstantiateDbRow($objDbRow, $strAliasPrefix . 'memberdocasmeeting__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of DeptYearEventses from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return DeptYearEvents[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = DeptYearEvents::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = DeptYearEvents::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single DeptYearEvents object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return DeptYearEvents next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return DeptYearEvents::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single DeptYearEvents object,
		 * by IddeptYearEvents Index(es)
		 * @param integer $intIddeptYearEvents
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents
		*/
		public static function LoadByIddeptYearEvents($intIddeptYearEvents, $objOptionalClauses = null) {
			return DeptYearEvents::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::DeptYearEvents()->IddeptYearEvents, $intIddeptYearEvents)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single DeptYearEvents object,
		 * by Title Index(es)
		 * @param string $strTitle
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents
		*/
		public static function LoadByTitle($strTitle, $objOptionalClauses = null) {
			return DeptYearEvents::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::DeptYearEvents()->Title, $strTitle)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of DeptYearEvents objects,
		 * by Event Index(es)
		 * @param integer $intEvent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public static function LoadArrayByEvent($intEvent, $objOptionalClauses = null) {
			// Call DeptYearEvents::QueryArray to perform the LoadArrayByEvent query
			try {
				return DeptYearEvents::QueryArray(
					QQ::Equal(QQN::DeptYearEvents()->Event, $intEvent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearEventses
		 * by Event Index(es)
		 * @param integer $intEvent
		 * @return int
		*/
		public static function CountByEvent($intEvent) {
			// Call DeptYearEvents::QueryCount to perform the CountByEvent query
			return DeptYearEvents::QueryCount(
				QQ::Equal(QQN::DeptYearEvents()->Event, $intEvent)
			);
		}

		/**
		 * Load an array of DeptYearEvents objects,
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public static function LoadArrayByDepartment($intDepartment, $objOptionalClauses = null) {
			// Call DeptYearEvents::QueryArray to perform the LoadArrayByDepartment query
			try {
				return DeptYearEvents::QueryArray(
					QQ::Equal(QQN::DeptYearEvents()->Department, $intDepartment),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearEventses
		 * by Department Index(es)
		 * @param integer $intDepartment
		 * @return int
		*/
		public static function CountByDepartment($intDepartment) {
			// Call DeptYearEvents::QueryCount to perform the CountByDepartment query
			return DeptYearEvents::QueryCount(
				QQ::Equal(QQN::DeptYearEvents()->Department, $intDepartment)
			);
		}

		/**
		 * Load an array of DeptYearEvents objects,
		 * by DeptYear Index(es)
		 * @param integer $intDeptYear
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public static function LoadArrayByDeptYear($intDeptYear, $objOptionalClauses = null) {
			// Call DeptYearEvents::QueryArray to perform the LoadArrayByDeptYear query
			try {
				return DeptYearEvents::QueryArray(
					QQ::Equal(QQN::DeptYearEvents()->DeptYear, $intDeptYear),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearEventses
		 * by DeptYear Index(es)
		 * @param integer $intDeptYear
		 * @return int
		*/
		public static function CountByDeptYear($intDeptYear) {
			// Call DeptYearEvents::QueryCount to perform the CountByDeptYear query
			return DeptYearEvents::QueryCount(
				QQ::Equal(QQN::DeptYearEvents()->DeptYear, $intDeptYear)
			);
		}

		/**
		 * Load an array of DeptYearEvents objects,
		 * by CalenderYear Index(es)
		 * @param integer $intCalenderYear
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public static function LoadArrayByCalenderYear($intCalenderYear, $objOptionalClauses = null) {
			// Call DeptYearEvents::QueryArray to perform the LoadArrayByCalenderYear query
			try {
				return DeptYearEvents::QueryArray(
					QQ::Equal(QQN::DeptYearEvents()->CalenderYear, $intCalenderYear),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearEventses
		 * by CalenderYear Index(es)
		 * @param integer $intCalenderYear
		 * @return int
		*/
		public static function CountByCalenderYear($intCalenderYear) {
			// Call DeptYearEvents::QueryCount to perform the CountByCalenderYear query
			return DeptYearEvents::QueryCount(
				QQ::Equal(QQN::DeptYearEvents()->CalenderYear, $intCalenderYear)
			);
		}

		/**
		 * Load an array of DeptYearEvents objects,
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public static function LoadArrayByParrent($intParrent, $objOptionalClauses = null) {
			// Call DeptYearEvents::QueryArray to perform the LoadArrayByParrent query
			try {
				return DeptYearEvents::QueryArray(
					QQ::Equal(QQN::DeptYearEvents()->Parrent, $intParrent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearEventses
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @return int
		*/
		public static function CountByParrent($intParrent) {
			// Call DeptYearEvents::QueryCount to perform the CountByParrent query
			return DeptYearEvents::QueryCount(
				QQ::Equal(QQN::DeptYearEvents()->Parrent, $intParrent)
			);
		}

		/**
		 * Load an array of DeptYearEvents objects,
		 * by YearlySubject Index(es)
		 * @param integer $intYearlySubject
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public static function LoadArrayByYearlySubject($intYearlySubject, $objOptionalClauses = null) {
			// Call DeptYearEvents::QueryArray to perform the LoadArrayByYearlySubject query
			try {
				return DeptYearEvents::QueryArray(
					QQ::Equal(QQN::DeptYearEvents()->YearlySubject, $intYearlySubject),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearEventses
		 * by YearlySubject Index(es)
		 * @param integer $intYearlySubject
		 * @return int
		*/
		public static function CountByYearlySubject($intYearlySubject) {
			// Call DeptYearEvents::QueryCount to perform the CountByYearlySubject query
			return DeptYearEvents::QueryCount(
				QQ::Equal(QQN::DeptYearEvents()->YearlySubject, $intYearlySubject)
			);
		}

		/**
		 * Load an array of DeptYearEvents objects,
		 * by ExamType Index(es)
		 * @param integer $intExamType
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public static function LoadArrayByExamType($intExamType, $objOptionalClauses = null) {
			// Call DeptYearEvents::QueryArray to perform the LoadArrayByExamType query
			try {
				return DeptYearEvents::QueryArray(
					QQ::Equal(QQN::DeptYearEvents()->ExamType, $intExamType),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearEventses
		 * by ExamType Index(es)
		 * @param integer $intExamType
		 * @return int
		*/
		public static function CountByExamType($intExamType) {
			// Call DeptYearEvents::QueryCount to perform the CountByExamType query
			return DeptYearEvents::QueryCount(
				QQ::Equal(QQN::DeptYearEvents()->ExamType, $intExamType)
			);
		}

		/**
		 * Load an array of DeptYearEvents objects,
		 * by RefrenceEvent Index(es)
		 * @param integer $intRefrenceEvent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public static function LoadArrayByRefrenceEvent($intRefrenceEvent, $objOptionalClauses = null) {
			// Call DeptYearEvents::QueryArray to perform the LoadArrayByRefrenceEvent query
			try {
				return DeptYearEvents::QueryArray(
					QQ::Equal(QQN::DeptYearEvents()->RefrenceEvent, $intRefrenceEvent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearEventses
		 * by RefrenceEvent Index(es)
		 * @param integer $intRefrenceEvent
		 * @return int
		*/
		public static function CountByRefrenceEvent($intRefrenceEvent) {
			// Call DeptYearEvents::QueryCount to perform the CountByRefrenceEvent query
			return DeptYearEvents::QueryCount(
				QQ::Equal(QQN::DeptYearEvents()->RefrenceEvent, $intRefrenceEvent)
			);
		}

		/**
		 * Load an array of DeptYearEvents objects,
		 * by Intiator Index(es)
		 * @param integer $intIntiator
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public static function LoadArrayByIntiator($intIntiator, $objOptionalClauses = null) {
			// Call DeptYearEvents::QueryArray to perform the LoadArrayByIntiator query
			try {
				return DeptYearEvents::QueryArray(
					QQ::Equal(QQN::DeptYearEvents()->Intiator, $intIntiator),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearEventses
		 * by Intiator Index(es)
		 * @param integer $intIntiator
		 * @return int
		*/
		public static function CountByIntiator($intIntiator) {
			// Call DeptYearEvents::QueryCount to perform the CountByIntiator query
			return DeptYearEvents::QueryCount(
				QQ::Equal(QQN::DeptYearEvents()->Intiator, $intIntiator)
			);
		}

		/**
		 * Load an array of DeptYearEvents objects,
		 * by Owner Index(es)
		 * @param integer $intOwner
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public static function LoadArrayByOwner($intOwner, $objOptionalClauses = null) {
			// Call DeptYearEvents::QueryArray to perform the LoadArrayByOwner query
			try {
				return DeptYearEvents::QueryArray(
					QQ::Equal(QQN::DeptYearEvents()->Owner, $intOwner),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count DeptYearEventses
		 * by Owner Index(es)
		 * @param integer $intOwner
		 * @return int
		*/
		public static function CountByOwner($intOwner) {
			// Call DeptYearEvents::QueryCount to perform the CountByOwner query
			return DeptYearEvents::QueryCount(
				QQ::Equal(QQN::DeptYearEvents()->Owner, $intOwner)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this DeptYearEvents
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `dept_year_events` (
							`title`,
							`event`,
							`department`,
							`dept_year`,
							`calender_year`,
							`parrent`,
							`from`,
							`to`,
							`description`,
							`exam_type`,
							`yearly_subject`,
							`refrence_event`,
							`mean`,
							`sd`,
							`intiator`,
							`owner`,
							`reason`,
							`code`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strTitle) . ',
							' . $objDatabase->SqlVariable($this->intEvent) . ',
							' . $objDatabase->SqlVariable($this->intDepartment) . ',
							' . $objDatabase->SqlVariable($this->intDeptYear) . ',
							' . $objDatabase->SqlVariable($this->intCalenderYear) . ',
							' . $objDatabase->SqlVariable($this->intParrent) . ',
							' . $objDatabase->SqlVariable($this->dttFrom) . ',
							' . $objDatabase->SqlVariable($this->dttTo) . ',
							' . $objDatabase->SqlVariable($this->strDescription) . ',
							' . $objDatabase->SqlVariable($this->intExamType) . ',
							' . $objDatabase->SqlVariable($this->intYearlySubject) . ',
							' . $objDatabase->SqlVariable($this->intRefrenceEvent) . ',
							' . $objDatabase->SqlVariable($this->strMean) . ',
							' . $objDatabase->SqlVariable($this->strSd) . ',
							' . $objDatabase->SqlVariable($this->intIntiator) . ',
							' . $objDatabase->SqlVariable($this->intOwner) . ',
							' . $objDatabase->SqlVariable($this->strReason) . ',
							' . $objDatabase->SqlVariable($this->strCode) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIddeptYearEvents = $objDatabase->InsertId('dept_year_events', 'iddept_year_events');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`dept_year_events`
						SET
							`title` = ' . $objDatabase->SqlVariable($this->strTitle) . ',
							`event` = ' . $objDatabase->SqlVariable($this->intEvent) . ',
							`department` = ' . $objDatabase->SqlVariable($this->intDepartment) . ',
							`dept_year` = ' . $objDatabase->SqlVariable($this->intDeptYear) . ',
							`calender_year` = ' . $objDatabase->SqlVariable($this->intCalenderYear) . ',
							`parrent` = ' . $objDatabase->SqlVariable($this->intParrent) . ',
							`from` = ' . $objDatabase->SqlVariable($this->dttFrom) . ',
							`to` = ' . $objDatabase->SqlVariable($this->dttTo) . ',
							`description` = ' . $objDatabase->SqlVariable($this->strDescription) . ',
							`exam_type` = ' . $objDatabase->SqlVariable($this->intExamType) . ',
							`yearly_subject` = ' . $objDatabase->SqlVariable($this->intYearlySubject) . ',
							`refrence_event` = ' . $objDatabase->SqlVariable($this->intRefrenceEvent) . ',
							`mean` = ' . $objDatabase->SqlVariable($this->strMean) . ',
							`sd` = ' . $objDatabase->SqlVariable($this->strSd) . ',
							`intiator` = ' . $objDatabase->SqlVariable($this->intIntiator) . ',
							`owner` = ' . $objDatabase->SqlVariable($this->intOwner) . ',
							`reason` = ' . $objDatabase->SqlVariable($this->strReason) . ',
							`code` = ' . $objDatabase->SqlVariable($this->strCode) . '
						WHERE
							`iddept_year_events` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this DeptYearEvents
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this DeptYearEvents with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this DeptYearEvents ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'DeptYearEvents', $this->intIddeptYearEvents);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all DeptYearEventses
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate dept_year_events table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `dept_year_events`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this DeptYearEvents from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved DeptYearEvents object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = DeptYearEvents::Load($this->intIddeptYearEvents);

			// Update $this's local variables to match
			$this->strTitle = $objReloaded->strTitle;
			$this->Event = $objReloaded->Event;
			$this->Department = $objReloaded->Department;
			$this->DeptYear = $objReloaded->DeptYear;
			$this->CalenderYear = $objReloaded->CalenderYear;
			$this->Parrent = $objReloaded->Parrent;
			$this->dttFrom = $objReloaded->dttFrom;
			$this->dttTo = $objReloaded->dttTo;
			$this->strDescription = $objReloaded->strDescription;
			$this->ExamType = $objReloaded->ExamType;
			$this->YearlySubject = $objReloaded->YearlySubject;
			$this->RefrenceEvent = $objReloaded->RefrenceEvent;
			$this->strMean = $objReloaded->strMean;
			$this->strSd = $objReloaded->strSd;
			$this->Intiator = $objReloaded->Intiator;
			$this->Owner = $objReloaded->Owner;
			$this->strReason = $objReloaded->strReason;
			$this->strCode = $objReloaded->strCode;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IddeptYearEvents':
					/**
					 * Gets the value for intIddeptYearEvents (Read-Only PK)
					 * @return integer
					 */
					return $this->intIddeptYearEvents;

				case 'Title':
					/**
					 * Gets the value for strTitle (Unique)
					 * @return string
					 */
					return $this->strTitle;

				case 'Event':
					/**
					 * Gets the value for intEvent (Not Null)
					 * @return integer
					 */
					return $this->intEvent;

				case 'Department':
					/**
					 * Gets the value for intDepartment 
					 * @return integer
					 */
					return $this->intDepartment;

				case 'DeptYear':
					/**
					 * Gets the value for intDeptYear 
					 * @return integer
					 */
					return $this->intDeptYear;

				case 'CalenderYear':
					/**
					 * Gets the value for intCalenderYear 
					 * @return integer
					 */
					return $this->intCalenderYear;

				case 'Parrent':
					/**
					 * Gets the value for intParrent 
					 * @return integer
					 */
					return $this->intParrent;

				case 'From':
					/**
					 * Gets the value for dttFrom (Not Null)
					 * @return QDateTime
					 */
					return $this->dttFrom;

				case 'To':
					/**
					 * Gets the value for dttTo (Not Null)
					 * @return QDateTime
					 */
					return $this->dttTo;

				case 'Description':
					/**
					 * Gets the value for strDescription 
					 * @return string
					 */
					return $this->strDescription;

				case 'ExamType':
					/**
					 * Gets the value for intExamType 
					 * @return integer
					 */
					return $this->intExamType;

				case 'YearlySubject':
					/**
					 * Gets the value for intYearlySubject 
					 * @return integer
					 */
					return $this->intYearlySubject;

				case 'RefrenceEvent':
					/**
					 * Gets the value for intRefrenceEvent 
					 * @return integer
					 */
					return $this->intRefrenceEvent;

				case 'Mean':
					/**
					 * Gets the value for strMean 
					 * @return string
					 */
					return $this->strMean;

				case 'Sd':
					/**
					 * Gets the value for strSd 
					 * @return string
					 */
					return $this->strSd;

				case 'Intiator':
					/**
					 * Gets the value for intIntiator 
					 * @return integer
					 */
					return $this->intIntiator;

				case 'Owner':
					/**
					 * Gets the value for intOwner 
					 * @return integer
					 */
					return $this->intOwner;

				case 'Reason':
					/**
					 * Gets the value for strReason 
					 * @return string
					 */
					return $this->strReason;

				case 'Code':
					/**
					 * Gets the value for strCode 
					 * @return string
					 */
					return $this->strCode;


				///////////////////
				// Member Objects
				///////////////////
				case 'EventObject':
					/**
					 * Gets the value for the Event object referenced by intEvent (Not Null)
					 * @return Event
					 */
					try {
						if ((!$this->objEventObject) && (!is_null($this->intEvent)))
							$this->objEventObject = Event::Load($this->intEvent);
						return $this->objEventObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DepartmentObject':
					/**
					 * Gets the value for the Role object referenced by intDepartment 
					 * @return Role
					 */
					try {
						if ((!$this->objDepartmentObject) && (!is_null($this->intDepartment)))
							$this->objDepartmentObject = Role::Load($this->intDepartment);
						return $this->objDepartmentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DeptYearObject':
					/**
					 * Gets the value for the DeptYear object referenced by intDeptYear 
					 * @return DeptYear
					 */
					try {
						if ((!$this->objDeptYearObject) && (!is_null($this->intDeptYear)))
							$this->objDeptYearObject = DeptYear::Load($this->intDeptYear);
						return $this->objDeptYearObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CalenderYearObject':
					/**
					 * Gets the value for the CalenderYear object referenced by intCalenderYear 
					 * @return CalenderYear
					 */
					try {
						if ((!$this->objCalenderYearObject) && (!is_null($this->intCalenderYear)))
							$this->objCalenderYearObject = CalenderYear::Load($this->intCalenderYear);
						return $this->objCalenderYearObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ParrentObject':
					/**
					 * Gets the value for the DeptYearEvents object referenced by intParrent 
					 * @return DeptYearEvents
					 */
					try {
						if ((!$this->objParrentObject) && (!is_null($this->intParrent)))
							$this->objParrentObject = DeptYearEvents::Load($this->intParrent);
						return $this->objParrentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ExamTypeObject':
					/**
					 * Gets the value for the Exam object referenced by intExamType 
					 * @return Exam
					 */
					try {
						if ((!$this->objExamTypeObject) && (!is_null($this->intExamType)))
							$this->objExamTypeObject = Exam::Load($this->intExamType);
						return $this->objExamTypeObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'YearlySubjectObject':
					/**
					 * Gets the value for the YearlySubject object referenced by intYearlySubject 
					 * @return YearlySubject
					 */
					try {
						if ((!$this->objYearlySubjectObject) && (!is_null($this->intYearlySubject)))
							$this->objYearlySubjectObject = YearlySubject::Load($this->intYearlySubject);
						return $this->objYearlySubjectObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RefrenceEventObject':
					/**
					 * Gets the value for the DeptYearEvents object referenced by intRefrenceEvent 
					 * @return DeptYearEvents
					 */
					try {
						if ((!$this->objRefrenceEventObject) && (!is_null($this->intRefrenceEvent)))
							$this->objRefrenceEventObject = DeptYearEvents::Load($this->intRefrenceEvent);
						return $this->objRefrenceEventObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'IntiatorObject':
					/**
					 * Gets the value for the Login object referenced by intIntiator 
					 * @return Login
					 */
					try {
						if ((!$this->objIntiatorObject) && (!is_null($this->intIntiator)))
							$this->objIntiatorObject = Login::Load($this->intIntiator);
						return $this->objIntiatorObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'OwnerObject':
					/**
					 * Gets the value for the Login object referenced by intOwner 
					 * @return Login
					 */
					try {
						if ((!$this->objOwnerObject) && (!is_null($this->intOwner)))
							$this->objOwnerObject = Login::Load($this->intOwner);
						return $this->objOwnerObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_AppliedExamAsEventSubject':
					/**
					 * Gets the value for the private _objAppliedExamAsEventSubject (Read-Only)
					 * if set due to an expansion on the applied_exam.event_subject reverse relationship
					 * @return AppliedExam
					 */
					return $this->_objAppliedExamAsEventSubject;

				case '_AppliedExamAsEventSubjectArray':
					/**
					 * Gets the value for the private _objAppliedExamAsEventSubjectArray (Read-Only)
					 * if set due to an ExpandAsArray on the applied_exam.event_subject reverse relationship
					 * @return AppliedExam[]
					 */
					return $this->_objAppliedExamAsEventSubjectArray;

				case '_AppliedExamAsEventExam':
					/**
					 * Gets the value for the private _objAppliedExamAsEventExam (Read-Only)
					 * if set due to an expansion on the applied_exam.event_exam reverse relationship
					 * @return AppliedExam
					 */
					return $this->_objAppliedExamAsEventExam;

				case '_AppliedExamAsEventExamArray':
					/**
					 * Gets the value for the private _objAppliedExamAsEventExamArray (Read-Only)
					 * if set due to an ExpandAsArray on the applied_exam.event_exam reverse relationship
					 * @return AppliedExam[]
					 */
					return $this->_objAppliedExamAsEventExamArray;

				case '_DeptYearEventsAsParrent':
					/**
					 * Gets the value for the private _objDeptYearEventsAsParrent (Read-Only)
					 * if set due to an expansion on the dept_year_events.parrent reverse relationship
					 * @return DeptYearEvents
					 */
					return $this->_objDeptYearEventsAsParrent;

				case '_DeptYearEventsAsParrentArray':
					/**
					 * Gets the value for the private _objDeptYearEventsAsParrentArray (Read-Only)
					 * if set due to an ExpandAsArray on the dept_year_events.parrent reverse relationship
					 * @return DeptYearEvents[]
					 */
					return $this->_objDeptYearEventsAsParrentArray;

				case '_DeptYearEventsAsRefrenceEvent':
					/**
					 * Gets the value for the private _objDeptYearEventsAsRefrenceEvent (Read-Only)
					 * if set due to an expansion on the dept_year_events.refrence_event reverse relationship
					 * @return DeptYearEvents
					 */
					return $this->_objDeptYearEventsAsRefrenceEvent;

				case '_DeptYearEventsAsRefrenceEventArray':
					/**
					 * Gets the value for the private _objDeptYearEventsAsRefrenceEventArray (Read-Only)
					 * if set due to an ExpandAsArray on the dept_year_events.refrence_event reverse relationship
					 * @return DeptYearEvents[]
					 */
					return $this->_objDeptYearEventsAsRefrenceEventArray;

				case '_EventHasAttendentAsEvent':
					/**
					 * Gets the value for the private _objEventHasAttendentAsEvent (Read-Only)
					 * if set due to an expansion on the event_has_attendent.event reverse relationship
					 * @return EventHasAttendent
					 */
					return $this->_objEventHasAttendentAsEvent;

				case '_EventHasAttendentAsEventArray':
					/**
					 * Gets the value for the private _objEventHasAttendentAsEventArray (Read-Only)
					 * if set due to an ExpandAsArray on the event_has_attendent.event reverse relationship
					 * @return EventHasAttendent[]
					 */
					return $this->_objEventHasAttendentAsEventArray;

				case '_EventHasGrade':
					/**
					 * Gets the value for the private _objEventHasGrade (Read-Only)
					 * if set due to an expansion on the event_has_grade.dept_year_events reverse relationship
					 * @return EventHasGrade
					 */
					return $this->_objEventHasGrade;

				case '_EventHasGradeArray':
					/**
					 * Gets the value for the private _objEventHasGradeArray (Read-Only)
					 * if set due to an ExpandAsArray on the event_has_grade.dept_year_events reverse relationship
					 * @return EventHasGrade[]
					 */
					return $this->_objEventHasGradeArray;

				case '_ExampaperAsEventExam':
					/**
					 * Gets the value for the private _objExampaperAsEventExam (Read-Only)
					 * if set due to an expansion on the exampaper.event_exam reverse relationship
					 * @return Exampaper
					 */
					return $this->_objExampaperAsEventExam;

				case '_ExampaperAsEventExamArray':
					/**
					 * Gets the value for the private _objExampaperAsEventExamArray (Read-Only)
					 * if set due to an ExpandAsArray on the exampaper.event_exam reverse relationship
					 * @return Exampaper[]
					 */
					return $this->_objExampaperAsEventExamArray;

				case '_MeetingNotesAsMeeting':
					/**
					 * Gets the value for the private _objMeetingNotesAsMeeting (Read-Only)
					 * if set due to an expansion on the meeting_notes.meeting reverse relationship
					 * @return MeetingNotes
					 */
					return $this->_objMeetingNotesAsMeeting;

				case '_MeetingNotesAsMeetingArray':
					/**
					 * Gets the value for the private _objMeetingNotesAsMeetingArray (Read-Only)
					 * if set due to an ExpandAsArray on the meeting_notes.meeting reverse relationship
					 * @return MeetingNotes[]
					 */
					return $this->_objMeetingNotesAsMeetingArray;

				case '_MemberDocAsMeeting':
					/**
					 * Gets the value for the private _objMemberDocAsMeeting (Read-Only)
					 * if set due to an expansion on the member_doc.meeting reverse relationship
					 * @return MemberDoc
					 */
					return $this->_objMemberDocAsMeeting;

				case '_MemberDocAsMeetingArray':
					/**
					 * Gets the value for the private _objMemberDocAsMeetingArray (Read-Only)
					 * if set due to an ExpandAsArray on the member_doc.meeting reverse relationship
					 * @return MemberDoc[]
					 */
					return $this->_objMemberDocAsMeetingArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Title':
					/**
					 * Sets the value for strTitle (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTitle = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Event':
					/**
					 * Sets the value for intEvent (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objEventObject = null;
						return ($this->intEvent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Department':
					/**
					 * Sets the value for intDepartment 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDepartmentObject = null;
						return ($this->intDepartment = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DeptYear':
					/**
					 * Sets the value for intDeptYear 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDeptYearObject = null;
						return ($this->intDeptYear = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'CalenderYear':
					/**
					 * Sets the value for intCalenderYear 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objCalenderYearObject = null;
						return ($this->intCalenderYear = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Parrent':
					/**
					 * Sets the value for intParrent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objParrentObject = null;
						return ($this->intParrent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'From':
					/**
					 * Sets the value for dttFrom (Not Null)
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttFrom = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'To':
					/**
					 * Sets the value for dttTo (Not Null)
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttTo = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Description':
					/**
					 * Sets the value for strDescription 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strDescription = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ExamType':
					/**
					 * Sets the value for intExamType 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objExamTypeObject = null;
						return ($this->intExamType = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'YearlySubject':
					/**
					 * Sets the value for intYearlySubject 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objYearlySubjectObject = null;
						return ($this->intYearlySubject = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RefrenceEvent':
					/**
					 * Sets the value for intRefrenceEvent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objRefrenceEventObject = null;
						return ($this->intRefrenceEvent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Mean':
					/**
					 * Sets the value for strMean 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strMean = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Sd':
					/**
					 * Sets the value for strSd 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strSd = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Intiator':
					/**
					 * Sets the value for intIntiator 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objIntiatorObject = null;
						return ($this->intIntiator = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Owner':
					/**
					 * Sets the value for intOwner 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objOwnerObject = null;
						return ($this->intOwner = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Reason':
					/**
					 * Sets the value for strReason 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strReason = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Code':
					/**
					 * Sets the value for strCode 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'EventObject':
					/**
					 * Sets the value for the Event object referenced by intEvent (Not Null)
					 * @param Event $mixValue
					 * @return Event
					 */
					if (is_null($mixValue)) {
						$this->intEvent = null;
						$this->objEventObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Event object
						try {
							$mixValue = QType::Cast($mixValue, 'Event');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Event object
						if (is_null($mixValue->Idevent))
							throw new QCallerException('Unable to set an unsaved EventObject for this DeptYearEvents');

						// Update Local Member Variables
						$this->objEventObject = $mixValue;
						$this->intEvent = $mixValue->Idevent;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DepartmentObject':
					/**
					 * Sets the value for the Role object referenced by intDepartment 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intDepartment = null;
						$this->objDepartmentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved DepartmentObject for this DeptYearEvents');

						// Update Local Member Variables
						$this->objDepartmentObject = $mixValue;
						$this->intDepartment = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DeptYearObject':
					/**
					 * Sets the value for the DeptYear object referenced by intDeptYear 
					 * @param DeptYear $mixValue
					 * @return DeptYear
					 */
					if (is_null($mixValue)) {
						$this->intDeptYear = null;
						$this->objDeptYearObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a DeptYear object
						try {
							$mixValue = QType::Cast($mixValue, 'DeptYear');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED DeptYear object
						if (is_null($mixValue->IddeptYear))
							throw new QCallerException('Unable to set an unsaved DeptYearObject for this DeptYearEvents');

						// Update Local Member Variables
						$this->objDeptYearObject = $mixValue;
						$this->intDeptYear = $mixValue->IddeptYear;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'CalenderYearObject':
					/**
					 * Sets the value for the CalenderYear object referenced by intCalenderYear 
					 * @param CalenderYear $mixValue
					 * @return CalenderYear
					 */
					if (is_null($mixValue)) {
						$this->intCalenderYear = null;
						$this->objCalenderYearObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a CalenderYear object
						try {
							$mixValue = QType::Cast($mixValue, 'CalenderYear');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED CalenderYear object
						if (is_null($mixValue->IdcalenderYear))
							throw new QCallerException('Unable to set an unsaved CalenderYearObject for this DeptYearEvents');

						// Update Local Member Variables
						$this->objCalenderYearObject = $mixValue;
						$this->intCalenderYear = $mixValue->IdcalenderYear;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ParrentObject':
					/**
					 * Sets the value for the DeptYearEvents object referenced by intParrent 
					 * @param DeptYearEvents $mixValue
					 * @return DeptYearEvents
					 */
					if (is_null($mixValue)) {
						$this->intParrent = null;
						$this->objParrentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a DeptYearEvents object
						try {
							$mixValue = QType::Cast($mixValue, 'DeptYearEvents');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED DeptYearEvents object
						if (is_null($mixValue->IddeptYearEvents))
							throw new QCallerException('Unable to set an unsaved ParrentObject for this DeptYearEvents');

						// Update Local Member Variables
						$this->objParrentObject = $mixValue;
						$this->intParrent = $mixValue->IddeptYearEvents;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ExamTypeObject':
					/**
					 * Sets the value for the Exam object referenced by intExamType 
					 * @param Exam $mixValue
					 * @return Exam
					 */
					if (is_null($mixValue)) {
						$this->intExamType = null;
						$this->objExamTypeObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Exam object
						try {
							$mixValue = QType::Cast($mixValue, 'Exam');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Exam object
						if (is_null($mixValue->Idexam))
							throw new QCallerException('Unable to set an unsaved ExamTypeObject for this DeptYearEvents');

						// Update Local Member Variables
						$this->objExamTypeObject = $mixValue;
						$this->intExamType = $mixValue->Idexam;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'YearlySubjectObject':
					/**
					 * Sets the value for the YearlySubject object referenced by intYearlySubject 
					 * @param YearlySubject $mixValue
					 * @return YearlySubject
					 */
					if (is_null($mixValue)) {
						$this->intYearlySubject = null;
						$this->objYearlySubjectObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a YearlySubject object
						try {
							$mixValue = QType::Cast($mixValue, 'YearlySubject');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED YearlySubject object
						if (is_null($mixValue->IdyearlySubject))
							throw new QCallerException('Unable to set an unsaved YearlySubjectObject for this DeptYearEvents');

						// Update Local Member Variables
						$this->objYearlySubjectObject = $mixValue;
						$this->intYearlySubject = $mixValue->IdyearlySubject;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'RefrenceEventObject':
					/**
					 * Sets the value for the DeptYearEvents object referenced by intRefrenceEvent 
					 * @param DeptYearEvents $mixValue
					 * @return DeptYearEvents
					 */
					if (is_null($mixValue)) {
						$this->intRefrenceEvent = null;
						$this->objRefrenceEventObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a DeptYearEvents object
						try {
							$mixValue = QType::Cast($mixValue, 'DeptYearEvents');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED DeptYearEvents object
						if (is_null($mixValue->IddeptYearEvents))
							throw new QCallerException('Unable to set an unsaved RefrenceEventObject for this DeptYearEvents');

						// Update Local Member Variables
						$this->objRefrenceEventObject = $mixValue;
						$this->intRefrenceEvent = $mixValue->IddeptYearEvents;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'IntiatorObject':
					/**
					 * Sets the value for the Login object referenced by intIntiator 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intIntiator = null;
						$this->objIntiatorObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved IntiatorObject for this DeptYearEvents');

						// Update Local Member Variables
						$this->objIntiatorObject = $mixValue;
						$this->intIntiator = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'OwnerObject':
					/**
					 * Sets the value for the Login object referenced by intOwner 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intOwner = null;
						$this->objOwnerObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved OwnerObject for this DeptYearEvents');

						// Update Local Member Variables
						$this->objOwnerObject = $mixValue;
						$this->intOwner = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for AppliedExamAsEventSubject
		//-------------------------------------------------------------------

		/**
		 * Gets all associated AppliedExamsAsEventSubject as an array of AppliedExam objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppliedExam[]
		*/
		public function GetAppliedExamAsEventSubjectArray($objOptionalClauses = null) {
			if ((is_null($this->intIddeptYearEvents)))
				return array();

			try {
				return AppliedExam::LoadArrayByEventSubject($this->intIddeptYearEvents, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated AppliedExamsAsEventSubject
		 * @return int
		*/
		public function CountAppliedExamsAsEventSubject() {
			if ((is_null($this->intIddeptYearEvents)))
				return 0;

			return AppliedExam::CountByEventSubject($this->intIddeptYearEvents);
		}

		/**
		 * Associates a AppliedExamAsEventSubject
		 * @param AppliedExam $objAppliedExam
		 * @return void
		*/
		public function AssociateAppliedExamAsEventSubject(AppliedExam $objAppliedExam) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppliedExamAsEventSubject on this unsaved DeptYearEvents.');
			if ((is_null($objAppliedExam->IdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppliedExamAsEventSubject on this DeptYearEvents with an unsaved AppliedExam.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`applied_exam`
				SET
					`event_subject` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($objAppliedExam->IdappliedExam) . '
			');
		}

		/**
		 * Unassociates a AppliedExamAsEventSubject
		 * @param AppliedExam $objAppliedExam
		 * @return void
		*/
		public function UnassociateAppliedExamAsEventSubject(AppliedExam $objAppliedExam) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsEventSubject on this unsaved DeptYearEvents.');
			if ((is_null($objAppliedExam->IdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsEventSubject on this DeptYearEvents with an unsaved AppliedExam.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`applied_exam`
				SET
					`event_subject` = null
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($objAppliedExam->IdappliedExam) . ' AND
					`event_subject` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates all AppliedExamsAsEventSubject
		 * @return void
		*/
		public function UnassociateAllAppliedExamsAsEventSubject() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsEventSubject on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`applied_exam`
				SET
					`event_subject` = null
				WHERE
					`event_subject` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes an associated AppliedExamAsEventSubject
		 * @param AppliedExam $objAppliedExam
		 * @return void
		*/
		public function DeleteAssociatedAppliedExamAsEventSubject(AppliedExam $objAppliedExam) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsEventSubject on this unsaved DeptYearEvents.');
			if ((is_null($objAppliedExam->IdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsEventSubject on this DeptYearEvents with an unsaved AppliedExam.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`applied_exam`
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($objAppliedExam->IdappliedExam) . ' AND
					`event_subject` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes all associated AppliedExamsAsEventSubject
		 * @return void
		*/
		public function DeleteAllAppliedExamsAsEventSubject() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsEventSubject on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`applied_exam`
				WHERE
					`event_subject` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}


		// Related Objects' Methods for AppliedExamAsEventExam
		//-------------------------------------------------------------------

		/**
		 * Gets all associated AppliedExamsAsEventExam as an array of AppliedExam objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppliedExam[]
		*/
		public function GetAppliedExamAsEventExamArray($objOptionalClauses = null) {
			if ((is_null($this->intIddeptYearEvents)))
				return array();

			try {
				return AppliedExam::LoadArrayByEventExam($this->intIddeptYearEvents, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated AppliedExamsAsEventExam
		 * @return int
		*/
		public function CountAppliedExamsAsEventExam() {
			if ((is_null($this->intIddeptYearEvents)))
				return 0;

			return AppliedExam::CountByEventExam($this->intIddeptYearEvents);
		}

		/**
		 * Associates a AppliedExamAsEventExam
		 * @param AppliedExam $objAppliedExam
		 * @return void
		*/
		public function AssociateAppliedExamAsEventExam(AppliedExam $objAppliedExam) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppliedExamAsEventExam on this unsaved DeptYearEvents.');
			if ((is_null($objAppliedExam->IdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppliedExamAsEventExam on this DeptYearEvents with an unsaved AppliedExam.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`applied_exam`
				SET
					`event_exam` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($objAppliedExam->IdappliedExam) . '
			');
		}

		/**
		 * Unassociates a AppliedExamAsEventExam
		 * @param AppliedExam $objAppliedExam
		 * @return void
		*/
		public function UnassociateAppliedExamAsEventExam(AppliedExam $objAppliedExam) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsEventExam on this unsaved DeptYearEvents.');
			if ((is_null($objAppliedExam->IdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsEventExam on this DeptYearEvents with an unsaved AppliedExam.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`applied_exam`
				SET
					`event_exam` = null
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($objAppliedExam->IdappliedExam) . ' AND
					`event_exam` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates all AppliedExamsAsEventExam
		 * @return void
		*/
		public function UnassociateAllAppliedExamsAsEventExam() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsEventExam on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`applied_exam`
				SET
					`event_exam` = null
				WHERE
					`event_exam` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes an associated AppliedExamAsEventExam
		 * @param AppliedExam $objAppliedExam
		 * @return void
		*/
		public function DeleteAssociatedAppliedExamAsEventExam(AppliedExam $objAppliedExam) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsEventExam on this unsaved DeptYearEvents.');
			if ((is_null($objAppliedExam->IdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsEventExam on this DeptYearEvents with an unsaved AppliedExam.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`applied_exam`
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($objAppliedExam->IdappliedExam) . ' AND
					`event_exam` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes all associated AppliedExamsAsEventExam
		 * @return void
		*/
		public function DeleteAllAppliedExamsAsEventExam() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsEventExam on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`applied_exam`
				WHERE
					`event_exam` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}


		// Related Objects' Methods for DeptYearEventsAsParrent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated DeptYearEventsesAsParrent as an array of DeptYearEvents objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public function GetDeptYearEventsAsParrentArray($objOptionalClauses = null) {
			if ((is_null($this->intIddeptYearEvents)))
				return array();

			try {
				return DeptYearEvents::LoadArrayByParrent($this->intIddeptYearEvents, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated DeptYearEventsesAsParrent
		 * @return int
		*/
		public function CountDeptYearEventsesAsParrent() {
			if ((is_null($this->intIddeptYearEvents)))
				return 0;

			return DeptYearEvents::CountByParrent($this->intIddeptYearEvents);
		}

		/**
		 * Associates a DeptYearEventsAsParrent
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function AssociateDeptYearEventsAsParrent(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEventsAsParrent on this unsaved DeptYearEvents.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEventsAsParrent on this DeptYearEvents with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`parrent` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates a DeptYearEventsAsParrent
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function UnassociateDeptYearEventsAsParrent(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsParrent on this unsaved DeptYearEvents.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsParrent on this DeptYearEvents with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`parrent` = null
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates all DeptYearEventsesAsParrent
		 * @return void
		*/
		public function UnassociateAllDeptYearEventsesAsParrent() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsParrent on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`parrent` = null
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes an associated DeptYearEventsAsParrent
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function DeleteAssociatedDeptYearEventsAsParrent(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsParrent on this unsaved DeptYearEvents.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsParrent on this DeptYearEvents with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes all associated DeptYearEventsesAsParrent
		 * @return void
		*/
		public function DeleteAllDeptYearEventsesAsParrent() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsParrent on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}


		// Related Objects' Methods for DeptYearEventsAsRefrenceEvent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated DeptYearEventsesAsRefrenceEvent as an array of DeptYearEvents objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return DeptYearEvents[]
		*/
		public function GetDeptYearEventsAsRefrenceEventArray($objOptionalClauses = null) {
			if ((is_null($this->intIddeptYearEvents)))
				return array();

			try {
				return DeptYearEvents::LoadArrayByRefrenceEvent($this->intIddeptYearEvents, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated DeptYearEventsesAsRefrenceEvent
		 * @return int
		*/
		public function CountDeptYearEventsesAsRefrenceEvent() {
			if ((is_null($this->intIddeptYearEvents)))
				return 0;

			return DeptYearEvents::CountByRefrenceEvent($this->intIddeptYearEvents);
		}

		/**
		 * Associates a DeptYearEventsAsRefrenceEvent
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function AssociateDeptYearEventsAsRefrenceEvent(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEventsAsRefrenceEvent on this unsaved DeptYearEvents.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateDeptYearEventsAsRefrenceEvent on this DeptYearEvents with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`refrence_event` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates a DeptYearEventsAsRefrenceEvent
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function UnassociateDeptYearEventsAsRefrenceEvent(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsRefrenceEvent on this unsaved DeptYearEvents.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsRefrenceEvent on this DeptYearEvents with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`refrence_event` = null
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`refrence_event` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates all DeptYearEventsesAsRefrenceEvent
		 * @return void
		*/
		public function UnassociateAllDeptYearEventsesAsRefrenceEvent() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsRefrenceEvent on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`dept_year_events`
				SET
					`refrence_event` = null
				WHERE
					`refrence_event` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes an associated DeptYearEventsAsRefrenceEvent
		 * @param DeptYearEvents $objDeptYearEvents
		 * @return void
		*/
		public function DeleteAssociatedDeptYearEventsAsRefrenceEvent(DeptYearEvents $objDeptYearEvents) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsRefrenceEvent on this unsaved DeptYearEvents.');
			if ((is_null($objDeptYearEvents->IddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsRefrenceEvent on this DeptYearEvents with an unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`iddept_year_events` = ' . $objDatabase->SqlVariable($objDeptYearEvents->IddeptYearEvents) . ' AND
					`refrence_event` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes all associated DeptYearEventsesAsRefrenceEvent
		 * @return void
		*/
		public function DeleteAllDeptYearEventsesAsRefrenceEvent() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateDeptYearEventsAsRefrenceEvent on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`dept_year_events`
				WHERE
					`refrence_event` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}


		// Related Objects' Methods for EventHasAttendentAsEvent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated EventHasAttendentsAsEvent as an array of EventHasAttendent objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EventHasAttendent[]
		*/
		public function GetEventHasAttendentAsEventArray($objOptionalClauses = null) {
			if ((is_null($this->intIddeptYearEvents)))
				return array();

			try {
				return EventHasAttendent::LoadArrayByEvent($this->intIddeptYearEvents, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated EventHasAttendentsAsEvent
		 * @return int
		*/
		public function CountEventHasAttendentsAsEvent() {
			if ((is_null($this->intIddeptYearEvents)))
				return 0;

			return EventHasAttendent::CountByEvent($this->intIddeptYearEvents);
		}

		/**
		 * Associates a EventHasAttendentAsEvent
		 * @param EventHasAttendent $objEventHasAttendent
		 * @return void
		*/
		public function AssociateEventHasAttendentAsEvent(EventHasAttendent $objEventHasAttendent) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEventHasAttendentAsEvent on this unsaved DeptYearEvents.');
			if ((is_null($objEventHasAttendent->IdeventHasAttendent)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEventHasAttendentAsEvent on this DeptYearEvents with an unsaved EventHasAttendent.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event_has_attendent`
				SET
					`event` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
				WHERE
					`idevent_has_attendent` = ' . $objDatabase->SqlVariable($objEventHasAttendent->IdeventHasAttendent) . '
			');
		}

		/**
		 * Unassociates a EventHasAttendentAsEvent
		 * @param EventHasAttendent $objEventHasAttendent
		 * @return void
		*/
		public function UnassociateEventHasAttendentAsEvent(EventHasAttendent $objEventHasAttendent) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasAttendentAsEvent on this unsaved DeptYearEvents.');
			if ((is_null($objEventHasAttendent->IdeventHasAttendent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasAttendentAsEvent on this DeptYearEvents with an unsaved EventHasAttendent.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event_has_attendent`
				SET
					`event` = null
				WHERE
					`idevent_has_attendent` = ' . $objDatabase->SqlVariable($objEventHasAttendent->IdeventHasAttendent) . ' AND
					`event` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates all EventHasAttendentsAsEvent
		 * @return void
		*/
		public function UnassociateAllEventHasAttendentsAsEvent() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasAttendentAsEvent on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event_has_attendent`
				SET
					`event` = null
				WHERE
					`event` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes an associated EventHasAttendentAsEvent
		 * @param EventHasAttendent $objEventHasAttendent
		 * @return void
		*/
		public function DeleteAssociatedEventHasAttendentAsEvent(EventHasAttendent $objEventHasAttendent) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasAttendentAsEvent on this unsaved DeptYearEvents.');
			if ((is_null($objEventHasAttendent->IdeventHasAttendent)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasAttendentAsEvent on this DeptYearEvents with an unsaved EventHasAttendent.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event_has_attendent`
				WHERE
					`idevent_has_attendent` = ' . $objDatabase->SqlVariable($objEventHasAttendent->IdeventHasAttendent) . ' AND
					`event` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes all associated EventHasAttendentsAsEvent
		 * @return void
		*/
		public function DeleteAllEventHasAttendentsAsEvent() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasAttendentAsEvent on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event_has_attendent`
				WHERE
					`event` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}


		// Related Objects' Methods for EventHasGrade
		//-------------------------------------------------------------------

		/**
		 * Gets all associated EventHasGrades as an array of EventHasGrade objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EventHasGrade[]
		*/
		public function GetEventHasGradeArray($objOptionalClauses = null) {
			if ((is_null($this->intIddeptYearEvents)))
				return array();

			try {
				return EventHasGrade::LoadArrayByDeptYearEvents($this->intIddeptYearEvents, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated EventHasGrades
		 * @return int
		*/
		public function CountEventHasGrades() {
			if ((is_null($this->intIddeptYearEvents)))
				return 0;

			return EventHasGrade::CountByDeptYearEvents($this->intIddeptYearEvents);
		}

		/**
		 * Associates a EventHasGrade
		 * @param EventHasGrade $objEventHasGrade
		 * @return void
		*/
		public function AssociateEventHasGrade(EventHasGrade $objEventHasGrade) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEventHasGrade on this unsaved DeptYearEvents.');
			if ((is_null($objEventHasGrade->IdeventHasGrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEventHasGrade on this DeptYearEvents with an unsaved EventHasGrade.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event_has_grade`
				SET
					`dept_year_events` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
				WHERE
					`idevent_has_grade` = ' . $objDatabase->SqlVariable($objEventHasGrade->IdeventHasGrade) . '
			');
		}

		/**
		 * Unassociates a EventHasGrade
		 * @param EventHasGrade $objEventHasGrade
		 * @return void
		*/
		public function UnassociateEventHasGrade(EventHasGrade $objEventHasGrade) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this unsaved DeptYearEvents.');
			if ((is_null($objEventHasGrade->IdeventHasGrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this DeptYearEvents with an unsaved EventHasGrade.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event_has_grade`
				SET
					`dept_year_events` = null
				WHERE
					`idevent_has_grade` = ' . $objDatabase->SqlVariable($objEventHasGrade->IdeventHasGrade) . ' AND
					`dept_year_events` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates all EventHasGrades
		 * @return void
		*/
		public function UnassociateAllEventHasGrades() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event_has_grade`
				SET
					`dept_year_events` = null
				WHERE
					`dept_year_events` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes an associated EventHasGrade
		 * @param EventHasGrade $objEventHasGrade
		 * @return void
		*/
		public function DeleteAssociatedEventHasGrade(EventHasGrade $objEventHasGrade) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this unsaved DeptYearEvents.');
			if ((is_null($objEventHasGrade->IdeventHasGrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this DeptYearEvents with an unsaved EventHasGrade.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event_has_grade`
				WHERE
					`idevent_has_grade` = ' . $objDatabase->SqlVariable($objEventHasGrade->IdeventHasGrade) . ' AND
					`dept_year_events` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes all associated EventHasGrades
		 * @return void
		*/
		public function DeleteAllEventHasGrades() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event_has_grade`
				WHERE
					`dept_year_events` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}


		// Related Objects' Methods for ExampaperAsEventExam
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ExampapersAsEventExam as an array of Exampaper objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Exampaper[]
		*/
		public function GetExampaperAsEventExamArray($objOptionalClauses = null) {
			if ((is_null($this->intIddeptYearEvents)))
				return array();

			try {
				return Exampaper::LoadArrayByEventExam($this->intIddeptYearEvents, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ExampapersAsEventExam
		 * @return int
		*/
		public function CountExampapersAsEventExam() {
			if ((is_null($this->intIddeptYearEvents)))
				return 0;

			return Exampaper::CountByEventExam($this->intIddeptYearEvents);
		}

		/**
		 * Associates a ExampaperAsEventExam
		 * @param Exampaper $objExampaper
		 * @return void
		*/
		public function AssociateExampaperAsEventExam(Exampaper $objExampaper) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateExampaperAsEventExam on this unsaved DeptYearEvents.');
			if ((is_null($objExampaper->Idexampaper)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateExampaperAsEventExam on this DeptYearEvents with an unsaved Exampaper.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`exampaper`
				SET
					`event_exam` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
				WHERE
					`idexampaper` = ' . $objDatabase->SqlVariable($objExampaper->Idexampaper) . '
			');
		}

		/**
		 * Unassociates a ExampaperAsEventExam
		 * @param Exampaper $objExampaper
		 * @return void
		*/
		public function UnassociateExampaperAsEventExam(Exampaper $objExampaper) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExampaperAsEventExam on this unsaved DeptYearEvents.');
			if ((is_null($objExampaper->Idexampaper)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExampaperAsEventExam on this DeptYearEvents with an unsaved Exampaper.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`exampaper`
				SET
					`event_exam` = null
				WHERE
					`idexampaper` = ' . $objDatabase->SqlVariable($objExampaper->Idexampaper) . ' AND
					`event_exam` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates all ExampapersAsEventExam
		 * @return void
		*/
		public function UnassociateAllExampapersAsEventExam() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExampaperAsEventExam on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`exampaper`
				SET
					`event_exam` = null
				WHERE
					`event_exam` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes an associated ExampaperAsEventExam
		 * @param Exampaper $objExampaper
		 * @return void
		*/
		public function DeleteAssociatedExampaperAsEventExam(Exampaper $objExampaper) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExampaperAsEventExam on this unsaved DeptYearEvents.');
			if ((is_null($objExampaper->Idexampaper)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExampaperAsEventExam on this DeptYearEvents with an unsaved Exampaper.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`exampaper`
				WHERE
					`idexampaper` = ' . $objDatabase->SqlVariable($objExampaper->Idexampaper) . ' AND
					`event_exam` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes all associated ExampapersAsEventExam
		 * @return void
		*/
		public function DeleteAllExampapersAsEventExam() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateExampaperAsEventExam on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`exampaper`
				WHERE
					`event_exam` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}


		// Related Objects' Methods for MeetingNotesAsMeeting
		//-------------------------------------------------------------------

		/**
		 * Gets all associated MeetingNotesesAsMeeting as an array of MeetingNotes objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingNotes[]
		*/
		public function GetMeetingNotesAsMeetingArray($objOptionalClauses = null) {
			if ((is_null($this->intIddeptYearEvents)))
				return array();

			try {
				return MeetingNotes::LoadArrayByMeeting($this->intIddeptYearEvents, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated MeetingNotesesAsMeeting
		 * @return int
		*/
		public function CountMeetingNotesesAsMeeting() {
			if ((is_null($this->intIddeptYearEvents)))
				return 0;

			return MeetingNotes::CountByMeeting($this->intIddeptYearEvents);
		}

		/**
		 * Associates a MeetingNotesAsMeeting
		 * @param MeetingNotes $objMeetingNotes
		 * @return void
		*/
		public function AssociateMeetingNotesAsMeeting(MeetingNotes $objMeetingNotes) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMeetingNotesAsMeeting on this unsaved DeptYearEvents.');
			if ((is_null($objMeetingNotes->IdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMeetingNotesAsMeeting on this DeptYearEvents with an unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_notes`
				SET
					`meeting` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
				WHERE
					`idmeeting_notes` = ' . $objDatabase->SqlVariable($objMeetingNotes->IdmeetingNotes) . '
			');
		}

		/**
		 * Unassociates a MeetingNotesAsMeeting
		 * @param MeetingNotes $objMeetingNotes
		 * @return void
		*/
		public function UnassociateMeetingNotesAsMeeting(MeetingNotes $objMeetingNotes) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsMeeting on this unsaved DeptYearEvents.');
			if ((is_null($objMeetingNotes->IdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsMeeting on this DeptYearEvents with an unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_notes`
				SET
					`meeting` = null
				WHERE
					`idmeeting_notes` = ' . $objDatabase->SqlVariable($objMeetingNotes->IdmeetingNotes) . ' AND
					`meeting` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates all MeetingNotesesAsMeeting
		 * @return void
		*/
		public function UnassociateAllMeetingNotesesAsMeeting() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsMeeting on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_notes`
				SET
					`meeting` = null
				WHERE
					`meeting` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes an associated MeetingNotesAsMeeting
		 * @param MeetingNotes $objMeetingNotes
		 * @return void
		*/
		public function DeleteAssociatedMeetingNotesAsMeeting(MeetingNotes $objMeetingNotes) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsMeeting on this unsaved DeptYearEvents.');
			if ((is_null($objMeetingNotes->IdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsMeeting on this DeptYearEvents with an unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_notes`
				WHERE
					`idmeeting_notes` = ' . $objDatabase->SqlVariable($objMeetingNotes->IdmeetingNotes) . ' AND
					`meeting` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes all associated MeetingNotesesAsMeeting
		 * @return void
		*/
		public function DeleteAllMeetingNotesesAsMeeting() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsMeeting on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_notes`
				WHERE
					`meeting` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}


		// Related Objects' Methods for MemberDocAsMeeting
		//-------------------------------------------------------------------

		/**
		 * Gets all associated MemberDocsAsMeeting as an array of MemberDoc objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MemberDoc[]
		*/
		public function GetMemberDocAsMeetingArray($objOptionalClauses = null) {
			if ((is_null($this->intIddeptYearEvents)))
				return array();

			try {
				return MemberDoc::LoadArrayByMeeting($this->intIddeptYearEvents, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated MemberDocsAsMeeting
		 * @return int
		*/
		public function CountMemberDocsAsMeeting() {
			if ((is_null($this->intIddeptYearEvents)))
				return 0;

			return MemberDoc::CountByMeeting($this->intIddeptYearEvents);
		}

		/**
		 * Associates a MemberDocAsMeeting
		 * @param MemberDoc $objMemberDoc
		 * @return void
		*/
		public function AssociateMemberDocAsMeeting(MemberDoc $objMemberDoc) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMemberDocAsMeeting on this unsaved DeptYearEvents.');
			if ((is_null($objMemberDoc->IdmemberDoc)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMemberDocAsMeeting on this DeptYearEvents with an unsaved MemberDoc.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`member_doc`
				SET
					`meeting` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
				WHERE
					`idmember_doc` = ' . $objDatabase->SqlVariable($objMemberDoc->IdmemberDoc) . '
			');
		}

		/**
		 * Unassociates a MemberDocAsMeeting
		 * @param MemberDoc $objMemberDoc
		 * @return void
		*/
		public function UnassociateMemberDocAsMeeting(MemberDoc $objMemberDoc) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMemberDocAsMeeting on this unsaved DeptYearEvents.');
			if ((is_null($objMemberDoc->IdmemberDoc)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMemberDocAsMeeting on this DeptYearEvents with an unsaved MemberDoc.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`member_doc`
				SET
					`meeting` = null
				WHERE
					`idmember_doc` = ' . $objDatabase->SqlVariable($objMemberDoc->IdmemberDoc) . ' AND
					`meeting` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Unassociates all MemberDocsAsMeeting
		 * @return void
		*/
		public function UnassociateAllMemberDocsAsMeeting() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMemberDocAsMeeting on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`member_doc`
				SET
					`meeting` = null
				WHERE
					`meeting` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes an associated MemberDocAsMeeting
		 * @param MemberDoc $objMemberDoc
		 * @return void
		*/
		public function DeleteAssociatedMemberDocAsMeeting(MemberDoc $objMemberDoc) {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMemberDocAsMeeting on this unsaved DeptYearEvents.');
			if ((is_null($objMemberDoc->IdmemberDoc)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMemberDocAsMeeting on this DeptYearEvents with an unsaved MemberDoc.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`member_doc`
				WHERE
					`idmember_doc` = ' . $objDatabase->SqlVariable($objMemberDoc->IdmemberDoc) . ' AND
					`meeting` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}

		/**
		 * Deletes all associated MemberDocsAsMeeting
		 * @return void
		*/
		public function DeleteAllMemberDocsAsMeeting() {
			if ((is_null($this->intIddeptYearEvents)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMemberDocAsMeeting on this unsaved DeptYearEvents.');

			// Get the Database Object for this Class
			$objDatabase = DeptYearEvents::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`member_doc`
				WHERE
					`meeting` = ' . $objDatabase->SqlVariable($this->intIddeptYearEvents) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "dept_year_events";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[DeptYearEvents::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="DeptYearEvents"><sequence>';
			$strToReturn .= '<element name="IddeptYearEvents" type="xsd:int"/>';
			$strToReturn .= '<element name="Title" type="xsd:string"/>';
			$strToReturn .= '<element name="EventObject" type="xsd1:Event"/>';
			$strToReturn .= '<element name="DepartmentObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="DeptYearObject" type="xsd1:DeptYear"/>';
			$strToReturn .= '<element name="CalenderYearObject" type="xsd1:CalenderYear"/>';
			$strToReturn .= '<element name="ParrentObject" type="xsd1:DeptYearEvents"/>';
			$strToReturn .= '<element name="From" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="To" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Description" type="xsd:string"/>';
			$strToReturn .= '<element name="ExamTypeObject" type="xsd1:Exam"/>';
			$strToReturn .= '<element name="YearlySubjectObject" type="xsd1:YearlySubject"/>';
			$strToReturn .= '<element name="RefrenceEventObject" type="xsd1:DeptYearEvents"/>';
			$strToReturn .= '<element name="Mean" type="xsd:string"/>';
			$strToReturn .= '<element name="Sd" type="xsd:string"/>';
			$strToReturn .= '<element name="IntiatorObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="OwnerObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="Reason" type="xsd:string"/>';
			$strToReturn .= '<element name="Code" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('DeptYearEvents', $strComplexTypeArray)) {
				$strComplexTypeArray['DeptYearEvents'] = DeptYearEvents::GetSoapComplexTypeXml();
				Event::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				DeptYear::AlterSoapComplexTypeArray($strComplexTypeArray);
				CalenderYear::AlterSoapComplexTypeArray($strComplexTypeArray);
				DeptYearEvents::AlterSoapComplexTypeArray($strComplexTypeArray);
				Exam::AlterSoapComplexTypeArray($strComplexTypeArray);
				YearlySubject::AlterSoapComplexTypeArray($strComplexTypeArray);
				DeptYearEvents::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, DeptYearEvents::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new DeptYearEvents();
			if (property_exists($objSoapObject, 'IddeptYearEvents'))
				$objToReturn->intIddeptYearEvents = $objSoapObject->IddeptYearEvents;
			if (property_exists($objSoapObject, 'Title'))
				$objToReturn->strTitle = $objSoapObject->Title;
			if ((property_exists($objSoapObject, 'EventObject')) &&
				($objSoapObject->EventObject))
				$objToReturn->EventObject = Event::GetObjectFromSoapObject($objSoapObject->EventObject);
			if ((property_exists($objSoapObject, 'DepartmentObject')) &&
				($objSoapObject->DepartmentObject))
				$objToReturn->DepartmentObject = Role::GetObjectFromSoapObject($objSoapObject->DepartmentObject);
			if ((property_exists($objSoapObject, 'DeptYearObject')) &&
				($objSoapObject->DeptYearObject))
				$objToReturn->DeptYearObject = DeptYear::GetObjectFromSoapObject($objSoapObject->DeptYearObject);
			if ((property_exists($objSoapObject, 'CalenderYearObject')) &&
				($objSoapObject->CalenderYearObject))
				$objToReturn->CalenderYearObject = CalenderYear::GetObjectFromSoapObject($objSoapObject->CalenderYearObject);
			if ((property_exists($objSoapObject, 'ParrentObject')) &&
				($objSoapObject->ParrentObject))
				$objToReturn->ParrentObject = DeptYearEvents::GetObjectFromSoapObject($objSoapObject->ParrentObject);
			if (property_exists($objSoapObject, 'From'))
				$objToReturn->dttFrom = new QDateTime($objSoapObject->From);
			if (property_exists($objSoapObject, 'To'))
				$objToReturn->dttTo = new QDateTime($objSoapObject->To);
			if (property_exists($objSoapObject, 'Description'))
				$objToReturn->strDescription = $objSoapObject->Description;
			if ((property_exists($objSoapObject, 'ExamTypeObject')) &&
				($objSoapObject->ExamTypeObject))
				$objToReturn->ExamTypeObject = Exam::GetObjectFromSoapObject($objSoapObject->ExamTypeObject);
			if ((property_exists($objSoapObject, 'YearlySubjectObject')) &&
				($objSoapObject->YearlySubjectObject))
				$objToReturn->YearlySubjectObject = YearlySubject::GetObjectFromSoapObject($objSoapObject->YearlySubjectObject);
			if ((property_exists($objSoapObject, 'RefrenceEventObject')) &&
				($objSoapObject->RefrenceEventObject))
				$objToReturn->RefrenceEventObject = DeptYearEvents::GetObjectFromSoapObject($objSoapObject->RefrenceEventObject);
			if (property_exists($objSoapObject, 'Mean'))
				$objToReturn->strMean = $objSoapObject->Mean;
			if (property_exists($objSoapObject, 'Sd'))
				$objToReturn->strSd = $objSoapObject->Sd;
			if ((property_exists($objSoapObject, 'IntiatorObject')) &&
				($objSoapObject->IntiatorObject))
				$objToReturn->IntiatorObject = Login::GetObjectFromSoapObject($objSoapObject->IntiatorObject);
			if ((property_exists($objSoapObject, 'OwnerObject')) &&
				($objSoapObject->OwnerObject))
				$objToReturn->OwnerObject = Login::GetObjectFromSoapObject($objSoapObject->OwnerObject);
			if (property_exists($objSoapObject, 'Reason'))
				$objToReturn->strReason = $objSoapObject->Reason;
			if (property_exists($objSoapObject, 'Code'))
				$objToReturn->strCode = $objSoapObject->Code;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, DeptYearEvents::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objEventObject)
				$objObject->objEventObject = Event::GetSoapObjectFromObject($objObject->objEventObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intEvent = null;
			if ($objObject->objDepartmentObject)
				$objObject->objDepartmentObject = Role::GetSoapObjectFromObject($objObject->objDepartmentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDepartment = null;
			if ($objObject->objDeptYearObject)
				$objObject->objDeptYearObject = DeptYear::GetSoapObjectFromObject($objObject->objDeptYearObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDeptYear = null;
			if ($objObject->objCalenderYearObject)
				$objObject->objCalenderYearObject = CalenderYear::GetSoapObjectFromObject($objObject->objCalenderYearObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intCalenderYear = null;
			if ($objObject->objParrentObject)
				$objObject->objParrentObject = DeptYearEvents::GetSoapObjectFromObject($objObject->objParrentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intParrent = null;
			if ($objObject->dttFrom)
				$objObject->dttFrom = $objObject->dttFrom->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttTo)
				$objObject->dttTo = $objObject->dttTo->qFormat(QDateTime::FormatSoap);
			if ($objObject->objExamTypeObject)
				$objObject->objExamTypeObject = Exam::GetSoapObjectFromObject($objObject->objExamTypeObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intExamType = null;
			if ($objObject->objYearlySubjectObject)
				$objObject->objYearlySubjectObject = YearlySubject::GetSoapObjectFromObject($objObject->objYearlySubjectObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intYearlySubject = null;
			if ($objObject->objRefrenceEventObject)
				$objObject->objRefrenceEventObject = DeptYearEvents::GetSoapObjectFromObject($objObject->objRefrenceEventObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intRefrenceEvent = null;
			if ($objObject->objIntiatorObject)
				$objObject->objIntiatorObject = Login::GetSoapObjectFromObject($objObject->objIntiatorObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intIntiator = null;
			if ($objObject->objOwnerObject)
				$objObject->objOwnerObject = Login::GetSoapObjectFromObject($objObject->objOwnerObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intOwner = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IddeptYearEvents'] = $this->intIddeptYearEvents;
			$iArray['Title'] = $this->strTitle;
			$iArray['Event'] = $this->intEvent;
			$iArray['Department'] = $this->intDepartment;
			$iArray['DeptYear'] = $this->intDeptYear;
			$iArray['CalenderYear'] = $this->intCalenderYear;
			$iArray['Parrent'] = $this->intParrent;
			$iArray['From'] = $this->dttFrom;
			$iArray['To'] = $this->dttTo;
			$iArray['Description'] = $this->strDescription;
			$iArray['ExamType'] = $this->intExamType;
			$iArray['YearlySubject'] = $this->intYearlySubject;
			$iArray['RefrenceEvent'] = $this->intRefrenceEvent;
			$iArray['Mean'] = $this->strMean;
			$iArray['Sd'] = $this->strSd;
			$iArray['Intiator'] = $this->intIntiator;
			$iArray['Owner'] = $this->intOwner;
			$iArray['Reason'] = $this->strReason;
			$iArray['Code'] = $this->strCode;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIddeptYearEvents ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IddeptYearEvents
     * @property-read QQNode $Title
     * @property-read QQNode $Event
     * @property-read QQNodeEvent $EventObject
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $DeptYear
     * @property-read QQNodeDeptYear $DeptYearObject
     * @property-read QQNode $CalenderYear
     * @property-read QQNodeCalenderYear $CalenderYearObject
     * @property-read QQNode $Parrent
     * @property-read QQNodeDeptYearEvents $ParrentObject
     * @property-read QQNode $From
     * @property-read QQNode $To
     * @property-read QQNode $Description
     * @property-read QQNode $ExamType
     * @property-read QQNodeExam $ExamTypeObject
     * @property-read QQNode $YearlySubject
     * @property-read QQNodeYearlySubject $YearlySubjectObject
     * @property-read QQNode $RefrenceEvent
     * @property-read QQNodeDeptYearEvents $RefrenceEventObject
     * @property-read QQNode $Mean
     * @property-read QQNode $Sd
     * @property-read QQNode $Intiator
     * @property-read QQNodeLogin $IntiatorObject
     * @property-read QQNode $Owner
     * @property-read QQNodeLogin $OwnerObject
     * @property-read QQNode $Reason
     * @property-read QQNode $Code
     *
     *
     * @property-read QQReverseReferenceNodeAppliedExam $AppliedExamAsEventSubject
     * @property-read QQReverseReferenceNodeAppliedExam $AppliedExamAsEventExam
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEventsAsParrent
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEventsAsRefrenceEvent
     * @property-read QQReverseReferenceNodeEventHasAttendent $EventHasAttendentAsEvent
     * @property-read QQReverseReferenceNodeEventHasGrade $EventHasGrade
     * @property-read QQReverseReferenceNodeExampaper $ExampaperAsEventExam
     * @property-read QQReverseReferenceNodeMeetingNotes $MeetingNotesAsMeeting
     * @property-read QQReverseReferenceNodeMemberDoc $MemberDocAsMeeting

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeDeptYearEvents extends QQNode {
		protected $strTableName = 'dept_year_events';
		protected $strPrimaryKey = 'iddept_year_events';
		protected $strClassName = 'DeptYearEvents';
		public function __get($strName) {
			switch ($strName) {
				case 'IddeptYearEvents':
					return new QQNode('iddept_year_events', 'IddeptYearEvents', 'Integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'VarChar', $this);
				case 'Event':
					return new QQNode('event', 'Event', 'Integer', $this);
				case 'EventObject':
					return new QQNodeEvent('event', 'EventObject', 'Integer', $this);
				case 'Department':
					return new QQNode('department', 'Department', 'Integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'Integer', $this);
				case 'DeptYear':
					return new QQNode('dept_year', 'DeptYear', 'Integer', $this);
				case 'DeptYearObject':
					return new QQNodeDeptYear('dept_year', 'DeptYearObject', 'Integer', $this);
				case 'CalenderYear':
					return new QQNode('calender_year', 'CalenderYear', 'Integer', $this);
				case 'CalenderYearObject':
					return new QQNodeCalenderYear('calender_year', 'CalenderYearObject', 'Integer', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'Integer', $this);
				case 'ParrentObject':
					return new QQNodeDeptYearEvents('parrent', 'ParrentObject', 'Integer', $this);
				case 'From':
					return new QQNode('from', 'From', 'DateTime', $this);
				case 'To':
					return new QQNode('to', 'To', 'DateTime', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'Blob', $this);
				case 'ExamType':
					return new QQNode('exam_type', 'ExamType', 'Integer', $this);
				case 'ExamTypeObject':
					return new QQNodeExam('exam_type', 'ExamTypeObject', 'Integer', $this);
				case 'YearlySubject':
					return new QQNode('yearly_subject', 'YearlySubject', 'Integer', $this);
				case 'YearlySubjectObject':
					return new QQNodeYearlySubject('yearly_subject', 'YearlySubjectObject', 'Integer', $this);
				case 'RefrenceEvent':
					return new QQNode('refrence_event', 'RefrenceEvent', 'Integer', $this);
				case 'RefrenceEventObject':
					return new QQNodeDeptYearEvents('refrence_event', 'RefrenceEventObject', 'Integer', $this);
				case 'Mean':
					return new QQNode('mean', 'Mean', 'VarChar', $this);
				case 'Sd':
					return new QQNode('sd', 'Sd', 'VarChar', $this);
				case 'Intiator':
					return new QQNode('intiator', 'Intiator', 'Integer', $this);
				case 'IntiatorObject':
					return new QQNodeLogin('intiator', 'IntiatorObject', 'Integer', $this);
				case 'Owner':
					return new QQNode('owner', 'Owner', 'Integer', $this);
				case 'OwnerObject':
					return new QQNodeLogin('owner', 'OwnerObject', 'Integer', $this);
				case 'Reason':
					return new QQNode('reason', 'Reason', 'Blob', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'VarChar', $this);
				case 'AppliedExamAsEventSubject':
					return new QQReverseReferenceNodeAppliedExam($this, 'appliedexamaseventsubject', 'reverse_reference', 'event_subject');
				case 'AppliedExamAsEventExam':
					return new QQReverseReferenceNodeAppliedExam($this, 'appliedexamaseventexam', 'reverse_reference', 'event_exam');
				case 'DeptYearEventsAsParrent':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyeareventsasparrent', 'reverse_reference', 'parrent');
				case 'DeptYearEventsAsRefrenceEvent':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyeareventsasrefrenceevent', 'reverse_reference', 'refrence_event');
				case 'EventHasAttendentAsEvent':
					return new QQReverseReferenceNodeEventHasAttendent($this, 'eventhasattendentasevent', 'reverse_reference', 'event');
				case 'EventHasGrade':
					return new QQReverseReferenceNodeEventHasGrade($this, 'eventhasgrade', 'reverse_reference', 'dept_year_events');
				case 'ExampaperAsEventExam':
					return new QQReverseReferenceNodeExampaper($this, 'exampaperaseventexam', 'reverse_reference', 'event_exam');
				case 'MeetingNotesAsMeeting':
					return new QQReverseReferenceNodeMeetingNotes($this, 'meetingnotesasmeeting', 'reverse_reference', 'meeting');
				case 'MemberDocAsMeeting':
					return new QQReverseReferenceNodeMemberDoc($this, 'memberdocasmeeting', 'reverse_reference', 'meeting');

				case '_PrimaryKeyNode':
					return new QQNode('iddept_year_events', 'IddeptYearEvents', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IddeptYearEvents
     * @property-read QQNode $Title
     * @property-read QQNode $Event
     * @property-read QQNodeEvent $EventObject
     * @property-read QQNode $Department
     * @property-read QQNodeRole $DepartmentObject
     * @property-read QQNode $DeptYear
     * @property-read QQNodeDeptYear $DeptYearObject
     * @property-read QQNode $CalenderYear
     * @property-read QQNodeCalenderYear $CalenderYearObject
     * @property-read QQNode $Parrent
     * @property-read QQNodeDeptYearEvents $ParrentObject
     * @property-read QQNode $From
     * @property-read QQNode $To
     * @property-read QQNode $Description
     * @property-read QQNode $ExamType
     * @property-read QQNodeExam $ExamTypeObject
     * @property-read QQNode $YearlySubject
     * @property-read QQNodeYearlySubject $YearlySubjectObject
     * @property-read QQNode $RefrenceEvent
     * @property-read QQNodeDeptYearEvents $RefrenceEventObject
     * @property-read QQNode $Mean
     * @property-read QQNode $Sd
     * @property-read QQNode $Intiator
     * @property-read QQNodeLogin $IntiatorObject
     * @property-read QQNode $Owner
     * @property-read QQNodeLogin $OwnerObject
     * @property-read QQNode $Reason
     * @property-read QQNode $Code
     *
     *
     * @property-read QQReverseReferenceNodeAppliedExam $AppliedExamAsEventSubject
     * @property-read QQReverseReferenceNodeAppliedExam $AppliedExamAsEventExam
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEventsAsParrent
     * @property-read QQReverseReferenceNodeDeptYearEvents $DeptYearEventsAsRefrenceEvent
     * @property-read QQReverseReferenceNodeEventHasAttendent $EventHasAttendentAsEvent
     * @property-read QQReverseReferenceNodeEventHasGrade $EventHasGrade
     * @property-read QQReverseReferenceNodeExampaper $ExampaperAsEventExam
     * @property-read QQReverseReferenceNodeMeetingNotes $MeetingNotesAsMeeting
     * @property-read QQReverseReferenceNodeMemberDoc $MemberDocAsMeeting

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeDeptYearEvents extends QQReverseReferenceNode {
		protected $strTableName = 'dept_year_events';
		protected $strPrimaryKey = 'iddept_year_events';
		protected $strClassName = 'DeptYearEvents';
		public function __get($strName) {
			switch ($strName) {
				case 'IddeptYearEvents':
					return new QQNode('iddept_year_events', 'IddeptYearEvents', 'integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'string', $this);
				case 'Event':
					return new QQNode('event', 'Event', 'integer', $this);
				case 'EventObject':
					return new QQNodeEvent('event', 'EventObject', 'integer', $this);
				case 'Department':
					return new QQNode('department', 'Department', 'integer', $this);
				case 'DepartmentObject':
					return new QQNodeRole('department', 'DepartmentObject', 'integer', $this);
				case 'DeptYear':
					return new QQNode('dept_year', 'DeptYear', 'integer', $this);
				case 'DeptYearObject':
					return new QQNodeDeptYear('dept_year', 'DeptYearObject', 'integer', $this);
				case 'CalenderYear':
					return new QQNode('calender_year', 'CalenderYear', 'integer', $this);
				case 'CalenderYearObject':
					return new QQNodeCalenderYear('calender_year', 'CalenderYearObject', 'integer', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'integer', $this);
				case 'ParrentObject':
					return new QQNodeDeptYearEvents('parrent', 'ParrentObject', 'integer', $this);
				case 'From':
					return new QQNode('from', 'From', 'QDateTime', $this);
				case 'To':
					return new QQNode('to', 'To', 'QDateTime', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'string', $this);
				case 'ExamType':
					return new QQNode('exam_type', 'ExamType', 'integer', $this);
				case 'ExamTypeObject':
					return new QQNodeExam('exam_type', 'ExamTypeObject', 'integer', $this);
				case 'YearlySubject':
					return new QQNode('yearly_subject', 'YearlySubject', 'integer', $this);
				case 'YearlySubjectObject':
					return new QQNodeYearlySubject('yearly_subject', 'YearlySubjectObject', 'integer', $this);
				case 'RefrenceEvent':
					return new QQNode('refrence_event', 'RefrenceEvent', 'integer', $this);
				case 'RefrenceEventObject':
					return new QQNodeDeptYearEvents('refrence_event', 'RefrenceEventObject', 'integer', $this);
				case 'Mean':
					return new QQNode('mean', 'Mean', 'string', $this);
				case 'Sd':
					return new QQNode('sd', 'Sd', 'string', $this);
				case 'Intiator':
					return new QQNode('intiator', 'Intiator', 'integer', $this);
				case 'IntiatorObject':
					return new QQNodeLogin('intiator', 'IntiatorObject', 'integer', $this);
				case 'Owner':
					return new QQNode('owner', 'Owner', 'integer', $this);
				case 'OwnerObject':
					return new QQNodeLogin('owner', 'OwnerObject', 'integer', $this);
				case 'Reason':
					return new QQNode('reason', 'Reason', 'string', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'string', $this);
				case 'AppliedExamAsEventSubject':
					return new QQReverseReferenceNodeAppliedExam($this, 'appliedexamaseventsubject', 'reverse_reference', 'event_subject');
				case 'AppliedExamAsEventExam':
					return new QQReverseReferenceNodeAppliedExam($this, 'appliedexamaseventexam', 'reverse_reference', 'event_exam');
				case 'DeptYearEventsAsParrent':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyeareventsasparrent', 'reverse_reference', 'parrent');
				case 'DeptYearEventsAsRefrenceEvent':
					return new QQReverseReferenceNodeDeptYearEvents($this, 'deptyeareventsasrefrenceevent', 'reverse_reference', 'refrence_event');
				case 'EventHasAttendentAsEvent':
					return new QQReverseReferenceNodeEventHasAttendent($this, 'eventhasattendentasevent', 'reverse_reference', 'event');
				case 'EventHasGrade':
					return new QQReverseReferenceNodeEventHasGrade($this, 'eventhasgrade', 'reverse_reference', 'dept_year_events');
				case 'ExampaperAsEventExam':
					return new QQReverseReferenceNodeExampaper($this, 'exampaperaseventexam', 'reverse_reference', 'event_exam');
				case 'MeetingNotesAsMeeting':
					return new QQReverseReferenceNodeMeetingNotes($this, 'meetingnotesasmeeting', 'reverse_reference', 'meeting');
				case 'MemberDocAsMeeting':
					return new QQReverseReferenceNodeMemberDoc($this, 'memberdocasmeeting', 'reverse_reference', 'meeting');

				case '_PrimaryKeyNode':
					return new QQNode('iddept_year_events', 'IddeptYearEvents', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
