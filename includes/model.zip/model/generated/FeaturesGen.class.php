<?php
	/**
	 * The abstract FeaturesGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Features subclass which
	 * extends this FeaturesGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Features class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idfeatures the value for intIdfeatures (Read-Only PK)
	 * @property-read string $Date the value for strDate (Read-Only Timestamp)
	 * @property integer $Grp the value for intGrp (Not Null)
	 * @property string $Title the value for strTitle (Not Null)
	 * @property string $Data the value for strData (Not Null)
	 * @property integer $Parrent the value for intParrent 
	 * @property integer $Counter the value for intCounter 
	 * @property FeatureGrp $GrpObject the value for the FeatureGrp object referenced by intGrp (Not Null)
	 * @property Features $ParrentObject the value for the Features object referenced by intParrent 
	 * @property-read Features $_FeaturesAsParrent the value for the private _objFeaturesAsParrent (Read-Only) if set due to an expansion on the features.parrent reverse relationship
	 * @property-read Features[] $_FeaturesAsParrentArray the value for the private _objFeaturesAsParrentArray (Read-Only) if set due to an ExpandAsArray on the features.parrent reverse relationship
	 * @property-read ItemHasFeatures $_ItemHasFeaturesAsFeature the value for the private _objItemHasFeaturesAsFeature (Read-Only) if set due to an expansion on the item_has_features.feature reverse relationship
	 * @property-read ItemHasFeatures[] $_ItemHasFeaturesAsFeatureArray the value for the private _objItemHasFeaturesAsFeatureArray (Read-Only) if set due to an ExpandAsArray on the item_has_features.feature reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class FeaturesGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column features.idfeatures
		 * @var integer intIdfeatures
		 */
		protected $intIdfeatures;
		const IdfeaturesDefault = null;


		/**
		 * Protected member variable that maps to the database column features.date
		 * @var string strDate
		 */
		protected $strDate;
		const DateDefault = null;


		/**
		 * Protected member variable that maps to the database column features.grp
		 * @var integer intGrp
		 */
		protected $intGrp;
		const GrpDefault = null;


		/**
		 * Protected member variable that maps to the database column features.title
		 * @var string strTitle
		 */
		protected $strTitle;
		const TitleMaxLength = 255;
		const TitleDefault = null;


		/**
		 * Protected member variable that maps to the database column features.data
		 * @var string strData
		 */
		protected $strData;
		const DataDefault = null;


		/**
		 * Protected member variable that maps to the database column features.parrent
		 * @var integer intParrent
		 */
		protected $intParrent;
		const ParrentDefault = null;


		/**
		 * Protected member variable that maps to the database column features.counter
		 * @var integer intCounter
		 */
		protected $intCounter;
		const CounterDefault = null;


		/**
		 * Private member variable that stores a reference to a single FeaturesAsParrent object
		 * (of type Features), if this Features object was restored with
		 * an expansion on the features association table.
		 * @var Features _objFeaturesAsParrent;
		 */
		private $_objFeaturesAsParrent;

		/**
		 * Private member variable that stores a reference to an array of FeaturesAsParrent objects
		 * (of type Features[]), if this Features object was restored with
		 * an ExpandAsArray on the features association table.
		 * @var Features[] _objFeaturesAsParrentArray;
		 */
		private $_objFeaturesAsParrentArray = null;

		/**
		 * Private member variable that stores a reference to a single ItemHasFeaturesAsFeature object
		 * (of type ItemHasFeatures), if this Features object was restored with
		 * an expansion on the item_has_features association table.
		 * @var ItemHasFeatures _objItemHasFeaturesAsFeature;
		 */
		private $_objItemHasFeaturesAsFeature;

		/**
		 * Private member variable that stores a reference to an array of ItemHasFeaturesAsFeature objects
		 * (of type ItemHasFeatures[]), if this Features object was restored with
		 * an ExpandAsArray on the item_has_features association table.
		 * @var ItemHasFeatures[] _objItemHasFeaturesAsFeatureArray;
		 */
		private $_objItemHasFeaturesAsFeatureArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column features.grp.
		 *
		 * NOTE: Always use the GrpObject property getter to correctly retrieve this FeatureGrp object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var FeatureGrp objGrpObject
		 */
		protected $objGrpObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column features.parrent.
		 *
		 * NOTE: Always use the ParrentObject property getter to correctly retrieve this Features object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Features objParrentObject
		 */
		protected $objParrentObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdfeatures = Features::IdfeaturesDefault;
			$this->strDate = Features::DateDefault;
			$this->intGrp = Features::GrpDefault;
			$this->strTitle = Features::TitleDefault;
			$this->strData = Features::DataDefault;
			$this->intParrent = Features::ParrentDefault;
			$this->intCounter = Features::CounterDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Features from PK Info
		 * @param integer $intIdfeatures
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Features
		 */
		public static function Load($intIdfeatures, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Features', $intIdfeatures);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Features::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Features()->Idfeatures, $intIdfeatures)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Featureses
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Features[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Features::QueryArray to perform the LoadAll query
			try {
				return Features::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Featureses
		 * @return int
		 */
		public static function CountAll() {
			// Call Features::QueryCount to perform the CountAll query
			return Features::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();

			// Create/Build out the QueryBuilder object with Features-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'features');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Features::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('features');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Features object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Features the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Features::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Features object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Features::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Features::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Features objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Features[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Features::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Features::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Features::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Features objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Features::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();

			$strQuery = Features::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/features', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Features::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Features
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'features';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idfeatures', $strAliasPrefix . 'idfeatures');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idfeatures', $strAliasPrefix . 'idfeatures');
			    $objBuilder->AddSelectItem($strTableName, 'date', $strAliasPrefix . 'date');
			    $objBuilder->AddSelectItem($strTableName, 'grp', $strAliasPrefix . 'grp');
			    $objBuilder->AddSelectItem($strTableName, 'title', $strAliasPrefix . 'title');
			    $objBuilder->AddSelectItem($strTableName, 'data', $strAliasPrefix . 'data');
			    $objBuilder->AddSelectItem($strTableName, 'parrent', $strAliasPrefix . 'parrent');
			    $objBuilder->AddSelectItem($strTableName, 'counter', $strAliasPrefix . 'counter');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Features from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Features::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Features
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idfeatures';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdfeatures == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'features__';


						// Expanding reverse references: FeaturesAsParrent
						$strAlias = $strAliasPrefix . 'featuresasparrent__idfeatures';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objFeaturesAsParrentArray)
								$objPreviousItem->_objFeaturesAsParrentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objFeaturesAsParrentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objFeaturesAsParrentArray;
								$objChildItem = Features::InstantiateDbRow($objDbRow, $strAliasPrefix . 'featuresasparrent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objFeaturesAsParrentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objFeaturesAsParrentArray[] = Features::InstantiateDbRow($objDbRow, $strAliasPrefix . 'featuresasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ItemHasFeaturesAsFeature
						$strAlias = $strAliasPrefix . 'itemhasfeaturesasfeature__iditem_has_features';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objItemHasFeaturesAsFeatureArray)
								$objPreviousItem->_objItemHasFeaturesAsFeatureArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objItemHasFeaturesAsFeatureArray)) {
								$objPreviousChildItems = $objPreviousItem->_objItemHasFeaturesAsFeatureArray;
								$objChildItem = ItemHasFeatures::InstantiateDbRow($objDbRow, $strAliasPrefix . 'itemhasfeaturesasfeature__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objItemHasFeaturesAsFeatureArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objItemHasFeaturesAsFeatureArray[] = ItemHasFeatures::InstantiateDbRow($objDbRow, $strAliasPrefix . 'itemhasfeaturesasfeature__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'features__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Features object
			$objToReturn = new Features();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idfeatures';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdfeatures = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strDate = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intGrp = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'title';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTitle = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'data';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strData = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'parrent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intParrent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'counter';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intCounter = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idfeatures != $objPreviousItem->Idfeatures) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objFeaturesAsParrentArray);
					$cnt = count($objToReturn->_objFeaturesAsParrentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objFeaturesAsParrentArray, $objToReturn->_objFeaturesAsParrentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objItemHasFeaturesAsFeatureArray);
					$cnt = count($objToReturn->_objItemHasFeaturesAsFeatureArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objItemHasFeaturesAsFeatureArray, $objToReturn->_objItemHasFeaturesAsFeatureArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'features__';

			// Check for GrpObject Early Binding
			$strAlias = $strAliasPrefix . 'grp__idfeature_grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objGrpObject = FeatureGrp::InstantiateDbRow($objDbRow, $strAliasPrefix . 'grp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ParrentObject Early Binding
			$strAlias = $strAliasPrefix . 'parrent__idfeatures';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objParrentObject = Features::InstantiateDbRow($objDbRow, $strAliasPrefix . 'parrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for FeaturesAsParrent Virtual Binding
			$strAlias = $strAliasPrefix . 'featuresasparrent__idfeatures';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objFeaturesAsParrentArray)
				$objToReturn->_objFeaturesAsParrentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objFeaturesAsParrentArray[] = Features::InstantiateDbRow($objDbRow, $strAliasPrefix . 'featuresasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objFeaturesAsParrent = Features::InstantiateDbRow($objDbRow, $strAliasPrefix . 'featuresasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ItemHasFeaturesAsFeature Virtual Binding
			$strAlias = $strAliasPrefix . 'itemhasfeaturesasfeature__iditem_has_features';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objItemHasFeaturesAsFeatureArray)
				$objToReturn->_objItemHasFeaturesAsFeatureArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objItemHasFeaturesAsFeatureArray[] = ItemHasFeatures::InstantiateDbRow($objDbRow, $strAliasPrefix . 'itemhasfeaturesasfeature__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objItemHasFeaturesAsFeature = ItemHasFeatures::InstantiateDbRow($objDbRow, $strAliasPrefix . 'itemhasfeaturesasfeature__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Featureses from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Features[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Features::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Features::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Features object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Features next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Features::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Features object,
		 * by Idfeatures Index(es)
		 * @param integer $intIdfeatures
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Features
		*/
		public static function LoadByIdfeatures($intIdfeatures, $objOptionalClauses = null) {
			return Features::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Features()->Idfeatures, $intIdfeatures)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Features objects,
		 * by Grp Index(es)
		 * @param integer $intGrp
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Features[]
		*/
		public static function LoadArrayByGrp($intGrp, $objOptionalClauses = null) {
			// Call Features::QueryArray to perform the LoadArrayByGrp query
			try {
				return Features::QueryArray(
					QQ::Equal(QQN::Features()->Grp, $intGrp),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Featureses
		 * by Grp Index(es)
		 * @param integer $intGrp
		 * @return int
		*/
		public static function CountByGrp($intGrp) {
			// Call Features::QueryCount to perform the CountByGrp query
			return Features::QueryCount(
				QQ::Equal(QQN::Features()->Grp, $intGrp)
			);
		}

		/**
		 * Load an array of Features objects,
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Features[]
		*/
		public static function LoadArrayByParrent($intParrent, $objOptionalClauses = null) {
			// Call Features::QueryArray to perform the LoadArrayByParrent query
			try {
				return Features::QueryArray(
					QQ::Equal(QQN::Features()->Parrent, $intParrent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Featureses
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @return int
		*/
		public static function CountByParrent($intParrent) {
			// Call Features::QueryCount to perform the CountByParrent query
			return Features::QueryCount(
				QQ::Equal(QQN::Features()->Parrent, $intParrent)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Features
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `features` (
							`grp`,
							`title`,
							`data`,
							`parrent`,
							`counter`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intGrp) . ',
							' . $objDatabase->SqlVariable($this->strTitle) . ',
							' . $objDatabase->SqlVariable($this->strData) . ',
							' . $objDatabase->SqlVariable($this->intParrent) . ',
							' . $objDatabase->SqlVariable($this->intCounter) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdfeatures = $objDatabase->InsertId('features', 'idfeatures');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)
					if (!$blnForceUpdate) {
						// Perform the Optimistic Locking check
						$objResult = $objDatabase->Query('
							SELECT
								`date`
							FROM
								`features`
							WHERE
							`idfeatures` = ' . $objDatabase->SqlVariable($this->intIdfeatures) . '
						');

						$objRow = $objResult->FetchArray();
						if ($objRow[0] != $this->strDate)
							throw new QOptimisticLockingException('Features');
					}

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`features`
						SET
							`grp` = ' . $objDatabase->SqlVariable($this->intGrp) . ',
							`title` = ' . $objDatabase->SqlVariable($this->strTitle) . ',
							`data` = ' . $objDatabase->SqlVariable($this->strData) . ',
							`parrent` = ' . $objDatabase->SqlVariable($this->intParrent) . ',
							`counter` = ' . $objDatabase->SqlVariable($this->intCounter) . '
						WHERE
							`idfeatures` = ' . $objDatabase->SqlVariable($this->intIdfeatures) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;

			// Update Local Timestamp
			$objResult = $objDatabase->Query('
				SELECT
					`date`
				FROM
					`features`
				WHERE
							`idfeatures` = ' . $objDatabase->SqlVariable($this->intIdfeatures) . '
			');

			$objRow = $objResult->FetchArray();
			$this->strDate = $objRow[0];

			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Features
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdfeatures)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Features with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`features`
				WHERE
					`idfeatures` = ' . $objDatabase->SqlVariable($this->intIdfeatures) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Features ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Features', $this->intIdfeatures);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Featureses
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`features`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate features table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `features`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Features from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Features object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Features::Load($this->intIdfeatures);

			// Update $this's local variables to match
			$this->strDate = $objReloaded->strDate;
			$this->Grp = $objReloaded->Grp;
			$this->strTitle = $objReloaded->strTitle;
			$this->strData = $objReloaded->strData;
			$this->Parrent = $objReloaded->Parrent;
			$this->intCounter = $objReloaded->intCounter;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idfeatures':
					/**
					 * Gets the value for intIdfeatures (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdfeatures;

				case 'Date':
					/**
					 * Gets the value for strDate (Read-Only Timestamp)
					 * @return string
					 */
					return $this->strDate;

				case 'Grp':
					/**
					 * Gets the value for intGrp (Not Null)
					 * @return integer
					 */
					return $this->intGrp;

				case 'Title':
					/**
					 * Gets the value for strTitle (Not Null)
					 * @return string
					 */
					return $this->strTitle;

				case 'Data':
					/**
					 * Gets the value for strData (Not Null)
					 * @return string
					 */
					return $this->strData;

				case 'Parrent':
					/**
					 * Gets the value for intParrent 
					 * @return integer
					 */
					return $this->intParrent;

				case 'Counter':
					/**
					 * Gets the value for intCounter 
					 * @return integer
					 */
					return $this->intCounter;


				///////////////////
				// Member Objects
				///////////////////
				case 'GrpObject':
					/**
					 * Gets the value for the FeatureGrp object referenced by intGrp (Not Null)
					 * @return FeatureGrp
					 */
					try {
						if ((!$this->objGrpObject) && (!is_null($this->intGrp)))
							$this->objGrpObject = FeatureGrp::Load($this->intGrp);
						return $this->objGrpObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ParrentObject':
					/**
					 * Gets the value for the Features object referenced by intParrent 
					 * @return Features
					 */
					try {
						if ((!$this->objParrentObject) && (!is_null($this->intParrent)))
							$this->objParrentObject = Features::Load($this->intParrent);
						return $this->objParrentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_FeaturesAsParrent':
					/**
					 * Gets the value for the private _objFeaturesAsParrent (Read-Only)
					 * if set due to an expansion on the features.parrent reverse relationship
					 * @return Features
					 */
					return $this->_objFeaturesAsParrent;

				case '_FeaturesAsParrentArray':
					/**
					 * Gets the value for the private _objFeaturesAsParrentArray (Read-Only)
					 * if set due to an ExpandAsArray on the features.parrent reverse relationship
					 * @return Features[]
					 */
					return $this->_objFeaturesAsParrentArray;

				case '_ItemHasFeaturesAsFeature':
					/**
					 * Gets the value for the private _objItemHasFeaturesAsFeature (Read-Only)
					 * if set due to an expansion on the item_has_features.feature reverse relationship
					 * @return ItemHasFeatures
					 */
					return $this->_objItemHasFeaturesAsFeature;

				case '_ItemHasFeaturesAsFeatureArray':
					/**
					 * Gets the value for the private _objItemHasFeaturesAsFeatureArray (Read-Only)
					 * if set due to an ExpandAsArray on the item_has_features.feature reverse relationship
					 * @return ItemHasFeatures[]
					 */
					return $this->_objItemHasFeaturesAsFeatureArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Grp':
					/**
					 * Sets the value for intGrp (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objGrpObject = null;
						return ($this->intGrp = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Title':
					/**
					 * Sets the value for strTitle (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTitle = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Data':
					/**
					 * Sets the value for strData (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strData = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Parrent':
					/**
					 * Sets the value for intParrent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objParrentObject = null;
						return ($this->intParrent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Counter':
					/**
					 * Sets the value for intCounter 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intCounter = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'GrpObject':
					/**
					 * Sets the value for the FeatureGrp object referenced by intGrp (Not Null)
					 * @param FeatureGrp $mixValue
					 * @return FeatureGrp
					 */
					if (is_null($mixValue)) {
						$this->intGrp = null;
						$this->objGrpObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a FeatureGrp object
						try {
							$mixValue = QType::Cast($mixValue, 'FeatureGrp');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED FeatureGrp object
						if (is_null($mixValue->IdfeatureGrp))
							throw new QCallerException('Unable to set an unsaved GrpObject for this Features');

						// Update Local Member Variables
						$this->objGrpObject = $mixValue;
						$this->intGrp = $mixValue->IdfeatureGrp;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ParrentObject':
					/**
					 * Sets the value for the Features object referenced by intParrent 
					 * @param Features $mixValue
					 * @return Features
					 */
					if (is_null($mixValue)) {
						$this->intParrent = null;
						$this->objParrentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Features object
						try {
							$mixValue = QType::Cast($mixValue, 'Features');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Features object
						if (is_null($mixValue->Idfeatures))
							throw new QCallerException('Unable to set an unsaved ParrentObject for this Features');

						// Update Local Member Variables
						$this->objParrentObject = $mixValue;
						$this->intParrent = $mixValue->Idfeatures;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for FeaturesAsParrent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated FeaturesesAsParrent as an array of Features objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Features[]
		*/
		public function GetFeaturesAsParrentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdfeatures)))
				return array();

			try {
				return Features::LoadArrayByParrent($this->intIdfeatures, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated FeaturesesAsParrent
		 * @return int
		*/
		public function CountFeaturesesAsParrent() {
			if ((is_null($this->intIdfeatures)))
				return 0;

			return Features::CountByParrent($this->intIdfeatures);
		}

		/**
		 * Associates a FeaturesAsParrent
		 * @param Features $objFeatures
		 * @return void
		*/
		public function AssociateFeaturesAsParrent(Features $objFeatures) {
			if ((is_null($this->intIdfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateFeaturesAsParrent on this unsaved Features.');
			if ((is_null($objFeatures->Idfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateFeaturesAsParrent on this Features with an unsaved Features.');

			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`features`
				SET
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdfeatures) . '
				WHERE
					`idfeatures` = ' . $objDatabase->SqlVariable($objFeatures->Idfeatures) . '
			');
		}

		/**
		 * Unassociates a FeaturesAsParrent
		 * @param Features $objFeatures
		 * @return void
		*/
		public function UnassociateFeaturesAsParrent(Features $objFeatures) {
			if ((is_null($this->intIdfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeaturesAsParrent on this unsaved Features.');
			if ((is_null($objFeatures->Idfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeaturesAsParrent on this Features with an unsaved Features.');

			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`features`
				SET
					`parrent` = null
				WHERE
					`idfeatures` = ' . $objDatabase->SqlVariable($objFeatures->Idfeatures) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdfeatures) . '
			');
		}

		/**
		 * Unassociates all FeaturesesAsParrent
		 * @return void
		*/
		public function UnassociateAllFeaturesesAsParrent() {
			if ((is_null($this->intIdfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeaturesAsParrent on this unsaved Features.');

			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`features`
				SET
					`parrent` = null
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdfeatures) . '
			');
		}

		/**
		 * Deletes an associated FeaturesAsParrent
		 * @param Features $objFeatures
		 * @return void
		*/
		public function DeleteAssociatedFeaturesAsParrent(Features $objFeatures) {
			if ((is_null($this->intIdfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeaturesAsParrent on this unsaved Features.');
			if ((is_null($objFeatures->Idfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeaturesAsParrent on this Features with an unsaved Features.');

			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`features`
				WHERE
					`idfeatures` = ' . $objDatabase->SqlVariable($objFeatures->Idfeatures) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdfeatures) . '
			');
		}

		/**
		 * Deletes all associated FeaturesesAsParrent
		 * @return void
		*/
		public function DeleteAllFeaturesesAsParrent() {
			if ((is_null($this->intIdfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeaturesAsParrent on this unsaved Features.');

			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`features`
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdfeatures) . '
			');
		}


		// Related Objects' Methods for ItemHasFeaturesAsFeature
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ItemHasFeaturesesAsFeature as an array of ItemHasFeatures objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ItemHasFeatures[]
		*/
		public function GetItemHasFeaturesAsFeatureArray($objOptionalClauses = null) {
			if ((is_null($this->intIdfeatures)))
				return array();

			try {
				return ItemHasFeatures::LoadArrayByFeature($this->intIdfeatures, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ItemHasFeaturesesAsFeature
		 * @return int
		*/
		public function CountItemHasFeaturesesAsFeature() {
			if ((is_null($this->intIdfeatures)))
				return 0;

			return ItemHasFeatures::CountByFeature($this->intIdfeatures);
		}

		/**
		 * Associates a ItemHasFeaturesAsFeature
		 * @param ItemHasFeatures $objItemHasFeatures
		 * @return void
		*/
		public function AssociateItemHasFeaturesAsFeature(ItemHasFeatures $objItemHasFeatures) {
			if ((is_null($this->intIdfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateItemHasFeaturesAsFeature on this unsaved Features.');
			if ((is_null($objItemHasFeatures->IditemHasFeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateItemHasFeaturesAsFeature on this Features with an unsaved ItemHasFeatures.');

			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`item_has_features`
				SET
					`feature` = ' . $objDatabase->SqlVariable($this->intIdfeatures) . '
				WHERE
					`iditem_has_features` = ' . $objDatabase->SqlVariable($objItemHasFeatures->IditemHasFeatures) . '
			');
		}

		/**
		 * Unassociates a ItemHasFeaturesAsFeature
		 * @param ItemHasFeatures $objItemHasFeatures
		 * @return void
		*/
		public function UnassociateItemHasFeaturesAsFeature(ItemHasFeatures $objItemHasFeatures) {
			if ((is_null($this->intIdfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateItemHasFeaturesAsFeature on this unsaved Features.');
			if ((is_null($objItemHasFeatures->IditemHasFeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateItemHasFeaturesAsFeature on this Features with an unsaved ItemHasFeatures.');

			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`item_has_features`
				SET
					`feature` = null
				WHERE
					`iditem_has_features` = ' . $objDatabase->SqlVariable($objItemHasFeatures->IditemHasFeatures) . ' AND
					`feature` = ' . $objDatabase->SqlVariable($this->intIdfeatures) . '
			');
		}

		/**
		 * Unassociates all ItemHasFeaturesesAsFeature
		 * @return void
		*/
		public function UnassociateAllItemHasFeaturesesAsFeature() {
			if ((is_null($this->intIdfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateItemHasFeaturesAsFeature on this unsaved Features.');

			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`item_has_features`
				SET
					`feature` = null
				WHERE
					`feature` = ' . $objDatabase->SqlVariable($this->intIdfeatures) . '
			');
		}

		/**
		 * Deletes an associated ItemHasFeaturesAsFeature
		 * @param ItemHasFeatures $objItemHasFeatures
		 * @return void
		*/
		public function DeleteAssociatedItemHasFeaturesAsFeature(ItemHasFeatures $objItemHasFeatures) {
			if ((is_null($this->intIdfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateItemHasFeaturesAsFeature on this unsaved Features.');
			if ((is_null($objItemHasFeatures->IditemHasFeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateItemHasFeaturesAsFeature on this Features with an unsaved ItemHasFeatures.');

			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`item_has_features`
				WHERE
					`iditem_has_features` = ' . $objDatabase->SqlVariable($objItemHasFeatures->IditemHasFeatures) . ' AND
					`feature` = ' . $objDatabase->SqlVariable($this->intIdfeatures) . '
			');
		}

		/**
		 * Deletes all associated ItemHasFeaturesesAsFeature
		 * @return void
		*/
		public function DeleteAllItemHasFeaturesesAsFeature() {
			if ((is_null($this->intIdfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateItemHasFeaturesAsFeature on this unsaved Features.');

			// Get the Database Object for this Class
			$objDatabase = Features::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`item_has_features`
				WHERE
					`feature` = ' . $objDatabase->SqlVariable($this->intIdfeatures) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "features";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Features::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Features"><sequence>';
			$strToReturn .= '<element name="Idfeatures" type="xsd:int"/>';
			$strToReturn .= '<element name="Date" type="xsd:string"/>';
			$strToReturn .= '<element name="GrpObject" type="xsd1:FeatureGrp"/>';
			$strToReturn .= '<element name="Title" type="xsd:string"/>';
			$strToReturn .= '<element name="Data" type="xsd:string"/>';
			$strToReturn .= '<element name="ParrentObject" type="xsd1:Features"/>';
			$strToReturn .= '<element name="Counter" type="xsd:int"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Features', $strComplexTypeArray)) {
				$strComplexTypeArray['Features'] = Features::GetSoapComplexTypeXml();
				FeatureGrp::AlterSoapComplexTypeArray($strComplexTypeArray);
				Features::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Features::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Features();
			if (property_exists($objSoapObject, 'Idfeatures'))
				$objToReturn->intIdfeatures = $objSoapObject->Idfeatures;
			if (property_exists($objSoapObject, 'Date'))
				$objToReturn->strDate = $objSoapObject->Date;
			if ((property_exists($objSoapObject, 'GrpObject')) &&
				($objSoapObject->GrpObject))
				$objToReturn->GrpObject = FeatureGrp::GetObjectFromSoapObject($objSoapObject->GrpObject);
			if (property_exists($objSoapObject, 'Title'))
				$objToReturn->strTitle = $objSoapObject->Title;
			if (property_exists($objSoapObject, 'Data'))
				$objToReturn->strData = $objSoapObject->Data;
			if ((property_exists($objSoapObject, 'ParrentObject')) &&
				($objSoapObject->ParrentObject))
				$objToReturn->ParrentObject = Features::GetObjectFromSoapObject($objSoapObject->ParrentObject);
			if (property_exists($objSoapObject, 'Counter'))
				$objToReturn->intCounter = $objSoapObject->Counter;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Features::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objGrpObject)
				$objObject->objGrpObject = FeatureGrp::GetSoapObjectFromObject($objObject->objGrpObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intGrp = null;
			if ($objObject->objParrentObject)
				$objObject->objParrentObject = Features::GetSoapObjectFromObject($objObject->objParrentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intParrent = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idfeatures'] = $this->intIdfeatures;
			$iArray['Date'] = $this->strDate;
			$iArray['Grp'] = $this->intGrp;
			$iArray['Title'] = $this->strTitle;
			$iArray['Data'] = $this->strData;
			$iArray['Parrent'] = $this->intParrent;
			$iArray['Counter'] = $this->intCounter;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdfeatures ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idfeatures
     * @property-read QQNode $Date
     * @property-read QQNode $Grp
     * @property-read QQNodeFeatureGrp $GrpObject
     * @property-read QQNode $Title
     * @property-read QQNode $Data
     * @property-read QQNode $Parrent
     * @property-read QQNodeFeatures $ParrentObject
     * @property-read QQNode $Counter
     *
     *
     * @property-read QQReverseReferenceNodeFeatures $FeaturesAsParrent
     * @property-read QQReverseReferenceNodeItemHasFeatures $ItemHasFeaturesAsFeature

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeFeatures extends QQNode {
		protected $strTableName = 'features';
		protected $strPrimaryKey = 'idfeatures';
		protected $strClassName = 'Features';
		public function __get($strName) {
			switch ($strName) {
				case 'Idfeatures':
					return new QQNode('idfeatures', 'Idfeatures', 'Integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'VarChar', $this);
				case 'Grp':
					return new QQNode('grp', 'Grp', 'Integer', $this);
				case 'GrpObject':
					return new QQNodeFeatureGrp('grp', 'GrpObject', 'Integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'VarChar', $this);
				case 'Data':
					return new QQNode('data', 'Data', 'Blob', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'Integer', $this);
				case 'ParrentObject':
					return new QQNodeFeatures('parrent', 'ParrentObject', 'Integer', $this);
				case 'Counter':
					return new QQNode('counter', 'Counter', 'Integer', $this);
				case 'FeaturesAsParrent':
					return new QQReverseReferenceNodeFeatures($this, 'featuresasparrent', 'reverse_reference', 'parrent');
				case 'ItemHasFeaturesAsFeature':
					return new QQReverseReferenceNodeItemHasFeatures($this, 'itemhasfeaturesasfeature', 'reverse_reference', 'feature');

				case '_PrimaryKeyNode':
					return new QQNode('idfeatures', 'Idfeatures', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idfeatures
     * @property-read QQNode $Date
     * @property-read QQNode $Grp
     * @property-read QQNodeFeatureGrp $GrpObject
     * @property-read QQNode $Title
     * @property-read QQNode $Data
     * @property-read QQNode $Parrent
     * @property-read QQNodeFeatures $ParrentObject
     * @property-read QQNode $Counter
     *
     *
     * @property-read QQReverseReferenceNodeFeatures $FeaturesAsParrent
     * @property-read QQReverseReferenceNodeItemHasFeatures $ItemHasFeaturesAsFeature

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeFeatures extends QQReverseReferenceNode {
		protected $strTableName = 'features';
		protected $strPrimaryKey = 'idfeatures';
		protected $strClassName = 'Features';
		public function __get($strName) {
			switch ($strName) {
				case 'Idfeatures':
					return new QQNode('idfeatures', 'Idfeatures', 'integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'string', $this);
				case 'Grp':
					return new QQNode('grp', 'Grp', 'integer', $this);
				case 'GrpObject':
					return new QQNodeFeatureGrp('grp', 'GrpObject', 'integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'string', $this);
				case 'Data':
					return new QQNode('data', 'Data', 'string', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'integer', $this);
				case 'ParrentObject':
					return new QQNodeFeatures('parrent', 'ParrentObject', 'integer', $this);
				case 'Counter':
					return new QQNode('counter', 'Counter', 'integer', $this);
				case 'FeaturesAsParrent':
					return new QQReverseReferenceNodeFeatures($this, 'featuresasparrent', 'reverse_reference', 'parrent');
				case 'ItemHasFeaturesAsFeature':
					return new QQReverseReferenceNodeItemHasFeatures($this, 'itemhasfeaturesasfeature', 'reverse_reference', 'feature');

				case '_PrimaryKeyNode':
					return new QQNode('idfeatures', 'Idfeatures', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
