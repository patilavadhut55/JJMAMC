<?php
	/**
	 * The abstract OccupyByGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the OccupyBy subclass which
	 * extends this OccupyByGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the OccupyBy class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdoccupyBy the value for intIdoccupyBy (Read-Only PK)
	 * @property integer $BlockDetails the value for intBlockDetails (Not Null)
	 * @property integer $Student the value for intStudent (Not Null)
	 * @property QDateTime $Date the value for dttDate 
	 * @property QDateTime $Fromdate the value for dttFromdate 
	 * @property QDateTime $Todate the value for dttTodate 
	 * @property integer $Subject the value for intSubject 
	 * @property BlockDetails $BlockDetailsObject the value for the BlockDetails object referenced by intBlockDetails (Not Null)
	 * @property CurrentStatus $StudentObject the value for the CurrentStatus object referenced by intStudent (Not Null)
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class OccupyByGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column occupy_by.idoccupy_by
		 * @var integer intIdoccupyBy
		 */
		protected $intIdoccupyBy;
		const IdoccupyByDefault = null;


		/**
		 * Protected member variable that maps to the database column occupy_by.block_details
		 * @var integer intBlockDetails
		 */
		protected $intBlockDetails;
		const BlockDetailsDefault = null;


		/**
		 * Protected member variable that maps to the database column occupy_by.student
		 * @var integer intStudent
		 */
		protected $intStudent;
		const StudentDefault = null;


		/**
		 * Protected member variable that maps to the database column occupy_by.date
		 * @var QDateTime dttDate
		 */
		protected $dttDate;
		const DateDefault = null;


		/**
		 * Protected member variable that maps to the database column occupy_by.fromdate
		 * @var QDateTime dttFromdate
		 */
		protected $dttFromdate;
		const FromdateDefault = null;


		/**
		 * Protected member variable that maps to the database column occupy_by.todate
		 * @var QDateTime dttTodate
		 */
		protected $dttTodate;
		const TodateDefault = null;


		/**
		 * Protected member variable that maps to the database column occupy_by.subject
		 * @var integer intSubject
		 */
		protected $intSubject;
		const SubjectDefault = null;


		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column occupy_by.block_details.
		 *
		 * NOTE: Always use the BlockDetailsObject property getter to correctly retrieve this BlockDetails object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var BlockDetails objBlockDetailsObject
		 */
		protected $objBlockDetailsObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column occupy_by.student.
		 *
		 * NOTE: Always use the StudentObject property getter to correctly retrieve this CurrentStatus object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var CurrentStatus objStudentObject
		 */
		protected $objStudentObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdoccupyBy = OccupyBy::IdoccupyByDefault;
			$this->intBlockDetails = OccupyBy::BlockDetailsDefault;
			$this->intStudent = OccupyBy::StudentDefault;
			$this->dttDate = (OccupyBy::DateDefault === null)?null:new QDateTime(OccupyBy::DateDefault);
			$this->dttFromdate = (OccupyBy::FromdateDefault === null)?null:new QDateTime(OccupyBy::FromdateDefault);
			$this->dttTodate = (OccupyBy::TodateDefault === null)?null:new QDateTime(OccupyBy::TodateDefault);
			$this->intSubject = OccupyBy::SubjectDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a OccupyBy from PK Info
		 * @param integer $intIdoccupyBy
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return OccupyBy
		 */
		public static function Load($intIdoccupyBy, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'OccupyBy', $intIdoccupyBy);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = OccupyBy::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::OccupyBy()->IdoccupyBy, $intIdoccupyBy)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all OccupyBies
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return OccupyBy[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call OccupyBy::QueryArray to perform the LoadAll query
			try {
				return OccupyBy::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all OccupyBies
		 * @return int
		 */
		public static function CountAll() {
			// Call OccupyBy::QueryCount to perform the CountAll query
			return OccupyBy::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = OccupyBy::GetDatabase();

			// Create/Build out the QueryBuilder object with OccupyBy-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'occupy_by');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				OccupyBy::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('occupy_by');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single OccupyBy object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return OccupyBy the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = OccupyBy::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new OccupyBy object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = OccupyBy::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return OccupyBy::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of OccupyBy objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return OccupyBy[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = OccupyBy::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return OccupyBy::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = OccupyBy::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of OccupyBy objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = OccupyBy::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = OccupyBy::GetDatabase();

			$strQuery = OccupyBy::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/occupyby', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = OccupyBy::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this OccupyBy
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'occupy_by';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idoccupy_by', $strAliasPrefix . 'idoccupy_by');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idoccupy_by', $strAliasPrefix . 'idoccupy_by');
			    $objBuilder->AddSelectItem($strTableName, 'block_details', $strAliasPrefix . 'block_details');
			    $objBuilder->AddSelectItem($strTableName, 'student', $strAliasPrefix . 'student');
			    $objBuilder->AddSelectItem($strTableName, 'date', $strAliasPrefix . 'date');
			    $objBuilder->AddSelectItem($strTableName, 'fromdate', $strAliasPrefix . 'fromdate');
			    $objBuilder->AddSelectItem($strTableName, 'todate', $strAliasPrefix . 'todate');
			    $objBuilder->AddSelectItem($strTableName, 'subject', $strAliasPrefix . 'subject');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a OccupyBy from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this OccupyBy::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return OccupyBy
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}

			// Create a new instance of the OccupyBy object
			$objToReturn = new OccupyBy();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idoccupy_by';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdoccupyBy = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'block_details';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intBlockDetails = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'student';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intStudent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'fromdate';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttFromdate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'todate';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttTodate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSubject = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdoccupyBy != $objPreviousItem->IdoccupyBy) {
						continue;
					}

					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'occupy_by__';

			// Check for BlockDetailsObject Early Binding
			$strAlias = $strAliasPrefix . 'block_details__idblock_details';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objBlockDetailsObject = BlockDetails::InstantiateDbRow($objDbRow, $strAliasPrefix . 'block_details__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for StudentObject Early Binding
			$strAlias = $strAliasPrefix . 'student__idcurrent_status';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objStudentObject = CurrentStatus::InstantiateDbRow($objDbRow, $strAliasPrefix . 'student__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			return $objToReturn;
		}

		/**
		 * Instantiate an array of OccupyBies from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return OccupyBy[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = OccupyBy::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = OccupyBy::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single OccupyBy object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return OccupyBy next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return OccupyBy::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single OccupyBy object,
		 * by IdoccupyBy Index(es)
		 * @param integer $intIdoccupyBy
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return OccupyBy
		*/
		public static function LoadByIdoccupyBy($intIdoccupyBy, $objOptionalClauses = null) {
			return OccupyBy::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::OccupyBy()->IdoccupyBy, $intIdoccupyBy)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of OccupyBy objects,
		 * by BlockDetails Index(es)
		 * @param integer $intBlockDetails
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return OccupyBy[]
		*/
		public static function LoadArrayByBlockDetails($intBlockDetails, $objOptionalClauses = null) {
			// Call OccupyBy::QueryArray to perform the LoadArrayByBlockDetails query
			try {
				return OccupyBy::QueryArray(
					QQ::Equal(QQN::OccupyBy()->BlockDetails, $intBlockDetails),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count OccupyBies
		 * by BlockDetails Index(es)
		 * @param integer $intBlockDetails
		 * @return int
		*/
		public static function CountByBlockDetails($intBlockDetails) {
			// Call OccupyBy::QueryCount to perform the CountByBlockDetails query
			return OccupyBy::QueryCount(
				QQ::Equal(QQN::OccupyBy()->BlockDetails, $intBlockDetails)
			);
		}

		/**
		 * Load an array of OccupyBy objects,
		 * by Student Index(es)
		 * @param integer $intStudent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return OccupyBy[]
		*/
		public static function LoadArrayByStudent($intStudent, $objOptionalClauses = null) {
			// Call OccupyBy::QueryArray to perform the LoadArrayByStudent query
			try {
				return OccupyBy::QueryArray(
					QQ::Equal(QQN::OccupyBy()->Student, $intStudent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count OccupyBies
		 * by Student Index(es)
		 * @param integer $intStudent
		 * @return int
		*/
		public static function CountByStudent($intStudent) {
			// Call OccupyBy::QueryCount to perform the CountByStudent query
			return OccupyBy::QueryCount(
				QQ::Equal(QQN::OccupyBy()->Student, $intStudent)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this OccupyBy
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = OccupyBy::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `occupy_by` (
							`block_details`,
							`student`,
							`date`,
							`fromdate`,
							`todate`,
							`subject`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intBlockDetails) . ',
							' . $objDatabase->SqlVariable($this->intStudent) . ',
							' . $objDatabase->SqlVariable($this->dttDate) . ',
							' . $objDatabase->SqlVariable($this->dttFromdate) . ',
							' . $objDatabase->SqlVariable($this->dttTodate) . ',
							' . $objDatabase->SqlVariable($this->intSubject) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdoccupyBy = $objDatabase->InsertId('occupy_by', 'idoccupy_by');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`occupy_by`
						SET
							`block_details` = ' . $objDatabase->SqlVariable($this->intBlockDetails) . ',
							`student` = ' . $objDatabase->SqlVariable($this->intStudent) . ',
							`date` = ' . $objDatabase->SqlVariable($this->dttDate) . ',
							`fromdate` = ' . $objDatabase->SqlVariable($this->dttFromdate) . ',
							`todate` = ' . $objDatabase->SqlVariable($this->dttTodate) . ',
							`subject` = ' . $objDatabase->SqlVariable($this->intSubject) . '
						WHERE
							`idoccupy_by` = ' . $objDatabase->SqlVariable($this->intIdoccupyBy) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this OccupyBy
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdoccupyBy)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this OccupyBy with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = OccupyBy::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`occupy_by`
				WHERE
					`idoccupy_by` = ' . $objDatabase->SqlVariable($this->intIdoccupyBy) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this OccupyBy ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'OccupyBy', $this->intIdoccupyBy);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all OccupyBies
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = OccupyBy::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`occupy_by`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate occupy_by table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = OccupyBy::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `occupy_by`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this OccupyBy from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved OccupyBy object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = OccupyBy::Load($this->intIdoccupyBy);

			// Update $this's local variables to match
			$this->BlockDetails = $objReloaded->BlockDetails;
			$this->Student = $objReloaded->Student;
			$this->dttDate = $objReloaded->dttDate;
			$this->dttFromdate = $objReloaded->dttFromdate;
			$this->dttTodate = $objReloaded->dttTodate;
			$this->intSubject = $objReloaded->intSubject;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdoccupyBy':
					/**
					 * Gets the value for intIdoccupyBy (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdoccupyBy;

				case 'BlockDetails':
					/**
					 * Gets the value for intBlockDetails (Not Null)
					 * @return integer
					 */
					return $this->intBlockDetails;

				case 'Student':
					/**
					 * Gets the value for intStudent (Not Null)
					 * @return integer
					 */
					return $this->intStudent;

				case 'Date':
					/**
					 * Gets the value for dttDate 
					 * @return QDateTime
					 */
					return $this->dttDate;

				case 'Fromdate':
					/**
					 * Gets the value for dttFromdate 
					 * @return QDateTime
					 */
					return $this->dttFromdate;

				case 'Todate':
					/**
					 * Gets the value for dttTodate 
					 * @return QDateTime
					 */
					return $this->dttTodate;

				case 'Subject':
					/**
					 * Gets the value for intSubject 
					 * @return integer
					 */
					return $this->intSubject;


				///////////////////
				// Member Objects
				///////////////////
				case 'BlockDetailsObject':
					/**
					 * Gets the value for the BlockDetails object referenced by intBlockDetails (Not Null)
					 * @return BlockDetails
					 */
					try {
						if ((!$this->objBlockDetailsObject) && (!is_null($this->intBlockDetails)))
							$this->objBlockDetailsObject = BlockDetails::Load($this->intBlockDetails);
						return $this->objBlockDetailsObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'StudentObject':
					/**
					 * Gets the value for the CurrentStatus object referenced by intStudent (Not Null)
					 * @return CurrentStatus
					 */
					try {
						if ((!$this->objStudentObject) && (!is_null($this->intStudent)))
							$this->objStudentObject = CurrentStatus::Load($this->intStudent);
						return $this->objStudentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'BlockDetails':
					/**
					 * Sets the value for intBlockDetails (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objBlockDetailsObject = null;
						return ($this->intBlockDetails = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Student':
					/**
					 * Sets the value for intStudent (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objStudentObject = null;
						return ($this->intStudent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Date':
					/**
					 * Sets the value for dttDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Fromdate':
					/**
					 * Sets the value for dttFromdate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttFromdate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Todate':
					/**
					 * Sets the value for dttTodate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttTodate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Subject':
					/**
					 * Sets the value for intSubject 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intSubject = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'BlockDetailsObject':
					/**
					 * Sets the value for the BlockDetails object referenced by intBlockDetails (Not Null)
					 * @param BlockDetails $mixValue
					 * @return BlockDetails
					 */
					if (is_null($mixValue)) {
						$this->intBlockDetails = null;
						$this->objBlockDetailsObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a BlockDetails object
						try {
							$mixValue = QType::Cast($mixValue, 'BlockDetails');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED BlockDetails object
						if (is_null($mixValue->IdblockDetails))
							throw new QCallerException('Unable to set an unsaved BlockDetailsObject for this OccupyBy');

						// Update Local Member Variables
						$this->objBlockDetailsObject = $mixValue;
						$this->intBlockDetails = $mixValue->IdblockDetails;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'StudentObject':
					/**
					 * Sets the value for the CurrentStatus object referenced by intStudent (Not Null)
					 * @param CurrentStatus $mixValue
					 * @return CurrentStatus
					 */
					if (is_null($mixValue)) {
						$this->intStudent = null;
						$this->objStudentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a CurrentStatus object
						try {
							$mixValue = QType::Cast($mixValue, 'CurrentStatus');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED CurrentStatus object
						if (is_null($mixValue->IdcurrentStatus))
							throw new QCallerException('Unable to set an unsaved StudentObject for this OccupyBy');

						// Update Local Member Variables
						$this->objStudentObject = $mixValue;
						$this->intStudent = $mixValue->IdcurrentStatus;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "occupy_by";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[OccupyBy::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="OccupyBy"><sequence>';
			$strToReturn .= '<element name="IdoccupyBy" type="xsd:int"/>';
			$strToReturn .= '<element name="BlockDetailsObject" type="xsd1:BlockDetails"/>';
			$strToReturn .= '<element name="StudentObject" type="xsd1:CurrentStatus"/>';
			$strToReturn .= '<element name="Date" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Fromdate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Todate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Subject" type="xsd:int"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('OccupyBy', $strComplexTypeArray)) {
				$strComplexTypeArray['OccupyBy'] = OccupyBy::GetSoapComplexTypeXml();
				BlockDetails::AlterSoapComplexTypeArray($strComplexTypeArray);
				CurrentStatus::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, OccupyBy::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new OccupyBy();
			if (property_exists($objSoapObject, 'IdoccupyBy'))
				$objToReturn->intIdoccupyBy = $objSoapObject->IdoccupyBy;
			if ((property_exists($objSoapObject, 'BlockDetailsObject')) &&
				($objSoapObject->BlockDetailsObject))
				$objToReturn->BlockDetailsObject = BlockDetails::GetObjectFromSoapObject($objSoapObject->BlockDetailsObject);
			if ((property_exists($objSoapObject, 'StudentObject')) &&
				($objSoapObject->StudentObject))
				$objToReturn->StudentObject = CurrentStatus::GetObjectFromSoapObject($objSoapObject->StudentObject);
			if (property_exists($objSoapObject, 'Date'))
				$objToReturn->dttDate = new QDateTime($objSoapObject->Date);
			if (property_exists($objSoapObject, 'Fromdate'))
				$objToReturn->dttFromdate = new QDateTime($objSoapObject->Fromdate);
			if (property_exists($objSoapObject, 'Todate'))
				$objToReturn->dttTodate = new QDateTime($objSoapObject->Todate);
			if (property_exists($objSoapObject, 'Subject'))
				$objToReturn->intSubject = $objSoapObject->Subject;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, OccupyBy::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objBlockDetailsObject)
				$objObject->objBlockDetailsObject = BlockDetails::GetSoapObjectFromObject($objObject->objBlockDetailsObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intBlockDetails = null;
			if ($objObject->objStudentObject)
				$objObject->objStudentObject = CurrentStatus::GetSoapObjectFromObject($objObject->objStudentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intStudent = null;
			if ($objObject->dttDate)
				$objObject->dttDate = $objObject->dttDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttFromdate)
				$objObject->dttFromdate = $objObject->dttFromdate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttTodate)
				$objObject->dttTodate = $objObject->dttTodate->qFormat(QDateTime::FormatSoap);
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdoccupyBy'] = $this->intIdoccupyBy;
			$iArray['BlockDetails'] = $this->intBlockDetails;
			$iArray['Student'] = $this->intStudent;
			$iArray['Date'] = $this->dttDate;
			$iArray['Fromdate'] = $this->dttFromdate;
			$iArray['Todate'] = $this->dttTodate;
			$iArray['Subject'] = $this->intSubject;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdoccupyBy ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdoccupyBy
     * @property-read QQNode $BlockDetails
     * @property-read QQNodeBlockDetails $BlockDetailsObject
     * @property-read QQNode $Student
     * @property-read QQNodeCurrentStatus $StudentObject
     * @property-read QQNode $Date
     * @property-read QQNode $Fromdate
     * @property-read QQNode $Todate
     * @property-read QQNode $Subject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeOccupyBy extends QQNode {
		protected $strTableName = 'occupy_by';
		protected $strPrimaryKey = 'idoccupy_by';
		protected $strClassName = 'OccupyBy';
		public function __get($strName) {
			switch ($strName) {
				case 'IdoccupyBy':
					return new QQNode('idoccupy_by', 'IdoccupyBy', 'Integer', $this);
				case 'BlockDetails':
					return new QQNode('block_details', 'BlockDetails', 'Integer', $this);
				case 'BlockDetailsObject':
					return new QQNodeBlockDetails('block_details', 'BlockDetailsObject', 'Integer', $this);
				case 'Student':
					return new QQNode('student', 'Student', 'Integer', $this);
				case 'StudentObject':
					return new QQNodeCurrentStatus('student', 'StudentObject', 'Integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'DateTime', $this);
				case 'Fromdate':
					return new QQNode('fromdate', 'Fromdate', 'DateTime', $this);
				case 'Todate':
					return new QQNode('todate', 'Todate', 'DateTime', $this);
				case 'Subject':
					return new QQNode('subject', 'Subject', 'Integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idoccupy_by', 'IdoccupyBy', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdoccupyBy
     * @property-read QQNode $BlockDetails
     * @property-read QQNodeBlockDetails $BlockDetailsObject
     * @property-read QQNode $Student
     * @property-read QQNodeCurrentStatus $StudentObject
     * @property-read QQNode $Date
     * @property-read QQNode $Fromdate
     * @property-read QQNode $Todate
     * @property-read QQNode $Subject
     *
     *

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeOccupyBy extends QQReverseReferenceNode {
		protected $strTableName = 'occupy_by';
		protected $strPrimaryKey = 'idoccupy_by';
		protected $strClassName = 'OccupyBy';
		public function __get($strName) {
			switch ($strName) {
				case 'IdoccupyBy':
					return new QQNode('idoccupy_by', 'IdoccupyBy', 'integer', $this);
				case 'BlockDetails':
					return new QQNode('block_details', 'BlockDetails', 'integer', $this);
				case 'BlockDetailsObject':
					return new QQNodeBlockDetails('block_details', 'BlockDetailsObject', 'integer', $this);
				case 'Student':
					return new QQNode('student', 'Student', 'integer', $this);
				case 'StudentObject':
					return new QQNodeCurrentStatus('student', 'StudentObject', 'integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'QDateTime', $this);
				case 'Fromdate':
					return new QQNode('fromdate', 'Fromdate', 'QDateTime', $this);
				case 'Todate':
					return new QQNode('todate', 'Todate', 'QDateTime', $this);
				case 'Subject':
					return new QQNode('subject', 'Subject', 'integer', $this);

				case '_PrimaryKeyNode':
					return new QQNode('idoccupy_by', 'IdoccupyBy', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
