<?php
	/**
	 * The abstract GradeGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Grade subclass which
	 * extends this GradeGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Grade class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idgrade the value for intIdgrade (Read-Only PK)
	 * @property string $Name the value for strName (Not Null)
	 * @property integer $Max the value for intMax (Not Null)
	 * @property integer $Min the value for intMin (Not Null)
	 * @property string $Factor the value for strFactor 
	 * @property integer $Exp the value for intExp 
	 * @property integer $Grp the value for intGrp 
	 * @property string $Gradepoint the value for strGradepoint 
	 * @property string $LowerLimit the value for strLowerLimit 
	 * @property string $UpperLimit the value for strUpperLimit 
	 * @property string $StatTh the value for strStatTh 
	 * @property GradeGrp $GrpObject the value for the GradeGrp object referenced by intGrp 
	 * @property-read EventHasGrade $_EventHasGrade the value for the private _objEventHasGrade (Read-Only) if set due to an expansion on the event_has_grade.grade reverse relationship
	 * @property-read EventHasGrade[] $_EventHasGradeArray the value for the private _objEventHasGradeArray (Read-Only) if set due to an ExpandAsArray on the event_has_grade.grade reverse relationship
	 * @property-read GradeCard $_GradeCardAsRelative the value for the private _objGradeCardAsRelative (Read-Only) if set due to an expansion on the grade_card.relative_grade reverse relationship
	 * @property-read GradeCard[] $_GradeCardAsRelativeArray the value for the private _objGradeCardAsRelativeArray (Read-Only) if set due to an ExpandAsArray on the grade_card.relative_grade reverse relationship
	 * @property-read GradeCard $_GradeCardAsAbsolute the value for the private _objGradeCardAsAbsolute (Read-Only) if set due to an expansion on the grade_card.absolute_grade reverse relationship
	 * @property-read GradeCard[] $_GradeCardAsAbsoluteArray the value for the private _objGradeCardAsAbsoluteArray (Read-Only) if set due to an ExpandAsArray on the grade_card.absolute_grade reverse relationship
	 * @property-read GradeCard $_GradeCardAsPenalty the value for the private _objGradeCardAsPenalty (Read-Only) if set due to an expansion on the grade_card.penalty_grade reverse relationship
	 * @property-read GradeCard[] $_GradeCardAsPenaltyArray the value for the private _objGradeCardAsPenaltyArray (Read-Only) if set due to an ExpandAsArray on the grade_card.penalty_grade reverse relationship
	 * @property-read ReEvaluation $_ReEvaluationAsPrevious the value for the private _objReEvaluationAsPrevious (Read-Only) if set due to an expansion on the re_evaluation.previous_grade reverse relationship
	 * @property-read ReEvaluation[] $_ReEvaluationAsPreviousArray the value for the private _objReEvaluationAsPreviousArray (Read-Only) if set due to an ExpandAsArray on the re_evaluation.previous_grade reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class GradeGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column grade.idgrade
		 * @var integer intIdgrade
		 */
		protected $intIdgrade;
		const IdgradeDefault = null;


		/**
		 * Protected member variable that maps to the database column grade.name
		 * @var string strName
		 */
		protected $strName;
		const NameMaxLength = 45;
		const NameDefault = null;


		/**
		 * Protected member variable that maps to the database column grade.max
		 * @var integer intMax
		 */
		protected $intMax;
		const MaxDefault = null;


		/**
		 * Protected member variable that maps to the database column grade.min
		 * @var integer intMin
		 */
		protected $intMin;
		const MinDefault = null;


		/**
		 * Protected member variable that maps to the database column grade.factor
		 * @var string strFactor
		 */
		protected $strFactor;
		const FactorDefault = null;


		/**
		 * Protected member variable that maps to the database column grade.exp
		 * @var integer intExp
		 */
		protected $intExp;
		const ExpDefault = null;


		/**
		 * Protected member variable that maps to the database column grade.grp
		 * @var integer intGrp
		 */
		protected $intGrp;
		const GrpDefault = null;


		/**
		 * Protected member variable that maps to the database column grade.gradepoint
		 * @var string strGradepoint
		 */
		protected $strGradepoint;
		const GradepointMaxLength = 45;
		const GradepointDefault = null;


		/**
		 * Protected member variable that maps to the database column grade.lower_limit
		 * @var string strLowerLimit
		 */
		protected $strLowerLimit;
		const LowerLimitDefault = null;


		/**
		 * Protected member variable that maps to the database column grade.upper_limit
		 * @var string strUpperLimit
		 */
		protected $strUpperLimit;
		const UpperLimitDefault = null;


		/**
		 * Protected member variable that maps to the database column grade.stat_th
		 * @var string strStatTh
		 */
		protected $strStatTh;
		const StatThDefault = null;


		/**
		 * Private member variable that stores a reference to a single EventHasGrade object
		 * (of type EventHasGrade), if this Grade object was restored with
		 * an expansion on the event_has_grade association table.
		 * @var EventHasGrade _objEventHasGrade;
		 */
		private $_objEventHasGrade;

		/**
		 * Private member variable that stores a reference to an array of EventHasGrade objects
		 * (of type EventHasGrade[]), if this Grade object was restored with
		 * an ExpandAsArray on the event_has_grade association table.
		 * @var EventHasGrade[] _objEventHasGradeArray;
		 */
		private $_objEventHasGradeArray = null;

		/**
		 * Private member variable that stores a reference to a single GradeCardAsRelative object
		 * (of type GradeCard), if this Grade object was restored with
		 * an expansion on the grade_card association table.
		 * @var GradeCard _objGradeCardAsRelative;
		 */
		private $_objGradeCardAsRelative;

		/**
		 * Private member variable that stores a reference to an array of GradeCardAsRelative objects
		 * (of type GradeCard[]), if this Grade object was restored with
		 * an ExpandAsArray on the grade_card association table.
		 * @var GradeCard[] _objGradeCardAsRelativeArray;
		 */
		private $_objGradeCardAsRelativeArray = null;

		/**
		 * Private member variable that stores a reference to a single GradeCardAsAbsolute object
		 * (of type GradeCard), if this Grade object was restored with
		 * an expansion on the grade_card association table.
		 * @var GradeCard _objGradeCardAsAbsolute;
		 */
		private $_objGradeCardAsAbsolute;

		/**
		 * Private member variable that stores a reference to an array of GradeCardAsAbsolute objects
		 * (of type GradeCard[]), if this Grade object was restored with
		 * an ExpandAsArray on the grade_card association table.
		 * @var GradeCard[] _objGradeCardAsAbsoluteArray;
		 */
		private $_objGradeCardAsAbsoluteArray = null;

		/**
		 * Private member variable that stores a reference to a single GradeCardAsPenalty object
		 * (of type GradeCard), if this Grade object was restored with
		 * an expansion on the grade_card association table.
		 * @var GradeCard _objGradeCardAsPenalty;
		 */
		private $_objGradeCardAsPenalty;

		/**
		 * Private member variable that stores a reference to an array of GradeCardAsPenalty objects
		 * (of type GradeCard[]), if this Grade object was restored with
		 * an ExpandAsArray on the grade_card association table.
		 * @var GradeCard[] _objGradeCardAsPenaltyArray;
		 */
		private $_objGradeCardAsPenaltyArray = null;

		/**
		 * Private member variable that stores a reference to a single ReEvaluationAsPrevious object
		 * (of type ReEvaluation), if this Grade object was restored with
		 * an expansion on the re_evaluation association table.
		 * @var ReEvaluation _objReEvaluationAsPrevious;
		 */
		private $_objReEvaluationAsPrevious;

		/**
		 * Private member variable that stores a reference to an array of ReEvaluationAsPrevious objects
		 * (of type ReEvaluation[]), if this Grade object was restored with
		 * an ExpandAsArray on the re_evaluation association table.
		 * @var ReEvaluation[] _objReEvaluationAsPreviousArray;
		 */
		private $_objReEvaluationAsPreviousArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column grade.grp.
		 *
		 * NOTE: Always use the GrpObject property getter to correctly retrieve this GradeGrp object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var GradeGrp objGrpObject
		 */
		protected $objGrpObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdgrade = Grade::IdgradeDefault;
			$this->strName = Grade::NameDefault;
			$this->intMax = Grade::MaxDefault;
			$this->intMin = Grade::MinDefault;
			$this->strFactor = Grade::FactorDefault;
			$this->intExp = Grade::ExpDefault;
			$this->intGrp = Grade::GrpDefault;
			$this->strGradepoint = Grade::GradepointDefault;
			$this->strLowerLimit = Grade::LowerLimitDefault;
			$this->strUpperLimit = Grade::UpperLimitDefault;
			$this->strStatTh = Grade::StatThDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Grade from PK Info
		 * @param integer $intIdgrade
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Grade
		 */
		public static function Load($intIdgrade, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Grade', $intIdgrade);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Grade::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Grade()->Idgrade, $intIdgrade)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Grades
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Grade[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Grade::QueryArray to perform the LoadAll query
			try {
				return Grade::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Grades
		 * @return int
		 */
		public static function CountAll() {
			// Call Grade::QueryCount to perform the CountAll query
			return Grade::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Create/Build out the QueryBuilder object with Grade-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'grade');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Grade::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('grade');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Grade object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Grade the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Grade::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Grade object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Grade::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Grade::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Grade objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Grade[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Grade::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Grade::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Grade::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Grade objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Grade::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			$strQuery = Grade::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/grade', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Grade::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Grade
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'grade';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idgrade', $strAliasPrefix . 'idgrade');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idgrade', $strAliasPrefix . 'idgrade');
			    $objBuilder->AddSelectItem($strTableName, 'name', $strAliasPrefix . 'name');
			    $objBuilder->AddSelectItem($strTableName, 'max', $strAliasPrefix . 'max');
			    $objBuilder->AddSelectItem($strTableName, 'min', $strAliasPrefix . 'min');
			    $objBuilder->AddSelectItem($strTableName, 'factor', $strAliasPrefix . 'factor');
			    $objBuilder->AddSelectItem($strTableName, 'exp', $strAliasPrefix . 'exp');
			    $objBuilder->AddSelectItem($strTableName, 'grp', $strAliasPrefix . 'grp');
			    $objBuilder->AddSelectItem($strTableName, 'gradepoint', $strAliasPrefix . 'gradepoint');
			    $objBuilder->AddSelectItem($strTableName, 'lower_limit', $strAliasPrefix . 'lower_limit');
			    $objBuilder->AddSelectItem($strTableName, 'upper_limit', $strAliasPrefix . 'upper_limit');
			    $objBuilder->AddSelectItem($strTableName, 'stat_th', $strAliasPrefix . 'stat_th');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Grade from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Grade::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Grade
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idgrade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdgrade == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'grade__';


						// Expanding reverse references: EventHasGrade
						$strAlias = $strAliasPrefix . 'eventhasgrade__idevent_has_grade';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objEventHasGradeArray)
								$objPreviousItem->_objEventHasGradeArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objEventHasGradeArray)) {
								$objPreviousChildItems = $objPreviousItem->_objEventHasGradeArray;
								$objChildItem = EventHasGrade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasgrade__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objEventHasGradeArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objEventHasGradeArray[] = EventHasGrade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasgrade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: GradeCardAsRelative
						$strAlias = $strAliasPrefix . 'gradecardasrelative__idgrade_card';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objGradeCardAsRelativeArray)
								$objPreviousItem->_objGradeCardAsRelativeArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objGradeCardAsRelativeArray)) {
								$objPreviousChildItems = $objPreviousItem->_objGradeCardAsRelativeArray;
								$objChildItem = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasrelative__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objGradeCardAsRelativeArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objGradeCardAsRelativeArray[] = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasrelative__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: GradeCardAsAbsolute
						$strAlias = $strAliasPrefix . 'gradecardasabsolute__idgrade_card';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objGradeCardAsAbsoluteArray)
								$objPreviousItem->_objGradeCardAsAbsoluteArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objGradeCardAsAbsoluteArray)) {
								$objPreviousChildItems = $objPreviousItem->_objGradeCardAsAbsoluteArray;
								$objChildItem = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasabsolute__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objGradeCardAsAbsoluteArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objGradeCardAsAbsoluteArray[] = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasabsolute__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: GradeCardAsPenalty
						$strAlias = $strAliasPrefix . 'gradecardaspenalty__idgrade_card';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objGradeCardAsPenaltyArray)
								$objPreviousItem->_objGradeCardAsPenaltyArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objGradeCardAsPenaltyArray)) {
								$objPreviousChildItems = $objPreviousItem->_objGradeCardAsPenaltyArray;
								$objChildItem = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardaspenalty__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objGradeCardAsPenaltyArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objGradeCardAsPenaltyArray[] = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardaspenalty__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ReEvaluationAsPrevious
						$strAlias = $strAliasPrefix . 'reevaluationasprevious__idre_evaluation';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objReEvaluationAsPreviousArray)
								$objPreviousItem->_objReEvaluationAsPreviousArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objReEvaluationAsPreviousArray)) {
								$objPreviousChildItems = $objPreviousItem->_objReEvaluationAsPreviousArray;
								$objChildItem = ReEvaluation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'reevaluationasprevious__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objReEvaluationAsPreviousArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objReEvaluationAsPreviousArray[] = ReEvaluation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'reevaluationasprevious__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'grade__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Grade object
			$objToReturn = new Grade();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idgrade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdgrade = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'name';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strName = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'max';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMax = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'min';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMin = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'factor';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strFactor = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'exp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intExp = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intGrp = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'gradepoint';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strGradepoint = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'lower_limit';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strLowerLimit = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'upper_limit';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strUpperLimit = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'stat_th';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strStatTh = $objDbRow->GetColumn($strAliasName, 'VarChar');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idgrade != $objPreviousItem->Idgrade) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objEventHasGradeArray);
					$cnt = count($objToReturn->_objEventHasGradeArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objEventHasGradeArray, $objToReturn->_objEventHasGradeArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objGradeCardAsRelativeArray);
					$cnt = count($objToReturn->_objGradeCardAsRelativeArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objGradeCardAsRelativeArray, $objToReturn->_objGradeCardAsRelativeArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objGradeCardAsAbsoluteArray);
					$cnt = count($objToReturn->_objGradeCardAsAbsoluteArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objGradeCardAsAbsoluteArray, $objToReturn->_objGradeCardAsAbsoluteArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objGradeCardAsPenaltyArray);
					$cnt = count($objToReturn->_objGradeCardAsPenaltyArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objGradeCardAsPenaltyArray, $objToReturn->_objGradeCardAsPenaltyArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objReEvaluationAsPreviousArray);
					$cnt = count($objToReturn->_objReEvaluationAsPreviousArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objReEvaluationAsPreviousArray, $objToReturn->_objReEvaluationAsPreviousArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'grade__';

			// Check for GrpObject Early Binding
			$strAlias = $strAliasPrefix . 'grp__idgrade_grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objGrpObject = GradeGrp::InstantiateDbRow($objDbRow, $strAliasPrefix . 'grp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for EventHasGrade Virtual Binding
			$strAlias = $strAliasPrefix . 'eventhasgrade__idevent_has_grade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objEventHasGradeArray)
				$objToReturn->_objEventHasGradeArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objEventHasGradeArray[] = EventHasGrade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasgrade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objEventHasGrade = EventHasGrade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'eventhasgrade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for GradeCardAsRelative Virtual Binding
			$strAlias = $strAliasPrefix . 'gradecardasrelative__idgrade_card';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objGradeCardAsRelativeArray)
				$objToReturn->_objGradeCardAsRelativeArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objGradeCardAsRelativeArray[] = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasrelative__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objGradeCardAsRelative = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasrelative__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for GradeCardAsAbsolute Virtual Binding
			$strAlias = $strAliasPrefix . 'gradecardasabsolute__idgrade_card';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objGradeCardAsAbsoluteArray)
				$objToReturn->_objGradeCardAsAbsoluteArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objGradeCardAsAbsoluteArray[] = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasabsolute__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objGradeCardAsAbsolute = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasabsolute__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for GradeCardAsPenalty Virtual Binding
			$strAlias = $strAliasPrefix . 'gradecardaspenalty__idgrade_card';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objGradeCardAsPenaltyArray)
				$objToReturn->_objGradeCardAsPenaltyArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objGradeCardAsPenaltyArray[] = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardaspenalty__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objGradeCardAsPenalty = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardaspenalty__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ReEvaluationAsPrevious Virtual Binding
			$strAlias = $strAliasPrefix . 'reevaluationasprevious__idre_evaluation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objReEvaluationAsPreviousArray)
				$objToReturn->_objReEvaluationAsPreviousArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objReEvaluationAsPreviousArray[] = ReEvaluation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'reevaluationasprevious__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objReEvaluationAsPrevious = ReEvaluation::InstantiateDbRow($objDbRow, $strAliasPrefix . 'reevaluationasprevious__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Grades from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Grade[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Grade::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Grade::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Grade object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Grade next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Grade::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Grade object,
		 * by Idgrade Index(es)
		 * @param integer $intIdgrade
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Grade
		*/
		public static function LoadByIdgrade($intIdgrade, $objOptionalClauses = null) {
			return Grade::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Grade()->Idgrade, $intIdgrade)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Grade objects,
		 * by Grp Index(es)
		 * @param integer $intGrp
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Grade[]
		*/
		public static function LoadArrayByGrp($intGrp, $objOptionalClauses = null) {
			// Call Grade::QueryArray to perform the LoadArrayByGrp query
			try {
				return Grade::QueryArray(
					QQ::Equal(QQN::Grade()->Grp, $intGrp),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Grades
		 * by Grp Index(es)
		 * @param integer $intGrp
		 * @return int
		*/
		public static function CountByGrp($intGrp) {
			// Call Grade::QueryCount to perform the CountByGrp query
			return Grade::QueryCount(
				QQ::Equal(QQN::Grade()->Grp, $intGrp)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Grade
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `grade` (
							`name`,
							`max`,
							`min`,
							`factor`,
							`exp`,
							`grp`,
							`gradepoint`,
							`lower_limit`,
							`upper_limit`,
							`stat_th`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strName) . ',
							' . $objDatabase->SqlVariable($this->intMax) . ',
							' . $objDatabase->SqlVariable($this->intMin) . ',
							' . $objDatabase->SqlVariable($this->strFactor) . ',
							' . $objDatabase->SqlVariable($this->intExp) . ',
							' . $objDatabase->SqlVariable($this->intGrp) . ',
							' . $objDatabase->SqlVariable($this->strGradepoint) . ',
							' . $objDatabase->SqlVariable($this->strLowerLimit) . ',
							' . $objDatabase->SqlVariable($this->strUpperLimit) . ',
							' . $objDatabase->SqlVariable($this->strStatTh) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdgrade = $objDatabase->InsertId('grade', 'idgrade');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`grade`
						SET
							`name` = ' . $objDatabase->SqlVariable($this->strName) . ',
							`max` = ' . $objDatabase->SqlVariable($this->intMax) . ',
							`min` = ' . $objDatabase->SqlVariable($this->intMin) . ',
							`factor` = ' . $objDatabase->SqlVariable($this->strFactor) . ',
							`exp` = ' . $objDatabase->SqlVariable($this->intExp) . ',
							`grp` = ' . $objDatabase->SqlVariable($this->intGrp) . ',
							`gradepoint` = ' . $objDatabase->SqlVariable($this->strGradepoint) . ',
							`lower_limit` = ' . $objDatabase->SqlVariable($this->strLowerLimit) . ',
							`upper_limit` = ' . $objDatabase->SqlVariable($this->strUpperLimit) . ',
							`stat_th` = ' . $objDatabase->SqlVariable($this->strStatTh) . '
						WHERE
							`idgrade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Grade
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Grade with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade`
				WHERE
					`idgrade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Grade ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Grade', $this->intIdgrade);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Grades
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate grade table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `grade`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Grade from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Grade object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Grade::Load($this->intIdgrade);

			// Update $this's local variables to match
			$this->strName = $objReloaded->strName;
			$this->intMax = $objReloaded->intMax;
			$this->intMin = $objReloaded->intMin;
			$this->strFactor = $objReloaded->strFactor;
			$this->intExp = $objReloaded->intExp;
			$this->Grp = $objReloaded->Grp;
			$this->strGradepoint = $objReloaded->strGradepoint;
			$this->strLowerLimit = $objReloaded->strLowerLimit;
			$this->strUpperLimit = $objReloaded->strUpperLimit;
			$this->strStatTh = $objReloaded->strStatTh;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idgrade':
					/**
					 * Gets the value for intIdgrade (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdgrade;

				case 'Name':
					/**
					 * Gets the value for strName (Not Null)
					 * @return string
					 */
					return $this->strName;

				case 'Max':
					/**
					 * Gets the value for intMax (Not Null)
					 * @return integer
					 */
					return $this->intMax;

				case 'Min':
					/**
					 * Gets the value for intMin (Not Null)
					 * @return integer
					 */
					return $this->intMin;

				case 'Factor':
					/**
					 * Gets the value for strFactor 
					 * @return string
					 */
					return $this->strFactor;

				case 'Exp':
					/**
					 * Gets the value for intExp 
					 * @return integer
					 */
					return $this->intExp;

				case 'Grp':
					/**
					 * Gets the value for intGrp 
					 * @return integer
					 */
					return $this->intGrp;

				case 'Gradepoint':
					/**
					 * Gets the value for strGradepoint 
					 * @return string
					 */
					return $this->strGradepoint;

				case 'LowerLimit':
					/**
					 * Gets the value for strLowerLimit 
					 * @return string
					 */
					return $this->strLowerLimit;

				case 'UpperLimit':
					/**
					 * Gets the value for strUpperLimit 
					 * @return string
					 */
					return $this->strUpperLimit;

				case 'StatTh':
					/**
					 * Gets the value for strStatTh 
					 * @return string
					 */
					return $this->strStatTh;


				///////////////////
				// Member Objects
				///////////////////
				case 'GrpObject':
					/**
					 * Gets the value for the GradeGrp object referenced by intGrp 
					 * @return GradeGrp
					 */
					try {
						if ((!$this->objGrpObject) && (!is_null($this->intGrp)))
							$this->objGrpObject = GradeGrp::Load($this->intGrp);
						return $this->objGrpObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_EventHasGrade':
					/**
					 * Gets the value for the private _objEventHasGrade (Read-Only)
					 * if set due to an expansion on the event_has_grade.grade reverse relationship
					 * @return EventHasGrade
					 */
					return $this->_objEventHasGrade;

				case '_EventHasGradeArray':
					/**
					 * Gets the value for the private _objEventHasGradeArray (Read-Only)
					 * if set due to an ExpandAsArray on the event_has_grade.grade reverse relationship
					 * @return EventHasGrade[]
					 */
					return $this->_objEventHasGradeArray;

				case '_GradeCardAsRelative':
					/**
					 * Gets the value for the private _objGradeCardAsRelative (Read-Only)
					 * if set due to an expansion on the grade_card.relative_grade reverse relationship
					 * @return GradeCard
					 */
					return $this->_objGradeCardAsRelative;

				case '_GradeCardAsRelativeArray':
					/**
					 * Gets the value for the private _objGradeCardAsRelativeArray (Read-Only)
					 * if set due to an ExpandAsArray on the grade_card.relative_grade reverse relationship
					 * @return GradeCard[]
					 */
					return $this->_objGradeCardAsRelativeArray;

				case '_GradeCardAsAbsolute':
					/**
					 * Gets the value for the private _objGradeCardAsAbsolute (Read-Only)
					 * if set due to an expansion on the grade_card.absolute_grade reverse relationship
					 * @return GradeCard
					 */
					return $this->_objGradeCardAsAbsolute;

				case '_GradeCardAsAbsoluteArray':
					/**
					 * Gets the value for the private _objGradeCardAsAbsoluteArray (Read-Only)
					 * if set due to an ExpandAsArray on the grade_card.absolute_grade reverse relationship
					 * @return GradeCard[]
					 */
					return $this->_objGradeCardAsAbsoluteArray;

				case '_GradeCardAsPenalty':
					/**
					 * Gets the value for the private _objGradeCardAsPenalty (Read-Only)
					 * if set due to an expansion on the grade_card.penalty_grade reverse relationship
					 * @return GradeCard
					 */
					return $this->_objGradeCardAsPenalty;

				case '_GradeCardAsPenaltyArray':
					/**
					 * Gets the value for the private _objGradeCardAsPenaltyArray (Read-Only)
					 * if set due to an ExpandAsArray on the grade_card.penalty_grade reverse relationship
					 * @return GradeCard[]
					 */
					return $this->_objGradeCardAsPenaltyArray;

				case '_ReEvaluationAsPrevious':
					/**
					 * Gets the value for the private _objReEvaluationAsPrevious (Read-Only)
					 * if set due to an expansion on the re_evaluation.previous_grade reverse relationship
					 * @return ReEvaluation
					 */
					return $this->_objReEvaluationAsPrevious;

				case '_ReEvaluationAsPreviousArray':
					/**
					 * Gets the value for the private _objReEvaluationAsPreviousArray (Read-Only)
					 * if set due to an ExpandAsArray on the re_evaluation.previous_grade reverse relationship
					 * @return ReEvaluation[]
					 */
					return $this->_objReEvaluationAsPreviousArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Name':
					/**
					 * Sets the value for strName (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strName = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Max':
					/**
					 * Sets the value for intMax (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intMax = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Min':
					/**
					 * Sets the value for intMin (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intMin = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Factor':
					/**
					 * Sets the value for strFactor 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strFactor = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Exp':
					/**
					 * Sets the value for intExp 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intExp = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Grp':
					/**
					 * Sets the value for intGrp 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objGrpObject = null;
						return ($this->intGrp = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Gradepoint':
					/**
					 * Sets the value for strGradepoint 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strGradepoint = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'LowerLimit':
					/**
					 * Sets the value for strLowerLimit 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strLowerLimit = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'UpperLimit':
					/**
					 * Sets the value for strUpperLimit 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strUpperLimit = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'StatTh':
					/**
					 * Sets the value for strStatTh 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strStatTh = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'GrpObject':
					/**
					 * Sets the value for the GradeGrp object referenced by intGrp 
					 * @param GradeGrp $mixValue
					 * @return GradeGrp
					 */
					if (is_null($mixValue)) {
						$this->intGrp = null;
						$this->objGrpObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a GradeGrp object
						try {
							$mixValue = QType::Cast($mixValue, 'GradeGrp');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED GradeGrp object
						if (is_null($mixValue->IdgradeGrp))
							throw new QCallerException('Unable to set an unsaved GrpObject for this Grade');

						// Update Local Member Variables
						$this->objGrpObject = $mixValue;
						$this->intGrp = $mixValue->IdgradeGrp;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for EventHasGrade
		//-------------------------------------------------------------------

		/**
		 * Gets all associated EventHasGrades as an array of EventHasGrade objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return EventHasGrade[]
		*/
		public function GetEventHasGradeArray($objOptionalClauses = null) {
			if ((is_null($this->intIdgrade)))
				return array();

			try {
				return EventHasGrade::LoadArrayByGrade($this->intIdgrade, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated EventHasGrades
		 * @return int
		*/
		public function CountEventHasGrades() {
			if ((is_null($this->intIdgrade)))
				return 0;

			return EventHasGrade::CountByGrade($this->intIdgrade);
		}

		/**
		 * Associates a EventHasGrade
		 * @param EventHasGrade $objEventHasGrade
		 * @return void
		*/
		public function AssociateEventHasGrade(EventHasGrade $objEventHasGrade) {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEventHasGrade on this unsaved Grade.');
			if ((is_null($objEventHasGrade->IdeventHasGrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateEventHasGrade on this Grade with an unsaved EventHasGrade.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event_has_grade`
				SET
					`grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
				WHERE
					`idevent_has_grade` = ' . $objDatabase->SqlVariable($objEventHasGrade->IdeventHasGrade) . '
			');
		}

		/**
		 * Unassociates a EventHasGrade
		 * @param EventHasGrade $objEventHasGrade
		 * @return void
		*/
		public function UnassociateEventHasGrade(EventHasGrade $objEventHasGrade) {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this unsaved Grade.');
			if ((is_null($objEventHasGrade->IdeventHasGrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this Grade with an unsaved EventHasGrade.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event_has_grade`
				SET
					`grade` = null
				WHERE
					`idevent_has_grade` = ' . $objDatabase->SqlVariable($objEventHasGrade->IdeventHasGrade) . ' AND
					`grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}

		/**
		 * Unassociates all EventHasGrades
		 * @return void
		*/
		public function UnassociateAllEventHasGrades() {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this unsaved Grade.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`event_has_grade`
				SET
					`grade` = null
				WHERE
					`grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}

		/**
		 * Deletes an associated EventHasGrade
		 * @param EventHasGrade $objEventHasGrade
		 * @return void
		*/
		public function DeleteAssociatedEventHasGrade(EventHasGrade $objEventHasGrade) {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this unsaved Grade.');
			if ((is_null($objEventHasGrade->IdeventHasGrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this Grade with an unsaved EventHasGrade.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event_has_grade`
				WHERE
					`idevent_has_grade` = ' . $objDatabase->SqlVariable($objEventHasGrade->IdeventHasGrade) . ' AND
					`grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}

		/**
		 * Deletes all associated EventHasGrades
		 * @return void
		*/
		public function DeleteAllEventHasGrades() {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateEventHasGrade on this unsaved Grade.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`event_has_grade`
				WHERE
					`grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}


		// Related Objects' Methods for GradeCardAsRelative
		//-------------------------------------------------------------------

		/**
		 * Gets all associated GradeCardsAsRelative as an array of GradeCard objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		*/
		public function GetGradeCardAsRelativeArray($objOptionalClauses = null) {
			if ((is_null($this->intIdgrade)))
				return array();

			try {
				return GradeCard::LoadArrayByRelativeGrade($this->intIdgrade, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated GradeCardsAsRelative
		 * @return int
		*/
		public function CountGradeCardsAsRelative() {
			if ((is_null($this->intIdgrade)))
				return 0;

			return GradeCard::CountByRelativeGrade($this->intIdgrade);
		}

		/**
		 * Associates a GradeCardAsRelative
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function AssociateGradeCardAsRelative(GradeCard $objGradeCard) {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGradeCardAsRelative on this unsaved Grade.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGradeCardAsRelative on this Grade with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`relative_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . '
			');
		}

		/**
		 * Unassociates a GradeCardAsRelative
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function UnassociateGradeCardAsRelative(GradeCard $objGradeCard) {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsRelative on this unsaved Grade.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsRelative on this Grade with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`relative_grade` = null
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . ' AND
					`relative_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}

		/**
		 * Unassociates all GradeCardsAsRelative
		 * @return void
		*/
		public function UnassociateAllGradeCardsAsRelative() {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsRelative on this unsaved Grade.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`relative_grade` = null
				WHERE
					`relative_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}

		/**
		 * Deletes an associated GradeCardAsRelative
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function DeleteAssociatedGradeCardAsRelative(GradeCard $objGradeCard) {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsRelative on this unsaved Grade.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsRelative on this Grade with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . ' AND
					`relative_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}

		/**
		 * Deletes all associated GradeCardsAsRelative
		 * @return void
		*/
		public function DeleteAllGradeCardsAsRelative() {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsRelative on this unsaved Grade.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`
				WHERE
					`relative_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}


		// Related Objects' Methods for GradeCardAsAbsolute
		//-------------------------------------------------------------------

		/**
		 * Gets all associated GradeCardsAsAbsolute as an array of GradeCard objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		*/
		public function GetGradeCardAsAbsoluteArray($objOptionalClauses = null) {
			if ((is_null($this->intIdgrade)))
				return array();

			try {
				return GradeCard::LoadArrayByAbsoluteGrade($this->intIdgrade, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated GradeCardsAsAbsolute
		 * @return int
		*/
		public function CountGradeCardsAsAbsolute() {
			if ((is_null($this->intIdgrade)))
				return 0;

			return GradeCard::CountByAbsoluteGrade($this->intIdgrade);
		}

		/**
		 * Associates a GradeCardAsAbsolute
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function AssociateGradeCardAsAbsolute(GradeCard $objGradeCard) {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGradeCardAsAbsolute on this unsaved Grade.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGradeCardAsAbsolute on this Grade with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`absolute_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . '
			');
		}

		/**
		 * Unassociates a GradeCardAsAbsolute
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function UnassociateGradeCardAsAbsolute(GradeCard $objGradeCard) {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsAbsolute on this unsaved Grade.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsAbsolute on this Grade with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`absolute_grade` = null
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . ' AND
					`absolute_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}

		/**
		 * Unassociates all GradeCardsAsAbsolute
		 * @return void
		*/
		public function UnassociateAllGradeCardsAsAbsolute() {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsAbsolute on this unsaved Grade.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`absolute_grade` = null
				WHERE
					`absolute_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}

		/**
		 * Deletes an associated GradeCardAsAbsolute
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function DeleteAssociatedGradeCardAsAbsolute(GradeCard $objGradeCard) {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsAbsolute on this unsaved Grade.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsAbsolute on this Grade with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . ' AND
					`absolute_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}

		/**
		 * Deletes all associated GradeCardsAsAbsolute
		 * @return void
		*/
		public function DeleteAllGradeCardsAsAbsolute() {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsAbsolute on this unsaved Grade.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`
				WHERE
					`absolute_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}


		// Related Objects' Methods for GradeCardAsPenalty
		//-------------------------------------------------------------------

		/**
		 * Gets all associated GradeCardsAsPenalty as an array of GradeCard objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		*/
		public function GetGradeCardAsPenaltyArray($objOptionalClauses = null) {
			if ((is_null($this->intIdgrade)))
				return array();

			try {
				return GradeCard::LoadArrayByPenaltyGrade($this->intIdgrade, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated GradeCardsAsPenalty
		 * @return int
		*/
		public function CountGradeCardsAsPenalty() {
			if ((is_null($this->intIdgrade)))
				return 0;

			return GradeCard::CountByPenaltyGrade($this->intIdgrade);
		}

		/**
		 * Associates a GradeCardAsPenalty
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function AssociateGradeCardAsPenalty(GradeCard $objGradeCard) {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGradeCardAsPenalty on this unsaved Grade.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGradeCardAsPenalty on this Grade with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`penalty_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . '
			');
		}

		/**
		 * Unassociates a GradeCardAsPenalty
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function UnassociateGradeCardAsPenalty(GradeCard $objGradeCard) {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsPenalty on this unsaved Grade.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsPenalty on this Grade with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`penalty_grade` = null
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . ' AND
					`penalty_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}

		/**
		 * Unassociates all GradeCardsAsPenalty
		 * @return void
		*/
		public function UnassociateAllGradeCardsAsPenalty() {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsPenalty on this unsaved Grade.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`penalty_grade` = null
				WHERE
					`penalty_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}

		/**
		 * Deletes an associated GradeCardAsPenalty
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function DeleteAssociatedGradeCardAsPenalty(GradeCard $objGradeCard) {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsPenalty on this unsaved Grade.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsPenalty on this Grade with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . ' AND
					`penalty_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}

		/**
		 * Deletes all associated GradeCardsAsPenalty
		 * @return void
		*/
		public function DeleteAllGradeCardsAsPenalty() {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsPenalty on this unsaved Grade.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`
				WHERE
					`penalty_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}


		// Related Objects' Methods for ReEvaluationAsPrevious
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ReEvaluationsAsPrevious as an array of ReEvaluation objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ReEvaluation[]
		*/
		public function GetReEvaluationAsPreviousArray($objOptionalClauses = null) {
			if ((is_null($this->intIdgrade)))
				return array();

			try {
				return ReEvaluation::LoadArrayByPreviousGrade($this->intIdgrade, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ReEvaluationsAsPrevious
		 * @return int
		*/
		public function CountReEvaluationsAsPrevious() {
			if ((is_null($this->intIdgrade)))
				return 0;

			return ReEvaluation::CountByPreviousGrade($this->intIdgrade);
		}

		/**
		 * Associates a ReEvaluationAsPrevious
		 * @param ReEvaluation $objReEvaluation
		 * @return void
		*/
		public function AssociateReEvaluationAsPrevious(ReEvaluation $objReEvaluation) {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateReEvaluationAsPrevious on this unsaved Grade.');
			if ((is_null($objReEvaluation->IdreEvaluation)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateReEvaluationAsPrevious on this Grade with an unsaved ReEvaluation.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`re_evaluation`
				SET
					`previous_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
				WHERE
					`idre_evaluation` = ' . $objDatabase->SqlVariable($objReEvaluation->IdreEvaluation) . '
			');
		}

		/**
		 * Unassociates a ReEvaluationAsPrevious
		 * @param ReEvaluation $objReEvaluation
		 * @return void
		*/
		public function UnassociateReEvaluationAsPrevious(ReEvaluation $objReEvaluation) {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluationAsPrevious on this unsaved Grade.');
			if ((is_null($objReEvaluation->IdreEvaluation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluationAsPrevious on this Grade with an unsaved ReEvaluation.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`re_evaluation`
				SET
					`previous_grade` = null
				WHERE
					`idre_evaluation` = ' . $objDatabase->SqlVariable($objReEvaluation->IdreEvaluation) . ' AND
					`previous_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}

		/**
		 * Unassociates all ReEvaluationsAsPrevious
		 * @return void
		*/
		public function UnassociateAllReEvaluationsAsPrevious() {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluationAsPrevious on this unsaved Grade.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`re_evaluation`
				SET
					`previous_grade` = null
				WHERE
					`previous_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}

		/**
		 * Deletes an associated ReEvaluationAsPrevious
		 * @param ReEvaluation $objReEvaluation
		 * @return void
		*/
		public function DeleteAssociatedReEvaluationAsPrevious(ReEvaluation $objReEvaluation) {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluationAsPrevious on this unsaved Grade.');
			if ((is_null($objReEvaluation->IdreEvaluation)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluationAsPrevious on this Grade with an unsaved ReEvaluation.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`re_evaluation`
				WHERE
					`idre_evaluation` = ' . $objDatabase->SqlVariable($objReEvaluation->IdreEvaluation) . ' AND
					`previous_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}

		/**
		 * Deletes all associated ReEvaluationsAsPrevious
		 * @return void
		*/
		public function DeleteAllReEvaluationsAsPrevious() {
			if ((is_null($this->intIdgrade)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateReEvaluationAsPrevious on this unsaved Grade.');

			// Get the Database Object for this Class
			$objDatabase = Grade::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`re_evaluation`
				WHERE
					`previous_grade` = ' . $objDatabase->SqlVariable($this->intIdgrade) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "grade";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Grade::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Grade"><sequence>';
			$strToReturn .= '<element name="Idgrade" type="xsd:int"/>';
			$strToReturn .= '<element name="Name" type="xsd:string"/>';
			$strToReturn .= '<element name="Max" type="xsd:int"/>';
			$strToReturn .= '<element name="Min" type="xsd:int"/>';
			$strToReturn .= '<element name="Factor" type="xsd:string"/>';
			$strToReturn .= '<element name="Exp" type="xsd:int"/>';
			$strToReturn .= '<element name="GrpObject" type="xsd1:GradeGrp"/>';
			$strToReturn .= '<element name="Gradepoint" type="xsd:string"/>';
			$strToReturn .= '<element name="LowerLimit" type="xsd:string"/>';
			$strToReturn .= '<element name="UpperLimit" type="xsd:string"/>';
			$strToReturn .= '<element name="StatTh" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Grade', $strComplexTypeArray)) {
				$strComplexTypeArray['Grade'] = Grade::GetSoapComplexTypeXml();
				GradeGrp::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Grade::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Grade();
			if (property_exists($objSoapObject, 'Idgrade'))
				$objToReturn->intIdgrade = $objSoapObject->Idgrade;
			if (property_exists($objSoapObject, 'Name'))
				$objToReturn->strName = $objSoapObject->Name;
			if (property_exists($objSoapObject, 'Max'))
				$objToReturn->intMax = $objSoapObject->Max;
			if (property_exists($objSoapObject, 'Min'))
				$objToReturn->intMin = $objSoapObject->Min;
			if (property_exists($objSoapObject, 'Factor'))
				$objToReturn->strFactor = $objSoapObject->Factor;
			if (property_exists($objSoapObject, 'Exp'))
				$objToReturn->intExp = $objSoapObject->Exp;
			if ((property_exists($objSoapObject, 'GrpObject')) &&
				($objSoapObject->GrpObject))
				$objToReturn->GrpObject = GradeGrp::GetObjectFromSoapObject($objSoapObject->GrpObject);
			if (property_exists($objSoapObject, 'Gradepoint'))
				$objToReturn->strGradepoint = $objSoapObject->Gradepoint;
			if (property_exists($objSoapObject, 'LowerLimit'))
				$objToReturn->strLowerLimit = $objSoapObject->LowerLimit;
			if (property_exists($objSoapObject, 'UpperLimit'))
				$objToReturn->strUpperLimit = $objSoapObject->UpperLimit;
			if (property_exists($objSoapObject, 'StatTh'))
				$objToReturn->strStatTh = $objSoapObject->StatTh;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Grade::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objGrpObject)
				$objObject->objGrpObject = GradeGrp::GetSoapObjectFromObject($objObject->objGrpObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intGrp = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idgrade'] = $this->intIdgrade;
			$iArray['Name'] = $this->strName;
			$iArray['Max'] = $this->intMax;
			$iArray['Min'] = $this->intMin;
			$iArray['Factor'] = $this->strFactor;
			$iArray['Exp'] = $this->intExp;
			$iArray['Grp'] = $this->intGrp;
			$iArray['Gradepoint'] = $this->strGradepoint;
			$iArray['LowerLimit'] = $this->strLowerLimit;
			$iArray['UpperLimit'] = $this->strUpperLimit;
			$iArray['StatTh'] = $this->strStatTh;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdgrade ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idgrade
     * @property-read QQNode $Name
     * @property-read QQNode $Max
     * @property-read QQNode $Min
     * @property-read QQNode $Factor
     * @property-read QQNode $Exp
     * @property-read QQNode $Grp
     * @property-read QQNodeGradeGrp $GrpObject
     * @property-read QQNode $Gradepoint
     * @property-read QQNode $LowerLimit
     * @property-read QQNode $UpperLimit
     * @property-read QQNode $StatTh
     *
     *
     * @property-read QQReverseReferenceNodeEventHasGrade $EventHasGrade
     * @property-read QQReverseReferenceNodeGradeCard $GradeCardAsRelative
     * @property-read QQReverseReferenceNodeGradeCard $GradeCardAsAbsolute
     * @property-read QQReverseReferenceNodeGradeCard $GradeCardAsPenalty
     * @property-read QQReverseReferenceNodeReEvaluation $ReEvaluationAsPrevious

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeGrade extends QQNode {
		protected $strTableName = 'grade';
		protected $strPrimaryKey = 'idgrade';
		protected $strClassName = 'Grade';
		public function __get($strName) {
			switch ($strName) {
				case 'Idgrade':
					return new QQNode('idgrade', 'Idgrade', 'Integer', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'VarChar', $this);
				case 'Max':
					return new QQNode('max', 'Max', 'Integer', $this);
				case 'Min':
					return new QQNode('min', 'Min', 'Integer', $this);
				case 'Factor':
					return new QQNode('factor', 'Factor', 'VarChar', $this);
				case 'Exp':
					return new QQNode('exp', 'Exp', 'Integer', $this);
				case 'Grp':
					return new QQNode('grp', 'Grp', 'Integer', $this);
				case 'GrpObject':
					return new QQNodeGradeGrp('grp', 'GrpObject', 'Integer', $this);
				case 'Gradepoint':
					return new QQNode('gradepoint', 'Gradepoint', 'VarChar', $this);
				case 'LowerLimit':
					return new QQNode('lower_limit', 'LowerLimit', 'VarChar', $this);
				case 'UpperLimit':
					return new QQNode('upper_limit', 'UpperLimit', 'VarChar', $this);
				case 'StatTh':
					return new QQNode('stat_th', 'StatTh', 'VarChar', $this);
				case 'EventHasGrade':
					return new QQReverseReferenceNodeEventHasGrade($this, 'eventhasgrade', 'reverse_reference', 'grade');
				case 'GradeCardAsRelative':
					return new QQReverseReferenceNodeGradeCard($this, 'gradecardasrelative', 'reverse_reference', 'relative_grade');
				case 'GradeCardAsAbsolute':
					return new QQReverseReferenceNodeGradeCard($this, 'gradecardasabsolute', 'reverse_reference', 'absolute_grade');
				case 'GradeCardAsPenalty':
					return new QQReverseReferenceNodeGradeCard($this, 'gradecardaspenalty', 'reverse_reference', 'penalty_grade');
				case 'ReEvaluationAsPrevious':
					return new QQReverseReferenceNodeReEvaluation($this, 'reevaluationasprevious', 'reverse_reference', 'previous_grade');

				case '_PrimaryKeyNode':
					return new QQNode('idgrade', 'Idgrade', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idgrade
     * @property-read QQNode $Name
     * @property-read QQNode $Max
     * @property-read QQNode $Min
     * @property-read QQNode $Factor
     * @property-read QQNode $Exp
     * @property-read QQNode $Grp
     * @property-read QQNodeGradeGrp $GrpObject
     * @property-read QQNode $Gradepoint
     * @property-read QQNode $LowerLimit
     * @property-read QQNode $UpperLimit
     * @property-read QQNode $StatTh
     *
     *
     * @property-read QQReverseReferenceNodeEventHasGrade $EventHasGrade
     * @property-read QQReverseReferenceNodeGradeCard $GradeCardAsRelative
     * @property-read QQReverseReferenceNodeGradeCard $GradeCardAsAbsolute
     * @property-read QQReverseReferenceNodeGradeCard $GradeCardAsPenalty
     * @property-read QQReverseReferenceNodeReEvaluation $ReEvaluationAsPrevious

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeGrade extends QQReverseReferenceNode {
		protected $strTableName = 'grade';
		protected $strPrimaryKey = 'idgrade';
		protected $strClassName = 'Grade';
		public function __get($strName) {
			switch ($strName) {
				case 'Idgrade':
					return new QQNode('idgrade', 'Idgrade', 'integer', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'string', $this);
				case 'Max':
					return new QQNode('max', 'Max', 'integer', $this);
				case 'Min':
					return new QQNode('min', 'Min', 'integer', $this);
				case 'Factor':
					return new QQNode('factor', 'Factor', 'string', $this);
				case 'Exp':
					return new QQNode('exp', 'Exp', 'integer', $this);
				case 'Grp':
					return new QQNode('grp', 'Grp', 'integer', $this);
				case 'GrpObject':
					return new QQNodeGradeGrp('grp', 'GrpObject', 'integer', $this);
				case 'Gradepoint':
					return new QQNode('gradepoint', 'Gradepoint', 'string', $this);
				case 'LowerLimit':
					return new QQNode('lower_limit', 'LowerLimit', 'string', $this);
				case 'UpperLimit':
					return new QQNode('upper_limit', 'UpperLimit', 'string', $this);
				case 'StatTh':
					return new QQNode('stat_th', 'StatTh', 'string', $this);
				case 'EventHasGrade':
					return new QQReverseReferenceNodeEventHasGrade($this, 'eventhasgrade', 'reverse_reference', 'grade');
				case 'GradeCardAsRelative':
					return new QQReverseReferenceNodeGradeCard($this, 'gradecardasrelative', 'reverse_reference', 'relative_grade');
				case 'GradeCardAsAbsolute':
					return new QQReverseReferenceNodeGradeCard($this, 'gradecardasabsolute', 'reverse_reference', 'absolute_grade');
				case 'GradeCardAsPenalty':
					return new QQReverseReferenceNodeGradeCard($this, 'gradecardaspenalty', 'reverse_reference', 'penalty_grade');
				case 'ReEvaluationAsPrevious':
					return new QQReverseReferenceNodeReEvaluation($this, 'reevaluationasprevious', 'reverse_reference', 'previous_grade');

				case '_PrimaryKeyNode':
					return new QQNode('idgrade', 'Idgrade', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
