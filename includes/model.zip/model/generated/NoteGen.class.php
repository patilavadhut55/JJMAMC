<?php
	/**
	 * The abstract NoteGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Note subclass which
	 * extends this NoteGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Note class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idnote the value for intIdnote (Read-Only PK)
	 * @property QDateTime $Date the value for dttDate 
	 * @property string $From the value for strFrom 
	 * @property string $To the value for strTo 
	 * @property integer $Menu the value for intMenu 
	 * @property string $Url the value for strUrl 
	 * @property integer $Databy the value for intDataby 
	 * @property integer $Role the value for intRole 
	 * @property integer $Type the value for intType 
	 * @property integer $Reproducible the value for intReproducible 
	 * @property integer $Impact the value for intImpact 
	 * @property string $Title the value for strTitle 
	 * @property string $Steptoreproduce the value for strSteptoreproduce 
	 * @property string $Whathappen the value for strWhathappen 
	 * @property string $Whatexpected the value for strWhatexpected 
	 * @property Menu $MenuObject the value for the Menu object referenced by intMenu 
	 * @property Login $DatabyObject the value for the Login object referenced by intDataby 
	 * @property Role $RoleObject the value for the Role object referenced by intRole 
	 * @property Type $TypeObject the value for the Type object referenced by intType 
	 * @property Reproducible $ReproducibleObject the value for the Reproducible object referenced by intReproducible 
	 * @property Impact $ImpactObject the value for the Impact object referenced by intImpact 
	 * @property-read History $_History the value for the private _objHistory (Read-Only) if set due to an expansion on the history.note reverse relationship
	 * @property-read History[] $_HistoryArray the value for the private _objHistoryArray (Read-Only) if set due to an ExpandAsArray on the history.note reverse relationship
	 * @property-read Scan $_Scan the value for the private _objScan (Read-Only) if set due to an expansion on the scan.note reverse relationship
	 * @property-read Scan[] $_ScanArray the value for the private _objScanArray (Read-Only) if set due to an ExpandAsArray on the scan.note reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class NoteGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column note.idnote
		 * @var integer intIdnote
		 */
		protected $intIdnote;
		const IdnoteDefault = null;


		/**
		 * Protected member variable that maps to the database column note.date
		 * @var QDateTime dttDate
		 */
		protected $dttDate;
		const DateDefault = null;


		/**
		 * Protected member variable that maps to the database column note.from
		 * @var string strFrom
		 */
		protected $strFrom;
		const FromMaxLength = 255;
		const FromDefault = null;


		/**
		 * Protected member variable that maps to the database column note.to
		 * @var string strTo
		 */
		protected $strTo;
		const ToMaxLength = 255;
		const ToDefault = null;


		/**
		 * Protected member variable that maps to the database column note.menu
		 * @var integer intMenu
		 */
		protected $intMenu;
		const MenuDefault = null;


		/**
		 * Protected member variable that maps to the database column note.url
		 * @var string strUrl
		 */
		protected $strUrl;
		const UrlDefault = null;


		/**
		 * Protected member variable that maps to the database column note.databy
		 * @var integer intDataby
		 */
		protected $intDataby;
		const DatabyDefault = null;


		/**
		 * Protected member variable that maps to the database column note.role
		 * @var integer intRole
		 */
		protected $intRole;
		const RoleDefault = null;


		/**
		 * Protected member variable that maps to the database column note.type
		 * @var integer intType
		 */
		protected $intType;
		const TypeDefault = null;


		/**
		 * Protected member variable that maps to the database column note.reproducible
		 * @var integer intReproducible
		 */
		protected $intReproducible;
		const ReproducibleDefault = null;


		/**
		 * Protected member variable that maps to the database column note.impact
		 * @var integer intImpact
		 */
		protected $intImpact;
		const ImpactDefault = null;


		/**
		 * Protected member variable that maps to the database column note.title
		 * @var string strTitle
		 */
		protected $strTitle;
		const TitleMaxLength = 255;
		const TitleDefault = null;


		/**
		 * Protected member variable that maps to the database column note.steptoreproduce
		 * @var string strSteptoreproduce
		 */
		protected $strSteptoreproduce;
		const SteptoreproduceDefault = null;


		/**
		 * Protected member variable that maps to the database column note.whathappen
		 * @var string strWhathappen
		 */
		protected $strWhathappen;
		const WhathappenDefault = null;


		/**
		 * Protected member variable that maps to the database column note.whatexpected
		 * @var string strWhatexpected
		 */
		protected $strWhatexpected;
		const WhatexpectedDefault = null;


		/**
		 * Private member variable that stores a reference to a single History object
		 * (of type History), if this Note object was restored with
		 * an expansion on the history association table.
		 * @var History _objHistory;
		 */
		private $_objHistory;

		/**
		 * Private member variable that stores a reference to an array of History objects
		 * (of type History[]), if this Note object was restored with
		 * an ExpandAsArray on the history association table.
		 * @var History[] _objHistoryArray;
		 */
		private $_objHistoryArray = null;

		/**
		 * Private member variable that stores a reference to a single Scan object
		 * (of type Scan), if this Note object was restored with
		 * an expansion on the scan association table.
		 * @var Scan _objScan;
		 */
		private $_objScan;

		/**
		 * Private member variable that stores a reference to an array of Scan objects
		 * (of type Scan[]), if this Note object was restored with
		 * an ExpandAsArray on the scan association table.
		 * @var Scan[] _objScanArray;
		 */
		private $_objScanArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column note.menu.
		 *
		 * NOTE: Always use the MenuObject property getter to correctly retrieve this Menu object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Menu objMenuObject
		 */
		protected $objMenuObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column note.databy.
		 *
		 * NOTE: Always use the DatabyObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objDatabyObject
		 */
		protected $objDatabyObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column note.role.
		 *
		 * NOTE: Always use the RoleObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objRoleObject
		 */
		protected $objRoleObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column note.type.
		 *
		 * NOTE: Always use the TypeObject property getter to correctly retrieve this Type object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Type objTypeObject
		 */
		protected $objTypeObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column note.reproducible.
		 *
		 * NOTE: Always use the ReproducibleObject property getter to correctly retrieve this Reproducible object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Reproducible objReproducibleObject
		 */
		protected $objReproducibleObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column note.impact.
		 *
		 * NOTE: Always use the ImpactObject property getter to correctly retrieve this Impact object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Impact objImpactObject
		 */
		protected $objImpactObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdnote = Note::IdnoteDefault;
			$this->dttDate = (Note::DateDefault === null)?null:new QDateTime(Note::DateDefault);
			$this->strFrom = Note::FromDefault;
			$this->strTo = Note::ToDefault;
			$this->intMenu = Note::MenuDefault;
			$this->strUrl = Note::UrlDefault;
			$this->intDataby = Note::DatabyDefault;
			$this->intRole = Note::RoleDefault;
			$this->intType = Note::TypeDefault;
			$this->intReproducible = Note::ReproducibleDefault;
			$this->intImpact = Note::ImpactDefault;
			$this->strTitle = Note::TitleDefault;
			$this->strSteptoreproduce = Note::SteptoreproduceDefault;
			$this->strWhathappen = Note::WhathappenDefault;
			$this->strWhatexpected = Note::WhatexpectedDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Note from PK Info
		 * @param integer $intIdnote
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Note
		 */
		public static function Load($intIdnote, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Note', $intIdnote);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Note::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Note()->Idnote, $intIdnote)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Notes
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Note[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Note::QueryArray to perform the LoadAll query
			try {
				return Note::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Notes
		 * @return int
		 */
		public static function CountAll() {
			// Call Note::QueryCount to perform the CountAll query
			return Note::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();

			// Create/Build out the QueryBuilder object with Note-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'note');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Note::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('note');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Note object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Note the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Note::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Note object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Note::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Note::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Note objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Note[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Note::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Note::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Note::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Note objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Note::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();

			$strQuery = Note::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/note', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Note::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Note
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'note';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idnote', $strAliasPrefix . 'idnote');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idnote', $strAliasPrefix . 'idnote');
			    $objBuilder->AddSelectItem($strTableName, 'date', $strAliasPrefix . 'date');
			    $objBuilder->AddSelectItem($strTableName, 'from', $strAliasPrefix . 'from');
			    $objBuilder->AddSelectItem($strTableName, 'to', $strAliasPrefix . 'to');
			    $objBuilder->AddSelectItem($strTableName, 'menu', $strAliasPrefix . 'menu');
			    $objBuilder->AddSelectItem($strTableName, 'url', $strAliasPrefix . 'url');
			    $objBuilder->AddSelectItem($strTableName, 'databy', $strAliasPrefix . 'databy');
			    $objBuilder->AddSelectItem($strTableName, 'role', $strAliasPrefix . 'role');
			    $objBuilder->AddSelectItem($strTableName, 'type', $strAliasPrefix . 'type');
			    $objBuilder->AddSelectItem($strTableName, 'reproducible', $strAliasPrefix . 'reproducible');
			    $objBuilder->AddSelectItem($strTableName, 'impact', $strAliasPrefix . 'impact');
			    $objBuilder->AddSelectItem($strTableName, 'title', $strAliasPrefix . 'title');
			    $objBuilder->AddSelectItem($strTableName, 'steptoreproduce', $strAliasPrefix . 'steptoreproduce');
			    $objBuilder->AddSelectItem($strTableName, 'whathappen', $strAliasPrefix . 'whathappen');
			    $objBuilder->AddSelectItem($strTableName, 'whatexpected', $strAliasPrefix . 'whatexpected');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Note from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Note::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Note
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idnote';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdnote == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'note__';


						// Expanding reverse references: History
						$strAlias = $strAliasPrefix . 'history__idhistory';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objHistoryArray)
								$objPreviousItem->_objHistoryArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objHistoryArray)) {
								$objPreviousChildItems = $objPreviousItem->_objHistoryArray;
								$objChildItem = History::InstantiateDbRow($objDbRow, $strAliasPrefix . 'history__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objHistoryArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objHistoryArray[] = History::InstantiateDbRow($objDbRow, $strAliasPrefix . 'history__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: Scan
						$strAlias = $strAliasPrefix . 'scan__idscan';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objScanArray)
								$objPreviousItem->_objScanArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objScanArray)) {
								$objPreviousChildItems = $objPreviousItem->_objScanArray;
								$objChildItem = Scan::InstantiateDbRow($objDbRow, $strAliasPrefix . 'scan__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objScanArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objScanArray[] = Scan::InstantiateDbRow($objDbRow, $strAliasPrefix . 'scan__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'note__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Note object
			$objToReturn = new Note();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idnote';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdnote = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'from';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strFrom = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'to';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTo = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'menu';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMenu = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'url';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strUrl = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'databy';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intDataby = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'role';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intRole = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'type';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intType = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'reproducible';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intReproducible = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'impact';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intImpact = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'title';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTitle = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'steptoreproduce';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strSteptoreproduce = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'whathappen';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strWhathappen = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'whatexpected';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strWhatexpected = $objDbRow->GetColumn($strAliasName, 'Blob');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idnote != $objPreviousItem->Idnote) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objHistoryArray);
					$cnt = count($objToReturn->_objHistoryArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objHistoryArray, $objToReturn->_objHistoryArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objScanArray);
					$cnt = count($objToReturn->_objScanArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objScanArray, $objToReturn->_objScanArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'note__';

			// Check for MenuObject Early Binding
			$strAlias = $strAliasPrefix . 'menu__idmenu';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objMenuObject = Menu::InstantiateDbRow($objDbRow, $strAliasPrefix . 'menu__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for DatabyObject Early Binding
			$strAlias = $strAliasPrefix . 'databy__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objDatabyObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'databy__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for RoleObject Early Binding
			$strAlias = $strAliasPrefix . 'role__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objRoleObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'role__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for TypeObject Early Binding
			$strAlias = $strAliasPrefix . 'type__idtype';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objTypeObject = Type::InstantiateDbRow($objDbRow, $strAliasPrefix . 'type__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ReproducibleObject Early Binding
			$strAlias = $strAliasPrefix . 'reproducible__idreproducible';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objReproducibleObject = Reproducible::InstantiateDbRow($objDbRow, $strAliasPrefix . 'reproducible__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ImpactObject Early Binding
			$strAlias = $strAliasPrefix . 'impact__idimpact';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objImpactObject = Impact::InstantiateDbRow($objDbRow, $strAliasPrefix . 'impact__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for History Virtual Binding
			$strAlias = $strAliasPrefix . 'history__idhistory';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objHistoryArray)
				$objToReturn->_objHistoryArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objHistoryArray[] = History::InstantiateDbRow($objDbRow, $strAliasPrefix . 'history__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objHistory = History::InstantiateDbRow($objDbRow, $strAliasPrefix . 'history__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for Scan Virtual Binding
			$strAlias = $strAliasPrefix . 'scan__idscan';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objScanArray)
				$objToReturn->_objScanArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objScanArray[] = Scan::InstantiateDbRow($objDbRow, $strAliasPrefix . 'scan__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objScan = Scan::InstantiateDbRow($objDbRow, $strAliasPrefix . 'scan__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Notes from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Note[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Note::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Note::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Note object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Note next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Note::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Note object,
		 * by Idnote Index(es)
		 * @param integer $intIdnote
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Note
		*/
		public static function LoadByIdnote($intIdnote, $objOptionalClauses = null) {
			return Note::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Note()->Idnote, $intIdnote)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Note objects,
		 * by Type Index(es)
		 * @param integer $intType
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Note[]
		*/
		public static function LoadArrayByType($intType, $objOptionalClauses = null) {
			// Call Note::QueryArray to perform the LoadArrayByType query
			try {
				return Note::QueryArray(
					QQ::Equal(QQN::Note()->Type, $intType),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Notes
		 * by Type Index(es)
		 * @param integer $intType
		 * @return int
		*/
		public static function CountByType($intType) {
			// Call Note::QueryCount to perform the CountByType query
			return Note::QueryCount(
				QQ::Equal(QQN::Note()->Type, $intType)
			);
		}

		/**
		 * Load an array of Note objects,
		 * by Impact Index(es)
		 * @param integer $intImpact
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Note[]
		*/
		public static function LoadArrayByImpact($intImpact, $objOptionalClauses = null) {
			// Call Note::QueryArray to perform the LoadArrayByImpact query
			try {
				return Note::QueryArray(
					QQ::Equal(QQN::Note()->Impact, $intImpact),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Notes
		 * by Impact Index(es)
		 * @param integer $intImpact
		 * @return int
		*/
		public static function CountByImpact($intImpact) {
			// Call Note::QueryCount to perform the CountByImpact query
			return Note::QueryCount(
				QQ::Equal(QQN::Note()->Impact, $intImpact)
			);
		}

		/**
		 * Load an array of Note objects,
		 * by Reproducible Index(es)
		 * @param integer $intReproducible
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Note[]
		*/
		public static function LoadArrayByReproducible($intReproducible, $objOptionalClauses = null) {
			// Call Note::QueryArray to perform the LoadArrayByReproducible query
			try {
				return Note::QueryArray(
					QQ::Equal(QQN::Note()->Reproducible, $intReproducible),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Notes
		 * by Reproducible Index(es)
		 * @param integer $intReproducible
		 * @return int
		*/
		public static function CountByReproducible($intReproducible) {
			// Call Note::QueryCount to perform the CountByReproducible query
			return Note::QueryCount(
				QQ::Equal(QQN::Note()->Reproducible, $intReproducible)
			);
		}

		/**
		 * Load an array of Note objects,
		 * by Role Index(es)
		 * @param integer $intRole
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Note[]
		*/
		public static function LoadArrayByRole($intRole, $objOptionalClauses = null) {
			// Call Note::QueryArray to perform the LoadArrayByRole query
			try {
				return Note::QueryArray(
					QQ::Equal(QQN::Note()->Role, $intRole),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Notes
		 * by Role Index(es)
		 * @param integer $intRole
		 * @return int
		*/
		public static function CountByRole($intRole) {
			// Call Note::QueryCount to perform the CountByRole query
			return Note::QueryCount(
				QQ::Equal(QQN::Note()->Role, $intRole)
			);
		}

		/**
		 * Load an array of Note objects,
		 * by Databy Index(es)
		 * @param integer $intDataby
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Note[]
		*/
		public static function LoadArrayByDataby($intDataby, $objOptionalClauses = null) {
			// Call Note::QueryArray to perform the LoadArrayByDataby query
			try {
				return Note::QueryArray(
					QQ::Equal(QQN::Note()->Databy, $intDataby),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Notes
		 * by Databy Index(es)
		 * @param integer $intDataby
		 * @return int
		*/
		public static function CountByDataby($intDataby) {
			// Call Note::QueryCount to perform the CountByDataby query
			return Note::QueryCount(
				QQ::Equal(QQN::Note()->Databy, $intDataby)
			);
		}

		/**
		 * Load an array of Note objects,
		 * by Menu Index(es)
		 * @param integer $intMenu
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Note[]
		*/
		public static function LoadArrayByMenu($intMenu, $objOptionalClauses = null) {
			// Call Note::QueryArray to perform the LoadArrayByMenu query
			try {
				return Note::QueryArray(
					QQ::Equal(QQN::Note()->Menu, $intMenu),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Notes
		 * by Menu Index(es)
		 * @param integer $intMenu
		 * @return int
		*/
		public static function CountByMenu($intMenu) {
			// Call Note::QueryCount to perform the CountByMenu query
			return Note::QueryCount(
				QQ::Equal(QQN::Note()->Menu, $intMenu)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Note
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `note` (
							`date`,
							`from`,
							`to`,
							`menu`,
							`url`,
							`databy`,
							`role`,
							`type`,
							`reproducible`,
							`impact`,
							`title`,
							`steptoreproduce`,
							`whathappen`,
							`whatexpected`
						) VALUES (
							' . $objDatabase->SqlVariable($this->dttDate) . ',
							' . $objDatabase->SqlVariable($this->strFrom) . ',
							' . $objDatabase->SqlVariable($this->strTo) . ',
							' . $objDatabase->SqlVariable($this->intMenu) . ',
							' . $objDatabase->SqlVariable($this->strUrl) . ',
							' . $objDatabase->SqlVariable($this->intDataby) . ',
							' . $objDatabase->SqlVariable($this->intRole) . ',
							' . $objDatabase->SqlVariable($this->intType) . ',
							' . $objDatabase->SqlVariable($this->intReproducible) . ',
							' . $objDatabase->SqlVariable($this->intImpact) . ',
							' . $objDatabase->SqlVariable($this->strTitle) . ',
							' . $objDatabase->SqlVariable($this->strSteptoreproduce) . ',
							' . $objDatabase->SqlVariable($this->strWhathappen) . ',
							' . $objDatabase->SqlVariable($this->strWhatexpected) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdnote = $objDatabase->InsertId('note', 'idnote');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`note`
						SET
							`date` = ' . $objDatabase->SqlVariable($this->dttDate) . ',
							`from` = ' . $objDatabase->SqlVariable($this->strFrom) . ',
							`to` = ' . $objDatabase->SqlVariable($this->strTo) . ',
							`menu` = ' . $objDatabase->SqlVariable($this->intMenu) . ',
							`url` = ' . $objDatabase->SqlVariable($this->strUrl) . ',
							`databy` = ' . $objDatabase->SqlVariable($this->intDataby) . ',
							`role` = ' . $objDatabase->SqlVariable($this->intRole) . ',
							`type` = ' . $objDatabase->SqlVariable($this->intType) . ',
							`reproducible` = ' . $objDatabase->SqlVariable($this->intReproducible) . ',
							`impact` = ' . $objDatabase->SqlVariable($this->intImpact) . ',
							`title` = ' . $objDatabase->SqlVariable($this->strTitle) . ',
							`steptoreproduce` = ' . $objDatabase->SqlVariable($this->strSteptoreproduce) . ',
							`whathappen` = ' . $objDatabase->SqlVariable($this->strWhathappen) . ',
							`whatexpected` = ' . $objDatabase->SqlVariable($this->strWhatexpected) . '
						WHERE
							`idnote` = ' . $objDatabase->SqlVariable($this->intIdnote) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Note
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdnote)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Note with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`note`
				WHERE
					`idnote` = ' . $objDatabase->SqlVariable($this->intIdnote) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Note ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Note', $this->intIdnote);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Notes
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`note`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate note table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `note`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Note from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Note object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Note::Load($this->intIdnote);

			// Update $this's local variables to match
			$this->dttDate = $objReloaded->dttDate;
			$this->strFrom = $objReloaded->strFrom;
			$this->strTo = $objReloaded->strTo;
			$this->Menu = $objReloaded->Menu;
			$this->strUrl = $objReloaded->strUrl;
			$this->Databy = $objReloaded->Databy;
			$this->Role = $objReloaded->Role;
			$this->Type = $objReloaded->Type;
			$this->Reproducible = $objReloaded->Reproducible;
			$this->Impact = $objReloaded->Impact;
			$this->strTitle = $objReloaded->strTitle;
			$this->strSteptoreproduce = $objReloaded->strSteptoreproduce;
			$this->strWhathappen = $objReloaded->strWhathappen;
			$this->strWhatexpected = $objReloaded->strWhatexpected;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idnote':
					/**
					 * Gets the value for intIdnote (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdnote;

				case 'Date':
					/**
					 * Gets the value for dttDate 
					 * @return QDateTime
					 */
					return $this->dttDate;

				case 'From':
					/**
					 * Gets the value for strFrom 
					 * @return string
					 */
					return $this->strFrom;

				case 'To':
					/**
					 * Gets the value for strTo 
					 * @return string
					 */
					return $this->strTo;

				case 'Menu':
					/**
					 * Gets the value for intMenu 
					 * @return integer
					 */
					return $this->intMenu;

				case 'Url':
					/**
					 * Gets the value for strUrl 
					 * @return string
					 */
					return $this->strUrl;

				case 'Databy':
					/**
					 * Gets the value for intDataby 
					 * @return integer
					 */
					return $this->intDataby;

				case 'Role':
					/**
					 * Gets the value for intRole 
					 * @return integer
					 */
					return $this->intRole;

				case 'Type':
					/**
					 * Gets the value for intType 
					 * @return integer
					 */
					return $this->intType;

				case 'Reproducible':
					/**
					 * Gets the value for intReproducible 
					 * @return integer
					 */
					return $this->intReproducible;

				case 'Impact':
					/**
					 * Gets the value for intImpact 
					 * @return integer
					 */
					return $this->intImpact;

				case 'Title':
					/**
					 * Gets the value for strTitle 
					 * @return string
					 */
					return $this->strTitle;

				case 'Steptoreproduce':
					/**
					 * Gets the value for strSteptoreproduce 
					 * @return string
					 */
					return $this->strSteptoreproduce;

				case 'Whathappen':
					/**
					 * Gets the value for strWhathappen 
					 * @return string
					 */
					return $this->strWhathappen;

				case 'Whatexpected':
					/**
					 * Gets the value for strWhatexpected 
					 * @return string
					 */
					return $this->strWhatexpected;


				///////////////////
				// Member Objects
				///////////////////
				case 'MenuObject':
					/**
					 * Gets the value for the Menu object referenced by intMenu 
					 * @return Menu
					 */
					try {
						if ((!$this->objMenuObject) && (!is_null($this->intMenu)))
							$this->objMenuObject = Menu::Load($this->intMenu);
						return $this->objMenuObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'DatabyObject':
					/**
					 * Gets the value for the Login object referenced by intDataby 
					 * @return Login
					 */
					try {
						if ((!$this->objDatabyObject) && (!is_null($this->intDataby)))
							$this->objDatabyObject = Login::Load($this->intDataby);
						return $this->objDatabyObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RoleObject':
					/**
					 * Gets the value for the Role object referenced by intRole 
					 * @return Role
					 */
					try {
						if ((!$this->objRoleObject) && (!is_null($this->intRole)))
							$this->objRoleObject = Role::Load($this->intRole);
						return $this->objRoleObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TypeObject':
					/**
					 * Gets the value for the Type object referenced by intType 
					 * @return Type
					 */
					try {
						if ((!$this->objTypeObject) && (!is_null($this->intType)))
							$this->objTypeObject = Type::Load($this->intType);
						return $this->objTypeObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ReproducibleObject':
					/**
					 * Gets the value for the Reproducible object referenced by intReproducible 
					 * @return Reproducible
					 */
					try {
						if ((!$this->objReproducibleObject) && (!is_null($this->intReproducible)))
							$this->objReproducibleObject = Reproducible::Load($this->intReproducible);
						return $this->objReproducibleObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ImpactObject':
					/**
					 * Gets the value for the Impact object referenced by intImpact 
					 * @return Impact
					 */
					try {
						if ((!$this->objImpactObject) && (!is_null($this->intImpact)))
							$this->objImpactObject = Impact::Load($this->intImpact);
						return $this->objImpactObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_History':
					/**
					 * Gets the value for the private _objHistory (Read-Only)
					 * if set due to an expansion on the history.note reverse relationship
					 * @return History
					 */
					return $this->_objHistory;

				case '_HistoryArray':
					/**
					 * Gets the value for the private _objHistoryArray (Read-Only)
					 * if set due to an ExpandAsArray on the history.note reverse relationship
					 * @return History[]
					 */
					return $this->_objHistoryArray;

				case '_Scan':
					/**
					 * Gets the value for the private _objScan (Read-Only)
					 * if set due to an expansion on the scan.note reverse relationship
					 * @return Scan
					 */
					return $this->_objScan;

				case '_ScanArray':
					/**
					 * Gets the value for the private _objScanArray (Read-Only)
					 * if set due to an ExpandAsArray on the scan.note reverse relationship
					 * @return Scan[]
					 */
					return $this->_objScanArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Date':
					/**
					 * Sets the value for dttDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'From':
					/**
					 * Sets the value for strFrom 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strFrom = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'To':
					/**
					 * Sets the value for strTo 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTo = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Menu':
					/**
					 * Sets the value for intMenu 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objMenuObject = null;
						return ($this->intMenu = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Url':
					/**
					 * Sets the value for strUrl 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strUrl = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Databy':
					/**
					 * Sets the value for intDataby 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objDatabyObject = null;
						return ($this->intDataby = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Role':
					/**
					 * Sets the value for intRole 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objRoleObject = null;
						return ($this->intRole = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Type':
					/**
					 * Sets the value for intType 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objTypeObject = null;
						return ($this->intType = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Reproducible':
					/**
					 * Sets the value for intReproducible 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objReproducibleObject = null;
						return ($this->intReproducible = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Impact':
					/**
					 * Sets the value for intImpact 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objImpactObject = null;
						return ($this->intImpact = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Title':
					/**
					 * Sets the value for strTitle 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTitle = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Steptoreproduce':
					/**
					 * Sets the value for strSteptoreproduce 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strSteptoreproduce = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Whathappen':
					/**
					 * Sets the value for strWhathappen 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strWhathappen = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Whatexpected':
					/**
					 * Sets the value for strWhatexpected 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strWhatexpected = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'MenuObject':
					/**
					 * Sets the value for the Menu object referenced by intMenu 
					 * @param Menu $mixValue
					 * @return Menu
					 */
					if (is_null($mixValue)) {
						$this->intMenu = null;
						$this->objMenuObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Menu object
						try {
							$mixValue = QType::Cast($mixValue, 'Menu');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Menu object
						if (is_null($mixValue->Idmenu))
							throw new QCallerException('Unable to set an unsaved MenuObject for this Note');

						// Update Local Member Variables
						$this->objMenuObject = $mixValue;
						$this->intMenu = $mixValue->Idmenu;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'DatabyObject':
					/**
					 * Sets the value for the Login object referenced by intDataby 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intDataby = null;
						$this->objDatabyObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved DatabyObject for this Note');

						// Update Local Member Variables
						$this->objDatabyObject = $mixValue;
						$this->intDataby = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'RoleObject':
					/**
					 * Sets the value for the Role object referenced by intRole 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intRole = null;
						$this->objRoleObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved RoleObject for this Note');

						// Update Local Member Variables
						$this->objRoleObject = $mixValue;
						$this->intRole = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'TypeObject':
					/**
					 * Sets the value for the Type object referenced by intType 
					 * @param Type $mixValue
					 * @return Type
					 */
					if (is_null($mixValue)) {
						$this->intType = null;
						$this->objTypeObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Type object
						try {
							$mixValue = QType::Cast($mixValue, 'Type');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Type object
						if (is_null($mixValue->Idtype))
							throw new QCallerException('Unable to set an unsaved TypeObject for this Note');

						// Update Local Member Variables
						$this->objTypeObject = $mixValue;
						$this->intType = $mixValue->Idtype;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ReproducibleObject':
					/**
					 * Sets the value for the Reproducible object referenced by intReproducible 
					 * @param Reproducible $mixValue
					 * @return Reproducible
					 */
					if (is_null($mixValue)) {
						$this->intReproducible = null;
						$this->objReproducibleObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Reproducible object
						try {
							$mixValue = QType::Cast($mixValue, 'Reproducible');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Reproducible object
						if (is_null($mixValue->Idreproducible))
							throw new QCallerException('Unable to set an unsaved ReproducibleObject for this Note');

						// Update Local Member Variables
						$this->objReproducibleObject = $mixValue;
						$this->intReproducible = $mixValue->Idreproducible;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ImpactObject':
					/**
					 * Sets the value for the Impact object referenced by intImpact 
					 * @param Impact $mixValue
					 * @return Impact
					 */
					if (is_null($mixValue)) {
						$this->intImpact = null;
						$this->objImpactObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Impact object
						try {
							$mixValue = QType::Cast($mixValue, 'Impact');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Impact object
						if (is_null($mixValue->Idimpact))
							throw new QCallerException('Unable to set an unsaved ImpactObject for this Note');

						// Update Local Member Variables
						$this->objImpactObject = $mixValue;
						$this->intImpact = $mixValue->Idimpact;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for History
		//-------------------------------------------------------------------

		/**
		 * Gets all associated Histories as an array of History objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return History[]
		*/
		public function GetHistoryArray($objOptionalClauses = null) {
			if ((is_null($this->intIdnote)))
				return array();

			try {
				return History::LoadArrayByNote($this->intIdnote, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated Histories
		 * @return int
		*/
		public function CountHistories() {
			if ((is_null($this->intIdnote)))
				return 0;

			return History::CountByNote($this->intIdnote);
		}

		/**
		 * Associates a History
		 * @param History $objHistory
		 * @return void
		*/
		public function AssociateHistory(History $objHistory) {
			if ((is_null($this->intIdnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateHistory on this unsaved Note.');
			if ((is_null($objHistory->Idhistory)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateHistory on this Note with an unsaved History.');

			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`history`
				SET
					`note` = ' . $objDatabase->SqlVariable($this->intIdnote) . '
				WHERE
					`idhistory` = ' . $objDatabase->SqlVariable($objHistory->Idhistory) . '
			');
		}

		/**
		 * Unassociates a History
		 * @param History $objHistory
		 * @return void
		*/
		public function UnassociateHistory(History $objHistory) {
			if ((is_null($this->intIdnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateHistory on this unsaved Note.');
			if ((is_null($objHistory->Idhistory)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateHistory on this Note with an unsaved History.');

			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`history`
				SET
					`note` = null
				WHERE
					`idhistory` = ' . $objDatabase->SqlVariable($objHistory->Idhistory) . ' AND
					`note` = ' . $objDatabase->SqlVariable($this->intIdnote) . '
			');
		}

		/**
		 * Unassociates all Histories
		 * @return void
		*/
		public function UnassociateAllHistories() {
			if ((is_null($this->intIdnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateHistory on this unsaved Note.');

			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`history`
				SET
					`note` = null
				WHERE
					`note` = ' . $objDatabase->SqlVariable($this->intIdnote) . '
			');
		}

		/**
		 * Deletes an associated History
		 * @param History $objHistory
		 * @return void
		*/
		public function DeleteAssociatedHistory(History $objHistory) {
			if ((is_null($this->intIdnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateHistory on this unsaved Note.');
			if ((is_null($objHistory->Idhistory)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateHistory on this Note with an unsaved History.');

			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`history`
				WHERE
					`idhistory` = ' . $objDatabase->SqlVariable($objHistory->Idhistory) . ' AND
					`note` = ' . $objDatabase->SqlVariable($this->intIdnote) . '
			');
		}

		/**
		 * Deletes all associated Histories
		 * @return void
		*/
		public function DeleteAllHistories() {
			if ((is_null($this->intIdnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateHistory on this unsaved Note.');

			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`history`
				WHERE
					`note` = ' . $objDatabase->SqlVariable($this->intIdnote) . '
			');
		}


		// Related Objects' Methods for Scan
		//-------------------------------------------------------------------

		/**
		 * Gets all associated Scans as an array of Scan objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Scan[]
		*/
		public function GetScanArray($objOptionalClauses = null) {
			if ((is_null($this->intIdnote)))
				return array();

			try {
				return Scan::LoadArrayByNote($this->intIdnote, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated Scans
		 * @return int
		*/
		public function CountScans() {
			if ((is_null($this->intIdnote)))
				return 0;

			return Scan::CountByNote($this->intIdnote);
		}

		/**
		 * Associates a Scan
		 * @param Scan $objScan
		 * @return void
		*/
		public function AssociateScan(Scan $objScan) {
			if ((is_null($this->intIdnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateScan on this unsaved Note.');
			if ((is_null($objScan->Idscan)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateScan on this Note with an unsaved Scan.');

			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`scan`
				SET
					`note` = ' . $objDatabase->SqlVariable($this->intIdnote) . '
				WHERE
					`idscan` = ' . $objDatabase->SqlVariable($objScan->Idscan) . '
			');
		}

		/**
		 * Unassociates a Scan
		 * @param Scan $objScan
		 * @return void
		*/
		public function UnassociateScan(Scan $objScan) {
			if ((is_null($this->intIdnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateScan on this unsaved Note.');
			if ((is_null($objScan->Idscan)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateScan on this Note with an unsaved Scan.');

			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`scan`
				SET
					`note` = null
				WHERE
					`idscan` = ' . $objDatabase->SqlVariable($objScan->Idscan) . ' AND
					`note` = ' . $objDatabase->SqlVariable($this->intIdnote) . '
			');
		}

		/**
		 * Unassociates all Scans
		 * @return void
		*/
		public function UnassociateAllScans() {
			if ((is_null($this->intIdnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateScan on this unsaved Note.');

			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`scan`
				SET
					`note` = null
				WHERE
					`note` = ' . $objDatabase->SqlVariable($this->intIdnote) . '
			');
		}

		/**
		 * Deletes an associated Scan
		 * @param Scan $objScan
		 * @return void
		*/
		public function DeleteAssociatedScan(Scan $objScan) {
			if ((is_null($this->intIdnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateScan on this unsaved Note.');
			if ((is_null($objScan->Idscan)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateScan on this Note with an unsaved Scan.');

			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`scan`
				WHERE
					`idscan` = ' . $objDatabase->SqlVariable($objScan->Idscan) . ' AND
					`note` = ' . $objDatabase->SqlVariable($this->intIdnote) . '
			');
		}

		/**
		 * Deletes all associated Scans
		 * @return void
		*/
		public function DeleteAllScans() {
			if ((is_null($this->intIdnote)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateScan on this unsaved Note.');

			// Get the Database Object for this Class
			$objDatabase = Note::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`scan`
				WHERE
					`note` = ' . $objDatabase->SqlVariable($this->intIdnote) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "note";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Note::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Note"><sequence>';
			$strToReturn .= '<element name="Idnote" type="xsd:int"/>';
			$strToReturn .= '<element name="Date" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="From" type="xsd:string"/>';
			$strToReturn .= '<element name="To" type="xsd:string"/>';
			$strToReturn .= '<element name="MenuObject" type="xsd1:Menu"/>';
			$strToReturn .= '<element name="Url" type="xsd:string"/>';
			$strToReturn .= '<element name="DatabyObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="RoleObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="TypeObject" type="xsd1:Type"/>';
			$strToReturn .= '<element name="ReproducibleObject" type="xsd1:Reproducible"/>';
			$strToReturn .= '<element name="ImpactObject" type="xsd1:Impact"/>';
			$strToReturn .= '<element name="Title" type="xsd:string"/>';
			$strToReturn .= '<element name="Steptoreproduce" type="xsd:string"/>';
			$strToReturn .= '<element name="Whathappen" type="xsd:string"/>';
			$strToReturn .= '<element name="Whatexpected" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Note', $strComplexTypeArray)) {
				$strComplexTypeArray['Note'] = Note::GetSoapComplexTypeXml();
				Menu::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				Type::AlterSoapComplexTypeArray($strComplexTypeArray);
				Reproducible::AlterSoapComplexTypeArray($strComplexTypeArray);
				Impact::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Note::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Note();
			if (property_exists($objSoapObject, 'Idnote'))
				$objToReturn->intIdnote = $objSoapObject->Idnote;
			if (property_exists($objSoapObject, 'Date'))
				$objToReturn->dttDate = new QDateTime($objSoapObject->Date);
			if (property_exists($objSoapObject, 'From'))
				$objToReturn->strFrom = $objSoapObject->From;
			if (property_exists($objSoapObject, 'To'))
				$objToReturn->strTo = $objSoapObject->To;
			if ((property_exists($objSoapObject, 'MenuObject')) &&
				($objSoapObject->MenuObject))
				$objToReturn->MenuObject = Menu::GetObjectFromSoapObject($objSoapObject->MenuObject);
			if (property_exists($objSoapObject, 'Url'))
				$objToReturn->strUrl = $objSoapObject->Url;
			if ((property_exists($objSoapObject, 'DatabyObject')) &&
				($objSoapObject->DatabyObject))
				$objToReturn->DatabyObject = Login::GetObjectFromSoapObject($objSoapObject->DatabyObject);
			if ((property_exists($objSoapObject, 'RoleObject')) &&
				($objSoapObject->RoleObject))
				$objToReturn->RoleObject = Role::GetObjectFromSoapObject($objSoapObject->RoleObject);
			if ((property_exists($objSoapObject, 'TypeObject')) &&
				($objSoapObject->TypeObject))
				$objToReturn->TypeObject = Type::GetObjectFromSoapObject($objSoapObject->TypeObject);
			if ((property_exists($objSoapObject, 'ReproducibleObject')) &&
				($objSoapObject->ReproducibleObject))
				$objToReturn->ReproducibleObject = Reproducible::GetObjectFromSoapObject($objSoapObject->ReproducibleObject);
			if ((property_exists($objSoapObject, 'ImpactObject')) &&
				($objSoapObject->ImpactObject))
				$objToReturn->ImpactObject = Impact::GetObjectFromSoapObject($objSoapObject->ImpactObject);
			if (property_exists($objSoapObject, 'Title'))
				$objToReturn->strTitle = $objSoapObject->Title;
			if (property_exists($objSoapObject, 'Steptoreproduce'))
				$objToReturn->strSteptoreproduce = $objSoapObject->Steptoreproduce;
			if (property_exists($objSoapObject, 'Whathappen'))
				$objToReturn->strWhathappen = $objSoapObject->Whathappen;
			if (property_exists($objSoapObject, 'Whatexpected'))
				$objToReturn->strWhatexpected = $objSoapObject->Whatexpected;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Note::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->dttDate)
				$objObject->dttDate = $objObject->dttDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objMenuObject)
				$objObject->objMenuObject = Menu::GetSoapObjectFromObject($objObject->objMenuObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intMenu = null;
			if ($objObject->objDatabyObject)
				$objObject->objDatabyObject = Login::GetSoapObjectFromObject($objObject->objDatabyObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intDataby = null;
			if ($objObject->objRoleObject)
				$objObject->objRoleObject = Role::GetSoapObjectFromObject($objObject->objRoleObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intRole = null;
			if ($objObject->objTypeObject)
				$objObject->objTypeObject = Type::GetSoapObjectFromObject($objObject->objTypeObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intType = null;
			if ($objObject->objReproducibleObject)
				$objObject->objReproducibleObject = Reproducible::GetSoapObjectFromObject($objObject->objReproducibleObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intReproducible = null;
			if ($objObject->objImpactObject)
				$objObject->objImpactObject = Impact::GetSoapObjectFromObject($objObject->objImpactObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intImpact = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idnote'] = $this->intIdnote;
			$iArray['Date'] = $this->dttDate;
			$iArray['From'] = $this->strFrom;
			$iArray['To'] = $this->strTo;
			$iArray['Menu'] = $this->intMenu;
			$iArray['Url'] = $this->strUrl;
			$iArray['Databy'] = $this->intDataby;
			$iArray['Role'] = $this->intRole;
			$iArray['Type'] = $this->intType;
			$iArray['Reproducible'] = $this->intReproducible;
			$iArray['Impact'] = $this->intImpact;
			$iArray['Title'] = $this->strTitle;
			$iArray['Steptoreproduce'] = $this->strSteptoreproduce;
			$iArray['Whathappen'] = $this->strWhathappen;
			$iArray['Whatexpected'] = $this->strWhatexpected;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdnote ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idnote
     * @property-read QQNode $Date
     * @property-read QQNode $From
     * @property-read QQNode $To
     * @property-read QQNode $Menu
     * @property-read QQNodeMenu $MenuObject
     * @property-read QQNode $Url
     * @property-read QQNode $Databy
     * @property-read QQNodeLogin $DatabyObject
     * @property-read QQNode $Role
     * @property-read QQNodeRole $RoleObject
     * @property-read QQNode $Type
     * @property-read QQNodeType $TypeObject
     * @property-read QQNode $Reproducible
     * @property-read QQNodeReproducible $ReproducibleObject
     * @property-read QQNode $Impact
     * @property-read QQNodeImpact $ImpactObject
     * @property-read QQNode $Title
     * @property-read QQNode $Steptoreproduce
     * @property-read QQNode $Whathappen
     * @property-read QQNode $Whatexpected
     *
     *
     * @property-read QQReverseReferenceNodeHistory $History
     * @property-read QQReverseReferenceNodeScan $Scan

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeNote extends QQNode {
		protected $strTableName = 'note';
		protected $strPrimaryKey = 'idnote';
		protected $strClassName = 'Note';
		public function __get($strName) {
			switch ($strName) {
				case 'Idnote':
					return new QQNode('idnote', 'Idnote', 'Integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'Date', $this);
				case 'From':
					return new QQNode('from', 'From', 'VarChar', $this);
				case 'To':
					return new QQNode('to', 'To', 'VarChar', $this);
				case 'Menu':
					return new QQNode('menu', 'Menu', 'Integer', $this);
				case 'MenuObject':
					return new QQNodeMenu('menu', 'MenuObject', 'Integer', $this);
				case 'Url':
					return new QQNode('url', 'Url', 'Blob', $this);
				case 'Databy':
					return new QQNode('databy', 'Databy', 'Integer', $this);
				case 'DatabyObject':
					return new QQNodeLogin('databy', 'DatabyObject', 'Integer', $this);
				case 'Role':
					return new QQNode('role', 'Role', 'Integer', $this);
				case 'RoleObject':
					return new QQNodeRole('role', 'RoleObject', 'Integer', $this);
				case 'Type':
					return new QQNode('type', 'Type', 'Integer', $this);
				case 'TypeObject':
					return new QQNodeType('type', 'TypeObject', 'Integer', $this);
				case 'Reproducible':
					return new QQNode('reproducible', 'Reproducible', 'Integer', $this);
				case 'ReproducibleObject':
					return new QQNodeReproducible('reproducible', 'ReproducibleObject', 'Integer', $this);
				case 'Impact':
					return new QQNode('impact', 'Impact', 'Integer', $this);
				case 'ImpactObject':
					return new QQNodeImpact('impact', 'ImpactObject', 'Integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'VarChar', $this);
				case 'Steptoreproduce':
					return new QQNode('steptoreproduce', 'Steptoreproduce', 'Blob', $this);
				case 'Whathappen':
					return new QQNode('whathappen', 'Whathappen', 'Blob', $this);
				case 'Whatexpected':
					return new QQNode('whatexpected', 'Whatexpected', 'Blob', $this);
				case 'History':
					return new QQReverseReferenceNodeHistory($this, 'history', 'reverse_reference', 'note');
				case 'Scan':
					return new QQReverseReferenceNodeScan($this, 'scan', 'reverse_reference', 'note');

				case '_PrimaryKeyNode':
					return new QQNode('idnote', 'Idnote', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idnote
     * @property-read QQNode $Date
     * @property-read QQNode $From
     * @property-read QQNode $To
     * @property-read QQNode $Menu
     * @property-read QQNodeMenu $MenuObject
     * @property-read QQNode $Url
     * @property-read QQNode $Databy
     * @property-read QQNodeLogin $DatabyObject
     * @property-read QQNode $Role
     * @property-read QQNodeRole $RoleObject
     * @property-read QQNode $Type
     * @property-read QQNodeType $TypeObject
     * @property-read QQNode $Reproducible
     * @property-read QQNodeReproducible $ReproducibleObject
     * @property-read QQNode $Impact
     * @property-read QQNodeImpact $ImpactObject
     * @property-read QQNode $Title
     * @property-read QQNode $Steptoreproduce
     * @property-read QQNode $Whathappen
     * @property-read QQNode $Whatexpected
     *
     *
     * @property-read QQReverseReferenceNodeHistory $History
     * @property-read QQReverseReferenceNodeScan $Scan

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeNote extends QQReverseReferenceNode {
		protected $strTableName = 'note';
		protected $strPrimaryKey = 'idnote';
		protected $strClassName = 'Note';
		public function __get($strName) {
			switch ($strName) {
				case 'Idnote':
					return new QQNode('idnote', 'Idnote', 'integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'QDateTime', $this);
				case 'From':
					return new QQNode('from', 'From', 'string', $this);
				case 'To':
					return new QQNode('to', 'To', 'string', $this);
				case 'Menu':
					return new QQNode('menu', 'Menu', 'integer', $this);
				case 'MenuObject':
					return new QQNodeMenu('menu', 'MenuObject', 'integer', $this);
				case 'Url':
					return new QQNode('url', 'Url', 'string', $this);
				case 'Databy':
					return new QQNode('databy', 'Databy', 'integer', $this);
				case 'DatabyObject':
					return new QQNodeLogin('databy', 'DatabyObject', 'integer', $this);
				case 'Role':
					return new QQNode('role', 'Role', 'integer', $this);
				case 'RoleObject':
					return new QQNodeRole('role', 'RoleObject', 'integer', $this);
				case 'Type':
					return new QQNode('type', 'Type', 'integer', $this);
				case 'TypeObject':
					return new QQNodeType('type', 'TypeObject', 'integer', $this);
				case 'Reproducible':
					return new QQNode('reproducible', 'Reproducible', 'integer', $this);
				case 'ReproducibleObject':
					return new QQNodeReproducible('reproducible', 'ReproducibleObject', 'integer', $this);
				case 'Impact':
					return new QQNode('impact', 'Impact', 'integer', $this);
				case 'ImpactObject':
					return new QQNodeImpact('impact', 'ImpactObject', 'integer', $this);
				case 'Title':
					return new QQNode('title', 'Title', 'string', $this);
				case 'Steptoreproduce':
					return new QQNode('steptoreproduce', 'Steptoreproduce', 'string', $this);
				case 'Whathappen':
					return new QQNode('whathappen', 'Whathappen', 'string', $this);
				case 'Whatexpected':
					return new QQNode('whatexpected', 'Whatexpected', 'string', $this);
				case 'History':
					return new QQReverseReferenceNodeHistory($this, 'history', 'reverse_reference', 'note');
				case 'Scan':
					return new QQReverseReferenceNodeScan($this, 'scan', 'reverse_reference', 'note');

				case '_PrimaryKeyNode':
					return new QQNode('idnote', 'Idnote', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
