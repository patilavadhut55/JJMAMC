<?php
	/**
	 * The abstract GradeCardGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the GradeCard subclass which
	 * extends this GradeCardGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the GradeCard class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdgradeCard the value for intIdgradeCard (Read-Only PK)
	 * @property integer $Student the value for intStudent 
	 * @property integer $StudeRole the value for intStudeRole 
	 * @property integer $Subject the value for intSubject 
	 * @property string $Total the value for strTotal 
	 * @property integer $RelativeGrade the value for intRelativeGrade 
	 * @property integer $AbsoluteGrade the value for intAbsoluteGrade 
	 * @property boolean $ByMakeup the value for blnByMakeup 
	 * @property string $PenaltyReason the value for strPenaltyReason 
	 * @property integer $PenaltyGrade the value for intPenaltyGrade 
	 * @property string $GraceMarks the value for strGraceMarks 
	 * @property string $ChangeInEse the value for strChangeInEse 
	 * @property integer $ChangeInEseBy the value for intChangeInEseBy 
	 * @property boolean $GradeModifyLock the value for blnGradeModifyLock 
	 * @property string $GradeCode the value for strGradeCode 
	 * @property boolean $GradeImprovement the value for blnGradeImprovement 
	 * @property integer $RefGradeImprovement the value for intRefGradeImprovement 
	 * @property boolean $ChangeInEseLock the value for blnChangeInEseLock 
	 * @property string $ReevaluationChangeOfMarks the value for strReevaluationChangeOfMarks 
	 * @property Login $StudentObject the value for the Login object referenced by intStudent 
	 * @property Role $StudeRoleObject the value for the Role object referenced by intStudeRole 
	 * @property YearlySubject $SubjectObject the value for the YearlySubject object referenced by intSubject 
	 * @property Grade $RelativeGradeObject the value for the Grade object referenced by intRelativeGrade 
	 * @property Grade $AbsoluteGradeObject the value for the Grade object referenced by intAbsoluteGrade 
	 * @property Grade $PenaltyGradeObject the value for the Grade object referenced by intPenaltyGrade 
	 * @property Login $ChangeInEseByObject the value for the Login object referenced by intChangeInEseBy 
	 * @property ApplyGradeImproment $RefGradeImprovementObject the value for the ApplyGradeImproment object referenced by intRefGradeImprovement 
	 * @property-read ApplyGradeImproment $_ApplyGradeImpromentAsGradecard the value for the private _objApplyGradeImpromentAsGradecard (Read-Only) if set due to an expansion on the apply_grade_improment.gradecard reverse relationship
	 * @property-read ApplyGradeImproment[] $_ApplyGradeImpromentAsGradecardArray the value for the private _objApplyGradeImpromentAsGradecardArray (Read-Only) if set due to an ExpandAsArray on the apply_grade_improment.gradecard reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class GradeCardGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column grade_card.idgrade_card
		 * @var integer intIdgradeCard
		 */
		protected $intIdgradeCard;
		const IdgradeCardDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.student
		 * @var integer intStudent
		 */
		protected $intStudent;
		const StudentDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.stude_role
		 * @var integer intStudeRole
		 */
		protected $intStudeRole;
		const StudeRoleDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.subject
		 * @var integer intSubject
		 */
		protected $intSubject;
		const SubjectDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.total
		 * @var string strTotal
		 */
		protected $strTotal;
		const TotalMaxLength = 45;
		const TotalDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.relative_grade
		 * @var integer intRelativeGrade
		 */
		protected $intRelativeGrade;
		const RelativeGradeDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.absolute_grade
		 * @var integer intAbsoluteGrade
		 */
		protected $intAbsoluteGrade;
		const AbsoluteGradeDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.by_makeup
		 * @var boolean blnByMakeup
		 */
		protected $blnByMakeup;
		const ByMakeupDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.penalty_reason
		 * @var string strPenaltyReason
		 */
		protected $strPenaltyReason;
		const PenaltyReasonDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.penalty_grade
		 * @var integer intPenaltyGrade
		 */
		protected $intPenaltyGrade;
		const PenaltyGradeDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.grace_marks
		 * @var string strGraceMarks
		 */
		protected $strGraceMarks;
		const GraceMarksMaxLength = 45;
		const GraceMarksDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.change_in_ese
		 * @var string strChangeInEse
		 */
		protected $strChangeInEse;
		const ChangeInEseMaxLength = 45;
		const ChangeInEseDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.change_in_ese_by
		 * @var integer intChangeInEseBy
		 */
		protected $intChangeInEseBy;
		const ChangeInEseByDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.grade_modify_lock
		 * @var boolean blnGradeModifyLock
		 */
		protected $blnGradeModifyLock;
		const GradeModifyLockDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.grade_code
		 * @var string strGradeCode
		 */
		protected $strGradeCode;
		const GradeCodeMaxLength = 255;
		const GradeCodeDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.grade_improvement
		 * @var boolean blnGradeImprovement
		 */
		protected $blnGradeImprovement;
		const GradeImprovementDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.ref_grade_improvement
		 * @var integer intRefGradeImprovement
		 */
		protected $intRefGradeImprovement;
		const RefGradeImprovementDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.change_in_ese_lock
		 * @var boolean blnChangeInEseLock
		 */
		protected $blnChangeInEseLock;
		const ChangeInEseLockDefault = null;


		/**
		 * Protected member variable that maps to the database column grade_card.reevaluation_change_of_marks
		 * @var string strReevaluationChangeOfMarks
		 */
		protected $strReevaluationChangeOfMarks;
		const ReevaluationChangeOfMarksMaxLength = 45;
		const ReevaluationChangeOfMarksDefault = null;


		/**
		 * Private member variable that stores a reference to a single ApplyGradeImpromentAsGradecard object
		 * (of type ApplyGradeImproment), if this GradeCard object was restored with
		 * an expansion on the apply_grade_improment association table.
		 * @var ApplyGradeImproment _objApplyGradeImpromentAsGradecard;
		 */
		private $_objApplyGradeImpromentAsGradecard;

		/**
		 * Private member variable that stores a reference to an array of ApplyGradeImpromentAsGradecard objects
		 * (of type ApplyGradeImproment[]), if this GradeCard object was restored with
		 * an ExpandAsArray on the apply_grade_improment association table.
		 * @var ApplyGradeImproment[] _objApplyGradeImpromentAsGradecardArray;
		 */
		private $_objApplyGradeImpromentAsGradecardArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column grade_card.student.
		 *
		 * NOTE: Always use the StudentObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objStudentObject
		 */
		protected $objStudentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column grade_card.stude_role.
		 *
		 * NOTE: Always use the StudeRoleObject property getter to correctly retrieve this Role object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Role objStudeRoleObject
		 */
		protected $objStudeRoleObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column grade_card.subject.
		 *
		 * NOTE: Always use the SubjectObject property getter to correctly retrieve this YearlySubject object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var YearlySubject objSubjectObject
		 */
		protected $objSubjectObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column grade_card.relative_grade.
		 *
		 * NOTE: Always use the RelativeGradeObject property getter to correctly retrieve this Grade object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Grade objRelativeGradeObject
		 */
		protected $objRelativeGradeObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column grade_card.absolute_grade.
		 *
		 * NOTE: Always use the AbsoluteGradeObject property getter to correctly retrieve this Grade object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Grade objAbsoluteGradeObject
		 */
		protected $objAbsoluteGradeObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column grade_card.penalty_grade.
		 *
		 * NOTE: Always use the PenaltyGradeObject property getter to correctly retrieve this Grade object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Grade objPenaltyGradeObject
		 */
		protected $objPenaltyGradeObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column grade_card.change_in_ese_by.
		 *
		 * NOTE: Always use the ChangeInEseByObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objChangeInEseByObject
		 */
		protected $objChangeInEseByObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column grade_card.ref_grade_improvement.
		 *
		 * NOTE: Always use the RefGradeImprovementObject property getter to correctly retrieve this ApplyGradeImproment object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var ApplyGradeImproment objRefGradeImprovementObject
		 */
		protected $objRefGradeImprovementObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdgradeCard = GradeCard::IdgradeCardDefault;
			$this->intStudent = GradeCard::StudentDefault;
			$this->intStudeRole = GradeCard::StudeRoleDefault;
			$this->intSubject = GradeCard::SubjectDefault;
			$this->strTotal = GradeCard::TotalDefault;
			$this->intRelativeGrade = GradeCard::RelativeGradeDefault;
			$this->intAbsoluteGrade = GradeCard::AbsoluteGradeDefault;
			$this->blnByMakeup = GradeCard::ByMakeupDefault;
			$this->strPenaltyReason = GradeCard::PenaltyReasonDefault;
			$this->intPenaltyGrade = GradeCard::PenaltyGradeDefault;
			$this->strGraceMarks = GradeCard::GraceMarksDefault;
			$this->strChangeInEse = GradeCard::ChangeInEseDefault;
			$this->intChangeInEseBy = GradeCard::ChangeInEseByDefault;
			$this->blnGradeModifyLock = GradeCard::GradeModifyLockDefault;
			$this->strGradeCode = GradeCard::GradeCodeDefault;
			$this->blnGradeImprovement = GradeCard::GradeImprovementDefault;
			$this->intRefGradeImprovement = GradeCard::RefGradeImprovementDefault;
			$this->blnChangeInEseLock = GradeCard::ChangeInEseLockDefault;
			$this->strReevaluationChangeOfMarks = GradeCard::ReevaluationChangeOfMarksDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a GradeCard from PK Info
		 * @param integer $intIdgradeCard
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard
		 */
		public static function Load($intIdgradeCard, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'GradeCard', $intIdgradeCard);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = GradeCard::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::GradeCard()->IdgradeCard, $intIdgradeCard)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all GradeCards
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call GradeCard::QueryArray to perform the LoadAll query
			try {
				return GradeCard::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all GradeCards
		 * @return int
		 */
		public static function CountAll() {
			// Call GradeCard::QueryCount to perform the CountAll query
			return GradeCard::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = GradeCard::GetDatabase();

			// Create/Build out the QueryBuilder object with GradeCard-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'grade_card');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				GradeCard::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('grade_card');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single GradeCard object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return GradeCard the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = GradeCard::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new GradeCard object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = GradeCard::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return GradeCard::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of GradeCard objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return GradeCard[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = GradeCard::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return GradeCard::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = GradeCard::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of GradeCard objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = GradeCard::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = GradeCard::GetDatabase();

			$strQuery = GradeCard::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/gradecard', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = GradeCard::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this GradeCard
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'grade_card';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idgrade_card', $strAliasPrefix . 'idgrade_card');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idgrade_card', $strAliasPrefix . 'idgrade_card');
			    $objBuilder->AddSelectItem($strTableName, 'student', $strAliasPrefix . 'student');
			    $objBuilder->AddSelectItem($strTableName, 'stude_role', $strAliasPrefix . 'stude_role');
			    $objBuilder->AddSelectItem($strTableName, 'subject', $strAliasPrefix . 'subject');
			    $objBuilder->AddSelectItem($strTableName, 'total', $strAliasPrefix . 'total');
			    $objBuilder->AddSelectItem($strTableName, 'relative_grade', $strAliasPrefix . 'relative_grade');
			    $objBuilder->AddSelectItem($strTableName, 'absolute_grade', $strAliasPrefix . 'absolute_grade');
			    $objBuilder->AddSelectItem($strTableName, 'by_makeup', $strAliasPrefix . 'by_makeup');
			    $objBuilder->AddSelectItem($strTableName, 'penalty_reason', $strAliasPrefix . 'penalty_reason');
			    $objBuilder->AddSelectItem($strTableName, 'penalty_grade', $strAliasPrefix . 'penalty_grade');
			    $objBuilder->AddSelectItem($strTableName, 'grace_marks', $strAliasPrefix . 'grace_marks');
			    $objBuilder->AddSelectItem($strTableName, 'change_in_ese', $strAliasPrefix . 'change_in_ese');
			    $objBuilder->AddSelectItem($strTableName, 'change_in_ese_by', $strAliasPrefix . 'change_in_ese_by');
			    $objBuilder->AddSelectItem($strTableName, 'grade_modify_lock', $strAliasPrefix . 'grade_modify_lock');
			    $objBuilder->AddSelectItem($strTableName, 'grade_code', $strAliasPrefix . 'grade_code');
			    $objBuilder->AddSelectItem($strTableName, 'grade_improvement', $strAliasPrefix . 'grade_improvement');
			    $objBuilder->AddSelectItem($strTableName, 'ref_grade_improvement', $strAliasPrefix . 'ref_grade_improvement');
			    $objBuilder->AddSelectItem($strTableName, 'change_in_ese_lock', $strAliasPrefix . 'change_in_ese_lock');
			    $objBuilder->AddSelectItem($strTableName, 'reevaluation_change_of_marks', $strAliasPrefix . 'reevaluation_change_of_marks');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a GradeCard from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this GradeCard::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return GradeCard
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idgrade_card';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdgradeCard == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'grade_card__';


						// Expanding reverse references: ApplyGradeImpromentAsGradecard
						$strAlias = $strAliasPrefix . 'applygradeimpromentasgradecard__idapply_grade_improment';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objApplyGradeImpromentAsGradecardArray)
								$objPreviousItem->_objApplyGradeImpromentAsGradecardArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objApplyGradeImpromentAsGradecardArray)) {
								$objPreviousChildItems = $objPreviousItem->_objApplyGradeImpromentAsGradecardArray;
								$objChildItem = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentasgradecard__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objApplyGradeImpromentAsGradecardArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objApplyGradeImpromentAsGradecardArray[] = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentasgradecard__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'grade_card__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the GradeCard object
			$objToReturn = new GradeCard();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idgrade_card';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdgradeCard = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'student';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intStudent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'stude_role';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intStudeRole = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSubject = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'total';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strTotal = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'relative_grade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intRelativeGrade = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'absolute_grade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intAbsoluteGrade = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'by_makeup';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnByMakeup = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'penalty_reason';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strPenaltyReason = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'penalty_grade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intPenaltyGrade = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'grace_marks';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strGraceMarks = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'change_in_ese';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strChangeInEse = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'change_in_ese_by';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intChangeInEseBy = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'grade_modify_lock';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnGradeModifyLock = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'grade_code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strGradeCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'grade_improvement';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnGradeImprovement = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'ref_grade_improvement';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intRefGradeImprovement = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'change_in_ese_lock';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnChangeInEseLock = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'reevaluation_change_of_marks';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strReevaluationChangeOfMarks = $objDbRow->GetColumn($strAliasName, 'VarChar');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdgradeCard != $objPreviousItem->IdgradeCard) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objApplyGradeImpromentAsGradecardArray);
					$cnt = count($objToReturn->_objApplyGradeImpromentAsGradecardArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objApplyGradeImpromentAsGradecardArray, $objToReturn->_objApplyGradeImpromentAsGradecardArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'grade_card__';

			// Check for StudentObject Early Binding
			$strAlias = $strAliasPrefix . 'student__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objStudentObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'student__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for StudeRoleObject Early Binding
			$strAlias = $strAliasPrefix . 'stude_role__idrole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objStudeRoleObject = Role::InstantiateDbRow($objDbRow, $strAliasPrefix . 'stude_role__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for SubjectObject Early Binding
			$strAlias = $strAliasPrefix . 'subject__idyearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSubjectObject = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'subject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for RelativeGradeObject Early Binding
			$strAlias = $strAliasPrefix . 'relative_grade__idgrade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objRelativeGradeObject = Grade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'relative_grade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for AbsoluteGradeObject Early Binding
			$strAlias = $strAliasPrefix . 'absolute_grade__idgrade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objAbsoluteGradeObject = Grade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'absolute_grade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for PenaltyGradeObject Early Binding
			$strAlias = $strAliasPrefix . 'penalty_grade__idgrade';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objPenaltyGradeObject = Grade::InstantiateDbRow($objDbRow, $strAliasPrefix . 'penalty_grade__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ChangeInEseByObject Early Binding
			$strAlias = $strAliasPrefix . 'change_in_ese_by__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objChangeInEseByObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'change_in_ese_by__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for RefGradeImprovementObject Early Binding
			$strAlias = $strAliasPrefix . 'ref_grade_improvement__idapply_grade_improment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objRefGradeImprovementObject = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ref_grade_improvement__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for ApplyGradeImpromentAsGradecard Virtual Binding
			$strAlias = $strAliasPrefix . 'applygradeimpromentasgradecard__idapply_grade_improment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objApplyGradeImpromentAsGradecardArray)
				$objToReturn->_objApplyGradeImpromentAsGradecardArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objApplyGradeImpromentAsGradecardArray[] = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentasgradecard__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objApplyGradeImpromentAsGradecard = ApplyGradeImproment::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applygradeimpromentasgradecard__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of GradeCards from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return GradeCard[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = GradeCard::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = GradeCard::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single GradeCard object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return GradeCard next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return GradeCard::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single GradeCard object,
		 * by IdgradeCard Index(es)
		 * @param integer $intIdgradeCard
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard
		*/
		public static function LoadByIdgradeCard($intIdgradeCard, $objOptionalClauses = null) {
			return GradeCard::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::GradeCard()->IdgradeCard, $intIdgradeCard)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of GradeCard objects,
		 * by RelativeGrade Index(es)
		 * @param integer $intRelativeGrade
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		*/
		public static function LoadArrayByRelativeGrade($intRelativeGrade, $objOptionalClauses = null) {
			// Call GradeCard::QueryArray to perform the LoadArrayByRelativeGrade query
			try {
				return GradeCard::QueryArray(
					QQ::Equal(QQN::GradeCard()->RelativeGrade, $intRelativeGrade),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count GradeCards
		 * by RelativeGrade Index(es)
		 * @param integer $intRelativeGrade
		 * @return int
		*/
		public static function CountByRelativeGrade($intRelativeGrade) {
			// Call GradeCard::QueryCount to perform the CountByRelativeGrade query
			return GradeCard::QueryCount(
				QQ::Equal(QQN::GradeCard()->RelativeGrade, $intRelativeGrade)
			);
		}

		/**
		 * Load an array of GradeCard objects,
		 * by AbsoluteGrade Index(es)
		 * @param integer $intAbsoluteGrade
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		*/
		public static function LoadArrayByAbsoluteGrade($intAbsoluteGrade, $objOptionalClauses = null) {
			// Call GradeCard::QueryArray to perform the LoadArrayByAbsoluteGrade query
			try {
				return GradeCard::QueryArray(
					QQ::Equal(QQN::GradeCard()->AbsoluteGrade, $intAbsoluteGrade),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count GradeCards
		 * by AbsoluteGrade Index(es)
		 * @param integer $intAbsoluteGrade
		 * @return int
		*/
		public static function CountByAbsoluteGrade($intAbsoluteGrade) {
			// Call GradeCard::QueryCount to perform the CountByAbsoluteGrade query
			return GradeCard::QueryCount(
				QQ::Equal(QQN::GradeCard()->AbsoluteGrade, $intAbsoluteGrade)
			);
		}

		/**
		 * Load an array of GradeCard objects,
		 * by Subject Index(es)
		 * @param integer $intSubject
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		*/
		public static function LoadArrayBySubject($intSubject, $objOptionalClauses = null) {
			// Call GradeCard::QueryArray to perform the LoadArrayBySubject query
			try {
				return GradeCard::QueryArray(
					QQ::Equal(QQN::GradeCard()->Subject, $intSubject),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count GradeCards
		 * by Subject Index(es)
		 * @param integer $intSubject
		 * @return int
		*/
		public static function CountBySubject($intSubject) {
			// Call GradeCard::QueryCount to perform the CountBySubject query
			return GradeCard::QueryCount(
				QQ::Equal(QQN::GradeCard()->Subject, $intSubject)
			);
		}

		/**
		 * Load an array of GradeCard objects,
		 * by StudeRole Index(es)
		 * @param integer $intStudeRole
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		*/
		public static function LoadArrayByStudeRole($intStudeRole, $objOptionalClauses = null) {
			// Call GradeCard::QueryArray to perform the LoadArrayByStudeRole query
			try {
				return GradeCard::QueryArray(
					QQ::Equal(QQN::GradeCard()->StudeRole, $intStudeRole),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count GradeCards
		 * by StudeRole Index(es)
		 * @param integer $intStudeRole
		 * @return int
		*/
		public static function CountByStudeRole($intStudeRole) {
			// Call GradeCard::QueryCount to perform the CountByStudeRole query
			return GradeCard::QueryCount(
				QQ::Equal(QQN::GradeCard()->StudeRole, $intStudeRole)
			);
		}

		/**
		 * Load an array of GradeCard objects,
		 * by Student Index(es)
		 * @param integer $intStudent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		*/
		public static function LoadArrayByStudent($intStudent, $objOptionalClauses = null) {
			// Call GradeCard::QueryArray to perform the LoadArrayByStudent query
			try {
				return GradeCard::QueryArray(
					QQ::Equal(QQN::GradeCard()->Student, $intStudent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count GradeCards
		 * by Student Index(es)
		 * @param integer $intStudent
		 * @return int
		*/
		public static function CountByStudent($intStudent) {
			// Call GradeCard::QueryCount to perform the CountByStudent query
			return GradeCard::QueryCount(
				QQ::Equal(QQN::GradeCard()->Student, $intStudent)
			);
		}

		/**
		 * Load an array of GradeCard objects,
		 * by PenaltyGrade Index(es)
		 * @param integer $intPenaltyGrade
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		*/
		public static function LoadArrayByPenaltyGrade($intPenaltyGrade, $objOptionalClauses = null) {
			// Call GradeCard::QueryArray to perform the LoadArrayByPenaltyGrade query
			try {
				return GradeCard::QueryArray(
					QQ::Equal(QQN::GradeCard()->PenaltyGrade, $intPenaltyGrade),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count GradeCards
		 * by PenaltyGrade Index(es)
		 * @param integer $intPenaltyGrade
		 * @return int
		*/
		public static function CountByPenaltyGrade($intPenaltyGrade) {
			// Call GradeCard::QueryCount to perform the CountByPenaltyGrade query
			return GradeCard::QueryCount(
				QQ::Equal(QQN::GradeCard()->PenaltyGrade, $intPenaltyGrade)
			);
		}

		/**
		 * Load an array of GradeCard objects,
		 * by ChangeInEseBy Index(es)
		 * @param integer $intChangeInEseBy
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		*/
		public static function LoadArrayByChangeInEseBy($intChangeInEseBy, $objOptionalClauses = null) {
			// Call GradeCard::QueryArray to perform the LoadArrayByChangeInEseBy query
			try {
				return GradeCard::QueryArray(
					QQ::Equal(QQN::GradeCard()->ChangeInEseBy, $intChangeInEseBy),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count GradeCards
		 * by ChangeInEseBy Index(es)
		 * @param integer $intChangeInEseBy
		 * @return int
		*/
		public static function CountByChangeInEseBy($intChangeInEseBy) {
			// Call GradeCard::QueryCount to perform the CountByChangeInEseBy query
			return GradeCard::QueryCount(
				QQ::Equal(QQN::GradeCard()->ChangeInEseBy, $intChangeInEseBy)
			);
		}

		/**
		 * Load an array of GradeCard objects,
		 * by RefGradeImprovement Index(es)
		 * @param integer $intRefGradeImprovement
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		*/
		public static function LoadArrayByRefGradeImprovement($intRefGradeImprovement, $objOptionalClauses = null) {
			// Call GradeCard::QueryArray to perform the LoadArrayByRefGradeImprovement query
			try {
				return GradeCard::QueryArray(
					QQ::Equal(QQN::GradeCard()->RefGradeImprovement, $intRefGradeImprovement),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count GradeCards
		 * by RefGradeImprovement Index(es)
		 * @param integer $intRefGradeImprovement
		 * @return int
		*/
		public static function CountByRefGradeImprovement($intRefGradeImprovement) {
			// Call GradeCard::QueryCount to perform the CountByRefGradeImprovement query
			return GradeCard::QueryCount(
				QQ::Equal(QQN::GradeCard()->RefGradeImprovement, $intRefGradeImprovement)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this GradeCard
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = GradeCard::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `grade_card` (
							`student`,
							`stude_role`,
							`subject`,
							`total`,
							`relative_grade`,
							`absolute_grade`,
							`by_makeup`,
							`penalty_reason`,
							`penalty_grade`,
							`grace_marks`,
							`change_in_ese`,
							`change_in_ese_by`,
							`grade_modify_lock`,
							`grade_code`,
							`grade_improvement`,
							`ref_grade_improvement`,
							`change_in_ese_lock`,
							`reevaluation_change_of_marks`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intStudent) . ',
							' . $objDatabase->SqlVariable($this->intStudeRole) . ',
							' . $objDatabase->SqlVariable($this->intSubject) . ',
							' . $objDatabase->SqlVariable($this->strTotal) . ',
							' . $objDatabase->SqlVariable($this->intRelativeGrade) . ',
							' . $objDatabase->SqlVariable($this->intAbsoluteGrade) . ',
							' . $objDatabase->SqlVariable($this->blnByMakeup) . ',
							' . $objDatabase->SqlVariable($this->strPenaltyReason) . ',
							' . $objDatabase->SqlVariable($this->intPenaltyGrade) . ',
							' . $objDatabase->SqlVariable($this->strGraceMarks) . ',
							' . $objDatabase->SqlVariable($this->strChangeInEse) . ',
							' . $objDatabase->SqlVariable($this->intChangeInEseBy) . ',
							' . $objDatabase->SqlVariable($this->blnGradeModifyLock) . ',
							' . $objDatabase->SqlVariable($this->strGradeCode) . ',
							' . $objDatabase->SqlVariable($this->blnGradeImprovement) . ',
							' . $objDatabase->SqlVariable($this->intRefGradeImprovement) . ',
							' . $objDatabase->SqlVariable($this->blnChangeInEseLock) . ',
							' . $objDatabase->SqlVariable($this->strReevaluationChangeOfMarks) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdgradeCard = $objDatabase->InsertId('grade_card', 'idgrade_card');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`grade_card`
						SET
							`student` = ' . $objDatabase->SqlVariable($this->intStudent) . ',
							`stude_role` = ' . $objDatabase->SqlVariable($this->intStudeRole) . ',
							`subject` = ' . $objDatabase->SqlVariable($this->intSubject) . ',
							`total` = ' . $objDatabase->SqlVariable($this->strTotal) . ',
							`relative_grade` = ' . $objDatabase->SqlVariable($this->intRelativeGrade) . ',
							`absolute_grade` = ' . $objDatabase->SqlVariable($this->intAbsoluteGrade) . ',
							`by_makeup` = ' . $objDatabase->SqlVariable($this->blnByMakeup) . ',
							`penalty_reason` = ' . $objDatabase->SqlVariable($this->strPenaltyReason) . ',
							`penalty_grade` = ' . $objDatabase->SqlVariable($this->intPenaltyGrade) . ',
							`grace_marks` = ' . $objDatabase->SqlVariable($this->strGraceMarks) . ',
							`change_in_ese` = ' . $objDatabase->SqlVariable($this->strChangeInEse) . ',
							`change_in_ese_by` = ' . $objDatabase->SqlVariable($this->intChangeInEseBy) . ',
							`grade_modify_lock` = ' . $objDatabase->SqlVariable($this->blnGradeModifyLock) . ',
							`grade_code` = ' . $objDatabase->SqlVariable($this->strGradeCode) . ',
							`grade_improvement` = ' . $objDatabase->SqlVariable($this->blnGradeImprovement) . ',
							`ref_grade_improvement` = ' . $objDatabase->SqlVariable($this->intRefGradeImprovement) . ',
							`change_in_ese_lock` = ' . $objDatabase->SqlVariable($this->blnChangeInEseLock) . ',
							`reevaluation_change_of_marks` = ' . $objDatabase->SqlVariable($this->strReevaluationChangeOfMarks) . '
						WHERE
							`idgrade_card` = ' . $objDatabase->SqlVariable($this->intIdgradeCard) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this GradeCard
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this GradeCard with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = GradeCard::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($this->intIdgradeCard) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this GradeCard ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'GradeCard', $this->intIdgradeCard);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all GradeCards
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = GradeCard::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate grade_card table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = GradeCard::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `grade_card`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this GradeCard from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved GradeCard object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = GradeCard::Load($this->intIdgradeCard);

			// Update $this's local variables to match
			$this->Student = $objReloaded->Student;
			$this->StudeRole = $objReloaded->StudeRole;
			$this->Subject = $objReloaded->Subject;
			$this->strTotal = $objReloaded->strTotal;
			$this->RelativeGrade = $objReloaded->RelativeGrade;
			$this->AbsoluteGrade = $objReloaded->AbsoluteGrade;
			$this->blnByMakeup = $objReloaded->blnByMakeup;
			$this->strPenaltyReason = $objReloaded->strPenaltyReason;
			$this->PenaltyGrade = $objReloaded->PenaltyGrade;
			$this->strGraceMarks = $objReloaded->strGraceMarks;
			$this->strChangeInEse = $objReloaded->strChangeInEse;
			$this->ChangeInEseBy = $objReloaded->ChangeInEseBy;
			$this->blnGradeModifyLock = $objReloaded->blnGradeModifyLock;
			$this->strGradeCode = $objReloaded->strGradeCode;
			$this->blnGradeImprovement = $objReloaded->blnGradeImprovement;
			$this->RefGradeImprovement = $objReloaded->RefGradeImprovement;
			$this->blnChangeInEseLock = $objReloaded->blnChangeInEseLock;
			$this->strReevaluationChangeOfMarks = $objReloaded->strReevaluationChangeOfMarks;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdgradeCard':
					/**
					 * Gets the value for intIdgradeCard (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdgradeCard;

				case 'Student':
					/**
					 * Gets the value for intStudent 
					 * @return integer
					 */
					return $this->intStudent;

				case 'StudeRole':
					/**
					 * Gets the value for intStudeRole 
					 * @return integer
					 */
					return $this->intStudeRole;

				case 'Subject':
					/**
					 * Gets the value for intSubject 
					 * @return integer
					 */
					return $this->intSubject;

				case 'Total':
					/**
					 * Gets the value for strTotal 
					 * @return string
					 */
					return $this->strTotal;

				case 'RelativeGrade':
					/**
					 * Gets the value for intRelativeGrade 
					 * @return integer
					 */
					return $this->intRelativeGrade;

				case 'AbsoluteGrade':
					/**
					 * Gets the value for intAbsoluteGrade 
					 * @return integer
					 */
					return $this->intAbsoluteGrade;

				case 'ByMakeup':
					/**
					 * Gets the value for blnByMakeup 
					 * @return boolean
					 */
					return $this->blnByMakeup;

				case 'PenaltyReason':
					/**
					 * Gets the value for strPenaltyReason 
					 * @return string
					 */
					return $this->strPenaltyReason;

				case 'PenaltyGrade':
					/**
					 * Gets the value for intPenaltyGrade 
					 * @return integer
					 */
					return $this->intPenaltyGrade;

				case 'GraceMarks':
					/**
					 * Gets the value for strGraceMarks 
					 * @return string
					 */
					return $this->strGraceMarks;

				case 'ChangeInEse':
					/**
					 * Gets the value for strChangeInEse 
					 * @return string
					 */
					return $this->strChangeInEse;

				case 'ChangeInEseBy':
					/**
					 * Gets the value for intChangeInEseBy 
					 * @return integer
					 */
					return $this->intChangeInEseBy;

				case 'GradeModifyLock':
					/**
					 * Gets the value for blnGradeModifyLock 
					 * @return boolean
					 */
					return $this->blnGradeModifyLock;

				case 'GradeCode':
					/**
					 * Gets the value for strGradeCode 
					 * @return string
					 */
					return $this->strGradeCode;

				case 'GradeImprovement':
					/**
					 * Gets the value for blnGradeImprovement 
					 * @return boolean
					 */
					return $this->blnGradeImprovement;

				case 'RefGradeImprovement':
					/**
					 * Gets the value for intRefGradeImprovement 
					 * @return integer
					 */
					return $this->intRefGradeImprovement;

				case 'ChangeInEseLock':
					/**
					 * Gets the value for blnChangeInEseLock 
					 * @return boolean
					 */
					return $this->blnChangeInEseLock;

				case 'ReevaluationChangeOfMarks':
					/**
					 * Gets the value for strReevaluationChangeOfMarks 
					 * @return string
					 */
					return $this->strReevaluationChangeOfMarks;


				///////////////////
				// Member Objects
				///////////////////
				case 'StudentObject':
					/**
					 * Gets the value for the Login object referenced by intStudent 
					 * @return Login
					 */
					try {
						if ((!$this->objStudentObject) && (!is_null($this->intStudent)))
							$this->objStudentObject = Login::Load($this->intStudent);
						return $this->objStudentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'StudeRoleObject':
					/**
					 * Gets the value for the Role object referenced by intStudeRole 
					 * @return Role
					 */
					try {
						if ((!$this->objStudeRoleObject) && (!is_null($this->intStudeRole)))
							$this->objStudeRoleObject = Role::Load($this->intStudeRole);
						return $this->objStudeRoleObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SubjectObject':
					/**
					 * Gets the value for the YearlySubject object referenced by intSubject 
					 * @return YearlySubject
					 */
					try {
						if ((!$this->objSubjectObject) && (!is_null($this->intSubject)))
							$this->objSubjectObject = YearlySubject::Load($this->intSubject);
						return $this->objSubjectObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RelativeGradeObject':
					/**
					 * Gets the value for the Grade object referenced by intRelativeGrade 
					 * @return Grade
					 */
					try {
						if ((!$this->objRelativeGradeObject) && (!is_null($this->intRelativeGrade)))
							$this->objRelativeGradeObject = Grade::Load($this->intRelativeGrade);
						return $this->objRelativeGradeObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AbsoluteGradeObject':
					/**
					 * Gets the value for the Grade object referenced by intAbsoluteGrade 
					 * @return Grade
					 */
					try {
						if ((!$this->objAbsoluteGradeObject) && (!is_null($this->intAbsoluteGrade)))
							$this->objAbsoluteGradeObject = Grade::Load($this->intAbsoluteGrade);
						return $this->objAbsoluteGradeObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'PenaltyGradeObject':
					/**
					 * Gets the value for the Grade object referenced by intPenaltyGrade 
					 * @return Grade
					 */
					try {
						if ((!$this->objPenaltyGradeObject) && (!is_null($this->intPenaltyGrade)))
							$this->objPenaltyGradeObject = Grade::Load($this->intPenaltyGrade);
						return $this->objPenaltyGradeObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ChangeInEseByObject':
					/**
					 * Gets the value for the Login object referenced by intChangeInEseBy 
					 * @return Login
					 */
					try {
						if ((!$this->objChangeInEseByObject) && (!is_null($this->intChangeInEseBy)))
							$this->objChangeInEseByObject = Login::Load($this->intChangeInEseBy);
						return $this->objChangeInEseByObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RefGradeImprovementObject':
					/**
					 * Gets the value for the ApplyGradeImproment object referenced by intRefGradeImprovement 
					 * @return ApplyGradeImproment
					 */
					try {
						if ((!$this->objRefGradeImprovementObject) && (!is_null($this->intRefGradeImprovement)))
							$this->objRefGradeImprovementObject = ApplyGradeImproment::Load($this->intRefGradeImprovement);
						return $this->objRefGradeImprovementObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_ApplyGradeImpromentAsGradecard':
					/**
					 * Gets the value for the private _objApplyGradeImpromentAsGradecard (Read-Only)
					 * if set due to an expansion on the apply_grade_improment.gradecard reverse relationship
					 * @return ApplyGradeImproment
					 */
					return $this->_objApplyGradeImpromentAsGradecard;

				case '_ApplyGradeImpromentAsGradecardArray':
					/**
					 * Gets the value for the private _objApplyGradeImpromentAsGradecardArray (Read-Only)
					 * if set due to an ExpandAsArray on the apply_grade_improment.gradecard reverse relationship
					 * @return ApplyGradeImproment[]
					 */
					return $this->_objApplyGradeImpromentAsGradecardArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Student':
					/**
					 * Sets the value for intStudent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objStudentObject = null;
						return ($this->intStudent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'StudeRole':
					/**
					 * Sets the value for intStudeRole 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objStudeRoleObject = null;
						return ($this->intStudeRole = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Subject':
					/**
					 * Sets the value for intSubject 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSubjectObject = null;
						return ($this->intSubject = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Total':
					/**
					 * Sets the value for strTotal 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strTotal = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RelativeGrade':
					/**
					 * Sets the value for intRelativeGrade 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objRelativeGradeObject = null;
						return ($this->intRelativeGrade = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AbsoluteGrade':
					/**
					 * Sets the value for intAbsoluteGrade 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objAbsoluteGradeObject = null;
						return ($this->intAbsoluteGrade = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ByMakeup':
					/**
					 * Sets the value for blnByMakeup 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnByMakeup = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'PenaltyReason':
					/**
					 * Sets the value for strPenaltyReason 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strPenaltyReason = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'PenaltyGrade':
					/**
					 * Sets the value for intPenaltyGrade 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objPenaltyGradeObject = null;
						return ($this->intPenaltyGrade = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GraceMarks':
					/**
					 * Sets the value for strGraceMarks 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strGraceMarks = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ChangeInEse':
					/**
					 * Sets the value for strChangeInEse 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strChangeInEse = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ChangeInEseBy':
					/**
					 * Sets the value for intChangeInEseBy 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objChangeInEseByObject = null;
						return ($this->intChangeInEseBy = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GradeModifyLock':
					/**
					 * Sets the value for blnGradeModifyLock 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnGradeModifyLock = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GradeCode':
					/**
					 * Sets the value for strGradeCode 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strGradeCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GradeImprovement':
					/**
					 * Sets the value for blnGradeImprovement 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnGradeImprovement = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RefGradeImprovement':
					/**
					 * Sets the value for intRefGradeImprovement 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objRefGradeImprovementObject = null;
						return ($this->intRefGradeImprovement = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ChangeInEseLock':
					/**
					 * Sets the value for blnChangeInEseLock 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnChangeInEseLock = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ReevaluationChangeOfMarks':
					/**
					 * Sets the value for strReevaluationChangeOfMarks 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strReevaluationChangeOfMarks = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'StudentObject':
					/**
					 * Sets the value for the Login object referenced by intStudent 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intStudent = null;
						$this->objStudentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved StudentObject for this GradeCard');

						// Update Local Member Variables
						$this->objStudentObject = $mixValue;
						$this->intStudent = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'StudeRoleObject':
					/**
					 * Sets the value for the Role object referenced by intStudeRole 
					 * @param Role $mixValue
					 * @return Role
					 */
					if (is_null($mixValue)) {
						$this->intStudeRole = null;
						$this->objStudeRoleObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Role object
						try {
							$mixValue = QType::Cast($mixValue, 'Role');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Role object
						if (is_null($mixValue->Idrole))
							throw new QCallerException('Unable to set an unsaved StudeRoleObject for this GradeCard');

						// Update Local Member Variables
						$this->objStudeRoleObject = $mixValue;
						$this->intStudeRole = $mixValue->Idrole;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'SubjectObject':
					/**
					 * Sets the value for the YearlySubject object referenced by intSubject 
					 * @param YearlySubject $mixValue
					 * @return YearlySubject
					 */
					if (is_null($mixValue)) {
						$this->intSubject = null;
						$this->objSubjectObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a YearlySubject object
						try {
							$mixValue = QType::Cast($mixValue, 'YearlySubject');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED YearlySubject object
						if (is_null($mixValue->IdyearlySubject))
							throw new QCallerException('Unable to set an unsaved SubjectObject for this GradeCard');

						// Update Local Member Variables
						$this->objSubjectObject = $mixValue;
						$this->intSubject = $mixValue->IdyearlySubject;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'RelativeGradeObject':
					/**
					 * Sets the value for the Grade object referenced by intRelativeGrade 
					 * @param Grade $mixValue
					 * @return Grade
					 */
					if (is_null($mixValue)) {
						$this->intRelativeGrade = null;
						$this->objRelativeGradeObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Grade object
						try {
							$mixValue = QType::Cast($mixValue, 'Grade');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Grade object
						if (is_null($mixValue->Idgrade))
							throw new QCallerException('Unable to set an unsaved RelativeGradeObject for this GradeCard');

						// Update Local Member Variables
						$this->objRelativeGradeObject = $mixValue;
						$this->intRelativeGrade = $mixValue->Idgrade;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'AbsoluteGradeObject':
					/**
					 * Sets the value for the Grade object referenced by intAbsoluteGrade 
					 * @param Grade $mixValue
					 * @return Grade
					 */
					if (is_null($mixValue)) {
						$this->intAbsoluteGrade = null;
						$this->objAbsoluteGradeObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Grade object
						try {
							$mixValue = QType::Cast($mixValue, 'Grade');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Grade object
						if (is_null($mixValue->Idgrade))
							throw new QCallerException('Unable to set an unsaved AbsoluteGradeObject for this GradeCard');

						// Update Local Member Variables
						$this->objAbsoluteGradeObject = $mixValue;
						$this->intAbsoluteGrade = $mixValue->Idgrade;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'PenaltyGradeObject':
					/**
					 * Sets the value for the Grade object referenced by intPenaltyGrade 
					 * @param Grade $mixValue
					 * @return Grade
					 */
					if (is_null($mixValue)) {
						$this->intPenaltyGrade = null;
						$this->objPenaltyGradeObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Grade object
						try {
							$mixValue = QType::Cast($mixValue, 'Grade');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Grade object
						if (is_null($mixValue->Idgrade))
							throw new QCallerException('Unable to set an unsaved PenaltyGradeObject for this GradeCard');

						// Update Local Member Variables
						$this->objPenaltyGradeObject = $mixValue;
						$this->intPenaltyGrade = $mixValue->Idgrade;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ChangeInEseByObject':
					/**
					 * Sets the value for the Login object referenced by intChangeInEseBy 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intChangeInEseBy = null;
						$this->objChangeInEseByObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved ChangeInEseByObject for this GradeCard');

						// Update Local Member Variables
						$this->objChangeInEseByObject = $mixValue;
						$this->intChangeInEseBy = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'RefGradeImprovementObject':
					/**
					 * Sets the value for the ApplyGradeImproment object referenced by intRefGradeImprovement 
					 * @param ApplyGradeImproment $mixValue
					 * @return ApplyGradeImproment
					 */
					if (is_null($mixValue)) {
						$this->intRefGradeImprovement = null;
						$this->objRefGradeImprovementObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a ApplyGradeImproment object
						try {
							$mixValue = QType::Cast($mixValue, 'ApplyGradeImproment');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED ApplyGradeImproment object
						if (is_null($mixValue->IdapplyGradeImproment))
							throw new QCallerException('Unable to set an unsaved RefGradeImprovementObject for this GradeCard');

						// Update Local Member Variables
						$this->objRefGradeImprovementObject = $mixValue;
						$this->intRefGradeImprovement = $mixValue->IdapplyGradeImproment;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for ApplyGradeImpromentAsGradecard
		//-------------------------------------------------------------------

		/**
		 * Gets all associated ApplyGradeImpromentsAsGradecard as an array of ApplyGradeImproment objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ApplyGradeImproment[]
		*/
		public function GetApplyGradeImpromentAsGradecardArray($objOptionalClauses = null) {
			if ((is_null($this->intIdgradeCard)))
				return array();

			try {
				return ApplyGradeImproment::LoadArrayByGradecard($this->intIdgradeCard, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated ApplyGradeImpromentsAsGradecard
		 * @return int
		*/
		public function CountApplyGradeImpromentsAsGradecard() {
			if ((is_null($this->intIdgradeCard)))
				return 0;

			return ApplyGradeImproment::CountByGradecard($this->intIdgradeCard);
		}

		/**
		 * Associates a ApplyGradeImpromentAsGradecard
		 * @param ApplyGradeImproment $objApplyGradeImproment
		 * @return void
		*/
		public function AssociateApplyGradeImpromentAsGradecard(ApplyGradeImproment $objApplyGradeImproment) {
			if ((is_null($this->intIdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplyGradeImpromentAsGradecard on this unsaved GradeCard.');
			if ((is_null($objApplyGradeImproment->IdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateApplyGradeImpromentAsGradecard on this GradeCard with an unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = GradeCard::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`apply_grade_improment`
				SET
					`gradecard` = ' . $objDatabase->SqlVariable($this->intIdgradeCard) . '
				WHERE
					`idapply_grade_improment` = ' . $objDatabase->SqlVariable($objApplyGradeImproment->IdapplyGradeImproment) . '
			');
		}

		/**
		 * Unassociates a ApplyGradeImpromentAsGradecard
		 * @param ApplyGradeImproment $objApplyGradeImproment
		 * @return void
		*/
		public function UnassociateApplyGradeImpromentAsGradecard(ApplyGradeImproment $objApplyGradeImproment) {
			if ((is_null($this->intIdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsGradecard on this unsaved GradeCard.');
			if ((is_null($objApplyGradeImproment->IdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsGradecard on this GradeCard with an unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = GradeCard::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`apply_grade_improment`
				SET
					`gradecard` = null
				WHERE
					`idapply_grade_improment` = ' . $objDatabase->SqlVariable($objApplyGradeImproment->IdapplyGradeImproment) . ' AND
					`gradecard` = ' . $objDatabase->SqlVariable($this->intIdgradeCard) . '
			');
		}

		/**
		 * Unassociates all ApplyGradeImpromentsAsGradecard
		 * @return void
		*/
		public function UnassociateAllApplyGradeImpromentsAsGradecard() {
			if ((is_null($this->intIdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsGradecard on this unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = GradeCard::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`apply_grade_improment`
				SET
					`gradecard` = null
				WHERE
					`gradecard` = ' . $objDatabase->SqlVariable($this->intIdgradeCard) . '
			');
		}

		/**
		 * Deletes an associated ApplyGradeImpromentAsGradecard
		 * @param ApplyGradeImproment $objApplyGradeImproment
		 * @return void
		*/
		public function DeleteAssociatedApplyGradeImpromentAsGradecard(ApplyGradeImproment $objApplyGradeImproment) {
			if ((is_null($this->intIdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsGradecard on this unsaved GradeCard.');
			if ((is_null($objApplyGradeImproment->IdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsGradecard on this GradeCard with an unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = GradeCard::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`apply_grade_improment`
				WHERE
					`idapply_grade_improment` = ' . $objDatabase->SqlVariable($objApplyGradeImproment->IdapplyGradeImproment) . ' AND
					`gradecard` = ' . $objDatabase->SqlVariable($this->intIdgradeCard) . '
			');
		}

		/**
		 * Deletes all associated ApplyGradeImpromentsAsGradecard
		 * @return void
		*/
		public function DeleteAllApplyGradeImpromentsAsGradecard() {
			if ((is_null($this->intIdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateApplyGradeImpromentAsGradecard on this unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = GradeCard::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`apply_grade_improment`
				WHERE
					`gradecard` = ' . $objDatabase->SqlVariable($this->intIdgradeCard) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "grade_card";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[GradeCard::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="GradeCard"><sequence>';
			$strToReturn .= '<element name="IdgradeCard" type="xsd:int"/>';
			$strToReturn .= '<element name="StudentObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="StudeRoleObject" type="xsd1:Role"/>';
			$strToReturn .= '<element name="SubjectObject" type="xsd1:YearlySubject"/>';
			$strToReturn .= '<element name="Total" type="xsd:string"/>';
			$strToReturn .= '<element name="RelativeGradeObject" type="xsd1:Grade"/>';
			$strToReturn .= '<element name="AbsoluteGradeObject" type="xsd1:Grade"/>';
			$strToReturn .= '<element name="ByMakeup" type="xsd:boolean"/>';
			$strToReturn .= '<element name="PenaltyReason" type="xsd:string"/>';
			$strToReturn .= '<element name="PenaltyGradeObject" type="xsd1:Grade"/>';
			$strToReturn .= '<element name="GraceMarks" type="xsd:string"/>';
			$strToReturn .= '<element name="ChangeInEse" type="xsd:string"/>';
			$strToReturn .= '<element name="ChangeInEseByObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="GradeModifyLock" type="xsd:boolean"/>';
			$strToReturn .= '<element name="GradeCode" type="xsd:string"/>';
			$strToReturn .= '<element name="GradeImprovement" type="xsd:boolean"/>';
			$strToReturn .= '<element name="RefGradeImprovementObject" type="xsd1:ApplyGradeImproment"/>';
			$strToReturn .= '<element name="ChangeInEseLock" type="xsd:boolean"/>';
			$strToReturn .= '<element name="ReevaluationChangeOfMarks" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('GradeCard', $strComplexTypeArray)) {
				$strComplexTypeArray['GradeCard'] = GradeCard::GetSoapComplexTypeXml();
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				Role::AlterSoapComplexTypeArray($strComplexTypeArray);
				YearlySubject::AlterSoapComplexTypeArray($strComplexTypeArray);
				Grade::AlterSoapComplexTypeArray($strComplexTypeArray);
				Grade::AlterSoapComplexTypeArray($strComplexTypeArray);
				Grade::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				ApplyGradeImproment::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, GradeCard::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new GradeCard();
			if (property_exists($objSoapObject, 'IdgradeCard'))
				$objToReturn->intIdgradeCard = $objSoapObject->IdgradeCard;
			if ((property_exists($objSoapObject, 'StudentObject')) &&
				($objSoapObject->StudentObject))
				$objToReturn->StudentObject = Login::GetObjectFromSoapObject($objSoapObject->StudentObject);
			if ((property_exists($objSoapObject, 'StudeRoleObject')) &&
				($objSoapObject->StudeRoleObject))
				$objToReturn->StudeRoleObject = Role::GetObjectFromSoapObject($objSoapObject->StudeRoleObject);
			if ((property_exists($objSoapObject, 'SubjectObject')) &&
				($objSoapObject->SubjectObject))
				$objToReturn->SubjectObject = YearlySubject::GetObjectFromSoapObject($objSoapObject->SubjectObject);
			if (property_exists($objSoapObject, 'Total'))
				$objToReturn->strTotal = $objSoapObject->Total;
			if ((property_exists($objSoapObject, 'RelativeGradeObject')) &&
				($objSoapObject->RelativeGradeObject))
				$objToReturn->RelativeGradeObject = Grade::GetObjectFromSoapObject($objSoapObject->RelativeGradeObject);
			if ((property_exists($objSoapObject, 'AbsoluteGradeObject')) &&
				($objSoapObject->AbsoluteGradeObject))
				$objToReturn->AbsoluteGradeObject = Grade::GetObjectFromSoapObject($objSoapObject->AbsoluteGradeObject);
			if (property_exists($objSoapObject, 'ByMakeup'))
				$objToReturn->blnByMakeup = $objSoapObject->ByMakeup;
			if (property_exists($objSoapObject, 'PenaltyReason'))
				$objToReturn->strPenaltyReason = $objSoapObject->PenaltyReason;
			if ((property_exists($objSoapObject, 'PenaltyGradeObject')) &&
				($objSoapObject->PenaltyGradeObject))
				$objToReturn->PenaltyGradeObject = Grade::GetObjectFromSoapObject($objSoapObject->PenaltyGradeObject);
			if (property_exists($objSoapObject, 'GraceMarks'))
				$objToReturn->strGraceMarks = $objSoapObject->GraceMarks;
			if (property_exists($objSoapObject, 'ChangeInEse'))
				$objToReturn->strChangeInEse = $objSoapObject->ChangeInEse;
			if ((property_exists($objSoapObject, 'ChangeInEseByObject')) &&
				($objSoapObject->ChangeInEseByObject))
				$objToReturn->ChangeInEseByObject = Login::GetObjectFromSoapObject($objSoapObject->ChangeInEseByObject);
			if (property_exists($objSoapObject, 'GradeModifyLock'))
				$objToReturn->blnGradeModifyLock = $objSoapObject->GradeModifyLock;
			if (property_exists($objSoapObject, 'GradeCode'))
				$objToReturn->strGradeCode = $objSoapObject->GradeCode;
			if (property_exists($objSoapObject, 'GradeImprovement'))
				$objToReturn->blnGradeImprovement = $objSoapObject->GradeImprovement;
			if ((property_exists($objSoapObject, 'RefGradeImprovementObject')) &&
				($objSoapObject->RefGradeImprovementObject))
				$objToReturn->RefGradeImprovementObject = ApplyGradeImproment::GetObjectFromSoapObject($objSoapObject->RefGradeImprovementObject);
			if (property_exists($objSoapObject, 'ChangeInEseLock'))
				$objToReturn->blnChangeInEseLock = $objSoapObject->ChangeInEseLock;
			if (property_exists($objSoapObject, 'ReevaluationChangeOfMarks'))
				$objToReturn->strReevaluationChangeOfMarks = $objSoapObject->ReevaluationChangeOfMarks;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, GradeCard::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objStudentObject)
				$objObject->objStudentObject = Login::GetSoapObjectFromObject($objObject->objStudentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intStudent = null;
			if ($objObject->objStudeRoleObject)
				$objObject->objStudeRoleObject = Role::GetSoapObjectFromObject($objObject->objStudeRoleObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intStudeRole = null;
			if ($objObject->objSubjectObject)
				$objObject->objSubjectObject = YearlySubject::GetSoapObjectFromObject($objObject->objSubjectObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSubject = null;
			if ($objObject->objRelativeGradeObject)
				$objObject->objRelativeGradeObject = Grade::GetSoapObjectFromObject($objObject->objRelativeGradeObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intRelativeGrade = null;
			if ($objObject->objAbsoluteGradeObject)
				$objObject->objAbsoluteGradeObject = Grade::GetSoapObjectFromObject($objObject->objAbsoluteGradeObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intAbsoluteGrade = null;
			if ($objObject->objPenaltyGradeObject)
				$objObject->objPenaltyGradeObject = Grade::GetSoapObjectFromObject($objObject->objPenaltyGradeObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intPenaltyGrade = null;
			if ($objObject->objChangeInEseByObject)
				$objObject->objChangeInEseByObject = Login::GetSoapObjectFromObject($objObject->objChangeInEseByObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intChangeInEseBy = null;
			if ($objObject->objRefGradeImprovementObject)
				$objObject->objRefGradeImprovementObject = ApplyGradeImproment::GetSoapObjectFromObject($objObject->objRefGradeImprovementObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intRefGradeImprovement = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdgradeCard'] = $this->intIdgradeCard;
			$iArray['Student'] = $this->intStudent;
			$iArray['StudeRole'] = $this->intStudeRole;
			$iArray['Subject'] = $this->intSubject;
			$iArray['Total'] = $this->strTotal;
			$iArray['RelativeGrade'] = $this->intRelativeGrade;
			$iArray['AbsoluteGrade'] = $this->intAbsoluteGrade;
			$iArray['ByMakeup'] = $this->blnByMakeup;
			$iArray['PenaltyReason'] = $this->strPenaltyReason;
			$iArray['PenaltyGrade'] = $this->intPenaltyGrade;
			$iArray['GraceMarks'] = $this->strGraceMarks;
			$iArray['ChangeInEse'] = $this->strChangeInEse;
			$iArray['ChangeInEseBy'] = $this->intChangeInEseBy;
			$iArray['GradeModifyLock'] = $this->blnGradeModifyLock;
			$iArray['GradeCode'] = $this->strGradeCode;
			$iArray['GradeImprovement'] = $this->blnGradeImprovement;
			$iArray['RefGradeImprovement'] = $this->intRefGradeImprovement;
			$iArray['ChangeInEseLock'] = $this->blnChangeInEseLock;
			$iArray['ReevaluationChangeOfMarks'] = $this->strReevaluationChangeOfMarks;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdgradeCard ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdgradeCard
     * @property-read QQNode $Student
     * @property-read QQNodeLogin $StudentObject
     * @property-read QQNode $StudeRole
     * @property-read QQNodeRole $StudeRoleObject
     * @property-read QQNode $Subject
     * @property-read QQNodeYearlySubject $SubjectObject
     * @property-read QQNode $Total
     * @property-read QQNode $RelativeGrade
     * @property-read QQNodeGrade $RelativeGradeObject
     * @property-read QQNode $AbsoluteGrade
     * @property-read QQNodeGrade $AbsoluteGradeObject
     * @property-read QQNode $ByMakeup
     * @property-read QQNode $PenaltyReason
     * @property-read QQNode $PenaltyGrade
     * @property-read QQNodeGrade $PenaltyGradeObject
     * @property-read QQNode $GraceMarks
     * @property-read QQNode $ChangeInEse
     * @property-read QQNode $ChangeInEseBy
     * @property-read QQNodeLogin $ChangeInEseByObject
     * @property-read QQNode $GradeModifyLock
     * @property-read QQNode $GradeCode
     * @property-read QQNode $GradeImprovement
     * @property-read QQNode $RefGradeImprovement
     * @property-read QQNodeApplyGradeImproment $RefGradeImprovementObject
     * @property-read QQNode $ChangeInEseLock
     * @property-read QQNode $ReevaluationChangeOfMarks
     *
     *
     * @property-read QQReverseReferenceNodeApplyGradeImproment $ApplyGradeImpromentAsGradecard

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeGradeCard extends QQNode {
		protected $strTableName = 'grade_card';
		protected $strPrimaryKey = 'idgrade_card';
		protected $strClassName = 'GradeCard';
		public function __get($strName) {
			switch ($strName) {
				case 'IdgradeCard':
					return new QQNode('idgrade_card', 'IdgradeCard', 'Integer', $this);
				case 'Student':
					return new QQNode('student', 'Student', 'Integer', $this);
				case 'StudentObject':
					return new QQNodeLogin('student', 'StudentObject', 'Integer', $this);
				case 'StudeRole':
					return new QQNode('stude_role', 'StudeRole', 'Integer', $this);
				case 'StudeRoleObject':
					return new QQNodeRole('stude_role', 'StudeRoleObject', 'Integer', $this);
				case 'Subject':
					return new QQNode('subject', 'Subject', 'Integer', $this);
				case 'SubjectObject':
					return new QQNodeYearlySubject('subject', 'SubjectObject', 'Integer', $this);
				case 'Total':
					return new QQNode('total', 'Total', 'VarChar', $this);
				case 'RelativeGrade':
					return new QQNode('relative_grade', 'RelativeGrade', 'Integer', $this);
				case 'RelativeGradeObject':
					return new QQNodeGrade('relative_grade', 'RelativeGradeObject', 'Integer', $this);
				case 'AbsoluteGrade':
					return new QQNode('absolute_grade', 'AbsoluteGrade', 'Integer', $this);
				case 'AbsoluteGradeObject':
					return new QQNodeGrade('absolute_grade', 'AbsoluteGradeObject', 'Integer', $this);
				case 'ByMakeup':
					return new QQNode('by_makeup', 'ByMakeup', 'Bit', $this);
				case 'PenaltyReason':
					return new QQNode('penalty_reason', 'PenaltyReason', 'Blob', $this);
				case 'PenaltyGrade':
					return new QQNode('penalty_grade', 'PenaltyGrade', 'Integer', $this);
				case 'PenaltyGradeObject':
					return new QQNodeGrade('penalty_grade', 'PenaltyGradeObject', 'Integer', $this);
				case 'GraceMarks':
					return new QQNode('grace_marks', 'GraceMarks', 'VarChar', $this);
				case 'ChangeInEse':
					return new QQNode('change_in_ese', 'ChangeInEse', 'VarChar', $this);
				case 'ChangeInEseBy':
					return new QQNode('change_in_ese_by', 'ChangeInEseBy', 'Integer', $this);
				case 'ChangeInEseByObject':
					return new QQNodeLogin('change_in_ese_by', 'ChangeInEseByObject', 'Integer', $this);
				case 'GradeModifyLock':
					return new QQNode('grade_modify_lock', 'GradeModifyLock', 'Bit', $this);
				case 'GradeCode':
					return new QQNode('grade_code', 'GradeCode', 'VarChar', $this);
				case 'GradeImprovement':
					return new QQNode('grade_improvement', 'GradeImprovement', 'Bit', $this);
				case 'RefGradeImprovement':
					return new QQNode('ref_grade_improvement', 'RefGradeImprovement', 'Integer', $this);
				case 'RefGradeImprovementObject':
					return new QQNodeApplyGradeImproment('ref_grade_improvement', 'RefGradeImprovementObject', 'Integer', $this);
				case 'ChangeInEseLock':
					return new QQNode('change_in_ese_lock', 'ChangeInEseLock', 'Bit', $this);
				case 'ReevaluationChangeOfMarks':
					return new QQNode('reevaluation_change_of_marks', 'ReevaluationChangeOfMarks', 'VarChar', $this);
				case 'ApplyGradeImpromentAsGradecard':
					return new QQReverseReferenceNodeApplyGradeImproment($this, 'applygradeimpromentasgradecard', 'reverse_reference', 'gradecard');

				case '_PrimaryKeyNode':
					return new QQNode('idgrade_card', 'IdgradeCard', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdgradeCard
     * @property-read QQNode $Student
     * @property-read QQNodeLogin $StudentObject
     * @property-read QQNode $StudeRole
     * @property-read QQNodeRole $StudeRoleObject
     * @property-read QQNode $Subject
     * @property-read QQNodeYearlySubject $SubjectObject
     * @property-read QQNode $Total
     * @property-read QQNode $RelativeGrade
     * @property-read QQNodeGrade $RelativeGradeObject
     * @property-read QQNode $AbsoluteGrade
     * @property-read QQNodeGrade $AbsoluteGradeObject
     * @property-read QQNode $ByMakeup
     * @property-read QQNode $PenaltyReason
     * @property-read QQNode $PenaltyGrade
     * @property-read QQNodeGrade $PenaltyGradeObject
     * @property-read QQNode $GraceMarks
     * @property-read QQNode $ChangeInEse
     * @property-read QQNode $ChangeInEseBy
     * @property-read QQNodeLogin $ChangeInEseByObject
     * @property-read QQNode $GradeModifyLock
     * @property-read QQNode $GradeCode
     * @property-read QQNode $GradeImprovement
     * @property-read QQNode $RefGradeImprovement
     * @property-read QQNodeApplyGradeImproment $RefGradeImprovementObject
     * @property-read QQNode $ChangeInEseLock
     * @property-read QQNode $ReevaluationChangeOfMarks
     *
     *
     * @property-read QQReverseReferenceNodeApplyGradeImproment $ApplyGradeImpromentAsGradecard

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeGradeCard extends QQReverseReferenceNode {
		protected $strTableName = 'grade_card';
		protected $strPrimaryKey = 'idgrade_card';
		protected $strClassName = 'GradeCard';
		public function __get($strName) {
			switch ($strName) {
				case 'IdgradeCard':
					return new QQNode('idgrade_card', 'IdgradeCard', 'integer', $this);
				case 'Student':
					return new QQNode('student', 'Student', 'integer', $this);
				case 'StudentObject':
					return new QQNodeLogin('student', 'StudentObject', 'integer', $this);
				case 'StudeRole':
					return new QQNode('stude_role', 'StudeRole', 'integer', $this);
				case 'StudeRoleObject':
					return new QQNodeRole('stude_role', 'StudeRoleObject', 'integer', $this);
				case 'Subject':
					return new QQNode('subject', 'Subject', 'integer', $this);
				case 'SubjectObject':
					return new QQNodeYearlySubject('subject', 'SubjectObject', 'integer', $this);
				case 'Total':
					return new QQNode('total', 'Total', 'string', $this);
				case 'RelativeGrade':
					return new QQNode('relative_grade', 'RelativeGrade', 'integer', $this);
				case 'RelativeGradeObject':
					return new QQNodeGrade('relative_grade', 'RelativeGradeObject', 'integer', $this);
				case 'AbsoluteGrade':
					return new QQNode('absolute_grade', 'AbsoluteGrade', 'integer', $this);
				case 'AbsoluteGradeObject':
					return new QQNodeGrade('absolute_grade', 'AbsoluteGradeObject', 'integer', $this);
				case 'ByMakeup':
					return new QQNode('by_makeup', 'ByMakeup', 'boolean', $this);
				case 'PenaltyReason':
					return new QQNode('penalty_reason', 'PenaltyReason', 'string', $this);
				case 'PenaltyGrade':
					return new QQNode('penalty_grade', 'PenaltyGrade', 'integer', $this);
				case 'PenaltyGradeObject':
					return new QQNodeGrade('penalty_grade', 'PenaltyGradeObject', 'integer', $this);
				case 'GraceMarks':
					return new QQNode('grace_marks', 'GraceMarks', 'string', $this);
				case 'ChangeInEse':
					return new QQNode('change_in_ese', 'ChangeInEse', 'string', $this);
				case 'ChangeInEseBy':
					return new QQNode('change_in_ese_by', 'ChangeInEseBy', 'integer', $this);
				case 'ChangeInEseByObject':
					return new QQNodeLogin('change_in_ese_by', 'ChangeInEseByObject', 'integer', $this);
				case 'GradeModifyLock':
					return new QQNode('grade_modify_lock', 'GradeModifyLock', 'boolean', $this);
				case 'GradeCode':
					return new QQNode('grade_code', 'GradeCode', 'string', $this);
				case 'GradeImprovement':
					return new QQNode('grade_improvement', 'GradeImprovement', 'boolean', $this);
				case 'RefGradeImprovement':
					return new QQNode('ref_grade_improvement', 'RefGradeImprovement', 'integer', $this);
				case 'RefGradeImprovementObject':
					return new QQNodeApplyGradeImproment('ref_grade_improvement', 'RefGradeImprovementObject', 'integer', $this);
				case 'ChangeInEseLock':
					return new QQNode('change_in_ese_lock', 'ChangeInEseLock', 'boolean', $this);
				case 'ReevaluationChangeOfMarks':
					return new QQNode('reevaluation_change_of_marks', 'ReevaluationChangeOfMarks', 'string', $this);
				case 'ApplyGradeImpromentAsGradecard':
					return new QQReverseReferenceNodeApplyGradeImproment($this, 'applygradeimpromentasgradecard', 'reverse_reference', 'gradecard');

				case '_PrimaryKeyNode':
					return new QQNode('idgrade_card', 'IdgradeCard', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
