<?php
	/**
	 * The abstract LeaveCatGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the LeaveCat subclass which
	 * extends this LeaveCatGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the LeaveCat class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdleaveCat the value for intIdleaveCat (Read-Only PK)
	 * @property string $Name the value for strName (Not Null)
	 * @property string $Description the value for strDescription 
	 * @property boolean $Calculation the value for blnCalculation 
	 * @property-read CertificateTemplet $_CertificateTemplet the value for the private _objCertificateTemplet (Read-Only) if set due to an expansion on the certificate_templet.leave_cat reverse relationship
	 * @property-read CertificateTemplet[] $_CertificateTempletArray the value for the private _objCertificateTempletArray (Read-Only) if set due to an ExpandAsArray on the certificate_templet.leave_cat reverse relationship
	 * @property-read LeaveBalance $_LeaveBalance the value for the private _objLeaveBalance (Read-Only) if set due to an expansion on the leave_balance.leave_cat reverse relationship
	 * @property-read LeaveBalance[] $_LeaveBalanceArray the value for the private _objLeaveBalanceArray (Read-Only) if set due to an ExpandAsArray on the leave_balance.leave_cat reverse relationship
	 * @property-read LeaveTemplet $_LeaveTemplet the value for the private _objLeaveTemplet (Read-Only) if set due to an expansion on the leave_templet.leave_cat reverse relationship
	 * @property-read LeaveTemplet[] $_LeaveTempletArray the value for the private _objLeaveTempletArray (Read-Only) if set due to an ExpandAsArray on the leave_templet.leave_cat reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class LeaveCatGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column leave_cat.idleave_cat
		 * @var integer intIdleaveCat
		 */
		protected $intIdleaveCat;
		const IdleaveCatDefault = null;


		/**
		 * Protected member variable that maps to the database column leave_cat.name
		 * @var string strName
		 */
		protected $strName;
		const NameMaxLength = 255;
		const NameDefault = null;


		/**
		 * Protected member variable that maps to the database column leave_cat.description
		 * @var string strDescription
		 */
		protected $strDescription;
		const DescriptionDefault = null;


		/**
		 * Protected member variable that maps to the database column leave_cat.calculation
		 * @var boolean blnCalculation
		 */
		protected $blnCalculation;
		const CalculationDefault = null;


		/**
		 * Private member variable that stores a reference to a single CertificateTemplet object
		 * (of type CertificateTemplet), if this LeaveCat object was restored with
		 * an expansion on the certificate_templet association table.
		 * @var CertificateTemplet _objCertificateTemplet;
		 */
		private $_objCertificateTemplet;

		/**
		 * Private member variable that stores a reference to an array of CertificateTemplet objects
		 * (of type CertificateTemplet[]), if this LeaveCat object was restored with
		 * an ExpandAsArray on the certificate_templet association table.
		 * @var CertificateTemplet[] _objCertificateTempletArray;
		 */
		private $_objCertificateTempletArray = null;

		/**
		 * Private member variable that stores a reference to a single LeaveBalance object
		 * (of type LeaveBalance), if this LeaveCat object was restored with
		 * an expansion on the leave_balance association table.
		 * @var LeaveBalance _objLeaveBalance;
		 */
		private $_objLeaveBalance;

		/**
		 * Private member variable that stores a reference to an array of LeaveBalance objects
		 * (of type LeaveBalance[]), if this LeaveCat object was restored with
		 * an ExpandAsArray on the leave_balance association table.
		 * @var LeaveBalance[] _objLeaveBalanceArray;
		 */
		private $_objLeaveBalanceArray = null;

		/**
		 * Private member variable that stores a reference to a single LeaveTemplet object
		 * (of type LeaveTemplet), if this LeaveCat object was restored with
		 * an expansion on the leave_templet association table.
		 * @var LeaveTemplet _objLeaveTemplet;
		 */
		private $_objLeaveTemplet;

		/**
		 * Private member variable that stores a reference to an array of LeaveTemplet objects
		 * (of type LeaveTemplet[]), if this LeaveCat object was restored with
		 * an ExpandAsArray on the leave_templet association table.
		 * @var LeaveTemplet[] _objLeaveTempletArray;
		 */
		private $_objLeaveTempletArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdleaveCat = LeaveCat::IdleaveCatDefault;
			$this->strName = LeaveCat::NameDefault;
			$this->strDescription = LeaveCat::DescriptionDefault;
			$this->blnCalculation = LeaveCat::CalculationDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a LeaveCat from PK Info
		 * @param integer $intIdleaveCat
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveCat
		 */
		public static function Load($intIdleaveCat, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'LeaveCat', $intIdleaveCat);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = LeaveCat::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::LeaveCat()->IdleaveCat, $intIdleaveCat)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all LeaveCats
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveCat[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call LeaveCat::QueryArray to perform the LoadAll query
			try {
				return LeaveCat::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all LeaveCats
		 * @return int
		 */
		public static function CountAll() {
			// Call LeaveCat::QueryCount to perform the CountAll query
			return LeaveCat::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Create/Build out the QueryBuilder object with LeaveCat-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'leave_cat');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				LeaveCat::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('leave_cat');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single LeaveCat object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return LeaveCat the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = LeaveCat::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new LeaveCat object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = LeaveCat::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return LeaveCat::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of LeaveCat objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return LeaveCat[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = LeaveCat::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return LeaveCat::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = LeaveCat::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of LeaveCat objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = LeaveCat::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			$strQuery = LeaveCat::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/leavecat', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = LeaveCat::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this LeaveCat
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'leave_cat';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idleave_cat', $strAliasPrefix . 'idleave_cat');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idleave_cat', $strAliasPrefix . 'idleave_cat');
			    $objBuilder->AddSelectItem($strTableName, 'name', $strAliasPrefix . 'name');
			    $objBuilder->AddSelectItem($strTableName, 'description', $strAliasPrefix . 'description');
			    $objBuilder->AddSelectItem($strTableName, 'calculation', $strAliasPrefix . 'calculation');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a LeaveCat from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this LeaveCat::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return LeaveCat
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idleave_cat';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdleaveCat == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'leave_cat__';


						// Expanding reverse references: CertificateTemplet
						$strAlias = $strAliasPrefix . 'certificatetemplet__idcertificate_templet';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objCertificateTempletArray)
								$objPreviousItem->_objCertificateTempletArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objCertificateTempletArray)) {
								$objPreviousChildItems = $objPreviousItem->_objCertificateTempletArray;
								$objChildItem = CertificateTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'certificatetemplet__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objCertificateTempletArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objCertificateTempletArray[] = CertificateTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'certificatetemplet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: LeaveBalance
						$strAlias = $strAliasPrefix . 'leavebalance__idleave_balance';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objLeaveBalanceArray)
								$objPreviousItem->_objLeaveBalanceArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objLeaveBalanceArray)) {
								$objPreviousChildItems = $objPreviousItem->_objLeaveBalanceArray;
								$objChildItem = LeaveBalance::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavebalance__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objLeaveBalanceArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objLeaveBalanceArray[] = LeaveBalance::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavebalance__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: LeaveTemplet
						$strAlias = $strAliasPrefix . 'leavetemplet__idleave_templet';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objLeaveTempletArray)
								$objPreviousItem->_objLeaveTempletArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objLeaveTempletArray)) {
								$objPreviousChildItems = $objPreviousItem->_objLeaveTempletArray;
								$objChildItem = LeaveTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavetemplet__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objLeaveTempletArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objLeaveTempletArray[] = LeaveTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavetemplet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'leave_cat__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the LeaveCat object
			$objToReturn = new LeaveCat();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idleave_cat';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdleaveCat = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'name';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strName = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'description';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strDescription = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'calculation';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnCalculation = $objDbRow->GetColumn($strAliasName, 'Bit');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdleaveCat != $objPreviousItem->IdleaveCat) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objCertificateTempletArray);
					$cnt = count($objToReturn->_objCertificateTempletArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objCertificateTempletArray, $objToReturn->_objCertificateTempletArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objLeaveBalanceArray);
					$cnt = count($objToReturn->_objLeaveBalanceArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objLeaveBalanceArray, $objToReturn->_objLeaveBalanceArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objLeaveTempletArray);
					$cnt = count($objToReturn->_objLeaveTempletArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objLeaveTempletArray, $objToReturn->_objLeaveTempletArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'leave_cat__';




			// Check for CertificateTemplet Virtual Binding
			$strAlias = $strAliasPrefix . 'certificatetemplet__idcertificate_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objCertificateTempletArray)
				$objToReturn->_objCertificateTempletArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objCertificateTempletArray[] = CertificateTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'certificatetemplet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objCertificateTemplet = CertificateTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'certificatetemplet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for LeaveBalance Virtual Binding
			$strAlias = $strAliasPrefix . 'leavebalance__idleave_balance';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objLeaveBalanceArray)
				$objToReturn->_objLeaveBalanceArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objLeaveBalanceArray[] = LeaveBalance::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavebalance__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objLeaveBalance = LeaveBalance::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavebalance__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for LeaveTemplet Virtual Binding
			$strAlias = $strAliasPrefix . 'leavetemplet__idleave_templet';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objLeaveTempletArray)
				$objToReturn->_objLeaveTempletArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objLeaveTempletArray[] = LeaveTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavetemplet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objLeaveTemplet = LeaveTemplet::InstantiateDbRow($objDbRow, $strAliasPrefix . 'leavetemplet__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of LeaveCats from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return LeaveCat[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = LeaveCat::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = LeaveCat::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single LeaveCat object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return LeaveCat next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return LeaveCat::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single LeaveCat object,
		 * by IdleaveCat Index(es)
		 * @param integer $intIdleaveCat
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveCat
		*/
		public static function LoadByIdleaveCat($intIdleaveCat, $objOptionalClauses = null) {
			return LeaveCat::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::LeaveCat()->IdleaveCat, $intIdleaveCat)
				),
				$objOptionalClauses
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this LeaveCat
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `leave_cat` (
							`name`,
							`description`,
							`calculation`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strName) . ',
							' . $objDatabase->SqlVariable($this->strDescription) . ',
							' . $objDatabase->SqlVariable($this->blnCalculation) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdleaveCat = $objDatabase->InsertId('leave_cat', 'idleave_cat');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`leave_cat`
						SET
							`name` = ' . $objDatabase->SqlVariable($this->strName) . ',
							`description` = ' . $objDatabase->SqlVariable($this->strDescription) . ',
							`calculation` = ' . $objDatabase->SqlVariable($this->blnCalculation) . '
						WHERE
							`idleave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this LeaveCat
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this LeaveCat with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leave_cat`
				WHERE
					`idleave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this LeaveCat ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'LeaveCat', $this->intIdleaveCat);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all LeaveCats
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leave_cat`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate leave_cat table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `leave_cat`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this LeaveCat from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved LeaveCat object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = LeaveCat::Load($this->intIdleaveCat);

			// Update $this's local variables to match
			$this->strName = $objReloaded->strName;
			$this->strDescription = $objReloaded->strDescription;
			$this->blnCalculation = $objReloaded->blnCalculation;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdleaveCat':
					/**
					 * Gets the value for intIdleaveCat (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdleaveCat;

				case 'Name':
					/**
					 * Gets the value for strName (Not Null)
					 * @return string
					 */
					return $this->strName;

				case 'Description':
					/**
					 * Gets the value for strDescription 
					 * @return string
					 */
					return $this->strDescription;

				case 'Calculation':
					/**
					 * Gets the value for blnCalculation 
					 * @return boolean
					 */
					return $this->blnCalculation;


				///////////////////
				// Member Objects
				///////////////////

				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_CertificateTemplet':
					/**
					 * Gets the value for the private _objCertificateTemplet (Read-Only)
					 * if set due to an expansion on the certificate_templet.leave_cat reverse relationship
					 * @return CertificateTemplet
					 */
					return $this->_objCertificateTemplet;

				case '_CertificateTempletArray':
					/**
					 * Gets the value for the private _objCertificateTempletArray (Read-Only)
					 * if set due to an ExpandAsArray on the certificate_templet.leave_cat reverse relationship
					 * @return CertificateTemplet[]
					 */
					return $this->_objCertificateTempletArray;

				case '_LeaveBalance':
					/**
					 * Gets the value for the private _objLeaveBalance (Read-Only)
					 * if set due to an expansion on the leave_balance.leave_cat reverse relationship
					 * @return LeaveBalance
					 */
					return $this->_objLeaveBalance;

				case '_LeaveBalanceArray':
					/**
					 * Gets the value for the private _objLeaveBalanceArray (Read-Only)
					 * if set due to an ExpandAsArray on the leave_balance.leave_cat reverse relationship
					 * @return LeaveBalance[]
					 */
					return $this->_objLeaveBalanceArray;

				case '_LeaveTemplet':
					/**
					 * Gets the value for the private _objLeaveTemplet (Read-Only)
					 * if set due to an expansion on the leave_templet.leave_cat reverse relationship
					 * @return LeaveTemplet
					 */
					return $this->_objLeaveTemplet;

				case '_LeaveTempletArray':
					/**
					 * Gets the value for the private _objLeaveTempletArray (Read-Only)
					 * if set due to an ExpandAsArray on the leave_templet.leave_cat reverse relationship
					 * @return LeaveTemplet[]
					 */
					return $this->_objLeaveTempletArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Name':
					/**
					 * Sets the value for strName (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strName = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Description':
					/**
					 * Sets the value for strDescription 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strDescription = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Calculation':
					/**
					 * Sets the value for blnCalculation 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnCalculation = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for CertificateTemplet
		//-------------------------------------------------------------------

		/**
		 * Gets all associated CertificateTemplets as an array of CertificateTemplet objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return CertificateTemplet[]
		*/
		public function GetCertificateTempletArray($objOptionalClauses = null) {
			if ((is_null($this->intIdleaveCat)))
				return array();

			try {
				return CertificateTemplet::LoadArrayByLeaveCat($this->intIdleaveCat, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated CertificateTemplets
		 * @return int
		*/
		public function CountCertificateTemplets() {
			if ((is_null($this->intIdleaveCat)))
				return 0;

			return CertificateTemplet::CountByLeaveCat($this->intIdleaveCat);
		}

		/**
		 * Associates a CertificateTemplet
		 * @param CertificateTemplet $objCertificateTemplet
		 * @return void
		*/
		public function AssociateCertificateTemplet(CertificateTemplet $objCertificateTemplet) {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCertificateTemplet on this unsaved LeaveCat.');
			if ((is_null($objCertificateTemplet->IdcertificateTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateCertificateTemplet on this LeaveCat with an unsaved CertificateTemplet.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`certificate_templet`
				SET
					`leave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
				WHERE
					`idcertificate_templet` = ' . $objDatabase->SqlVariable($objCertificateTemplet->IdcertificateTemplet) . '
			');
		}

		/**
		 * Unassociates a CertificateTemplet
		 * @param CertificateTemplet $objCertificateTemplet
		 * @return void
		*/
		public function UnassociateCertificateTemplet(CertificateTemplet $objCertificateTemplet) {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateTemplet on this unsaved LeaveCat.');
			if ((is_null($objCertificateTemplet->IdcertificateTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateTemplet on this LeaveCat with an unsaved CertificateTemplet.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`certificate_templet`
				SET
					`leave_cat` = null
				WHERE
					`idcertificate_templet` = ' . $objDatabase->SqlVariable($objCertificateTemplet->IdcertificateTemplet) . ' AND
					`leave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
			');
		}

		/**
		 * Unassociates all CertificateTemplets
		 * @return void
		*/
		public function UnassociateAllCertificateTemplets() {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateTemplet on this unsaved LeaveCat.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`certificate_templet`
				SET
					`leave_cat` = null
				WHERE
					`leave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
			');
		}

		/**
		 * Deletes an associated CertificateTemplet
		 * @param CertificateTemplet $objCertificateTemplet
		 * @return void
		*/
		public function DeleteAssociatedCertificateTemplet(CertificateTemplet $objCertificateTemplet) {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateTemplet on this unsaved LeaveCat.');
			if ((is_null($objCertificateTemplet->IdcertificateTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateTemplet on this LeaveCat with an unsaved CertificateTemplet.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`certificate_templet`
				WHERE
					`idcertificate_templet` = ' . $objDatabase->SqlVariable($objCertificateTemplet->IdcertificateTemplet) . ' AND
					`leave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
			');
		}

		/**
		 * Deletes all associated CertificateTemplets
		 * @return void
		*/
		public function DeleteAllCertificateTemplets() {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateCertificateTemplet on this unsaved LeaveCat.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`certificate_templet`
				WHERE
					`leave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
			');
		}


		// Related Objects' Methods for LeaveBalance
		//-------------------------------------------------------------------

		/**
		 * Gets all associated LeaveBalances as an array of LeaveBalance objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveBalance[]
		*/
		public function GetLeaveBalanceArray($objOptionalClauses = null) {
			if ((is_null($this->intIdleaveCat)))
				return array();

			try {
				return LeaveBalance::LoadArrayByLeaveCat($this->intIdleaveCat, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated LeaveBalances
		 * @return int
		*/
		public function CountLeaveBalances() {
			if ((is_null($this->intIdleaveCat)))
				return 0;

			return LeaveBalance::CountByLeaveCat($this->intIdleaveCat);
		}

		/**
		 * Associates a LeaveBalance
		 * @param LeaveBalance $objLeaveBalance
		 * @return void
		*/
		public function AssociateLeaveBalance(LeaveBalance $objLeaveBalance) {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLeaveBalance on this unsaved LeaveCat.');
			if ((is_null($objLeaveBalance->IdleaveBalance)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLeaveBalance on this LeaveCat with an unsaved LeaveBalance.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`leave_balance`
				SET
					`leave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
				WHERE
					`idleave_balance` = ' . $objDatabase->SqlVariable($objLeaveBalance->IdleaveBalance) . '
			');
		}

		/**
		 * Unassociates a LeaveBalance
		 * @param LeaveBalance $objLeaveBalance
		 * @return void
		*/
		public function UnassociateLeaveBalance(LeaveBalance $objLeaveBalance) {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveBalance on this unsaved LeaveCat.');
			if ((is_null($objLeaveBalance->IdleaveBalance)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveBalance on this LeaveCat with an unsaved LeaveBalance.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`leave_balance`
				SET
					`leave_cat` = null
				WHERE
					`idleave_balance` = ' . $objDatabase->SqlVariable($objLeaveBalance->IdleaveBalance) . ' AND
					`leave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
			');
		}

		/**
		 * Unassociates all LeaveBalances
		 * @return void
		*/
		public function UnassociateAllLeaveBalances() {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveBalance on this unsaved LeaveCat.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`leave_balance`
				SET
					`leave_cat` = null
				WHERE
					`leave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
			');
		}

		/**
		 * Deletes an associated LeaveBalance
		 * @param LeaveBalance $objLeaveBalance
		 * @return void
		*/
		public function DeleteAssociatedLeaveBalance(LeaveBalance $objLeaveBalance) {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveBalance on this unsaved LeaveCat.');
			if ((is_null($objLeaveBalance->IdleaveBalance)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveBalance on this LeaveCat with an unsaved LeaveBalance.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leave_balance`
				WHERE
					`idleave_balance` = ' . $objDatabase->SqlVariable($objLeaveBalance->IdleaveBalance) . ' AND
					`leave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
			');
		}

		/**
		 * Deletes all associated LeaveBalances
		 * @return void
		*/
		public function DeleteAllLeaveBalances() {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveBalance on this unsaved LeaveCat.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leave_balance`
				WHERE
					`leave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
			');
		}


		// Related Objects' Methods for LeaveTemplet
		//-------------------------------------------------------------------

		/**
		 * Gets all associated LeaveTemplets as an array of LeaveTemplet objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return LeaveTemplet[]
		*/
		public function GetLeaveTempletArray($objOptionalClauses = null) {
			if ((is_null($this->intIdleaveCat)))
				return array();

			try {
				return LeaveTemplet::LoadArrayByLeaveCat($this->intIdleaveCat, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated LeaveTemplets
		 * @return int
		*/
		public function CountLeaveTemplets() {
			if ((is_null($this->intIdleaveCat)))
				return 0;

			return LeaveTemplet::CountByLeaveCat($this->intIdleaveCat);
		}

		/**
		 * Associates a LeaveTemplet
		 * @param LeaveTemplet $objLeaveTemplet
		 * @return void
		*/
		public function AssociateLeaveTemplet(LeaveTemplet $objLeaveTemplet) {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLeaveTemplet on this unsaved LeaveCat.');
			if ((is_null($objLeaveTemplet->IdleaveTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateLeaveTemplet on this LeaveCat with an unsaved LeaveTemplet.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`leave_templet`
				SET
					`leave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
				WHERE
					`idleave_templet` = ' . $objDatabase->SqlVariable($objLeaveTemplet->IdleaveTemplet) . '
			');
		}

		/**
		 * Unassociates a LeaveTemplet
		 * @param LeaveTemplet $objLeaveTemplet
		 * @return void
		*/
		public function UnassociateLeaveTemplet(LeaveTemplet $objLeaveTemplet) {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveTemplet on this unsaved LeaveCat.');
			if ((is_null($objLeaveTemplet->IdleaveTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveTemplet on this LeaveCat with an unsaved LeaveTemplet.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`leave_templet`
				SET
					`leave_cat` = null
				WHERE
					`idleave_templet` = ' . $objDatabase->SqlVariable($objLeaveTemplet->IdleaveTemplet) . ' AND
					`leave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
			');
		}

		/**
		 * Unassociates all LeaveTemplets
		 * @return void
		*/
		public function UnassociateAllLeaveTemplets() {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveTemplet on this unsaved LeaveCat.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`leave_templet`
				SET
					`leave_cat` = null
				WHERE
					`leave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
			');
		}

		/**
		 * Deletes an associated LeaveTemplet
		 * @param LeaveTemplet $objLeaveTemplet
		 * @return void
		*/
		public function DeleteAssociatedLeaveTemplet(LeaveTemplet $objLeaveTemplet) {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveTemplet on this unsaved LeaveCat.');
			if ((is_null($objLeaveTemplet->IdleaveTemplet)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveTemplet on this LeaveCat with an unsaved LeaveTemplet.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leave_templet`
				WHERE
					`idleave_templet` = ' . $objDatabase->SqlVariable($objLeaveTemplet->IdleaveTemplet) . ' AND
					`leave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
			');
		}

		/**
		 * Deletes all associated LeaveTemplets
		 * @return void
		*/
		public function DeleteAllLeaveTemplets() {
			if ((is_null($this->intIdleaveCat)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateLeaveTemplet on this unsaved LeaveCat.');

			// Get the Database Object for this Class
			$objDatabase = LeaveCat::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`leave_templet`
				WHERE
					`leave_cat` = ' . $objDatabase->SqlVariable($this->intIdleaveCat) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "leave_cat";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[LeaveCat::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="LeaveCat"><sequence>';
			$strToReturn .= '<element name="IdleaveCat" type="xsd:int"/>';
			$strToReturn .= '<element name="Name" type="xsd:string"/>';
			$strToReturn .= '<element name="Description" type="xsd:string"/>';
			$strToReturn .= '<element name="Calculation" type="xsd:boolean"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('LeaveCat', $strComplexTypeArray)) {
				$strComplexTypeArray['LeaveCat'] = LeaveCat::GetSoapComplexTypeXml();
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, LeaveCat::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new LeaveCat();
			if (property_exists($objSoapObject, 'IdleaveCat'))
				$objToReturn->intIdleaveCat = $objSoapObject->IdleaveCat;
			if (property_exists($objSoapObject, 'Name'))
				$objToReturn->strName = $objSoapObject->Name;
			if (property_exists($objSoapObject, 'Description'))
				$objToReturn->strDescription = $objSoapObject->Description;
			if (property_exists($objSoapObject, 'Calculation'))
				$objToReturn->blnCalculation = $objSoapObject->Calculation;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, LeaveCat::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdleaveCat'] = $this->intIdleaveCat;
			$iArray['Name'] = $this->strName;
			$iArray['Description'] = $this->strDescription;
			$iArray['Calculation'] = $this->blnCalculation;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdleaveCat ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdleaveCat
     * @property-read QQNode $Name
     * @property-read QQNode $Description
     * @property-read QQNode $Calculation
     *
     *
     * @property-read QQReverseReferenceNodeCertificateTemplet $CertificateTemplet
     * @property-read QQReverseReferenceNodeLeaveBalance $LeaveBalance
     * @property-read QQReverseReferenceNodeLeaveTemplet $LeaveTemplet

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeLeaveCat extends QQNode {
		protected $strTableName = 'leave_cat';
		protected $strPrimaryKey = 'idleave_cat';
		protected $strClassName = 'LeaveCat';
		public function __get($strName) {
			switch ($strName) {
				case 'IdleaveCat':
					return new QQNode('idleave_cat', 'IdleaveCat', 'Integer', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'VarChar', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'Blob', $this);
				case 'Calculation':
					return new QQNode('calculation', 'Calculation', 'Bit', $this);
				case 'CertificateTemplet':
					return new QQReverseReferenceNodeCertificateTemplet($this, 'certificatetemplet', 'reverse_reference', 'leave_cat');
				case 'LeaveBalance':
					return new QQReverseReferenceNodeLeaveBalance($this, 'leavebalance', 'reverse_reference', 'leave_cat');
				case 'LeaveTemplet':
					return new QQReverseReferenceNodeLeaveTemplet($this, 'leavetemplet', 'reverse_reference', 'leave_cat');

				case '_PrimaryKeyNode':
					return new QQNode('idleave_cat', 'IdleaveCat', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdleaveCat
     * @property-read QQNode $Name
     * @property-read QQNode $Description
     * @property-read QQNode $Calculation
     *
     *
     * @property-read QQReverseReferenceNodeCertificateTemplet $CertificateTemplet
     * @property-read QQReverseReferenceNodeLeaveBalance $LeaveBalance
     * @property-read QQReverseReferenceNodeLeaveTemplet $LeaveTemplet

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeLeaveCat extends QQReverseReferenceNode {
		protected $strTableName = 'leave_cat';
		protected $strPrimaryKey = 'idleave_cat';
		protected $strClassName = 'LeaveCat';
		public function __get($strName) {
			switch ($strName) {
				case 'IdleaveCat':
					return new QQNode('idleave_cat', 'IdleaveCat', 'integer', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'string', $this);
				case 'Description':
					return new QQNode('description', 'Description', 'string', $this);
				case 'Calculation':
					return new QQNode('calculation', 'Calculation', 'boolean', $this);
				case 'CertificateTemplet':
					return new QQReverseReferenceNodeCertificateTemplet($this, 'certificatetemplet', 'reverse_reference', 'leave_cat');
				case 'LeaveBalance':
					return new QQReverseReferenceNodeLeaveBalance($this, 'leavebalance', 'reverse_reference', 'leave_cat');
				case 'LeaveTemplet':
					return new QQReverseReferenceNodeLeaveTemplet($this, 'leavetemplet', 'reverse_reference', 'leave_cat');

				case '_PrimaryKeyNode':
					return new QQNode('idleave_cat', 'IdleaveCat', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
