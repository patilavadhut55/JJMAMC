<?php
	/**
	 * The abstract MeetingNotesGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the MeetingNotes subclass which
	 * extends this MeetingNotesGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the MeetingNotes class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdmeetingNotes the value for intIdmeetingNotes (Read-Only PK)
	 * @property QDateTime $Date the value for dttDate (Not Null)
	 * @property integer $NoteGrp the value for intNoteGrp (Not Null)
	 * @property integer $Seq the value for intSeq (Not Null)
	 * @property string $Code the value for strCode (Unique)
	 * @property integer $ReferedBy the value for intReferedBy 
	 * @property string $Intro the value for strIntro 
	 * @property string $Data the value for strData 
	 * @property integer $Parrent the value for intParrent 
	 * @property integer $Meeting the value for intMeeting 
	 * @property integer $ActionOn the value for intActionOn 
	 * @property QDateTime $ExpectedClosedDate the value for dttExpectedClosedDate 
	 * @property QDateTime $ClosedDate the value for dttClosedDate 
	 * @property string $ActionSummary the value for strActionSummary 
	 * @property Ledger $NoteGrpObject the value for the Ledger object referenced by intNoteGrp (Not Null)
	 * @property Login $ReferedByObject the value for the Login object referenced by intReferedBy 
	 * @property MeetingNotes $ParrentObject the value for the MeetingNotes object referenced by intParrent 
	 * @property DeptYearEvents $MeetingObject the value for the DeptYearEvents object referenced by intMeeting 
	 * @property Login $ActionOnObject the value for the Login object referenced by intActionOn 
	 * @property-read MeetingAgendaPole $_MeetingAgendaPoleAsMeetingAgenda the value for the private _objMeetingAgendaPoleAsMeetingAgenda (Read-Only) if set due to an expansion on the meeting_agenda_pole.meeting_agenda reverse relationship
	 * @property-read MeetingAgendaPole[] $_MeetingAgendaPoleAsMeetingAgendaArray the value for the private _objMeetingAgendaPoleAsMeetingAgendaArray (Read-Only) if set due to an ExpandAsArray on the meeting_agenda_pole.meeting_agenda reverse relationship
	 * @property-read MeetingNotes $_MeetingNotesAsParrent the value for the private _objMeetingNotesAsParrent (Read-Only) if set due to an expansion on the meeting_notes.parrent reverse relationship
	 * @property-read MeetingNotes[] $_MeetingNotesAsParrentArray the value for the private _objMeetingNotesAsParrentArray (Read-Only) if set due to an ExpandAsArray on the meeting_notes.parrent reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class MeetingNotesGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column meeting_notes.idmeeting_notes
		 * @var integer intIdmeetingNotes
		 */
		protected $intIdmeetingNotes;
		const IdmeetingNotesDefault = null;


		/**
		 * Protected member variable that maps to the database column meeting_notes.date
		 * @var QDateTime dttDate
		 */
		protected $dttDate;
		const DateDefault = null;


		/**
		 * Protected member variable that maps to the database column meeting_notes.note_grp
		 * @var integer intNoteGrp
		 */
		protected $intNoteGrp;
		const NoteGrpDefault = null;


		/**
		 * Protected member variable that maps to the database column meeting_notes.seq
		 * @var integer intSeq
		 */
		protected $intSeq;
		const SeqDefault = null;


		/**
		 * Protected member variable that maps to the database column meeting_notes.code
		 * @var string strCode
		 */
		protected $strCode;
		const CodeMaxLength = 45;
		const CodeDefault = null;


		/**
		 * Protected member variable that maps to the database column meeting_notes.refered_by
		 * @var integer intReferedBy
		 */
		protected $intReferedBy;
		const ReferedByDefault = null;


		/**
		 * Protected member variable that maps to the database column meeting_notes.intro
		 * @var string strIntro
		 */
		protected $strIntro;
		const IntroDefault = null;


		/**
		 * Protected member variable that maps to the database column meeting_notes.data
		 * @var string strData
		 */
		protected $strData;
		const DataDefault = null;


		/**
		 * Protected member variable that maps to the database column meeting_notes.parrent
		 * @var integer intParrent
		 */
		protected $intParrent;
		const ParrentDefault = null;


		/**
		 * Protected member variable that maps to the database column meeting_notes.meeting
		 * @var integer intMeeting
		 */
		protected $intMeeting;
		const MeetingDefault = null;


		/**
		 * Protected member variable that maps to the database column meeting_notes.action_on
		 * @var integer intActionOn
		 */
		protected $intActionOn;
		const ActionOnDefault = null;


		/**
		 * Protected member variable that maps to the database column meeting_notes.expected_closed_date
		 * @var QDateTime dttExpectedClosedDate
		 */
		protected $dttExpectedClosedDate;
		const ExpectedClosedDateDefault = null;


		/**
		 * Protected member variable that maps to the database column meeting_notes.closed_date
		 * @var QDateTime dttClosedDate
		 */
		protected $dttClosedDate;
		const ClosedDateDefault = null;


		/**
		 * Protected member variable that maps to the database column meeting_notes.action_summary
		 * @var string strActionSummary
		 */
		protected $strActionSummary;
		const ActionSummaryDefault = null;


		/**
		 * Private member variable that stores a reference to a single MeetingAgendaPoleAsMeetingAgenda object
		 * (of type MeetingAgendaPole), if this MeetingNotes object was restored with
		 * an expansion on the meeting_agenda_pole association table.
		 * @var MeetingAgendaPole _objMeetingAgendaPoleAsMeetingAgenda;
		 */
		private $_objMeetingAgendaPoleAsMeetingAgenda;

		/**
		 * Private member variable that stores a reference to an array of MeetingAgendaPoleAsMeetingAgenda objects
		 * (of type MeetingAgendaPole[]), if this MeetingNotes object was restored with
		 * an ExpandAsArray on the meeting_agenda_pole association table.
		 * @var MeetingAgendaPole[] _objMeetingAgendaPoleAsMeetingAgendaArray;
		 */
		private $_objMeetingAgendaPoleAsMeetingAgendaArray = null;

		/**
		 * Private member variable that stores a reference to a single MeetingNotesAsParrent object
		 * (of type MeetingNotes), if this MeetingNotes object was restored with
		 * an expansion on the meeting_notes association table.
		 * @var MeetingNotes _objMeetingNotesAsParrent;
		 */
		private $_objMeetingNotesAsParrent;

		/**
		 * Private member variable that stores a reference to an array of MeetingNotesAsParrent objects
		 * (of type MeetingNotes[]), if this MeetingNotes object was restored with
		 * an ExpandAsArray on the meeting_notes association table.
		 * @var MeetingNotes[] _objMeetingNotesAsParrentArray;
		 */
		private $_objMeetingNotesAsParrentArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column meeting_notes.note_grp.
		 *
		 * NOTE: Always use the NoteGrpObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objNoteGrpObject
		 */
		protected $objNoteGrpObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column meeting_notes.refered_by.
		 *
		 * NOTE: Always use the ReferedByObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objReferedByObject
		 */
		protected $objReferedByObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column meeting_notes.parrent.
		 *
		 * NOTE: Always use the ParrentObject property getter to correctly retrieve this MeetingNotes object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var MeetingNotes objParrentObject
		 */
		protected $objParrentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column meeting_notes.meeting.
		 *
		 * NOTE: Always use the MeetingObject property getter to correctly retrieve this DeptYearEvents object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var DeptYearEvents objMeetingObject
		 */
		protected $objMeetingObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column meeting_notes.action_on.
		 *
		 * NOTE: Always use the ActionOnObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objActionOnObject
		 */
		protected $objActionOnObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdmeetingNotes = MeetingNotes::IdmeetingNotesDefault;
			$this->dttDate = (MeetingNotes::DateDefault === null)?null:new QDateTime(MeetingNotes::DateDefault);
			$this->intNoteGrp = MeetingNotes::NoteGrpDefault;
			$this->intSeq = MeetingNotes::SeqDefault;
			$this->strCode = MeetingNotes::CodeDefault;
			$this->intReferedBy = MeetingNotes::ReferedByDefault;
			$this->strIntro = MeetingNotes::IntroDefault;
			$this->strData = MeetingNotes::DataDefault;
			$this->intParrent = MeetingNotes::ParrentDefault;
			$this->intMeeting = MeetingNotes::MeetingDefault;
			$this->intActionOn = MeetingNotes::ActionOnDefault;
			$this->dttExpectedClosedDate = (MeetingNotes::ExpectedClosedDateDefault === null)?null:new QDateTime(MeetingNotes::ExpectedClosedDateDefault);
			$this->dttClosedDate = (MeetingNotes::ClosedDateDefault === null)?null:new QDateTime(MeetingNotes::ClosedDateDefault);
			$this->strActionSummary = MeetingNotes::ActionSummaryDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a MeetingNotes from PK Info
		 * @param integer $intIdmeetingNotes
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingNotes
		 */
		public static function Load($intIdmeetingNotes, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'MeetingNotes', $intIdmeetingNotes);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = MeetingNotes::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::MeetingNotes()->IdmeetingNotes, $intIdmeetingNotes)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all MeetingNoteses
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingNotes[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call MeetingNotes::QueryArray to perform the LoadAll query
			try {
				return MeetingNotes::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all MeetingNoteses
		 * @return int
		 */
		public static function CountAll() {
			// Call MeetingNotes::QueryCount to perform the CountAll query
			return MeetingNotes::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();

			// Create/Build out the QueryBuilder object with MeetingNotes-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'meeting_notes');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				MeetingNotes::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('meeting_notes');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single MeetingNotes object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return MeetingNotes the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = MeetingNotes::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new MeetingNotes object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = MeetingNotes::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return MeetingNotes::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of MeetingNotes objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return MeetingNotes[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = MeetingNotes::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return MeetingNotes::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = MeetingNotes::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of MeetingNotes objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = MeetingNotes::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();

			$strQuery = MeetingNotes::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/meetingnotes', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = MeetingNotes::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this MeetingNotes
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'meeting_notes';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idmeeting_notes', $strAliasPrefix . 'idmeeting_notes');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idmeeting_notes', $strAliasPrefix . 'idmeeting_notes');
			    $objBuilder->AddSelectItem($strTableName, 'date', $strAliasPrefix . 'date');
			    $objBuilder->AddSelectItem($strTableName, 'note_grp', $strAliasPrefix . 'note_grp');
			    $objBuilder->AddSelectItem($strTableName, 'seq', $strAliasPrefix . 'seq');
			    $objBuilder->AddSelectItem($strTableName, 'code', $strAliasPrefix . 'code');
			    $objBuilder->AddSelectItem($strTableName, 'refered_by', $strAliasPrefix . 'refered_by');
			    $objBuilder->AddSelectItem($strTableName, 'intro', $strAliasPrefix . 'intro');
			    $objBuilder->AddSelectItem($strTableName, 'data', $strAliasPrefix . 'data');
			    $objBuilder->AddSelectItem($strTableName, 'parrent', $strAliasPrefix . 'parrent');
			    $objBuilder->AddSelectItem($strTableName, 'meeting', $strAliasPrefix . 'meeting');
			    $objBuilder->AddSelectItem($strTableName, 'action_on', $strAliasPrefix . 'action_on');
			    $objBuilder->AddSelectItem($strTableName, 'expected_closed_date', $strAliasPrefix . 'expected_closed_date');
			    $objBuilder->AddSelectItem($strTableName, 'closed_date', $strAliasPrefix . 'closed_date');
			    $objBuilder->AddSelectItem($strTableName, 'action_summary', $strAliasPrefix . 'action_summary');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a MeetingNotes from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this MeetingNotes::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return MeetingNotes
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idmeeting_notes';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdmeetingNotes == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'meeting_notes__';


						// Expanding reverse references: MeetingAgendaPoleAsMeetingAgenda
						$strAlias = $strAliasPrefix . 'meetingagendapoleasmeetingagenda__idmeeting_agenda_pole';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objMeetingAgendaPoleAsMeetingAgendaArray)
								$objPreviousItem->_objMeetingAgendaPoleAsMeetingAgendaArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objMeetingAgendaPoleAsMeetingAgendaArray)) {
								$objPreviousChildItems = $objPreviousItem->_objMeetingAgendaPoleAsMeetingAgendaArray;
								$objChildItem = MeetingAgendaPole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingagendapoleasmeetingagenda__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objMeetingAgendaPoleAsMeetingAgendaArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objMeetingAgendaPoleAsMeetingAgendaArray[] = MeetingAgendaPole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingagendapoleasmeetingagenda__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: MeetingNotesAsParrent
						$strAlias = $strAliasPrefix . 'meetingnotesasparrent__idmeeting_notes';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objMeetingNotesAsParrentArray)
								$objPreviousItem->_objMeetingNotesAsParrentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objMeetingNotesAsParrentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objMeetingNotesAsParrentArray;
								$objChildItem = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasparrent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objMeetingNotesAsParrentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objMeetingNotesAsParrentArray[] = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'meeting_notes__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the MeetingNotes object
			$objToReturn = new MeetingNotes();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idmeeting_notes';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdmeetingNotes = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'note_grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intNoteGrp = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'seq';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSeq = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'refered_by';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intReferedBy = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'intro';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strIntro = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'data';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strData = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'parrent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intParrent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'meeting';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intMeeting = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'action_on';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intActionOn = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'expected_closed_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttExpectedClosedDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'closed_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttClosedDate = $objDbRow->GetColumn($strAliasName, 'Date');
			$strAlias = $strAliasPrefix . 'action_summary';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strActionSummary = $objDbRow->GetColumn($strAliasName, 'Blob');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdmeetingNotes != $objPreviousItem->IdmeetingNotes) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objMeetingAgendaPoleAsMeetingAgendaArray);
					$cnt = count($objToReturn->_objMeetingAgendaPoleAsMeetingAgendaArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objMeetingAgendaPoleAsMeetingAgendaArray, $objToReturn->_objMeetingAgendaPoleAsMeetingAgendaArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objMeetingNotesAsParrentArray);
					$cnt = count($objToReturn->_objMeetingNotesAsParrentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objMeetingNotesAsParrentArray, $objToReturn->_objMeetingNotesAsParrentArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'meeting_notes__';

			// Check for NoteGrpObject Early Binding
			$strAlias = $strAliasPrefix . 'note_grp__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objNoteGrpObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'note_grp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ReferedByObject Early Binding
			$strAlias = $strAliasPrefix . 'refered_by__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objReferedByObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'refered_by__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ParrentObject Early Binding
			$strAlias = $strAliasPrefix . 'parrent__idmeeting_notes';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objParrentObject = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'parrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for MeetingObject Early Binding
			$strAlias = $strAliasPrefix . 'meeting__iddept_year_events';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objMeetingObject = DeptYearEvents::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meeting__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ActionOnObject Early Binding
			$strAlias = $strAliasPrefix . 'action_on__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objActionOnObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'action_on__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for MeetingAgendaPoleAsMeetingAgenda Virtual Binding
			$strAlias = $strAliasPrefix . 'meetingagendapoleasmeetingagenda__idmeeting_agenda_pole';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objMeetingAgendaPoleAsMeetingAgendaArray)
				$objToReturn->_objMeetingAgendaPoleAsMeetingAgendaArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objMeetingAgendaPoleAsMeetingAgendaArray[] = MeetingAgendaPole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingagendapoleasmeetingagenda__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objMeetingAgendaPoleAsMeetingAgenda = MeetingAgendaPole::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingagendapoleasmeetingagenda__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for MeetingNotesAsParrent Virtual Binding
			$strAlias = $strAliasPrefix . 'meetingnotesasparrent__idmeeting_notes';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objMeetingNotesAsParrentArray)
				$objToReturn->_objMeetingNotesAsParrentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objMeetingNotesAsParrentArray[] = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objMeetingNotesAsParrent = MeetingNotes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'meetingnotesasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of MeetingNoteses from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return MeetingNotes[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = MeetingNotes::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = MeetingNotes::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single MeetingNotes object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return MeetingNotes next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return MeetingNotes::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single MeetingNotes object,
		 * by IdmeetingNotes Index(es)
		 * @param integer $intIdmeetingNotes
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingNotes
		*/
		public static function LoadByIdmeetingNotes($intIdmeetingNotes, $objOptionalClauses = null) {
			return MeetingNotes::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::MeetingNotes()->IdmeetingNotes, $intIdmeetingNotes)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load a single MeetingNotes object,
		 * by Code Index(es)
		 * @param string $strCode
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingNotes
		*/
		public static function LoadByCode($strCode, $objOptionalClauses = null) {
			return MeetingNotes::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::MeetingNotes()->Code, $strCode)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of MeetingNotes objects,
		 * by ReferedBy Index(es)
		 * @param integer $intReferedBy
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingNotes[]
		*/
		public static function LoadArrayByReferedBy($intReferedBy, $objOptionalClauses = null) {
			// Call MeetingNotes::QueryArray to perform the LoadArrayByReferedBy query
			try {
				return MeetingNotes::QueryArray(
					QQ::Equal(QQN::MeetingNotes()->ReferedBy, $intReferedBy),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count MeetingNoteses
		 * by ReferedBy Index(es)
		 * @param integer $intReferedBy
		 * @return int
		*/
		public static function CountByReferedBy($intReferedBy) {
			// Call MeetingNotes::QueryCount to perform the CountByReferedBy query
			return MeetingNotes::QueryCount(
				QQ::Equal(QQN::MeetingNotes()->ReferedBy, $intReferedBy)
			);
		}

		/**
		 * Load an array of MeetingNotes objects,
		 * by NoteGrp Index(es)
		 * @param integer $intNoteGrp
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingNotes[]
		*/
		public static function LoadArrayByNoteGrp($intNoteGrp, $objOptionalClauses = null) {
			// Call MeetingNotes::QueryArray to perform the LoadArrayByNoteGrp query
			try {
				return MeetingNotes::QueryArray(
					QQ::Equal(QQN::MeetingNotes()->NoteGrp, $intNoteGrp),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count MeetingNoteses
		 * by NoteGrp Index(es)
		 * @param integer $intNoteGrp
		 * @return int
		*/
		public static function CountByNoteGrp($intNoteGrp) {
			// Call MeetingNotes::QueryCount to perform the CountByNoteGrp query
			return MeetingNotes::QueryCount(
				QQ::Equal(QQN::MeetingNotes()->NoteGrp, $intNoteGrp)
			);
		}

		/**
		 * Load an array of MeetingNotes objects,
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingNotes[]
		*/
		public static function LoadArrayByParrent($intParrent, $objOptionalClauses = null) {
			// Call MeetingNotes::QueryArray to perform the LoadArrayByParrent query
			try {
				return MeetingNotes::QueryArray(
					QQ::Equal(QQN::MeetingNotes()->Parrent, $intParrent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count MeetingNoteses
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @return int
		*/
		public static function CountByParrent($intParrent) {
			// Call MeetingNotes::QueryCount to perform the CountByParrent query
			return MeetingNotes::QueryCount(
				QQ::Equal(QQN::MeetingNotes()->Parrent, $intParrent)
			);
		}

		/**
		 * Load an array of MeetingNotes objects,
		 * by Meeting Index(es)
		 * @param integer $intMeeting
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingNotes[]
		*/
		public static function LoadArrayByMeeting($intMeeting, $objOptionalClauses = null) {
			// Call MeetingNotes::QueryArray to perform the LoadArrayByMeeting query
			try {
				return MeetingNotes::QueryArray(
					QQ::Equal(QQN::MeetingNotes()->Meeting, $intMeeting),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count MeetingNoteses
		 * by Meeting Index(es)
		 * @param integer $intMeeting
		 * @return int
		*/
		public static function CountByMeeting($intMeeting) {
			// Call MeetingNotes::QueryCount to perform the CountByMeeting query
			return MeetingNotes::QueryCount(
				QQ::Equal(QQN::MeetingNotes()->Meeting, $intMeeting)
			);
		}

		/**
		 * Load an array of MeetingNotes objects,
		 * by ActionOn Index(es)
		 * @param integer $intActionOn
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingNotes[]
		*/
		public static function LoadArrayByActionOn($intActionOn, $objOptionalClauses = null) {
			// Call MeetingNotes::QueryArray to perform the LoadArrayByActionOn query
			try {
				return MeetingNotes::QueryArray(
					QQ::Equal(QQN::MeetingNotes()->ActionOn, $intActionOn),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count MeetingNoteses
		 * by ActionOn Index(es)
		 * @param integer $intActionOn
		 * @return int
		*/
		public static function CountByActionOn($intActionOn) {
			// Call MeetingNotes::QueryCount to perform the CountByActionOn query
			return MeetingNotes::QueryCount(
				QQ::Equal(QQN::MeetingNotes()->ActionOn, $intActionOn)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this MeetingNotes
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `meeting_notes` (
							`date`,
							`note_grp`,
							`seq`,
							`code`,
							`refered_by`,
							`intro`,
							`data`,
							`parrent`,
							`meeting`,
							`action_on`,
							`expected_closed_date`,
							`closed_date`,
							`action_summary`
						) VALUES (
							' . $objDatabase->SqlVariable($this->dttDate) . ',
							' . $objDatabase->SqlVariable($this->intNoteGrp) . ',
							' . $objDatabase->SqlVariable($this->intSeq) . ',
							' . $objDatabase->SqlVariable($this->strCode) . ',
							' . $objDatabase->SqlVariable($this->intReferedBy) . ',
							' . $objDatabase->SqlVariable($this->strIntro) . ',
							' . $objDatabase->SqlVariable($this->strData) . ',
							' . $objDatabase->SqlVariable($this->intParrent) . ',
							' . $objDatabase->SqlVariable($this->intMeeting) . ',
							' . $objDatabase->SqlVariable($this->intActionOn) . ',
							' . $objDatabase->SqlVariable($this->dttExpectedClosedDate) . ',
							' . $objDatabase->SqlVariable($this->dttClosedDate) . ',
							' . $objDatabase->SqlVariable($this->strActionSummary) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdmeetingNotes = $objDatabase->InsertId('meeting_notes', 'idmeeting_notes');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`meeting_notes`
						SET
							`date` = ' . $objDatabase->SqlVariable($this->dttDate) . ',
							`note_grp` = ' . $objDatabase->SqlVariable($this->intNoteGrp) . ',
							`seq` = ' . $objDatabase->SqlVariable($this->intSeq) . ',
							`code` = ' . $objDatabase->SqlVariable($this->strCode) . ',
							`refered_by` = ' . $objDatabase->SqlVariable($this->intReferedBy) . ',
							`intro` = ' . $objDatabase->SqlVariable($this->strIntro) . ',
							`data` = ' . $objDatabase->SqlVariable($this->strData) . ',
							`parrent` = ' . $objDatabase->SqlVariable($this->intParrent) . ',
							`meeting` = ' . $objDatabase->SqlVariable($this->intMeeting) . ',
							`action_on` = ' . $objDatabase->SqlVariable($this->intActionOn) . ',
							`expected_closed_date` = ' . $objDatabase->SqlVariable($this->dttExpectedClosedDate) . ',
							`closed_date` = ' . $objDatabase->SqlVariable($this->dttClosedDate) . ',
							`action_summary` = ' . $objDatabase->SqlVariable($this->strActionSummary) . '
						WHERE
							`idmeeting_notes` = ' . $objDatabase->SqlVariable($this->intIdmeetingNotes) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this MeetingNotes
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this MeetingNotes with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_notes`
				WHERE
					`idmeeting_notes` = ' . $objDatabase->SqlVariable($this->intIdmeetingNotes) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this MeetingNotes ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'MeetingNotes', $this->intIdmeetingNotes);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all MeetingNoteses
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_notes`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate meeting_notes table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `meeting_notes`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this MeetingNotes from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved MeetingNotes object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = MeetingNotes::Load($this->intIdmeetingNotes);

			// Update $this's local variables to match
			$this->dttDate = $objReloaded->dttDate;
			$this->NoteGrp = $objReloaded->NoteGrp;
			$this->intSeq = $objReloaded->intSeq;
			$this->strCode = $objReloaded->strCode;
			$this->ReferedBy = $objReloaded->ReferedBy;
			$this->strIntro = $objReloaded->strIntro;
			$this->strData = $objReloaded->strData;
			$this->Parrent = $objReloaded->Parrent;
			$this->Meeting = $objReloaded->Meeting;
			$this->ActionOn = $objReloaded->ActionOn;
			$this->dttExpectedClosedDate = $objReloaded->dttExpectedClosedDate;
			$this->dttClosedDate = $objReloaded->dttClosedDate;
			$this->strActionSummary = $objReloaded->strActionSummary;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdmeetingNotes':
					/**
					 * Gets the value for intIdmeetingNotes (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdmeetingNotes;

				case 'Date':
					/**
					 * Gets the value for dttDate (Not Null)
					 * @return QDateTime
					 */
					return $this->dttDate;

				case 'NoteGrp':
					/**
					 * Gets the value for intNoteGrp (Not Null)
					 * @return integer
					 */
					return $this->intNoteGrp;

				case 'Seq':
					/**
					 * Gets the value for intSeq (Not Null)
					 * @return integer
					 */
					return $this->intSeq;

				case 'Code':
					/**
					 * Gets the value for strCode (Unique)
					 * @return string
					 */
					return $this->strCode;

				case 'ReferedBy':
					/**
					 * Gets the value for intReferedBy 
					 * @return integer
					 */
					return $this->intReferedBy;

				case 'Intro':
					/**
					 * Gets the value for strIntro 
					 * @return string
					 */
					return $this->strIntro;

				case 'Data':
					/**
					 * Gets the value for strData 
					 * @return string
					 */
					return $this->strData;

				case 'Parrent':
					/**
					 * Gets the value for intParrent 
					 * @return integer
					 */
					return $this->intParrent;

				case 'Meeting':
					/**
					 * Gets the value for intMeeting 
					 * @return integer
					 */
					return $this->intMeeting;

				case 'ActionOn':
					/**
					 * Gets the value for intActionOn 
					 * @return integer
					 */
					return $this->intActionOn;

				case 'ExpectedClosedDate':
					/**
					 * Gets the value for dttExpectedClosedDate 
					 * @return QDateTime
					 */
					return $this->dttExpectedClosedDate;

				case 'ClosedDate':
					/**
					 * Gets the value for dttClosedDate 
					 * @return QDateTime
					 */
					return $this->dttClosedDate;

				case 'ActionSummary':
					/**
					 * Gets the value for strActionSummary 
					 * @return string
					 */
					return $this->strActionSummary;


				///////////////////
				// Member Objects
				///////////////////
				case 'NoteGrpObject':
					/**
					 * Gets the value for the Ledger object referenced by intNoteGrp (Not Null)
					 * @return Ledger
					 */
					try {
						if ((!$this->objNoteGrpObject) && (!is_null($this->intNoteGrp)))
							$this->objNoteGrpObject = Ledger::Load($this->intNoteGrp);
						return $this->objNoteGrpObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ReferedByObject':
					/**
					 * Gets the value for the Login object referenced by intReferedBy 
					 * @return Login
					 */
					try {
						if ((!$this->objReferedByObject) && (!is_null($this->intReferedBy)))
							$this->objReferedByObject = Login::Load($this->intReferedBy);
						return $this->objReferedByObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ParrentObject':
					/**
					 * Gets the value for the MeetingNotes object referenced by intParrent 
					 * @return MeetingNotes
					 */
					try {
						if ((!$this->objParrentObject) && (!is_null($this->intParrent)))
							$this->objParrentObject = MeetingNotes::Load($this->intParrent);
						return $this->objParrentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'MeetingObject':
					/**
					 * Gets the value for the DeptYearEvents object referenced by intMeeting 
					 * @return DeptYearEvents
					 */
					try {
						if ((!$this->objMeetingObject) && (!is_null($this->intMeeting)))
							$this->objMeetingObject = DeptYearEvents::Load($this->intMeeting);
						return $this->objMeetingObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ActionOnObject':
					/**
					 * Gets the value for the Login object referenced by intActionOn 
					 * @return Login
					 */
					try {
						if ((!$this->objActionOnObject) && (!is_null($this->intActionOn)))
							$this->objActionOnObject = Login::Load($this->intActionOn);
						return $this->objActionOnObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_MeetingAgendaPoleAsMeetingAgenda':
					/**
					 * Gets the value for the private _objMeetingAgendaPoleAsMeetingAgenda (Read-Only)
					 * if set due to an expansion on the meeting_agenda_pole.meeting_agenda reverse relationship
					 * @return MeetingAgendaPole
					 */
					return $this->_objMeetingAgendaPoleAsMeetingAgenda;

				case '_MeetingAgendaPoleAsMeetingAgendaArray':
					/**
					 * Gets the value for the private _objMeetingAgendaPoleAsMeetingAgendaArray (Read-Only)
					 * if set due to an ExpandAsArray on the meeting_agenda_pole.meeting_agenda reverse relationship
					 * @return MeetingAgendaPole[]
					 */
					return $this->_objMeetingAgendaPoleAsMeetingAgendaArray;

				case '_MeetingNotesAsParrent':
					/**
					 * Gets the value for the private _objMeetingNotesAsParrent (Read-Only)
					 * if set due to an expansion on the meeting_notes.parrent reverse relationship
					 * @return MeetingNotes
					 */
					return $this->_objMeetingNotesAsParrent;

				case '_MeetingNotesAsParrentArray':
					/**
					 * Gets the value for the private _objMeetingNotesAsParrentArray (Read-Only)
					 * if set due to an ExpandAsArray on the meeting_notes.parrent reverse relationship
					 * @return MeetingNotes[]
					 */
					return $this->_objMeetingNotesAsParrentArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Date':
					/**
					 * Sets the value for dttDate (Not Null)
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'NoteGrp':
					/**
					 * Sets the value for intNoteGrp (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objNoteGrpObject = null;
						return ($this->intNoteGrp = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Seq':
					/**
					 * Sets the value for intSeq (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intSeq = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Code':
					/**
					 * Sets the value for strCode (Unique)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ReferedBy':
					/**
					 * Sets the value for intReferedBy 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objReferedByObject = null;
						return ($this->intReferedBy = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Intro':
					/**
					 * Sets the value for strIntro 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strIntro = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Data':
					/**
					 * Sets the value for strData 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strData = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Parrent':
					/**
					 * Sets the value for intParrent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objParrentObject = null;
						return ($this->intParrent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Meeting':
					/**
					 * Sets the value for intMeeting 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objMeetingObject = null;
						return ($this->intMeeting = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ActionOn':
					/**
					 * Sets the value for intActionOn 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objActionOnObject = null;
						return ($this->intActionOn = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ExpectedClosedDate':
					/**
					 * Sets the value for dttExpectedClosedDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttExpectedClosedDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ClosedDate':
					/**
					 * Sets the value for dttClosedDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttClosedDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ActionSummary':
					/**
					 * Sets the value for strActionSummary 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strActionSummary = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'NoteGrpObject':
					/**
					 * Sets the value for the Ledger object referenced by intNoteGrp (Not Null)
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intNoteGrp = null;
						$this->objNoteGrpObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved NoteGrpObject for this MeetingNotes');

						// Update Local Member Variables
						$this->objNoteGrpObject = $mixValue;
						$this->intNoteGrp = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ReferedByObject':
					/**
					 * Sets the value for the Login object referenced by intReferedBy 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intReferedBy = null;
						$this->objReferedByObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved ReferedByObject for this MeetingNotes');

						// Update Local Member Variables
						$this->objReferedByObject = $mixValue;
						$this->intReferedBy = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ParrentObject':
					/**
					 * Sets the value for the MeetingNotes object referenced by intParrent 
					 * @param MeetingNotes $mixValue
					 * @return MeetingNotes
					 */
					if (is_null($mixValue)) {
						$this->intParrent = null;
						$this->objParrentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a MeetingNotes object
						try {
							$mixValue = QType::Cast($mixValue, 'MeetingNotes');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED MeetingNotes object
						if (is_null($mixValue->IdmeetingNotes))
							throw new QCallerException('Unable to set an unsaved ParrentObject for this MeetingNotes');

						// Update Local Member Variables
						$this->objParrentObject = $mixValue;
						$this->intParrent = $mixValue->IdmeetingNotes;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'MeetingObject':
					/**
					 * Sets the value for the DeptYearEvents object referenced by intMeeting 
					 * @param DeptYearEvents $mixValue
					 * @return DeptYearEvents
					 */
					if (is_null($mixValue)) {
						$this->intMeeting = null;
						$this->objMeetingObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a DeptYearEvents object
						try {
							$mixValue = QType::Cast($mixValue, 'DeptYearEvents');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED DeptYearEvents object
						if (is_null($mixValue->IddeptYearEvents))
							throw new QCallerException('Unable to set an unsaved MeetingObject for this MeetingNotes');

						// Update Local Member Variables
						$this->objMeetingObject = $mixValue;
						$this->intMeeting = $mixValue->IddeptYearEvents;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ActionOnObject':
					/**
					 * Sets the value for the Login object referenced by intActionOn 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intActionOn = null;
						$this->objActionOnObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved ActionOnObject for this MeetingNotes');

						// Update Local Member Variables
						$this->objActionOnObject = $mixValue;
						$this->intActionOn = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for MeetingAgendaPoleAsMeetingAgenda
		//-------------------------------------------------------------------

		/**
		 * Gets all associated MeetingAgendaPolesAsMeetingAgenda as an array of MeetingAgendaPole objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingAgendaPole[]
		*/
		public function GetMeetingAgendaPoleAsMeetingAgendaArray($objOptionalClauses = null) {
			if ((is_null($this->intIdmeetingNotes)))
				return array();

			try {
				return MeetingAgendaPole::LoadArrayByMeetingAgenda($this->intIdmeetingNotes, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated MeetingAgendaPolesAsMeetingAgenda
		 * @return int
		*/
		public function CountMeetingAgendaPolesAsMeetingAgenda() {
			if ((is_null($this->intIdmeetingNotes)))
				return 0;

			return MeetingAgendaPole::CountByMeetingAgenda($this->intIdmeetingNotes);
		}

		/**
		 * Associates a MeetingAgendaPoleAsMeetingAgenda
		 * @param MeetingAgendaPole $objMeetingAgendaPole
		 * @return void
		*/
		public function AssociateMeetingAgendaPoleAsMeetingAgenda(MeetingAgendaPole $objMeetingAgendaPole) {
			if ((is_null($this->intIdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMeetingAgendaPoleAsMeetingAgenda on this unsaved MeetingNotes.');
			if ((is_null($objMeetingAgendaPole->IdmeetingAgendaPole)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMeetingAgendaPoleAsMeetingAgenda on this MeetingNotes with an unsaved MeetingAgendaPole.');

			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_agenda_pole`
				SET
					`meeting_agenda` = ' . $objDatabase->SqlVariable($this->intIdmeetingNotes) . '
				WHERE
					`idmeeting_agenda_pole` = ' . $objDatabase->SqlVariable($objMeetingAgendaPole->IdmeetingAgendaPole) . '
			');
		}

		/**
		 * Unassociates a MeetingAgendaPoleAsMeetingAgenda
		 * @param MeetingAgendaPole $objMeetingAgendaPole
		 * @return void
		*/
		public function UnassociateMeetingAgendaPoleAsMeetingAgenda(MeetingAgendaPole $objMeetingAgendaPole) {
			if ((is_null($this->intIdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingAgendaPoleAsMeetingAgenda on this unsaved MeetingNotes.');
			if ((is_null($objMeetingAgendaPole->IdmeetingAgendaPole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingAgendaPoleAsMeetingAgenda on this MeetingNotes with an unsaved MeetingAgendaPole.');

			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_agenda_pole`
				SET
					`meeting_agenda` = null
				WHERE
					`idmeeting_agenda_pole` = ' . $objDatabase->SqlVariable($objMeetingAgendaPole->IdmeetingAgendaPole) . ' AND
					`meeting_agenda` = ' . $objDatabase->SqlVariable($this->intIdmeetingNotes) . '
			');
		}

		/**
		 * Unassociates all MeetingAgendaPolesAsMeetingAgenda
		 * @return void
		*/
		public function UnassociateAllMeetingAgendaPolesAsMeetingAgenda() {
			if ((is_null($this->intIdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingAgendaPoleAsMeetingAgenda on this unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_agenda_pole`
				SET
					`meeting_agenda` = null
				WHERE
					`meeting_agenda` = ' . $objDatabase->SqlVariable($this->intIdmeetingNotes) . '
			');
		}

		/**
		 * Deletes an associated MeetingAgendaPoleAsMeetingAgenda
		 * @param MeetingAgendaPole $objMeetingAgendaPole
		 * @return void
		*/
		public function DeleteAssociatedMeetingAgendaPoleAsMeetingAgenda(MeetingAgendaPole $objMeetingAgendaPole) {
			if ((is_null($this->intIdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingAgendaPoleAsMeetingAgenda on this unsaved MeetingNotes.');
			if ((is_null($objMeetingAgendaPole->IdmeetingAgendaPole)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingAgendaPoleAsMeetingAgenda on this MeetingNotes with an unsaved MeetingAgendaPole.');

			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_agenda_pole`
				WHERE
					`idmeeting_agenda_pole` = ' . $objDatabase->SqlVariable($objMeetingAgendaPole->IdmeetingAgendaPole) . ' AND
					`meeting_agenda` = ' . $objDatabase->SqlVariable($this->intIdmeetingNotes) . '
			');
		}

		/**
		 * Deletes all associated MeetingAgendaPolesAsMeetingAgenda
		 * @return void
		*/
		public function DeleteAllMeetingAgendaPolesAsMeetingAgenda() {
			if ((is_null($this->intIdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingAgendaPoleAsMeetingAgenda on this unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_agenda_pole`
				WHERE
					`meeting_agenda` = ' . $objDatabase->SqlVariable($this->intIdmeetingNotes) . '
			');
		}


		// Related Objects' Methods for MeetingNotesAsParrent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated MeetingNotesesAsParrent as an array of MeetingNotes objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return MeetingNotes[]
		*/
		public function GetMeetingNotesAsParrentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdmeetingNotes)))
				return array();

			try {
				return MeetingNotes::LoadArrayByParrent($this->intIdmeetingNotes, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated MeetingNotesesAsParrent
		 * @return int
		*/
		public function CountMeetingNotesesAsParrent() {
			if ((is_null($this->intIdmeetingNotes)))
				return 0;

			return MeetingNotes::CountByParrent($this->intIdmeetingNotes);
		}

		/**
		 * Associates a MeetingNotesAsParrent
		 * @param MeetingNotes $objMeetingNotes
		 * @return void
		*/
		public function AssociateMeetingNotesAsParrent(MeetingNotes $objMeetingNotes) {
			if ((is_null($this->intIdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMeetingNotesAsParrent on this unsaved MeetingNotes.');
			if ((is_null($objMeetingNotes->IdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateMeetingNotesAsParrent on this MeetingNotes with an unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_notes`
				SET
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdmeetingNotes) . '
				WHERE
					`idmeeting_notes` = ' . $objDatabase->SqlVariable($objMeetingNotes->IdmeetingNotes) . '
			');
		}

		/**
		 * Unassociates a MeetingNotesAsParrent
		 * @param MeetingNotes $objMeetingNotes
		 * @return void
		*/
		public function UnassociateMeetingNotesAsParrent(MeetingNotes $objMeetingNotes) {
			if ((is_null($this->intIdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsParrent on this unsaved MeetingNotes.');
			if ((is_null($objMeetingNotes->IdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsParrent on this MeetingNotes with an unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_notes`
				SET
					`parrent` = null
				WHERE
					`idmeeting_notes` = ' . $objDatabase->SqlVariable($objMeetingNotes->IdmeetingNotes) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdmeetingNotes) . '
			');
		}

		/**
		 * Unassociates all MeetingNotesesAsParrent
		 * @return void
		*/
		public function UnassociateAllMeetingNotesesAsParrent() {
			if ((is_null($this->intIdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsParrent on this unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`meeting_notes`
				SET
					`parrent` = null
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdmeetingNotes) . '
			');
		}

		/**
		 * Deletes an associated MeetingNotesAsParrent
		 * @param MeetingNotes $objMeetingNotes
		 * @return void
		*/
		public function DeleteAssociatedMeetingNotesAsParrent(MeetingNotes $objMeetingNotes) {
			if ((is_null($this->intIdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsParrent on this unsaved MeetingNotes.');
			if ((is_null($objMeetingNotes->IdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsParrent on this MeetingNotes with an unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_notes`
				WHERE
					`idmeeting_notes` = ' . $objDatabase->SqlVariable($objMeetingNotes->IdmeetingNotes) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdmeetingNotes) . '
			');
		}

		/**
		 * Deletes all associated MeetingNotesesAsParrent
		 * @return void
		*/
		public function DeleteAllMeetingNotesesAsParrent() {
			if ((is_null($this->intIdmeetingNotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateMeetingNotesAsParrent on this unsaved MeetingNotes.');

			// Get the Database Object for this Class
			$objDatabase = MeetingNotes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`meeting_notes`
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdmeetingNotes) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "meeting_notes";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[MeetingNotes::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="MeetingNotes"><sequence>';
			$strToReturn .= '<element name="IdmeetingNotes" type="xsd:int"/>';
			$strToReturn .= '<element name="Date" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="NoteGrpObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="Seq" type="xsd:int"/>';
			$strToReturn .= '<element name="Code" type="xsd:string"/>';
			$strToReturn .= '<element name="ReferedByObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="Intro" type="xsd:string"/>';
			$strToReturn .= '<element name="Data" type="xsd:string"/>';
			$strToReturn .= '<element name="ParrentObject" type="xsd1:MeetingNotes"/>';
			$strToReturn .= '<element name="MeetingObject" type="xsd1:DeptYearEvents"/>';
			$strToReturn .= '<element name="ActionOnObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="ExpectedClosedDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="ClosedDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="ActionSummary" type="xsd:string"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('MeetingNotes', $strComplexTypeArray)) {
				$strComplexTypeArray['MeetingNotes'] = MeetingNotes::GetSoapComplexTypeXml();
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				MeetingNotes::AlterSoapComplexTypeArray($strComplexTypeArray);
				DeptYearEvents::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, MeetingNotes::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new MeetingNotes();
			if (property_exists($objSoapObject, 'IdmeetingNotes'))
				$objToReturn->intIdmeetingNotes = $objSoapObject->IdmeetingNotes;
			if (property_exists($objSoapObject, 'Date'))
				$objToReturn->dttDate = new QDateTime($objSoapObject->Date);
			if ((property_exists($objSoapObject, 'NoteGrpObject')) &&
				($objSoapObject->NoteGrpObject))
				$objToReturn->NoteGrpObject = Ledger::GetObjectFromSoapObject($objSoapObject->NoteGrpObject);
			if (property_exists($objSoapObject, 'Seq'))
				$objToReturn->intSeq = $objSoapObject->Seq;
			if (property_exists($objSoapObject, 'Code'))
				$objToReturn->strCode = $objSoapObject->Code;
			if ((property_exists($objSoapObject, 'ReferedByObject')) &&
				($objSoapObject->ReferedByObject))
				$objToReturn->ReferedByObject = Login::GetObjectFromSoapObject($objSoapObject->ReferedByObject);
			if (property_exists($objSoapObject, 'Intro'))
				$objToReturn->strIntro = $objSoapObject->Intro;
			if (property_exists($objSoapObject, 'Data'))
				$objToReturn->strData = $objSoapObject->Data;
			if ((property_exists($objSoapObject, 'ParrentObject')) &&
				($objSoapObject->ParrentObject))
				$objToReturn->ParrentObject = MeetingNotes::GetObjectFromSoapObject($objSoapObject->ParrentObject);
			if ((property_exists($objSoapObject, 'MeetingObject')) &&
				($objSoapObject->MeetingObject))
				$objToReturn->MeetingObject = DeptYearEvents::GetObjectFromSoapObject($objSoapObject->MeetingObject);
			if ((property_exists($objSoapObject, 'ActionOnObject')) &&
				($objSoapObject->ActionOnObject))
				$objToReturn->ActionOnObject = Login::GetObjectFromSoapObject($objSoapObject->ActionOnObject);
			if (property_exists($objSoapObject, 'ExpectedClosedDate'))
				$objToReturn->dttExpectedClosedDate = new QDateTime($objSoapObject->ExpectedClosedDate);
			if (property_exists($objSoapObject, 'ClosedDate'))
				$objToReturn->dttClosedDate = new QDateTime($objSoapObject->ClosedDate);
			if (property_exists($objSoapObject, 'ActionSummary'))
				$objToReturn->strActionSummary = $objSoapObject->ActionSummary;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, MeetingNotes::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->dttDate)
				$objObject->dttDate = $objObject->dttDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objNoteGrpObject)
				$objObject->objNoteGrpObject = Ledger::GetSoapObjectFromObject($objObject->objNoteGrpObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intNoteGrp = null;
			if ($objObject->objReferedByObject)
				$objObject->objReferedByObject = Login::GetSoapObjectFromObject($objObject->objReferedByObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intReferedBy = null;
			if ($objObject->objParrentObject)
				$objObject->objParrentObject = MeetingNotes::GetSoapObjectFromObject($objObject->objParrentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intParrent = null;
			if ($objObject->objMeetingObject)
				$objObject->objMeetingObject = DeptYearEvents::GetSoapObjectFromObject($objObject->objMeetingObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intMeeting = null;
			if ($objObject->objActionOnObject)
				$objObject->objActionOnObject = Login::GetSoapObjectFromObject($objObject->objActionOnObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intActionOn = null;
			if ($objObject->dttExpectedClosedDate)
				$objObject->dttExpectedClosedDate = $objObject->dttExpectedClosedDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->dttClosedDate)
				$objObject->dttClosedDate = $objObject->dttClosedDate->qFormat(QDateTime::FormatSoap);
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdmeetingNotes'] = $this->intIdmeetingNotes;
			$iArray['Date'] = $this->dttDate;
			$iArray['NoteGrp'] = $this->intNoteGrp;
			$iArray['Seq'] = $this->intSeq;
			$iArray['Code'] = $this->strCode;
			$iArray['ReferedBy'] = $this->intReferedBy;
			$iArray['Intro'] = $this->strIntro;
			$iArray['Data'] = $this->strData;
			$iArray['Parrent'] = $this->intParrent;
			$iArray['Meeting'] = $this->intMeeting;
			$iArray['ActionOn'] = $this->intActionOn;
			$iArray['ExpectedClosedDate'] = $this->dttExpectedClosedDate;
			$iArray['ClosedDate'] = $this->dttClosedDate;
			$iArray['ActionSummary'] = $this->strActionSummary;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdmeetingNotes ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdmeetingNotes
     * @property-read QQNode $Date
     * @property-read QQNode $NoteGrp
     * @property-read QQNodeLedger $NoteGrpObject
     * @property-read QQNode $Seq
     * @property-read QQNode $Code
     * @property-read QQNode $ReferedBy
     * @property-read QQNodeLogin $ReferedByObject
     * @property-read QQNode $Intro
     * @property-read QQNode $Data
     * @property-read QQNode $Parrent
     * @property-read QQNodeMeetingNotes $ParrentObject
     * @property-read QQNode $Meeting
     * @property-read QQNodeDeptYearEvents $MeetingObject
     * @property-read QQNode $ActionOn
     * @property-read QQNodeLogin $ActionOnObject
     * @property-read QQNode $ExpectedClosedDate
     * @property-read QQNode $ClosedDate
     * @property-read QQNode $ActionSummary
     *
     *
     * @property-read QQReverseReferenceNodeMeetingAgendaPole $MeetingAgendaPoleAsMeetingAgenda
     * @property-read QQReverseReferenceNodeMeetingNotes $MeetingNotesAsParrent

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeMeetingNotes extends QQNode {
		protected $strTableName = 'meeting_notes';
		protected $strPrimaryKey = 'idmeeting_notes';
		protected $strClassName = 'MeetingNotes';
		public function __get($strName) {
			switch ($strName) {
				case 'IdmeetingNotes':
					return new QQNode('idmeeting_notes', 'IdmeetingNotes', 'Integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'DateTime', $this);
				case 'NoteGrp':
					return new QQNode('note_grp', 'NoteGrp', 'Integer', $this);
				case 'NoteGrpObject':
					return new QQNodeLedger('note_grp', 'NoteGrpObject', 'Integer', $this);
				case 'Seq':
					return new QQNode('seq', 'Seq', 'Integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'VarChar', $this);
				case 'ReferedBy':
					return new QQNode('refered_by', 'ReferedBy', 'Integer', $this);
				case 'ReferedByObject':
					return new QQNodeLogin('refered_by', 'ReferedByObject', 'Integer', $this);
				case 'Intro':
					return new QQNode('intro', 'Intro', 'Blob', $this);
				case 'Data':
					return new QQNode('data', 'Data', 'Blob', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'Integer', $this);
				case 'ParrentObject':
					return new QQNodeMeetingNotes('parrent', 'ParrentObject', 'Integer', $this);
				case 'Meeting':
					return new QQNode('meeting', 'Meeting', 'Integer', $this);
				case 'MeetingObject':
					return new QQNodeDeptYearEvents('meeting', 'MeetingObject', 'Integer', $this);
				case 'ActionOn':
					return new QQNode('action_on', 'ActionOn', 'Integer', $this);
				case 'ActionOnObject':
					return new QQNodeLogin('action_on', 'ActionOnObject', 'Integer', $this);
				case 'ExpectedClosedDate':
					return new QQNode('expected_closed_date', 'ExpectedClosedDate', 'Date', $this);
				case 'ClosedDate':
					return new QQNode('closed_date', 'ClosedDate', 'Date', $this);
				case 'ActionSummary':
					return new QQNode('action_summary', 'ActionSummary', 'Blob', $this);
				case 'MeetingAgendaPoleAsMeetingAgenda':
					return new QQReverseReferenceNodeMeetingAgendaPole($this, 'meetingagendapoleasmeetingagenda', 'reverse_reference', 'meeting_agenda');
				case 'MeetingNotesAsParrent':
					return new QQReverseReferenceNodeMeetingNotes($this, 'meetingnotesasparrent', 'reverse_reference', 'parrent');

				case '_PrimaryKeyNode':
					return new QQNode('idmeeting_notes', 'IdmeetingNotes', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdmeetingNotes
     * @property-read QQNode $Date
     * @property-read QQNode $NoteGrp
     * @property-read QQNodeLedger $NoteGrpObject
     * @property-read QQNode $Seq
     * @property-read QQNode $Code
     * @property-read QQNode $ReferedBy
     * @property-read QQNodeLogin $ReferedByObject
     * @property-read QQNode $Intro
     * @property-read QQNode $Data
     * @property-read QQNode $Parrent
     * @property-read QQNodeMeetingNotes $ParrentObject
     * @property-read QQNode $Meeting
     * @property-read QQNodeDeptYearEvents $MeetingObject
     * @property-read QQNode $ActionOn
     * @property-read QQNodeLogin $ActionOnObject
     * @property-read QQNode $ExpectedClosedDate
     * @property-read QQNode $ClosedDate
     * @property-read QQNode $ActionSummary
     *
     *
     * @property-read QQReverseReferenceNodeMeetingAgendaPole $MeetingAgendaPoleAsMeetingAgenda
     * @property-read QQReverseReferenceNodeMeetingNotes $MeetingNotesAsParrent

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeMeetingNotes extends QQReverseReferenceNode {
		protected $strTableName = 'meeting_notes';
		protected $strPrimaryKey = 'idmeeting_notes';
		protected $strClassName = 'MeetingNotes';
		public function __get($strName) {
			switch ($strName) {
				case 'IdmeetingNotes':
					return new QQNode('idmeeting_notes', 'IdmeetingNotes', 'integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'QDateTime', $this);
				case 'NoteGrp':
					return new QQNode('note_grp', 'NoteGrp', 'integer', $this);
				case 'NoteGrpObject':
					return new QQNodeLedger('note_grp', 'NoteGrpObject', 'integer', $this);
				case 'Seq':
					return new QQNode('seq', 'Seq', 'integer', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'string', $this);
				case 'ReferedBy':
					return new QQNode('refered_by', 'ReferedBy', 'integer', $this);
				case 'ReferedByObject':
					return new QQNodeLogin('refered_by', 'ReferedByObject', 'integer', $this);
				case 'Intro':
					return new QQNode('intro', 'Intro', 'string', $this);
				case 'Data':
					return new QQNode('data', 'Data', 'string', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'integer', $this);
				case 'ParrentObject':
					return new QQNodeMeetingNotes('parrent', 'ParrentObject', 'integer', $this);
				case 'Meeting':
					return new QQNode('meeting', 'Meeting', 'integer', $this);
				case 'MeetingObject':
					return new QQNodeDeptYearEvents('meeting', 'MeetingObject', 'integer', $this);
				case 'ActionOn':
					return new QQNode('action_on', 'ActionOn', 'integer', $this);
				case 'ActionOnObject':
					return new QQNodeLogin('action_on', 'ActionOnObject', 'integer', $this);
				case 'ExpectedClosedDate':
					return new QQNode('expected_closed_date', 'ExpectedClosedDate', 'QDateTime', $this);
				case 'ClosedDate':
					return new QQNode('closed_date', 'ClosedDate', 'QDateTime', $this);
				case 'ActionSummary':
					return new QQNode('action_summary', 'ActionSummary', 'string', $this);
				case 'MeetingAgendaPoleAsMeetingAgenda':
					return new QQReverseReferenceNodeMeetingAgendaPole($this, 'meetingagendapoleasmeetingagenda', 'reverse_reference', 'meeting_agenda');
				case 'MeetingNotesAsParrent':
					return new QQReverseReferenceNodeMeetingNotes($this, 'meetingnotesasparrent', 'reverse_reference', 'parrent');

				case '_PrimaryKeyNode':
					return new QQNode('idmeeting_notes', 'IdmeetingNotes', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
