<?php
	/**
	 * The abstract NotesGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the Notes subclass which
	 * extends this NotesGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the Notes class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $Idnotes the value for intIdnotes (Read-Only PK)
	 * @property-read string $Date the value for strDate (Read-Only Timestamp)
	 * @property string $Code the value for strCode (Not Null)
	 * @property integer $By the value for intBy (Not Null)
	 * @property integer $RefFeature the value for intRefFeature 
	 * @property integer $RefItemFeature the value for intRefItemFeature 
	 * @property integer $Task the value for intTask 
	 * @property string $Data the value for strData (Not Null)
	 * @property integer $Parrent the value for intParrent 
	 * @property Ledger $ByObject the value for the Ledger object referenced by intBy (Not Null)
	 * @property Features $RefFeatureObject the value for the Features object referenced by intRefFeature 
	 * @property ItemHasFeatures $RefItemFeatureObject the value for the ItemHasFeatures object referenced by intRefItemFeature 
	 * @property Tasks $TaskObject the value for the Tasks object referenced by intTask 
	 * @property Notes $ParrentObject the value for the Notes object referenced by intParrent 
	 * @property-read Notes $_NotesAsParrent the value for the private _objNotesAsParrent (Read-Only) if set due to an expansion on the notes.parrent reverse relationship
	 * @property-read Notes[] $_NotesAsParrentArray the value for the private _objNotesAsParrentArray (Read-Only) if set due to an ExpandAsArray on the notes.parrent reverse relationship
	 * @property-read Share $_ShareAsNote the value for the private _objShareAsNote (Read-Only) if set due to an expansion on the share.note reverse relationship
	 * @property-read Share[] $_ShareAsNoteArray the value for the private _objShareAsNoteArray (Read-Only) if set due to an ExpandAsArray on the share.note reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class NotesGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column notes.idnotes
		 * @var integer intIdnotes
		 */
		protected $intIdnotes;
		const IdnotesDefault = null;


		/**
		 * Protected member variable that maps to the database column notes.date
		 * @var string strDate
		 */
		protected $strDate;
		const DateDefault = null;


		/**
		 * Protected member variable that maps to the database column notes.code
		 * @var string strCode
		 */
		protected $strCode;
		const CodeMaxLength = 45;
		const CodeDefault = null;


		/**
		 * Protected member variable that maps to the database column notes.by
		 * @var integer intBy
		 */
		protected $intBy;
		const ByDefault = null;


		/**
		 * Protected member variable that maps to the database column notes.ref_feature
		 * @var integer intRefFeature
		 */
		protected $intRefFeature;
		const RefFeatureDefault = null;


		/**
		 * Protected member variable that maps to the database column notes.ref_item_feature
		 * @var integer intRefItemFeature
		 */
		protected $intRefItemFeature;
		const RefItemFeatureDefault = null;


		/**
		 * Protected member variable that maps to the database column notes.task
		 * @var integer intTask
		 */
		protected $intTask;
		const TaskDefault = null;


		/**
		 * Protected member variable that maps to the database column notes.data
		 * @var string strData
		 */
		protected $strData;
		const DataDefault = null;


		/**
		 * Protected member variable that maps to the database column notes.parrent
		 * @var integer intParrent
		 */
		protected $intParrent;
		const ParrentDefault = null;


		/**
		 * Private member variable that stores a reference to a single NotesAsParrent object
		 * (of type Notes), if this Notes object was restored with
		 * an expansion on the notes association table.
		 * @var Notes _objNotesAsParrent;
		 */
		private $_objNotesAsParrent;

		/**
		 * Private member variable that stores a reference to an array of NotesAsParrent objects
		 * (of type Notes[]), if this Notes object was restored with
		 * an ExpandAsArray on the notes association table.
		 * @var Notes[] _objNotesAsParrentArray;
		 */
		private $_objNotesAsParrentArray = null;

		/**
		 * Private member variable that stores a reference to a single ShareAsNote object
		 * (of type Share), if this Notes object was restored with
		 * an expansion on the share association table.
		 * @var Share _objShareAsNote;
		 */
		private $_objShareAsNote;

		/**
		 * Private member variable that stores a reference to an array of ShareAsNote objects
		 * (of type Share[]), if this Notes object was restored with
		 * an ExpandAsArray on the share association table.
		 * @var Share[] _objShareAsNoteArray;
		 */
		private $_objShareAsNoteArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column notes.by.
		 *
		 * NOTE: Always use the ByObject property getter to correctly retrieve this Ledger object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Ledger objByObject
		 */
		protected $objByObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column notes.ref_feature.
		 *
		 * NOTE: Always use the RefFeatureObject property getter to correctly retrieve this Features object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Features objRefFeatureObject
		 */
		protected $objRefFeatureObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column notes.ref_item_feature.
		 *
		 * NOTE: Always use the RefItemFeatureObject property getter to correctly retrieve this ItemHasFeatures object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var ItemHasFeatures objRefItemFeatureObject
		 */
		protected $objRefItemFeatureObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column notes.task.
		 *
		 * NOTE: Always use the TaskObject property getter to correctly retrieve this Tasks object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Tasks objTaskObject
		 */
		protected $objTaskObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column notes.parrent.
		 *
		 * NOTE: Always use the ParrentObject property getter to correctly retrieve this Notes object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Notes objParrentObject
		 */
		protected $objParrentObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdnotes = Notes::IdnotesDefault;
			$this->strDate = Notes::DateDefault;
			$this->strCode = Notes::CodeDefault;
			$this->intBy = Notes::ByDefault;
			$this->intRefFeature = Notes::RefFeatureDefault;
			$this->intRefItemFeature = Notes::RefItemFeatureDefault;
			$this->intTask = Notes::TaskDefault;
			$this->strData = Notes::DataDefault;
			$this->intParrent = Notes::ParrentDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a Notes from PK Info
		 * @param integer $intIdnotes
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Notes
		 */
		public static function Load($intIdnotes, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Notes', $intIdnotes);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = Notes::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Notes()->Idnotes, $intIdnotes)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all Noteses
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Notes[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call Notes::QueryArray to perform the LoadAll query
			try {
				return Notes::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all Noteses
		 * @return int
		 */
		public static function CountAll() {
			// Call Notes::QueryCount to perform the CountAll query
			return Notes::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();

			// Create/Build out the QueryBuilder object with Notes-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'notes');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				Notes::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('notes');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single Notes object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Notes the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Notes::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new Notes object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Notes::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return Notes::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of Notes objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return Notes[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Notes::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return Notes::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = Notes::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of Notes objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = Notes::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();

			$strQuery = Notes::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/notes', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = Notes::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this Notes
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'notes';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idnotes', $strAliasPrefix . 'idnotes');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idnotes', $strAliasPrefix . 'idnotes');
			    $objBuilder->AddSelectItem($strTableName, 'date', $strAliasPrefix . 'date');
			    $objBuilder->AddSelectItem($strTableName, 'code', $strAliasPrefix . 'code');
			    $objBuilder->AddSelectItem($strTableName, 'by', $strAliasPrefix . 'by');
			    $objBuilder->AddSelectItem($strTableName, 'ref_feature', $strAliasPrefix . 'ref_feature');
			    $objBuilder->AddSelectItem($strTableName, 'ref_item_feature', $strAliasPrefix . 'ref_item_feature');
			    $objBuilder->AddSelectItem($strTableName, 'task', $strAliasPrefix . 'task');
			    $objBuilder->AddSelectItem($strTableName, 'data', $strAliasPrefix . 'data');
			    $objBuilder->AddSelectItem($strTableName, 'parrent', $strAliasPrefix . 'parrent');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a Notes from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this Notes::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return Notes
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idnotes';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdnotes == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'notes__';


						// Expanding reverse references: NotesAsParrent
						$strAlias = $strAliasPrefix . 'notesasparrent__idnotes';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objNotesAsParrentArray)
								$objPreviousItem->_objNotesAsParrentArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objNotesAsParrentArray)) {
								$objPreviousChildItems = $objPreviousItem->_objNotesAsParrentArray;
								$objChildItem = Notes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'notesasparrent__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objNotesAsParrentArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objNotesAsParrentArray[] = Notes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'notesasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: ShareAsNote
						$strAlias = $strAliasPrefix . 'shareasnote__idshare';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objShareAsNoteArray)
								$objPreviousItem->_objShareAsNoteArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objShareAsNoteArray)) {
								$objPreviousChildItems = $objPreviousItem->_objShareAsNoteArray;
								$objChildItem = Share::InstantiateDbRow($objDbRow, $strAliasPrefix . 'shareasnote__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objShareAsNoteArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objShareAsNoteArray[] = Share::InstantiateDbRow($objDbRow, $strAliasPrefix . 'shareasnote__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'notes__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the Notes object
			$objToReturn = new Notes();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idnotes';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdnotes = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strDate = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'code';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strCode = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'by';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intBy = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'ref_feature';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intRefFeature = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'ref_item_feature';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intRefItemFeature = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'task';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intTask = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'data';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strData = $objDbRow->GetColumn($strAliasName, 'Blob');
			$strAlias = $strAliasPrefix . 'parrent';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intParrent = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->Idnotes != $objPreviousItem->Idnotes) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objNotesAsParrentArray);
					$cnt = count($objToReturn->_objNotesAsParrentArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objNotesAsParrentArray, $objToReturn->_objNotesAsParrentArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objShareAsNoteArray);
					$cnt = count($objToReturn->_objShareAsNoteArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objShareAsNoteArray, $objToReturn->_objShareAsNoteArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'notes__';

			// Check for ByObject Early Binding
			$strAlias = $strAliasPrefix . 'by__idledger';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objByObject = Ledger::InstantiateDbRow($objDbRow, $strAliasPrefix . 'by__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for RefFeatureObject Early Binding
			$strAlias = $strAliasPrefix . 'ref_feature__idfeatures';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objRefFeatureObject = Features::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ref_feature__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for RefItemFeatureObject Early Binding
			$strAlias = $strAliasPrefix . 'ref_item_feature__iditem_has_features';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objRefItemFeatureObject = ItemHasFeatures::InstantiateDbRow($objDbRow, $strAliasPrefix . 'ref_item_feature__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for TaskObject Early Binding
			$strAlias = $strAliasPrefix . 'task__idtasks';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objTaskObject = Tasks::InstantiateDbRow($objDbRow, $strAliasPrefix . 'task__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for ParrentObject Early Binding
			$strAlias = $strAliasPrefix . 'parrent__idnotes';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objParrentObject = Notes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'parrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for NotesAsParrent Virtual Binding
			$strAlias = $strAliasPrefix . 'notesasparrent__idnotes';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objNotesAsParrentArray)
				$objToReturn->_objNotesAsParrentArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objNotesAsParrentArray[] = Notes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'notesasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objNotesAsParrent = Notes::InstantiateDbRow($objDbRow, $strAliasPrefix . 'notesasparrent__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for ShareAsNote Virtual Binding
			$strAlias = $strAliasPrefix . 'shareasnote__idshare';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objShareAsNoteArray)
				$objToReturn->_objShareAsNoteArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objShareAsNoteArray[] = Share::InstantiateDbRow($objDbRow, $strAliasPrefix . 'shareasnote__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objShareAsNote = Share::InstantiateDbRow($objDbRow, $strAliasPrefix . 'shareasnote__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of Noteses from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return Notes[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = Notes::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = Notes::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single Notes object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return Notes next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return Notes::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single Notes object,
		 * by Idnotes Index(es)
		 * @param integer $intIdnotes
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Notes
		*/
		public static function LoadByIdnotes($intIdnotes, $objOptionalClauses = null) {
			return Notes::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::Notes()->Idnotes, $intIdnotes)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of Notes objects,
		 * by By Index(es)
		 * @param integer $intBy
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Notes[]
		*/
		public static function LoadArrayByBy($intBy, $objOptionalClauses = null) {
			// Call Notes::QueryArray to perform the LoadArrayByBy query
			try {
				return Notes::QueryArray(
					QQ::Equal(QQN::Notes()->By, $intBy),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Noteses
		 * by By Index(es)
		 * @param integer $intBy
		 * @return int
		*/
		public static function CountByBy($intBy) {
			// Call Notes::QueryCount to perform the CountByBy query
			return Notes::QueryCount(
				QQ::Equal(QQN::Notes()->By, $intBy)
			);
		}

		/**
		 * Load an array of Notes objects,
		 * by RefFeature Index(es)
		 * @param integer $intRefFeature
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Notes[]
		*/
		public static function LoadArrayByRefFeature($intRefFeature, $objOptionalClauses = null) {
			// Call Notes::QueryArray to perform the LoadArrayByRefFeature query
			try {
				return Notes::QueryArray(
					QQ::Equal(QQN::Notes()->RefFeature, $intRefFeature),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Noteses
		 * by RefFeature Index(es)
		 * @param integer $intRefFeature
		 * @return int
		*/
		public static function CountByRefFeature($intRefFeature) {
			// Call Notes::QueryCount to perform the CountByRefFeature query
			return Notes::QueryCount(
				QQ::Equal(QQN::Notes()->RefFeature, $intRefFeature)
			);
		}

		/**
		 * Load an array of Notes objects,
		 * by RefItemFeature Index(es)
		 * @param integer $intRefItemFeature
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Notes[]
		*/
		public static function LoadArrayByRefItemFeature($intRefItemFeature, $objOptionalClauses = null) {
			// Call Notes::QueryArray to perform the LoadArrayByRefItemFeature query
			try {
				return Notes::QueryArray(
					QQ::Equal(QQN::Notes()->RefItemFeature, $intRefItemFeature),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Noteses
		 * by RefItemFeature Index(es)
		 * @param integer $intRefItemFeature
		 * @return int
		*/
		public static function CountByRefItemFeature($intRefItemFeature) {
			// Call Notes::QueryCount to perform the CountByRefItemFeature query
			return Notes::QueryCount(
				QQ::Equal(QQN::Notes()->RefItemFeature, $intRefItemFeature)
			);
		}

		/**
		 * Load an array of Notes objects,
		 * by Task Index(es)
		 * @param integer $intTask
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Notes[]
		*/
		public static function LoadArrayByTask($intTask, $objOptionalClauses = null) {
			// Call Notes::QueryArray to perform the LoadArrayByTask query
			try {
				return Notes::QueryArray(
					QQ::Equal(QQN::Notes()->Task, $intTask),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Noteses
		 * by Task Index(es)
		 * @param integer $intTask
		 * @return int
		*/
		public static function CountByTask($intTask) {
			// Call Notes::QueryCount to perform the CountByTask query
			return Notes::QueryCount(
				QQ::Equal(QQN::Notes()->Task, $intTask)
			);
		}

		/**
		 * Load an array of Notes objects,
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Notes[]
		*/
		public static function LoadArrayByParrent($intParrent, $objOptionalClauses = null) {
			// Call Notes::QueryArray to perform the LoadArrayByParrent query
			try {
				return Notes::QueryArray(
					QQ::Equal(QQN::Notes()->Parrent, $intParrent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count Noteses
		 * by Parrent Index(es)
		 * @param integer $intParrent
		 * @return int
		*/
		public static function CountByParrent($intParrent) {
			// Call Notes::QueryCount to perform the CountByParrent query
			return Notes::QueryCount(
				QQ::Equal(QQN::Notes()->Parrent, $intParrent)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this Notes
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `notes` (
							`code`,
							`by`,
							`ref_feature`,
							`ref_item_feature`,
							`task`,
							`data`,
							`parrent`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strCode) . ',
							' . $objDatabase->SqlVariable($this->intBy) . ',
							' . $objDatabase->SqlVariable($this->intRefFeature) . ',
							' . $objDatabase->SqlVariable($this->intRefItemFeature) . ',
							' . $objDatabase->SqlVariable($this->intTask) . ',
							' . $objDatabase->SqlVariable($this->strData) . ',
							' . $objDatabase->SqlVariable($this->intParrent) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdnotes = $objDatabase->InsertId('notes', 'idnotes');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)
					if (!$blnForceUpdate) {
						// Perform the Optimistic Locking check
						$objResult = $objDatabase->Query('
							SELECT
								`date`
							FROM
								`notes`
							WHERE
							`idnotes` = ' . $objDatabase->SqlVariable($this->intIdnotes) . '
						');

						$objRow = $objResult->FetchArray();
						if ($objRow[0] != $this->strDate)
							throw new QOptimisticLockingException('Notes');
					}

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`notes`
						SET
							`code` = ' . $objDatabase->SqlVariable($this->strCode) . ',
							`by` = ' . $objDatabase->SqlVariable($this->intBy) . ',
							`ref_feature` = ' . $objDatabase->SqlVariable($this->intRefFeature) . ',
							`ref_item_feature` = ' . $objDatabase->SqlVariable($this->intRefItemFeature) . ',
							`task` = ' . $objDatabase->SqlVariable($this->intTask) . ',
							`data` = ' . $objDatabase->SqlVariable($this->strData) . ',
							`parrent` = ' . $objDatabase->SqlVariable($this->intParrent) . '
						WHERE
							`idnotes` = ' . $objDatabase->SqlVariable($this->intIdnotes) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;

			// Update Local Timestamp
			$objResult = $objDatabase->Query('
				SELECT
					`date`
				FROM
					`notes`
				WHERE
							`idnotes` = ' . $objDatabase->SqlVariable($this->intIdnotes) . '
			');

			$objRow = $objResult->FetchArray();
			$this->strDate = $objRow[0];

			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this Notes
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdnotes)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this Notes with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`notes`
				WHERE
					`idnotes` = ' . $objDatabase->SqlVariable($this->intIdnotes) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this Notes ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'Notes', $this->intIdnotes);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all Noteses
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`notes`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate notes table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `notes`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this Notes from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved Notes object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = Notes::Load($this->intIdnotes);

			// Update $this's local variables to match
			$this->strDate = $objReloaded->strDate;
			$this->strCode = $objReloaded->strCode;
			$this->By = $objReloaded->By;
			$this->RefFeature = $objReloaded->RefFeature;
			$this->RefItemFeature = $objReloaded->RefItemFeature;
			$this->Task = $objReloaded->Task;
			$this->strData = $objReloaded->strData;
			$this->Parrent = $objReloaded->Parrent;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Idnotes':
					/**
					 * Gets the value for intIdnotes (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdnotes;

				case 'Date':
					/**
					 * Gets the value for strDate (Read-Only Timestamp)
					 * @return string
					 */
					return $this->strDate;

				case 'Code':
					/**
					 * Gets the value for strCode (Not Null)
					 * @return string
					 */
					return $this->strCode;

				case 'By':
					/**
					 * Gets the value for intBy (Not Null)
					 * @return integer
					 */
					return $this->intBy;

				case 'RefFeature':
					/**
					 * Gets the value for intRefFeature 
					 * @return integer
					 */
					return $this->intRefFeature;

				case 'RefItemFeature':
					/**
					 * Gets the value for intRefItemFeature 
					 * @return integer
					 */
					return $this->intRefItemFeature;

				case 'Task':
					/**
					 * Gets the value for intTask 
					 * @return integer
					 */
					return $this->intTask;

				case 'Data':
					/**
					 * Gets the value for strData (Not Null)
					 * @return string
					 */
					return $this->strData;

				case 'Parrent':
					/**
					 * Gets the value for intParrent 
					 * @return integer
					 */
					return $this->intParrent;


				///////////////////
				// Member Objects
				///////////////////
				case 'ByObject':
					/**
					 * Gets the value for the Ledger object referenced by intBy (Not Null)
					 * @return Ledger
					 */
					try {
						if ((!$this->objByObject) && (!is_null($this->intBy)))
							$this->objByObject = Ledger::Load($this->intBy);
						return $this->objByObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RefFeatureObject':
					/**
					 * Gets the value for the Features object referenced by intRefFeature 
					 * @return Features
					 */
					try {
						if ((!$this->objRefFeatureObject) && (!is_null($this->intRefFeature)))
							$this->objRefFeatureObject = Features::Load($this->intRefFeature);
						return $this->objRefFeatureObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RefItemFeatureObject':
					/**
					 * Gets the value for the ItemHasFeatures object referenced by intRefItemFeature 
					 * @return ItemHasFeatures
					 */
					try {
						if ((!$this->objRefItemFeatureObject) && (!is_null($this->intRefItemFeature)))
							$this->objRefItemFeatureObject = ItemHasFeatures::Load($this->intRefItemFeature);
						return $this->objRefItemFeatureObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'TaskObject':
					/**
					 * Gets the value for the Tasks object referenced by intTask 
					 * @return Tasks
					 */
					try {
						if ((!$this->objTaskObject) && (!is_null($this->intTask)))
							$this->objTaskObject = Tasks::Load($this->intTask);
						return $this->objTaskObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'ParrentObject':
					/**
					 * Gets the value for the Notes object referenced by intParrent 
					 * @return Notes
					 */
					try {
						if ((!$this->objParrentObject) && (!is_null($this->intParrent)))
							$this->objParrentObject = Notes::Load($this->intParrent);
						return $this->objParrentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_NotesAsParrent':
					/**
					 * Gets the value for the private _objNotesAsParrent (Read-Only)
					 * if set due to an expansion on the notes.parrent reverse relationship
					 * @return Notes
					 */
					return $this->_objNotesAsParrent;

				case '_NotesAsParrentArray':
					/**
					 * Gets the value for the private _objNotesAsParrentArray (Read-Only)
					 * if set due to an ExpandAsArray on the notes.parrent reverse relationship
					 * @return Notes[]
					 */
					return $this->_objNotesAsParrentArray;

				case '_ShareAsNote':
					/**
					 * Gets the value for the private _objShareAsNote (Read-Only)
					 * if set due to an expansion on the share.note reverse relationship
					 * @return Share
					 */
					return $this->_objShareAsNote;

				case '_ShareAsNoteArray':
					/**
					 * Gets the value for the private _objShareAsNoteArray (Read-Only)
					 * if set due to an ExpandAsArray on the share.note reverse relationship
					 * @return Share[]
					 */
					return $this->_objShareAsNoteArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Code':
					/**
					 * Sets the value for strCode (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strCode = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'By':
					/**
					 * Sets the value for intBy (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objByObject = null;
						return ($this->intBy = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RefFeature':
					/**
					 * Sets the value for intRefFeature 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objRefFeatureObject = null;
						return ($this->intRefFeature = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'RefItemFeature':
					/**
					 * Sets the value for intRefItemFeature 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objRefItemFeatureObject = null;
						return ($this->intRefItemFeature = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Task':
					/**
					 * Sets the value for intTask 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objTaskObject = null;
						return ($this->intTask = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Data':
					/**
					 * Sets the value for strData (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strData = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Parrent':
					/**
					 * Sets the value for intParrent 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objParrentObject = null;
						return ($this->intParrent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'ByObject':
					/**
					 * Sets the value for the Ledger object referenced by intBy (Not Null)
					 * @param Ledger $mixValue
					 * @return Ledger
					 */
					if (is_null($mixValue)) {
						$this->intBy = null;
						$this->objByObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Ledger object
						try {
							$mixValue = QType::Cast($mixValue, 'Ledger');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Ledger object
						if (is_null($mixValue->Idledger))
							throw new QCallerException('Unable to set an unsaved ByObject for this Notes');

						// Update Local Member Variables
						$this->objByObject = $mixValue;
						$this->intBy = $mixValue->Idledger;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'RefFeatureObject':
					/**
					 * Sets the value for the Features object referenced by intRefFeature 
					 * @param Features $mixValue
					 * @return Features
					 */
					if (is_null($mixValue)) {
						$this->intRefFeature = null;
						$this->objRefFeatureObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Features object
						try {
							$mixValue = QType::Cast($mixValue, 'Features');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Features object
						if (is_null($mixValue->Idfeatures))
							throw new QCallerException('Unable to set an unsaved RefFeatureObject for this Notes');

						// Update Local Member Variables
						$this->objRefFeatureObject = $mixValue;
						$this->intRefFeature = $mixValue->Idfeatures;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'RefItemFeatureObject':
					/**
					 * Sets the value for the ItemHasFeatures object referenced by intRefItemFeature 
					 * @param ItemHasFeatures $mixValue
					 * @return ItemHasFeatures
					 */
					if (is_null($mixValue)) {
						$this->intRefItemFeature = null;
						$this->objRefItemFeatureObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a ItemHasFeatures object
						try {
							$mixValue = QType::Cast($mixValue, 'ItemHasFeatures');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED ItemHasFeatures object
						if (is_null($mixValue->IditemHasFeatures))
							throw new QCallerException('Unable to set an unsaved RefItemFeatureObject for this Notes');

						// Update Local Member Variables
						$this->objRefItemFeatureObject = $mixValue;
						$this->intRefItemFeature = $mixValue->IditemHasFeatures;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'TaskObject':
					/**
					 * Sets the value for the Tasks object referenced by intTask 
					 * @param Tasks $mixValue
					 * @return Tasks
					 */
					if (is_null($mixValue)) {
						$this->intTask = null;
						$this->objTaskObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Tasks object
						try {
							$mixValue = QType::Cast($mixValue, 'Tasks');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Tasks object
						if (is_null($mixValue->Idtasks))
							throw new QCallerException('Unable to set an unsaved TaskObject for this Notes');

						// Update Local Member Variables
						$this->objTaskObject = $mixValue;
						$this->intTask = $mixValue->Idtasks;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'ParrentObject':
					/**
					 * Sets the value for the Notes object referenced by intParrent 
					 * @param Notes $mixValue
					 * @return Notes
					 */
					if (is_null($mixValue)) {
						$this->intParrent = null;
						$this->objParrentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Notes object
						try {
							$mixValue = QType::Cast($mixValue, 'Notes');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Notes object
						if (is_null($mixValue->Idnotes))
							throw new QCallerException('Unable to set an unsaved ParrentObject for this Notes');

						// Update Local Member Variables
						$this->objParrentObject = $mixValue;
						$this->intParrent = $mixValue->Idnotes;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for NotesAsParrent
		//-------------------------------------------------------------------

		/**
		 * Gets all associated NotesesAsParrent as an array of Notes objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Notes[]
		*/
		public function GetNotesAsParrentArray($objOptionalClauses = null) {
			if ((is_null($this->intIdnotes)))
				return array();

			try {
				return Notes::LoadArrayByParrent($this->intIdnotes, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated NotesesAsParrent
		 * @return int
		*/
		public function CountNotesesAsParrent() {
			if ((is_null($this->intIdnotes)))
				return 0;

			return Notes::CountByParrent($this->intIdnotes);
		}

		/**
		 * Associates a NotesAsParrent
		 * @param Notes $objNotes
		 * @return void
		*/
		public function AssociateNotesAsParrent(Notes $objNotes) {
			if ((is_null($this->intIdnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateNotesAsParrent on this unsaved Notes.');
			if ((is_null($objNotes->Idnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateNotesAsParrent on this Notes with an unsaved Notes.');

			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`notes`
				SET
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdnotes) . '
				WHERE
					`idnotes` = ' . $objDatabase->SqlVariable($objNotes->Idnotes) . '
			');
		}

		/**
		 * Unassociates a NotesAsParrent
		 * @param Notes $objNotes
		 * @return void
		*/
		public function UnassociateNotesAsParrent(Notes $objNotes) {
			if ((is_null($this->intIdnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNotesAsParrent on this unsaved Notes.');
			if ((is_null($objNotes->Idnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNotesAsParrent on this Notes with an unsaved Notes.');

			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`notes`
				SET
					`parrent` = null
				WHERE
					`idnotes` = ' . $objDatabase->SqlVariable($objNotes->Idnotes) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdnotes) . '
			');
		}

		/**
		 * Unassociates all NotesesAsParrent
		 * @return void
		*/
		public function UnassociateAllNotesesAsParrent() {
			if ((is_null($this->intIdnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNotesAsParrent on this unsaved Notes.');

			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`notes`
				SET
					`parrent` = null
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdnotes) . '
			');
		}

		/**
		 * Deletes an associated NotesAsParrent
		 * @param Notes $objNotes
		 * @return void
		*/
		public function DeleteAssociatedNotesAsParrent(Notes $objNotes) {
			if ((is_null($this->intIdnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNotesAsParrent on this unsaved Notes.');
			if ((is_null($objNotes->Idnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNotesAsParrent on this Notes with an unsaved Notes.');

			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`notes`
				WHERE
					`idnotes` = ' . $objDatabase->SqlVariable($objNotes->Idnotes) . ' AND
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdnotes) . '
			');
		}

		/**
		 * Deletes all associated NotesesAsParrent
		 * @return void
		*/
		public function DeleteAllNotesesAsParrent() {
			if ((is_null($this->intIdnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateNotesAsParrent on this unsaved Notes.');

			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`notes`
				WHERE
					`parrent` = ' . $objDatabase->SqlVariable($this->intIdnotes) . '
			');
		}


		// Related Objects' Methods for ShareAsNote
		//-------------------------------------------------------------------

		/**
		 * Gets all associated SharesAsNote as an array of Share objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Share[]
		*/
		public function GetShareAsNoteArray($objOptionalClauses = null) {
			if ((is_null($this->intIdnotes)))
				return array();

			try {
				return Share::LoadArrayByNote($this->intIdnotes, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated SharesAsNote
		 * @return int
		*/
		public function CountSharesAsNote() {
			if ((is_null($this->intIdnotes)))
				return 0;

			return Share::CountByNote($this->intIdnotes);
		}

		/**
		 * Associates a ShareAsNote
		 * @param Share $objShare
		 * @return void
		*/
		public function AssociateShareAsNote(Share $objShare) {
			if ((is_null($this->intIdnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateShareAsNote on this unsaved Notes.');
			if ((is_null($objShare->Idshare)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateShareAsNote on this Notes with an unsaved Share.');

			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`share`
				SET
					`note` = ' . $objDatabase->SqlVariable($this->intIdnotes) . '
				WHERE
					`idshare` = ' . $objDatabase->SqlVariable($objShare->Idshare) . '
			');
		}

		/**
		 * Unassociates a ShareAsNote
		 * @param Share $objShare
		 * @return void
		*/
		public function UnassociateShareAsNote(Share $objShare) {
			if ((is_null($this->intIdnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateShareAsNote on this unsaved Notes.');
			if ((is_null($objShare->Idshare)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateShareAsNote on this Notes with an unsaved Share.');

			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`share`
				SET
					`note` = null
				WHERE
					`idshare` = ' . $objDatabase->SqlVariable($objShare->Idshare) . ' AND
					`note` = ' . $objDatabase->SqlVariable($this->intIdnotes) . '
			');
		}

		/**
		 * Unassociates all SharesAsNote
		 * @return void
		*/
		public function UnassociateAllSharesAsNote() {
			if ((is_null($this->intIdnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateShareAsNote on this unsaved Notes.');

			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`share`
				SET
					`note` = null
				WHERE
					`note` = ' . $objDatabase->SqlVariable($this->intIdnotes) . '
			');
		}

		/**
		 * Deletes an associated ShareAsNote
		 * @param Share $objShare
		 * @return void
		*/
		public function DeleteAssociatedShareAsNote(Share $objShare) {
			if ((is_null($this->intIdnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateShareAsNote on this unsaved Notes.');
			if ((is_null($objShare->Idshare)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateShareAsNote on this Notes with an unsaved Share.');

			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`share`
				WHERE
					`idshare` = ' . $objDatabase->SqlVariable($objShare->Idshare) . ' AND
					`note` = ' . $objDatabase->SqlVariable($this->intIdnotes) . '
			');
		}

		/**
		 * Deletes all associated SharesAsNote
		 * @return void
		*/
		public function DeleteAllSharesAsNote() {
			if ((is_null($this->intIdnotes)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateShareAsNote on this unsaved Notes.');

			// Get the Database Object for this Class
			$objDatabase = Notes::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`share`
				WHERE
					`note` = ' . $objDatabase->SqlVariable($this->intIdnotes) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "notes";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[Notes::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="Notes"><sequence>';
			$strToReturn .= '<element name="Idnotes" type="xsd:int"/>';
			$strToReturn .= '<element name="Date" type="xsd:string"/>';
			$strToReturn .= '<element name="Code" type="xsd:string"/>';
			$strToReturn .= '<element name="ByObject" type="xsd1:Ledger"/>';
			$strToReturn .= '<element name="RefFeatureObject" type="xsd1:Features"/>';
			$strToReturn .= '<element name="RefItemFeatureObject" type="xsd1:ItemHasFeatures"/>';
			$strToReturn .= '<element name="TaskObject" type="xsd1:Tasks"/>';
			$strToReturn .= '<element name="Data" type="xsd:string"/>';
			$strToReturn .= '<element name="ParrentObject" type="xsd1:Notes"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('Notes', $strComplexTypeArray)) {
				$strComplexTypeArray['Notes'] = Notes::GetSoapComplexTypeXml();
				Ledger::AlterSoapComplexTypeArray($strComplexTypeArray);
				Features::AlterSoapComplexTypeArray($strComplexTypeArray);
				ItemHasFeatures::AlterSoapComplexTypeArray($strComplexTypeArray);
				Tasks::AlterSoapComplexTypeArray($strComplexTypeArray);
				Notes::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, Notes::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new Notes();
			if (property_exists($objSoapObject, 'Idnotes'))
				$objToReturn->intIdnotes = $objSoapObject->Idnotes;
			if (property_exists($objSoapObject, 'Date'))
				$objToReturn->strDate = $objSoapObject->Date;
			if (property_exists($objSoapObject, 'Code'))
				$objToReturn->strCode = $objSoapObject->Code;
			if ((property_exists($objSoapObject, 'ByObject')) &&
				($objSoapObject->ByObject))
				$objToReturn->ByObject = Ledger::GetObjectFromSoapObject($objSoapObject->ByObject);
			if ((property_exists($objSoapObject, 'RefFeatureObject')) &&
				($objSoapObject->RefFeatureObject))
				$objToReturn->RefFeatureObject = Features::GetObjectFromSoapObject($objSoapObject->RefFeatureObject);
			if ((property_exists($objSoapObject, 'RefItemFeatureObject')) &&
				($objSoapObject->RefItemFeatureObject))
				$objToReturn->RefItemFeatureObject = ItemHasFeatures::GetObjectFromSoapObject($objSoapObject->RefItemFeatureObject);
			if ((property_exists($objSoapObject, 'TaskObject')) &&
				($objSoapObject->TaskObject))
				$objToReturn->TaskObject = Tasks::GetObjectFromSoapObject($objSoapObject->TaskObject);
			if (property_exists($objSoapObject, 'Data'))
				$objToReturn->strData = $objSoapObject->Data;
			if ((property_exists($objSoapObject, 'ParrentObject')) &&
				($objSoapObject->ParrentObject))
				$objToReturn->ParrentObject = Notes::GetObjectFromSoapObject($objSoapObject->ParrentObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, Notes::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objByObject)
				$objObject->objByObject = Ledger::GetSoapObjectFromObject($objObject->objByObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intBy = null;
			if ($objObject->objRefFeatureObject)
				$objObject->objRefFeatureObject = Features::GetSoapObjectFromObject($objObject->objRefFeatureObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intRefFeature = null;
			if ($objObject->objRefItemFeatureObject)
				$objObject->objRefItemFeatureObject = ItemHasFeatures::GetSoapObjectFromObject($objObject->objRefItemFeatureObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intRefItemFeature = null;
			if ($objObject->objTaskObject)
				$objObject->objTaskObject = Tasks::GetSoapObjectFromObject($objObject->objTaskObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intTask = null;
			if ($objObject->objParrentObject)
				$objObject->objParrentObject = Notes::GetSoapObjectFromObject($objObject->objParrentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intParrent = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['Idnotes'] = $this->intIdnotes;
			$iArray['Date'] = $this->strDate;
			$iArray['Code'] = $this->strCode;
			$iArray['By'] = $this->intBy;
			$iArray['RefFeature'] = $this->intRefFeature;
			$iArray['RefItemFeature'] = $this->intRefItemFeature;
			$iArray['Task'] = $this->intTask;
			$iArray['Data'] = $this->strData;
			$iArray['Parrent'] = $this->intParrent;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdnotes ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $Idnotes
     * @property-read QQNode $Date
     * @property-read QQNode $Code
     * @property-read QQNode $By
     * @property-read QQNodeLedger $ByObject
     * @property-read QQNode $RefFeature
     * @property-read QQNodeFeatures $RefFeatureObject
     * @property-read QQNode $RefItemFeature
     * @property-read QQNodeItemHasFeatures $RefItemFeatureObject
     * @property-read QQNode $Task
     * @property-read QQNodeTasks $TaskObject
     * @property-read QQNode $Data
     * @property-read QQNode $Parrent
     * @property-read QQNodeNotes $ParrentObject
     *
     *
     * @property-read QQReverseReferenceNodeNotes $NotesAsParrent
     * @property-read QQReverseReferenceNodeShare $ShareAsNote

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeNotes extends QQNode {
		protected $strTableName = 'notes';
		protected $strPrimaryKey = 'idnotes';
		protected $strClassName = 'Notes';
		public function __get($strName) {
			switch ($strName) {
				case 'Idnotes':
					return new QQNode('idnotes', 'Idnotes', 'Integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'VarChar', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'VarChar', $this);
				case 'By':
					return new QQNode('by', 'By', 'Integer', $this);
				case 'ByObject':
					return new QQNodeLedger('by', 'ByObject', 'Integer', $this);
				case 'RefFeature':
					return new QQNode('ref_feature', 'RefFeature', 'Integer', $this);
				case 'RefFeatureObject':
					return new QQNodeFeatures('ref_feature', 'RefFeatureObject', 'Integer', $this);
				case 'RefItemFeature':
					return new QQNode('ref_item_feature', 'RefItemFeature', 'Integer', $this);
				case 'RefItemFeatureObject':
					return new QQNodeItemHasFeatures('ref_item_feature', 'RefItemFeatureObject', 'Integer', $this);
				case 'Task':
					return new QQNode('task', 'Task', 'Integer', $this);
				case 'TaskObject':
					return new QQNodeTasks('task', 'TaskObject', 'Integer', $this);
				case 'Data':
					return new QQNode('data', 'Data', 'Blob', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'Integer', $this);
				case 'ParrentObject':
					return new QQNodeNotes('parrent', 'ParrentObject', 'Integer', $this);
				case 'NotesAsParrent':
					return new QQReverseReferenceNodeNotes($this, 'notesasparrent', 'reverse_reference', 'parrent');
				case 'ShareAsNote':
					return new QQReverseReferenceNodeShare($this, 'shareasnote', 'reverse_reference', 'note');

				case '_PrimaryKeyNode':
					return new QQNode('idnotes', 'Idnotes', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $Idnotes
     * @property-read QQNode $Date
     * @property-read QQNode $Code
     * @property-read QQNode $By
     * @property-read QQNodeLedger $ByObject
     * @property-read QQNode $RefFeature
     * @property-read QQNodeFeatures $RefFeatureObject
     * @property-read QQNode $RefItemFeature
     * @property-read QQNodeItemHasFeatures $RefItemFeatureObject
     * @property-read QQNode $Task
     * @property-read QQNodeTasks $TaskObject
     * @property-read QQNode $Data
     * @property-read QQNode $Parrent
     * @property-read QQNodeNotes $ParrentObject
     *
     *
     * @property-read QQReverseReferenceNodeNotes $NotesAsParrent
     * @property-read QQReverseReferenceNodeShare $ShareAsNote

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeNotes extends QQReverseReferenceNode {
		protected $strTableName = 'notes';
		protected $strPrimaryKey = 'idnotes';
		protected $strClassName = 'Notes';
		public function __get($strName) {
			switch ($strName) {
				case 'Idnotes':
					return new QQNode('idnotes', 'Idnotes', 'integer', $this);
				case 'Date':
					return new QQNode('date', 'Date', 'string', $this);
				case 'Code':
					return new QQNode('code', 'Code', 'string', $this);
				case 'By':
					return new QQNode('by', 'By', 'integer', $this);
				case 'ByObject':
					return new QQNodeLedger('by', 'ByObject', 'integer', $this);
				case 'RefFeature':
					return new QQNode('ref_feature', 'RefFeature', 'integer', $this);
				case 'RefFeatureObject':
					return new QQNodeFeatures('ref_feature', 'RefFeatureObject', 'integer', $this);
				case 'RefItemFeature':
					return new QQNode('ref_item_feature', 'RefItemFeature', 'integer', $this);
				case 'RefItemFeatureObject':
					return new QQNodeItemHasFeatures('ref_item_feature', 'RefItemFeatureObject', 'integer', $this);
				case 'Task':
					return new QQNode('task', 'Task', 'integer', $this);
				case 'TaskObject':
					return new QQNodeTasks('task', 'TaskObject', 'integer', $this);
				case 'Data':
					return new QQNode('data', 'Data', 'string', $this);
				case 'Parrent':
					return new QQNode('parrent', 'Parrent', 'integer', $this);
				case 'ParrentObject':
					return new QQNodeNotes('parrent', 'ParrentObject', 'integer', $this);
				case 'NotesAsParrent':
					return new QQReverseReferenceNodeNotes($this, 'notesasparrent', 'reverse_reference', 'parrent');
				case 'ShareAsNote':
					return new QQReverseReferenceNodeShare($this, 'shareasnote', 'reverse_reference', 'note');

				case '_PrimaryKeyNode':
					return new QQNode('idnotes', 'Idnotes', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
