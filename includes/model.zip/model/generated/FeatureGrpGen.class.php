<?php
	/**
	 * The abstract FeatureGrpGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the FeatureGrp subclass which
	 * extends this FeatureGrpGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the FeatureGrp class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdfeatureGrp the value for intIdfeatureGrp (Read-Only PK)
	 * @property string $Name the value for strName (Not Null)
	 * @property string $Abbri the value for strAbbri 
	 * @property integer $Seq the value for intSeq (Not Null)
	 * @property-read Features $_FeaturesAsGrp the value for the private _objFeaturesAsGrp (Read-Only) if set due to an expansion on the features.grp reverse relationship
	 * @property-read Features[] $_FeaturesAsGrpArray the value for the private _objFeaturesAsGrpArray (Read-Only) if set due to an ExpandAsArray on the features.grp reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class FeatureGrpGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column feature_grp.idfeature_grp
		 * @var integer intIdfeatureGrp
		 */
		protected $intIdfeatureGrp;
		const IdfeatureGrpDefault = null;


		/**
		 * Protected member variable that maps to the database column feature_grp.name
		 * @var string strName
		 */
		protected $strName;
		const NameMaxLength = 45;
		const NameDefault = null;


		/**
		 * Protected member variable that maps to the database column feature_grp.abbri
		 * @var string strAbbri
		 */
		protected $strAbbri;
		const AbbriMaxLength = 45;
		const AbbriDefault = null;


		/**
		 * Protected member variable that maps to the database column feature_grp.seq
		 * @var integer intSeq
		 */
		protected $intSeq;
		const SeqDefault = null;


		/**
		 * Private member variable that stores a reference to a single FeaturesAsGrp object
		 * (of type Features), if this FeatureGrp object was restored with
		 * an expansion on the features association table.
		 * @var Features _objFeaturesAsGrp;
		 */
		private $_objFeaturesAsGrp;

		/**
		 * Private member variable that stores a reference to an array of FeaturesAsGrp objects
		 * (of type Features[]), if this FeatureGrp object was restored with
		 * an ExpandAsArray on the features association table.
		 * @var Features[] _objFeaturesAsGrpArray;
		 */
		private $_objFeaturesAsGrpArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdfeatureGrp = FeatureGrp::IdfeatureGrpDefault;
			$this->strName = FeatureGrp::NameDefault;
			$this->strAbbri = FeatureGrp::AbbriDefault;
			$this->intSeq = FeatureGrp::SeqDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a FeatureGrp from PK Info
		 * @param integer $intIdfeatureGrp
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return FeatureGrp
		 */
		public static function Load($intIdfeatureGrp, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'FeatureGrp', $intIdfeatureGrp);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = FeatureGrp::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::FeatureGrp()->IdfeatureGrp, $intIdfeatureGrp)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all FeatureGrps
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return FeatureGrp[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call FeatureGrp::QueryArray to perform the LoadAll query
			try {
				return FeatureGrp::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all FeatureGrps
		 * @return int
		 */
		public static function CountAll() {
			// Call FeatureGrp::QueryCount to perform the CountAll query
			return FeatureGrp::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = FeatureGrp::GetDatabase();

			// Create/Build out the QueryBuilder object with FeatureGrp-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'feature_grp');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				FeatureGrp::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('feature_grp');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single FeatureGrp object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return FeatureGrp the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = FeatureGrp::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new FeatureGrp object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = FeatureGrp::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return FeatureGrp::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of FeatureGrp objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return FeatureGrp[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = FeatureGrp::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return FeatureGrp::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = FeatureGrp::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of FeatureGrp objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = FeatureGrp::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = FeatureGrp::GetDatabase();

			$strQuery = FeatureGrp::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/featuregrp', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = FeatureGrp::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this FeatureGrp
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'feature_grp';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idfeature_grp', $strAliasPrefix . 'idfeature_grp');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idfeature_grp', $strAliasPrefix . 'idfeature_grp');
			    $objBuilder->AddSelectItem($strTableName, 'name', $strAliasPrefix . 'name');
			    $objBuilder->AddSelectItem($strTableName, 'abbri', $strAliasPrefix . 'abbri');
			    $objBuilder->AddSelectItem($strTableName, 'seq', $strAliasPrefix . 'seq');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a FeatureGrp from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this FeatureGrp::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return FeatureGrp
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idfeature_grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdfeatureGrp == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'feature_grp__';


						// Expanding reverse references: FeaturesAsGrp
						$strAlias = $strAliasPrefix . 'featuresasgrp__idfeatures';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objFeaturesAsGrpArray)
								$objPreviousItem->_objFeaturesAsGrpArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objFeaturesAsGrpArray)) {
								$objPreviousChildItems = $objPreviousItem->_objFeaturesAsGrpArray;
								$objChildItem = Features::InstantiateDbRow($objDbRow, $strAliasPrefix . 'featuresasgrp__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objFeaturesAsGrpArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objFeaturesAsGrpArray[] = Features::InstantiateDbRow($objDbRow, $strAliasPrefix . 'featuresasgrp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'feature_grp__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the FeatureGrp object
			$objToReturn = new FeatureGrp();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idfeature_grp';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdfeatureGrp = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'name';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strName = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'abbri';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->strAbbri = $objDbRow->GetColumn($strAliasName, 'VarChar');
			$strAlias = $strAliasPrefix . 'seq';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSeq = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdfeatureGrp != $objPreviousItem->IdfeatureGrp) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objFeaturesAsGrpArray);
					$cnt = count($objToReturn->_objFeaturesAsGrpArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objFeaturesAsGrpArray, $objToReturn->_objFeaturesAsGrpArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'feature_grp__';




			// Check for FeaturesAsGrp Virtual Binding
			$strAlias = $strAliasPrefix . 'featuresasgrp__idfeatures';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objFeaturesAsGrpArray)
				$objToReturn->_objFeaturesAsGrpArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objFeaturesAsGrpArray[] = Features::InstantiateDbRow($objDbRow, $strAliasPrefix . 'featuresasgrp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objFeaturesAsGrp = Features::InstantiateDbRow($objDbRow, $strAliasPrefix . 'featuresasgrp__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of FeatureGrps from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return FeatureGrp[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = FeatureGrp::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = FeatureGrp::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single FeatureGrp object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return FeatureGrp next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return FeatureGrp::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single FeatureGrp object,
		 * by IdfeatureGrp Index(es)
		 * @param integer $intIdfeatureGrp
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return FeatureGrp
		*/
		public static function LoadByIdfeatureGrp($intIdfeatureGrp, $objOptionalClauses = null) {
			return FeatureGrp::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::FeatureGrp()->IdfeatureGrp, $intIdfeatureGrp)
				),
				$objOptionalClauses
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this FeatureGrp
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = FeatureGrp::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `feature_grp` (
							`name`,
							`abbri`,
							`seq`
						) VALUES (
							' . $objDatabase->SqlVariable($this->strName) . ',
							' . $objDatabase->SqlVariable($this->strAbbri) . ',
							' . $objDatabase->SqlVariable($this->intSeq) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdfeatureGrp = $objDatabase->InsertId('feature_grp', 'idfeature_grp');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`feature_grp`
						SET
							`name` = ' . $objDatabase->SqlVariable($this->strName) . ',
							`abbri` = ' . $objDatabase->SqlVariable($this->strAbbri) . ',
							`seq` = ' . $objDatabase->SqlVariable($this->intSeq) . '
						WHERE
							`idfeature_grp` = ' . $objDatabase->SqlVariable($this->intIdfeatureGrp) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this FeatureGrp
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdfeatureGrp)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this FeatureGrp with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = FeatureGrp::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`feature_grp`
				WHERE
					`idfeature_grp` = ' . $objDatabase->SqlVariable($this->intIdfeatureGrp) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this FeatureGrp ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'FeatureGrp', $this->intIdfeatureGrp);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all FeatureGrps
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = FeatureGrp::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`feature_grp`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate feature_grp table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = FeatureGrp::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `feature_grp`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this FeatureGrp from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved FeatureGrp object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = FeatureGrp::Load($this->intIdfeatureGrp);

			// Update $this's local variables to match
			$this->strName = $objReloaded->strName;
			$this->strAbbri = $objReloaded->strAbbri;
			$this->intSeq = $objReloaded->intSeq;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdfeatureGrp':
					/**
					 * Gets the value for intIdfeatureGrp (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdfeatureGrp;

				case 'Name':
					/**
					 * Gets the value for strName (Not Null)
					 * @return string
					 */
					return $this->strName;

				case 'Abbri':
					/**
					 * Gets the value for strAbbri 
					 * @return string
					 */
					return $this->strAbbri;

				case 'Seq':
					/**
					 * Gets the value for intSeq (Not Null)
					 * @return integer
					 */
					return $this->intSeq;


				///////////////////
				// Member Objects
				///////////////////

				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_FeaturesAsGrp':
					/**
					 * Gets the value for the private _objFeaturesAsGrp (Read-Only)
					 * if set due to an expansion on the features.grp reverse relationship
					 * @return Features
					 */
					return $this->_objFeaturesAsGrp;

				case '_FeaturesAsGrpArray':
					/**
					 * Gets the value for the private _objFeaturesAsGrpArray (Read-Only)
					 * if set due to an ExpandAsArray on the features.grp reverse relationship
					 * @return Features[]
					 */
					return $this->_objFeaturesAsGrpArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Name':
					/**
					 * Sets the value for strName (Not Null)
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strName = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Abbri':
					/**
					 * Sets the value for strAbbri 
					 * @param string $mixValue
					 * @return string
					 */
					try {
						return ($this->strAbbri = QType::Cast($mixValue, QType::String));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Seq':
					/**
					 * Sets the value for intSeq (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						return ($this->intSeq = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for FeaturesAsGrp
		//-------------------------------------------------------------------

		/**
		 * Gets all associated FeaturesesAsGrp as an array of Features objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return Features[]
		*/
		public function GetFeaturesAsGrpArray($objOptionalClauses = null) {
			if ((is_null($this->intIdfeatureGrp)))
				return array();

			try {
				return Features::LoadArrayByGrp($this->intIdfeatureGrp, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated FeaturesesAsGrp
		 * @return int
		*/
		public function CountFeaturesesAsGrp() {
			if ((is_null($this->intIdfeatureGrp)))
				return 0;

			return Features::CountByGrp($this->intIdfeatureGrp);
		}

		/**
		 * Associates a FeaturesAsGrp
		 * @param Features $objFeatures
		 * @return void
		*/
		public function AssociateFeaturesAsGrp(Features $objFeatures) {
			if ((is_null($this->intIdfeatureGrp)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateFeaturesAsGrp on this unsaved FeatureGrp.');
			if ((is_null($objFeatures->Idfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateFeaturesAsGrp on this FeatureGrp with an unsaved Features.');

			// Get the Database Object for this Class
			$objDatabase = FeatureGrp::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`features`
				SET
					`grp` = ' . $objDatabase->SqlVariable($this->intIdfeatureGrp) . '
				WHERE
					`idfeatures` = ' . $objDatabase->SqlVariable($objFeatures->Idfeatures) . '
			');
		}

		/**
		 * Unassociates a FeaturesAsGrp
		 * @param Features $objFeatures
		 * @return void
		*/
		public function UnassociateFeaturesAsGrp(Features $objFeatures) {
			if ((is_null($this->intIdfeatureGrp)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeaturesAsGrp on this unsaved FeatureGrp.');
			if ((is_null($objFeatures->Idfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeaturesAsGrp on this FeatureGrp with an unsaved Features.');

			// Get the Database Object for this Class
			$objDatabase = FeatureGrp::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`features`
				SET
					`grp` = null
				WHERE
					`idfeatures` = ' . $objDatabase->SqlVariable($objFeatures->Idfeatures) . ' AND
					`grp` = ' . $objDatabase->SqlVariable($this->intIdfeatureGrp) . '
			');
		}

		/**
		 * Unassociates all FeaturesesAsGrp
		 * @return void
		*/
		public function UnassociateAllFeaturesesAsGrp() {
			if ((is_null($this->intIdfeatureGrp)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeaturesAsGrp on this unsaved FeatureGrp.');

			// Get the Database Object for this Class
			$objDatabase = FeatureGrp::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`features`
				SET
					`grp` = null
				WHERE
					`grp` = ' . $objDatabase->SqlVariable($this->intIdfeatureGrp) . '
			');
		}

		/**
		 * Deletes an associated FeaturesAsGrp
		 * @param Features $objFeatures
		 * @return void
		*/
		public function DeleteAssociatedFeaturesAsGrp(Features $objFeatures) {
			if ((is_null($this->intIdfeatureGrp)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeaturesAsGrp on this unsaved FeatureGrp.');
			if ((is_null($objFeatures->Idfeatures)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeaturesAsGrp on this FeatureGrp with an unsaved Features.');

			// Get the Database Object for this Class
			$objDatabase = FeatureGrp::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`features`
				WHERE
					`idfeatures` = ' . $objDatabase->SqlVariable($objFeatures->Idfeatures) . ' AND
					`grp` = ' . $objDatabase->SqlVariable($this->intIdfeatureGrp) . '
			');
		}

		/**
		 * Deletes all associated FeaturesesAsGrp
		 * @return void
		*/
		public function DeleteAllFeaturesesAsGrp() {
			if ((is_null($this->intIdfeatureGrp)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateFeaturesAsGrp on this unsaved FeatureGrp.');

			// Get the Database Object for this Class
			$objDatabase = FeatureGrp::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`features`
				WHERE
					`grp` = ' . $objDatabase->SqlVariable($this->intIdfeatureGrp) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "feature_grp";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[FeatureGrp::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="FeatureGrp"><sequence>';
			$strToReturn .= '<element name="IdfeatureGrp" type="xsd:int"/>';
			$strToReturn .= '<element name="Name" type="xsd:string"/>';
			$strToReturn .= '<element name="Abbri" type="xsd:string"/>';
			$strToReturn .= '<element name="Seq" type="xsd:int"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('FeatureGrp', $strComplexTypeArray)) {
				$strComplexTypeArray['FeatureGrp'] = FeatureGrp::GetSoapComplexTypeXml();
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, FeatureGrp::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new FeatureGrp();
			if (property_exists($objSoapObject, 'IdfeatureGrp'))
				$objToReturn->intIdfeatureGrp = $objSoapObject->IdfeatureGrp;
			if (property_exists($objSoapObject, 'Name'))
				$objToReturn->strName = $objSoapObject->Name;
			if (property_exists($objSoapObject, 'Abbri'))
				$objToReturn->strAbbri = $objSoapObject->Abbri;
			if (property_exists($objSoapObject, 'Seq'))
				$objToReturn->intSeq = $objSoapObject->Seq;
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, FeatureGrp::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdfeatureGrp'] = $this->intIdfeatureGrp;
			$iArray['Name'] = $this->strName;
			$iArray['Abbri'] = $this->strAbbri;
			$iArray['Seq'] = $this->intSeq;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdfeatureGrp ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdfeatureGrp
     * @property-read QQNode $Name
     * @property-read QQNode $Abbri
     * @property-read QQNode $Seq
     *
     *
     * @property-read QQReverseReferenceNodeFeatures $FeaturesAsGrp

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeFeatureGrp extends QQNode {
		protected $strTableName = 'feature_grp';
		protected $strPrimaryKey = 'idfeature_grp';
		protected $strClassName = 'FeatureGrp';
		public function __get($strName) {
			switch ($strName) {
				case 'IdfeatureGrp':
					return new QQNode('idfeature_grp', 'IdfeatureGrp', 'Integer', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'VarChar', $this);
				case 'Abbri':
					return new QQNode('abbri', 'Abbri', 'VarChar', $this);
				case 'Seq':
					return new QQNode('seq', 'Seq', 'Integer', $this);
				case 'FeaturesAsGrp':
					return new QQReverseReferenceNodeFeatures($this, 'featuresasgrp', 'reverse_reference', 'grp');

				case '_PrimaryKeyNode':
					return new QQNode('idfeature_grp', 'IdfeatureGrp', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdfeatureGrp
     * @property-read QQNode $Name
     * @property-read QQNode $Abbri
     * @property-read QQNode $Seq
     *
     *
     * @property-read QQReverseReferenceNodeFeatures $FeaturesAsGrp

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeFeatureGrp extends QQReverseReferenceNode {
		protected $strTableName = 'feature_grp';
		protected $strPrimaryKey = 'idfeature_grp';
		protected $strClassName = 'FeatureGrp';
		public function __get($strName) {
			switch ($strName) {
				case 'IdfeatureGrp':
					return new QQNode('idfeature_grp', 'IdfeatureGrp', 'integer', $this);
				case 'Name':
					return new QQNode('name', 'Name', 'string', $this);
				case 'Abbri':
					return new QQNode('abbri', 'Abbri', 'string', $this);
				case 'Seq':
					return new QQNode('seq', 'Seq', 'integer', $this);
				case 'FeaturesAsGrp':
					return new QQReverseReferenceNodeFeatures($this, 'featuresasgrp', 'reverse_reference', 'grp');

				case '_PrimaryKeyNode':
					return new QQNode('idfeature_grp', 'IdfeatureGrp', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
