<?php
	/**
	 * The AttendenceType class defined here contains
	 * code for the AttendenceType enumerated type.  It represents
	 * the enumerated values found in the "attendence_type" table
	 * in the database.
	 *
	 * To use, you should use the AttendenceType subclass which
	 * extends this AttendenceTypeGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the AttendenceType class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 */
	abstract class AttendenceTypeGen extends QBaseClass {

		const MaxId = 0;

		public static $NameArray = array();

		public static $TokenArray = array();

		public static function ToString($intAttendenceTypeId) {
			switch ($intAttendenceTypeId) {
				default:
					throw new QCallerException(sprintf('Invalid intAttendenceTypeId: %s', $intAttendenceTypeId));
			}
		}

		public static function ToToken($intAttendenceTypeId) {
			switch ($intAttendenceTypeId) {
				default:
					throw new QCallerException(sprintf('Invalid intAttendenceTypeId: %s', $intAttendenceTypeId));
			}
		}

	}
?>