<?php
	/**
	 * The AppointmentType class defined here contains
	 * code for the AppointmentType enumerated type.  It represents
	 * the enumerated values found in the "appointment_type" table
	 * in the database.
	 *
	 * To use, you should use the AppointmentType subclass which
	 * extends this AppointmentTypeGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the AppointmentType class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 */
	abstract class AppointmentTypeGen extends QBaseClass {

		const MaxId = 0;

		public static $NameArray = array();

		public static $TokenArray = array();

		public static function ToString($intAppointmentTypeId) {
			switch ($intAppointmentTypeId) {
				default:
					throw new QCallerException(sprintf('Invalid intAppointmentTypeId: %s', $intAppointmentTypeId));
			}
		}

		public static function ToToken($intAppointmentTypeId) {
			switch ($intAppointmentTypeId) {
				default:
					throw new QCallerException(sprintf('Invalid intAppointmentTypeId: %s', $intAppointmentTypeId));
			}
		}

	}
?>