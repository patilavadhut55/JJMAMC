<?php
	/**
	 * The abstract ApplyGradeImpromentGen class defined here is
	 * code-generated and contains all the basic CRUD-type functionality as well as
	 * basic methods to handle relationships and index-based loading.
	 *
	 * To use, you should use the ApplyGradeImproment subclass which
	 * extends this ApplyGradeImpromentGen class.
	 *
	 * Because subsequent re-code generations will overwrite any changes to this
	 * file, you should leave this file unaltered to prevent yourself from losing
	 * any information or code changes.  All customizations should be done by
	 * overriding existing or implementing new methods, properties and variables
	 * in the ApplyGradeImproment class.
	 *
	 * @package My QCubed Application
	 * @subpackage GeneratedDataObjects
	 * @property-read integer $IdapplyGradeImproment the value for intIdapplyGradeImproment (Read-Only PK)
	 * @property integer $Student the value for intStudent (Not Null)
	 * @property integer $Subject the value for intSubject (Not Null)
	 * @property boolean $Applied the value for blnApplied 
	 * @property integer $AppliedBy the value for intAppliedBy 
	 * @property QDateTime $AppliedDate the value for dttAppliedDate 
	 * @property boolean $Discard the value for blnDiscard 
	 * @property integer $Gradecard the value for intGradecard 
	 * @property Login $StudentObject the value for the Login object referenced by intStudent (Not Null)
	 * @property YearlySubject $SubjectObject the value for the YearlySubject object referenced by intSubject (Not Null)
	 * @property Login $AppliedByObject the value for the Login object referenced by intAppliedBy 
	 * @property GradeCard $GradecardObject the value for the GradeCard object referenced by intGradecard 
	 * @property-read AppliedExam $_AppliedExamAsRefGradeImprovement the value for the private _objAppliedExamAsRefGradeImprovement (Read-Only) if set due to an expansion on the applied_exam.ref_grade_improvement reverse relationship
	 * @property-read AppliedExam[] $_AppliedExamAsRefGradeImprovementArray the value for the private _objAppliedExamAsRefGradeImprovementArray (Read-Only) if set due to an ExpandAsArray on the applied_exam.ref_grade_improvement reverse relationship
	 * @property-read GradeCard $_GradeCardAsRefGradeImprovement the value for the private _objGradeCardAsRefGradeImprovement (Read-Only) if set due to an expansion on the grade_card.ref_grade_improvement reverse relationship
	 * @property-read GradeCard[] $_GradeCardAsRefGradeImprovementArray the value for the private _objGradeCardAsRefGradeImprovementArray (Read-Only) if set due to an ExpandAsArray on the grade_card.ref_grade_improvement reverse relationship
	 * @property-read boolean $__Restored whether or not this object was restored from the database (as opposed to created new)
	 */
	class ApplyGradeImpromentGen extends QBaseClass implements IteratorAggregate {

		///////////////////////////////////////////////////////////////////////
		// PROTECTED MEMBER VARIABLES and TEXT FIELD MAXLENGTHS (if applicable)
		///////////////////////////////////////////////////////////////////////

		/**
		 * Protected member variable that maps to the database PK Identity column apply_grade_improment.idapply_grade_improment
		 * @var integer intIdapplyGradeImproment
		 */
		protected $intIdapplyGradeImproment;
		const IdapplyGradeImpromentDefault = null;


		/**
		 * Protected member variable that maps to the database column apply_grade_improment.student
		 * @var integer intStudent
		 */
		protected $intStudent;
		const StudentDefault = null;


		/**
		 * Protected member variable that maps to the database column apply_grade_improment.subject
		 * @var integer intSubject
		 */
		protected $intSubject;
		const SubjectDefault = null;


		/**
		 * Protected member variable that maps to the database column apply_grade_improment.applied
		 * @var boolean blnApplied
		 */
		protected $blnApplied;
		const AppliedDefault = null;


		/**
		 * Protected member variable that maps to the database column apply_grade_improment.applied_by
		 * @var integer intAppliedBy
		 */
		protected $intAppliedBy;
		const AppliedByDefault = null;


		/**
		 * Protected member variable that maps to the database column apply_grade_improment.applied_date
		 * @var QDateTime dttAppliedDate
		 */
		protected $dttAppliedDate;
		const AppliedDateDefault = null;


		/**
		 * Protected member variable that maps to the database column apply_grade_improment.discard
		 * @var boolean blnDiscard
		 */
		protected $blnDiscard;
		const DiscardDefault = null;


		/**
		 * Protected member variable that maps to the database column apply_grade_improment.gradecard
		 * @var integer intGradecard
		 */
		protected $intGradecard;
		const GradecardDefault = null;


		/**
		 * Private member variable that stores a reference to a single AppliedExamAsRefGradeImprovement object
		 * (of type AppliedExam), if this ApplyGradeImproment object was restored with
		 * an expansion on the applied_exam association table.
		 * @var AppliedExam _objAppliedExamAsRefGradeImprovement;
		 */
		private $_objAppliedExamAsRefGradeImprovement;

		/**
		 * Private member variable that stores a reference to an array of AppliedExamAsRefGradeImprovement objects
		 * (of type AppliedExam[]), if this ApplyGradeImproment object was restored with
		 * an ExpandAsArray on the applied_exam association table.
		 * @var AppliedExam[] _objAppliedExamAsRefGradeImprovementArray;
		 */
		private $_objAppliedExamAsRefGradeImprovementArray = null;

		/**
		 * Private member variable that stores a reference to a single GradeCardAsRefGradeImprovement object
		 * (of type GradeCard), if this ApplyGradeImproment object was restored with
		 * an expansion on the grade_card association table.
		 * @var GradeCard _objGradeCardAsRefGradeImprovement;
		 */
		private $_objGradeCardAsRefGradeImprovement;

		/**
		 * Private member variable that stores a reference to an array of GradeCardAsRefGradeImprovement objects
		 * (of type GradeCard[]), if this ApplyGradeImproment object was restored with
		 * an ExpandAsArray on the grade_card association table.
		 * @var GradeCard[] _objGradeCardAsRefGradeImprovementArray;
		 */
		private $_objGradeCardAsRefGradeImprovementArray = null;

		/**
		 * Protected array of virtual attributes for this object (e.g. extra/other calculated and/or non-object bound
		 * columns from the run-time database query result for this object).  Used by InstantiateDbRow and
		 * GetVirtualAttribute.
		 * @var string[] $__strVirtualAttributeArray
		 */
		protected $__strVirtualAttributeArray = array();

		/**
		 * Protected internal member variable that specifies whether or not this object is Restored from the database.
		 * Used by Save() to determine if Save() should perform a db UPDATE or INSERT.
		 * @var bool __blnRestored;
		 */
		protected $__blnRestored;




		///////////////////////////////
		// PROTECTED MEMBER OBJECTS
		///////////////////////////////

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column apply_grade_improment.student.
		 *
		 * NOTE: Always use the StudentObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objStudentObject
		 */
		protected $objStudentObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column apply_grade_improment.subject.
		 *
		 * NOTE: Always use the SubjectObject property getter to correctly retrieve this YearlySubject object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var YearlySubject objSubjectObject
		 */
		protected $objSubjectObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column apply_grade_improment.applied_by.
		 *
		 * NOTE: Always use the AppliedByObject property getter to correctly retrieve this Login object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var Login objAppliedByObject
		 */
		protected $objAppliedByObject;

		/**
		 * Protected member variable that contains the object pointed by the reference
		 * in the database column apply_grade_improment.gradecard.
		 *
		 * NOTE: Always use the GradecardObject property getter to correctly retrieve this GradeCard object.
		 * (Because this class implements late binding, this variable reference MAY be null.)
		 * @var GradeCard objGradecardObject
		 */
		protected $objGradecardObject;



		/**
		 * Initialize each property with default values from database definition
		 */
		public function Initialize()
		{
			$this->intIdapplyGradeImproment = ApplyGradeImproment::IdapplyGradeImpromentDefault;
			$this->intStudent = ApplyGradeImproment::StudentDefault;
			$this->intSubject = ApplyGradeImproment::SubjectDefault;
			$this->blnApplied = ApplyGradeImproment::AppliedDefault;
			$this->intAppliedBy = ApplyGradeImproment::AppliedByDefault;
			$this->dttAppliedDate = (ApplyGradeImproment::AppliedDateDefault === null)?null:new QDateTime(ApplyGradeImproment::AppliedDateDefault);
			$this->blnDiscard = ApplyGradeImproment::DiscardDefault;
			$this->intGradecard = ApplyGradeImproment::GradecardDefault;
		}


		///////////////////////////////
		// CLASS-WIDE LOAD AND COUNT METHODS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return QDatabaseBase reference to the Database object that can query this class
		 */
		public static function GetDatabase() {
			return QApplication::$Database[1];
		}

		/**
		 * Load a ApplyGradeImproment from PK Info
		 * @param integer $intIdapplyGradeImproment
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ApplyGradeImproment
		 */
		public static function Load($intIdapplyGradeImproment, $objOptionalClauses = null) {
			$strCacheKey = false;
			if (QApplication::$objCacheProvider && !$objOptionalClauses && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'ApplyGradeImproment', $intIdapplyGradeImproment);
				$objCachedObject = QApplication::$objCacheProvider->Get($strCacheKey);
				if ($objCachedObject !== false) {
					return $objCachedObject;
				}
			}
			// Use QuerySingle to Perform the Query
			$objToReturn = ApplyGradeImproment::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::ApplyGradeImproment()->IdapplyGradeImproment, $intIdapplyGradeImproment)
				),
				$objOptionalClauses
			);
			if ($strCacheKey !== false) {
				QApplication::$objCacheProvider->Set($strCacheKey, $objToReturn);
			}
			return $objToReturn;
		}

		/**
		 * Load all ApplyGradeImproments
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ApplyGradeImproment[]
		 */
		public static function LoadAll($objOptionalClauses = null) {
			if (func_num_args() > 1) {
				throw new QCallerException("LoadAll must be called with an array of optional clauses as a single argument");
			}
			// Call ApplyGradeImproment::QueryArray to perform the LoadAll query
			try {
				return ApplyGradeImproment::QueryArray(QQ::All(), $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count all ApplyGradeImproments
		 * @return int
		 */
		public static function CountAll() {
			// Call ApplyGradeImproment::QueryCount to perform the CountAll query
			return ApplyGradeImproment::QueryCount(QQ::All());
		}




		///////////////////////////////
		// QCUBED QUERY-RELATED METHODS
		///////////////////////////////

		/**
		 * Internally called method to assist with calling Qcubed Query for this class
		 * on load methods.
		 * @param QQueryBuilder &$objQueryBuilder the QueryBuilder object that will be created
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause object or array of QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with (sending in null will skip the PrepareStatement step)
		 * @param boolean $blnCountOnly only select a rowcount
		 * @return string the query statement
		 */
		protected static function BuildQueryStatement(&$objQueryBuilder, QQCondition $objConditions, $objOptionalClauses, $mixParameterArray, $blnCountOnly) {
			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();

			// Create/Build out the QueryBuilder object with ApplyGradeImproment-specific SELET and FROM fields
			$objQueryBuilder = new QQueryBuilder($objDatabase, 'apply_grade_improment');

			$blnAddAllFieldsToSelect = true;
			if ($objDatabase->OnlyFullGroupBy) {
				// see if we have any group by or aggregation clauses, if yes, don't add the fields to select clause
				if ($objOptionalClauses instanceof QQClause) {
					if ($objOptionalClauses instanceof QQAggregationClause || $objOptionalClauses instanceof QQGroupBy) {
						$blnAddAllFieldsToSelect = false;
					}
				} else if (is_array($objOptionalClauses)) {
					foreach ($objOptionalClauses as $objClause) {
						if ($objClause instanceof QQAggregationClause || $objClause instanceof QQGroupBy) {
							$blnAddAllFieldsToSelect = false;
							break;
						}
					}
				}
			}
			if ($blnAddAllFieldsToSelect) {
				ApplyGradeImproment::GetSelectFields($objQueryBuilder, null, QQuery::extractSelectClause($objOptionalClauses));
			}
			$objQueryBuilder->AddFromItem('apply_grade_improment');

			// Set "CountOnly" option (if applicable)
			if ($blnCountOnly)
				$objQueryBuilder->SetCountOnlyFlag();

			// Apply Any Conditions
			if ($objConditions)
				try {
					$objConditions->UpdateQueryBuilder($objQueryBuilder);
				} catch (QCallerException $objExc) {
					$objExc->IncrementOffset();
					throw $objExc;
				}

			// Iterate through all the Optional Clauses (if any) and perform accordingly
			if ($objOptionalClauses) {
				if ($objOptionalClauses instanceof QQClause)
					$objOptionalClauses->UpdateQueryBuilder($objQueryBuilder);
				else if (is_array($objOptionalClauses))
					foreach ($objOptionalClauses as $objClause)
						$objClause->UpdateQueryBuilder($objQueryBuilder);
				else
					throw new QCallerException('Optional Clauses must be a QQClause object or an array of QQClause objects');
			}

			// Get the SQL Statement
			$strQuery = $objQueryBuilder->GetStatement();

			// Prepare the Statement with the Query Parameters (if applicable)
			if ($mixParameterArray) {
				if (is_array($mixParameterArray)) {
					if (count($mixParameterArray))
						$strQuery = $objDatabase->PrepareStatement($strQuery, $mixParameterArray);

					// Ensure that there are no other Unresolved Named Parameters
					if (strpos($strQuery, chr(QQNamedValue::DelimiterCode) . '{') !== false)
						throw new QCallerException('Unresolved named parameters in the query');
				} else
					throw new QCallerException('Parameter Array must be an array of name-value parameter pairs');
			}

			// Return the Objects
			return $strQuery;
		}

		/**
		 * Static Qcubed Query method to query for a single ApplyGradeImproment object.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return ApplyGradeImproment the queried object
		 */
		public static function QuerySingle(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = ApplyGradeImproment::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query, Get the First Row, and Instantiate a new ApplyGradeImproment object
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Do we have to expand anything?
			if ($objQueryBuilder->ExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = ApplyGradeImproment::InstantiateDbRow($objDbRow, null, $objQueryBuilder->ExpandAsArrayNodes, $objToReturn, $objQueryBuilder->ColumnAliasArray);
					if ($objItem)
						$objToReturn[] = $objItem;
				}
				if (count($objToReturn)) {
					// Since we only want the object to return, lets return the object and not the array.
					return $objToReturn[0];
				} else {
					return null;
				}
			} else {
				// No expands just return the first row
				$objDbRow = $objDbResult->GetNextRow();
				if(null === $objDbRow)
					return null;
				return ApplyGradeImproment::InstantiateDbRow($objDbRow, null, null, null, $objQueryBuilder->ColumnAliasArray);
			}
		}

		/**
		 * Static Qcubed Query method to query for an array of ApplyGradeImproment objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return ApplyGradeImproment[] the queried objects as an array
		 */
		public static function QueryArray(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = ApplyGradeImproment::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and Instantiate the Array Result
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);
			return ApplyGradeImproment::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
		}

		/**
		 * Static Qcodo query method to issue a query and get a cursor to progressively fetch its results.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return QDatabaseResultBase the cursor resource instance
		 */
		public static function QueryCursor(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the query statement
			try {
				$strQuery = ApplyGradeImproment::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the query
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Return the results cursor
			$objDbResult->QueryBuilder = $objQueryBuilder;
			return $objDbResult;
		}

		/**
		 * Static Qcubed Query method to query for a count of ApplyGradeImproment objects.
		 * Uses BuildQueryStatment to perform most of the work.
		 * @param QQCondition $objConditions any conditions on the query, itself
		 * @param QQClause[] $objOptionalClausees additional optional QQClause objects for this query
		 * @param mixed[] $mixParameterArray a array of name-value pairs to perform PrepareStatement with
		 * @return integer the count of queried objects as an integer
		 */
		public static function QueryCount(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null) {
			// Get the Query Statement
			try {
				$strQuery = ApplyGradeImproment::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, true);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Perform the Query and return the row_count
			$objDbResult = $objQueryBuilder->Database->Query($strQuery);

			// Figure out if the query is using GroupBy
			$blnGrouped = false;

			if ($objOptionalClauses) foreach ($objOptionalClauses as $objClause) {
				if ($objClause instanceof QQGroupBy) {
					$blnGrouped = true;
					break;
				}
			}

			if ($blnGrouped)
				// Groups in this query - return the count of Groups (which is the count of all rows)
				return $objDbResult->CountRows();
			else {
				// No Groups - return the sql-calculated count(*) value
				$strDbRow = $objDbResult->FetchRow();
				return QType::Cast($strDbRow[0], QType::Integer);
			}
		}

		public static function QueryArrayCached(QQCondition $objConditions, $objOptionalClauses = null, $mixParameterArray = null, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();

			$strQuery = ApplyGradeImproment::BuildQueryStatement($objQueryBuilder, $objConditions, $objOptionalClauses, $mixParameterArray, false);

			$objCache = new QCache('qquery/applygradeimproment', $strQuery);
			$cacheData = $objCache->GetData();

			if (!$cacheData || $blnForceUpdate) {
				$objDbResult = $objQueryBuilder->Database->Query($strQuery);
				$arrResult = ApplyGradeImproment::InstantiateDbResult($objDbResult, $objQueryBuilder->ExpandAsArrayNodes, $objQueryBuilder->ColumnAliasArray);
				$objCache->SaveData(serialize($arrResult));
			} else {
				$arrResult = unserialize($cacheData);
			}

			return $arrResult;
		}

		/**
		 * Updates a QQueryBuilder with the SELECT fields for this ApplyGradeImproment
		 * @param QQueryBuilder $objBuilder the Query Builder object to update
		 * @param string $strPrefix optional prefix to add to the SELECT fields
		 */
		public static function GetSelectFields(QQueryBuilder $objBuilder, $strPrefix = null, QQSelect $objSelect = null) {
			if ($strPrefix) {
				$strTableName = $strPrefix;
				$strAliasPrefix = $strPrefix . '__';
			} else {
				$strTableName = 'apply_grade_improment';
				$strAliasPrefix = '';
			}

            if ($objSelect) {
			    $objBuilder->AddSelectItem($strTableName, 'idapply_grade_improment', $strAliasPrefix . 'idapply_grade_improment');
                $objSelect->AddSelectItems($objBuilder, $strTableName, $strAliasPrefix);
            } else {
			    $objBuilder->AddSelectItem($strTableName, 'idapply_grade_improment', $strAliasPrefix . 'idapply_grade_improment');
			    $objBuilder->AddSelectItem($strTableName, 'student', $strAliasPrefix . 'student');
			    $objBuilder->AddSelectItem($strTableName, 'subject', $strAliasPrefix . 'subject');
			    $objBuilder->AddSelectItem($strTableName, 'applied', $strAliasPrefix . 'applied');
			    $objBuilder->AddSelectItem($strTableName, 'applied_by', $strAliasPrefix . 'applied_by');
			    $objBuilder->AddSelectItem($strTableName, 'applied_date', $strAliasPrefix . 'applied_date');
			    $objBuilder->AddSelectItem($strTableName, 'discard', $strAliasPrefix . 'discard');
			    $objBuilder->AddSelectItem($strTableName, 'gradecard', $strAliasPrefix . 'gradecard');
            }
		}



		///////////////////////////////
		// INSTANTIATION-RELATED METHODS
		///////////////////////////////

		/**
		 * Instantiate a ApplyGradeImproment from a Database Row.
		 * Takes in an optional strAliasPrefix, used in case another Object::InstantiateDbRow
		 * is calling this ApplyGradeImproment::InstantiateDbRow in order to perform
		 * early binding on referenced objects.
		 * @param DatabaseRowBase $objDbRow
		 * @param string $strAliasPrefix
		 * @param string $strExpandAsArrayNodes
		 * @param QBaseClass $arrPreviousItem
		 * @param string[] $strColumnAliasArray
		 * @return ApplyGradeImproment
		*/
		public static function InstantiateDbRow($objDbRow, $strAliasPrefix = null, $strExpandAsArrayNodes = null, $arrPreviousItems = null, $strColumnAliasArray = array()) {
			// If blank row, return null
			if (!$objDbRow) {
				return null;
			}
			// See if we're doing an array expansion on the previous item
			$strAlias = $strAliasPrefix . 'idapply_grade_improment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (($strExpandAsArrayNodes) && is_array($arrPreviousItems) && count($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objPreviousItem->intIdapplyGradeImproment == $objDbRow->GetColumn($strAliasName, 'Integer')) {
						// We are.  Now, prepare to check for ExpandAsArray clauses
						$blnExpandedViaArray = false;
						if (!$strAliasPrefix)
							$strAliasPrefix = 'apply_grade_improment__';


						// Expanding reverse references: AppliedExamAsRefGradeImprovement
						$strAlias = $strAliasPrefix . 'appliedexamasrefgradeimprovement__idapplied_exam';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objAppliedExamAsRefGradeImprovementArray)
								$objPreviousItem->_objAppliedExamAsRefGradeImprovementArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objAppliedExamAsRefGradeImprovementArray)) {
								$objPreviousChildItems = $objPreviousItem->_objAppliedExamAsRefGradeImprovementArray;
								$objChildItem = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamasrefgradeimprovement__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objAppliedExamAsRefGradeImprovementArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objAppliedExamAsRefGradeImprovementArray[] = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamasrefgradeimprovement__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Expanding reverse references: GradeCardAsRefGradeImprovement
						$strAlias = $strAliasPrefix . 'gradecardasrefgradeimprovement__idgrade_card';
						$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
						if ((array_key_exists($strAlias, $strExpandAsArrayNodes)) &&
							(!is_null($objDbRow->GetColumn($strAliasName)))) {
							if(null === $objPreviousItem->_objGradeCardAsRefGradeImprovementArray)
								$objPreviousItem->_objGradeCardAsRefGradeImprovementArray = array();
							if ($intPreviousChildItemCount = count($objPreviousItem->_objGradeCardAsRefGradeImprovementArray)) {
								$objPreviousChildItems = $objPreviousItem->_objGradeCardAsRefGradeImprovementArray;
								$objChildItem = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasrefgradeimprovement__', $strExpandAsArrayNodes, $objPreviousChildItems, $strColumnAliasArray);
								if ($objChildItem) {
									$objPreviousItem->_objGradeCardAsRefGradeImprovementArray[] = $objChildItem;
								}
							} else {
								$objPreviousItem->_objGradeCardAsRefGradeImprovementArray[] = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasrefgradeimprovement__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
							}
							$blnExpandedViaArray = true;
						}

						// Either return false to signal array expansion, or check-to-reset the Alias prefix and move on
						if ($blnExpandedViaArray) {
							return false;
						} else if ($strAliasPrefix == 'apply_grade_improment__') {
							$strAliasPrefix = null;
						}
					}
				}
			}

			// Create a new instance of the ApplyGradeImproment object
			$objToReturn = new ApplyGradeImproment();
			$objToReturn->__blnRestored = true;

			$strAlias = $strAliasPrefix . 'idapply_grade_improment';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intIdapplyGradeImproment = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'student';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intStudent = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intSubject = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'applied';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnApplied = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'applied_by';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intAppliedBy = $objDbRow->GetColumn($strAliasName, 'Integer');
			$strAlias = $strAliasPrefix . 'applied_date';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->dttAppliedDate = $objDbRow->GetColumn($strAliasName, 'DateTime');
			$strAlias = $strAliasPrefix . 'discard';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->blnDiscard = $objDbRow->GetColumn($strAliasName, 'Bit');
			$strAlias = $strAliasPrefix . 'gradecard';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$objToReturn->intGradecard = $objDbRow->GetColumn($strAliasName, 'Integer');

			if (isset($arrPreviousItems) && is_array($arrPreviousItems)) {
				foreach ($arrPreviousItems as $objPreviousItem) {
					if ($objToReturn->IdapplyGradeImproment != $objPreviousItem->IdapplyGradeImproment) {
						continue;
					}
					$prevCnt = count($objPreviousItem->_objAppliedExamAsRefGradeImprovementArray);
					$cnt = count($objToReturn->_objAppliedExamAsRefGradeImprovementArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objAppliedExamAsRefGradeImprovementArray, $objToReturn->_objAppliedExamAsRefGradeImprovementArray)) {
						continue;
					}

					$prevCnt = count($objPreviousItem->_objGradeCardAsRefGradeImprovementArray);
					$cnt = count($objToReturn->_objGradeCardAsRefGradeImprovementArray);
					if ($prevCnt != $cnt)
					    continue;
					if ($prevCnt == 0 || $cnt == 0 || !array_diff($objPreviousItem->_objGradeCardAsRefGradeImprovementArray, $objToReturn->_objGradeCardAsRefGradeImprovementArray)) {
						continue;
					}


					// complete match - all primary key columns are the same
					return null;
				}
			}

			// Instantiate Virtual Attributes
			$strVirtualPrefix = $strAliasPrefix . '__';
			$strVirtualPrefixLength = strlen($strVirtualPrefix);
			foreach ($objDbRow->GetColumnNameArray() as $strColumnName => $mixValue) {
				if (strncmp($strColumnName, $strVirtualPrefix, $strVirtualPrefixLength) == 0)
					$objToReturn->__strVirtualAttributeArray[substr($strColumnName, $strVirtualPrefixLength)] = $mixValue;
			}

			// Prepare to Check for Early/Virtual Binding
			if (!$strAliasPrefix)
				$strAliasPrefix = 'apply_grade_improment__';

			// Check for StudentObject Early Binding
			$strAlias = $strAliasPrefix . 'student__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objStudentObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'student__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for SubjectObject Early Binding
			$strAlias = $strAliasPrefix . 'subject__idyearly_subject';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objSubjectObject = YearlySubject::InstantiateDbRow($objDbRow, $strAliasPrefix . 'subject__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for AppliedByObject Early Binding
			$strAlias = $strAliasPrefix . 'applied_by__idlogin';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objAppliedByObject = Login::InstantiateDbRow($objDbRow, $strAliasPrefix . 'applied_by__', $strExpandAsArrayNodes, null, $strColumnAliasArray);

			// Check for GradecardObject Early Binding
			$strAlias = $strAliasPrefix . 'gradecard__idgrade_card';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			if (!is_null($objDbRow->GetColumn($strAliasName)))
				$objToReturn->objGradecardObject = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecard__', $strExpandAsArrayNodes, null, $strColumnAliasArray);




			// Check for AppliedExamAsRefGradeImprovement Virtual Binding
			$strAlias = $strAliasPrefix . 'appliedexamasrefgradeimprovement__idapplied_exam';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objAppliedExamAsRefGradeImprovementArray)
				$objToReturn->_objAppliedExamAsRefGradeImprovementArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objAppliedExamAsRefGradeImprovementArray[] = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamasrefgradeimprovement__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objAppliedExamAsRefGradeImprovement = AppliedExam::InstantiateDbRow($objDbRow, $strAliasPrefix . 'appliedexamasrefgradeimprovement__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			// Check for GradeCardAsRefGradeImprovement Virtual Binding
			$strAlias = $strAliasPrefix . 'gradecardasrefgradeimprovement__idgrade_card';
			$strAliasName = array_key_exists($strAlias, $strColumnAliasArray) ? $strColumnAliasArray[$strAlias] : $strAlias;
			$blnExpanded = $strExpandAsArrayNodes && array_key_exists($strAlias, $strExpandAsArrayNodes);
			if ($blnExpanded && null === $objToReturn->_objGradeCardAsRefGradeImprovementArray)
				$objToReturn->_objGradeCardAsRefGradeImprovementArray = array();
			if (!is_null($objDbRow->GetColumn($strAliasName))) {
				if ($blnExpanded)
					$objToReturn->_objGradeCardAsRefGradeImprovementArray[] = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasrefgradeimprovement__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
				else
					$objToReturn->_objGradeCardAsRefGradeImprovement = GradeCard::InstantiateDbRow($objDbRow, $strAliasPrefix . 'gradecardasrefgradeimprovement__', $strExpandAsArrayNodes, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}

		/**
		 * Instantiate an array of ApplyGradeImproments from a Database Result
		 * @param DatabaseResultBase $objDbResult
		 * @param string $strExpandAsArrayNodes
		 * @param string[] $strColumnAliasArray
		 * @return ApplyGradeImproment[]
		 */
		public static function InstantiateDbResult(QDatabaseResultBase $objDbResult, $strExpandAsArrayNodes = null, $strColumnAliasArray = null) {
			$objToReturn = array();

			if (!$strColumnAliasArray)
				$strColumnAliasArray = array();

			// If blank resultset, then return empty array
			if (!$objDbResult)
				return $objToReturn;

			// Load up the return array with each row
			if ($strExpandAsArrayNodes) {
				$objToReturn = array();
				while ($objDbRow = $objDbResult->GetNextRow()) {
					$objItem = ApplyGradeImproment::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, $objToReturn, $strColumnAliasArray);
					if ($objItem) {
						$objToReturn[] = $objItem;
					}
				}
			} else {
				while ($objDbRow = $objDbResult->GetNextRow())
					$objToReturn[] = ApplyGradeImproment::InstantiateDbRow($objDbRow, null, null, null, $strColumnAliasArray);
			}

			return $objToReturn;
		}


		/**
		 * Instantiate a single ApplyGradeImproment object from a query cursor (e.g. a DB ResultSet).
		 * Cursor is automatically moved to the "next row" of the result set.
		 * Will return NULL if no cursor or if the cursor has no more rows in the resultset.
		 * @param QDatabaseResultBase $objDbResult cursor resource
		 * @return ApplyGradeImproment next row resulting from the query
		 */
		public static function InstantiateCursor(QDatabaseResultBase $objDbResult) {
			// If blank resultset, then return empty result
			if (!$objDbResult) return null;

			// If empty resultset, then return empty result
			$objDbRow = $objDbResult->GetNextRow();
			if (!$objDbRow) return null;

			// We need the Column Aliases
			$strColumnAliasArray = $objDbResult->QueryBuilder->ColumnAliasArray;
			if (!$strColumnAliasArray) $strColumnAliasArray = array();

			// Pull Expansions (if applicable)
			$strExpandAsArrayNodes = $objDbResult->QueryBuilder->ExpandAsArrayNodes;

			// Load up the return result with a row and return it
			return ApplyGradeImproment::InstantiateDbRow($objDbRow, null, $strExpandAsArrayNodes, null, $strColumnAliasArray);
		}




		///////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Single Load and Array)
		///////////////////////////////////////////////////

		/**
		 * Load a single ApplyGradeImproment object,
		 * by IdapplyGradeImproment Index(es)
		 * @param integer $intIdapplyGradeImproment
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ApplyGradeImproment
		*/
		public static function LoadByIdapplyGradeImproment($intIdapplyGradeImproment, $objOptionalClauses = null) {
			return ApplyGradeImproment::QuerySingle(
				QQ::AndCondition(
					QQ::Equal(QQN::ApplyGradeImproment()->IdapplyGradeImproment, $intIdapplyGradeImproment)
				),
				$objOptionalClauses
			);
		}

		/**
		 * Load an array of ApplyGradeImproment objects,
		 * by Student Index(es)
		 * @param integer $intStudent
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ApplyGradeImproment[]
		*/
		public static function LoadArrayByStudent($intStudent, $objOptionalClauses = null) {
			// Call ApplyGradeImproment::QueryArray to perform the LoadArrayByStudent query
			try {
				return ApplyGradeImproment::QueryArray(
					QQ::Equal(QQN::ApplyGradeImproment()->Student, $intStudent),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ApplyGradeImproments
		 * by Student Index(es)
		 * @param integer $intStudent
		 * @return int
		*/
		public static function CountByStudent($intStudent) {
			// Call ApplyGradeImproment::QueryCount to perform the CountByStudent query
			return ApplyGradeImproment::QueryCount(
				QQ::Equal(QQN::ApplyGradeImproment()->Student, $intStudent)
			);
		}

		/**
		 * Load an array of ApplyGradeImproment objects,
		 * by Subject Index(es)
		 * @param integer $intSubject
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ApplyGradeImproment[]
		*/
		public static function LoadArrayBySubject($intSubject, $objOptionalClauses = null) {
			// Call ApplyGradeImproment::QueryArray to perform the LoadArrayBySubject query
			try {
				return ApplyGradeImproment::QueryArray(
					QQ::Equal(QQN::ApplyGradeImproment()->Subject, $intSubject),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ApplyGradeImproments
		 * by Subject Index(es)
		 * @param integer $intSubject
		 * @return int
		*/
		public static function CountBySubject($intSubject) {
			// Call ApplyGradeImproment::QueryCount to perform the CountBySubject query
			return ApplyGradeImproment::QueryCount(
				QQ::Equal(QQN::ApplyGradeImproment()->Subject, $intSubject)
			);
		}

		/**
		 * Load an array of ApplyGradeImproment objects,
		 * by AppliedBy Index(es)
		 * @param integer $intAppliedBy
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ApplyGradeImproment[]
		*/
		public static function LoadArrayByAppliedBy($intAppliedBy, $objOptionalClauses = null) {
			// Call ApplyGradeImproment::QueryArray to perform the LoadArrayByAppliedBy query
			try {
				return ApplyGradeImproment::QueryArray(
					QQ::Equal(QQN::ApplyGradeImproment()->AppliedBy, $intAppliedBy),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ApplyGradeImproments
		 * by AppliedBy Index(es)
		 * @param integer $intAppliedBy
		 * @return int
		*/
		public static function CountByAppliedBy($intAppliedBy) {
			// Call ApplyGradeImproment::QueryCount to perform the CountByAppliedBy query
			return ApplyGradeImproment::QueryCount(
				QQ::Equal(QQN::ApplyGradeImproment()->AppliedBy, $intAppliedBy)
			);
		}

		/**
		 * Load an array of ApplyGradeImproment objects,
		 * by Gradecard Index(es)
		 * @param integer $intGradecard
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return ApplyGradeImproment[]
		*/
		public static function LoadArrayByGradecard($intGradecard, $objOptionalClauses = null) {
			// Call ApplyGradeImproment::QueryArray to perform the LoadArrayByGradecard query
			try {
				return ApplyGradeImproment::QueryArray(
					QQ::Equal(QQN::ApplyGradeImproment()->Gradecard, $intGradecard),
					$objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Count ApplyGradeImproments
		 * by Gradecard Index(es)
		 * @param integer $intGradecard
		 * @return int
		*/
		public static function CountByGradecard($intGradecard) {
			// Call ApplyGradeImproment::QueryCount to perform the CountByGradecard query
			return ApplyGradeImproment::QueryCount(
				QQ::Equal(QQN::ApplyGradeImproment()->Gradecard, $intGradecard)
			);
		}



		////////////////////////////////////////////////////
		// INDEX-BASED LOAD METHODS (Array via Many to Many)
		////////////////////////////////////////////////////





		//////////////////////////
		// SAVE, DELETE AND RELOAD
		//////////////////////////

		/**
		 * Save this ApplyGradeImproment
		 * @param bool $blnForceInsert
		 * @param bool $blnForceUpdate
		 * @return int
		 */
		public function Save($blnForceInsert = false, $blnForceUpdate = false) {
			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();

			$mixToReturn = null;

			try {
				if ((!$this->__blnRestored) || ($blnForceInsert)) {
					// Perform an INSERT query
					$objDatabase->NonQuery('
						INSERT INTO `apply_grade_improment` (
							`student`,
							`subject`,
							`applied`,
							`applied_by`,
							`applied_date`,
							`discard`,
							`gradecard`
						) VALUES (
							' . $objDatabase->SqlVariable($this->intStudent) . ',
							' . $objDatabase->SqlVariable($this->intSubject) . ',
							' . $objDatabase->SqlVariable($this->blnApplied) . ',
							' . $objDatabase->SqlVariable($this->intAppliedBy) . ',
							' . $objDatabase->SqlVariable($this->dttAppliedDate) . ',
							' . $objDatabase->SqlVariable($this->blnDiscard) . ',
							' . $objDatabase->SqlVariable($this->intGradecard) . '
						)
					');

					// Update Identity column and return its value
					$mixToReturn = $this->intIdapplyGradeImproment = $objDatabase->InsertId('apply_grade_improment', 'idapply_grade_improment');
				} else {
					// Perform an UPDATE query

					// First checking for Optimistic Locking constraints (if applicable)

					// Perform the UPDATE query
					$objDatabase->NonQuery('
						UPDATE
							`apply_grade_improment`
						SET
							`student` = ' . $objDatabase->SqlVariable($this->intStudent) . ',
							`subject` = ' . $objDatabase->SqlVariable($this->intSubject) . ',
							`applied` = ' . $objDatabase->SqlVariable($this->blnApplied) . ',
							`applied_by` = ' . $objDatabase->SqlVariable($this->intAppliedBy) . ',
							`applied_date` = ' . $objDatabase->SqlVariable($this->dttAppliedDate) . ',
							`discard` = ' . $objDatabase->SqlVariable($this->blnDiscard) . ',
							`gradecard` = ' . $objDatabase->SqlVariable($this->intGradecard) . '
						WHERE
							`idapply_grade_improment` = ' . $objDatabase->SqlVariable($this->intIdapplyGradeImproment) . '
					');
				}

			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}

			// Update __blnRestored and any Non-Identity PK Columns (if applicable)
			$this->__blnRestored = true;


			$this->DeleteCache();

			// Return
			return $mixToReturn;
		}

		/**
		 * Delete this ApplyGradeImproment
		 * @return void
		 */
		public function Delete() {
			if ((is_null($this->intIdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Cannot delete this ApplyGradeImproment with an unset primary key.');

			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();


			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`apply_grade_improment`
				WHERE
					`idapply_grade_improment` = ' . $objDatabase->SqlVariable($this->intIdapplyGradeImproment) . '');

			$this->DeleteCache();
		}

        /**
 	     * Delete this ApplyGradeImproment ONLY from the cache
 		 * @return void
		 */
		public function DeleteCache() {
			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				$strCacheKey = QApplication::$objCacheProvider->CreateKey(QApplication::$Database[1]->Database, 'ApplyGradeImproment', $this->intIdapplyGradeImproment);
				QApplication::$objCacheProvider->Delete($strCacheKey);
			}
		}

		/**
		 * Delete all ApplyGradeImproments
		 * @return void
		 */
		public static function DeleteAll() {
			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				DELETE FROM
					`apply_grade_improment`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Truncate apply_grade_improment table
		 * @return void
		 */
		public static function Truncate() {
			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();

			// Perform the Query
			$objDatabase->NonQuery('
				TRUNCATE `apply_grade_improment`');

			if (QApplication::$objCacheProvider && QApplication::$Database[1]->Caching) {
				QApplication::$objCacheProvider->DeleteAll();
			}
		}

		/**
		 * Reload this ApplyGradeImproment from the database.
		 * @return void
		 */
		public function Reload() {
			// Make sure we are actually Restored from the database
			if (!$this->__blnRestored)
				throw new QCallerException('Cannot call Reload() on a new, unsaved ApplyGradeImproment object.');

			$this->DeleteCache();

			// Reload the Object
			$objReloaded = ApplyGradeImproment::Load($this->intIdapplyGradeImproment);

			// Update $this's local variables to match
			$this->Student = $objReloaded->Student;
			$this->Subject = $objReloaded->Subject;
			$this->blnApplied = $objReloaded->blnApplied;
			$this->AppliedBy = $objReloaded->AppliedBy;
			$this->dttAppliedDate = $objReloaded->dttAppliedDate;
			$this->blnDiscard = $objReloaded->blnDiscard;
			$this->Gradecard = $objReloaded->Gradecard;
		}



		////////////////////
		// PUBLIC OVERRIDERS
		////////////////////

				/**
		 * Override method to perform a property "Get"
		 * This will get the value of $strName
		 *
		 * @param string $strName Name of the property to get
		 * @return mixed
		 */
		public function __get($strName) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'IdapplyGradeImproment':
					/**
					 * Gets the value for intIdapplyGradeImproment (Read-Only PK)
					 * @return integer
					 */
					return $this->intIdapplyGradeImproment;

				case 'Student':
					/**
					 * Gets the value for intStudent (Not Null)
					 * @return integer
					 */
					return $this->intStudent;

				case 'Subject':
					/**
					 * Gets the value for intSubject (Not Null)
					 * @return integer
					 */
					return $this->intSubject;

				case 'Applied':
					/**
					 * Gets the value for blnApplied 
					 * @return boolean
					 */
					return $this->blnApplied;

				case 'AppliedBy':
					/**
					 * Gets the value for intAppliedBy 
					 * @return integer
					 */
					return $this->intAppliedBy;

				case 'AppliedDate':
					/**
					 * Gets the value for dttAppliedDate 
					 * @return QDateTime
					 */
					return $this->dttAppliedDate;

				case 'Discard':
					/**
					 * Gets the value for blnDiscard 
					 * @return boolean
					 */
					return $this->blnDiscard;

				case 'Gradecard':
					/**
					 * Gets the value for intGradecard 
					 * @return integer
					 */
					return $this->intGradecard;


				///////////////////
				// Member Objects
				///////////////////
				case 'StudentObject':
					/**
					 * Gets the value for the Login object referenced by intStudent (Not Null)
					 * @return Login
					 */
					try {
						if ((!$this->objStudentObject) && (!is_null($this->intStudent)))
							$this->objStudentObject = Login::Load($this->intStudent);
						return $this->objStudentObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'SubjectObject':
					/**
					 * Gets the value for the YearlySubject object referenced by intSubject (Not Null)
					 * @return YearlySubject
					 */
					try {
						if ((!$this->objSubjectObject) && (!is_null($this->intSubject)))
							$this->objSubjectObject = YearlySubject::Load($this->intSubject);
						return $this->objSubjectObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AppliedByObject':
					/**
					 * Gets the value for the Login object referenced by intAppliedBy 
					 * @return Login
					 */
					try {
						if ((!$this->objAppliedByObject) && (!is_null($this->intAppliedBy)))
							$this->objAppliedByObject = Login::Load($this->intAppliedBy);
						return $this->objAppliedByObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'GradecardObject':
					/**
					 * Gets the value for the GradeCard object referenced by intGradecard 
					 * @return GradeCard
					 */
					try {
						if ((!$this->objGradecardObject) && (!is_null($this->intGradecard)))
							$this->objGradecardObject = GradeCard::Load($this->intGradecard);
						return $this->objGradecardObject;
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				////////////////////////////
				// Virtual Object References (Many to Many and Reverse References)
				// (If restored via a "Many-to" expansion)
				////////////////////////////

				case '_AppliedExamAsRefGradeImprovement':
					/**
					 * Gets the value for the private _objAppliedExamAsRefGradeImprovement (Read-Only)
					 * if set due to an expansion on the applied_exam.ref_grade_improvement reverse relationship
					 * @return AppliedExam
					 */
					return $this->_objAppliedExamAsRefGradeImprovement;

				case '_AppliedExamAsRefGradeImprovementArray':
					/**
					 * Gets the value for the private _objAppliedExamAsRefGradeImprovementArray (Read-Only)
					 * if set due to an ExpandAsArray on the applied_exam.ref_grade_improvement reverse relationship
					 * @return AppliedExam[]
					 */
					return $this->_objAppliedExamAsRefGradeImprovementArray;

				case '_GradeCardAsRefGradeImprovement':
					/**
					 * Gets the value for the private _objGradeCardAsRefGradeImprovement (Read-Only)
					 * if set due to an expansion on the grade_card.ref_grade_improvement reverse relationship
					 * @return GradeCard
					 */
					return $this->_objGradeCardAsRefGradeImprovement;

				case '_GradeCardAsRefGradeImprovementArray':
					/**
					 * Gets the value for the private _objGradeCardAsRefGradeImprovementArray (Read-Only)
					 * if set due to an ExpandAsArray on the grade_card.ref_grade_improvement reverse relationship
					 * @return GradeCard[]
					 */
					return $this->_objGradeCardAsRefGradeImprovementArray;


				case '__Restored':
					return $this->__blnRestored;

				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

				/**
		 * Override method to perform a property "Set"
		 * This will set the property $strName to be $mixValue
		 *
		 * @param string $strName Name of the property to set
		 * @param string $mixValue New value of the property
		 * @return mixed
		 */
		public function __set($strName, $mixValue) {
			switch ($strName) {
				///////////////////
				// Member Variables
				///////////////////
				case 'Student':
					/**
					 * Sets the value for intStudent (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objStudentObject = null;
						return ($this->intStudent = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Subject':
					/**
					 * Sets the value for intSubject (Not Null)
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objSubjectObject = null;
						return ($this->intSubject = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Applied':
					/**
					 * Sets the value for blnApplied 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnApplied = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AppliedBy':
					/**
					 * Sets the value for intAppliedBy 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objAppliedByObject = null;
						return ($this->intAppliedBy = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'AppliedDate':
					/**
					 * Sets the value for dttAppliedDate 
					 * @param QDateTime $mixValue
					 * @return QDateTime
					 */
					try {
						return ($this->dttAppliedDate = QType::Cast($mixValue, QType::DateTime));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Discard':
					/**
					 * Sets the value for blnDiscard 
					 * @param boolean $mixValue
					 * @return boolean
					 */
					try {
						return ($this->blnDiscard = QType::Cast($mixValue, QType::Boolean));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}

				case 'Gradecard':
					/**
					 * Sets the value for intGradecard 
					 * @param integer $mixValue
					 * @return integer
					 */
					try {
						$this->objGradecardObject = null;
						return ($this->intGradecard = QType::Cast($mixValue, QType::Integer));
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}


				///////////////////
				// Member Objects
				///////////////////
				case 'StudentObject':
					/**
					 * Sets the value for the Login object referenced by intStudent (Not Null)
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intStudent = null;
						$this->objStudentObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved StudentObject for this ApplyGradeImproment');

						// Update Local Member Variables
						$this->objStudentObject = $mixValue;
						$this->intStudent = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'SubjectObject':
					/**
					 * Sets the value for the YearlySubject object referenced by intSubject (Not Null)
					 * @param YearlySubject $mixValue
					 * @return YearlySubject
					 */
					if (is_null($mixValue)) {
						$this->intSubject = null;
						$this->objSubjectObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a YearlySubject object
						try {
							$mixValue = QType::Cast($mixValue, 'YearlySubject');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED YearlySubject object
						if (is_null($mixValue->IdyearlySubject))
							throw new QCallerException('Unable to set an unsaved SubjectObject for this ApplyGradeImproment');

						// Update Local Member Variables
						$this->objSubjectObject = $mixValue;
						$this->intSubject = $mixValue->IdyearlySubject;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'AppliedByObject':
					/**
					 * Sets the value for the Login object referenced by intAppliedBy 
					 * @param Login $mixValue
					 * @return Login
					 */
					if (is_null($mixValue)) {
						$this->intAppliedBy = null;
						$this->objAppliedByObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a Login object
						try {
							$mixValue = QType::Cast($mixValue, 'Login');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED Login object
						if (is_null($mixValue->Idlogin))
							throw new QCallerException('Unable to set an unsaved AppliedByObject for this ApplyGradeImproment');

						// Update Local Member Variables
						$this->objAppliedByObject = $mixValue;
						$this->intAppliedBy = $mixValue->Idlogin;

						// Return $mixValue
						return $mixValue;
					}
					break;

				case 'GradecardObject':
					/**
					 * Sets the value for the GradeCard object referenced by intGradecard 
					 * @param GradeCard $mixValue
					 * @return GradeCard
					 */
					if (is_null($mixValue)) {
						$this->intGradecard = null;
						$this->objGradecardObject = null;
						return null;
					} else {
						// Make sure $mixValue actually is a GradeCard object
						try {
							$mixValue = QType::Cast($mixValue, 'GradeCard');
						} catch (QInvalidCastException $objExc) {
							$objExc->IncrementOffset();
							throw $objExc;
						}

						// Make sure $mixValue is a SAVED GradeCard object
						if (is_null($mixValue->IdgradeCard))
							throw new QCallerException('Unable to set an unsaved GradecardObject for this ApplyGradeImproment');

						// Update Local Member Variables
						$this->objGradecardObject = $mixValue;
						$this->intGradecard = $mixValue->IdgradeCard;

						// Return $mixValue
						return $mixValue;
					}
					break;

				default:
					try {
						return parent::__set($strName, $mixValue);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}

		/**
		 * Lookup a VirtualAttribute value (if applicable).  Returns NULL if none found.
		 * @param string $strName
		 * @return string
		 */
		public function GetVirtualAttribute($strName) {
			if (array_key_exists($strName, $this->__strVirtualAttributeArray))
				return $this->__strVirtualAttributeArray[$strName];
			return null;
		}



		///////////////////////////////
		// ASSOCIATED OBJECTS' METHODS
		///////////////////////////////



		// Related Objects' Methods for AppliedExamAsRefGradeImprovement
		//-------------------------------------------------------------------

		/**
		 * Gets all associated AppliedExamsAsRefGradeImprovement as an array of AppliedExam objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return AppliedExam[]
		*/
		public function GetAppliedExamAsRefGradeImprovementArray($objOptionalClauses = null) {
			if ((is_null($this->intIdapplyGradeImproment)))
				return array();

			try {
				return AppliedExam::LoadArrayByRefGradeImprovement($this->intIdapplyGradeImproment, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated AppliedExamsAsRefGradeImprovement
		 * @return int
		*/
		public function CountAppliedExamsAsRefGradeImprovement() {
			if ((is_null($this->intIdapplyGradeImproment)))
				return 0;

			return AppliedExam::CountByRefGradeImprovement($this->intIdapplyGradeImproment);
		}

		/**
		 * Associates a AppliedExamAsRefGradeImprovement
		 * @param AppliedExam $objAppliedExam
		 * @return void
		*/
		public function AssociateAppliedExamAsRefGradeImprovement(AppliedExam $objAppliedExam) {
			if ((is_null($this->intIdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppliedExamAsRefGradeImprovement on this unsaved ApplyGradeImproment.');
			if ((is_null($objAppliedExam->IdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateAppliedExamAsRefGradeImprovement on this ApplyGradeImproment with an unsaved AppliedExam.');

			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`applied_exam`
				SET
					`ref_grade_improvement` = ' . $objDatabase->SqlVariable($this->intIdapplyGradeImproment) . '
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($objAppliedExam->IdappliedExam) . '
			');
		}

		/**
		 * Unassociates a AppliedExamAsRefGradeImprovement
		 * @param AppliedExam $objAppliedExam
		 * @return void
		*/
		public function UnassociateAppliedExamAsRefGradeImprovement(AppliedExam $objAppliedExam) {
			if ((is_null($this->intIdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsRefGradeImprovement on this unsaved ApplyGradeImproment.');
			if ((is_null($objAppliedExam->IdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsRefGradeImprovement on this ApplyGradeImproment with an unsaved AppliedExam.');

			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`applied_exam`
				SET
					`ref_grade_improvement` = null
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($objAppliedExam->IdappliedExam) . ' AND
					`ref_grade_improvement` = ' . $objDatabase->SqlVariable($this->intIdapplyGradeImproment) . '
			');
		}

		/**
		 * Unassociates all AppliedExamsAsRefGradeImprovement
		 * @return void
		*/
		public function UnassociateAllAppliedExamsAsRefGradeImprovement() {
			if ((is_null($this->intIdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsRefGradeImprovement on this unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`applied_exam`
				SET
					`ref_grade_improvement` = null
				WHERE
					`ref_grade_improvement` = ' . $objDatabase->SqlVariable($this->intIdapplyGradeImproment) . '
			');
		}

		/**
		 * Deletes an associated AppliedExamAsRefGradeImprovement
		 * @param AppliedExam $objAppliedExam
		 * @return void
		*/
		public function DeleteAssociatedAppliedExamAsRefGradeImprovement(AppliedExam $objAppliedExam) {
			if ((is_null($this->intIdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsRefGradeImprovement on this unsaved ApplyGradeImproment.');
			if ((is_null($objAppliedExam->IdappliedExam)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsRefGradeImprovement on this ApplyGradeImproment with an unsaved AppliedExam.');

			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`applied_exam`
				WHERE
					`idapplied_exam` = ' . $objDatabase->SqlVariable($objAppliedExam->IdappliedExam) . ' AND
					`ref_grade_improvement` = ' . $objDatabase->SqlVariable($this->intIdapplyGradeImproment) . '
			');
		}

		/**
		 * Deletes all associated AppliedExamsAsRefGradeImprovement
		 * @return void
		*/
		public function DeleteAllAppliedExamsAsRefGradeImprovement() {
			if ((is_null($this->intIdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateAppliedExamAsRefGradeImprovement on this unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`applied_exam`
				WHERE
					`ref_grade_improvement` = ' . $objDatabase->SqlVariable($this->intIdapplyGradeImproment) . '
			');
		}


		// Related Objects' Methods for GradeCardAsRefGradeImprovement
		//-------------------------------------------------------------------

		/**
		 * Gets all associated GradeCardsAsRefGradeImprovement as an array of GradeCard objects
		 * @param QQClause[] $objOptionalClauses additional optional QQClause objects for this query
		 * @return GradeCard[]
		*/
		public function GetGradeCardAsRefGradeImprovementArray($objOptionalClauses = null) {
			if ((is_null($this->intIdapplyGradeImproment)))
				return array();

			try {
				return GradeCard::LoadArrayByRefGradeImprovement($this->intIdapplyGradeImproment, $objOptionalClauses);
			} catch (QCallerException $objExc) {
				$objExc->IncrementOffset();
				throw $objExc;
			}
		}

		/**
		 * Counts all associated GradeCardsAsRefGradeImprovement
		 * @return int
		*/
		public function CountGradeCardsAsRefGradeImprovement() {
			if ((is_null($this->intIdapplyGradeImproment)))
				return 0;

			return GradeCard::CountByRefGradeImprovement($this->intIdapplyGradeImproment);
		}

		/**
		 * Associates a GradeCardAsRefGradeImprovement
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function AssociateGradeCardAsRefGradeImprovement(GradeCard $objGradeCard) {
			if ((is_null($this->intIdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGradeCardAsRefGradeImprovement on this unsaved ApplyGradeImproment.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call AssociateGradeCardAsRefGradeImprovement on this ApplyGradeImproment with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`ref_grade_improvement` = ' . $objDatabase->SqlVariable($this->intIdapplyGradeImproment) . '
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . '
			');
		}

		/**
		 * Unassociates a GradeCardAsRefGradeImprovement
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function UnassociateGradeCardAsRefGradeImprovement(GradeCard $objGradeCard) {
			if ((is_null($this->intIdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsRefGradeImprovement on this unsaved ApplyGradeImproment.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsRefGradeImprovement on this ApplyGradeImproment with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`ref_grade_improvement` = null
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . ' AND
					`ref_grade_improvement` = ' . $objDatabase->SqlVariable($this->intIdapplyGradeImproment) . '
			');
		}

		/**
		 * Unassociates all GradeCardsAsRefGradeImprovement
		 * @return void
		*/
		public function UnassociateAllGradeCardsAsRefGradeImprovement() {
			if ((is_null($this->intIdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsRefGradeImprovement on this unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				UPDATE
					`grade_card`
				SET
					`ref_grade_improvement` = null
				WHERE
					`ref_grade_improvement` = ' . $objDatabase->SqlVariable($this->intIdapplyGradeImproment) . '
			');
		}

		/**
		 * Deletes an associated GradeCardAsRefGradeImprovement
		 * @param GradeCard $objGradeCard
		 * @return void
		*/
		public function DeleteAssociatedGradeCardAsRefGradeImprovement(GradeCard $objGradeCard) {
			if ((is_null($this->intIdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsRefGradeImprovement on this unsaved ApplyGradeImproment.');
			if ((is_null($objGradeCard->IdgradeCard)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsRefGradeImprovement on this ApplyGradeImproment with an unsaved GradeCard.');

			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`
				WHERE
					`idgrade_card` = ' . $objDatabase->SqlVariable($objGradeCard->IdgradeCard) . ' AND
					`ref_grade_improvement` = ' . $objDatabase->SqlVariable($this->intIdapplyGradeImproment) . '
			');
		}

		/**
		 * Deletes all associated GradeCardsAsRefGradeImprovement
		 * @return void
		*/
		public function DeleteAllGradeCardsAsRefGradeImprovement() {
			if ((is_null($this->intIdapplyGradeImproment)))
				throw new QUndefinedPrimaryKeyException('Unable to call UnassociateGradeCardAsRefGradeImprovement on this unsaved ApplyGradeImproment.');

			// Get the Database Object for this Class
			$objDatabase = ApplyGradeImproment::GetDatabase();

			// Perform the SQL Query
			$objDatabase->NonQuery('
				DELETE FROM
					`grade_card`
				WHERE
					`ref_grade_improvement` = ' . $objDatabase->SqlVariable($this->intIdapplyGradeImproment) . '
			');
		}


		
		///////////////////////////////
		// METHODS TO EXTRACT INFO ABOUT THE CLASS
		///////////////////////////////

		/**
		 * Static method to retrieve the Database object that owns this class.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetTableName() {
			return "apply_grade_improment";
		}

		/**
		 * Static method to retrieve the Table name from which this class has been created.
		 * @return string Name of the table from which this class has been created.
		 */
		public static function GetDatabaseName() {
			return QApplication::$Database[ApplyGradeImproment::GetDatabaseIndex()]->Database;
		}

		/**
		 * Static method to retrieve the Database index in the configuration.inc.php file.
		 * This can be useful when there are two databases of the same name which create
		 * confusion for the developer. There are no internal uses of this function but are
		 * here to help retrieve info if need be!
		 * @return int position or index of the database in the config file.
		 */
		public static function GetDatabaseIndex() {
			return 1;
		}

		////////////////////////////////////////
		// METHODS for SOAP-BASED WEB SERVICES
		////////////////////////////////////////

		public static function GetSoapComplexTypeXml() {
			$strToReturn = '<complexType name="ApplyGradeImproment"><sequence>';
			$strToReturn .= '<element name="IdapplyGradeImproment" type="xsd:int"/>';
			$strToReturn .= '<element name="StudentObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="SubjectObject" type="xsd1:YearlySubject"/>';
			$strToReturn .= '<element name="Applied" type="xsd:boolean"/>';
			$strToReturn .= '<element name="AppliedByObject" type="xsd1:Login"/>';
			$strToReturn .= '<element name="AppliedDate" type="xsd:dateTime"/>';
			$strToReturn .= '<element name="Discard" type="xsd:boolean"/>';
			$strToReturn .= '<element name="GradecardObject" type="xsd1:GradeCard"/>';
			$strToReturn .= '<element name="__blnRestored" type="xsd:boolean"/>';
			$strToReturn .= '</sequence></complexType>';
			return $strToReturn;
		}

		public static function AlterSoapComplexTypeArray(&$strComplexTypeArray) {
			if (!array_key_exists('ApplyGradeImproment', $strComplexTypeArray)) {
				$strComplexTypeArray['ApplyGradeImproment'] = ApplyGradeImproment::GetSoapComplexTypeXml();
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				YearlySubject::AlterSoapComplexTypeArray($strComplexTypeArray);
				Login::AlterSoapComplexTypeArray($strComplexTypeArray);
				GradeCard::AlterSoapComplexTypeArray($strComplexTypeArray);
			}
		}

		public static function GetArrayFromSoapArray($objSoapArray) {
			$objArrayToReturn = array();

			foreach ($objSoapArray as $objSoapObject)
				array_push($objArrayToReturn, ApplyGradeImproment::GetObjectFromSoapObject($objSoapObject));

			return $objArrayToReturn;
		}

		public static function GetObjectFromSoapObject($objSoapObject) {
			$objToReturn = new ApplyGradeImproment();
			if (property_exists($objSoapObject, 'IdapplyGradeImproment'))
				$objToReturn->intIdapplyGradeImproment = $objSoapObject->IdapplyGradeImproment;
			if ((property_exists($objSoapObject, 'StudentObject')) &&
				($objSoapObject->StudentObject))
				$objToReturn->StudentObject = Login::GetObjectFromSoapObject($objSoapObject->StudentObject);
			if ((property_exists($objSoapObject, 'SubjectObject')) &&
				($objSoapObject->SubjectObject))
				$objToReturn->SubjectObject = YearlySubject::GetObjectFromSoapObject($objSoapObject->SubjectObject);
			if (property_exists($objSoapObject, 'Applied'))
				$objToReturn->blnApplied = $objSoapObject->Applied;
			if ((property_exists($objSoapObject, 'AppliedByObject')) &&
				($objSoapObject->AppliedByObject))
				$objToReturn->AppliedByObject = Login::GetObjectFromSoapObject($objSoapObject->AppliedByObject);
			if (property_exists($objSoapObject, 'AppliedDate'))
				$objToReturn->dttAppliedDate = new QDateTime($objSoapObject->AppliedDate);
			if (property_exists($objSoapObject, 'Discard'))
				$objToReturn->blnDiscard = $objSoapObject->Discard;
			if ((property_exists($objSoapObject, 'GradecardObject')) &&
				($objSoapObject->GradecardObject))
				$objToReturn->GradecardObject = GradeCard::GetObjectFromSoapObject($objSoapObject->GradecardObject);
			if (property_exists($objSoapObject, '__blnRestored'))
				$objToReturn->__blnRestored = $objSoapObject->__blnRestored;
			return $objToReturn;
		}

		public static function GetSoapArrayFromArray($objArray) {
			if (!$objArray)
				return null;

			$objArrayToReturn = array();

			foreach ($objArray as $objObject)
				array_push($objArrayToReturn, ApplyGradeImproment::GetSoapObjectFromObject($objObject, true));

			return unserialize(serialize($objArrayToReturn));
		}

		public static function GetSoapObjectFromObject($objObject, $blnBindRelatedObjects) {
			if ($objObject->objStudentObject)
				$objObject->objStudentObject = Login::GetSoapObjectFromObject($objObject->objStudentObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intStudent = null;
			if ($objObject->objSubjectObject)
				$objObject->objSubjectObject = YearlySubject::GetSoapObjectFromObject($objObject->objSubjectObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intSubject = null;
			if ($objObject->objAppliedByObject)
				$objObject->objAppliedByObject = Login::GetSoapObjectFromObject($objObject->objAppliedByObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intAppliedBy = null;
			if ($objObject->dttAppliedDate)
				$objObject->dttAppliedDate = $objObject->dttAppliedDate->qFormat(QDateTime::FormatSoap);
			if ($objObject->objGradecardObject)
				$objObject->objGradecardObject = GradeCard::GetSoapObjectFromObject($objObject->objGradecardObject, false);
			else if (!$blnBindRelatedObjects)
				$objObject->intGradecard = null;
			return $objObject;
		}


		////////////////////////////////////////
		// METHODS for JSON Object Translation
		////////////////////////////////////////

		// this function is required for objects that implement the
		// IteratorAggregate interface
		public function getIterator() {
			///////////////////
			// Member Variables
			///////////////////
			$iArray['IdapplyGradeImproment'] = $this->intIdapplyGradeImproment;
			$iArray['Student'] = $this->intStudent;
			$iArray['Subject'] = $this->intSubject;
			$iArray['Applied'] = $this->blnApplied;
			$iArray['AppliedBy'] = $this->intAppliedBy;
			$iArray['AppliedDate'] = $this->dttAppliedDate;
			$iArray['Discard'] = $this->blnDiscard;
			$iArray['Gradecard'] = $this->intGradecard;
			return new ArrayIterator($iArray);
		}

		// this function returns a Json formatted string using the
		// IteratorAggregate interface
		public function getJson() {
			return json_encode($this->getIterator());
		}

		/**
		 * Default "toJsObject" handler
		 * Specifies how the object should be displayed in JQuery UI lists and menus. Note that these lists use
		 * value and label differently.
		 *
		 * value 	= The short form of what to display in the list and selection.
		 * label 	= [optional] If defined, is what is displayed in the menu
		 * id 		= Primary key of object.
		 *
		 * @return an array that specifies how to display the object
		 */
		public function toJsObject () {
			return JavaScriptHelper::toJsObject(array('value' => $this->__toString(), 'id' =>  $this->intIdapplyGradeImproment ));
		}



	}



	/////////////////////////////////////
	// ADDITIONAL CLASSES for QCubed QUERY
	/////////////////////////////////////

    /**
     * @uses QQNode
     *
     * @property-read QQNode $IdapplyGradeImproment
     * @property-read QQNode $Student
     * @property-read QQNodeLogin $StudentObject
     * @property-read QQNode $Subject
     * @property-read QQNodeYearlySubject $SubjectObject
     * @property-read QQNode $Applied
     * @property-read QQNode $AppliedBy
     * @property-read QQNodeLogin $AppliedByObject
     * @property-read QQNode $AppliedDate
     * @property-read QQNode $Discard
     * @property-read QQNode $Gradecard
     * @property-read QQNodeGradeCard $GradecardObject
     *
     *
     * @property-read QQReverseReferenceNodeAppliedExam $AppliedExamAsRefGradeImprovement
     * @property-read QQReverseReferenceNodeGradeCard $GradeCardAsRefGradeImprovement

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQNodeApplyGradeImproment extends QQNode {
		protected $strTableName = 'apply_grade_improment';
		protected $strPrimaryKey = 'idapply_grade_improment';
		protected $strClassName = 'ApplyGradeImproment';
		public function __get($strName) {
			switch ($strName) {
				case 'IdapplyGradeImproment':
					return new QQNode('idapply_grade_improment', 'IdapplyGradeImproment', 'Integer', $this);
				case 'Student':
					return new QQNode('student', 'Student', 'Integer', $this);
				case 'StudentObject':
					return new QQNodeLogin('student', 'StudentObject', 'Integer', $this);
				case 'Subject':
					return new QQNode('subject', 'Subject', 'Integer', $this);
				case 'SubjectObject':
					return new QQNodeYearlySubject('subject', 'SubjectObject', 'Integer', $this);
				case 'Applied':
					return new QQNode('applied', 'Applied', 'Bit', $this);
				case 'AppliedBy':
					return new QQNode('applied_by', 'AppliedBy', 'Integer', $this);
				case 'AppliedByObject':
					return new QQNodeLogin('applied_by', 'AppliedByObject', 'Integer', $this);
				case 'AppliedDate':
					return new QQNode('applied_date', 'AppliedDate', 'DateTime', $this);
				case 'Discard':
					return new QQNode('discard', 'Discard', 'Bit', $this);
				case 'Gradecard':
					return new QQNode('gradecard', 'Gradecard', 'Integer', $this);
				case 'GradecardObject':
					return new QQNodeGradeCard('gradecard', 'GradecardObject', 'Integer', $this);
				case 'AppliedExamAsRefGradeImprovement':
					return new QQReverseReferenceNodeAppliedExam($this, 'appliedexamasrefgradeimprovement', 'reverse_reference', 'ref_grade_improvement');
				case 'GradeCardAsRefGradeImprovement':
					return new QQReverseReferenceNodeGradeCard($this, 'gradecardasrefgradeimprovement', 'reverse_reference', 'ref_grade_improvement');

				case '_PrimaryKeyNode':
					return new QQNode('idapply_grade_improment', 'IdapplyGradeImproment', 'Integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

    /**
     * @property-read QQNode $IdapplyGradeImproment
     * @property-read QQNode $Student
     * @property-read QQNodeLogin $StudentObject
     * @property-read QQNode $Subject
     * @property-read QQNodeYearlySubject $SubjectObject
     * @property-read QQNode $Applied
     * @property-read QQNode $AppliedBy
     * @property-read QQNodeLogin $AppliedByObject
     * @property-read QQNode $AppliedDate
     * @property-read QQNode $Discard
     * @property-read QQNode $Gradecard
     * @property-read QQNodeGradeCard $GradecardObject
     *
     *
     * @property-read QQReverseReferenceNodeAppliedExam $AppliedExamAsRefGradeImprovement
     * @property-read QQReverseReferenceNodeGradeCard $GradeCardAsRefGradeImprovement

     * @property-read QQNode $_PrimaryKeyNode
     **/
	class QQReverseReferenceNodeApplyGradeImproment extends QQReverseReferenceNode {
		protected $strTableName = 'apply_grade_improment';
		protected $strPrimaryKey = 'idapply_grade_improment';
		protected $strClassName = 'ApplyGradeImproment';
		public function __get($strName) {
			switch ($strName) {
				case 'IdapplyGradeImproment':
					return new QQNode('idapply_grade_improment', 'IdapplyGradeImproment', 'integer', $this);
				case 'Student':
					return new QQNode('student', 'Student', 'integer', $this);
				case 'StudentObject':
					return new QQNodeLogin('student', 'StudentObject', 'integer', $this);
				case 'Subject':
					return new QQNode('subject', 'Subject', 'integer', $this);
				case 'SubjectObject':
					return new QQNodeYearlySubject('subject', 'SubjectObject', 'integer', $this);
				case 'Applied':
					return new QQNode('applied', 'Applied', 'boolean', $this);
				case 'AppliedBy':
					return new QQNode('applied_by', 'AppliedBy', 'integer', $this);
				case 'AppliedByObject':
					return new QQNodeLogin('applied_by', 'AppliedByObject', 'integer', $this);
				case 'AppliedDate':
					return new QQNode('applied_date', 'AppliedDate', 'QDateTime', $this);
				case 'Discard':
					return new QQNode('discard', 'Discard', 'boolean', $this);
				case 'Gradecard':
					return new QQNode('gradecard', 'Gradecard', 'integer', $this);
				case 'GradecardObject':
					return new QQNodeGradeCard('gradecard', 'GradecardObject', 'integer', $this);
				case 'AppliedExamAsRefGradeImprovement':
					return new QQReverseReferenceNodeAppliedExam($this, 'appliedexamasrefgradeimprovement', 'reverse_reference', 'ref_grade_improvement');
				case 'GradeCardAsRefGradeImprovement':
					return new QQReverseReferenceNodeGradeCard($this, 'gradecardasrefgradeimprovement', 'reverse_reference', 'ref_grade_improvement');

				case '_PrimaryKeyNode':
					return new QQNode('idapply_grade_improment', 'IdapplyGradeImproment', 'integer', $this);
				default:
					try {
						return parent::__get($strName);
					} catch (QCallerException $objExc) {
						$objExc->IncrementOffset();
						throw $objExc;
					}
			}
		}
	}

?>
